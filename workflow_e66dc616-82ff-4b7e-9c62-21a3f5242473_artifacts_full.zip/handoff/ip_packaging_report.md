# IP Packaging & Handoff Report

- Top: `imported_from_arch2rtl`
- Package: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/e66dc616-82ff-4b7e-9c62-21a3f5242473/60f8ef54-49ad-47d2-8e3c-af30a9ee96a2/digital/arch2tapeout/handoff/imported_from_arch2rtl_ip_package`
- Zip: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/e66dc616-82ff-4b7e-9c62-21a3f5242473/60f8ef54-49ad-47d2-8e3c-af30a9ee96a2/digital/arch2tapeout/handoff/imported_from_arch2rtl_ip_package.zip`

## Bucket counts
- **rtl**: 1
- **spec**: 1
- **arch**: 0
- **microarch**: 0
- **regmap**: 1
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 2
