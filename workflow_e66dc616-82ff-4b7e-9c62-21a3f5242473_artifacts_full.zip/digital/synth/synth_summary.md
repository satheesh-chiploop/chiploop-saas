# Digital Synthesis Summary

- **Workflow**: e66dc616-82ff-4b7e-9c62-21a3f5242473
- **Status**: `ok` (rc=0)
- **Top module**: `pwm_controller_mmio`
- **Clock**: `clk` @ **10.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/e66dc616-82ff-4b7e-9c62-21a3f5242473/60f8ef54-49ad-47d2-8e3c-af30a9ee96a2/digital/arch2tapeout/digital/synth/runs/digital_e66dc616-82ff-4b7e-9c62-21a3f5242473/final/metrics.json`
- netlist candidates: 1 found
