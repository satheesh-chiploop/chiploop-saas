module pwm_controller_mmio (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    rd_data,
    pwm_out,
    counter_value
);

input clk;
input reset_n;
input wr_en;
input [7:0] wr_addr;
input [7:0] wr_data;
input rd_en;
input [7:0] rd_addr;
output reg [7:0] rd_data;
output reg pwm_out;
output reg [7:0] counter_value;

reg [7:0] control_reg;
reg [7:0] duty_cycle_reg;
reg [7:0] period_reg;

wire enable;
wire period_nonzero;
wire will_wrap;
wire [7:0] counter_next;
wire pwm_next;

assign enable = control_reg[0];
assign period_nonzero = (period_reg != 8'h00);
assign will_wrap = period_nonzero && (counter_value == period_reg);

assign counter_next = (enable && period_nonzero) ? (will_wrap ? 8'h00 : (counter_value + 8'h01)) : counter_value;
assign pwm_next = enable && (counter_value < duty_cycle_reg) && period_nonzero;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        control_reg <= 8'h00;
        duty_cycle_reg <= 8'h00;
        period_reg <= 8'h00;
        counter_value <= 8'h00;
        pwm_out <= 1'b0;
    end else begin
        if (wr_en) begin
            case (wr_addr)
                8'h00: control_reg <= {7'b00000000, wr_data[0]};
                8'h04: duty_cycle_reg <= wr_data;
                8'h08: period_reg <= wr_data;
                8'h0C: begin
                    control_reg <= control_reg;
                    duty_cycle_reg <= duty_cycle_reg;
                    period_reg <= period_reg;
                end
                default: begin
                    control_reg <= control_reg;
                    duty_cycle_reg <= duty_cycle_reg;
                    period_reg <= period_reg;
                end
            endcase
        end
        counter_value <= counter_next;
        pwm_out <= pwm_next;
    end
end

always @(*) begin
    rd_data = 8'h00;
    if (rd_en) begin
        case (rd_addr)
            8'h00: rd_data = control_reg;
            8'h04: rd_data = duty_cycle_reg;
            8'h08: rd_data = period_reg;
            8'h0C: rd_data = counter_value;
            default: rd_data = 8'h00;
        endcase
    end
end

endmodule
