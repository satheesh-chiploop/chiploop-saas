# Digital Executive Summary
- workflow_id: `e66dc616-82ff-4b7e-9c62-21a3f5242473`
- run_tag: `digital_e66dc616-82ff-4b7e-9c62-21a3f5242473`
- run_work_dir: `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/e66dc616-82ff-4b7e-9c62-21a3f5242473/60f8ef54-49ad-47d2-8e3c-af30a9ee96a2/digital/arch2tapeout/digital/run_work`

## Key Metrics (best-effort parsed)
- Cell count: `142`
- Area: `1767.9456`
- STA stage used: `None`
- Worst slack: `None`
- TNS: `None`
- DRC violations: `0`
- DRC status: `clean`
- LVS status: `clean`
- Tapeout status: `failed`
- Tapeout LEC status: `incomplete_stdcell_models`
- ATPG status: `adapter_completed_no_patterns`
- Summary status: `failed`

## STA Stage Breakdown
- sta_preplace: worst_slack=`None`, tns=`None`
- sta_postplace: worst_slack=`None`, tns=`None`
- sta_postcts: worst_slack=`None`, tns=`None`
- sta_postroute: worst_slack=`None`, tns=`None`

## GDS Paths (local, only if produced)
- KLayout GDS: `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/e66dc616-82ff-4b7e-9c62-21a3f5242473/60f8ef54-49ad-47d2-8e3c-af30a9ee96a2/digital/arch2tapeout/digital/tapeout/gds/klayout.gds`
- Magic GDS: `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/e66dc616-82ff-4b7e-9c62-21a3f5242473/60f8ef54-49ad-47d2-8e3c-af30a9ee96a2/digital/arch2tapeout/digital/tapeout/gds/magic.gds`

## Artifact Map
- synth_metrics: `digital/synth/metrics.json`
- sta_preplace_metrics: `None`
- sta_postplace_metrics: `None`
- sta_postcts_metrics: `None`
- sta_postroute_metrics: `None`
- drc_metrics: `None`
- lvs_metrics: `None`
- tapeout_metrics: `digital/tapeout/metrics.json`

## Next Iteration Suggestions
- If worst_slack < 0: relax constraints or improve synthesis/placement/CTS/route parameters.
- If DRC violations > 0: inspect DRC logs and rerun with adjusted floorplan/route settings.
- If LVS not clean: check extraction/streamout mismatch and netlist naming.