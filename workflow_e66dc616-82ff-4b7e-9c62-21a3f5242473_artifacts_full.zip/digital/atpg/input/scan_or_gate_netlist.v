module pwm_controller_mmio (clk,
    pwm_out,
    rd_en,
    reset_n,
    scan_en,
    wr_en,
    counter_value,
    rd_addr,
    rd_data,
    scan_in,
    scan_out,
    wr_addr,
    wr_data);
 input clk;
 output pwm_out;
 input rd_en;
 input reset_n;
 input scan_en;
 input wr_en;
 output [7:0] counter_value;
 input [7:0] rd_addr;
 output [7:0] rd_data;
 input [3:0] scan_in;
 output [3:0] scan_out;
 input [7:0] wr_addr;
 input [7:0] wr_data;

 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire _086_;
 wire _087_;
 wire _088_;
 wire _089_;
 wire _090_;
 wire _091_;
 wire _092_;
 wire _093_;
 wire _094_;
 wire _095_;
 wire _096_;
 wire _097_;
 wire _098_;
 wire _099_;
 wire _100_;
 wire _101_;
 wire _102_;
 wire _103_;
 wire _104_;
 wire _105_;
 wire _106_;
 wire \duty_cycle_reg[0] ;
 wire \duty_cycle_reg[1] ;
 wire \duty_cycle_reg[2] ;
 wire \duty_cycle_reg[3] ;
 wire \duty_cycle_reg[4] ;
 wire \duty_cycle_reg[5] ;
 wire \duty_cycle_reg[6] ;
 wire \duty_cycle_reg[7] ;
 wire enable;
 wire \period_reg[0] ;
 wire \period_reg[1] ;
 wire \period_reg[2] ;
 wire \period_reg[3] ;
 wire \period_reg[4] ;
 wire \period_reg[5] ;
 wire \period_reg[6] ;
 wire \period_reg[7] ;
 wire pwm_next;

 sky130_fd_sc_hd__xor2_2 _107_ (.A(\period_reg[1] ),
    .B(counter_value[1]),
    .X(_063_));
 sky130_fd_sc_hd__nand2_2 _108_ (.A(\period_reg[0] ),
    .B(counter_value[0]),
    .Y(_064_));
 sky130_fd_sc_hd__or2_2 _109_ (.A(\period_reg[0] ),
    .B(counter_value[0]),
    .X(_065_));
 sky130_fd_sc_hd__nand2_2 _110_ (.A(\period_reg[3] ),
    .B(counter_value[3]),
    .Y(_066_));
 sky130_fd_sc_hd__or2_2 _111_ (.A(\period_reg[3] ),
    .B(counter_value[3]),
    .X(_067_));
 sky130_fd_sc_hd__xor2_2 _112_ (.A(\period_reg[2] ),
    .B(counter_value[2]),
    .X(_068_));
 sky130_fd_sc_hd__a221o_2 _113_ (.A1(_064_),
    .A2(_065_),
    .B1(_066_),
    .B2(_067_),
    .C1(_063_),
    .X(_069_));
 sky130_fd_sc_hd__xor2_2 _114_ (.A(\period_reg[6] ),
    .B(counter_value[6]),
    .X(_070_));
 sky130_fd_sc_hd__xor2_2 _115_ (.A(\period_reg[7] ),
    .B(counter_value[7]),
    .X(_071_));
 sky130_fd_sc_hd__xor2_2 _116_ (.A(\period_reg[5] ),
    .B(counter_value[5]),
    .X(_072_));
 sky130_fd_sc_hd__xor2_2 _117_ (.A(\period_reg[4] ),
    .B(counter_value[4]),
    .X(_073_));
 sky130_fd_sc_hd__or4_2 _118_ (.A(_070_),
    .B(_071_),
    .C(_072_),
    .D(_073_),
    .X(_074_));
 sky130_fd_sc_hd__or4b_2 _119_ (.A(_068_),
    .B(_069_),
    .C(_074_),
    .D_N(_033_),
    .X(_075_));
 sky130_fd_sc_hd__and2_2 _120_ (.A(counter_value[0]),
    .B(_033_),
    .X(_076_));
 sky130_fd_sc_hd__o21ai_2 _121_ (.A1(counter_value[0]),
    .A2(_033_),
    .B1(_075_),
    .Y(_077_));
 sky130_fd_sc_hd__nor2_2 _122_ (.A(_076_),
    .B(_077_),
    .Y(_009_));
 sky130_fd_sc_hd__a21boi_2 _123_ (.A1(counter_value[1]),
    .A2(_076_),
    .B1_N(_075_),
    .Y(_078_));
 sky130_fd_sc_hd__o21a_2 _124_ (.A1(counter_value[1]),
    .A2(_076_),
    .B1(_078_),
    .X(_010_));
 sky130_fd_sc_hd__a31o_2 _125_ (.A1(counter_value[1]),
    .A2(counter_value[0]),
    .A3(_033_),
    .B1(counter_value[2]),
    .X(_079_));
 sky130_fd_sc_hd__and3_2 _126_ (.A(counter_value[2]),
    .B(counter_value[1]),
    .C(counter_value[0]),
    .X(_080_));
 sky130_fd_sc_hd__o211a_2 _127_ (.A1(_031_),
    .A2(_032_),
    .B1(_080_),
    .C1(enable),
    .X(_081_));
 sky130_fd_sc_hd__inv_2 _128_ (.A(_081_),
    .Y(_082_));
 sky130_fd_sc_hd__and3_2 _129_ (.A(_075_),
    .B(_079_),
    .C(_082_),
    .X(_011_));
 sky130_fd_sc_hd__or2_2 _130_ (.A(counter_value[3]),
    .B(_081_),
    .X(_083_));
 sky130_fd_sc_hd__o211a_2 _131_ (.A1(_097_),
    .A2(_082_),
    .B1(_083_),
    .C1(_075_),
    .X(_012_));
 sky130_fd_sc_hd__a21o_2 _132_ (.A1(counter_value[3]),
    .A2(_081_),
    .B1(counter_value[4]),
    .X(_084_));
 sky130_fd_sc_hd__and2_2 _133_ (.A(counter_value[4]),
    .B(counter_value[3]),
    .X(_085_));
 sky130_fd_sc_hd__o2111a_2 _134_ (.A1(_031_),
    .A2(_032_),
    .B1(_080_),
    .C1(_085_),
    .D1(enable),
    .X(_086_));
 sky130_fd_sc_hd__nand2_2 _135_ (.A(_075_),
    .B(_084_),
    .Y(_087_));
 sky130_fd_sc_hd__nor2_2 _136_ (.A(_086_),
    .B(_087_),
    .Y(_013_));
 sky130_fd_sc_hd__o21ai_2 _137_ (.A1(counter_value[5]),
    .A2(_086_),
    .B1(_075_),
    .Y(_088_));
 sky130_fd_sc_hd__a21oi_2 _138_ (.A1(counter_value[5]),
    .A2(_086_),
    .B1(_088_),
    .Y(_014_));
 sky130_fd_sc_hd__a21o_2 _139_ (.A1(counter_value[5]),
    .A2(_086_),
    .B1(counter_value[6]),
    .X(_089_));
 sky130_fd_sc_hd__nand3_2 _140_ (.A(counter_value[6]),
    .B(counter_value[5]),
    .C(_086_),
    .Y(_090_));
 sky130_fd_sc_hd__and3_2 _141_ (.A(_075_),
    .B(_089_),
    .C(_090_),
    .X(_015_));
 sky130_fd_sc_hd__o21ai_2 _142_ (.A1(_095_),
    .A2(_090_),
    .B1(_075_),
    .Y(_091_));
 sky130_fd_sc_hd__a21oi_2 _143_ (.A1(_095_),
    .A2(_090_),
    .B1(_091_),
    .Y(_016_));
 sky130_fd_sc_hd__or4b_2 _144_ (.A(wr_addr[3]),
    .B(_094_),
    .C(_060_),
    .D_N(wr_addr[2]),
    .X(_092_));
 sky130_fd_sc_hd__mux2_1 _145_ (.A0(wr_data[0]),
    .A1(\duty_cycle_reg[0] ),
    .S(_092_),
    .X(_017_));
 sky130_fd_sc_hd__mux2_1 _146_ (.A0(wr_data[1]),
    .A1(\duty_cycle_reg[1] ),
    .S(_092_),
    .X(_018_));
 sky130_fd_sc_hd__mux2_1 _147_ (.A0(wr_data[2]),
    .A1(\duty_cycle_reg[2] ),
    .S(_092_),
    .X(_019_));
 sky130_fd_sc_hd__mux2_1 _148_ (.A0(wr_data[3]),
    .A1(\duty_cycle_reg[3] ),
    .S(_092_),
    .X(_020_));
 sky130_fd_sc_hd__mux2_1 _149_ (.A0(wr_data[4]),
    .A1(\duty_cycle_reg[4] ),
    .S(_092_),
    .X(_021_));
 sky130_fd_sc_hd__mux2_1 _150_ (.A0(wr_data[5]),
    .A1(\duty_cycle_reg[5] ),
    .S(_092_),
    .X(_022_));
 sky130_fd_sc_hd__mux2_1 _151_ (.A0(wr_data[6]),
    .A1(\duty_cycle_reg[6] ),
    .S(_092_),
    .X(_023_));
 sky130_fd_sc_hd__mux2_1 _152_ (.A0(wr_data[7]),
    .A1(\duty_cycle_reg[7] ),
    .S(_092_),
    .X(_024_));
 sky130_fd_sc_hd__inv_2 _153_ (.A(wr_addr[3]),
    .Y(_093_));
 sky130_fd_sc_hd__inv_2 _154_ (.A(wr_en),
    .Y(_094_));
 sky130_fd_sc_hd__inv_2 _155_ (.A(counter_value[7]),
    .Y(_095_));
 sky130_fd_sc_hd__inv_2 _156_ (.A(counter_value[5]),
    .Y(_096_));
 sky130_fd_sc_hd__inv_2 _157_ (.A(counter_value[3]),
    .Y(_097_));
 sky130_fd_sc_hd__inv_2 _158_ (.A(counter_value[2]),
    .Y(_098_));
 sky130_fd_sc_hd__o22a_2 _159_ (.A1(\duty_cycle_reg[3] ),
    .A2(_097_),
    .B1(\duty_cycle_reg[2] ),
    .B2(_098_),
    .X(_099_));
 sky130_fd_sc_hd__nand2b_2 _160_ (.A_N(\duty_cycle_reg[1] ),
    .B(counter_value[1]),
    .Y(_100_));
 sky130_fd_sc_hd__and2b_2 _161_ (.A_N(counter_value[0]),
    .B(\duty_cycle_reg[0] ),
    .X(_101_));
 sky130_fd_sc_hd__and2b_2 _162_ (.A_N(counter_value[1]),
    .B(\duty_cycle_reg[1] ),
    .X(_102_));
 sky130_fd_sc_hd__a221o_2 _163_ (.A1(\duty_cycle_reg[2] ),
    .A2(_098_),
    .B1(_100_),
    .B2(_101_),
    .C1(_102_),
    .X(_103_));
 sky130_fd_sc_hd__and2b_2 _164_ (.A_N(counter_value[5]),
    .B(\duty_cycle_reg[5] ),
    .X(_104_));
 sky130_fd_sc_hd__xor2_2 _165_ (.A(counter_value[4]),
    .B(\duty_cycle_reg[4] ),
    .X(_105_));
 sky130_fd_sc_hd__a211o_2 _166_ (.A1(\duty_cycle_reg[3] ),
    .A2(_097_),
    .B1(_104_),
    .C1(_105_),
    .X(_106_));
 sky130_fd_sc_hd__a21o_2 _167_ (.A1(_099_),
    .A2(_103_),
    .B1(_106_),
    .X(_025_));
 sky130_fd_sc_hd__or3b_2 _168_ (.A(\duty_cycle_reg[4] ),
    .B(_104_),
    .C_N(counter_value[4]),
    .X(_026_));
 sky130_fd_sc_hd__o21a_2 _169_ (.A1(\duty_cycle_reg[5] ),
    .A2(_096_),
    .B1(_026_),
    .X(_027_));
 sky130_fd_sc_hd__and2_2 _170_ (.A(_095_),
    .B(\duty_cycle_reg[7] ),
    .X(_028_));
 sky130_fd_sc_hd__xor2_2 _171_ (.A(\duty_cycle_reg[6] ),
    .B(counter_value[6]),
    .X(_029_));
 sky130_fd_sc_hd__a211o_2 _172_ (.A1(_025_),
    .A2(_027_),
    .B1(_028_),
    .C1(_029_),
    .X(_030_));
 sky130_fd_sc_hd__or4_2 _173_ (.A(\period_reg[5] ),
    .B(\period_reg[4] ),
    .C(\period_reg[7] ),
    .D(\period_reg[6] ),
    .X(_031_));
 sky130_fd_sc_hd__or4_2 _174_ (.A(\period_reg[1] ),
    .B(\period_reg[0] ),
    .C(\period_reg[3] ),
    .D(\period_reg[2] ),
    .X(_032_));
 sky130_fd_sc_hd__o21a_2 _175_ (.A1(_031_),
    .A2(_032_),
    .B1(enable),
    .X(_033_));
 sky130_fd_sc_hd__or3b_2 _176_ (.A(\duty_cycle_reg[6] ),
    .B(_028_),
    .C_N(counter_value[6]),
    .X(_034_));
 sky130_fd_sc_hd__o2111a_2 _177_ (.A1(_095_),
    .A2(\duty_cycle_reg[7] ),
    .B1(_030_),
    .C1(_033_),
    .D1(_034_),
    .X(pwm_next));
 sky130_fd_sc_hd__or2_2 _178_ (.A(rd_addr[5]),
    .B(rd_addr[4]),
    .X(_035_));
 sky130_fd_sc_hd__or4b_2 _179_ (.A(rd_addr[7]),
    .B(rd_addr[6]),
    .C(_035_),
    .D_N(rd_addr[3]),
    .X(_036_));
 sky130_fd_sc_hd__or3b_2 _180_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .C_N(rd_addr[2]),
    .X(_037_));
 sky130_fd_sc_hd__nor2_2 _181_ (.A(_036_),
    .B(_037_),
    .Y(_038_));
 sky130_fd_sc_hd__nor4_2 _182_ (.A(rd_addr[3]),
    .B(rd_addr[7]),
    .C(rd_addr[6]),
    .D(_035_),
    .Y(_039_));
 sky130_fd_sc_hd__nor3_2 _183_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .C(rd_addr[2]),
    .Y(_040_));
 sky130_fd_sc_hd__a32o_2 _184_ (.A1(enable),
    .A2(_039_),
    .A3(_040_),
    .B1(counter_value[0]),
    .B2(_038_),
    .X(_041_));
 sky130_fd_sc_hd__and2b_2 _185_ (.A_N(_036_),
    .B(_040_),
    .X(_042_));
 sky130_fd_sc_hd__and2b_2 _186_ (.A_N(_037_),
    .B(_039_),
    .X(_043_));
 sky130_fd_sc_hd__a22o_2 _187_ (.A1(\period_reg[0] ),
    .A2(_042_),
    .B1(_043_),
    .B2(\duty_cycle_reg[0] ),
    .X(_044_));
 sky130_fd_sc_hd__o21a_2 _188_ (.A1(_041_),
    .A2(_044_),
    .B1(rd_en),
    .X(rd_data[0]));
 sky130_fd_sc_hd__and2_2 _189_ (.A(counter_value[1]),
    .B(_038_),
    .X(_045_));
 sky130_fd_sc_hd__a22o_2 _190_ (.A1(\period_reg[1] ),
    .A2(_042_),
    .B1(_043_),
    .B2(\duty_cycle_reg[1] ),
    .X(_046_));
 sky130_fd_sc_hd__o21a_2 _191_ (.A1(_045_),
    .A2(_046_),
    .B1(rd_en),
    .X(rd_data[1]));
 sky130_fd_sc_hd__and2_2 _192_ (.A(\period_reg[2] ),
    .B(_042_),
    .X(_047_));
 sky130_fd_sc_hd__a22o_2 _193_ (.A1(counter_value[2]),
    .A2(_038_),
    .B1(_043_),
    .B2(\duty_cycle_reg[2] ),
    .X(_048_));
 sky130_fd_sc_hd__o21a_2 _194_ (.A1(_047_),
    .A2(_048_),
    .B1(rd_en),
    .X(rd_data[2]));
 sky130_fd_sc_hd__and2_2 _195_ (.A(\period_reg[3] ),
    .B(_042_),
    .X(_049_));
 sky130_fd_sc_hd__a22o_2 _196_ (.A1(counter_value[3]),
    .A2(_038_),
    .B1(_043_),
    .B2(\duty_cycle_reg[3] ),
    .X(_050_));
 sky130_fd_sc_hd__o21a_2 _197_ (.A1(_049_),
    .A2(_050_),
    .B1(rd_en),
    .X(rd_data[3]));
 sky130_fd_sc_hd__and2_2 _198_ (.A(counter_value[4]),
    .B(_038_),
    .X(_051_));
 sky130_fd_sc_hd__a22o_2 _199_ (.A1(\period_reg[4] ),
    .A2(_042_),
    .B1(_043_),
    .B2(\duty_cycle_reg[4] ),
    .X(_052_));
 sky130_fd_sc_hd__o21a_2 _200_ (.A1(_051_),
    .A2(_052_),
    .B1(rd_en),
    .X(rd_data[4]));
 sky130_fd_sc_hd__and2_2 _201_ (.A(\period_reg[5] ),
    .B(_042_),
    .X(_053_));
 sky130_fd_sc_hd__a22o_2 _202_ (.A1(counter_value[5]),
    .A2(_038_),
    .B1(_043_),
    .B2(\duty_cycle_reg[5] ),
    .X(_054_));
 sky130_fd_sc_hd__o21a_2 _203_ (.A1(_053_),
    .A2(_054_),
    .B1(rd_en),
    .X(rd_data[5]));
 sky130_fd_sc_hd__and2_2 _204_ (.A(\period_reg[6] ),
    .B(_042_),
    .X(_055_));
 sky130_fd_sc_hd__a22o_2 _205_ (.A1(counter_value[6]),
    .A2(_038_),
    .B1(_043_),
    .B2(\duty_cycle_reg[6] ),
    .X(_056_));
 sky130_fd_sc_hd__o21a_2 _206_ (.A1(_055_),
    .A2(_056_),
    .B1(rd_en),
    .X(rd_data[6]));
 sky130_fd_sc_hd__and2_2 _207_ (.A(counter_value[7]),
    .B(_038_),
    .X(_057_));
 sky130_fd_sc_hd__a22o_2 _208_ (.A1(\period_reg[7] ),
    .A2(_042_),
    .B1(_043_),
    .B2(\duty_cycle_reg[7] ),
    .X(_058_));
 sky130_fd_sc_hd__o21a_2 _209_ (.A1(_057_),
    .A2(_058_),
    .B1(rd_en),
    .X(rd_data[7]));
 sky130_fd_sc_hd__or4_2 _210_ (.A(wr_addr[5]),
    .B(wr_addr[4]),
    .C(wr_addr[7]),
    .D(wr_addr[6]),
    .X(_059_));
 sky130_fd_sc_hd__or3_2 _211_ (.A(wr_addr[1]),
    .B(wr_addr[0]),
    .C(_059_),
    .X(_060_));
 sky130_fd_sc_hd__or4_2 _212_ (.A(wr_addr[2]),
    .B(_093_),
    .C(_094_),
    .D(_060_),
    .X(_061_));
 sky130_fd_sc_hd__mux2_1 _213_ (.A0(wr_data[0]),
    .A1(\period_reg[0] ),
    .S(_061_),
    .X(_000_));
 sky130_fd_sc_hd__mux2_1 _214_ (.A0(wr_data[1]),
    .A1(\period_reg[1] ),
    .S(_061_),
    .X(_001_));
 sky130_fd_sc_hd__mux2_1 _215_ (.A0(wr_data[2]),
    .A1(\period_reg[2] ),
    .S(_061_),
    .X(_002_));
 sky130_fd_sc_hd__mux2_1 _216_ (.A0(wr_data[3]),
    .A1(\period_reg[3] ),
    .S(_061_),
    .X(_003_));
 sky130_fd_sc_hd__mux2_1 _217_ (.A0(wr_data[4]),
    .A1(\period_reg[4] ),
    .S(_061_),
    .X(_004_));
 sky130_fd_sc_hd__mux2_1 _218_ (.A0(wr_data[5]),
    .A1(\period_reg[5] ),
    .S(_061_),
    .X(_005_));
 sky130_fd_sc_hd__mux2_1 _219_ (.A0(wr_data[6]),
    .A1(\period_reg[6] ),
    .S(_061_),
    .X(_006_));
 sky130_fd_sc_hd__mux2_1 _220_ (.A0(wr_data[7]),
    .A1(\period_reg[7] ),
    .S(_061_),
    .X(_007_));
 sky130_fd_sc_hd__or4_2 _221_ (.A(wr_addr[2]),
    .B(wr_addr[3]),
    .C(_094_),
    .D(_060_),
    .X(_062_));
 sky130_fd_sc_hd__mux2_1 _222_ (.A0(wr_data[0]),
    .A1(enable),
    .S(_062_),
    .X(_008_));
 sky130_fd_sc_hd__sdfrtp_2 _223_ (.CLK(clk),
    .D(_000_),
    .RESET_B(reset_n),
    .SCD(scan_in[0]),
    .SCE(scan_en),
    .Q(\period_reg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _224_ (.CLK(clk),
    .D(_001_),
    .RESET_B(reset_n),
    .SCD(scan_in[1]),
    .SCE(scan_en),
    .Q(\period_reg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _225_ (.CLK(clk),
    .D(_002_),
    .RESET_B(reset_n),
    .SCD(scan_in[2]),
    .SCE(scan_en),
    .Q(\period_reg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _226_ (.CLK(clk),
    .D(_003_),
    .RESET_B(reset_n),
    .SCD(scan_in[3]),
    .SCE(scan_en),
    .Q(\period_reg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _227_ (.CLK(clk),
    .D(_004_),
    .RESET_B(reset_n),
    .SCD(\period_reg[0] ),
    .SCE(scan_en),
    .Q(\period_reg[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _228_ (.CLK(clk),
    .D(_005_),
    .RESET_B(reset_n),
    .SCD(\period_reg[1] ),
    .SCE(scan_en),
    .Q(\period_reg[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _229_ (.CLK(clk),
    .D(_006_),
    .RESET_B(reset_n),
    .SCD(\period_reg[2] ),
    .SCE(scan_en),
    .Q(\period_reg[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _230_ (.CLK(clk),
    .D(_007_),
    .RESET_B(reset_n),
    .SCD(\period_reg[3] ),
    .SCE(scan_en),
    .Q(\period_reg[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _231_ (.CLK(clk),
    .D(pwm_next),
    .RESET_B(reset_n),
    .SCD(\period_reg[4] ),
    .SCE(scan_en),
    .Q(pwm_out));
 sky130_fd_sc_hd__sdfrtp_2 _232_ (.CLK(clk),
    .D(_008_),
    .RESET_B(reset_n),
    .SCD(\period_reg[5] ),
    .SCE(scan_en),
    .Q(enable));
 sky130_fd_sc_hd__sdfrtp_2 _233_ (.CLK(clk),
    .D(_009_),
    .RESET_B(reset_n),
    .SCD(\period_reg[6] ),
    .SCE(scan_en),
    .Q(counter_value[0]));
 sky130_fd_sc_hd__sdfrtp_2 _234_ (.CLK(clk),
    .D(_010_),
    .RESET_B(reset_n),
    .SCD(\period_reg[7] ),
    .SCE(scan_en),
    .Q(counter_value[1]));
 sky130_fd_sc_hd__sdfrtp_2 _235_ (.CLK(clk),
    .D(_011_),
    .RESET_B(reset_n),
    .SCD(pwm_out),
    .SCE(scan_en),
    .Q(counter_value[2]));
 sky130_fd_sc_hd__sdfrtp_2 _236_ (.CLK(clk),
    .D(_012_),
    .RESET_B(reset_n),
    .SCD(enable),
    .SCE(scan_en),
    .Q(counter_value[3]));
 sky130_fd_sc_hd__sdfrtp_2 _237_ (.CLK(clk),
    .D(_013_),
    .RESET_B(reset_n),
    .SCD(counter_value[0]),
    .SCE(scan_en),
    .Q(counter_value[4]));
 sky130_fd_sc_hd__sdfrtp_2 _238_ (.CLK(clk),
    .D(_014_),
    .RESET_B(reset_n),
    .SCD(counter_value[1]),
    .SCE(scan_en),
    .Q(counter_value[5]));
 sky130_fd_sc_hd__sdfrtp_2 _239_ (.CLK(clk),
    .D(_015_),
    .RESET_B(reset_n),
    .SCD(counter_value[2]),
    .SCE(scan_en),
    .Q(counter_value[6]));
 sky130_fd_sc_hd__sdfrtp_2 _240_ (.CLK(clk),
    .D(_016_),
    .RESET_B(reset_n),
    .SCD(counter_value[3]),
    .SCE(scan_en),
    .Q(counter_value[7]));
 sky130_fd_sc_hd__sdfrtp_2 _241_ (.CLK(clk),
    .D(_017_),
    .RESET_B(reset_n),
    .SCD(counter_value[4]),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _242_ (.CLK(clk),
    .D(_018_),
    .RESET_B(reset_n),
    .SCD(counter_value[5]),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _243_ (.CLK(clk),
    .D(_019_),
    .RESET_B(reset_n),
    .SCD(counter_value[6]),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _244_ (.CLK(clk),
    .D(_020_),
    .RESET_B(reset_n),
    .SCD(counter_value[7]),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _245_ (.CLK(clk),
    .D(_021_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[0] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _246_ (.CLK(clk),
    .D(_022_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[1] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _247_ (.CLK(clk),
    .D(_023_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[2] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _248_ (.CLK(clk),
    .D(_024_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[3] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[7] ));
 assign scan_out[2] = \duty_cycle_reg[4] ;
 assign scan_out[3] = \duty_cycle_reg[5] ;
 assign scan_out[0] = \duty_cycle_reg[6] ;
 assign scan_out[1] = \duty_cycle_reg[7] ;
endmodule
