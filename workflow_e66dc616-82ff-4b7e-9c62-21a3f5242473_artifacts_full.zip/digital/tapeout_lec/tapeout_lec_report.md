# Tapeout Logic Equivalence Check

- Status: `incomplete_stdcell_models`
- Comparison: `RTL vs final tapeout implementation netlist`
- Top module: `pwm_controller_mmio`
- RTL files: `1`
- Tapeout netlist: `pwm_controller_mmio.pnl.v`
- Standard-cell models loaded: `1`
- Missing standard-cell models: `1`
- Unproven points: `0`
- Return code: `None`
- Failure reason: `standard_cell_verilog_models_incomplete`

This is distinct from synthesis LEC. Synthesis LEC compares RTL against `digital/synth/netlist/*_synth.v`; tapeout LEC compares RTL against the final implementation netlist collected after physical implementation.
