#!/usr/bin/env bash
set -euo pipefail

echo "== ChipLoop: Digital CTS Agent =="
echo "PDK_VARIANT=sky130A"
echo "OPENLANE_IMAGE=ghcr.io/efabless/openlane2:2.4.0.dev1"
echo "WORKDIR=/work"

export OPENLANE_NUM_CORES=2

docker run --rm   -v "/root/chiploop-backend/backend/pdk":/pdk   -v "/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/e66dc616-82ff-4b7e-9c62-21a3f5242473/60f8ef54-49ad-47d2-8e3c-af30a9ee96a2/digital/arch2tapeout/digital/run_work":/work   -e PDK=sky130A   -e PDK_ROOT=/pdk   ghcr.io/efabless/openlane2:2.4.0.dev1   bash -lc 'set -e; cd /work && openlane --flow Classic --run-tag digital_e66dc616-82ff-4b7e-9c62-21a3f5242473 --override-config RUN_LINTER=False --to OpenROAD.CTS cts/config.json'

