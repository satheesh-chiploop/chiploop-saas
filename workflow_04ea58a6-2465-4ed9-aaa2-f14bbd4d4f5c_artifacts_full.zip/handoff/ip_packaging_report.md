# IP Packaging & Handoff Report

- Top: `motor_control_top`
- Package: `backend/workflows/04ea58a6-2465-4ed9-aaa2-f14bbd4d4f5c/handoff/motor_control_top_ip_package`
- Zip: `backend/workflows/04ea58a6-2465-4ed9-aaa2-f14bbd4d4f5c/handoff/motor_control_top_ip_package.zip`

## Bucket counts
- **rtl**: 7
- **spec**: 3
- **arch**: 1
- **microarch**: 1
- **regmap**: 2
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 6
