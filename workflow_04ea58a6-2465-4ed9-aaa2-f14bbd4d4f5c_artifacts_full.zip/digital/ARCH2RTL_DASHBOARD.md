# Arch2RTL Evidence Dashboard

- Lint: errors
- Flip-flops: 359
- Latches: 0
- Full-cycle paths: 3
- Half-cycle paths: 4
- Input bits: 402
- Output bits: 487
- Input ports: 43
- Output ports: 46
- Clock: clk
- Reset: rst_n
- Modules: 5
- RTL files: 5
