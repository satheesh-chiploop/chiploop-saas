module motor_control_register_map (
    clk,
    reset_n,
    reg_cs,
    reg_we,
    reg_addr,
    reg_wdata,
    reg_rdata,
    reg_ready,
    cfg_enable,
    cfg_start,
    cfg_timeout_limit,
    cfg_seq_base,
    cfg_clamp_min,
    cfg_clamp_max,
    cfg_fallback_cmd,
    cfg_safety_override,
    cfg_fault_clear,
    status_last_seq,
    status_busy,
    status_timeout,
    status_stale_reject,
    status_rsp_valid,
    status_fallback_active,
    status_fault
);

input clk;
input reset_n;
input reg_cs;
input reg_we;
input [7:0] reg_addr;
input [63:0] reg_wdata;
output reg [63:0] reg_rdata;
output reg reg_ready;

output reg cfg_enable;
output reg cfg_start;
output reg [15:0] cfg_timeout_limit;
output reg [15:0] cfg_seq_base;
output reg [31:0] cfg_clamp_min;
output reg [31:0] cfg_clamp_max;
output reg [31:0] cfg_fallback_cmd;
output reg cfg_safety_override;
output reg cfg_fault_clear;

input [15:0] status_last_seq;
input status_busy;
input status_timeout;
input status_stale_reject;
input status_rsp_valid;
input status_fallback_active;
input status_fault;

reg [15:0] timeout_limit_reg;
reg [15:0] seq_base_reg;
reg [31:0] clamp_min_reg;
reg [31:0] clamp_max_reg;
reg [31:0] fallback_cmd_reg;
reg enable_reg;
reg safety_override_reg;
reg fault_clear_reg;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        enable_reg <= 1'b0;
        fault_clear_reg <= 1'b0;
    end else begin
        fault_clear_reg <= 1'b0;
        if (reg_cs && reg_we) begin
            case (reg_addr)
                8'h00: begin
                    enable_reg <= reg_wdata[0];
                    fault_clear_reg <= reg_wdata[2];
                    safety_override_reg <= reg_wdata[3];
                end
                8'h01: timeout_limit_reg[7:0] <= reg_wdata[7:0];
                8'h02: begin
                    timeout_limit_reg[15:8] <= reg_wdata[7:0];
                    seq_base_reg[7:0] <= reg_wdata[15:8];
                end
                8'h03: seq_base_reg[15:8] <= reg_wdata[7:0];
                8'h04: clamp_min_reg[7:0] <= reg_wdata[7:0];
                8'h05: clamp_min_reg[15:8] <= reg_wdata[7:0];
                8'h06: clamp_min_reg[23:16] <= reg_wdata[7:0];
                8'h07: clamp_min_reg[31:24] <= reg_wdata[7:0];
                8'h08: clamp_max_reg[7:0] <= reg_wdata[7:0];
                8'h09: clamp_max_reg[15:8] <= reg_wdata[7:0];
                8'h0A: clamp_max_reg[23:16] <= reg_wdata[7:0];
                8'h0B: clamp_max_reg[31:24] <= reg_wdata[7:0];
                8'h0C: fallback_cmd_reg[7:0] <= reg_wdata[7:0];
                8'h0D: fallback_cmd_reg[15:8] <= reg_wdata[7:0];
                8'h0E: fallback_cmd_reg[23:16] <= reg_wdata[7:0];
                8'h0F: fallback_cmd_reg[31:24] <= reg_wdata[7:0];
                default: begin
                end
            endcase
        end
    end
end

always @(*) begin
    cfg_enable = enable_reg;
    cfg_start = 1'b0;
    cfg_timeout_limit = timeout_limit_reg;
    cfg_seq_base = seq_base_reg;
    cfg_clamp_min = clamp_min_reg;
    cfg_clamp_max = clamp_max_reg;
    cfg_fallback_cmd = fallback_cmd_reg;
    cfg_safety_override = safety_override_reg;
    cfg_fault_clear = fault_clear_reg;

    reg_rdata = 64'h0000000000000000;
    reg_ready = 1'b0;

    if (reg_cs) begin
        reg_ready = 1'b1;
        if (reg_we) begin
            case (reg_addr)
                8'h00: reg_rdata = {60'h000000000000000, safety_override_reg, 1'b0, 1'b0, enable_reg};
                8'h01: reg_rdata = {56'h00000000000000, timeout_limit_reg[7:0]};
                8'h02: reg_rdata = {48'h000000000000, seq_base_reg[7:0], timeout_limit_reg[15:8]};
                8'h03: reg_rdata = {56'h00000000000000, seq_base_reg[15:8]};
                8'h04: reg_rdata = {56'h00000000000000, clamp_min_reg[7:0]};
                8'h05: reg_rdata = {56'h00000000000000, clamp_min_reg[15:8]};
                8'h06: reg_rdata = {56'h00000000000000, clamp_min_reg[23:16]};
                8'h07: reg_rdata = {56'h00000000000000, clamp_min_reg[31:24]};
                8'h08: reg_rdata = {56'h00000000000000, clamp_max_reg[7:0]};
                8'h09: reg_rdata = {56'h00000000000000, clamp_max_reg[15:8]};
                8'h0A: reg_rdata = {56'h00000000000000, clamp_max_reg[23:16]};
                8'h0B: reg_rdata = {56'h00000000000000, clamp_max_reg[31:24]};
                8'h0C: reg_rdata = {56'h00000000000000, fallback_cmd_reg[7:0]};
                8'h0D: reg_rdata = {56'h00000000000000, fallback_cmd_reg[15:8]};
                8'h0E: reg_rdata = {56'h00000000000000, fallback_cmd_reg[23:16]};
                8'h0F: reg_rdata = {56'h00000000000000, fallback_cmd_reg[31:24]};
                8'h10: reg_rdata = {56'h00000000000000, status_last_seq[7:0]};
                8'h11: reg_rdata = {56'h00000000000000, status_last_seq[15:8]};
                8'h12: reg_rdata = {56'h00000000000000, 2'b00, status_fault, status_fallback_active, status_rsp_valid, status_stale_reject, status_timeout, status_busy};
                8'h13: reg_rdata = 64'h0000000000000000;
                default: reg_rdata = 64'h0000000000000000;
            endcase
        end else begin
            case (reg_addr)
                8'h00: reg_rdata = {60'h000000000000000, safety_override_reg, 1'b0, 1'b0, enable_reg};
                8'h01: reg_rdata = {56'h00000000000000, timeout_limit_reg[7:0]};
                8'h02: reg_rdata = {48'h000000000000, seq_base_reg[7:0], timeout_limit_reg[15:8]};
                8'h03: reg_rdata = {56'h00000000000000, seq_base_reg[15:8]};
                8'h04: reg_rdata = {56'h00000000000000, clamp_min_reg[7:0]};
                8'h05: reg_rdata = {56'h00000000000000, clamp_min_reg[15:8]};
                8'h06: reg_rdata = {56'h00000000000000, clamp_min_reg[23:16]};
                8'h07: reg_rdata = {56'h00000000000000, clamp_min_reg[31:24]};
                8'h08: reg_rdata = {56'h00000000000000, clamp_max_reg[7:0]};
                8'h09: reg_rdata = {56'h00000000000000, clamp_max_reg[15:8]};
                8'h0A: reg_rdata = {56'h00000000000000, clamp_max_reg[23:16]};
                8'h0B: reg_rdata = {56'h00000000000000, clamp_max_reg[31:24]};
                8'h0C: reg_rdata = {56'h00000000000000, fallback_cmd_reg[7:0]};
                8'h0D: reg_rdata = {56'h00000000000000, fallback_cmd_reg[15:8]};
                8'h0E: reg_rdata = {56'h00000000000000, fallback_cmd_reg[23:16]};
                8'h0F: reg_rdata = {56'h00000000000000, fallback_cmd_reg[31:24]};
                8'h10: reg_rdata = {56'h00000000000000, status_last_seq[7:0]};
                8'h11: reg_rdata = {56'h00000000000000, status_last_seq[15:8]};
                8'h12: reg_rdata = {56'h00000000000000, 2'b00, status_fault, status_fallback_active, status_rsp_valid, status_stale_reject, status_timeout, status_busy};
                8'h13: reg_rdata = 64'h0000000000000000;
                default: reg_rdata = 64'h0000000000000000;
            endcase
        end
    end
end

endmodule
