module motor_control_top (
    clk,
    reset_n,
    reg_cs,
    reg_we,
    reg_addr,
    reg_wdata,
    reg_rdata,
    reg_ready,
    req_valid,
    req_ready,
    req_data,
    rsp_valid,
    rsp_ready,
    rsp_data,
    act_cmd_valid,
    act_cmd_fault,
    act_cmd,
    motor_control_register_map_cfg_enable,
    motor_control_register_map_cfg_start,
    motor_control_register_map_cfg_timeout_limit,
    motor_control_register_map_cfg_seq_base,
    motor_control_register_map_cfg_clamp_min,
    motor_control_register_map_cfg_clamp_max,
    motor_control_register_map_cfg_fallback_cmd,
    motor_control_register_map_cfg_safety_override,
    motor_control_register_map_cfg_fault_clear,
    motor_control_register_map_status_last_seq,
    motor_control_register_map_status_busy,
    motor_control_register_map_status_timeout,
    motor_control_register_map_status_stale_reject,
    motor_control_register_map_status_rsp_valid,
    motor_control_register_map_status_fallback_active,
    motor_control_register_map_status_fault,
    motor_control_transport_fsm_cfg_enable,
    motor_control_transport_fsm_cfg_start,
    motor_control_transport_fsm_cfg_timeout_limit,
    motor_control_transport_fsm_cfg_seq_base,
    motor_control_transport_fsm_cfg_safety_override,
    motor_control_transport_fsm_cfg_fault_clear,
    motor_control_transport_fsm_cfg_clamp_min,
    motor_control_transport_fsm_cfg_clamp_max,
    motor_control_transport_fsm_cfg_fallback_cmd,
    motor_control_transport_fsm_status_last_seq,
    motor_control_transport_fsm_status_busy,
    motor_control_transport_fsm_status_timeout,
    motor_control_transport_fsm_status_stale_reject,
    motor_control_transport_fsm_status_rsp_valid,
    motor_control_transport_fsm_status_fallback_active,
    motor_control_transport_fsm_status_fault
);

input clk;
input reset_n;
input reg_cs;
input reg_we;
input [7:0] reg_addr;
input [63:0] reg_wdata;
output [63:0] reg_rdata;
output reg_ready;
output req_valid;
input req_ready;
output [63:0] req_data;
input rsp_valid;
output rsp_ready;
input [63:0] rsp_data;
output act_cmd_valid;
output act_cmd_fault;
output [31:0] act_cmd;
input motor_control_register_map_cfg_enable;
input motor_control_register_map_cfg_start;
input [15:0] motor_control_register_map_cfg_timeout_limit;
input [15:0] motor_control_register_map_cfg_seq_base;
input [31:0] motor_control_register_map_cfg_clamp_min;
input [31:0] motor_control_register_map_cfg_clamp_max;
input [31:0] motor_control_register_map_cfg_fallback_cmd;
input motor_control_register_map_cfg_safety_override;
input motor_control_register_map_cfg_fault_clear;
output [15:0] motor_control_register_map_status_last_seq;
output motor_control_register_map_status_busy;
output motor_control_register_map_status_timeout;
output motor_control_register_map_status_stale_reject;
output motor_control_register_map_status_rsp_valid;
output motor_control_register_map_status_fallback_active;
output motor_control_register_map_status_fault;
output motor_control_transport_fsm_cfg_enable;
output motor_control_transport_fsm_cfg_start;
output [15:0] motor_control_transport_fsm_cfg_timeout_limit;
output [15:0] motor_control_transport_fsm_cfg_seq_base;
output motor_control_transport_fsm_cfg_safety_override;
output motor_control_transport_fsm_cfg_fault_clear;
output [31:0] motor_control_transport_fsm_cfg_clamp_min;
output [31:0] motor_control_transport_fsm_cfg_clamp_max;
output [31:0] motor_control_transport_fsm_cfg_fallback_cmd;
input [15:0] motor_control_transport_fsm_status_last_seq;
input motor_control_transport_fsm_status_busy;
input motor_control_transport_fsm_status_timeout;
input motor_control_transport_fsm_status_stale_reject;
input motor_control_transport_fsm_status_rsp_valid;
input motor_control_transport_fsm_status_fallback_active;
input motor_control_transport_fsm_status_fault;

wire [63:0] reg_rdata_w;
wire reg_ready_w;
wire req_valid_w;
wire [63:0] req_data_w;
wire rsp_ready_w;
wire act_cmd_valid_w;
wire act_cmd_fault_w;
wire [31:0] act_cmd_w;
wire [15:0] motor_control_register_map_status_last_seq;
wire motor_control_register_map_status_busy;
wire motor_control_register_map_status_timeout;
wire motor_control_register_map_status_stale_reject;
wire motor_control_register_map_status_rsp_valid;
wire motor_control_register_map_status_fallback_active;
wire motor_control_register_map_status_fault;

wire motor_control_transport_fsm_cfg_enable;
wire motor_control_transport_fsm_cfg_start;
wire [15:0] motor_control_transport_fsm_cfg_timeout_limit;
wire [15:0] motor_control_transport_fsm_cfg_seq_base;
wire motor_control_transport_fsm_cfg_safety_override;
wire motor_control_transport_fsm_cfg_fault_clear;
wire [31:0] motor_control_transport_fsm_cfg_clamp_min;
wire [31:0] motor_control_transport_fsm_cfg_clamp_max;
wire [31:0] motor_control_transport_fsm_cfg_fallback_cmd;
wire [15:0] motor_control_transport_fsm_status_last_seq;
wire motor_control_transport_fsm_status_busy;
wire motor_control_transport_fsm_status_timeout;
wire motor_control_transport_fsm_status_stale_reject;
wire motor_control_transport_fsm_status_rsp_valid;
wire motor_control_transport_fsm_status_fallback_active;
wire motor_control_transport_fsm_status_fault;

wire [31:0] motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map;
wire [31:0] motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map;
wire motor_control_register_map_cfg_enable_from_u_motor_control_register_map;
wire [31:0] motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map;
wire motor_control_register_map_cfg_fault_clear_from_u_motor_control_register_map;
wire motor_control_register_map_cfg_safety_override_from_u_motor_control_register_map;
wire [15:0] motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map;
wire motor_control_register_map_cfg_start_from_u_motor_control_register_map;
wire [15:0] motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map;
wire motor_control_transport_fsm_status_busy_from_u_motor_control_transport_fsm;
wire motor_control_transport_fsm_status_fallback_active_from_u_motor_control_transport_fsm;
wire motor_control_transport_fsm_status_fault_from_u_motor_control_transport_fsm;
wire [15:0] motor_control_transport_fsm_status_last_seq_from_u_motor_control_transport_fsm;
wire motor_control_transport_fsm_status_rsp_valid_from_u_motor_control_transport_fsm;
wire motor_control_transport_fsm_status_stale_reject_from_u_motor_control_transport_fsm;
wire motor_control_transport_fsm_status_timeout_from_u_motor_control_transport_fsm;
assign reg_rdata = reg_rdata_w;
assign reg_ready = reg_ready_w;
assign req_valid = req_valid_w;
assign req_data = req_data_w;
assign rsp_ready = rsp_ready_w;
assign act_cmd_valid = act_cmd_valid_w;
assign act_cmd_fault = act_cmd_fault_w;
assign act_cmd = act_cmd_w;

assign motor_control_register_map_status_last_seq = motor_control_transport_fsm_status_last_seq;
assign motor_control_register_map_status_busy = motor_control_transport_fsm_status_busy;
assign motor_control_register_map_status_timeout = motor_control_transport_fsm_status_timeout;
assign motor_control_register_map_status_stale_reject = motor_control_transport_fsm_status_stale_reject;
assign motor_control_register_map_status_rsp_valid = motor_control_transport_fsm_status_rsp_valid;
assign motor_control_register_map_status_fallback_active = motor_control_transport_fsm_status_fallback_active;
assign motor_control_register_map_status_fault = motor_control_transport_fsm_status_fault;

assign motor_control_transport_fsm_cfg_enable = motor_control_register_map_cfg_enable;
assign motor_control_transport_fsm_cfg_start = motor_control_register_map_cfg_start;
assign motor_control_transport_fsm_cfg_timeout_limit = motor_control_register_map_cfg_timeout_limit;
assign motor_control_transport_fsm_cfg_seq_base = motor_control_register_map_cfg_seq_base;
assign motor_control_transport_fsm_cfg_safety_override = motor_control_register_map_cfg_safety_override;
assign motor_control_transport_fsm_cfg_fault_clear = motor_control_register_map_cfg_fault_clear;
assign motor_control_transport_fsm_cfg_clamp_min = motor_control_register_map_cfg_clamp_min;
assign motor_control_transport_fsm_cfg_clamp_max = motor_control_register_map_cfg_clamp_max;
assign motor_control_transport_fsm_cfg_fallback_cmd = motor_control_register_map_cfg_fallback_cmd;

motor_control_register_map u_motor_control_register_map (
    .clk(clk),
    .reset_n(reset_n),
    .reg_cs(reg_cs),
    .reg_we(reg_we),
    .reg_addr(reg_addr),
    .reg_wdata(reg_wdata),
    .reg_rdata(reg_rdata_w),
    .reg_ready(reg_ready_w),
    .cfg_enable(motor_control_register_map_cfg_enable_from_u_motor_control_register_map),
    .cfg_start(motor_control_register_map_cfg_start_from_u_motor_control_register_map),
    .cfg_timeout_limit(motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map),
    .cfg_seq_base(motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map),
    .cfg_clamp_min(motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map),
    .cfg_clamp_max(motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map),
    .cfg_fallback_cmd(motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map),
    .cfg_safety_override(motor_control_register_map_cfg_safety_override_from_u_motor_control_register_map),
    .cfg_fault_clear(motor_control_register_map_cfg_fault_clear_from_u_motor_control_register_map),
    .status_last_seq(motor_control_register_map_status_last_seq),
    .status_busy(motor_control_register_map_status_busy),
    .status_timeout(motor_control_register_map_status_timeout),
    .status_stale_reject(motor_control_register_map_status_stale_reject),
    .status_rsp_valid(motor_control_register_map_status_rsp_valid),
    .status_fallback_active(motor_control_register_map_status_fallback_active),
    .status_fault(motor_control_register_map_status_fault)
);

motor_control_transport_fsm u_motor_control_transport_fsm (
    .clk(clk),
    .reset_n(reset_n),
    .cfg_enable(motor_control_transport_fsm_cfg_enable),
    .cfg_start(motor_control_transport_fsm_cfg_start),
    .cfg_timeout_limit(motor_control_transport_fsm_cfg_timeout_limit),
    .cfg_seq_base(motor_control_transport_fsm_cfg_seq_base),
    .cfg_safety_override(motor_control_transport_fsm_cfg_safety_override),
    .cfg_fault_clear(motor_control_transport_fsm_cfg_fault_clear),
    .cfg_clamp_min(motor_control_transport_fsm_cfg_clamp_min),
    .cfg_clamp_max(motor_control_transport_fsm_cfg_clamp_max),
    .cfg_fallback_cmd(motor_control_transport_fsm_cfg_fallback_cmd),
    .req_ready(req_ready),
    .rsp_valid(rsp_valid),
    .rsp_data(rsp_data),
    .req_valid(req_valid_w),
    .req_data(req_data_w),
    .rsp_ready(rsp_ready_w),
    .act_cmd_valid(act_cmd_valid_w),
    .act_cmd_fault(act_cmd_fault_w),
    .act_cmd(act_cmd_w),
    .status_last_seq(motor_control_transport_fsm_status_last_seq_from_u_motor_control_transport_fsm),
    .status_busy(motor_control_transport_fsm_status_busy_from_u_motor_control_transport_fsm),
    .status_timeout(motor_control_transport_fsm_status_timeout_from_u_motor_control_transport_fsm),
    .status_stale_reject(motor_control_transport_fsm_status_stale_reject_from_u_motor_control_transport_fsm),
    .status_rsp_valid(motor_control_transport_fsm_status_rsp_valid_from_u_motor_control_transport_fsm),
    .status_fallback_active(motor_control_transport_fsm_status_fallback_active_from_u_motor_control_transport_fsm),
    .status_fault(motor_control_transport_fsm_status_fault_from_u_motor_control_transport_fsm)
);

endmodule
