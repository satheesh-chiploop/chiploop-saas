module motor_control_transport_fsm (
    clk,
    reset_n,
    cfg_enable,
    cfg_start,
    cfg_timeout_limit,
    cfg_seq_base,
    cfg_safety_override,
    cfg_fault_clear,
    cfg_clamp_min,
    cfg_clamp_max,
    cfg_fallback_cmd,
    req_ready,
    rsp_valid,
    rsp_data,
    req_valid,
    req_data,
    rsp_ready,
    act_cmd_valid,
    act_cmd_fault,
    act_cmd,
    status_last_seq,
    status_busy,
    status_timeout,
    status_stale_reject,
    status_rsp_valid,
    status_fallback_active,
    status_fault
);

input clk;
input reset_n;
input cfg_enable;
input cfg_start;
input [15:0] cfg_timeout_limit;
input [15:0] cfg_seq_base;
input cfg_safety_override;
input cfg_fault_clear;
input [31:0] cfg_clamp_min;
input [31:0] cfg_clamp_max;
input [31:0] cfg_fallback_cmd;
input req_ready;
input rsp_valid;
input [63:0] rsp_data;
output reg req_valid;
output reg [63:0] req_data;
output reg rsp_ready;
output reg act_cmd_valid;
output reg act_cmd_fault;
output reg [31:0] act_cmd;
output reg [15:0] status_last_seq;
output reg status_busy;
output reg status_timeout;
output reg status_stale_reject;
output reg status_rsp_valid;
output reg status_fallback_active;
output reg status_fault;

reg [2:0] state, next_state;
reg [15:0] seq_reg;
reg [15:0] timeout_cnt;
reg [31:0] latched_cmd;
reg [63:0] req_data_next;
reg req_valid_next;
reg rsp_ready_next;
reg act_cmd_valid_next;
reg act_cmd_fault_next;
reg [31:0] act_cmd_next;
reg [15:0] status_last_seq_next;
reg status_busy_next;
reg status_timeout_next;
reg status_stale_reject_next;
reg status_rsp_valid_next;
reg status_fallback_active_next;
reg status_fault_next;

localparam S_RESET = 3'd0;
localparam S_IDLE = 3'd1;
localparam S_REQUEST_PENDING = 3'd2;
localparam S_WAIT_RESPONSE = 3'd3;
localparam S_APPLY_RESPONSE = 3'd4;
localparam S_FALLBACK = 3'd5;
localparam S_FAULT_HOLD = 3'd6;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        state <= S_RESET;
        seq_reg <= 16'h0000;
        timeout_cnt <= 16'h0000;
        latched_cmd <= 32'h00000000;
        req_valid <= 1'b0;
        req_data <= 64'h0000000000000000;
        rsp_ready <= 1'b0;
        act_cmd_valid <= 1'b0;
        act_cmd_fault <= 1'b0;
        act_cmd <= 32'h00000000;
        status_last_seq <= 16'h0000;
        status_busy <= 1'b0;
        status_timeout <= 1'b0;
        status_stale_reject <= 1'b0;
        status_rsp_valid <= 1'b0;
        status_fallback_active <= 1'b1;
        status_fault <= 1'b0;
    end else begin
        state <= next_state;
        req_valid <= req_valid_next;
        req_data <= req_data_next;
        rsp_ready <= rsp_ready_next;
        act_cmd_valid <= act_cmd_valid_next;
        act_cmd_fault <= act_cmd_fault_next;
        act_cmd <= act_cmd_next;
        status_last_seq <= status_last_seq_next;
        status_busy <= status_busy_next;
        status_timeout <= status_timeout_next;
        status_stale_reject <= status_stale_reject_next;
        status_rsp_valid <= status_rsp_valid_next;
        status_fallback_active <= status_fallback_active_next;
        status_fault <= status_fault_next;

        if (state == S_IDLE) begin
            timeout_cnt <= 16'h0000;
        end else if (state == S_REQUEST_PENDING) begin
            if (req_ready) timeout_cnt <= 16'h0000;
        end else if (state == S_WAIT_RESPONSE) begin
            if (timeout_cnt != cfg_timeout_limit) timeout_cnt <= timeout_cnt + 16'h0001;
        end

        if (state == S_IDLE && cfg_enable && cfg_start) begin
            seq_reg <= cfg_seq_base;
        end else if (state == S_REQUEST_PENDING && req_ready) begin
            seq_reg <= seq_reg + 16'h0001;
        end else if (state == S_FAULT_HOLD && cfg_fault_clear && cfg_safety_override) begin
            seq_reg <= cfg_seq_base;
        end
    end
end

always @(*) begin
    next_state = state;
    req_valid_next = 1'b0;
    req_data_next = 64'h0000000000000000;
    rsp_ready_next = 1'b0;
    act_cmd_valid_next = 1'b0;
    act_cmd_fault_next = 1'b0;
    act_cmd_next = cfg_fallback_cmd;
    status_last_seq_next = status_last_seq;
    status_busy_next = 1'b0;
    status_timeout_next = 1'b0;
    status_stale_reject_next = 1'b0;
    status_rsp_valid_next = 1'b0;
    status_fallback_active_next = 1'b1;
    status_fault_next = status_fault;

    case (state)
        S_RESET: begin
            next_state = S_IDLE;
            status_fallback_active_next = 1'b1;
        end
        S_IDLE: begin
            status_busy_next = 1'b0;
            status_fallback_active_next = 1'b1;
            if (!cfg_enable) begin
                next_state = S_FALLBACK;
            end else if (cfg_start) begin
                next_state = S_REQUEST_PENDING;
                req_valid_next = 1'b1;
                req_data_next = {16'hA55A, cfg_enable, cfg_safety_override, cfg_seq_base, cfg_timeout_limit, cfg_clamp_min[7:0], cfg_clamp_max[7:0], 14'h0000};
                status_fallback_active_next = 1'b1;
            end
            if (cfg_fault_clear && status_fault && cfg_safety_override) begin
                next_state = S_IDLE;
                status_fault_next = 1'b0;
            end
        end
        S_REQUEST_PENDING: begin
            status_busy_next = 1'b1;
            req_valid_next = 1'b1;
            req_data_next = {16'hA55A, cfg_enable, cfg_safety_override, seq_reg, cfg_timeout_limit, cfg_clamp_min[7:0], cfg_clamp_max[7:0], 14'h0000};
            if (!cfg_enable) begin
                next_state = S_FALLBACK;
            end else if (req_ready) begin
                next_state = S_WAIT_RESPONSE;
                status_last_seq_next = seq_reg;
            end
        end
        S_WAIT_RESPONSE: begin
            status_busy_next = 1'b1;
            rsp_ready_next = 1'b1;
            req_data_next = {16'hA55A, cfg_enable, cfg_safety_override, seq_reg, cfg_timeout_limit, cfg_clamp_min[7:0], cfg_clamp_max[7:0], 14'h0000};
            if (!cfg_enable) begin
                next_state = S_FALLBACK;
            end else if (rsp_valid) begin
                if (rsp_data[63:48] == seq_reg) begin
                    next_state = S_APPLY_RESPONSE;
                    status_rsp_valid_next = 1'b1;
                    act_cmd_next = rsp_data[31:0];
                end else begin
                    next_state = S_FALLBACK;
                    status_stale_reject_next = 1'b1;
                end
            end else if ((cfg_timeout_limit != 16'h0000) && (timeout_cnt >= cfg_timeout_limit)) begin
                next_state = S_FALLBACK;
                status_timeout_next = 1'b1;
            end
        end
        S_APPLY_RESPONSE: begin
            status_busy_next = 1'b0;
            status_rsp_valid_next = 1'b1;
            act_cmd_valid_next = 1'b1;
            act_cmd_next = rsp_data[31:0];
            if (rsp_data[31:0] < cfg_clamp_min) act_cmd_next = cfg_clamp_min;
            if (rsp_data[31:0] > cfg_clamp_max) act_cmd_next = cfg_clamp_max;
            next_state = S_IDLE;
            status_fallback_active_next = 1'b0;
            status_last_seq_next = seq_reg;
        end
        S_FALLBACK: begin
            status_busy_next = 1'b0;
            status_fallback_active_next = 1'b1;
            act_cmd_next = cfg_fallback_cmd;
            act_cmd_valid_next = 1'b1;
            act_cmd_fault_next = status_fault | (!cfg_enable);
            if (cfg_fault_clear && cfg_safety_override && !cfg_enable) begin
                next_state = S_IDLE;
                status_fault_next = 1'b0;
            end else if (cfg_fault_clear && cfg_safety_override && !status_fault) begin
                next_state = S_IDLE;
            end else if (cfg_fault_clear && cfg_safety_override) begin
                next_state = S_IDLE;
                status_fault_next = 1'b0;
            end else begin
                next_state = S_FAULT_HOLD;
                if (!cfg_safety_override) status_fault_next = 1'b1;
            end
        end
        S_FAULT_HOLD: begin
            status_busy_next = 1'b0;
            status_fault_next = 1'b1;
            status_fallback_active_next = 1'b1;
            act_cmd_next = cfg_fallback_cmd;
            act_cmd_valid_next = 1'b1;
            act_cmd_fault_next = 1'b1;
            if (cfg_fault_clear && cfg_safety_override) begin
                next_state = S_IDLE;
                status_fault_next = 1'b0;
            end
        end
        default: begin
            next_state = S_IDLE;
        end
    endcase

    if (state == S_WAIT_RESPONSE && rsp_valid && (rsp_data[63:48] != seq_reg)) begin
        status_stale_reject_next = 1'b1;
    end

    if (status_timeout_next || status_stale_reject_next) begin
        status_fault_next = status_fault_next | (~cfg_safety_override);
    end

    if (!cfg_enable) begin
        act_cmd_next = cfg_fallback_cmd;
        status_fallback_active_next = 1'b1;
        status_busy_next = 1'b0;
    end

    if (status_fault_next && !cfg_safety_override) begin
        act_cmd_fault_next = 1'b1;
    end
end

endmodule
