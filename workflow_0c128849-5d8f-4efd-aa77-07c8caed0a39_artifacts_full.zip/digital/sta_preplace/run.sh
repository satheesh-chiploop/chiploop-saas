#!/usr/bin/env bash
set -euo pipefail

echo "== ChipLoop: Digital STA PrePlace Agent =="
echo "PDK_VARIANT=sky130A"
echo "OPENLANE_IMAGE=ghcr.io/efabless/openlane2:2.4.0.dev1"
echo "WORKDIR=/work"

export OPENLANE_NUM_CORES=2

docker run --rm \
  -v "/root/chiploop-backend/backend/pdk":/pdk \
  -v "/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0c128849-5d8f-4efd-aa77-07c8caed0a39/17b59b6a-6fa3-4e57-8df9-0060f089b900/digital/arch2tapeout/digital/run_work":/work \
  -e PDK=sky130A \
  -e PDK_ROOT=/pdk \
  ghcr.io/efabless/openlane2:2.4.0.dev1 \
  bash -lc 'set -e; cd /work && openlane --flow Classic --run-tag Digital_Arch2Tapeout_0c128849-5d8f-4efd-aa77-07c8caed0a39 --override-config RUN_LINTER=False --to OpenROAD.STAPrePNR sta_preplace/config.json'
