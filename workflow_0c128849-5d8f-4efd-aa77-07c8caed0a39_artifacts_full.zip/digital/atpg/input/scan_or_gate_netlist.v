module motor_control_top (act_cmd_fault,
    act_cmd_valid,
    clk,
    motor_control_register_map_cfg_enable,
    motor_control_register_map_cfg_fault_clear,
    motor_control_register_map_cfg_safety_override,
    motor_control_register_map_cfg_start,
    motor_control_register_map_status_busy,
    motor_control_register_map_status_fallback_active,
    motor_control_register_map_status_fault,
    motor_control_register_map_status_rsp_valid,
    motor_control_register_map_status_stale_reject,
    motor_control_register_map_status_timeout,
    motor_control_transport_fsm_cfg_enable,
    motor_control_transport_fsm_cfg_fault_clear,
    motor_control_transport_fsm_cfg_safety_override,
    motor_control_transport_fsm_cfg_start,
    motor_control_transport_fsm_status_busy,
    motor_control_transport_fsm_status_fallback_active,
    motor_control_transport_fsm_status_fault,
    motor_control_transport_fsm_status_rsp_valid,
    motor_control_transport_fsm_status_stale_reject,
    motor_control_transport_fsm_status_timeout,
    reg_cs,
    reg_ready,
    reg_we,
    req_ready,
    req_valid,
    reset_n,
    rsp_ready,
    rsp_valid,
    scan_en,
    act_cmd,
    motor_control_register_map_cfg_clamp_max,
    motor_control_register_map_cfg_clamp_min,
    motor_control_register_map_cfg_fallback_cmd,
    motor_control_register_map_cfg_seq_base,
    motor_control_register_map_cfg_timeout_limit,
    motor_control_register_map_status_last_seq,
    motor_control_transport_fsm_cfg_clamp_max,
    motor_control_transport_fsm_cfg_clamp_min,
    motor_control_transport_fsm_cfg_fallback_cmd,
    motor_control_transport_fsm_cfg_seq_base,
    motor_control_transport_fsm_cfg_timeout_limit,
    motor_control_transport_fsm_status_last_seq,
    reg_addr,
    reg_rdata,
    reg_wdata,
    req_data,
    rsp_data,
    scan_in,
    scan_out);
 output act_cmd_fault;
 output act_cmd_valid;
 input clk;
 input motor_control_register_map_cfg_enable;
 input motor_control_register_map_cfg_fault_clear;
 input motor_control_register_map_cfg_safety_override;
 input motor_control_register_map_cfg_start;
 output motor_control_register_map_status_busy;
 output motor_control_register_map_status_fallback_active;
 output motor_control_register_map_status_fault;
 output motor_control_register_map_status_rsp_valid;
 output motor_control_register_map_status_stale_reject;
 output motor_control_register_map_status_timeout;
 output motor_control_transport_fsm_cfg_enable;
 output motor_control_transport_fsm_cfg_fault_clear;
 output motor_control_transport_fsm_cfg_safety_override;
 output motor_control_transport_fsm_cfg_start;
 input motor_control_transport_fsm_status_busy;
 input motor_control_transport_fsm_status_fallback_active;
 input motor_control_transport_fsm_status_fault;
 input motor_control_transport_fsm_status_rsp_valid;
 input motor_control_transport_fsm_status_stale_reject;
 input motor_control_transport_fsm_status_timeout;
 input reg_cs;
 output reg_ready;
 input reg_we;
 input req_ready;
 output req_valid;
 input reset_n;
 output rsp_ready;
 input rsp_valid;
 input scan_en;
 output [31:0] act_cmd;
 input [31:0] motor_control_register_map_cfg_clamp_max;
 input [31:0] motor_control_register_map_cfg_clamp_min;
 input [31:0] motor_control_register_map_cfg_fallback_cmd;
 input [15:0] motor_control_register_map_cfg_seq_base;
 input [15:0] motor_control_register_map_cfg_timeout_limit;
 output [15:0] motor_control_register_map_status_last_seq;
 output [31:0] motor_control_transport_fsm_cfg_clamp_max;
 output [31:0] motor_control_transport_fsm_cfg_clamp_min;
 output [31:0] motor_control_transport_fsm_cfg_fallback_cmd;
 output [15:0] motor_control_transport_fsm_cfg_seq_base;
 output [15:0] motor_control_transport_fsm_cfg_timeout_limit;
 input [15:0] motor_control_transport_fsm_status_last_seq;
 input [7:0] reg_addr;
 output [63:0] reg_rdata;
 input [63:0] reg_wdata;
 output [63:0] req_data;
 input [63:0] rsp_data;
 input [3:0] scan_in;
 output [3:0] scan_out;

 wire _0000_;
 wire _0001_;
 wire _0002_;
 wire _0003_;
 wire _0004_;
 wire _0005_;
 wire _0006_;
 wire _0007_;
 wire _0008_;
 wire _0009_;
 wire _0010_;
 wire _0011_;
 wire _0012_;
 wire _0013_;
 wire _0014_;
 wire _0015_;
 wire _0016_;
 wire _0017_;
 wire _0018_;
 wire _0019_;
 wire _0020_;
 wire _0021_;
 wire _0022_;
 wire _0023_;
 wire _0024_;
 wire _0025_;
 wire _0026_;
 wire _0027_;
 wire _0028_;
 wire _0029_;
 wire _0030_;
 wire _0031_;
 wire _0032_;
 wire _0033_;
 wire _0034_;
 wire _0035_;
 wire _0036_;
 wire _0037_;
 wire _0038_;
 wire _0039_;
 wire _0040_;
 wire _0041_;
 wire _0042_;
 wire _0043_;
 wire _0044_;
 wire _0045_;
 wire _0046_;
 wire _0047_;
 wire _0048_;
 wire _0049_;
 wire _0050_;
 wire _0051_;
 wire _0052_;
 wire _0053_;
 wire _0054_;
 wire _0055_;
 wire _0056_;
 wire _0057_;
 wire _0058_;
 wire _0059_;
 wire _0060_;
 wire _0061_;
 wire _0062_;
 wire _0063_;
 wire _0064_;
 wire _0065_;
 wire _0066_;
 wire _0067_;
 wire _0068_;
 wire _0069_;
 wire _0070_;
 wire _0071_;
 wire _0072_;
 wire _0073_;
 wire _0074_;
 wire _0075_;
 wire _0076_;
 wire _0077_;
 wire _0078_;
 wire _0079_;
 wire _0080_;
 wire _0081_;
 wire _0082_;
 wire _0083_;
 wire _0084_;
 wire _0085_;
 wire _0086_;
 wire _0087_;
 wire _0088_;
 wire _0089_;
 wire _0090_;
 wire _0091_;
 wire _0092_;
 wire _0093_;
 wire _0094_;
 wire _0095_;
 wire _0096_;
 wire _0097_;
 wire _0098_;
 wire _0099_;
 wire _0100_;
 wire _0101_;
 wire _0102_;
 wire _0103_;
 wire _0104_;
 wire _0105_;
 wire _0106_;
 wire _0107_;
 wire _0108_;
 wire _0109_;
 wire _0110_;
 wire _0111_;
 wire _0112_;
 wire _0113_;
 wire _0114_;
 wire _0115_;
 wire _0116_;
 wire _0117_;
 wire _0118_;
 wire _0119_;
 wire _0120_;
 wire _0121_;
 wire _0122_;
 wire _0123_;
 wire _0124_;
 wire _0125_;
 wire _0126_;
 wire _0127_;
 wire _0128_;
 wire _0129_;
 wire _0130_;
 wire _0131_;
 wire _0132_;
 wire _0133_;
 wire _0134_;
 wire _0135_;
 wire _0136_;
 wire _0137_;
 wire _0138_;
 wire _0139_;
 wire _0140_;
 wire _0141_;
 wire _0142_;
 wire _0143_;
 wire _0144_;
 wire _0145_;
 wire _0146_;
 wire _0147_;
 wire _0148_;
 wire _0149_;
 wire _0150_;
 wire _0151_;
 wire _0152_;
 wire _0153_;
 wire _0154_;
 wire _0155_;
 wire _0156_;
 wire _0157_;
 wire _0158_;
 wire _0159_;
 wire _0160_;
 wire _0161_;
 wire _0162_;
 wire _0163_;
 wire _0164_;
 wire _0165_;
 wire _0166_;
 wire _0167_;
 wire _0168_;
 wire _0169_;
 wire _0170_;
 wire _0171_;
 wire _0172_;
 wire _0173_;
 wire _0174_;
 wire _0175_;
 wire _0176_;
 wire _0177_;
 wire _0178_;
 wire _0179_;
 wire _0180_;
 wire _0181_;
 wire _0182_;
 wire _0183_;
 wire _0184_;
 wire _0185_;
 wire _0186_;
 wire _0187_;
 wire _0188_;
 wire _0189_;
 wire _0190_;
 wire _0191_;
 wire _0192_;
 wire _0193_;
 wire _0194_;
 wire _0195_;
 wire _0196_;
 wire _0197_;
 wire _0198_;
 wire _0199_;
 wire _0200_;
 wire _0201_;
 wire _0202_;
 wire _0203_;
 wire _0204_;
 wire _0205_;
 wire _0206_;
 wire _0207_;
 wire _0208_;
 wire _0209_;
 wire _0210_;
 wire _0211_;
 wire _0212_;
 wire _0213_;
 wire _0214_;
 wire _0215_;
 wire _0216_;
 wire _0217_;
 wire _0218_;
 wire _0219_;
 wire _0220_;
 wire _0221_;
 wire _0222_;
 wire _0223_;
 wire _0224_;
 wire _0225_;
 wire _0226_;
 wire _0227_;
 wire _0228_;
 wire _0229_;
 wire _0230_;
 wire _0231_;
 wire _0232_;
 wire _0233_;
 wire _0234_;
 wire _0235_;
 wire _0236_;
 wire _0237_;
 wire _0238_;
 wire _0239_;
 wire _0240_;
 wire _0241_;
 wire _0242_;
 wire _0243_;
 wire _0244_;
 wire _0245_;
 wire _0246_;
 wire _0247_;
 wire _0248_;
 wire _0249_;
 wire _0250_;
 wire _0251_;
 wire _0252_;
 wire _0253_;
 wire _0254_;
 wire _0255_;
 wire _0256_;
 wire _0257_;
 wire _0258_;
 wire _0259_;
 wire _0260_;
 wire _0261_;
 wire _0262_;
 wire _0263_;
 wire _0264_;
 wire _0265_;
 wire _0266_;
 wire _0267_;
 wire _0268_;
 wire _0269_;
 wire _0270_;
 wire _0271_;
 wire _0272_;
 wire _0273_;
 wire _0274_;
 wire _0275_;
 wire _0276_;
 wire _0277_;
 wire _0278_;
 wire _0279_;
 wire _0280_;
 wire _0281_;
 wire _0282_;
 wire _0283_;
 wire _0284_;
 wire _0285_;
 wire _0286_;
 wire _0287_;
 wire _0288_;
 wire _0289_;
 wire _0290_;
 wire _0291_;
 wire _0292_;
 wire _0293_;
 wire _0294_;
 wire _0295_;
 wire _0296_;
 wire _0297_;
 wire _0298_;
 wire _0299_;
 wire _0300_;
 wire _0301_;
 wire _0302_;
 wire _0303_;
 wire _0304_;
 wire _0305_;
 wire _0306_;
 wire _0307_;
 wire _0308_;
 wire _0309_;
 wire _0310_;
 wire _0311_;
 wire _0312_;
 wire _0313_;
 wire _0314_;
 wire _0315_;
 wire _0316_;
 wire _0317_;
 wire _0318_;
 wire _0319_;
 wire _0320_;
 wire _0321_;
 wire _0322_;
 wire _0323_;
 wire _0324_;
 wire _0325_;
 wire _0326_;
 wire _0327_;
 wire _0328_;
 wire _0329_;
 wire _0330_;
 wire _0331_;
 wire _0332_;
 wire _0333_;
 wire _0334_;
 wire _0335_;
 wire _0336_;
 wire _0337_;
 wire _0338_;
 wire _0339_;
 wire _0340_;
 wire _0341_;
 wire _0342_;
 wire _0343_;
 wire _0344_;
 wire _0345_;
 wire _0346_;
 wire _0347_;
 wire _0348_;
 wire _0349_;
 wire _0350_;
 wire _0351_;
 wire _0352_;
 wire _0353_;
 wire _0354_;
 wire _0355_;
 wire _0356_;
 wire _0357_;
 wire _0358_;
 wire _0359_;
 wire _0360_;
 wire _0361_;
 wire _0362_;
 wire _0363_;
 wire _0364_;
 wire _0365_;
 wire _0366_;
 wire _0367_;
 wire _0368_;
 wire _0369_;
 wire _0370_;
 wire _0371_;
 wire _0372_;
 wire _0373_;
 wire _0374_;
 wire _0375_;
 wire _0376_;
 wire _0377_;
 wire _0378_;
 wire _0379_;
 wire _0380_;
 wire _0381_;
 wire _0382_;
 wire _0383_;
 wire _0384_;
 wire _0385_;
 wire _0386_;
 wire _0387_;
 wire _0388_;
 wire _0389_;
 wire _0390_;
 wire _0391_;
 wire _0392_;
 wire _0393_;
 wire _0394_;
 wire _0395_;
 wire _0396_;
 wire _0397_;
 wire _0398_;
 wire _0399_;
 wire _0400_;
 wire _0401_;
 wire _0402_;
 wire _0403_;
 wire _0404_;
 wire _0405_;
 wire _0406_;
 wire _0407_;
 wire _0408_;
 wire _0409_;
 wire _0410_;
 wire _0411_;
 wire _0412_;
 wire _0413_;
 wire _0414_;
 wire _0415_;
 wire _0416_;
 wire _0417_;
 wire _0418_;
 wire _0419_;
 wire _0420_;
 wire _0421_;
 wire _0422_;
 wire _0423_;
 wire _0424_;
 wire _0425_;
 wire _0426_;
 wire _0427_;
 wire _0428_;
 wire _0429_;
 wire _0430_;
 wire _0431_;
 wire _0432_;
 wire _0433_;
 wire _0434_;
 wire _0435_;
 wire _0436_;
 wire _0437_;
 wire _0438_;
 wire _0439_;
 wire _0440_;
 wire _0441_;
 wire _0442_;
 wire _0443_;
 wire _0444_;
 wire _0445_;
 wire _0446_;
 wire _0447_;
 wire _0448_;
 wire _0449_;
 wire _0450_;
 wire _0451_;
 wire _0452_;
 wire _0453_;
 wire _0454_;
 wire _0455_;
 wire _0456_;
 wire _0457_;
 wire _0458_;
 wire _0459_;
 wire _0460_;
 wire _0461_;
 wire _0462_;
 wire _0463_;
 wire _0464_;
 wire _0465_;
 wire _0466_;
 wire _0467_;
 wire _0468_;
 wire _0469_;
 wire _0470_;
 wire _0471_;
 wire _0472_;
 wire _0473_;
 wire _0474_;
 wire _0475_;
 wire _0476_;
 wire _0477_;
 wire _0478_;
 wire _0479_;
 wire _0480_;
 wire _0481_;
 wire _0482_;
 wire _0483_;
 wire _0484_;
 wire _0485_;
 wire _0486_;
 wire _0487_;
 wire _0488_;
 wire _0489_;
 wire _0490_;
 wire _0491_;
 wire _0492_;
 wire _0493_;
 wire _0494_;
 wire _0495_;
 wire _0496_;
 wire _0497_;
 wire _0498_;
 wire _0499_;
 wire _0500_;
 wire _0501_;
 wire _0502_;
 wire _0503_;
 wire _0504_;
 wire _0505_;
 wire _0506_;
 wire _0507_;
 wire _0508_;
 wire _0509_;
 wire _0510_;
 wire _0511_;
 wire _0512_;
 wire _0513_;
 wire _0514_;
 wire _0515_;
 wire _0516_;
 wire _0517_;
 wire _0518_;
 wire _0519_;
 wire _0520_;
 wire _0521_;
 wire _0522_;
 wire _0523_;
 wire _0524_;
 wire _0525_;
 wire _0526_;
 wire _0527_;
 wire _0528_;
 wire _0529_;
 wire _0530_;
 wire _0531_;
 wire _0532_;
 wire _0533_;
 wire _0534_;
 wire _0535_;
 wire _0536_;
 wire _0537_;
 wire _0538_;
 wire _0539_;
 wire _0540_;
 wire _0541_;
 wire _0542_;
 wire _0543_;
 wire _0544_;
 wire _0545_;
 wire _0546_;
 wire _0547_;
 wire _0548_;
 wire _0549_;
 wire _0550_;
 wire _0551_;
 wire _0552_;
 wire _0553_;
 wire _0554_;
 wire _0555_;
 wire _0556_;
 wire _0557_;
 wire _0558_;
 wire _0559_;
 wire _0560_;
 wire _0561_;
 wire _0562_;
 wire _0563_;
 wire _0564_;
 wire _0565_;
 wire _0566_;
 wire _0567_;
 wire _0568_;
 wire _0569_;
 wire _0570_;
 wire _0571_;
 wire _0572_;
 wire _0573_;
 wire _0574_;
 wire _0575_;
 wire _0576_;
 wire _0577_;
 wire _0578_;
 wire _0579_;
 wire _0580_;
 wire _0581_;
 wire _0582_;
 wire _0583_;
 wire _0584_;
 wire _0585_;
 wire _0586_;
 wire _0587_;
 wire _0588_;
 wire _0589_;
 wire _0590_;
 wire _0591_;
 wire _0592_;
 wire _0593_;
 wire _0594_;
 wire _0595_;
 wire _0596_;
 wire _0597_;
 wire _0598_;
 wire _0599_;
 wire _0600_;
 wire _0601_;
 wire _0602_;
 wire _0603_;
 wire _0604_;
 wire _0605_;
 wire _0606_;
 wire _0607_;
 wire _0608_;
 wire _0609_;
 wire _0610_;
 wire _0611_;
 wire _0612_;
 wire _0613_;
 wire _0614_;
 wire _0615_;
 wire _0616_;
 wire _0617_;
 wire _0618_;
 wire _0619_;
 wire _0620_;
 wire _0621_;
 wire _0622_;
 wire _0623_;
 wire _0624_;
 wire _0625_;
 wire _0626_;
 wire _0627_;
 wire _0628_;
 wire _0629_;
 wire _0630_;
 wire _0631_;
 wire _0632_;
 wire _0633_;
 wire _0634_;
 wire _0635_;
 wire _0636_;
 wire _0637_;
 wire _0638_;
 wire _0639_;
 wire _0640_;
 wire _0641_;
 wire _0642_;
 wire _0643_;
 wire _0644_;
 wire _0645_;
 wire _0646_;
 wire _0647_;
 wire _0648_;
 wire _0649_;
 wire _0650_;
 wire _0651_;
 wire _0652_;
 wire _0653_;
 wire _0654_;
 wire _0655_;
 wire _0656_;
 wire _0657_;
 wire _0658_;
 wire _0659_;
 wire _0660_;
 wire _0661_;
 wire _0662_;
 wire _0663_;
 wire _0664_;
 wire _0665_;
 wire _0666_;
 wire _0667_;
 wire _0668_;
 wire _0669_;
 wire _0670_;
 wire _0671_;
 wire _0672_;
 wire _0673_;
 wire _0674_;
 wire _0675_;
 wire _0676_;
 wire _0677_;
 wire _0678_;
 wire _0679_;
 wire _0680_;
 wire _0681_;
 wire _0682_;
 wire _0683_;
 wire _0684_;
 wire _0685_;
 wire _0686_;
 wire _0687_;
 wire _0688_;
 wire _0689_;
 wire _0690_;
 wire _0691_;
 wire _0692_;
 wire _0693_;
 wire _0694_;
 wire _0695_;
 wire _0696_;
 wire _0697_;
 wire _0698_;
 wire _0699_;
 wire _0700_;
 wire _0701_;
 wire _0702_;
 wire _0703_;
 wire _0704_;
 wire _0705_;
 wire _0706_;
 wire _0707_;
 wire _0708_;
 wire _0709_;
 wire _0710_;
 wire _0711_;
 wire _0712_;
 wire _0713_;
 wire _0714_;
 wire _0715_;
 wire _0716_;
 wire _0717_;
 wire _0718_;
 wire _0719_;
 wire _0720_;
 wire _0721_;
 wire _0722_;
 wire _0723_;
 wire _0724_;
 wire _0725_;
 wire _0726_;
 wire _0727_;
 wire _0728_;
 wire _0729_;
 wire _0730_;
 wire _0731_;
 wire _0732_;
 wire _0733_;
 wire _0734_;
 wire _0735_;
 wire _0736_;
 wire _0737_;
 wire _0738_;
 wire _0739_;
 wire _0740_;
 wire _0741_;
 wire _0742_;
 wire _0743_;
 wire _0744_;
 wire _0745_;
 wire _0746_;
 wire _0747_;
 wire _0748_;
 wire _0749_;
 wire _0750_;
 wire _0751_;
 wire _0752_;
 wire _0753_;
 wire _0754_;
 wire _0755_;
 wire _0756_;
 wire _0757_;
 wire _0758_;
 wire _0759_;
 wire _0760_;
 wire _0761_;
 wire _0762_;
 wire _0763_;
 wire _0764_;
 wire _0765_;
 wire _0766_;
 wire _0767_;
 wire _0768_;
 wire _0769_;
 wire _0770_;
 wire _0771_;
 wire _0772_;
 wire _0773_;
 wire _0774_;
 wire _0775_;
 wire _0776_;
 wire _0777_;
 wire _0778_;
 wire _0779_;
 wire _0780_;
 wire _0781_;
 wire _0782_;
 wire _0783_;
 wire _0784_;
 wire _0785_;
 wire _0786_;
 wire _0787_;
 wire _0788_;
 wire _0789_;
 wire _0790_;
 wire _0791_;
 wire _0792_;
 wire _0793_;
 wire _0794_;
 wire _0795_;
 wire _0796_;
 wire _0797_;
 wire _0798_;
 wire _0799_;
 wire _0800_;
 wire _0801_;
 wire _0802_;
 wire _0803_;
 wire _0804_;
 wire _0805_;
 wire _0806_;
 wire _0807_;
 wire _0808_;
 wire _0809_;
 wire _0810_;
 wire _0811_;
 wire _0812_;
 wire _0813_;
 wire _0814_;
 wire _0815_;
 wire _0816_;
 wire _0817_;
 wire _0818_;
 wire _0819_;
 wire _0820_;
 wire _0821_;
 wire _0822_;
 wire _0823_;
 wire _0824_;
 wire _0825_;
 wire _0826_;
 wire _0827_;
 wire _0828_;
 wire _0829_;
 wire _0830_;
 wire _0831_;
 wire _0832_;
 wire _0833_;
 wire _0834_;
 wire _0835_;
 wire _0836_;
 wire _0837_;
 wire _0838_;
 wire _0839_;
 wire _0840_;
 wire _0841_;
 wire _0842_;
 wire _0843_;
 wire _0844_;
 wire _0845_;
 wire _0846_;
 wire _0847_;
 wire _0848_;
 wire _0849_;
 wire _0850_;
 wire _0851_;
 wire _0852_;
 wire _0853_;
 wire _0854_;
 wire _0855_;
 wire _0856_;
 wire _0857_;
 wire _0858_;
 wire _0859_;
 wire _0860_;
 wire _0861_;
 wire _0862_;
 wire _0863_;
 wire _0864_;
 wire _0865_;
 wire _0866_;
 wire _0867_;
 wire _0868_;
 wire _0869_;
 wire _0870_;
 wire _0871_;
 wire _0872_;
 wire _0873_;
 wire _0874_;
 wire _0875_;
 wire _0876_;
 wire _0877_;
 wire _0878_;
 wire _0879_;
 wire _0880_;
 wire _0881_;
 wire _0882_;
 wire _0883_;
 wire _0884_;
 wire _0885_;
 wire _0886_;
 wire _0887_;
 wire _0888_;
 wire _0889_;
 wire _0890_;
 wire _0891_;
 wire _0892_;
 wire _0893_;
 wire _0894_;
 wire _0895_;
 wire _0896_;
 wire _0897_;
 wire _0898_;
 wire _0899_;
 wire _0900_;
 wire _0901_;
 wire _0902_;
 wire _0903_;
 wire _0904_;
 wire _0905_;
 wire _0906_;
 wire _0907_;
 wire _0908_;
 wire _0909_;
 wire _0910_;
 wire _0911_;
 wire _0912_;
 wire _0913_;
 wire _0914_;
 wire _0915_;
 wire _0916_;
 wire _0917_;
 wire _0918_;
 wire _0919_;
 wire _0920_;
 wire _0921_;
 wire _0922_;
 wire _0923_;
 wire _0924_;
 wire _0925_;
 wire _0926_;
 wire _0927_;
 wire _0928_;
 wire _0929_;
 wire _0930_;
 wire _0931_;
 wire _0932_;
 wire _0933_;
 wire _0934_;
 wire _0935_;
 wire _0936_;
 wire _0937_;
 wire _0938_;
 wire _0939_;
 wire _0940_;
 wire _0941_;
 wire _0942_;
 wire _0943_;
 wire _0944_;
 wire _0945_;
 wire _0946_;
 wire _0947_;
 wire _0948_;
 wire _0949_;
 wire _0950_;
 wire _0951_;
 wire _0952_;
 wire _0953_;
 wire _0954_;
 wire _0955_;
 wire _0956_;
 wire _0957_;
 wire _0958_;
 wire _0959_;
 wire _0960_;
 wire _0961_;
 wire _0962_;
 wire _0963_;
 wire _0964_;
 wire _0965_;
 wire _0966_;
 wire _0967_;
 wire _0968_;
 wire _0969_;
 wire _0970_;
 wire _0971_;
 wire _0972_;
 wire _0973_;
 wire _0974_;
 wire _0975_;
 wire _0976_;
 wire _0977_;
 wire _0978_;
 wire _0979_;
 wire _0980_;
 wire _0981_;
 wire _0982_;
 wire _0983_;
 wire _0984_;
 wire _0985_;
 wire _0986_;
 wire _0987_;
 wire _0988_;
 wire _0989_;
 wire _0990_;
 wire _0991_;
 wire _0992_;
 wire _0993_;
 wire _0994_;
 wire _0995_;
 wire _0996_;
 wire _0997_;
 wire _0998_;
 wire _0999_;
 wire _1000_;
 wire _1001_;
 wire _1002_;
 wire _1003_;
 wire _1004_;
 wire _1005_;
 wire _1006_;
 wire _1007_;
 wire _1008_;
 wire _1009_;
 wire _1010_;
 wire _1011_;
 wire _1012_;
 wire _1013_;
 wire _1014_;
 wire _1015_;
 wire _1016_;
 wire _1017_;
 wire _1018_;
 wire _1019_;
 wire _1020_;
 wire _1021_;
 wire _1022_;
 wire _1023_;
 wire _1024_;
 wire _1025_;
 wire _1026_;
 wire _1027_;
 wire _1028_;
 wire _1029_;
 wire _1030_;
 wire _1031_;
 wire _1032_;
 wire _1033_;
 wire _1034_;
 wire _1035_;
 wire _1036_;
 wire _1037_;
 wire _1038_;
 wire _1039_;
 wire _1040_;
 wire _1041_;
 wire _1042_;
 wire _1043_;
 wire _1044_;
 wire _1045_;
 wire _1046_;
 wire _1047_;
 wire _1048_;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[0] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[10] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[11] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[12] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[13] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[14] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[15] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[16] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[17] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[18] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[19] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[1] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[20] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[21] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[22] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[23] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[24] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[25] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[26] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[27] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[28] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[29] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[2] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[30] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[31] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[3] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[4] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[5] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[6] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[7] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[8] ;
 wire \motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[9] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[0] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[10] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[11] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[12] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[13] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[14] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[15] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[16] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[17] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[18] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[19] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[1] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[20] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[21] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[22] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[23] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[24] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[25] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[26] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[27] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[28] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[29] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[2] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[30] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[31] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[3] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[4] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[5] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[6] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[7] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[8] ;
 wire \motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[9] ;
 wire motor_control_register_map_cfg_enable_from_u_motor_control_register_map;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[0] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[10] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[11] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[12] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[13] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[14] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[15] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[16] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[17] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[18] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[19] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[1] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[20] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[21] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[22] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[23] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[24] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[25] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[26] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[27] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[28] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[29] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[2] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[30] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[31] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[3] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[4] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[5] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[6] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[7] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[8] ;
 wire \motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[9] ;
 wire motor_control_register_map_cfg_safety_override_from_u_motor_control_register_map;
 wire \motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[0] ;
 wire \motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[10] ;
 wire \motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[11] ;
 wire \motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[12] ;
 wire \motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[13] ;
 wire \motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[14] ;
 wire \motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[15] ;
 wire \motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[1] ;
 wire \motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[2] ;
 wire \motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[3] ;
 wire \motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[4] ;
 wire \motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[5] ;
 wire \motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[6] ;
 wire \motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[7] ;
 wire \motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[8] ;
 wire \motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[9] ;
 wire \motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[0] ;
 wire \motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[10] ;
 wire \motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[11] ;
 wire \motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[12] ;
 wire \motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[13] ;
 wire \motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[14] ;
 wire \motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[15] ;
 wire \motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[1] ;
 wire \motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[2] ;
 wire \motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[3] ;
 wire \motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[4] ;
 wire \motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[5] ;
 wire \motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[6] ;
 wire \motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[7] ;
 wire \motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[8] ;
 wire \motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[9] ;
 wire motor_control_transport_fsm_status_fault_from_u_motor_control_transport_fsm;
 wire \u_motor_control_transport_fsm.rsp_ready_next ;
 wire \u_motor_control_transport_fsm.seq_reg[0] ;
 wire \u_motor_control_transport_fsm.seq_reg[10] ;
 wire \u_motor_control_transport_fsm.seq_reg[11] ;
 wire \u_motor_control_transport_fsm.seq_reg[12] ;
 wire \u_motor_control_transport_fsm.seq_reg[13] ;
 wire \u_motor_control_transport_fsm.seq_reg[14] ;
 wire \u_motor_control_transport_fsm.seq_reg[15] ;
 wire \u_motor_control_transport_fsm.seq_reg[1] ;
 wire \u_motor_control_transport_fsm.seq_reg[2] ;
 wire \u_motor_control_transport_fsm.seq_reg[3] ;
 wire \u_motor_control_transport_fsm.seq_reg[4] ;
 wire \u_motor_control_transport_fsm.seq_reg[5] ;
 wire \u_motor_control_transport_fsm.seq_reg[6] ;
 wire \u_motor_control_transport_fsm.seq_reg[7] ;
 wire \u_motor_control_transport_fsm.seq_reg[8] ;
 wire \u_motor_control_transport_fsm.seq_reg[9] ;
 wire \u_motor_control_transport_fsm.state[0] ;
 wire \u_motor_control_transport_fsm.state[1] ;
 wire \u_motor_control_transport_fsm.state[2] ;
 wire \u_motor_control_transport_fsm.state[3] ;
 wire \u_motor_control_transport_fsm.state[4] ;
 wire \u_motor_control_transport_fsm.state[5] ;
 wire \u_motor_control_transport_fsm.timeout_cnt[0] ;
 wire \u_motor_control_transport_fsm.timeout_cnt[10] ;
 wire \u_motor_control_transport_fsm.timeout_cnt[11] ;
 wire \u_motor_control_transport_fsm.timeout_cnt[12] ;
 wire \u_motor_control_transport_fsm.timeout_cnt[13] ;
 wire \u_motor_control_transport_fsm.timeout_cnt[14] ;
 wire \u_motor_control_transport_fsm.timeout_cnt[15] ;
 wire \u_motor_control_transport_fsm.timeout_cnt[1] ;
 wire \u_motor_control_transport_fsm.timeout_cnt[2] ;
 wire \u_motor_control_transport_fsm.timeout_cnt[3] ;
 wire \u_motor_control_transport_fsm.timeout_cnt[4] ;
 wire \u_motor_control_transport_fsm.timeout_cnt[5] ;
 wire \u_motor_control_transport_fsm.timeout_cnt[6] ;
 wire \u_motor_control_transport_fsm.timeout_cnt[7] ;
 wire \u_motor_control_transport_fsm.timeout_cnt[8] ;
 wire \u_motor_control_transport_fsm.timeout_cnt[9] ;

 sky130_fd_sc_hd__inv_2 _1049_ (.A(\u_motor_control_transport_fsm.seq_reg[12] ),
    .Y(_0734_));
 sky130_fd_sc_hd__inv_2 _1050_ (.A(\u_motor_control_transport_fsm.seq_reg[10] ),
    .Y(_0735_));
 sky130_fd_sc_hd__inv_2 _1051_ (.A(\u_motor_control_transport_fsm.seq_reg[7] ),
    .Y(_0736_));
 sky130_fd_sc_hd__inv_2 _1052_ (.A(\u_motor_control_transport_fsm.seq_reg[4] ),
    .Y(_0737_));
 sky130_fd_sc_hd__inv_2 _1053_ (.A(\u_motor_control_transport_fsm.timeout_cnt[15] ),
    .Y(_0738_));
 sky130_fd_sc_hd__inv_2 _1054_ (.A(\u_motor_control_transport_fsm.timeout_cnt[9] ),
    .Y(_0739_));
 sky130_fd_sc_hd__inv_2 _1055_ (.A(\u_motor_control_transport_fsm.timeout_cnt[8] ),
    .Y(_0740_));
 sky130_fd_sc_hd__inv_2 _1056_ (.A(\u_motor_control_transport_fsm.timeout_cnt[1] ),
    .Y(_0741_));
 sky130_fd_sc_hd__inv_2 _1057_ (.A(\u_motor_control_transport_fsm.timeout_cnt[0] ),
    .Y(_0742_));
 sky130_fd_sc_hd__inv_2 _1058_ (.A(reset_n),
    .Y(_0001_));
 sky130_fd_sc_hd__inv_2 _1059_ (.A(motor_control_register_map_cfg_timeout_limit[3]),
    .Y(_0743_));
 sky130_fd_sc_hd__inv_2 _1060_ (.A(motor_control_register_map_cfg_timeout_limit[2]),
    .Y(_0744_));
 sky130_fd_sc_hd__inv_2 _1061_ (.A(motor_control_register_map_cfg_timeout_limit[5]),
    .Y(_0745_));
 sky130_fd_sc_hd__inv_2 _1062_ (.A(motor_control_register_map_cfg_timeout_limit[4]),
    .Y(_0746_));
 sky130_fd_sc_hd__inv_2 _1063_ (.A(motor_control_register_map_cfg_timeout_limit[8]),
    .Y(_0747_));
 sky130_fd_sc_hd__inv_2 _1064_ (.A(motor_control_register_map_cfg_timeout_limit[11]),
    .Y(_0748_));
 sky130_fd_sc_hd__inv_2 _1065_ (.A(motor_control_register_map_cfg_timeout_limit[13]),
    .Y(_0749_));
 sky130_fd_sc_hd__inv_2 _1066_ (.A(motor_control_register_map_cfg_timeout_limit[12]),
    .Y(_0750_));
 sky130_fd_sc_hd__inv_2 _1067_ (.A(motor_control_register_map_cfg_timeout_limit[14]),
    .Y(_0751_));
 sky130_fd_sc_hd__inv_2 _1068_ (.A(motor_control_register_map_cfg_enable),
    .Y(_0752_));
 sky130_fd_sc_hd__inv_2 _1069_ (.A(motor_control_transport_fsm_status_fault_from_u_motor_control_transport_fsm),
    .Y(_0753_));
 sky130_fd_sc_hd__inv_2 _1070_ (.A(motor_control_register_map_cfg_safety_override),
    .Y(_0754_));
 sky130_fd_sc_hd__inv_2 _1071_ (.A(rsp_data[52]),
    .Y(_0755_));
 sky130_fd_sc_hd__inv_2 _1072_ (.A(rsp_data[60]),
    .Y(_0756_));
 sky130_fd_sc_hd__inv_2 _1073_ (.A(\u_motor_control_transport_fsm.state[1] ),
    .Y(_0757_));
 sky130_fd_sc_hd__inv_2 _1074_ (.A(motor_control_register_map_cfg_start),
    .Y(_0758_));
 sky130_fd_sc_hd__inv_2 _1075_ (.A(motor_control_register_map_cfg_clamp_max[0]),
    .Y(_0759_));
 sky130_fd_sc_hd__inv_2 _1076_ (.A(motor_control_register_map_cfg_clamp_max[1]),
    .Y(_0760_));
 sky130_fd_sc_hd__inv_2 _1077_ (.A(motor_control_register_map_cfg_clamp_max[2]),
    .Y(_0761_));
 sky130_fd_sc_hd__inv_2 _1078_ (.A(motor_control_register_map_cfg_clamp_max[3]),
    .Y(_0762_));
 sky130_fd_sc_hd__inv_2 _1079_ (.A(motor_control_register_map_cfg_clamp_max[4]),
    .Y(_0763_));
 sky130_fd_sc_hd__inv_2 _1080_ (.A(motor_control_register_map_cfg_clamp_max[5]),
    .Y(_0764_));
 sky130_fd_sc_hd__inv_2 _1081_ (.A(motor_control_register_map_cfg_clamp_max[6]),
    .Y(_0765_));
 sky130_fd_sc_hd__inv_2 _1082_ (.A(motor_control_register_map_cfg_clamp_max[7]),
    .Y(_0766_));
 sky130_fd_sc_hd__inv_2 _1083_ (.A(motor_control_register_map_cfg_clamp_min[0]),
    .Y(_0767_));
 sky130_fd_sc_hd__inv_2 _1084_ (.A(motor_control_register_map_cfg_clamp_min[1]),
    .Y(_0768_));
 sky130_fd_sc_hd__inv_2 _1085_ (.A(motor_control_register_map_cfg_clamp_min[2]),
    .Y(_0769_));
 sky130_fd_sc_hd__inv_2 _1086_ (.A(motor_control_register_map_cfg_clamp_min[3]),
    .Y(_0770_));
 sky130_fd_sc_hd__inv_2 _1087_ (.A(motor_control_register_map_cfg_clamp_min[4]),
    .Y(_0771_));
 sky130_fd_sc_hd__inv_2 _1088_ (.A(motor_control_register_map_cfg_clamp_min[5]),
    .Y(_0772_));
 sky130_fd_sc_hd__inv_2 _1089_ (.A(motor_control_register_map_cfg_clamp_min[6]),
    .Y(_0773_));
 sky130_fd_sc_hd__inv_2 _1090_ (.A(motor_control_register_map_cfg_clamp_min[7]),
    .Y(_0774_));
 sky130_fd_sc_hd__inv_2 _1091_ (.A(rsp_data[31]),
    .Y(_0775_));
 sky130_fd_sc_hd__inv_2 _1092_ (.A(motor_control_register_map_cfg_clamp_max[31]),
    .Y(_0776_));
 sky130_fd_sc_hd__inv_2 _1093_ (.A(rsp_data[30]),
    .Y(_0777_));
 sky130_fd_sc_hd__inv_2 _1094_ (.A(motor_control_register_map_cfg_clamp_max[30]),
    .Y(_0778_));
 sky130_fd_sc_hd__inv_2 _1095_ (.A(rsp_data[29]),
    .Y(_0779_));
 sky130_fd_sc_hd__inv_2 _1096_ (.A(motor_control_register_map_cfg_clamp_max[29]),
    .Y(_0780_));
 sky130_fd_sc_hd__inv_2 _1097_ (.A(motor_control_register_map_cfg_clamp_max[28]),
    .Y(_0781_));
 sky130_fd_sc_hd__inv_2 _1098_ (.A(rsp_data[28]),
    .Y(_0782_));
 sky130_fd_sc_hd__inv_2 _1099_ (.A(rsp_data[27]),
    .Y(_0783_));
 sky130_fd_sc_hd__inv_2 _1100_ (.A(motor_control_register_map_cfg_clamp_max[27]),
    .Y(_0784_));
 sky130_fd_sc_hd__inv_2 _1101_ (.A(rsp_data[26]),
    .Y(_0785_));
 sky130_fd_sc_hd__inv_2 _1102_ (.A(motor_control_register_map_cfg_clamp_max[26]),
    .Y(_0786_));
 sky130_fd_sc_hd__inv_2 _1103_ (.A(rsp_data[25]),
    .Y(_0787_));
 sky130_fd_sc_hd__inv_2 _1104_ (.A(motor_control_register_map_cfg_clamp_max[25]),
    .Y(_0788_));
 sky130_fd_sc_hd__inv_2 _1105_ (.A(rsp_data[24]),
    .Y(_0789_));
 sky130_fd_sc_hd__inv_2 _1106_ (.A(motor_control_register_map_cfg_clamp_max[24]),
    .Y(_0790_));
 sky130_fd_sc_hd__inv_2 _1107_ (.A(rsp_data[23]),
    .Y(_0791_));
 sky130_fd_sc_hd__inv_2 _1108_ (.A(motor_control_register_map_cfg_clamp_max[23]),
    .Y(_0792_));
 sky130_fd_sc_hd__inv_2 _1109_ (.A(rsp_data[22]),
    .Y(_0793_));
 sky130_fd_sc_hd__inv_2 _1110_ (.A(motor_control_register_map_cfg_clamp_max[22]),
    .Y(_0794_));
 sky130_fd_sc_hd__inv_2 _1111_ (.A(rsp_data[21]),
    .Y(_0795_));
 sky130_fd_sc_hd__inv_2 _1112_ (.A(motor_control_register_map_cfg_clamp_max[21]),
    .Y(_0796_));
 sky130_fd_sc_hd__inv_2 _1113_ (.A(rsp_data[20]),
    .Y(_0797_));
 sky130_fd_sc_hd__inv_2 _1114_ (.A(motor_control_register_map_cfg_clamp_max[20]),
    .Y(_0798_));
 sky130_fd_sc_hd__inv_2 _1115_ (.A(rsp_data[19]),
    .Y(_0799_));
 sky130_fd_sc_hd__inv_2 _1116_ (.A(motor_control_register_map_cfg_clamp_max[19]),
    .Y(_0800_));
 sky130_fd_sc_hd__inv_2 _1117_ (.A(rsp_data[18]),
    .Y(_0801_));
 sky130_fd_sc_hd__inv_2 _1118_ (.A(motor_control_register_map_cfg_clamp_max[18]),
    .Y(_0802_));
 sky130_fd_sc_hd__inv_2 _1119_ (.A(rsp_data[17]),
    .Y(_0803_));
 sky130_fd_sc_hd__inv_2 _1120_ (.A(motor_control_register_map_cfg_clamp_max[17]),
    .Y(_0804_));
 sky130_fd_sc_hd__inv_2 _1121_ (.A(rsp_data[16]),
    .Y(_0805_));
 sky130_fd_sc_hd__inv_2 _1122_ (.A(motor_control_register_map_cfg_clamp_max[16]),
    .Y(_0806_));
 sky130_fd_sc_hd__inv_2 _1123_ (.A(rsp_data[15]),
    .Y(_0807_));
 sky130_fd_sc_hd__inv_2 _1124_ (.A(motor_control_register_map_cfg_clamp_max[15]),
    .Y(_0808_));
 sky130_fd_sc_hd__inv_2 _1125_ (.A(rsp_data[14]),
    .Y(_0809_));
 sky130_fd_sc_hd__inv_2 _1126_ (.A(motor_control_register_map_cfg_clamp_max[14]),
    .Y(_0810_));
 sky130_fd_sc_hd__inv_2 _1127_ (.A(rsp_data[13]),
    .Y(_0811_));
 sky130_fd_sc_hd__inv_2 _1128_ (.A(motor_control_register_map_cfg_clamp_max[13]),
    .Y(_0812_));
 sky130_fd_sc_hd__inv_2 _1129_ (.A(rsp_data[12]),
    .Y(_0813_));
 sky130_fd_sc_hd__inv_2 _1130_ (.A(motor_control_register_map_cfg_clamp_max[12]),
    .Y(_0814_));
 sky130_fd_sc_hd__inv_2 _1131_ (.A(rsp_data[11]),
    .Y(_0815_));
 sky130_fd_sc_hd__inv_2 _1132_ (.A(motor_control_register_map_cfg_clamp_max[11]),
    .Y(_0816_));
 sky130_fd_sc_hd__inv_2 _1133_ (.A(rsp_data[10]),
    .Y(_0817_));
 sky130_fd_sc_hd__inv_2 _1134_ (.A(motor_control_register_map_cfg_clamp_max[10]),
    .Y(_0818_));
 sky130_fd_sc_hd__inv_2 _1135_ (.A(rsp_data[9]),
    .Y(_0819_));
 sky130_fd_sc_hd__inv_2 _1136_ (.A(motor_control_register_map_cfg_clamp_max[9]),
    .Y(_0820_));
 sky130_fd_sc_hd__inv_2 _1137_ (.A(rsp_data[8]),
    .Y(_0821_));
 sky130_fd_sc_hd__inv_2 _1138_ (.A(motor_control_register_map_cfg_clamp_max[8]),
    .Y(_0822_));
 sky130_fd_sc_hd__inv_2 _1139_ (.A(rsp_data[7]),
    .Y(_0823_));
 sky130_fd_sc_hd__inv_2 _1140_ (.A(rsp_data[6]),
    .Y(_0824_));
 sky130_fd_sc_hd__inv_2 _1141_ (.A(rsp_data[5]),
    .Y(_0825_));
 sky130_fd_sc_hd__inv_2 _1142_ (.A(rsp_data[4]),
    .Y(_0826_));
 sky130_fd_sc_hd__inv_2 _1143_ (.A(rsp_data[3]),
    .Y(_0827_));
 sky130_fd_sc_hd__inv_2 _1144_ (.A(rsp_data[2]),
    .Y(_0828_));
 sky130_fd_sc_hd__inv_2 _1145_ (.A(rsp_data[1]),
    .Y(_0829_));
 sky130_fd_sc_hd__inv_2 _1146_ (.A(rsp_data[0]),
    .Y(_0830_));
 sky130_fd_sc_hd__inv_2 _1147_ (.A(motor_control_register_map_cfg_clamp_min[31]),
    .Y(_0831_));
 sky130_fd_sc_hd__inv_2 _1148_ (.A(motor_control_register_map_cfg_clamp_min[30]),
    .Y(_0832_));
 sky130_fd_sc_hd__inv_2 _1149_ (.A(motor_control_register_map_cfg_clamp_min[29]),
    .Y(_0833_));
 sky130_fd_sc_hd__inv_2 _1150_ (.A(motor_control_register_map_cfg_clamp_min[28]),
    .Y(_0834_));
 sky130_fd_sc_hd__inv_2 _1151_ (.A(motor_control_register_map_cfg_clamp_min[27]),
    .Y(_0835_));
 sky130_fd_sc_hd__inv_2 _1152_ (.A(motor_control_register_map_cfg_clamp_min[26]),
    .Y(_0836_));
 sky130_fd_sc_hd__inv_2 _1153_ (.A(motor_control_register_map_cfg_clamp_min[25]),
    .Y(_0837_));
 sky130_fd_sc_hd__inv_2 _1154_ (.A(motor_control_register_map_cfg_clamp_min[24]),
    .Y(_0838_));
 sky130_fd_sc_hd__inv_2 _1155_ (.A(motor_control_register_map_cfg_clamp_min[23]),
    .Y(_0839_));
 sky130_fd_sc_hd__inv_2 _1156_ (.A(motor_control_register_map_cfg_clamp_min[22]),
    .Y(_0840_));
 sky130_fd_sc_hd__inv_2 _1157_ (.A(motor_control_register_map_cfg_clamp_min[21]),
    .Y(_0841_));
 sky130_fd_sc_hd__inv_2 _1158_ (.A(motor_control_register_map_cfg_clamp_min[20]),
    .Y(_0842_));
 sky130_fd_sc_hd__inv_2 _1159_ (.A(motor_control_register_map_cfg_clamp_min[19]),
    .Y(_0843_));
 sky130_fd_sc_hd__inv_2 _1160_ (.A(motor_control_register_map_cfg_clamp_min[18]),
    .Y(_0844_));
 sky130_fd_sc_hd__inv_2 _1161_ (.A(motor_control_register_map_cfg_clamp_min[17]),
    .Y(_0845_));
 sky130_fd_sc_hd__inv_2 _1162_ (.A(motor_control_register_map_cfg_clamp_min[16]),
    .Y(_0846_));
 sky130_fd_sc_hd__inv_2 _1163_ (.A(motor_control_register_map_cfg_clamp_min[15]),
    .Y(_0847_));
 sky130_fd_sc_hd__inv_2 _1164_ (.A(motor_control_register_map_cfg_clamp_min[14]),
    .Y(_0848_));
 sky130_fd_sc_hd__inv_2 _1165_ (.A(motor_control_register_map_cfg_clamp_min[13]),
    .Y(_0849_));
 sky130_fd_sc_hd__inv_2 _1166_ (.A(motor_control_register_map_cfg_clamp_min[12]),
    .Y(_0850_));
 sky130_fd_sc_hd__inv_2 _1167_ (.A(motor_control_register_map_cfg_clamp_min[11]),
    .Y(_0851_));
 sky130_fd_sc_hd__inv_2 _1168_ (.A(motor_control_register_map_cfg_clamp_min[10]),
    .Y(_0852_));
 sky130_fd_sc_hd__inv_2 _1169_ (.A(motor_control_register_map_cfg_clamp_min[9]),
    .Y(_0853_));
 sky130_fd_sc_hd__inv_2 _1170_ (.A(motor_control_register_map_cfg_clamp_min[8]),
    .Y(_0854_));
 sky130_fd_sc_hd__and2_2 _1171_ (.A(req_ready),
    .B(\u_motor_control_transport_fsm.state[2] ),
    .X(_0855_));
 sky130_fd_sc_hd__nand2_2 _1172_ (.A(req_ready),
    .B(\u_motor_control_transport_fsm.state[2] ),
    .Y(_0856_));
 sky130_fd_sc_hd__nor2_2 _1173_ (.A(_0001_),
    .B(_0752_),
    .Y(_0857_));
 sky130_fd_sc_hd__and2b_2 _1174_ (.A_N(\u_motor_control_transport_fsm.timeout_cnt[14] ),
    .B(motor_control_register_map_cfg_timeout_limit[14]),
    .X(_0858_));
 sky130_fd_sc_hd__a21oi_2 _1175_ (.A1(_0738_),
    .A2(motor_control_register_map_cfg_timeout_limit[15]),
    .B1(_0858_),
    .Y(_0859_));
 sky130_fd_sc_hd__and2b_2 _1176_ (.A_N(\u_motor_control_transport_fsm.timeout_cnt[12] ),
    .B(motor_control_register_map_cfg_timeout_limit[12]),
    .X(_0860_));
 sky130_fd_sc_hd__and2b_2 _1177_ (.A_N(\u_motor_control_transport_fsm.timeout_cnt[13] ),
    .B(motor_control_register_map_cfg_timeout_limit[13]),
    .X(_0861_));
 sky130_fd_sc_hd__a2111o_2 _1178_ (.A1(_0738_),
    .A2(motor_control_register_map_cfg_timeout_limit[15]),
    .B1(_0858_),
    .C1(_0860_),
    .D1(_0861_),
    .X(_0862_));
 sky130_fd_sc_hd__a22o_2 _1179_ (.A1(\u_motor_control_transport_fsm.timeout_cnt[13] ),
    .A2(_0749_),
    .B1(_0751_),
    .B2(\u_motor_control_transport_fsm.timeout_cnt[14] ),
    .X(_0863_));
 sky130_fd_sc_hd__nor2_2 _1180_ (.A(_0738_),
    .B(motor_control_register_map_cfg_timeout_limit[15]),
    .Y(_0864_));
 sky130_fd_sc_hd__a2111o_2 _1181_ (.A1(\u_motor_control_transport_fsm.timeout_cnt[12] ),
    .A2(_0750_),
    .B1(_0862_),
    .C1(_0863_),
    .D1(_0864_),
    .X(_0865_));
 sky130_fd_sc_hd__nor2_2 _1182_ (.A(\u_motor_control_transport_fsm.timeout_cnt[11] ),
    .B(_0748_),
    .Y(_0866_));
 sky130_fd_sc_hd__and2_2 _1183_ (.A(\u_motor_control_transport_fsm.timeout_cnt[11] ),
    .B(_0748_),
    .X(_0867_));
 sky130_fd_sc_hd__xor2_2 _1184_ (.A(\u_motor_control_transport_fsm.timeout_cnt[10] ),
    .B(motor_control_register_map_cfg_timeout_limit[10]),
    .X(_0868_));
 sky130_fd_sc_hd__or3_2 _1185_ (.A(_0866_),
    .B(_0867_),
    .C(_0868_),
    .X(_0869_));
 sky130_fd_sc_hd__o2bb2a_2 _1186_ (.A1_N(_0739_),
    .A2_N(motor_control_register_map_cfg_timeout_limit[9]),
    .B1(_0747_),
    .B2(\u_motor_control_transport_fsm.timeout_cnt[8] ),
    .X(_0870_));
 sky130_fd_sc_hd__nor2_2 _1187_ (.A(_0739_),
    .B(motor_control_register_map_cfg_timeout_limit[9]),
    .Y(_0871_));
 sky130_fd_sc_hd__a21oi_2 _1188_ (.A1(\u_motor_control_transport_fsm.timeout_cnt[8] ),
    .A2(_0747_),
    .B1(_0871_),
    .Y(_0872_));
 sky130_fd_sc_hd__and4bb_2 _1189_ (.A_N(_0865_),
    .B_N(_0869_),
    .C(_0870_),
    .D(_0872_),
    .X(_0873_));
 sky130_fd_sc_hd__and2b_2 _1190_ (.A_N(\u_motor_control_transport_fsm.timeout_cnt[7] ),
    .B(motor_control_register_map_cfg_timeout_limit[7]),
    .X(_0874_));
 sky130_fd_sc_hd__and2b_2 _1191_ (.A_N(\u_motor_control_transport_fsm.timeout_cnt[6] ),
    .B(motor_control_register_map_cfg_timeout_limit[6]),
    .X(_0875_));
 sky130_fd_sc_hd__and2b_2 _1192_ (.A_N(motor_control_register_map_cfg_timeout_limit[6]),
    .B(\u_motor_control_transport_fsm.timeout_cnt[6] ),
    .X(_0876_));
 sky130_fd_sc_hd__nand2b_2 _1193_ (.A_N(motor_control_register_map_cfg_timeout_limit[7]),
    .B(\u_motor_control_transport_fsm.timeout_cnt[7] ),
    .Y(_0877_));
 sky130_fd_sc_hd__or4b_2 _1194_ (.A(_0874_),
    .B(_0875_),
    .C(_0876_),
    .D_N(_0877_),
    .X(_0878_));
 sky130_fd_sc_hd__o22a_2 _1195_ (.A1(\u_motor_control_transport_fsm.timeout_cnt[5] ),
    .A2(_0745_),
    .B1(_0746_),
    .B2(\u_motor_control_transport_fsm.timeout_cnt[4] ),
    .X(_0879_));
 sky130_fd_sc_hd__and2_2 _1196_ (.A(\u_motor_control_transport_fsm.timeout_cnt[5] ),
    .B(_0745_),
    .X(_0880_));
 sky130_fd_sc_hd__nand2_2 _1197_ (.A(\u_motor_control_transport_fsm.timeout_cnt[4] ),
    .B(_0746_),
    .Y(_0881_));
 sky130_fd_sc_hd__and4bb_2 _1198_ (.A_N(_0878_),
    .B_N(_0880_),
    .C(_0881_),
    .D(_0879_),
    .X(_0882_));
 sky130_fd_sc_hd__o22a_2 _1199_ (.A1(\u_motor_control_transport_fsm.timeout_cnt[3] ),
    .A2(_0743_),
    .B1(_0744_),
    .B2(\u_motor_control_transport_fsm.timeout_cnt[2] ),
    .X(_0883_));
 sky130_fd_sc_hd__nand2_2 _1200_ (.A(\u_motor_control_transport_fsm.timeout_cnt[3] ),
    .B(_0743_),
    .Y(_0884_));
 sky130_fd_sc_hd__nand2_2 _1201_ (.A(\u_motor_control_transport_fsm.timeout_cnt[2] ),
    .B(_0744_),
    .Y(_0885_));
 sky130_fd_sc_hd__and3_2 _1202_ (.A(_0883_),
    .B(_0884_),
    .C(_0885_),
    .X(_0886_));
 sky130_fd_sc_hd__o22a_2 _1203_ (.A1(_0741_),
    .A2(motor_control_register_map_cfg_timeout_limit[1]),
    .B1(motor_control_register_map_cfg_timeout_limit[0]),
    .B2(_0742_),
    .X(_0887_));
 sky130_fd_sc_hd__and2_2 _1204_ (.A(_0741_),
    .B(motor_control_register_map_cfg_timeout_limit[1]),
    .X(_0888_));
 sky130_fd_sc_hd__a21oi_2 _1205_ (.A1(_0742_),
    .A2(motor_control_register_map_cfg_timeout_limit[0]),
    .B1(_0888_),
    .Y(_0889_));
 sky130_fd_sc_hd__and3_2 _1206_ (.A(_0886_),
    .B(_0887_),
    .C(_0889_),
    .X(_0890_));
 sky130_fd_sc_hd__and3_2 _1207_ (.A(_0873_),
    .B(_0882_),
    .C(_0890_),
    .X(_0891_));
 sky130_fd_sc_hd__and2b_2 _1208_ (.A_N(_0883_),
    .B(_0884_),
    .X(_0892_));
 sky130_fd_sc_hd__o2111a_2 _1209_ (.A1(_0887_),
    .A2(_0888_),
    .B1(_0883_),
    .C1(_0884_),
    .D1(_0885_),
    .X(_0893_));
 sky130_fd_sc_hd__o21a_2 _1210_ (.A1(_0892_),
    .A2(_0893_),
    .B1(_0882_),
    .X(_0894_));
 sky130_fd_sc_hd__nor3_2 _1211_ (.A(_0878_),
    .B(_0879_),
    .C(_0880_),
    .Y(_0895_));
 sky130_fd_sc_hd__o21a_2 _1212_ (.A1(_0874_),
    .A2(_0875_),
    .B1(_0877_),
    .X(_0896_));
 sky130_fd_sc_hd__o31ai_2 _1213_ (.A1(_0894_),
    .A2(_0895_),
    .A3(_0896_),
    .B1(_0873_),
    .Y(_0897_));
 sky130_fd_sc_hd__a21bo_2 _1214_ (.A1(_0859_),
    .A2(_0863_),
    .B1_N(_0862_),
    .X(_0898_));
 sky130_fd_sc_hd__or3b_2 _1215_ (.A(\u_motor_control_transport_fsm.timeout_cnt[10] ),
    .B(_0867_),
    .C_N(motor_control_register_map_cfg_timeout_limit[10]),
    .X(_0899_));
 sky130_fd_sc_hd__o32a_2 _1216_ (.A1(_0869_),
    .A2(_0870_),
    .A3(_0871_),
    .B1(_0748_),
    .B2(\u_motor_control_transport_fsm.timeout_cnt[11] ),
    .X(_0900_));
 sky130_fd_sc_hd__a21o_2 _1217_ (.A1(_0899_),
    .A2(_0900_),
    .B1(_0865_),
    .X(_0901_));
 sky130_fd_sc_hd__o211a_2 _1218_ (.A1(_0864_),
    .A2(_0898_),
    .B1(_0901_),
    .C1(_0897_),
    .X(_0902_));
 sky130_fd_sc_hd__or4_2 _1219_ (.A(motor_control_register_map_cfg_timeout_limit[5]),
    .B(motor_control_register_map_cfg_timeout_limit[4]),
    .C(motor_control_register_map_cfg_timeout_limit[7]),
    .D(motor_control_register_map_cfg_timeout_limit[6]),
    .X(_0903_));
 sky130_fd_sc_hd__or4_2 _1220_ (.A(motor_control_register_map_cfg_timeout_limit[1]),
    .B(motor_control_register_map_cfg_timeout_limit[0]),
    .C(motor_control_register_map_cfg_timeout_limit[3]),
    .D(motor_control_register_map_cfg_timeout_limit[2]),
    .X(_0904_));
 sky130_fd_sc_hd__or4_2 _1221_ (.A(motor_control_register_map_cfg_timeout_limit[9]),
    .B(motor_control_register_map_cfg_timeout_limit[8]),
    .C(motor_control_register_map_cfg_timeout_limit[11]),
    .D(motor_control_register_map_cfg_timeout_limit[10]),
    .X(_0905_));
 sky130_fd_sc_hd__or4_2 _1222_ (.A(motor_control_register_map_cfg_timeout_limit[13]),
    .B(motor_control_register_map_cfg_timeout_limit[12]),
    .C(motor_control_register_map_cfg_timeout_limit[15]),
    .D(motor_control_register_map_cfg_timeout_limit[14]),
    .X(_0906_));
 sky130_fd_sc_hd__or4_2 _1223_ (.A(_0903_),
    .B(_0904_),
    .C(_0905_),
    .D(_0906_),
    .X(_0907_));
 sky130_fd_sc_hd__o21a_2 _1224_ (.A1(_0891_),
    .A2(_0902_),
    .B1(_0907_),
    .X(_0908_));
 sky130_fd_sc_hd__and2_2 _1225_ (.A(reset_n),
    .B(\u_motor_control_transport_fsm.rsp_ready_next ),
    .X(_0202_));
 sky130_fd_sc_hd__and4bb_2 _1226_ (.A_N(rsp_valid),
    .B_N(_0908_),
    .C(_0857_),
    .D(\u_motor_control_transport_fsm.rsp_ready_next ),
    .X(_0909_));
 sky130_fd_sc_hd__a21o_2 _1227_ (.A1(_0855_),
    .A2(_0857_),
    .B1(_0909_),
    .X(_0006_));
 sky130_fd_sc_hd__a21oi_2 _1228_ (.A1(motor_control_register_map_cfg_enable),
    .A2(_0908_),
    .B1(rsp_valid),
    .Y(_0910_));
 sky130_fd_sc_hd__and2b_2 _1229_ (.A_N(rsp_data[49]),
    .B(\u_motor_control_transport_fsm.seq_reg[1] ),
    .X(_0911_));
 sky130_fd_sc_hd__xor2_2 _1230_ (.A(\u_motor_control_transport_fsm.seq_reg[10] ),
    .B(rsp_data[58]),
    .X(_0912_));
 sky130_fd_sc_hd__and2b_2 _1231_ (.A_N(rsp_data[48]),
    .B(\u_motor_control_transport_fsm.seq_reg[0] ),
    .X(_0913_));
 sky130_fd_sc_hd__and2b_2 _1232_ (.A_N(rsp_data[56]),
    .B(\u_motor_control_transport_fsm.seq_reg[8] ),
    .X(_0914_));
 sky130_fd_sc_hd__and2b_2 _1233_ (.A_N(\u_motor_control_transport_fsm.seq_reg[0] ),
    .B(rsp_data[48]),
    .X(_0915_));
 sky130_fd_sc_hd__a2111o_2 _1234_ (.A1(_0734_),
    .A2(rsp_data[60]),
    .B1(_0913_),
    .C1(_0914_),
    .D1(_0915_),
    .X(_0916_));
 sky130_fd_sc_hd__and2b_2 _1235_ (.A_N(\u_motor_control_transport_fsm.seq_reg[6] ),
    .B(rsp_data[54]),
    .X(_0917_));
 sky130_fd_sc_hd__and2b_2 _1236_ (.A_N(\u_motor_control_transport_fsm.seq_reg[1] ),
    .B(rsp_data[49]),
    .X(_0918_));
 sky130_fd_sc_hd__and2b_2 _1237_ (.A_N(\u_motor_control_transport_fsm.seq_reg[11] ),
    .B(rsp_data[59]),
    .X(_0919_));
 sky130_fd_sc_hd__a2111o_2 _1238_ (.A1(\u_motor_control_transport_fsm.seq_reg[12] ),
    .A2(_0756_),
    .B1(_0917_),
    .C1(_0918_),
    .D1(_0919_),
    .X(_0920_));
 sky130_fd_sc_hd__or4_2 _1239_ (.A(_0911_),
    .B(_0912_),
    .C(_0916_),
    .D(_0920_),
    .X(_0921_));
 sky130_fd_sc_hd__nand2_2 _1240_ (.A(\u_motor_control_transport_fsm.seq_reg[15] ),
    .B(rsp_data[63]),
    .Y(_0922_));
 sky130_fd_sc_hd__or2_2 _1241_ (.A(\u_motor_control_transport_fsm.seq_reg[15] ),
    .B(rsp_data[63]),
    .X(_0923_));
 sky130_fd_sc_hd__or2_2 _1242_ (.A(\u_motor_control_transport_fsm.seq_reg[14] ),
    .B(rsp_data[62]),
    .X(_0924_));
 sky130_fd_sc_hd__nand2_2 _1243_ (.A(\u_motor_control_transport_fsm.seq_reg[14] ),
    .B(rsp_data[62]),
    .Y(_0925_));
 sky130_fd_sc_hd__a22o_2 _1244_ (.A1(_0922_),
    .A2(_0923_),
    .B1(_0924_),
    .B2(_0925_),
    .X(_0926_));
 sky130_fd_sc_hd__nand2_2 _1245_ (.A(\u_motor_control_transport_fsm.seq_reg[7] ),
    .B(rsp_data[55]),
    .Y(_0927_));
 sky130_fd_sc_hd__or2_2 _1246_ (.A(\u_motor_control_transport_fsm.seq_reg[7] ),
    .B(rsp_data[55]),
    .X(_0928_));
 sky130_fd_sc_hd__and2b_2 _1247_ (.A_N(\u_motor_control_transport_fsm.seq_reg[3] ),
    .B(rsp_data[51]),
    .X(_0929_));
 sky130_fd_sc_hd__and2b_2 _1248_ (.A_N(\u_motor_control_transport_fsm.seq_reg[8] ),
    .B(rsp_data[56]),
    .X(_0930_));
 sky130_fd_sc_hd__and2b_2 _1249_ (.A_N(rsp_data[54]),
    .B(\u_motor_control_transport_fsm.seq_reg[6] ),
    .X(_0931_));
 sky130_fd_sc_hd__and2b_2 _1250_ (.A_N(\u_motor_control_transport_fsm.seq_reg[9] ),
    .B(rsp_data[57]),
    .X(_0932_));
 sky130_fd_sc_hd__or4_2 _1251_ (.A(_0929_),
    .B(_0930_),
    .C(_0931_),
    .D(_0932_),
    .X(_0933_));
 sky130_fd_sc_hd__xor2_2 _1252_ (.A(\u_motor_control_transport_fsm.seq_reg[4] ),
    .B(rsp_data[52]),
    .X(_0934_));
 sky130_fd_sc_hd__and2b_2 _1253_ (.A_N(rsp_data[51]),
    .B(\u_motor_control_transport_fsm.seq_reg[3] ),
    .X(_0935_));
 sky130_fd_sc_hd__or3b_2 _1254_ (.A(_0934_),
    .B(_0935_),
    .C_N(rsp_valid),
    .X(_0936_));
 sky130_fd_sc_hd__and2b_2 _1255_ (.A_N(\u_motor_control_transport_fsm.seq_reg[5] ),
    .B(rsp_data[53]),
    .X(_0937_));
 sky130_fd_sc_hd__and2b_2 _1256_ (.A_N(rsp_data[50]),
    .B(\u_motor_control_transport_fsm.seq_reg[2] ),
    .X(_0938_));
 sky130_fd_sc_hd__and2b_2 _1257_ (.A_N(rsp_data[59]),
    .B(\u_motor_control_transport_fsm.seq_reg[11] ),
    .X(_0939_));
 sky130_fd_sc_hd__and2b_2 _1258_ (.A_N(rsp_data[57]),
    .B(\u_motor_control_transport_fsm.seq_reg[9] ),
    .X(_0940_));
 sky130_fd_sc_hd__or4_2 _1259_ (.A(_0937_),
    .B(_0938_),
    .C(_0939_),
    .D(_0940_),
    .X(_0941_));
 sky130_fd_sc_hd__and2b_2 _1260_ (.A_N(\u_motor_control_transport_fsm.seq_reg[2] ),
    .B(rsp_data[50]),
    .X(_0942_));
 sky130_fd_sc_hd__and2b_2 _1261_ (.A_N(rsp_data[61]),
    .B(\u_motor_control_transport_fsm.seq_reg[13] ),
    .X(_0943_));
 sky130_fd_sc_hd__and2b_2 _1262_ (.A_N(rsp_data[53]),
    .B(\u_motor_control_transport_fsm.seq_reg[5] ),
    .X(_0944_));
 sky130_fd_sc_hd__and2b_2 _1263_ (.A_N(\u_motor_control_transport_fsm.seq_reg[13] ),
    .B(rsp_data[61]),
    .X(_0945_));
 sky130_fd_sc_hd__or4_2 _1264_ (.A(_0942_),
    .B(_0943_),
    .C(_0944_),
    .D(_0945_),
    .X(_0946_));
 sky130_fd_sc_hd__or4_2 _1265_ (.A(_0933_),
    .B(_0936_),
    .C(_0941_),
    .D(_0946_),
    .X(_0947_));
 sky130_fd_sc_hd__a2111oi_2 _1266_ (.A1(_0927_),
    .A2(_0928_),
    .B1(_0947_),
    .C1(_0926_),
    .D1(_0921_),
    .Y(_0948_));
 sky130_fd_sc_hd__nor2_2 _1267_ (.A(_0736_),
    .B(rsp_data[55]),
    .Y(_0949_));
 sky130_fd_sc_hd__xor2_2 _1268_ (.A(\u_motor_control_transport_fsm.seq_reg[12] ),
    .B(rsp_data[60]),
    .X(_0950_));
 sky130_fd_sc_hd__or4_2 _1269_ (.A(_0913_),
    .B(_0915_),
    .C(_0931_),
    .D(_0945_),
    .X(_0951_));
 sky130_fd_sc_hd__or4_2 _1270_ (.A(_0911_),
    .B(_0917_),
    .C(_0929_),
    .D(_0939_),
    .X(_0952_));
 sky130_fd_sc_hd__a2111o_2 _1271_ (.A1(_0737_),
    .A2(rsp_data[52]),
    .B1(_0937_),
    .C1(_0942_),
    .D1(_0944_),
    .X(_0953_));
 sky130_fd_sc_hd__a211o_2 _1272_ (.A1(\u_motor_control_transport_fsm.seq_reg[4] ),
    .A2(_0755_),
    .B1(_0952_),
    .C1(_0953_),
    .X(_0954_));
 sky130_fd_sc_hd__or3_2 _1273_ (.A(_0914_),
    .B(_0935_),
    .C(_0954_),
    .X(_0955_));
 sky130_fd_sc_hd__or4b_2 _1274_ (.A(_0918_),
    .B(_0940_),
    .C(_0949_),
    .D_N(rsp_valid),
    .X(_0956_));
 sky130_fd_sc_hd__or4_2 _1275_ (.A(_0919_),
    .B(_0930_),
    .C(_0932_),
    .D(_0938_),
    .X(_0957_));
 sky130_fd_sc_hd__a211o_2 _1276_ (.A1(_0736_),
    .A2(rsp_data[55]),
    .B1(_0912_),
    .C1(_0943_),
    .X(_0958_));
 sky130_fd_sc_hd__or4_2 _1277_ (.A(_0951_),
    .B(_0956_),
    .C(_0957_),
    .D(_0958_),
    .X(_0959_));
 sky130_fd_sc_hd__or4_2 _1278_ (.A(_0926_),
    .B(_0950_),
    .C(_0955_),
    .D(_0959_),
    .X(_0960_));
 sky130_fd_sc_hd__nor2_2 _1279_ (.A(_0910_),
    .B(_0948_),
    .Y(_0961_));
 sky130_fd_sc_hd__or2_2 _1280_ (.A(\u_motor_control_transport_fsm.rsp_ready_next ),
    .B(\u_motor_control_transport_fsm.state[2] ),
    .X(_0962_));
 sky130_fd_sc_hd__nand2_2 _1281_ (.A(motor_control_register_map_cfg_fault_clear),
    .B(motor_control_register_map_cfg_safety_override),
    .Y(_0963_));
 sky130_fd_sc_hd__o21a_2 _1282_ (.A1(_0753_),
    .A2(_0963_),
    .B1(\u_motor_control_transport_fsm.state[4] ),
    .X(_0964_));
 sky130_fd_sc_hd__o211a_2 _1283_ (.A1(_0962_),
    .A2(_0964_),
    .B1(reset_n),
    .C1(_0752_),
    .X(_0965_));
 sky130_fd_sc_hd__a31o_2 _1284_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0857_),
    .A3(_0961_),
    .B1(_0965_),
    .X(_0005_));
 sky130_fd_sc_hd__or2_2 _1285_ (.A(\u_motor_control_transport_fsm.state[3] ),
    .B(\u_motor_control_transport_fsm.state[5] ),
    .X(_0966_));
 sky130_fd_sc_hd__a21o_2 _1286_ (.A1(motor_control_transport_fsm_status_fault_from_u_motor_control_transport_fsm),
    .A2(\u_motor_control_transport_fsm.state[4] ),
    .B1(_0966_),
    .X(_0967_));
 sky130_fd_sc_hd__a311o_2 _1287_ (.A1(motor_control_register_map_cfg_fault_clear),
    .A2(motor_control_register_map_cfg_safety_override),
    .A3(_0967_),
    .B1(\u_motor_control_transport_fsm.state[0] ),
    .C1(\u_motor_control_transport_fsm.state[1] ),
    .X(_0968_));
 sky130_fd_sc_hd__a32o_2 _1288_ (.A1(_0758_),
    .A2(_0857_),
    .A3(_0964_),
    .B1(_0968_),
    .B2(reset_n),
    .X(_0004_));
 sky130_fd_sc_hd__and4b_2 _1289_ (.A_N(req_ready),
    .B(\u_motor_control_transport_fsm.state[2] ),
    .C(reset_n),
    .D(motor_control_register_map_cfg_enable),
    .X(_0969_));
 sky130_fd_sc_hd__a31o_2 _1290_ (.A1(motor_control_register_map_cfg_start),
    .A2(_0857_),
    .A3(_0964_),
    .B1(_0969_),
    .X(_0002_));
 sky130_fd_sc_hd__and3_2 _1291_ (.A(reset_n),
    .B(_0963_),
    .C(_0966_),
    .X(_0003_));
 sky130_fd_sc_hd__or2_2 _1292_ (.A(reg_addr[2]),
    .B(reg_addr[3]),
    .X(_0970_));
 sky130_fd_sc_hd__or4b_2 _1293_ (.A(reg_addr[5]),
    .B(reg_addr[7]),
    .C(reg_addr[6]),
    .D_N(reg_addr[4]),
    .X(_0971_));
 sky130_fd_sc_hd__nor2_2 _1294_ (.A(_0970_),
    .B(_0971_),
    .Y(_0972_));
 sky130_fd_sc_hd__and3b_2 _1295_ (.A_N(reg_addr[1]),
    .B(reg_addr[0]),
    .C(_0972_),
    .X(_0973_));
 sky130_fd_sc_hd__and3b_2 _1296_ (.A_N(reg_addr[0]),
    .B(_0972_),
    .C(reg_addr[1]),
    .X(_0974_));
 sky130_fd_sc_hd__a22o_2 _1297_ (.A1(motor_control_transport_fsm_status_last_seq[8]),
    .A2(_0973_),
    .B1(_0974_),
    .B2(motor_control_transport_fsm_status_busy),
    .X(_0975_));
 sky130_fd_sc_hd__nor4_2 _1298_ (.A(reg_addr[1]),
    .B(reg_addr[0]),
    .C(_0970_),
    .D(_0971_),
    .Y(_0976_));
 sky130_fd_sc_hd__or4_2 _1299_ (.A(reg_addr[5]),
    .B(reg_addr[4]),
    .C(reg_addr[7]),
    .D(reg_addr[6]),
    .X(_0977_));
 sky130_fd_sc_hd__or3b_2 _1300_ (.A(_0977_),
    .B(reg_addr[1]),
    .C_N(reg_addr[0]),
    .X(_0978_));
 sky130_fd_sc_hd__nand2_2 _1301_ (.A(reg_addr[2]),
    .B(reg_addr[3]),
    .Y(_0979_));
 sky130_fd_sc_hd__nor2_2 _1302_ (.A(_0978_),
    .B(_0979_),
    .Y(_0980_));
 sky130_fd_sc_hd__nand2b_2 _1303_ (.A_N(reg_addr[2]),
    .B(reg_addr[3]),
    .Y(_0981_));
 sky130_fd_sc_hd__or3_2 _1304_ (.A(reg_addr[1]),
    .B(reg_addr[0]),
    .C(_0977_),
    .X(_0982_));
 sky130_fd_sc_hd__nor2_2 _1305_ (.A(_0981_),
    .B(_0982_),
    .Y(_0983_));
 sky130_fd_sc_hd__nand2b_2 _1306_ (.A_N(reg_addr[3]),
    .B(reg_addr[2]),
    .Y(_0984_));
 sky130_fd_sc_hd__nor2_2 _1307_ (.A(_0978_),
    .B(_0984_),
    .Y(_0985_));
 sky130_fd_sc_hd__nor2_2 _1308_ (.A(_0970_),
    .B(_0982_),
    .Y(_0986_));
 sky130_fd_sc_hd__nor2_2 _1309_ (.A(_0982_),
    .B(_0984_),
    .Y(_0987_));
 sky130_fd_sc_hd__nor2_2 _1310_ (.A(_0970_),
    .B(_0978_),
    .Y(_0988_));
 sky130_fd_sc_hd__nand2_2 _1311_ (.A(reg_addr[1]),
    .B(reg_addr[0]),
    .Y(_0989_));
 sky130_fd_sc_hd__or2_2 _1312_ (.A(_0977_),
    .B(_0989_),
    .X(_0990_));
 sky130_fd_sc_hd__nor2_2 _1313_ (.A(_0970_),
    .B(_0990_),
    .Y(_0991_));
 sky130_fd_sc_hd__nor2_2 _1314_ (.A(_0979_),
    .B(_0982_),
    .Y(_0992_));
 sky130_fd_sc_hd__or3b_2 _1315_ (.A(reg_addr[0]),
    .B(_0977_),
    .C_N(reg_addr[1]),
    .X(_0993_));
 sky130_fd_sc_hd__nor2_2 _1316_ (.A(_0979_),
    .B(_0993_),
    .Y(_0994_));
 sky130_fd_sc_hd__nor2_2 _1317_ (.A(_0978_),
    .B(_0981_),
    .Y(_0995_));
 sky130_fd_sc_hd__nor2_2 _1318_ (.A(_0984_),
    .B(_0990_),
    .Y(_0996_));
 sky130_fd_sc_hd__nor2_2 _1319_ (.A(_0970_),
    .B(_0993_),
    .Y(_0997_));
 sky130_fd_sc_hd__nor2_2 _1320_ (.A(_0981_),
    .B(_0993_),
    .Y(_0998_));
 sky130_fd_sc_hd__nor2_2 _1321_ (.A(_0984_),
    .B(_0993_),
    .Y(_0999_));
 sky130_fd_sc_hd__a22o_2 _1322_ (.A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[16] ),
    .A2(_0998_),
    .B1(_0999_),
    .B2(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[16] ),
    .X(_1000_));
 sky130_fd_sc_hd__nor2_2 _1323_ (.A(_0981_),
    .B(_0990_),
    .Y(_1001_));
 sky130_fd_sc_hd__nor2_2 _1324_ (.A(_0979_),
    .B(_0990_),
    .Y(_1002_));
 sky130_fd_sc_hd__a22o_2 _1325_ (.A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[0] ),
    .A2(_0983_),
    .B1(_0994_),
    .B2(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[16] ),
    .X(_1003_));
 sky130_fd_sc_hd__a221o_2 _1326_ (.A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[8] ),
    .A2(_0995_),
    .B1(_0997_),
    .B2(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[8] ),
    .C1(_1003_),
    .X(_1004_));
 sky130_fd_sc_hd__a22o_2 _1327_ (.A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[8] ),
    .A2(_0985_),
    .B1(_0996_),
    .B2(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[24] ),
    .X(_1005_));
 sky130_fd_sc_hd__a22o_2 _1328_ (.A1(motor_control_register_map_cfg_enable_from_u_motor_control_register_map),
    .A2(_0986_),
    .B1(_0992_),
    .B2(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[0] ),
    .X(_1006_));
 sky130_fd_sc_hd__a221o_2 _1329_ (.A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[0] ),
    .A2(_0987_),
    .B1(_0988_),
    .B2(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[0] ),
    .C1(_1006_),
    .X(_1007_));
 sky130_fd_sc_hd__a221o_2 _1330_ (.A1(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[8] ),
    .A2(_0991_),
    .B1(_1001_),
    .B2(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[24] ),
    .C1(_1000_),
    .X(_1008_));
 sky130_fd_sc_hd__a221o_2 _1331_ (.A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[8] ),
    .A2(_0980_),
    .B1(_1002_),
    .B2(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[24] ),
    .C1(_1005_),
    .X(_1009_));
 sky130_fd_sc_hd__a2111o_2 _1332_ (.A1(motor_control_transport_fsm_status_last_seq[0]),
    .A2(_0976_),
    .B1(_1004_),
    .C1(_1007_),
    .D1(_0975_),
    .X(_1010_));
 sky130_fd_sc_hd__o31a_2 _1333_ (.A1(_1008_),
    .A2(_1009_),
    .A3(_1010_),
    .B1(reg_cs),
    .X(reg_rdata[0]));
 sky130_fd_sc_hd__a22o_2 _1334_ (.A1(motor_control_transport_fsm_status_last_seq[9]),
    .A2(_0973_),
    .B1(_0974_),
    .B2(motor_control_transport_fsm_status_timeout),
    .X(_1011_));
 sky130_fd_sc_hd__a22o_2 _1335_ (.A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[1] ),
    .A2(_0983_),
    .B1(_0992_),
    .B2(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[1] ),
    .X(_1012_));
 sky130_fd_sc_hd__a221o_2 _1336_ (.A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[9] ),
    .A2(_0985_),
    .B1(_1002_),
    .B2(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[25] ),
    .C1(_1012_),
    .X(_1013_));
 sky130_fd_sc_hd__a22o_2 _1337_ (.A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[17] ),
    .A2(_0994_),
    .B1(_0995_),
    .B2(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[9] ),
    .X(_1014_));
 sky130_fd_sc_hd__a221o_2 _1338_ (.A1(motor_control_transport_fsm_status_last_seq[1]),
    .A2(_0976_),
    .B1(_0998_),
    .B2(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[17] ),
    .C1(_1011_),
    .X(_1015_));
 sky130_fd_sc_hd__a211o_2 _1339_ (.A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[25] ),
    .A2(_0996_),
    .B1(_1014_),
    .C1(_1015_),
    .X(_1016_));
 sky130_fd_sc_hd__a22o_2 _1340_ (.A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[1] ),
    .A2(_0987_),
    .B1(_1001_),
    .B2(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[25] ),
    .X(_1017_));
 sky130_fd_sc_hd__a22o_2 _1341_ (.A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[9] ),
    .A2(_0980_),
    .B1(_0999_),
    .B2(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[17] ),
    .X(_1018_));
 sky130_fd_sc_hd__a221o_2 _1342_ (.A1(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[1] ),
    .A2(_0988_),
    .B1(_0991_),
    .B2(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[9] ),
    .C1(_1018_),
    .X(_1019_));
 sky130_fd_sc_hd__a211o_2 _1343_ (.A1(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[9] ),
    .A2(_0997_),
    .B1(_1017_),
    .C1(_1019_),
    .X(_1020_));
 sky130_fd_sc_hd__o31a_2 _1344_ (.A1(_1013_),
    .A2(_1016_),
    .A3(_1020_),
    .B1(reg_cs),
    .X(reg_rdata[1]));
 sky130_fd_sc_hd__and2_2 _1345_ (.A(motor_control_transport_fsm_status_last_seq[2]),
    .B(_0976_),
    .X(_1021_));
 sky130_fd_sc_hd__a221o_2 _1346_ (.A1(motor_control_transport_fsm_status_last_seq[10]),
    .A2(_0973_),
    .B1(_0974_),
    .B2(motor_control_transport_fsm_status_stale_reject),
    .C1(_1021_),
    .X(_1022_));
 sky130_fd_sc_hd__a22o_2 _1347_ (.A1(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[2] ),
    .A2(_0988_),
    .B1(_0994_),
    .B2(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[18] ),
    .X(_1023_));
 sky130_fd_sc_hd__a22o_2 _1348_ (.A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[2] ),
    .A2(_0987_),
    .B1(_0999_),
    .B2(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[18] ),
    .X(_1024_));
 sky130_fd_sc_hd__a221o_2 _1349_ (.A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[10] ),
    .A2(_0985_),
    .B1(_1001_),
    .B2(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[26] ),
    .C1(_1023_),
    .X(_1025_));
 sky130_fd_sc_hd__a22o_2 _1350_ (.A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[10] ),
    .A2(_0995_),
    .B1(_0996_),
    .B2(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[26] ),
    .X(_1026_));
 sky130_fd_sc_hd__a221o_2 _1351_ (.A1(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[10] ),
    .A2(_0991_),
    .B1(_0998_),
    .B2(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[18] ),
    .C1(_1026_),
    .X(_1027_));
 sky130_fd_sc_hd__a221o_2 _1352_ (.A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[10] ),
    .A2(_0980_),
    .B1(_0983_),
    .B2(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[2] ),
    .C1(_1024_),
    .X(_1028_));
 sky130_fd_sc_hd__a211o_2 _1353_ (.A1(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[10] ),
    .A2(_0997_),
    .B1(_1027_),
    .C1(_1028_),
    .X(_1029_));
 sky130_fd_sc_hd__a221o_2 _1354_ (.A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[2] ),
    .A2(_0992_),
    .B1(_1002_),
    .B2(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[26] ),
    .C1(_1029_),
    .X(_1030_));
 sky130_fd_sc_hd__o31a_2 _1355_ (.A1(_1022_),
    .A2(_1025_),
    .A3(_1030_),
    .B1(reg_cs),
    .X(reg_rdata[2]));
 sky130_fd_sc_hd__a22o_2 _1356_ (.A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[11] ),
    .A2(_0985_),
    .B1(_0992_),
    .B2(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[3] ),
    .X(_1031_));
 sky130_fd_sc_hd__a22o_2 _1357_ (.A1(motor_control_register_map_cfg_safety_override_from_u_motor_control_register_map),
    .A2(_0986_),
    .B1(_1001_),
    .B2(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[27] ),
    .X(_1032_));
 sky130_fd_sc_hd__a22o_2 _1358_ (.A1(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[3] ),
    .A2(_0988_),
    .B1(_0995_),
    .B2(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[11] ),
    .X(_1033_));
 sky130_fd_sc_hd__a22o_2 _1359_ (.A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[19] ),
    .A2(_0994_),
    .B1(_0999_),
    .B2(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[19] ),
    .X(_1034_));
 sky130_fd_sc_hd__a221o_2 _1360_ (.A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[11] ),
    .A2(_0980_),
    .B1(_0998_),
    .B2(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[19] ),
    .C1(_1034_),
    .X(_1035_));
 sky130_fd_sc_hd__a221o_2 _1361_ (.A1(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[11] ),
    .A2(_0991_),
    .B1(_0996_),
    .B2(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[27] ),
    .C1(_1031_),
    .X(_1036_));
 sky130_fd_sc_hd__a221o_2 _1362_ (.A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[3] ),
    .A2(_0983_),
    .B1(_1002_),
    .B2(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[27] ),
    .C1(_1033_),
    .X(_1037_));
 sky130_fd_sc_hd__a221o_2 _1363_ (.A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[3] ),
    .A2(_0987_),
    .B1(_0997_),
    .B2(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[11] ),
    .C1(_1032_),
    .X(_1038_));
 sky130_fd_sc_hd__a22o_2 _1364_ (.A1(motor_control_transport_fsm_status_rsp_valid),
    .A2(_0974_),
    .B1(_0976_),
    .B2(motor_control_transport_fsm_status_last_seq[3]),
    .X(_1039_));
 sky130_fd_sc_hd__a2111o_2 _1365_ (.A1(motor_control_transport_fsm_status_last_seq[11]),
    .A2(_0973_),
    .B1(_1035_),
    .C1(_1038_),
    .D1(_1039_),
    .X(_1040_));
 sky130_fd_sc_hd__o31a_2 _1366_ (.A1(_1036_),
    .A2(_1037_),
    .A3(_1040_),
    .B1(reg_cs),
    .X(reg_rdata[3]));
 sky130_fd_sc_hd__a22o_2 _1367_ (.A1(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[4] ),
    .A2(_0988_),
    .B1(_0999_),
    .B2(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[20] ),
    .X(_1041_));
 sky130_fd_sc_hd__a221o_2 _1368_ (.A1(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[12] ),
    .A2(_0991_),
    .B1(_1001_),
    .B2(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[28] ),
    .C1(_1041_),
    .X(_1042_));
 sky130_fd_sc_hd__a22o_2 _1369_ (.A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[20] ),
    .A2(_0994_),
    .B1(_0997_),
    .B2(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[12] ),
    .X(_1043_));
 sky130_fd_sc_hd__a221o_2 _1370_ (.A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[4] ),
    .A2(_0992_),
    .B1(_0996_),
    .B2(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[28] ),
    .C1(_1043_),
    .X(_1044_));
 sky130_fd_sc_hd__a22o_2 _1371_ (.A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[12] ),
    .A2(_0980_),
    .B1(_0987_),
    .B2(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[4] ),
    .X(_1045_));
 sky130_fd_sc_hd__a22o_2 _1372_ (.A1(motor_control_transport_fsm_status_last_seq[12]),
    .A2(_0973_),
    .B1(_0974_),
    .B2(motor_control_transport_fsm_status_fallback_active),
    .X(_1046_));
 sky130_fd_sc_hd__a22o_2 _1373_ (.A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[12] ),
    .A2(_0995_),
    .B1(_1002_),
    .B2(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[28] ),
    .X(_1047_));
 sky130_fd_sc_hd__a221o_2 _1374_ (.A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[4] ),
    .A2(_0983_),
    .B1(_0998_),
    .B2(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[20] ),
    .C1(_1047_),
    .X(_1048_));
 sky130_fd_sc_hd__a211o_2 _1375_ (.A1(motor_control_transport_fsm_status_last_seq[4]),
    .A2(_0976_),
    .B1(_1046_),
    .C1(_1048_),
    .X(_0256_));
 sky130_fd_sc_hd__a211o_2 _1376_ (.A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[12] ),
    .A2(_0985_),
    .B1(_1045_),
    .C1(_0256_),
    .X(_0257_));
 sky130_fd_sc_hd__o31a_2 _1377_ (.A1(_1042_),
    .A2(_1044_),
    .A3(_0257_),
    .B1(reg_cs),
    .X(reg_rdata[4]));
 sky130_fd_sc_hd__a22o_2 _1378_ (.A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[5] ),
    .A2(_0987_),
    .B1(_0997_),
    .B2(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[13] ),
    .X(_0258_));
 sky130_fd_sc_hd__a221o_2 _1379_ (.A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[13] ),
    .A2(_0995_),
    .B1(_1002_),
    .B2(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[29] ),
    .C1(_0258_),
    .X(_0259_));
 sky130_fd_sc_hd__a22o_2 _1380_ (.A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[13] ),
    .A2(_0980_),
    .B1(_0991_),
    .B2(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[13] ),
    .X(_0260_));
 sky130_fd_sc_hd__a221o_2 _1381_ (.A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[21] ),
    .A2(_0994_),
    .B1(_1001_),
    .B2(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[29] ),
    .C1(_0260_),
    .X(_0261_));
 sky130_fd_sc_hd__a22o_2 _1382_ (.A1(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[5] ),
    .A2(_0988_),
    .B1(_0996_),
    .B2(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[29] ),
    .X(_0262_));
 sky130_fd_sc_hd__a22o_2 _1383_ (.A1(motor_control_transport_fsm_status_fault),
    .A2(_0974_),
    .B1(_0976_),
    .B2(motor_control_transport_fsm_status_last_seq[5]),
    .X(_0263_));
 sky130_fd_sc_hd__a22o_2 _1384_ (.A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[5] ),
    .A2(_0992_),
    .B1(_0998_),
    .B2(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[21] ),
    .X(_0264_));
 sky130_fd_sc_hd__a221o_2 _1385_ (.A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[13] ),
    .A2(_0985_),
    .B1(_0999_),
    .B2(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[21] ),
    .C1(_0264_),
    .X(_0265_));
 sky130_fd_sc_hd__a211o_2 _1386_ (.A1(motor_control_transport_fsm_status_last_seq[13]),
    .A2(_0973_),
    .B1(_0263_),
    .C1(_0265_),
    .X(_0266_));
 sky130_fd_sc_hd__a211o_2 _1387_ (.A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[5] ),
    .A2(_0983_),
    .B1(_0262_),
    .C1(_0266_),
    .X(_0267_));
 sky130_fd_sc_hd__o31a_2 _1388_ (.A1(_0259_),
    .A2(_0261_),
    .A3(_0267_),
    .B1(reg_cs),
    .X(reg_rdata[5]));
 sky130_fd_sc_hd__a22o_2 _1389_ (.A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[22] ),
    .A2(_0999_),
    .B1(_1002_),
    .B2(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[30] ),
    .X(_0268_));
 sky130_fd_sc_hd__a22o_2 _1390_ (.A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[14] ),
    .A2(_0980_),
    .B1(_0988_),
    .B2(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[6] ),
    .X(_0269_));
 sky130_fd_sc_hd__a221o_2 _1391_ (.A1(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[14] ),
    .A2(_0997_),
    .B1(_0998_),
    .B2(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[22] ),
    .C1(_0269_),
    .X(_0270_));
 sky130_fd_sc_hd__a22o_2 _1392_ (.A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[6] ),
    .A2(_0983_),
    .B1(_1001_),
    .B2(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[30] ),
    .X(_0271_));
 sky130_fd_sc_hd__a221o_2 _1393_ (.A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[14] ),
    .A2(_0985_),
    .B1(_0991_),
    .B2(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[14] ),
    .C1(_0271_),
    .X(_0272_));
 sky130_fd_sc_hd__a22o_2 _1394_ (.A1(motor_control_transport_fsm_status_last_seq[6]),
    .A2(_0976_),
    .B1(_0992_),
    .B2(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[6] ),
    .X(_0273_));
 sky130_fd_sc_hd__a22o_2 _1395_ (.A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[22] ),
    .A2(_0994_),
    .B1(_0995_),
    .B2(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[14] ),
    .X(_0274_));
 sky130_fd_sc_hd__a2111o_2 _1396_ (.A1(motor_control_transport_fsm_status_last_seq[14]),
    .A2(_0973_),
    .B1(_0272_),
    .C1(_0273_),
    .D1(_0274_),
    .X(_0275_));
 sky130_fd_sc_hd__a221o_2 _1397_ (.A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[6] ),
    .A2(_0987_),
    .B1(_0996_),
    .B2(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[30] ),
    .C1(_0268_),
    .X(_0276_));
 sky130_fd_sc_hd__o31a_2 _1398_ (.A1(_0270_),
    .A2(_0275_),
    .A3(_0276_),
    .B1(reg_cs),
    .X(reg_rdata[6]));
 sky130_fd_sc_hd__a22o_2 _1399_ (.A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[7] ),
    .A2(_0987_),
    .B1(_1001_),
    .B2(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[31] ),
    .X(_0277_));
 sky130_fd_sc_hd__a22o_2 _1400_ (.A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[15] ),
    .A2(_0980_),
    .B1(_0998_),
    .B2(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[23] ),
    .X(_0278_));
 sky130_fd_sc_hd__a22o_2 _1401_ (.A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[15] ),
    .A2(_0985_),
    .B1(_0999_),
    .B2(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[23] ),
    .X(_0279_));
 sky130_fd_sc_hd__a221o_2 _1402_ (.A1(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[7] ),
    .A2(_0988_),
    .B1(_1002_),
    .B2(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[31] ),
    .C1(_0277_),
    .X(_0280_));
 sky130_fd_sc_hd__a22o_2 _1403_ (.A1(motor_control_transport_fsm_status_last_seq[7]),
    .A2(_0976_),
    .B1(_0983_),
    .B2(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[7] ),
    .X(_0281_));
 sky130_fd_sc_hd__a22o_2 _1404_ (.A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[23] ),
    .A2(_0994_),
    .B1(_0995_),
    .B2(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[15] ),
    .X(_0282_));
 sky130_fd_sc_hd__a2111o_2 _1405_ (.A1(motor_control_transport_fsm_status_last_seq[15]),
    .A2(_0973_),
    .B1(_0280_),
    .C1(_0281_),
    .D1(_0282_),
    .X(_0283_));
 sky130_fd_sc_hd__a221o_2 _1406_ (.A1(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[15] ),
    .A2(_0991_),
    .B1(_0992_),
    .B2(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[7] ),
    .C1(_0279_),
    .X(_0284_));
 sky130_fd_sc_hd__a221o_2 _1407_ (.A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[31] ),
    .A2(_0996_),
    .B1(_0997_),
    .B2(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[15] ),
    .C1(_0278_),
    .X(_0285_));
 sky130_fd_sc_hd__o31a_2 _1408_ (.A1(_0283_),
    .A2(_0284_),
    .A3(_0285_),
    .B1(reg_cs),
    .X(reg_rdata[7]));
 sky130_fd_sc_hd__and3_2 _1409_ (.A(reg_cs),
    .B(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[0] ),
    .C(_0997_),
    .X(reg_rdata[8]));
 sky130_fd_sc_hd__and3_2 _1410_ (.A(reg_cs),
    .B(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[1] ),
    .C(_0997_),
    .X(reg_rdata[9]));
 sky130_fd_sc_hd__and3_2 _1411_ (.A(reg_cs),
    .B(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[2] ),
    .C(_0997_),
    .X(reg_rdata[10]));
 sky130_fd_sc_hd__and3_2 _1412_ (.A(reg_cs),
    .B(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[3] ),
    .C(_0997_),
    .X(reg_rdata[11]));
 sky130_fd_sc_hd__and3_2 _1413_ (.A(reg_cs),
    .B(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[4] ),
    .C(_0997_),
    .X(reg_rdata[12]));
 sky130_fd_sc_hd__and3_2 _1414_ (.A(reg_cs),
    .B(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[5] ),
    .C(_0997_),
    .X(reg_rdata[13]));
 sky130_fd_sc_hd__and3_2 _1415_ (.A(reg_cs),
    .B(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[6] ),
    .C(_0997_),
    .X(reg_rdata[14]));
 sky130_fd_sc_hd__and3_2 _1416_ (.A(reg_cs),
    .B(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[7] ),
    .C(_0997_),
    .X(reg_rdata[15]));
 sky130_fd_sc_hd__and3_2 _1417_ (.A(\u_motor_control_transport_fsm.rsp_ready_next ),
    .B(_0857_),
    .C(_0948_),
    .X(_0000_));
 sky130_fd_sc_hd__and3_2 _1418_ (.A(reset_n),
    .B(reg_we),
    .C(reg_cs),
    .X(_0286_));
 sky130_fd_sc_hd__nand2_2 _1419_ (.A(_0983_),
    .B(_0286_),
    .Y(_0287_));
 sky130_fd_sc_hd__mux2_1 _1420_ (.A0(reg_wdata[0]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[0] ),
    .S(_0287_),
    .X(_0007_));
 sky130_fd_sc_hd__mux2_1 _1421_ (.A0(reg_wdata[1]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[1] ),
    .S(_0287_),
    .X(_0008_));
 sky130_fd_sc_hd__mux2_1 _1422_ (.A0(reg_wdata[2]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[2] ),
    .S(_0287_),
    .X(_0009_));
 sky130_fd_sc_hd__mux2_1 _1423_ (.A0(reg_wdata[3]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[3] ),
    .S(_0287_),
    .X(_0010_));
 sky130_fd_sc_hd__mux2_1 _1424_ (.A0(reg_wdata[4]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[4] ),
    .S(_0287_),
    .X(_0011_));
 sky130_fd_sc_hd__mux2_1 _1425_ (.A0(reg_wdata[5]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[5] ),
    .S(_0287_),
    .X(_0012_));
 sky130_fd_sc_hd__mux2_1 _1426_ (.A0(reg_wdata[6]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[6] ),
    .S(_0287_),
    .X(_0013_));
 sky130_fd_sc_hd__mux2_1 _1427_ (.A0(reg_wdata[7]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[7] ),
    .S(_0287_),
    .X(_0014_));
 sky130_fd_sc_hd__nand2_2 _1428_ (.A(_0987_),
    .B(_0286_),
    .Y(_0288_));
 sky130_fd_sc_hd__mux2_1 _1429_ (.A0(reg_wdata[0]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[0] ),
    .S(_0288_),
    .X(_0015_));
 sky130_fd_sc_hd__mux2_1 _1430_ (.A0(reg_wdata[1]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[1] ),
    .S(_0288_),
    .X(_0016_));
 sky130_fd_sc_hd__mux2_1 _1431_ (.A0(reg_wdata[2]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[2] ),
    .S(_0288_),
    .X(_0017_));
 sky130_fd_sc_hd__mux2_1 _1432_ (.A0(reg_wdata[3]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[3] ),
    .S(_0288_),
    .X(_0018_));
 sky130_fd_sc_hd__mux2_1 _1433_ (.A0(reg_wdata[4]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[4] ),
    .S(_0288_),
    .X(_0019_));
 sky130_fd_sc_hd__mux2_1 _1434_ (.A0(reg_wdata[5]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[5] ),
    .S(_0288_),
    .X(_0020_));
 sky130_fd_sc_hd__mux2_1 _1435_ (.A0(reg_wdata[6]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[6] ),
    .S(_0288_),
    .X(_0021_));
 sky130_fd_sc_hd__mux2_1 _1436_ (.A0(reg_wdata[7]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[7] ),
    .S(_0288_),
    .X(_0022_));
 sky130_fd_sc_hd__and3_2 _1437_ (.A(reg_we),
    .B(reg_cs),
    .C(_0986_),
    .X(_0289_));
 sky130_fd_sc_hd__mux2_1 _1438_ (.A0(motor_control_register_map_cfg_enable_from_u_motor_control_register_map),
    .A1(reg_wdata[0]),
    .S(_0289_),
    .X(_0023_));
 sky130_fd_sc_hd__nand2_2 _1439_ (.A(_0997_),
    .B(_0286_),
    .Y(_0290_));
 sky130_fd_sc_hd__mux2_1 _1440_ (.A0(reg_wdata[8]),
    .A1(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[0] ),
    .S(_0290_),
    .X(_0024_));
 sky130_fd_sc_hd__mux2_1 _1441_ (.A0(reg_wdata[9]),
    .A1(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[1] ),
    .S(_0290_),
    .X(_0025_));
 sky130_fd_sc_hd__mux2_1 _1442_ (.A0(reg_wdata[10]),
    .A1(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[2] ),
    .S(_0290_),
    .X(_0026_));
 sky130_fd_sc_hd__mux2_1 _1443_ (.A0(reg_wdata[11]),
    .A1(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[3] ),
    .S(_0290_),
    .X(_0027_));
 sky130_fd_sc_hd__mux2_1 _1444_ (.A0(reg_wdata[12]),
    .A1(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[4] ),
    .S(_0290_),
    .X(_0028_));
 sky130_fd_sc_hd__mux2_1 _1445_ (.A0(reg_wdata[13]),
    .A1(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[5] ),
    .S(_0290_),
    .X(_0029_));
 sky130_fd_sc_hd__mux2_1 _1446_ (.A0(reg_wdata[14]),
    .A1(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[6] ),
    .S(_0290_),
    .X(_0030_));
 sky130_fd_sc_hd__mux2_1 _1447_ (.A0(reg_wdata[15]),
    .A1(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[7] ),
    .S(_0290_),
    .X(_0031_));
 sky130_fd_sc_hd__nand2_2 _1448_ (.A(_0988_),
    .B(_0286_),
    .Y(_0291_));
 sky130_fd_sc_hd__mux2_1 _1449_ (.A0(reg_wdata[0]),
    .A1(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[0] ),
    .S(_0291_),
    .X(_0032_));
 sky130_fd_sc_hd__mux2_1 _1450_ (.A0(reg_wdata[1]),
    .A1(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[1] ),
    .S(_0291_),
    .X(_0033_));
 sky130_fd_sc_hd__mux2_1 _1451_ (.A0(reg_wdata[2]),
    .A1(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[2] ),
    .S(_0291_),
    .X(_0034_));
 sky130_fd_sc_hd__mux2_1 _1452_ (.A0(reg_wdata[3]),
    .A1(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[3] ),
    .S(_0291_),
    .X(_0035_));
 sky130_fd_sc_hd__mux2_1 _1453_ (.A0(reg_wdata[4]),
    .A1(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[4] ),
    .S(_0291_),
    .X(_0036_));
 sky130_fd_sc_hd__mux2_1 _1454_ (.A0(reg_wdata[5]),
    .A1(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[5] ),
    .S(_0291_),
    .X(_0037_));
 sky130_fd_sc_hd__mux2_1 _1455_ (.A0(reg_wdata[6]),
    .A1(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[6] ),
    .S(_0291_),
    .X(_0038_));
 sky130_fd_sc_hd__mux2_1 _1456_ (.A0(reg_wdata[7]),
    .A1(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[7] ),
    .S(_0291_),
    .X(_0039_));
 sky130_fd_sc_hd__nand2_2 _1457_ (.A(_0992_),
    .B(_0286_),
    .Y(_0292_));
 sky130_fd_sc_hd__mux2_1 _1458_ (.A0(reg_wdata[0]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[0] ),
    .S(_0292_),
    .X(_0040_));
 sky130_fd_sc_hd__mux2_1 _1459_ (.A0(reg_wdata[1]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[1] ),
    .S(_0292_),
    .X(_0041_));
 sky130_fd_sc_hd__mux2_1 _1460_ (.A0(reg_wdata[2]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[2] ),
    .S(_0292_),
    .X(_0042_));
 sky130_fd_sc_hd__mux2_1 _1461_ (.A0(reg_wdata[3]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[3] ),
    .S(_0292_),
    .X(_0043_));
 sky130_fd_sc_hd__mux2_1 _1462_ (.A0(reg_wdata[4]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[4] ),
    .S(_0292_),
    .X(_0044_));
 sky130_fd_sc_hd__mux2_1 _1463_ (.A0(reg_wdata[5]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[5] ),
    .S(_0292_),
    .X(_0045_));
 sky130_fd_sc_hd__mux2_1 _1464_ (.A0(reg_wdata[6]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[6] ),
    .S(_0292_),
    .X(_0046_));
 sky130_fd_sc_hd__mux2_1 _1465_ (.A0(reg_wdata[7]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[7] ),
    .S(_0292_),
    .X(_0047_));
 sky130_fd_sc_hd__mux2_1 _1466_ (.A0(reg_wdata[0]),
    .A1(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[8] ),
    .S(_0290_),
    .X(_0048_));
 sky130_fd_sc_hd__mux2_1 _1467_ (.A0(reg_wdata[1]),
    .A1(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[9] ),
    .S(_0290_),
    .X(_0049_));
 sky130_fd_sc_hd__mux2_1 _1468_ (.A0(reg_wdata[2]),
    .A1(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[10] ),
    .S(_0290_),
    .X(_0050_));
 sky130_fd_sc_hd__mux2_1 _1469_ (.A0(reg_wdata[3]),
    .A1(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[11] ),
    .S(_0290_),
    .X(_0051_));
 sky130_fd_sc_hd__mux2_1 _1470_ (.A0(reg_wdata[4]),
    .A1(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[12] ),
    .S(_0290_),
    .X(_0052_));
 sky130_fd_sc_hd__mux2_1 _1471_ (.A0(reg_wdata[5]),
    .A1(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[13] ),
    .S(_0290_),
    .X(_0053_));
 sky130_fd_sc_hd__mux2_1 _1472_ (.A0(reg_wdata[6]),
    .A1(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[14] ),
    .S(_0290_),
    .X(_0054_));
 sky130_fd_sc_hd__mux2_1 _1473_ (.A0(reg_wdata[7]),
    .A1(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[15] ),
    .S(_0290_),
    .X(_0055_));
 sky130_fd_sc_hd__nand2_2 _1474_ (.A(_0991_),
    .B(_0286_),
    .Y(_0293_));
 sky130_fd_sc_hd__mux2_1 _1475_ (.A0(reg_wdata[0]),
    .A1(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[8] ),
    .S(_0293_),
    .X(_0056_));
 sky130_fd_sc_hd__mux2_1 _1476_ (.A0(reg_wdata[1]),
    .A1(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[9] ),
    .S(_0293_),
    .X(_0057_));
 sky130_fd_sc_hd__mux2_1 _1477_ (.A0(reg_wdata[2]),
    .A1(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[10] ),
    .S(_0293_),
    .X(_0058_));
 sky130_fd_sc_hd__mux2_1 _1478_ (.A0(reg_wdata[3]),
    .A1(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[11] ),
    .S(_0293_),
    .X(_0059_));
 sky130_fd_sc_hd__mux2_1 _1479_ (.A0(reg_wdata[4]),
    .A1(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[12] ),
    .S(_0293_),
    .X(_0060_));
 sky130_fd_sc_hd__mux2_1 _1480_ (.A0(reg_wdata[5]),
    .A1(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[13] ),
    .S(_0293_),
    .X(_0061_));
 sky130_fd_sc_hd__mux2_1 _1481_ (.A0(reg_wdata[6]),
    .A1(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[14] ),
    .S(_0293_),
    .X(_0062_));
 sky130_fd_sc_hd__mux2_1 _1482_ (.A0(reg_wdata[7]),
    .A1(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[15] ),
    .S(_0293_),
    .X(_0063_));
 sky130_fd_sc_hd__nand2_2 _1483_ (.A(_0996_),
    .B(_0286_),
    .Y(_0294_));
 sky130_fd_sc_hd__mux2_1 _1484_ (.A0(reg_wdata[0]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[24] ),
    .S(_0294_),
    .X(_0064_));
 sky130_fd_sc_hd__mux2_1 _1485_ (.A0(reg_wdata[1]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[25] ),
    .S(_0294_),
    .X(_0065_));
 sky130_fd_sc_hd__mux2_1 _1486_ (.A0(reg_wdata[2]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[26] ),
    .S(_0294_),
    .X(_0066_));
 sky130_fd_sc_hd__mux2_1 _1487_ (.A0(reg_wdata[3]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[27] ),
    .S(_0294_),
    .X(_0067_));
 sky130_fd_sc_hd__mux2_1 _1488_ (.A0(reg_wdata[4]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[28] ),
    .S(_0294_),
    .X(_0068_));
 sky130_fd_sc_hd__mux2_1 _1489_ (.A0(reg_wdata[5]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[29] ),
    .S(_0294_),
    .X(_0069_));
 sky130_fd_sc_hd__mux2_1 _1490_ (.A0(reg_wdata[6]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[30] ),
    .S(_0294_),
    .X(_0070_));
 sky130_fd_sc_hd__mux2_1 _1491_ (.A0(reg_wdata[7]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[31] ),
    .S(_0294_),
    .X(_0071_));
 sky130_fd_sc_hd__nand2_2 _1492_ (.A(_0999_),
    .B(_0286_),
    .Y(_0295_));
 sky130_fd_sc_hd__mux2_1 _1493_ (.A0(reg_wdata[0]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[16] ),
    .S(_0295_),
    .X(_0072_));
 sky130_fd_sc_hd__mux2_1 _1494_ (.A0(reg_wdata[1]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[17] ),
    .S(_0295_),
    .X(_0073_));
 sky130_fd_sc_hd__mux2_1 _1495_ (.A0(reg_wdata[2]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[18] ),
    .S(_0295_),
    .X(_0074_));
 sky130_fd_sc_hd__mux2_1 _1496_ (.A0(reg_wdata[3]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[19] ),
    .S(_0295_),
    .X(_0075_));
 sky130_fd_sc_hd__mux2_1 _1497_ (.A0(reg_wdata[4]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[20] ),
    .S(_0295_),
    .X(_0076_));
 sky130_fd_sc_hd__mux2_1 _1498_ (.A0(reg_wdata[5]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[21] ),
    .S(_0295_),
    .X(_0077_));
 sky130_fd_sc_hd__mux2_1 _1499_ (.A0(reg_wdata[6]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[22] ),
    .S(_0295_),
    .X(_0078_));
 sky130_fd_sc_hd__mux2_1 _1500_ (.A0(reg_wdata[7]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[23] ),
    .S(_0295_),
    .X(_0079_));
 sky130_fd_sc_hd__nand2_2 _1501_ (.A(_0985_),
    .B(_0286_),
    .Y(_0296_));
 sky130_fd_sc_hd__mux2_1 _1502_ (.A0(reg_wdata[0]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[8] ),
    .S(_0296_),
    .X(_0080_));
 sky130_fd_sc_hd__mux2_1 _1503_ (.A0(reg_wdata[1]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[9] ),
    .S(_0296_),
    .X(_0081_));
 sky130_fd_sc_hd__mux2_1 _1504_ (.A0(reg_wdata[2]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[10] ),
    .S(_0296_),
    .X(_0082_));
 sky130_fd_sc_hd__mux2_1 _1505_ (.A0(reg_wdata[3]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[11] ),
    .S(_0296_),
    .X(_0083_));
 sky130_fd_sc_hd__mux2_1 _1506_ (.A0(reg_wdata[4]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[12] ),
    .S(_0296_),
    .X(_0084_));
 sky130_fd_sc_hd__mux2_1 _1507_ (.A0(reg_wdata[5]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[13] ),
    .S(_0296_),
    .X(_0085_));
 sky130_fd_sc_hd__mux2_1 _1508_ (.A0(reg_wdata[6]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[14] ),
    .S(_0296_),
    .X(_0086_));
 sky130_fd_sc_hd__mux2_1 _1509_ (.A0(reg_wdata[7]),
    .A1(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[15] ),
    .S(_0296_),
    .X(_0087_));
 sky130_fd_sc_hd__nand2_2 _1510_ (.A(_1001_),
    .B(_0286_),
    .Y(_0297_));
 sky130_fd_sc_hd__mux2_1 _1511_ (.A0(reg_wdata[0]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[24] ),
    .S(_0297_),
    .X(_0088_));
 sky130_fd_sc_hd__mux2_1 _1512_ (.A0(reg_wdata[1]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[25] ),
    .S(_0297_),
    .X(_0089_));
 sky130_fd_sc_hd__mux2_1 _1513_ (.A0(reg_wdata[2]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[26] ),
    .S(_0297_),
    .X(_0090_));
 sky130_fd_sc_hd__mux2_1 _1514_ (.A0(reg_wdata[3]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[27] ),
    .S(_0297_),
    .X(_0091_));
 sky130_fd_sc_hd__mux2_1 _1515_ (.A0(reg_wdata[4]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[28] ),
    .S(_0297_),
    .X(_0092_));
 sky130_fd_sc_hd__mux2_1 _1516_ (.A0(reg_wdata[5]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[29] ),
    .S(_0297_),
    .X(_0093_));
 sky130_fd_sc_hd__mux2_1 _1517_ (.A0(reg_wdata[6]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[30] ),
    .S(_0297_),
    .X(_0094_));
 sky130_fd_sc_hd__mux2_1 _1518_ (.A0(reg_wdata[7]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[31] ),
    .S(_0297_),
    .X(_0095_));
 sky130_fd_sc_hd__nand2_2 _1519_ (.A(_0998_),
    .B(_0286_),
    .Y(_0298_));
 sky130_fd_sc_hd__mux2_1 _1520_ (.A0(reg_wdata[0]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[16] ),
    .S(_0298_),
    .X(_0096_));
 sky130_fd_sc_hd__mux2_1 _1521_ (.A0(reg_wdata[1]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[17] ),
    .S(_0298_),
    .X(_0097_));
 sky130_fd_sc_hd__mux2_1 _1522_ (.A0(reg_wdata[2]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[18] ),
    .S(_0298_),
    .X(_0098_));
 sky130_fd_sc_hd__mux2_1 _1523_ (.A0(reg_wdata[3]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[19] ),
    .S(_0298_),
    .X(_0099_));
 sky130_fd_sc_hd__mux2_1 _1524_ (.A0(reg_wdata[4]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[20] ),
    .S(_0298_),
    .X(_0100_));
 sky130_fd_sc_hd__mux2_1 _1525_ (.A0(reg_wdata[5]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[21] ),
    .S(_0298_),
    .X(_0101_));
 sky130_fd_sc_hd__mux2_1 _1526_ (.A0(reg_wdata[6]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[22] ),
    .S(_0298_),
    .X(_0102_));
 sky130_fd_sc_hd__mux2_1 _1527_ (.A0(reg_wdata[7]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[23] ),
    .S(_0298_),
    .X(_0103_));
 sky130_fd_sc_hd__nand2_2 _1528_ (.A(_0995_),
    .B(_0286_),
    .Y(_0299_));
 sky130_fd_sc_hd__mux2_1 _1529_ (.A0(reg_wdata[0]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[8] ),
    .S(_0299_),
    .X(_0104_));
 sky130_fd_sc_hd__mux2_1 _1530_ (.A0(reg_wdata[1]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[9] ),
    .S(_0299_),
    .X(_0105_));
 sky130_fd_sc_hd__mux2_1 _1531_ (.A0(reg_wdata[2]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[10] ),
    .S(_0299_),
    .X(_0106_));
 sky130_fd_sc_hd__mux2_1 _1532_ (.A0(reg_wdata[3]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[11] ),
    .S(_0299_),
    .X(_0107_));
 sky130_fd_sc_hd__mux2_1 _1533_ (.A0(reg_wdata[4]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[12] ),
    .S(_0299_),
    .X(_0108_));
 sky130_fd_sc_hd__mux2_1 _1534_ (.A0(reg_wdata[5]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[13] ),
    .S(_0299_),
    .X(_0109_));
 sky130_fd_sc_hd__mux2_1 _1535_ (.A0(reg_wdata[6]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[14] ),
    .S(_0299_),
    .X(_0110_));
 sky130_fd_sc_hd__mux2_1 _1536_ (.A0(reg_wdata[7]),
    .A1(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[15] ),
    .S(_0299_),
    .X(_0111_));
 sky130_fd_sc_hd__nand2_2 _1537_ (.A(_1002_),
    .B(_0286_),
    .Y(_0300_));
 sky130_fd_sc_hd__mux2_1 _1538_ (.A0(reg_wdata[0]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[24] ),
    .S(_0300_),
    .X(_0112_));
 sky130_fd_sc_hd__mux2_1 _1539_ (.A0(reg_wdata[1]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[25] ),
    .S(_0300_),
    .X(_0113_));
 sky130_fd_sc_hd__mux2_1 _1540_ (.A0(reg_wdata[2]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[26] ),
    .S(_0300_),
    .X(_0114_));
 sky130_fd_sc_hd__mux2_1 _1541_ (.A0(reg_wdata[3]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[27] ),
    .S(_0300_),
    .X(_0115_));
 sky130_fd_sc_hd__mux2_1 _1542_ (.A0(reg_wdata[4]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[28] ),
    .S(_0300_),
    .X(_0116_));
 sky130_fd_sc_hd__mux2_1 _1543_ (.A0(reg_wdata[5]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[29] ),
    .S(_0300_),
    .X(_0117_));
 sky130_fd_sc_hd__mux2_1 _1544_ (.A0(reg_wdata[6]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[30] ),
    .S(_0300_),
    .X(_0118_));
 sky130_fd_sc_hd__mux2_1 _1545_ (.A0(reg_wdata[7]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[31] ),
    .S(_0300_),
    .X(_0119_));
 sky130_fd_sc_hd__nand2_2 _1546_ (.A(_0994_),
    .B(_0286_),
    .Y(_0301_));
 sky130_fd_sc_hd__mux2_1 _1547_ (.A0(reg_wdata[0]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[16] ),
    .S(_0301_),
    .X(_0120_));
 sky130_fd_sc_hd__mux2_1 _1548_ (.A0(reg_wdata[1]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[17] ),
    .S(_0301_),
    .X(_0121_));
 sky130_fd_sc_hd__mux2_1 _1549_ (.A0(reg_wdata[2]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[18] ),
    .S(_0301_),
    .X(_0122_));
 sky130_fd_sc_hd__mux2_1 _1550_ (.A0(reg_wdata[3]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[19] ),
    .S(_0301_),
    .X(_0123_));
 sky130_fd_sc_hd__mux2_1 _1551_ (.A0(reg_wdata[4]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[20] ),
    .S(_0301_),
    .X(_0124_));
 sky130_fd_sc_hd__mux2_1 _1552_ (.A0(reg_wdata[5]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[21] ),
    .S(_0301_),
    .X(_0125_));
 sky130_fd_sc_hd__mux2_1 _1553_ (.A0(reg_wdata[6]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[22] ),
    .S(_0301_),
    .X(_0126_));
 sky130_fd_sc_hd__mux2_1 _1554_ (.A0(reg_wdata[7]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[23] ),
    .S(_0301_),
    .X(_0127_));
 sky130_fd_sc_hd__nand2_2 _1555_ (.A(_0980_),
    .B(_0286_),
    .Y(_0302_));
 sky130_fd_sc_hd__mux2_1 _1556_ (.A0(reg_wdata[0]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[8] ),
    .S(_0302_),
    .X(_0128_));
 sky130_fd_sc_hd__mux2_1 _1557_ (.A0(reg_wdata[1]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[9] ),
    .S(_0302_),
    .X(_0129_));
 sky130_fd_sc_hd__mux2_1 _1558_ (.A0(reg_wdata[2]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[10] ),
    .S(_0302_),
    .X(_0130_));
 sky130_fd_sc_hd__mux2_1 _1559_ (.A0(reg_wdata[3]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[11] ),
    .S(_0302_),
    .X(_0131_));
 sky130_fd_sc_hd__mux2_1 _1560_ (.A0(reg_wdata[4]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[12] ),
    .S(_0302_),
    .X(_0132_));
 sky130_fd_sc_hd__mux2_1 _1561_ (.A0(reg_wdata[5]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[13] ),
    .S(_0302_),
    .X(_0133_));
 sky130_fd_sc_hd__mux2_1 _1562_ (.A0(reg_wdata[6]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[14] ),
    .S(_0302_),
    .X(_0134_));
 sky130_fd_sc_hd__mux2_1 _1563_ (.A0(reg_wdata[7]),
    .A1(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[15] ),
    .S(_0302_),
    .X(_0135_));
 sky130_fd_sc_hd__nor3b_2 _1564_ (.A(\u_motor_control_transport_fsm.state[2] ),
    .B(_0891_),
    .C_N(\u_motor_control_transport_fsm.rsp_ready_next ),
    .Y(_0303_));
 sky130_fd_sc_hd__nor2_2 _1565_ (.A(_0855_),
    .B(_0303_),
    .Y(_0304_));
 sky130_fd_sc_hd__nor2_2 _1566_ (.A(_0001_),
    .B(\u_motor_control_transport_fsm.state[4] ),
    .Y(_0305_));
 sky130_fd_sc_hd__or2_2 _1567_ (.A(\u_motor_control_transport_fsm.timeout_cnt[0] ),
    .B(_0303_),
    .X(_0306_));
 sky130_fd_sc_hd__o211a_2 _1568_ (.A1(_0742_),
    .A2(_0304_),
    .B1(_0305_),
    .C1(_0306_),
    .X(_0136_));
 sky130_fd_sc_hd__nand2_2 _1569_ (.A(\u_motor_control_transport_fsm.timeout_cnt[1] ),
    .B(\u_motor_control_transport_fsm.timeout_cnt[0] ),
    .Y(_0307_));
 sky130_fd_sc_hd__or2_2 _1570_ (.A(\u_motor_control_transport_fsm.timeout_cnt[1] ),
    .B(\u_motor_control_transport_fsm.timeout_cnt[0] ),
    .X(_0308_));
 sky130_fd_sc_hd__a32o_2 _1571_ (.A1(_0303_),
    .A2(_0307_),
    .A3(_0308_),
    .B1(_0304_),
    .B2(\u_motor_control_transport_fsm.timeout_cnt[1] ),
    .X(_0309_));
 sky130_fd_sc_hd__and2_2 _1572_ (.A(_0305_),
    .B(_0309_),
    .X(_0137_));
 sky130_fd_sc_hd__nand3_2 _1573_ (.A(\u_motor_control_transport_fsm.timeout_cnt[2] ),
    .B(\u_motor_control_transport_fsm.timeout_cnt[1] ),
    .C(\u_motor_control_transport_fsm.timeout_cnt[0] ),
    .Y(_0310_));
 sky130_fd_sc_hd__a21o_2 _1574_ (.A1(\u_motor_control_transport_fsm.timeout_cnt[1] ),
    .A2(\u_motor_control_transport_fsm.timeout_cnt[0] ),
    .B1(\u_motor_control_transport_fsm.timeout_cnt[2] ),
    .X(_0311_));
 sky130_fd_sc_hd__a32o_2 _1575_ (.A1(_0303_),
    .A2(_0310_),
    .A3(_0311_),
    .B1(_0304_),
    .B2(\u_motor_control_transport_fsm.timeout_cnt[2] ),
    .X(_0312_));
 sky130_fd_sc_hd__and2_2 _1576_ (.A(_0305_),
    .B(_0312_),
    .X(_0138_));
 sky130_fd_sc_hd__a31o_2 _1577_ (.A1(\u_motor_control_transport_fsm.timeout_cnt[2] ),
    .A2(\u_motor_control_transport_fsm.timeout_cnt[1] ),
    .A3(\u_motor_control_transport_fsm.timeout_cnt[0] ),
    .B1(\u_motor_control_transport_fsm.timeout_cnt[3] ),
    .X(_0313_));
 sky130_fd_sc_hd__and4_2 _1578_ (.A(\u_motor_control_transport_fsm.timeout_cnt[3] ),
    .B(\u_motor_control_transport_fsm.timeout_cnt[2] ),
    .C(\u_motor_control_transport_fsm.timeout_cnt[1] ),
    .D(\u_motor_control_transport_fsm.timeout_cnt[0] ),
    .X(_0314_));
 sky130_fd_sc_hd__inv_2 _1579_ (.A(_0314_),
    .Y(_0315_));
 sky130_fd_sc_hd__a32o_2 _1580_ (.A1(_0303_),
    .A2(_0313_),
    .A3(_0315_),
    .B1(_0304_),
    .B2(\u_motor_control_transport_fsm.timeout_cnt[3] ),
    .X(_0316_));
 sky130_fd_sc_hd__and2_2 _1581_ (.A(_0305_),
    .B(_0316_),
    .X(_0139_));
 sky130_fd_sc_hd__or2_2 _1582_ (.A(\u_motor_control_transport_fsm.timeout_cnt[4] ),
    .B(_0314_),
    .X(_0317_));
 sky130_fd_sc_hd__nand2_2 _1583_ (.A(\u_motor_control_transport_fsm.timeout_cnt[4] ),
    .B(_0314_),
    .Y(_0318_));
 sky130_fd_sc_hd__a32o_2 _1584_ (.A1(_0303_),
    .A2(_0317_),
    .A3(_0318_),
    .B1(_0304_),
    .B2(\u_motor_control_transport_fsm.timeout_cnt[4] ),
    .X(_0319_));
 sky130_fd_sc_hd__and2_2 _1585_ (.A(_0305_),
    .B(_0319_),
    .X(_0140_));
 sky130_fd_sc_hd__a21o_2 _1586_ (.A1(\u_motor_control_transport_fsm.timeout_cnt[4] ),
    .A2(_0314_),
    .B1(\u_motor_control_transport_fsm.timeout_cnt[5] ),
    .X(_0320_));
 sky130_fd_sc_hd__and3_2 _1587_ (.A(\u_motor_control_transport_fsm.timeout_cnt[5] ),
    .B(\u_motor_control_transport_fsm.timeout_cnt[4] ),
    .C(_0314_),
    .X(_0321_));
 sky130_fd_sc_hd__inv_2 _1588_ (.A(_0321_),
    .Y(_0322_));
 sky130_fd_sc_hd__a22o_2 _1589_ (.A1(\u_motor_control_transport_fsm.timeout_cnt[5] ),
    .A2(_0304_),
    .B1(_0322_),
    .B2(_0303_),
    .X(_0323_));
 sky130_fd_sc_hd__and3_2 _1590_ (.A(_0305_),
    .B(_0320_),
    .C(_0323_),
    .X(_0141_));
 sky130_fd_sc_hd__and2_2 _1591_ (.A(\u_motor_control_transport_fsm.timeout_cnt[6] ),
    .B(_0321_),
    .X(_0324_));
 sky130_fd_sc_hd__inv_2 _1592_ (.A(_0324_),
    .Y(_0325_));
 sky130_fd_sc_hd__a22o_2 _1593_ (.A1(\u_motor_control_transport_fsm.timeout_cnt[6] ),
    .A2(_0304_),
    .B1(_0325_),
    .B2(_0303_),
    .X(_0326_));
 sky130_fd_sc_hd__o211a_2 _1594_ (.A1(\u_motor_control_transport_fsm.timeout_cnt[6] ),
    .A2(_0321_),
    .B1(_0326_),
    .C1(_0305_),
    .X(_0142_));
 sky130_fd_sc_hd__nand2_2 _1595_ (.A(\u_motor_control_transport_fsm.timeout_cnt[7] ),
    .B(_0324_),
    .Y(_0327_));
 sky130_fd_sc_hd__a22o_2 _1596_ (.A1(\u_motor_control_transport_fsm.timeout_cnt[7] ),
    .A2(_0304_),
    .B1(_0327_),
    .B2(_0303_),
    .X(_0328_));
 sky130_fd_sc_hd__o211a_2 _1597_ (.A1(\u_motor_control_transport_fsm.timeout_cnt[7] ),
    .A2(_0324_),
    .B1(_0328_),
    .C1(_0305_),
    .X(_0143_));
 sky130_fd_sc_hd__nor2_2 _1598_ (.A(_0740_),
    .B(_0327_),
    .Y(_0329_));
 sky130_fd_sc_hd__inv_2 _1599_ (.A(_0329_),
    .Y(_0330_));
 sky130_fd_sc_hd__a22o_2 _1600_ (.A1(\u_motor_control_transport_fsm.timeout_cnt[8] ),
    .A2(_0304_),
    .B1(_0330_),
    .B2(_0303_),
    .X(_0331_));
 sky130_fd_sc_hd__nand2_2 _1601_ (.A(_0305_),
    .B(_0331_),
    .Y(_0332_));
 sky130_fd_sc_hd__a21oi_2 _1602_ (.A1(_0740_),
    .A2(_0327_),
    .B1(_0332_),
    .Y(_0144_));
 sky130_fd_sc_hd__nor2_2 _1603_ (.A(_0739_),
    .B(_0330_),
    .Y(_0333_));
 sky130_fd_sc_hd__inv_2 _1604_ (.A(_0333_),
    .Y(_0334_));
 sky130_fd_sc_hd__a22o_2 _1605_ (.A1(\u_motor_control_transport_fsm.timeout_cnt[9] ),
    .A2(_0304_),
    .B1(_0334_),
    .B2(_0303_),
    .X(_0335_));
 sky130_fd_sc_hd__o211a_2 _1606_ (.A1(\u_motor_control_transport_fsm.timeout_cnt[9] ),
    .A2(_0329_),
    .B1(_0335_),
    .C1(_0305_),
    .X(_0145_));
 sky130_fd_sc_hd__a31o_2 _1607_ (.A1(\u_motor_control_transport_fsm.timeout_cnt[9] ),
    .A2(_0303_),
    .A3(_0329_),
    .B1(\u_motor_control_transport_fsm.timeout_cnt[10] ),
    .X(_0336_));
 sky130_fd_sc_hd__nand3_2 _1608_ (.A(\u_motor_control_transport_fsm.timeout_cnt[10] ),
    .B(_0303_),
    .C(_0333_),
    .Y(_0337_));
 sky130_fd_sc_hd__and4_2 _1609_ (.A(_0856_),
    .B(_0305_),
    .C(_0336_),
    .D(_0337_),
    .X(_0146_));
 sky130_fd_sc_hd__a21bo_2 _1610_ (.A1(\u_motor_control_transport_fsm.timeout_cnt[11] ),
    .A2(_0856_),
    .B1_N(_0337_),
    .X(_0338_));
 sky130_fd_sc_hd__and4_2 _1611_ (.A(\u_motor_control_transport_fsm.timeout_cnt[11] ),
    .B(\u_motor_control_transport_fsm.timeout_cnt[10] ),
    .C(_0303_),
    .D(_0333_),
    .X(_0339_));
 sky130_fd_sc_hd__and3b_2 _1612_ (.A_N(_0339_),
    .B(_0305_),
    .C(_0338_),
    .X(_0147_));
 sky130_fd_sc_hd__a21o_2 _1613_ (.A1(\u_motor_control_transport_fsm.timeout_cnt[12] ),
    .A2(_0856_),
    .B1(_0339_),
    .X(_0340_));
 sky130_fd_sc_hd__nand2_2 _1614_ (.A(\u_motor_control_transport_fsm.timeout_cnt[12] ),
    .B(_0339_),
    .Y(_0341_));
 sky130_fd_sc_hd__and3_2 _1615_ (.A(_0305_),
    .B(_0340_),
    .C(_0341_),
    .X(_0148_));
 sky130_fd_sc_hd__a22o_2 _1616_ (.A1(\u_motor_control_transport_fsm.timeout_cnt[13] ),
    .A2(_0856_),
    .B1(_0339_),
    .B2(\u_motor_control_transport_fsm.timeout_cnt[12] ),
    .X(_0342_));
 sky130_fd_sc_hd__and3_2 _1617_ (.A(\u_motor_control_transport_fsm.timeout_cnt[13] ),
    .B(\u_motor_control_transport_fsm.timeout_cnt[12] ),
    .C(_0339_),
    .X(_0343_));
 sky130_fd_sc_hd__and3b_2 _1618_ (.A_N(_0343_),
    .B(_0305_),
    .C(_0342_),
    .X(_0149_));
 sky130_fd_sc_hd__a21oi_2 _1619_ (.A1(\u_motor_control_transport_fsm.timeout_cnt[14] ),
    .A2(_0343_),
    .B1(_0855_),
    .Y(_0344_));
 sky130_fd_sc_hd__o211a_2 _1620_ (.A1(\u_motor_control_transport_fsm.timeout_cnt[14] ),
    .A2(_0343_),
    .B1(_0344_),
    .C1(_0305_),
    .X(_0150_));
 sky130_fd_sc_hd__a21o_2 _1621_ (.A1(\u_motor_control_transport_fsm.timeout_cnt[14] ),
    .A2(_0343_),
    .B1(\u_motor_control_transport_fsm.timeout_cnt[15] ),
    .X(_0345_));
 sky130_fd_sc_hd__o211a_2 _1622_ (.A1(_0738_),
    .A2(_0344_),
    .B1(_0345_),
    .C1(_0305_),
    .X(_0151_));
 sky130_fd_sc_hd__and3_2 _1623_ (.A(motor_control_register_map_cfg_enable),
    .B(\u_motor_control_transport_fsm.state[4] ),
    .C(motor_control_register_map_cfg_start),
    .X(_0346_));
 sky130_fd_sc_hd__a311oi_2 _1624_ (.A1(motor_control_register_map_cfg_fault_clear),
    .A2(motor_control_register_map_cfg_safety_override),
    .A3(\u_motor_control_transport_fsm.state[3] ),
    .B1(_0855_),
    .C1(_0346_),
    .Y(_0347_));
 sky130_fd_sc_hd__a311o_2 _1625_ (.A1(motor_control_register_map_cfg_fault_clear),
    .A2(motor_control_register_map_cfg_safety_override),
    .A3(\u_motor_control_transport_fsm.state[3] ),
    .B1(_0855_),
    .C1(_0346_),
    .X(_0348_));
 sky130_fd_sc_hd__nor2_2 _1626_ (.A(_0856_),
    .B(_0346_),
    .Y(_0349_));
 sky130_fd_sc_hd__or2_2 _1627_ (.A(_0856_),
    .B(_0346_),
    .X(_0350_));
 sky130_fd_sc_hd__o21ai_2 _1628_ (.A1(\u_motor_control_transport_fsm.seq_reg[0] ),
    .A2(_0350_),
    .B1(_0348_),
    .Y(_0351_));
 sky130_fd_sc_hd__and2_2 _1629_ (.A(motor_control_register_map_cfg_seq_base[0]),
    .B(_0350_),
    .X(_0352_));
 sky130_fd_sc_hd__o221a_2 _1630_ (.A1(\u_motor_control_transport_fsm.seq_reg[0] ),
    .A2(_0348_),
    .B1(_0351_),
    .B2(_0352_),
    .C1(reset_n),
    .X(_0152_));
 sky130_fd_sc_hd__nand2b_2 _1631_ (.A_N(\u_motor_control_transport_fsm.seq_reg[1] ),
    .B(_0351_),
    .Y(_0353_));
 sky130_fd_sc_hd__a21oi_2 _1632_ (.A1(\u_motor_control_transport_fsm.seq_reg[1] ),
    .A2(\u_motor_control_transport_fsm.seq_reg[0] ),
    .B1(_0350_),
    .Y(_0354_));
 sky130_fd_sc_hd__a211o_2 _1633_ (.A1(motor_control_register_map_cfg_seq_base[1]),
    .A2(_0350_),
    .B1(_0354_),
    .C1(_0347_),
    .X(_0355_));
 sky130_fd_sc_hd__and3_2 _1634_ (.A(reset_n),
    .B(_0353_),
    .C(_0355_),
    .X(_0153_));
 sky130_fd_sc_hd__o21bai_2 _1635_ (.A1(_0347_),
    .A2(_0354_),
    .B1_N(\u_motor_control_transport_fsm.seq_reg[2] ),
    .Y(_0356_));
 sky130_fd_sc_hd__and3_2 _1636_ (.A(\u_motor_control_transport_fsm.seq_reg[2] ),
    .B(\u_motor_control_transport_fsm.seq_reg[1] ),
    .C(\u_motor_control_transport_fsm.seq_reg[0] ),
    .X(_0357_));
 sky130_fd_sc_hd__o21ai_2 _1637_ (.A1(_0350_),
    .A2(_0357_),
    .B1(_0348_),
    .Y(_0358_));
 sky130_fd_sc_hd__a21o_2 _1638_ (.A1(motor_control_register_map_cfg_seq_base[2]),
    .A2(_0350_),
    .B1(_0358_),
    .X(_0359_));
 sky130_fd_sc_hd__and3_2 _1639_ (.A(reset_n),
    .B(_0356_),
    .C(_0359_),
    .X(_0154_));
 sky130_fd_sc_hd__and2_2 _1640_ (.A(\u_motor_control_transport_fsm.seq_reg[3] ),
    .B(_0357_),
    .X(_0360_));
 sky130_fd_sc_hd__o21ai_2 _1641_ (.A1(_0350_),
    .A2(_0360_),
    .B1(_0348_),
    .Y(_0361_));
 sky130_fd_sc_hd__a21o_2 _1642_ (.A1(motor_control_register_map_cfg_seq_base[3]),
    .A2(_0350_),
    .B1(_0361_),
    .X(_0362_));
 sky130_fd_sc_hd__nand2b_2 _1643_ (.A_N(\u_motor_control_transport_fsm.seq_reg[3] ),
    .B(_0358_),
    .Y(_0363_));
 sky130_fd_sc_hd__and3_2 _1644_ (.A(reset_n),
    .B(_0362_),
    .C(_0363_),
    .X(_0155_));
 sky130_fd_sc_hd__a21oi_2 _1645_ (.A1(\u_motor_control_transport_fsm.seq_reg[4] ),
    .A2(_0360_),
    .B1(_0350_),
    .Y(_0364_));
 sky130_fd_sc_hd__or2_2 _1646_ (.A(_0347_),
    .B(_0364_),
    .X(_0365_));
 sky130_fd_sc_hd__inv_2 _1647_ (.A(_0365_),
    .Y(_0366_));
 sky130_fd_sc_hd__a21oi_2 _1648_ (.A1(motor_control_register_map_cfg_seq_base[4]),
    .A2(_0350_),
    .B1(_0365_),
    .Y(_0367_));
 sky130_fd_sc_hd__a211oi_2 _1649_ (.A1(_0737_),
    .A2(_0361_),
    .B1(_0367_),
    .C1(_0001_),
    .Y(_0156_));
 sky130_fd_sc_hd__a31o_2 _1650_ (.A1(\u_motor_control_transport_fsm.seq_reg[5] ),
    .A2(\u_motor_control_transport_fsm.seq_reg[4] ),
    .A3(_0360_),
    .B1(_0350_),
    .X(_0368_));
 sky130_fd_sc_hd__nand2_2 _1651_ (.A(_0348_),
    .B(_0368_),
    .Y(_0369_));
 sky130_fd_sc_hd__inv_2 _1652_ (.A(_0369_),
    .Y(_0370_));
 sky130_fd_sc_hd__a21o_2 _1653_ (.A1(motor_control_register_map_cfg_seq_base[5]),
    .A2(_0350_),
    .B1(_0369_),
    .X(_0371_));
 sky130_fd_sc_hd__o211a_2 _1654_ (.A1(\u_motor_control_transport_fsm.seq_reg[5] ),
    .A2(_0366_),
    .B1(_0371_),
    .C1(reset_n),
    .X(_0157_));
 sky130_fd_sc_hd__and4_2 _1655_ (.A(\u_motor_control_transport_fsm.seq_reg[6] ),
    .B(\u_motor_control_transport_fsm.seq_reg[5] ),
    .C(\u_motor_control_transport_fsm.seq_reg[4] ),
    .D(_0360_),
    .X(_0372_));
 sky130_fd_sc_hd__o21ai_2 _1656_ (.A1(_0350_),
    .A2(_0372_),
    .B1(_0348_),
    .Y(_0373_));
 sky130_fd_sc_hd__a21o_2 _1657_ (.A1(motor_control_register_map_cfg_seq_base[6]),
    .A2(_0350_),
    .B1(_0373_),
    .X(_0374_));
 sky130_fd_sc_hd__o211a_2 _1658_ (.A1(\u_motor_control_transport_fsm.seq_reg[6] ),
    .A2(_0370_),
    .B1(_0374_),
    .C1(reset_n),
    .X(_0158_));
 sky130_fd_sc_hd__a21oi_2 _1659_ (.A1(\u_motor_control_transport_fsm.seq_reg[7] ),
    .A2(_0372_),
    .B1(_0350_),
    .Y(_0375_));
 sky130_fd_sc_hd__nor2_2 _1660_ (.A(_0347_),
    .B(_0375_),
    .Y(_0376_));
 sky130_fd_sc_hd__nand2_2 _1661_ (.A(motor_control_register_map_cfg_seq_base[7]),
    .B(_0350_),
    .Y(_0377_));
 sky130_fd_sc_hd__a221oi_2 _1662_ (.A1(_0736_),
    .A2(_0373_),
    .B1(_0376_),
    .B2(_0377_),
    .C1(_0001_),
    .Y(_0159_));
 sky130_fd_sc_hd__a31o_2 _1663_ (.A1(\u_motor_control_transport_fsm.seq_reg[8] ),
    .A2(\u_motor_control_transport_fsm.seq_reg[7] ),
    .A3(_0372_),
    .B1(_0350_),
    .X(_0378_));
 sky130_fd_sc_hd__nand2_2 _1664_ (.A(_0348_),
    .B(_0378_),
    .Y(_0379_));
 sky130_fd_sc_hd__inv_2 _1665_ (.A(_0379_),
    .Y(_0380_));
 sky130_fd_sc_hd__and2_2 _1666_ (.A(motor_control_register_map_cfg_seq_base[8]),
    .B(_0350_),
    .X(_0381_));
 sky130_fd_sc_hd__o221a_2 _1667_ (.A1(\u_motor_control_transport_fsm.seq_reg[8] ),
    .A2(_0376_),
    .B1(_0379_),
    .B2(_0381_),
    .C1(reset_n),
    .X(_0160_));
 sky130_fd_sc_hd__and4_2 _1668_ (.A(\u_motor_control_transport_fsm.seq_reg[9] ),
    .B(\u_motor_control_transport_fsm.seq_reg[8] ),
    .C(\u_motor_control_transport_fsm.seq_reg[7] ),
    .D(_0372_),
    .X(_0382_));
 sky130_fd_sc_hd__o21ai_2 _1669_ (.A1(_0350_),
    .A2(_0382_),
    .B1(_0348_),
    .Y(_0383_));
 sky130_fd_sc_hd__a21o_2 _1670_ (.A1(motor_control_register_map_cfg_seq_base[9]),
    .A2(_0350_),
    .B1(_0383_),
    .X(_0384_));
 sky130_fd_sc_hd__o211a_2 _1671_ (.A1(\u_motor_control_transport_fsm.seq_reg[9] ),
    .A2(_0380_),
    .B1(_0384_),
    .C1(reset_n),
    .X(_0161_));
 sky130_fd_sc_hd__a21o_2 _1672_ (.A1(\u_motor_control_transport_fsm.seq_reg[10] ),
    .A2(_0382_),
    .B1(_0350_),
    .X(_0385_));
 sky130_fd_sc_hd__a21oi_2 _1673_ (.A1(motor_control_register_map_cfg_seq_base[10]),
    .A2(_0350_),
    .B1(_0347_),
    .Y(_0386_));
 sky130_fd_sc_hd__a221oi_2 _1674_ (.A1(_0735_),
    .A2(_0383_),
    .B1(_0385_),
    .B2(_0386_),
    .C1(_0001_),
    .Y(_0162_));
 sky130_fd_sc_hd__and3_2 _1675_ (.A(\u_motor_control_transport_fsm.seq_reg[11] ),
    .B(\u_motor_control_transport_fsm.seq_reg[10] ),
    .C(_0382_),
    .X(_0387_));
 sky130_fd_sc_hd__a21oi_2 _1676_ (.A1(\u_motor_control_transport_fsm.seq_reg[10] ),
    .A2(_0382_),
    .B1(\u_motor_control_transport_fsm.seq_reg[11] ),
    .Y(_0388_));
 sky130_fd_sc_hd__o21ai_2 _1677_ (.A1(_0387_),
    .A2(_0388_),
    .B1(_0349_),
    .Y(_0389_));
 sky130_fd_sc_hd__o211a_2 _1678_ (.A1(motor_control_register_map_cfg_seq_base[11]),
    .A2(_0349_),
    .B1(_0389_),
    .C1(_0348_),
    .X(_0390_));
 sky130_fd_sc_hd__a21oi_2 _1679_ (.A1(\u_motor_control_transport_fsm.seq_reg[11] ),
    .A2(_0347_),
    .B1(_0390_),
    .Y(_0391_));
 sky130_fd_sc_hd__nor2_2 _1680_ (.A(_0001_),
    .B(_0391_),
    .Y(_0163_));
 sky130_fd_sc_hd__and2_2 _1681_ (.A(\u_motor_control_transport_fsm.seq_reg[12] ),
    .B(_0387_),
    .X(_0392_));
 sky130_fd_sc_hd__nor2_2 _1682_ (.A(\u_motor_control_transport_fsm.seq_reg[12] ),
    .B(_0387_),
    .Y(_0393_));
 sky130_fd_sc_hd__o21a_2 _1683_ (.A1(_0392_),
    .A2(_0393_),
    .B1(_0349_),
    .X(_0394_));
 sky130_fd_sc_hd__o21ai_2 _1684_ (.A1(motor_control_register_map_cfg_seq_base[12]),
    .A2(_0349_),
    .B1(_0348_),
    .Y(_0395_));
 sky130_fd_sc_hd__o22a_2 _1685_ (.A1(_0734_),
    .A2(_0348_),
    .B1(_0394_),
    .B2(_0395_),
    .X(_0396_));
 sky130_fd_sc_hd__nor2_2 _1686_ (.A(_0001_),
    .B(_0396_),
    .Y(_0164_));
 sky130_fd_sc_hd__and3_2 _1687_ (.A(\u_motor_control_transport_fsm.seq_reg[13] ),
    .B(\u_motor_control_transport_fsm.seq_reg[12] ),
    .C(_0387_),
    .X(_0397_));
 sky130_fd_sc_hd__inv_2 _1688_ (.A(_0397_),
    .Y(_0398_));
 sky130_fd_sc_hd__o21a_2 _1689_ (.A1(\u_motor_control_transport_fsm.seq_reg[13] ),
    .A2(_0392_),
    .B1(_0349_),
    .X(_0399_));
 sky130_fd_sc_hd__a221o_2 _1690_ (.A1(motor_control_register_map_cfg_seq_base[13]),
    .A2(_0350_),
    .B1(_0398_),
    .B2(_0399_),
    .C1(_0347_),
    .X(_0400_));
 sky130_fd_sc_hd__o211a_2 _1691_ (.A1(\u_motor_control_transport_fsm.seq_reg[13] ),
    .A2(_0348_),
    .B1(_0400_),
    .C1(reset_n),
    .X(_0165_));
 sky130_fd_sc_hd__or2_2 _1692_ (.A(\u_motor_control_transport_fsm.seq_reg[14] ),
    .B(_0397_),
    .X(_0401_));
 sky130_fd_sc_hd__nand2_2 _1693_ (.A(\u_motor_control_transport_fsm.seq_reg[14] ),
    .B(_0397_),
    .Y(_0402_));
 sky130_fd_sc_hd__a21o_2 _1694_ (.A1(_0401_),
    .A2(_0402_),
    .B1(_0350_),
    .X(_0403_));
 sky130_fd_sc_hd__o211a_2 _1695_ (.A1(motor_control_register_map_cfg_seq_base[14]),
    .A2(_0349_),
    .B1(_0403_),
    .C1(_0348_),
    .X(_0404_));
 sky130_fd_sc_hd__a21oi_2 _1696_ (.A1(\u_motor_control_transport_fsm.seq_reg[14] ),
    .A2(_0347_),
    .B1(_0404_),
    .Y(_0405_));
 sky130_fd_sc_hd__nor2_2 _1697_ (.A(_0001_),
    .B(_0405_),
    .Y(_0166_));
 sky130_fd_sc_hd__nor2_2 _1698_ (.A(\u_motor_control_transport_fsm.seq_reg[15] ),
    .B(_0402_),
    .Y(_0406_));
 sky130_fd_sc_hd__a21o_2 _1699_ (.A1(\u_motor_control_transport_fsm.seq_reg[15] ),
    .A2(_0402_),
    .B1(_0350_),
    .X(_0407_));
 sky130_fd_sc_hd__o22a_2 _1700_ (.A1(motor_control_register_map_cfg_seq_base[15]),
    .A2(_0349_),
    .B1(_0406_),
    .B2(_0407_),
    .X(_0408_));
 sky130_fd_sc_hd__or2_2 _1701_ (.A(\u_motor_control_transport_fsm.seq_reg[15] ),
    .B(_0348_),
    .X(_0409_));
 sky130_fd_sc_hd__o211a_2 _1702_ (.A1(_0347_),
    .A2(_0408_),
    .B1(_0409_),
    .C1(reset_n),
    .X(_0167_));
 sky130_fd_sc_hd__o22a_2 _1703_ (.A1(_0815_),
    .A2(motor_control_register_map_cfg_clamp_min[11]),
    .B1(motor_control_register_map_cfg_clamp_min[10]),
    .B2(_0817_),
    .X(_0410_));
 sky130_fd_sc_hd__a22o_2 _1704_ (.A1(rsp_data[9]),
    .A2(_0853_),
    .B1(_0854_),
    .B2(rsp_data[8]),
    .X(_0411_));
 sky130_fd_sc_hd__o211a_2 _1705_ (.A1(motor_control_register_map_cfg_clamp_min[1]),
    .A2(_0829_),
    .B1(_0830_),
    .C1(motor_control_register_map_cfg_clamp_min[0]),
    .X(_0412_));
 sky130_fd_sc_hd__a22o_2 _1706_ (.A1(motor_control_register_map_cfg_clamp_min[2]),
    .A2(_0828_),
    .B1(_0829_),
    .B2(motor_control_register_map_cfg_clamp_min[1]),
    .X(_0413_));
 sky130_fd_sc_hd__o22a_2 _1707_ (.A1(motor_control_register_map_cfg_clamp_min[3]),
    .A2(_0827_),
    .B1(_0828_),
    .B2(motor_control_register_map_cfg_clamp_min[2]),
    .X(_0414_));
 sky130_fd_sc_hd__o21a_2 _1708_ (.A1(_0412_),
    .A2(_0413_),
    .B1(_0414_),
    .X(_0415_));
 sky130_fd_sc_hd__a22o_2 _1709_ (.A1(motor_control_register_map_cfg_clamp_min[4]),
    .A2(_0826_),
    .B1(_0827_),
    .B2(motor_control_register_map_cfg_clamp_min[3]),
    .X(_0416_));
 sky130_fd_sc_hd__o22a_2 _1710_ (.A1(motor_control_register_map_cfg_clamp_min[5]),
    .A2(_0825_),
    .B1(_0826_),
    .B2(motor_control_register_map_cfg_clamp_min[4]),
    .X(_0417_));
 sky130_fd_sc_hd__o21ai_2 _1711_ (.A1(_0415_),
    .A2(_0416_),
    .B1(_0417_),
    .Y(_0418_));
 sky130_fd_sc_hd__o22a_2 _1712_ (.A1(_0773_),
    .A2(rsp_data[6]),
    .B1(rsp_data[5]),
    .B2(_0772_),
    .X(_0419_));
 sky130_fd_sc_hd__a22o_2 _1713_ (.A1(_0774_),
    .A2(rsp_data[7]),
    .B1(rsp_data[6]),
    .B2(_0773_),
    .X(_0420_));
 sky130_fd_sc_hd__a21oi_2 _1714_ (.A1(_0418_),
    .A2(_0419_),
    .B1(_0420_),
    .Y(_0421_));
 sky130_fd_sc_hd__a22o_2 _1715_ (.A1(motor_control_register_map_cfg_clamp_min[7]),
    .A2(_0823_),
    .B1(motor_control_register_map_cfg_clamp_min[9]),
    .B2(_0819_),
    .X(_0422_));
 sky130_fd_sc_hd__nor2_2 _1716_ (.A(rsp_data[10]),
    .B(_0852_),
    .Y(_0423_));
 sky130_fd_sc_hd__a22o_2 _1717_ (.A1(rsp_data[15]),
    .A2(_0847_),
    .B1(_0848_),
    .B2(rsp_data[14]),
    .X(_0424_));
 sky130_fd_sc_hd__a22o_2 _1718_ (.A1(rsp_data[13]),
    .A2(_0849_),
    .B1(_0850_),
    .B2(rsp_data[12]),
    .X(_0425_));
 sky130_fd_sc_hd__nor2_2 _1719_ (.A(_0424_),
    .B(_0425_),
    .Y(_0426_));
 sky130_fd_sc_hd__o22a_2 _1720_ (.A1(rsp_data[14]),
    .A2(_0848_),
    .B1(_0849_),
    .B2(rsp_data[13]),
    .X(_0427_));
 sky130_fd_sc_hd__nand2_2 _1721_ (.A(_0807_),
    .B(motor_control_register_map_cfg_clamp_min[15]),
    .Y(_0428_));
 sky130_fd_sc_hd__nor2_2 _1722_ (.A(rsp_data[11]),
    .B(_0851_),
    .Y(_0429_));
 sky130_fd_sc_hd__o2111a_2 _1723_ (.A1(rsp_data[12]),
    .A2(_0850_),
    .B1(_0426_),
    .C1(_0427_),
    .D1(_0428_),
    .X(_0430_));
 sky130_fd_sc_hd__nor2_2 _1724_ (.A(_0410_),
    .B(_0429_),
    .Y(_0431_));
 sky130_fd_sc_hd__nor2_2 _1725_ (.A(_0423_),
    .B(_0429_),
    .Y(_0432_));
 sky130_fd_sc_hd__a211o_2 _1726_ (.A1(_0821_),
    .A2(motor_control_register_map_cfg_clamp_min[8]),
    .B1(_0411_),
    .C1(_0422_),
    .X(_0433_));
 sky130_fd_sc_hd__or4b_2 _1727_ (.A(_0423_),
    .B(_0429_),
    .C(_0433_),
    .D_N(_0410_),
    .X(_0434_));
 sky130_fd_sc_hd__or3b_2 _1728_ (.A(_0434_),
    .B(_0421_),
    .C_N(_0430_),
    .X(_0435_));
 sky130_fd_sc_hd__o2111a_2 _1729_ (.A1(rsp_data[9]),
    .A2(_0853_),
    .B1(_0410_),
    .C1(_0411_),
    .D1(_0432_),
    .X(_0436_));
 sky130_fd_sc_hd__o21ai_2 _1730_ (.A1(_0431_),
    .A2(_0436_),
    .B1(_0430_),
    .Y(_0437_));
 sky130_fd_sc_hd__a21o_2 _1731_ (.A1(_0425_),
    .A2(_0427_),
    .B1(_0424_),
    .X(_0438_));
 sky130_fd_sc_hd__nand2_2 _1732_ (.A(_0428_),
    .B(_0438_),
    .Y(_0439_));
 sky130_fd_sc_hd__a22o_2 _1733_ (.A1(rsp_data[29]),
    .A2(_0833_),
    .B1(_0834_),
    .B2(rsp_data[28]),
    .X(_0440_));
 sky130_fd_sc_hd__a22o_2 _1734_ (.A1(rsp_data[25]),
    .A2(_0837_),
    .B1(_0838_),
    .B2(rsp_data[24]),
    .X(_0441_));
 sky130_fd_sc_hd__nor2_2 _1735_ (.A(_0440_),
    .B(_0441_),
    .Y(_0442_));
 sky130_fd_sc_hd__o22a_2 _1736_ (.A1(_0775_),
    .A2(motor_control_register_map_cfg_clamp_min[31]),
    .B1(motor_control_register_map_cfg_clamp_min[30]),
    .B2(_0777_),
    .X(_0443_));
 sky130_fd_sc_hd__o22a_2 _1737_ (.A1(rsp_data[30]),
    .A2(_0832_),
    .B1(_0833_),
    .B2(rsp_data[29]),
    .X(_0444_));
 sky130_fd_sc_hd__a22o_2 _1738_ (.A1(rsp_data[27]),
    .A2(_0835_),
    .B1(_0836_),
    .B2(rsp_data[26]),
    .X(_0445_));
 sky130_fd_sc_hd__nand2_2 _1739_ (.A(_0783_),
    .B(motor_control_register_map_cfg_clamp_min[27]),
    .Y(_0446_));
 sky130_fd_sc_hd__o21ai_2 _1740_ (.A1(rsp_data[26]),
    .A2(_0836_),
    .B1(_0446_),
    .Y(_0447_));
 sky130_fd_sc_hd__nor2_2 _1741_ (.A(_0445_),
    .B(_0447_),
    .Y(_0448_));
 sky130_fd_sc_hd__nand2_2 _1742_ (.A(_0787_),
    .B(motor_control_register_map_cfg_clamp_min[25]),
    .Y(_0449_));
 sky130_fd_sc_hd__nor2_2 _1743_ (.A(rsp_data[31]),
    .B(_0831_),
    .Y(_0450_));
 sky130_fd_sc_hd__nand2_2 _1744_ (.A(_0782_),
    .B(motor_control_register_map_cfg_clamp_min[28]),
    .Y(_0451_));
 sky130_fd_sc_hd__and3b_2 _1745_ (.A_N(_0450_),
    .B(_0444_),
    .C(_0443_),
    .X(_0452_));
 sky130_fd_sc_hd__o211a_2 _1746_ (.A1(rsp_data[24]),
    .A2(_0838_),
    .B1(_0449_),
    .C1(_0451_),
    .X(_0453_));
 sky130_fd_sc_hd__and4_2 _1747_ (.A(_0442_),
    .B(_0448_),
    .C(_0452_),
    .D(_0453_),
    .X(_0454_));
 sky130_fd_sc_hd__o22a_2 _1748_ (.A1(rsp_data[22]),
    .A2(_0840_),
    .B1(_0841_),
    .B2(rsp_data[21]),
    .X(_0455_));
 sky130_fd_sc_hd__o221a_2 _1749_ (.A1(rsp_data[23]),
    .A2(_0839_),
    .B1(_0842_),
    .B2(rsp_data[20]),
    .C1(_0455_),
    .X(_0456_));
 sky130_fd_sc_hd__o22a_2 _1750_ (.A1(_0795_),
    .A2(motor_control_register_map_cfg_clamp_min[21]),
    .B1(motor_control_register_map_cfg_clamp_min[20]),
    .B2(_0797_),
    .X(_0457_));
 sky130_fd_sc_hd__o22a_2 _1751_ (.A1(_0791_),
    .A2(motor_control_register_map_cfg_clamp_min[23]),
    .B1(motor_control_register_map_cfg_clamp_min[22]),
    .B2(_0793_),
    .X(_0458_));
 sky130_fd_sc_hd__and3_2 _1752_ (.A(_0456_),
    .B(_0457_),
    .C(_0458_),
    .X(_0459_));
 sky130_fd_sc_hd__and2b_2 _1753_ (.A_N(motor_control_register_map_cfg_clamp_min[19]),
    .B(rsp_data[19]),
    .X(_0460_));
 sky130_fd_sc_hd__a21oi_2 _1754_ (.A1(rsp_data[18]),
    .A2(_0844_),
    .B1(_0460_),
    .Y(_0461_));
 sky130_fd_sc_hd__nand2_2 _1755_ (.A(_0799_),
    .B(motor_control_register_map_cfg_clamp_min[19]),
    .Y(_0462_));
 sky130_fd_sc_hd__o211a_2 _1756_ (.A1(rsp_data[18]),
    .A2(_0844_),
    .B1(_0461_),
    .C1(_0462_),
    .X(_0463_));
 sky130_fd_sc_hd__a22o_2 _1757_ (.A1(rsp_data[17]),
    .A2(_0845_),
    .B1(_0846_),
    .B2(rsp_data[16]),
    .X(_0464_));
 sky130_fd_sc_hd__nand2_2 _1758_ (.A(_0803_),
    .B(motor_control_register_map_cfg_clamp_min[17]),
    .Y(_0465_));
 sky130_fd_sc_hd__o221a_2 _1759_ (.A1(_0803_),
    .A2(motor_control_register_map_cfg_clamp_min[17]),
    .B1(_0846_),
    .B2(rsp_data[16]),
    .C1(_0463_),
    .X(_0466_));
 sky130_fd_sc_hd__o2111a_2 _1760_ (.A1(_0805_),
    .A2(motor_control_register_map_cfg_clamp_min[16]),
    .B1(_0459_),
    .C1(_0465_),
    .D1(_0466_),
    .X(_0467_));
 sky130_fd_sc_hd__nand2_2 _1761_ (.A(_0454_),
    .B(_0467_),
    .Y(_0468_));
 sky130_fd_sc_hd__a31o_2 _1762_ (.A1(_0435_),
    .A2(_0437_),
    .A3(_0439_),
    .B1(_0468_),
    .X(_0469_));
 sky130_fd_sc_hd__a31o_2 _1763_ (.A1(_0463_),
    .A2(_0464_),
    .A3(_0465_),
    .B1(_0460_),
    .X(_0470_));
 sky130_fd_sc_hd__a31o_2 _1764_ (.A1(rsp_data[18]),
    .A2(_0844_),
    .A3(_0462_),
    .B1(_0470_),
    .X(_0471_));
 sky130_fd_sc_hd__nand2b_2 _1765_ (.A_N(_0457_),
    .B(_0455_),
    .Y(_0472_));
 sky130_fd_sc_hd__o2bb2a_2 _1766_ (.A1_N(_0458_),
    .A2_N(_0472_),
    .B1(rsp_data[23]),
    .B2(_0839_),
    .X(_0473_));
 sky130_fd_sc_hd__a21o_2 _1767_ (.A1(_0459_),
    .A2(_0471_),
    .B1(_0473_),
    .X(_0474_));
 sky130_fd_sc_hd__nand2_2 _1768_ (.A(_0454_),
    .B(_0474_),
    .Y(_0475_));
 sky130_fd_sc_hd__a32o_2 _1769_ (.A1(_0441_),
    .A2(_0448_),
    .A3(_0449_),
    .B1(_0445_),
    .B2(_0446_),
    .X(_0476_));
 sky130_fd_sc_hd__a21o_2 _1770_ (.A1(_0451_),
    .A2(_0476_),
    .B1(_0440_),
    .X(_0477_));
 sky130_fd_sc_hd__nand2_2 _1771_ (.A(_0452_),
    .B(_0477_),
    .Y(_0478_));
 sky130_fd_sc_hd__o2111ai_2 _1772_ (.A1(_0443_),
    .A2(_0450_),
    .B1(_0469_),
    .C1(_0475_),
    .D1(_0478_),
    .Y(_0479_));
 sky130_fd_sc_hd__nor2_2 _1773_ (.A(rsp_data[31]),
    .B(_0776_),
    .Y(_0480_));
 sky130_fd_sc_hd__nand2_2 _1774_ (.A(_0781_),
    .B(rsp_data[28]),
    .Y(_0481_));
 sky130_fd_sc_hd__a22o_2 _1775_ (.A1(_0779_),
    .A2(motor_control_register_map_cfg_clamp_max[29]),
    .B1(motor_control_register_map_cfg_clamp_max[28]),
    .B2(_0782_),
    .X(_0482_));
 sky130_fd_sc_hd__o22a_2 _1776_ (.A1(rsp_data[25]),
    .A2(_0788_),
    .B1(rsp_data[24]),
    .B2(_0790_),
    .X(_0483_));
 sky130_fd_sc_hd__a221o_2 _1777_ (.A1(_0783_),
    .A2(motor_control_register_map_cfg_clamp_max[27]),
    .B1(rsp_data[24]),
    .B2(_0790_),
    .C1(_0482_),
    .X(_0484_));
 sky130_fd_sc_hd__or4bb_2 _1778_ (.A(_0480_),
    .B(_0484_),
    .C_N(_0481_),
    .D_N(_0483_),
    .X(_0485_));
 sky130_fd_sc_hd__nor2_2 _1779_ (.A(_0783_),
    .B(motor_control_register_map_cfg_clamp_max[27]),
    .Y(_0486_));
 sky130_fd_sc_hd__a22o_2 _1780_ (.A1(_0785_),
    .A2(motor_control_register_map_cfg_clamp_max[26]),
    .B1(rsp_data[25]),
    .B2(_0788_),
    .X(_0487_));
 sky130_fd_sc_hd__a211o_2 _1781_ (.A1(rsp_data[26]),
    .A2(_0786_),
    .B1(_0486_),
    .C1(_0487_),
    .X(_0488_));
 sky130_fd_sc_hd__nand2_2 _1782_ (.A(_0777_),
    .B(motor_control_register_map_cfg_clamp_max[30]),
    .Y(_0489_));
 sky130_fd_sc_hd__nand2_2 _1783_ (.A(rsp_data[30]),
    .B(_0778_),
    .Y(_0490_));
 sky130_fd_sc_hd__nand2_2 _1784_ (.A(rsp_data[29]),
    .B(_0780_),
    .Y(_0491_));
 sky130_fd_sc_hd__o211a_2 _1785_ (.A1(_0775_),
    .A2(motor_control_register_map_cfg_clamp_max[31]),
    .B1(_0489_),
    .C1(_0490_),
    .X(_0492_));
 sky130_fd_sc_hd__and4bb_2 _1786_ (.A_N(_0485_),
    .B_N(_0488_),
    .C(_0491_),
    .D(_0492_),
    .X(_0493_));
 sky130_fd_sc_hd__a22o_2 _1787_ (.A1(rsp_data[22]),
    .A2(_0794_),
    .B1(rsp_data[21]),
    .B2(_0796_),
    .X(_0494_));
 sky130_fd_sc_hd__o22a_2 _1788_ (.A1(rsp_data[23]),
    .A2(_0792_),
    .B1(rsp_data[22]),
    .B2(_0794_),
    .X(_0495_));
 sky130_fd_sc_hd__o221a_2 _1789_ (.A1(rsp_data[21]),
    .A2(_0796_),
    .B1(rsp_data[20]),
    .B2(_0798_),
    .C1(_0495_),
    .X(_0496_));
 sky130_fd_sc_hd__a221oi_2 _1790_ (.A1(rsp_data[23]),
    .A2(_0792_),
    .B1(_0494_),
    .B2(_0495_),
    .C1(_0496_),
    .Y(_0497_));
 sky130_fd_sc_hd__o22a_2 _1791_ (.A1(rsp_data[19]),
    .A2(_0800_),
    .B1(rsp_data[18]),
    .B2(_0802_),
    .X(_0498_));
 sky130_fd_sc_hd__a22o_2 _1792_ (.A1(_0803_),
    .A2(motor_control_register_map_cfg_clamp_max[17]),
    .B1(_0805_),
    .B2(motor_control_register_map_cfg_clamp_max[16]),
    .X(_0499_));
 sky130_fd_sc_hd__o22a_2 _1793_ (.A1(_0801_),
    .A2(motor_control_register_map_cfg_clamp_max[18]),
    .B1(_0803_),
    .B2(motor_control_register_map_cfg_clamp_max[17]),
    .X(_0500_));
 sky130_fd_sc_hd__a21bo_2 _1794_ (.A1(_0499_),
    .A2(_0500_),
    .B1_N(_0498_),
    .X(_0501_));
 sky130_fd_sc_hd__o22a_2 _1795_ (.A1(_0791_),
    .A2(motor_control_register_map_cfg_clamp_max[23]),
    .B1(_0797_),
    .B2(motor_control_register_map_cfg_clamp_max[20]),
    .X(_0502_));
 sky130_fd_sc_hd__and3b_2 _1796_ (.A_N(_0494_),
    .B(_0496_),
    .C(_0502_),
    .X(_0503_));
 sky130_fd_sc_hd__nand2_2 _1797_ (.A(rsp_data[19]),
    .B(_0800_),
    .Y(_0504_));
 sky130_fd_sc_hd__a31o_2 _1798_ (.A1(_0501_),
    .A2(_0503_),
    .A3(_0504_),
    .B1(_0497_),
    .X(_0505_));
 sky130_fd_sc_hd__nor2_2 _1799_ (.A(motor_control_register_map_cfg_clamp_max[7]),
    .B(_0823_),
    .Y(_0506_));
 sky130_fd_sc_hd__a22o_2 _1800_ (.A1(motor_control_register_map_cfg_clamp_max[6]),
    .A2(_0824_),
    .B1(rsp_data[5]),
    .B2(_0764_),
    .X(_0507_));
 sky130_fd_sc_hd__a211o_2 _1801_ (.A1(_0765_),
    .A2(rsp_data[6]),
    .B1(_0506_),
    .C1(_0507_),
    .X(_0508_));
 sky130_fd_sc_hd__nand2b_2 _1802_ (.A_N(rsp_data[1]),
    .B(motor_control_register_map_cfg_clamp_max[1]),
    .Y(_0509_));
 sky130_fd_sc_hd__and2b_2 _1803_ (.A_N(motor_control_register_map_cfg_clamp_max[2]),
    .B(rsp_data[2]),
    .X(_0510_));
 sky130_fd_sc_hd__and2b_2 _1804_ (.A_N(motor_control_register_map_cfg_clamp_max[1]),
    .B(rsp_data[1]),
    .X(_0511_));
 sky130_fd_sc_hd__a311o_2 _1805_ (.A1(_0759_),
    .A2(rsp_data[0]),
    .A3(_0509_),
    .B1(_0510_),
    .C1(_0511_),
    .X(_0512_));
 sky130_fd_sc_hd__o22a_2 _1806_ (.A1(_0762_),
    .A2(rsp_data[3]),
    .B1(rsp_data[2]),
    .B2(_0761_),
    .X(_0513_));
 sky130_fd_sc_hd__a22o_2 _1807_ (.A1(motor_control_register_map_cfg_clamp_max[7]),
    .A2(_0823_),
    .B1(rsp_data[4]),
    .B2(_0763_),
    .X(_0514_));
 sky130_fd_sc_hd__a221o_2 _1808_ (.A1(_0762_),
    .A2(rsp_data[3]),
    .B1(_0512_),
    .B2(_0513_),
    .C1(_0514_),
    .X(_0515_));
 sky130_fd_sc_hd__o221a_2 _1809_ (.A1(_0764_),
    .A2(rsp_data[5]),
    .B1(rsp_data[4]),
    .B2(_0763_),
    .C1(_0515_),
    .X(_0516_));
 sky130_fd_sc_hd__or3_2 _1810_ (.A(_0765_),
    .B(rsp_data[6]),
    .C(_0506_),
    .X(_0517_));
 sky130_fd_sc_hd__o221a_2 _1811_ (.A1(_0766_),
    .A2(rsp_data[7]),
    .B1(_0508_),
    .B2(_0516_),
    .C1(_0517_),
    .X(_0518_));
 sky130_fd_sc_hd__o22a_2 _1812_ (.A1(rsp_data[11]),
    .A2(_0816_),
    .B1(rsp_data[10]),
    .B2(_0818_),
    .X(_0519_));
 sky130_fd_sc_hd__nor2_2 _1813_ (.A(_0815_),
    .B(motor_control_register_map_cfg_clamp_max[11]),
    .Y(_0520_));
 sky130_fd_sc_hd__nand2b_2 _1814_ (.A_N(_0520_),
    .B(_0519_),
    .Y(_0521_));
 sky130_fd_sc_hd__a221o_2 _1815_ (.A1(rsp_data[10]),
    .A2(_0818_),
    .B1(rsp_data[9]),
    .B2(_0820_),
    .C1(_0521_),
    .X(_0522_));
 sky130_fd_sc_hd__o22a_2 _1816_ (.A1(rsp_data[9]),
    .A2(_0820_),
    .B1(rsp_data[8]),
    .B2(_0822_),
    .X(_0523_));
 sky130_fd_sc_hd__nor2_2 _1817_ (.A(_0821_),
    .B(motor_control_register_map_cfg_clamp_max[8]),
    .Y(_0524_));
 sky130_fd_sc_hd__or4b_2 _1818_ (.A(_0518_),
    .B(_0522_),
    .C(_0524_),
    .D_N(_0523_),
    .X(_0525_));
 sky130_fd_sc_hd__o22a_2 _1819_ (.A1(_0519_),
    .A2(_0520_),
    .B1(_0522_),
    .B2(_0523_),
    .X(_0526_));
 sky130_fd_sc_hd__o22a_2 _1820_ (.A1(rsp_data[15]),
    .A2(_0808_),
    .B1(rsp_data[14]),
    .B2(_0810_),
    .X(_0527_));
 sky130_fd_sc_hd__nor2_2 _1821_ (.A(_0807_),
    .B(motor_control_register_map_cfg_clamp_max[15]),
    .Y(_0528_));
 sky130_fd_sc_hd__nor2_2 _1822_ (.A(_0809_),
    .B(motor_control_register_map_cfg_clamp_max[14]),
    .Y(_0529_));
 sky130_fd_sc_hd__or3b_2 _1823_ (.A(_0528_),
    .B(_0529_),
    .C_N(_0527_),
    .X(_0530_));
 sky130_fd_sc_hd__a22o_2 _1824_ (.A1(_0811_),
    .A2(motor_control_register_map_cfg_clamp_max[13]),
    .B1(_0813_),
    .B2(motor_control_register_map_cfg_clamp_max[12]),
    .X(_0531_));
 sky130_fd_sc_hd__nor2_2 _1825_ (.A(_0811_),
    .B(motor_control_register_map_cfg_clamp_max[13]),
    .Y(_0532_));
 sky130_fd_sc_hd__a2111oi_2 _1826_ (.A1(rsp_data[12]),
    .A2(_0814_),
    .B1(_0530_),
    .C1(_0531_),
    .D1(_0532_),
    .Y(_0533_));
 sky130_fd_sc_hd__a21bo_2 _1827_ (.A1(_0525_),
    .A2(_0526_),
    .B1_N(_0533_),
    .X(_0534_));
 sky130_fd_sc_hd__or3b_2 _1828_ (.A(_0532_),
    .B(_0530_),
    .C_N(_0531_),
    .X(_0535_));
 sky130_fd_sc_hd__or2_2 _1829_ (.A(_0527_),
    .B(_0528_),
    .X(_0536_));
 sky130_fd_sc_hd__o211a_2 _1830_ (.A1(_0805_),
    .A2(motor_control_register_map_cfg_clamp_max[16]),
    .B1(_0498_),
    .C1(_0504_),
    .X(_0537_));
 sky130_fd_sc_hd__and4b_2 _1831_ (.A_N(_0499_),
    .B(_0500_),
    .C(_0503_),
    .D(_0537_),
    .X(_0538_));
 sky130_fd_sc_hd__nand2_2 _1832_ (.A(_0493_),
    .B(_0538_),
    .Y(_0539_));
 sky130_fd_sc_hd__a31o_2 _1833_ (.A1(_0534_),
    .A2(_0535_),
    .A3(_0536_),
    .B1(_0539_),
    .X(_0540_));
 sky130_fd_sc_hd__or3_2 _1834_ (.A(rsp_data[26]),
    .B(_0786_),
    .C(_0486_),
    .X(_0541_));
 sky130_fd_sc_hd__o221ai_2 _1835_ (.A1(rsp_data[27]),
    .A2(_0784_),
    .B1(_0483_),
    .B2(_0488_),
    .C1(_0541_),
    .Y(_0542_));
 sky130_fd_sc_hd__a21o_2 _1836_ (.A1(_0481_),
    .A2(_0542_),
    .B1(_0482_),
    .X(_0543_));
 sky130_fd_sc_hd__a21oi_2 _1837_ (.A1(rsp_data[31]),
    .A2(_0776_),
    .B1(_0489_),
    .Y(_0544_));
 sky130_fd_sc_hd__nor2_2 _1838_ (.A(_0480_),
    .B(_0544_),
    .Y(_0545_));
 sky130_fd_sc_hd__a32oi_2 _1839_ (.A1(_0491_),
    .A2(_0492_),
    .A3(_0543_),
    .B1(_0505_),
    .B2(_0493_),
    .Y(_0546_));
 sky130_fd_sc_hd__nand3_2 _1840_ (.A(_0540_),
    .B(_0545_),
    .C(_0546_),
    .Y(_0547_));
 sky130_fd_sc_hd__mux2_1 _1841_ (.A0(_0767_),
    .A1(_0830_),
    .S(_0479_),
    .X(_0548_));
 sky130_fd_sc_hd__a41o_2 _1842_ (.A1(_0759_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0549_));
 sky130_fd_sc_hd__a21oi_2 _1843_ (.A1(_0547_),
    .A2(_0548_),
    .B1(_0549_),
    .Y(_0550_));
 sky130_fd_sc_hd__o21a_2 _1844_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(\u_motor_control_transport_fsm.state[1] ),
    .B1(motor_control_register_map_cfg_enable),
    .X(_0551_));
 sky130_fd_sc_hd__o21ai_2 _1845_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(\u_motor_control_transport_fsm.state[1] ),
    .B1(motor_control_register_map_cfg_enable),
    .Y(_0552_));
 sky130_fd_sc_hd__mux2_1 _1846_ (.A0(rsp_data[0]),
    .A1(motor_control_register_map_cfg_fallback_cmd[0]),
    .S(_0960_),
    .X(_0553_));
 sky130_fd_sc_hd__a21o_2 _1847_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0553_),
    .B1(_0552_),
    .X(_0554_));
 sky130_fd_sc_hd__o221a_2 _1848_ (.A1(motor_control_register_map_cfg_fallback_cmd[0]),
    .A2(_0551_),
    .B1(_0554_),
    .B2(_0550_),
    .C1(reset_n),
    .X(_0168_));
 sky130_fd_sc_hd__mux2_1 _1849_ (.A0(_0768_),
    .A1(_0829_),
    .S(_0479_),
    .X(_0555_));
 sky130_fd_sc_hd__a41o_2 _1850_ (.A1(_0760_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0556_));
 sky130_fd_sc_hd__a21oi_2 _1851_ (.A1(_0547_),
    .A2(_0555_),
    .B1(_0556_),
    .Y(_0557_));
 sky130_fd_sc_hd__mux2_1 _1852_ (.A0(rsp_data[1]),
    .A1(motor_control_register_map_cfg_fallback_cmd[1]),
    .S(_0960_),
    .X(_0558_));
 sky130_fd_sc_hd__a21o_2 _1853_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0558_),
    .B1(_0552_),
    .X(_0559_));
 sky130_fd_sc_hd__o221a_2 _1854_ (.A1(motor_control_register_map_cfg_fallback_cmd[1]),
    .A2(_0551_),
    .B1(_0557_),
    .B2(_0559_),
    .C1(reset_n),
    .X(_0169_));
 sky130_fd_sc_hd__mux2_1 _1855_ (.A0(_0769_),
    .A1(_0828_),
    .S(_0479_),
    .X(_0560_));
 sky130_fd_sc_hd__a41o_2 _1856_ (.A1(_0761_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0561_));
 sky130_fd_sc_hd__a21oi_2 _1857_ (.A1(_0547_),
    .A2(_0560_),
    .B1(_0561_),
    .Y(_0562_));
 sky130_fd_sc_hd__mux2_1 _1858_ (.A0(rsp_data[2]),
    .A1(motor_control_register_map_cfg_fallback_cmd[2]),
    .S(_0960_),
    .X(_0563_));
 sky130_fd_sc_hd__a21o_2 _1859_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0563_),
    .B1(_0552_),
    .X(_0564_));
 sky130_fd_sc_hd__o221a_2 _1860_ (.A1(motor_control_register_map_cfg_fallback_cmd[2]),
    .A2(_0551_),
    .B1(_0562_),
    .B2(_0564_),
    .C1(reset_n),
    .X(_0170_));
 sky130_fd_sc_hd__mux2_1 _1861_ (.A0(_0770_),
    .A1(_0827_),
    .S(_0479_),
    .X(_0565_));
 sky130_fd_sc_hd__a41o_2 _1862_ (.A1(_0762_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0566_));
 sky130_fd_sc_hd__a21oi_2 _1863_ (.A1(_0547_),
    .A2(_0565_),
    .B1(_0566_),
    .Y(_0567_));
 sky130_fd_sc_hd__mux2_1 _1864_ (.A0(rsp_data[3]),
    .A1(motor_control_register_map_cfg_fallback_cmd[3]),
    .S(_0960_),
    .X(_0568_));
 sky130_fd_sc_hd__a21o_2 _1865_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0568_),
    .B1(_0552_),
    .X(_0569_));
 sky130_fd_sc_hd__o221a_2 _1866_ (.A1(motor_control_register_map_cfg_fallback_cmd[3]),
    .A2(_0551_),
    .B1(_0567_),
    .B2(_0569_),
    .C1(reset_n),
    .X(_0171_));
 sky130_fd_sc_hd__mux2_1 _1867_ (.A0(_0771_),
    .A1(_0826_),
    .S(_0479_),
    .X(_0570_));
 sky130_fd_sc_hd__a41o_2 _1868_ (.A1(_0763_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0571_));
 sky130_fd_sc_hd__a21oi_2 _1869_ (.A1(_0547_),
    .A2(_0570_),
    .B1(_0571_),
    .Y(_0572_));
 sky130_fd_sc_hd__mux2_1 _1870_ (.A0(rsp_data[4]),
    .A1(motor_control_register_map_cfg_fallback_cmd[4]),
    .S(_0960_),
    .X(_0573_));
 sky130_fd_sc_hd__a21o_2 _1871_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0573_),
    .B1(_0552_),
    .X(_0574_));
 sky130_fd_sc_hd__o221a_2 _1872_ (.A1(motor_control_register_map_cfg_fallback_cmd[4]),
    .A2(_0551_),
    .B1(_0572_),
    .B2(_0574_),
    .C1(reset_n),
    .X(_0172_));
 sky130_fd_sc_hd__mux2_1 _1873_ (.A0(_0772_),
    .A1(_0825_),
    .S(_0479_),
    .X(_0575_));
 sky130_fd_sc_hd__a41o_2 _1874_ (.A1(_0764_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0576_));
 sky130_fd_sc_hd__a21oi_2 _1875_ (.A1(_0547_),
    .A2(_0575_),
    .B1(_0576_),
    .Y(_0577_));
 sky130_fd_sc_hd__mux2_1 _1876_ (.A0(rsp_data[5]),
    .A1(motor_control_register_map_cfg_fallback_cmd[5]),
    .S(_0960_),
    .X(_0578_));
 sky130_fd_sc_hd__a21o_2 _1877_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0578_),
    .B1(_0552_),
    .X(_0579_));
 sky130_fd_sc_hd__o221a_2 _1878_ (.A1(motor_control_register_map_cfg_fallback_cmd[5]),
    .A2(_0551_),
    .B1(_0577_),
    .B2(_0579_),
    .C1(reset_n),
    .X(_0173_));
 sky130_fd_sc_hd__mux2_1 _1879_ (.A0(_0773_),
    .A1(_0824_),
    .S(_0479_),
    .X(_0580_));
 sky130_fd_sc_hd__a41o_2 _1880_ (.A1(_0765_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0581_));
 sky130_fd_sc_hd__a21oi_2 _1881_ (.A1(_0547_),
    .A2(_0580_),
    .B1(_0581_),
    .Y(_0582_));
 sky130_fd_sc_hd__mux2_1 _1882_ (.A0(rsp_data[6]),
    .A1(motor_control_register_map_cfg_fallback_cmd[6]),
    .S(_0960_),
    .X(_0583_));
 sky130_fd_sc_hd__a21o_2 _1883_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0583_),
    .B1(_0552_),
    .X(_0584_));
 sky130_fd_sc_hd__o221a_2 _1884_ (.A1(motor_control_register_map_cfg_fallback_cmd[6]),
    .A2(_0551_),
    .B1(_0582_),
    .B2(_0584_),
    .C1(reset_n),
    .X(_0174_));
 sky130_fd_sc_hd__mux2_1 _1885_ (.A0(_0774_),
    .A1(_0823_),
    .S(_0479_),
    .X(_0585_));
 sky130_fd_sc_hd__a41o_2 _1886_ (.A1(_0766_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0586_));
 sky130_fd_sc_hd__a21oi_2 _1887_ (.A1(_0547_),
    .A2(_0585_),
    .B1(_0586_),
    .Y(_0587_));
 sky130_fd_sc_hd__mux2_1 _1888_ (.A0(rsp_data[7]),
    .A1(motor_control_register_map_cfg_fallback_cmd[7]),
    .S(_0960_),
    .X(_0588_));
 sky130_fd_sc_hd__a21o_2 _1889_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0588_),
    .B1(_0552_),
    .X(_0589_));
 sky130_fd_sc_hd__o221a_2 _1890_ (.A1(motor_control_register_map_cfg_fallback_cmd[7]),
    .A2(_0551_),
    .B1(_0587_),
    .B2(_0589_),
    .C1(reset_n),
    .X(_0175_));
 sky130_fd_sc_hd__mux2_1 _1891_ (.A0(_0854_),
    .A1(_0821_),
    .S(_0479_),
    .X(_0590_));
 sky130_fd_sc_hd__a41o_2 _1892_ (.A1(_0822_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0591_));
 sky130_fd_sc_hd__a21oi_2 _1893_ (.A1(_0547_),
    .A2(_0590_),
    .B1(_0591_),
    .Y(_0592_));
 sky130_fd_sc_hd__mux2_1 _1894_ (.A0(rsp_data[8]),
    .A1(motor_control_register_map_cfg_fallback_cmd[8]),
    .S(_0960_),
    .X(_0593_));
 sky130_fd_sc_hd__a21o_2 _1895_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0593_),
    .B1(_0552_),
    .X(_0594_));
 sky130_fd_sc_hd__o221a_2 _1896_ (.A1(motor_control_register_map_cfg_fallback_cmd[8]),
    .A2(_0551_),
    .B1(_0592_),
    .B2(_0594_),
    .C1(reset_n),
    .X(_0176_));
 sky130_fd_sc_hd__mux2_1 _1897_ (.A0(_0853_),
    .A1(_0819_),
    .S(_0479_),
    .X(_0595_));
 sky130_fd_sc_hd__a41o_2 _1898_ (.A1(_0820_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0596_));
 sky130_fd_sc_hd__a21oi_2 _1899_ (.A1(_0547_),
    .A2(_0595_),
    .B1(_0596_),
    .Y(_0597_));
 sky130_fd_sc_hd__mux2_1 _1900_ (.A0(rsp_data[9]),
    .A1(motor_control_register_map_cfg_fallback_cmd[9]),
    .S(_0960_),
    .X(_0598_));
 sky130_fd_sc_hd__a21o_2 _1901_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0598_),
    .B1(_0552_),
    .X(_0599_));
 sky130_fd_sc_hd__o221a_2 _1902_ (.A1(motor_control_register_map_cfg_fallback_cmd[9]),
    .A2(_0551_),
    .B1(_0597_),
    .B2(_0599_),
    .C1(reset_n),
    .X(_0177_));
 sky130_fd_sc_hd__mux2_1 _1903_ (.A0(_0852_),
    .A1(_0817_),
    .S(_0479_),
    .X(_0600_));
 sky130_fd_sc_hd__a41o_2 _1904_ (.A1(_0818_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0601_));
 sky130_fd_sc_hd__a21oi_2 _1905_ (.A1(_0547_),
    .A2(_0600_),
    .B1(_0601_),
    .Y(_0602_));
 sky130_fd_sc_hd__mux2_1 _1906_ (.A0(rsp_data[10]),
    .A1(motor_control_register_map_cfg_fallback_cmd[10]),
    .S(_0960_),
    .X(_0603_));
 sky130_fd_sc_hd__a21o_2 _1907_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0603_),
    .B1(_0552_),
    .X(_0604_));
 sky130_fd_sc_hd__o221a_2 _1908_ (.A1(motor_control_register_map_cfg_fallback_cmd[10]),
    .A2(_0551_),
    .B1(_0602_),
    .B2(_0604_),
    .C1(reset_n),
    .X(_0178_));
 sky130_fd_sc_hd__mux2_1 _1909_ (.A0(_0851_),
    .A1(_0815_),
    .S(_0479_),
    .X(_0605_));
 sky130_fd_sc_hd__a41o_2 _1910_ (.A1(_0816_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0606_));
 sky130_fd_sc_hd__a21oi_2 _1911_ (.A1(_0547_),
    .A2(_0605_),
    .B1(_0606_),
    .Y(_0607_));
 sky130_fd_sc_hd__mux2_1 _1912_ (.A0(rsp_data[11]),
    .A1(motor_control_register_map_cfg_fallback_cmd[11]),
    .S(_0960_),
    .X(_0608_));
 sky130_fd_sc_hd__a21o_2 _1913_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0608_),
    .B1(_0552_),
    .X(_0609_));
 sky130_fd_sc_hd__o221a_2 _1914_ (.A1(motor_control_register_map_cfg_fallback_cmd[11]),
    .A2(_0551_),
    .B1(_0607_),
    .B2(_0609_),
    .C1(reset_n),
    .X(_0179_));
 sky130_fd_sc_hd__mux2_1 _1915_ (.A0(_0850_),
    .A1(_0813_),
    .S(_0479_),
    .X(_0610_));
 sky130_fd_sc_hd__a41o_2 _1916_ (.A1(_0814_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0611_));
 sky130_fd_sc_hd__a21oi_2 _1917_ (.A1(_0547_),
    .A2(_0610_),
    .B1(_0611_),
    .Y(_0612_));
 sky130_fd_sc_hd__mux2_1 _1918_ (.A0(rsp_data[12]),
    .A1(motor_control_register_map_cfg_fallback_cmd[12]),
    .S(_0960_),
    .X(_0613_));
 sky130_fd_sc_hd__a21o_2 _1919_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0613_),
    .B1(_0552_),
    .X(_0614_));
 sky130_fd_sc_hd__o221a_2 _1920_ (.A1(motor_control_register_map_cfg_fallback_cmd[12]),
    .A2(_0551_),
    .B1(_0612_),
    .B2(_0614_),
    .C1(reset_n),
    .X(_0180_));
 sky130_fd_sc_hd__mux2_1 _1921_ (.A0(_0849_),
    .A1(_0811_),
    .S(_0479_),
    .X(_0615_));
 sky130_fd_sc_hd__a41o_2 _1922_ (.A1(_0812_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0616_));
 sky130_fd_sc_hd__a21oi_2 _1923_ (.A1(_0547_),
    .A2(_0615_),
    .B1(_0616_),
    .Y(_0617_));
 sky130_fd_sc_hd__mux2_1 _1924_ (.A0(rsp_data[13]),
    .A1(motor_control_register_map_cfg_fallback_cmd[13]),
    .S(_0960_),
    .X(_0618_));
 sky130_fd_sc_hd__a21o_2 _1925_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0618_),
    .B1(_0552_),
    .X(_0619_));
 sky130_fd_sc_hd__o221a_2 _1926_ (.A1(motor_control_register_map_cfg_fallback_cmd[13]),
    .A2(_0551_),
    .B1(_0617_),
    .B2(_0619_),
    .C1(reset_n),
    .X(_0181_));
 sky130_fd_sc_hd__mux2_1 _1927_ (.A0(_0848_),
    .A1(_0809_),
    .S(_0479_),
    .X(_0620_));
 sky130_fd_sc_hd__a41o_2 _1928_ (.A1(_0810_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0621_));
 sky130_fd_sc_hd__a21oi_2 _1929_ (.A1(_0547_),
    .A2(_0620_),
    .B1(_0621_),
    .Y(_0622_));
 sky130_fd_sc_hd__mux2_1 _1930_ (.A0(rsp_data[14]),
    .A1(motor_control_register_map_cfg_fallback_cmd[14]),
    .S(_0960_),
    .X(_0623_));
 sky130_fd_sc_hd__a21o_2 _1931_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0623_),
    .B1(_0552_),
    .X(_0624_));
 sky130_fd_sc_hd__o221a_2 _1932_ (.A1(motor_control_register_map_cfg_fallback_cmd[14]),
    .A2(_0551_),
    .B1(_0622_),
    .B2(_0624_),
    .C1(reset_n),
    .X(_0182_));
 sky130_fd_sc_hd__mux2_1 _1933_ (.A0(_0847_),
    .A1(_0807_),
    .S(_0479_),
    .X(_0625_));
 sky130_fd_sc_hd__a41o_2 _1934_ (.A1(_0808_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0626_));
 sky130_fd_sc_hd__a21oi_2 _1935_ (.A1(_0547_),
    .A2(_0625_),
    .B1(_0626_),
    .Y(_0627_));
 sky130_fd_sc_hd__mux2_1 _1936_ (.A0(rsp_data[15]),
    .A1(motor_control_register_map_cfg_fallback_cmd[15]),
    .S(_0960_),
    .X(_0628_));
 sky130_fd_sc_hd__a21o_2 _1937_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0628_),
    .B1(_0552_),
    .X(_0629_));
 sky130_fd_sc_hd__o221a_2 _1938_ (.A1(motor_control_register_map_cfg_fallback_cmd[15]),
    .A2(_0551_),
    .B1(_0627_),
    .B2(_0629_),
    .C1(reset_n),
    .X(_0183_));
 sky130_fd_sc_hd__mux2_1 _1939_ (.A0(_0846_),
    .A1(_0805_),
    .S(_0479_),
    .X(_0630_));
 sky130_fd_sc_hd__a41o_2 _1940_ (.A1(_0806_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0631_));
 sky130_fd_sc_hd__a21oi_2 _1941_ (.A1(_0547_),
    .A2(_0630_),
    .B1(_0631_),
    .Y(_0632_));
 sky130_fd_sc_hd__mux2_1 _1942_ (.A0(rsp_data[16]),
    .A1(motor_control_register_map_cfg_fallback_cmd[16]),
    .S(_0960_),
    .X(_0633_));
 sky130_fd_sc_hd__a21o_2 _1943_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0633_),
    .B1(_0552_),
    .X(_0634_));
 sky130_fd_sc_hd__o221a_2 _1944_ (.A1(motor_control_register_map_cfg_fallback_cmd[16]),
    .A2(_0551_),
    .B1(_0632_),
    .B2(_0634_),
    .C1(reset_n),
    .X(_0184_));
 sky130_fd_sc_hd__mux2_1 _1945_ (.A0(_0845_),
    .A1(_0803_),
    .S(_0479_),
    .X(_0635_));
 sky130_fd_sc_hd__a41o_2 _1946_ (.A1(_0804_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0636_));
 sky130_fd_sc_hd__a21oi_2 _1947_ (.A1(_0547_),
    .A2(_0635_),
    .B1(_0636_),
    .Y(_0637_));
 sky130_fd_sc_hd__mux2_1 _1948_ (.A0(rsp_data[17]),
    .A1(motor_control_register_map_cfg_fallback_cmd[17]),
    .S(_0960_),
    .X(_0638_));
 sky130_fd_sc_hd__a21o_2 _1949_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0638_),
    .B1(_0552_),
    .X(_0639_));
 sky130_fd_sc_hd__o221a_2 _1950_ (.A1(motor_control_register_map_cfg_fallback_cmd[17]),
    .A2(_0551_),
    .B1(_0637_),
    .B2(_0639_),
    .C1(reset_n),
    .X(_0185_));
 sky130_fd_sc_hd__mux2_1 _1951_ (.A0(_0844_),
    .A1(_0801_),
    .S(_0479_),
    .X(_0640_));
 sky130_fd_sc_hd__a41o_2 _1952_ (.A1(_0802_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0641_));
 sky130_fd_sc_hd__a21oi_2 _1953_ (.A1(_0547_),
    .A2(_0640_),
    .B1(_0641_),
    .Y(_0642_));
 sky130_fd_sc_hd__mux2_1 _1954_ (.A0(rsp_data[18]),
    .A1(motor_control_register_map_cfg_fallback_cmd[18]),
    .S(_0960_),
    .X(_0643_));
 sky130_fd_sc_hd__a21o_2 _1955_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0643_),
    .B1(_0552_),
    .X(_0644_));
 sky130_fd_sc_hd__o221a_2 _1956_ (.A1(motor_control_register_map_cfg_fallback_cmd[18]),
    .A2(_0551_),
    .B1(_0642_),
    .B2(_0644_),
    .C1(reset_n),
    .X(_0186_));
 sky130_fd_sc_hd__mux2_1 _1957_ (.A0(_0843_),
    .A1(_0799_),
    .S(_0479_),
    .X(_0645_));
 sky130_fd_sc_hd__a41o_2 _1958_ (.A1(_0800_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0646_));
 sky130_fd_sc_hd__a21oi_2 _1959_ (.A1(_0547_),
    .A2(_0645_),
    .B1(_0646_),
    .Y(_0647_));
 sky130_fd_sc_hd__mux2_1 _1960_ (.A0(rsp_data[19]),
    .A1(motor_control_register_map_cfg_fallback_cmd[19]),
    .S(_0960_),
    .X(_0648_));
 sky130_fd_sc_hd__a21o_2 _1961_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0648_),
    .B1(_0552_),
    .X(_0649_));
 sky130_fd_sc_hd__o221a_2 _1962_ (.A1(motor_control_register_map_cfg_fallback_cmd[19]),
    .A2(_0551_),
    .B1(_0647_),
    .B2(_0649_),
    .C1(reset_n),
    .X(_0187_));
 sky130_fd_sc_hd__mux2_1 _1963_ (.A0(_0842_),
    .A1(_0797_),
    .S(_0479_),
    .X(_0650_));
 sky130_fd_sc_hd__a41o_2 _1964_ (.A1(_0798_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0651_));
 sky130_fd_sc_hd__a21oi_2 _1965_ (.A1(_0547_),
    .A2(_0650_),
    .B1(_0651_),
    .Y(_0652_));
 sky130_fd_sc_hd__mux2_1 _1966_ (.A0(rsp_data[20]),
    .A1(motor_control_register_map_cfg_fallback_cmd[20]),
    .S(_0960_),
    .X(_0653_));
 sky130_fd_sc_hd__a21o_2 _1967_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0653_),
    .B1(_0552_),
    .X(_0654_));
 sky130_fd_sc_hd__o221a_2 _1968_ (.A1(motor_control_register_map_cfg_fallback_cmd[20]),
    .A2(_0551_),
    .B1(_0652_),
    .B2(_0654_),
    .C1(reset_n),
    .X(_0188_));
 sky130_fd_sc_hd__mux2_1 _1969_ (.A0(_0841_),
    .A1(_0795_),
    .S(_0479_),
    .X(_0655_));
 sky130_fd_sc_hd__a41o_2 _1970_ (.A1(_0796_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0656_));
 sky130_fd_sc_hd__a21oi_2 _1971_ (.A1(_0547_),
    .A2(_0655_),
    .B1(_0656_),
    .Y(_0657_));
 sky130_fd_sc_hd__mux2_1 _1972_ (.A0(rsp_data[21]),
    .A1(motor_control_register_map_cfg_fallback_cmd[21]),
    .S(_0960_),
    .X(_0658_));
 sky130_fd_sc_hd__a21o_2 _1973_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0658_),
    .B1(_0552_),
    .X(_0659_));
 sky130_fd_sc_hd__o221a_2 _1974_ (.A1(motor_control_register_map_cfg_fallback_cmd[21]),
    .A2(_0551_),
    .B1(_0657_),
    .B2(_0659_),
    .C1(reset_n),
    .X(_0189_));
 sky130_fd_sc_hd__mux2_1 _1975_ (.A0(_0840_),
    .A1(_0793_),
    .S(_0479_),
    .X(_0660_));
 sky130_fd_sc_hd__a41o_2 _1976_ (.A1(_0794_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0661_));
 sky130_fd_sc_hd__a21oi_2 _1977_ (.A1(_0547_),
    .A2(_0660_),
    .B1(_0661_),
    .Y(_0662_));
 sky130_fd_sc_hd__mux2_1 _1978_ (.A0(rsp_data[22]),
    .A1(motor_control_register_map_cfg_fallback_cmd[22]),
    .S(_0960_),
    .X(_0663_));
 sky130_fd_sc_hd__a21o_2 _1979_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0663_),
    .B1(_0552_),
    .X(_0664_));
 sky130_fd_sc_hd__o221a_2 _1980_ (.A1(motor_control_register_map_cfg_fallback_cmd[22]),
    .A2(_0551_),
    .B1(_0662_),
    .B2(_0664_),
    .C1(reset_n),
    .X(_0190_));
 sky130_fd_sc_hd__mux2_1 _1981_ (.A0(_0839_),
    .A1(_0791_),
    .S(_0479_),
    .X(_0665_));
 sky130_fd_sc_hd__a41o_2 _1982_ (.A1(_0792_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0666_));
 sky130_fd_sc_hd__a21oi_2 _1983_ (.A1(_0547_),
    .A2(_0665_),
    .B1(_0666_),
    .Y(_0667_));
 sky130_fd_sc_hd__mux2_1 _1984_ (.A0(rsp_data[23]),
    .A1(motor_control_register_map_cfg_fallback_cmd[23]),
    .S(_0960_),
    .X(_0668_));
 sky130_fd_sc_hd__a21o_2 _1985_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0668_),
    .B1(_0552_),
    .X(_0669_));
 sky130_fd_sc_hd__o221a_2 _1986_ (.A1(motor_control_register_map_cfg_fallback_cmd[23]),
    .A2(_0551_),
    .B1(_0667_),
    .B2(_0669_),
    .C1(reset_n),
    .X(_0191_));
 sky130_fd_sc_hd__mux2_1 _1987_ (.A0(_0838_),
    .A1(_0789_),
    .S(_0479_),
    .X(_0670_));
 sky130_fd_sc_hd__a41o_2 _1988_ (.A1(_0790_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0671_));
 sky130_fd_sc_hd__a21oi_2 _1989_ (.A1(_0547_),
    .A2(_0670_),
    .B1(_0671_),
    .Y(_0672_));
 sky130_fd_sc_hd__mux2_1 _1990_ (.A0(rsp_data[24]),
    .A1(motor_control_register_map_cfg_fallback_cmd[24]),
    .S(_0960_),
    .X(_0673_));
 sky130_fd_sc_hd__a21o_2 _1991_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0673_),
    .B1(_0552_),
    .X(_0674_));
 sky130_fd_sc_hd__o221a_2 _1992_ (.A1(motor_control_register_map_cfg_fallback_cmd[24]),
    .A2(_0551_),
    .B1(_0672_),
    .B2(_0674_),
    .C1(reset_n),
    .X(_0192_));
 sky130_fd_sc_hd__mux2_1 _1993_ (.A0(_0837_),
    .A1(_0787_),
    .S(_0479_),
    .X(_0675_));
 sky130_fd_sc_hd__a41o_2 _1994_ (.A1(_0788_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0676_));
 sky130_fd_sc_hd__a21oi_2 _1995_ (.A1(_0547_),
    .A2(_0675_),
    .B1(_0676_),
    .Y(_0677_));
 sky130_fd_sc_hd__mux2_1 _1996_ (.A0(rsp_data[25]),
    .A1(motor_control_register_map_cfg_fallback_cmd[25]),
    .S(_0960_),
    .X(_0678_));
 sky130_fd_sc_hd__a21o_2 _1997_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0678_),
    .B1(_0552_),
    .X(_0679_));
 sky130_fd_sc_hd__o221a_2 _1998_ (.A1(motor_control_register_map_cfg_fallback_cmd[25]),
    .A2(_0551_),
    .B1(_0677_),
    .B2(_0679_),
    .C1(reset_n),
    .X(_0193_));
 sky130_fd_sc_hd__mux2_1 _1999_ (.A0(_0836_),
    .A1(_0785_),
    .S(_0479_),
    .X(_0680_));
 sky130_fd_sc_hd__a41o_2 _2000_ (.A1(_0786_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0681_));
 sky130_fd_sc_hd__a21oi_2 _2001_ (.A1(_0547_),
    .A2(_0680_),
    .B1(_0681_),
    .Y(_0682_));
 sky130_fd_sc_hd__mux2_1 _2002_ (.A0(rsp_data[26]),
    .A1(motor_control_register_map_cfg_fallback_cmd[26]),
    .S(_0960_),
    .X(_0683_));
 sky130_fd_sc_hd__a21o_2 _2003_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0683_),
    .B1(_0552_),
    .X(_0684_));
 sky130_fd_sc_hd__o221a_2 _2004_ (.A1(motor_control_register_map_cfg_fallback_cmd[26]),
    .A2(_0551_),
    .B1(_0682_),
    .B2(_0684_),
    .C1(reset_n),
    .X(_0194_));
 sky130_fd_sc_hd__mux2_1 _2005_ (.A0(_0835_),
    .A1(_0783_),
    .S(_0479_),
    .X(_0685_));
 sky130_fd_sc_hd__a41o_2 _2006_ (.A1(_0784_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0686_));
 sky130_fd_sc_hd__a21oi_2 _2007_ (.A1(_0547_),
    .A2(_0685_),
    .B1(_0686_),
    .Y(_0687_));
 sky130_fd_sc_hd__mux2_1 _2008_ (.A0(rsp_data[27]),
    .A1(motor_control_register_map_cfg_fallback_cmd[27]),
    .S(_0960_),
    .X(_0688_));
 sky130_fd_sc_hd__a21o_2 _2009_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0688_),
    .B1(_0552_),
    .X(_0689_));
 sky130_fd_sc_hd__o221a_2 _2010_ (.A1(motor_control_register_map_cfg_fallback_cmd[27]),
    .A2(_0551_),
    .B1(_0687_),
    .B2(_0689_),
    .C1(reset_n),
    .X(_0195_));
 sky130_fd_sc_hd__mux2_1 _2011_ (.A0(_0834_),
    .A1(_0782_),
    .S(_0479_),
    .X(_0690_));
 sky130_fd_sc_hd__a41o_2 _2012_ (.A1(_0781_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0691_));
 sky130_fd_sc_hd__a21oi_2 _2013_ (.A1(_0547_),
    .A2(_0690_),
    .B1(_0691_),
    .Y(_0692_));
 sky130_fd_sc_hd__mux2_1 _2014_ (.A0(rsp_data[28]),
    .A1(motor_control_register_map_cfg_fallback_cmd[28]),
    .S(_0960_),
    .X(_0693_));
 sky130_fd_sc_hd__a21o_2 _2015_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0693_),
    .B1(_0552_),
    .X(_0694_));
 sky130_fd_sc_hd__o221a_2 _2016_ (.A1(motor_control_register_map_cfg_fallback_cmd[28]),
    .A2(_0551_),
    .B1(_0692_),
    .B2(_0694_),
    .C1(reset_n),
    .X(_0196_));
 sky130_fd_sc_hd__mux2_1 _2017_ (.A0(_0833_),
    .A1(_0779_),
    .S(_0479_),
    .X(_0695_));
 sky130_fd_sc_hd__a41o_2 _2018_ (.A1(_0780_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0696_));
 sky130_fd_sc_hd__a21oi_2 _2019_ (.A1(_0547_),
    .A2(_0695_),
    .B1(_0696_),
    .Y(_0697_));
 sky130_fd_sc_hd__mux2_1 _2020_ (.A0(rsp_data[29]),
    .A1(motor_control_register_map_cfg_fallback_cmd[29]),
    .S(_0960_),
    .X(_0698_));
 sky130_fd_sc_hd__a21o_2 _2021_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0698_),
    .B1(_0552_),
    .X(_0699_));
 sky130_fd_sc_hd__o221a_2 _2022_ (.A1(motor_control_register_map_cfg_fallback_cmd[29]),
    .A2(_0551_),
    .B1(_0697_),
    .B2(_0699_),
    .C1(reset_n),
    .X(_0197_));
 sky130_fd_sc_hd__mux2_1 _2023_ (.A0(_0832_),
    .A1(_0777_),
    .S(_0479_),
    .X(_0700_));
 sky130_fd_sc_hd__a41o_2 _2024_ (.A1(_0778_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0701_));
 sky130_fd_sc_hd__a21oi_2 _2025_ (.A1(_0547_),
    .A2(_0700_),
    .B1(_0701_),
    .Y(_0702_));
 sky130_fd_sc_hd__mux2_1 _2026_ (.A0(rsp_data[30]),
    .A1(motor_control_register_map_cfg_fallback_cmd[30]),
    .S(_0960_),
    .X(_0703_));
 sky130_fd_sc_hd__a21o_2 _2027_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0703_),
    .B1(_0552_),
    .X(_0704_));
 sky130_fd_sc_hd__o221a_2 _2028_ (.A1(motor_control_register_map_cfg_fallback_cmd[30]),
    .A2(_0551_),
    .B1(_0702_),
    .B2(_0704_),
    .C1(reset_n),
    .X(_0198_));
 sky130_fd_sc_hd__mux2_1 _2029_ (.A0(_0831_),
    .A1(_0775_),
    .S(_0479_),
    .X(_0705_));
 sky130_fd_sc_hd__a41o_2 _2030_ (.A1(_0776_),
    .A2(_0540_),
    .A3(_0545_),
    .A4(_0546_),
    .B1(_0757_),
    .X(_0706_));
 sky130_fd_sc_hd__a21oi_2 _2031_ (.A1(_0547_),
    .A2(_0705_),
    .B1(_0706_),
    .Y(_0707_));
 sky130_fd_sc_hd__mux2_1 _2032_ (.A0(rsp_data[31]),
    .A1(motor_control_register_map_cfg_fallback_cmd[31]),
    .S(_0960_),
    .X(_0708_));
 sky130_fd_sc_hd__a21o_2 _2033_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0708_),
    .B1(_0552_),
    .X(_0709_));
 sky130_fd_sc_hd__o221a_2 _2034_ (.A1(motor_control_register_map_cfg_fallback_cmd[31]),
    .A2(_0551_),
    .B1(_0707_),
    .B2(_0709_),
    .C1(reset_n),
    .X(_0199_));
 sky130_fd_sc_hd__nor3_2 _2035_ (.A(_0753_),
    .B(\u_motor_control_transport_fsm.state[4] ),
    .C(_0966_),
    .Y(_0710_));
 sky130_fd_sc_hd__a211o_2 _2036_ (.A1(_0754_),
    .A2(\u_motor_control_transport_fsm.state[5] ),
    .B1(\u_motor_control_transport_fsm.state[3] ),
    .C1(motor_control_transport_fsm_status_fault_from_u_motor_control_transport_fsm),
    .X(_0711_));
 sky130_fd_sc_hd__o211a_2 _2037_ (.A1(\u_motor_control_transport_fsm.state[4] ),
    .A2(_0966_),
    .B1(_0711_),
    .C1(_0963_),
    .X(_0712_));
 sky130_fd_sc_hd__a311o_2 _2038_ (.A1(\u_motor_control_transport_fsm.rsp_ready_next ),
    .A2(_0754_),
    .A3(_0961_),
    .B1(_0710_),
    .C1(_0712_),
    .X(_0713_));
 sky130_fd_sc_hd__and2_2 _2039_ (.A(reset_n),
    .B(_0713_),
    .X(_0204_));
 sky130_fd_sc_hd__o311a_2 _2040_ (.A1(_0752_),
    .A2(motor_control_transport_fsm_status_fault_from_u_motor_control_transport_fsm),
    .A3(\u_motor_control_transport_fsm.state[3] ),
    .B1(_0966_),
    .C1(reset_n),
    .X(_0714_));
 sky130_fd_sc_hd__a31o_2 _2041_ (.A1(reset_n),
    .A2(_0754_),
    .A3(_0713_),
    .B1(_0714_),
    .X(_0200_));
 sky130_fd_sc_hd__o21a_2 _2042_ (.A1(\u_motor_control_transport_fsm.state[1] ),
    .A2(_0966_),
    .B1(reset_n),
    .X(_0201_));
 sky130_fd_sc_hd__nand2_2 _2043_ (.A(_0986_),
    .B(_0286_),
    .Y(_0715_));
 sky130_fd_sc_hd__mux2_1 _2044_ (.A0(reg_wdata[3]),
    .A1(motor_control_register_map_cfg_safety_override_from_u_motor_control_register_map),
    .S(_0715_),
    .X(_0203_));
 sky130_fd_sc_hd__o21a_2 _2045_ (.A1(\u_motor_control_transport_fsm.state[4] ),
    .A2(_0962_),
    .B1(reset_n),
    .X(_0716_));
 sky130_fd_sc_hd__o21a_2 _2046_ (.A1(_0962_),
    .A2(_0346_),
    .B1(_0857_),
    .X(_0205_));
 sky130_fd_sc_hd__o21a_2 _2047_ (.A1(_0962_),
    .A2(_0346_),
    .B1(reset_n),
    .X(_0717_));
 sky130_fd_sc_hd__and2_2 _2048_ (.A(motor_control_register_map_cfg_safety_override),
    .B(_0717_),
    .X(_0206_));
 sky130_fd_sc_hd__a22o_2 _2049_ (.A1(\u_motor_control_transport_fsm.seq_reg[15] ),
    .A2(_0962_),
    .B1(_0346_),
    .B2(motor_control_register_map_cfg_seq_base[15]),
    .X(_0718_));
 sky130_fd_sc_hd__and2_2 _2050_ (.A(_0716_),
    .B(_0718_),
    .X(_0207_));
 sky130_fd_sc_hd__a22o_2 _2051_ (.A1(\u_motor_control_transport_fsm.seq_reg[14] ),
    .A2(_0962_),
    .B1(_0346_),
    .B2(motor_control_register_map_cfg_seq_base[14]),
    .X(_0719_));
 sky130_fd_sc_hd__and2_2 _2052_ (.A(_0716_),
    .B(_0719_),
    .X(_0208_));
 sky130_fd_sc_hd__a22o_2 _2053_ (.A1(\u_motor_control_transport_fsm.seq_reg[13] ),
    .A2(_0962_),
    .B1(_0346_),
    .B2(motor_control_register_map_cfg_seq_base[13]),
    .X(_0720_));
 sky130_fd_sc_hd__and2_2 _2054_ (.A(_0716_),
    .B(_0720_),
    .X(_0209_));
 sky130_fd_sc_hd__a22o_2 _2055_ (.A1(\u_motor_control_transport_fsm.seq_reg[12] ),
    .A2(_0962_),
    .B1(_0346_),
    .B2(motor_control_register_map_cfg_seq_base[12]),
    .X(_0721_));
 sky130_fd_sc_hd__and2_2 _2056_ (.A(_0716_),
    .B(_0721_),
    .X(_0210_));
 sky130_fd_sc_hd__a22o_2 _2057_ (.A1(\u_motor_control_transport_fsm.seq_reg[11] ),
    .A2(_0962_),
    .B1(_0346_),
    .B2(motor_control_register_map_cfg_seq_base[11]),
    .X(_0722_));
 sky130_fd_sc_hd__and2_2 _2058_ (.A(_0716_),
    .B(_0722_),
    .X(_0211_));
 sky130_fd_sc_hd__a22o_2 _2059_ (.A1(\u_motor_control_transport_fsm.seq_reg[10] ),
    .A2(_0962_),
    .B1(_0346_),
    .B2(motor_control_register_map_cfg_seq_base[10]),
    .X(_0723_));
 sky130_fd_sc_hd__and2_2 _2060_ (.A(_0716_),
    .B(_0723_),
    .X(_0212_));
 sky130_fd_sc_hd__a22o_2 _2061_ (.A1(\u_motor_control_transport_fsm.seq_reg[9] ),
    .A2(_0962_),
    .B1(_0346_),
    .B2(motor_control_register_map_cfg_seq_base[9]),
    .X(_0724_));
 sky130_fd_sc_hd__and2_2 _2062_ (.A(_0716_),
    .B(_0724_),
    .X(_0213_));
 sky130_fd_sc_hd__a22o_2 _2063_ (.A1(\u_motor_control_transport_fsm.seq_reg[8] ),
    .A2(_0962_),
    .B1(_0346_),
    .B2(motor_control_register_map_cfg_seq_base[8]),
    .X(_0725_));
 sky130_fd_sc_hd__and2_2 _2064_ (.A(_0716_),
    .B(_0725_),
    .X(_0214_));
 sky130_fd_sc_hd__a22o_2 _2065_ (.A1(\u_motor_control_transport_fsm.seq_reg[7] ),
    .A2(_0962_),
    .B1(_0346_),
    .B2(motor_control_register_map_cfg_seq_base[7]),
    .X(_0726_));
 sky130_fd_sc_hd__and2_2 _2066_ (.A(_0716_),
    .B(_0726_),
    .X(_0215_));
 sky130_fd_sc_hd__a22o_2 _2067_ (.A1(\u_motor_control_transport_fsm.seq_reg[6] ),
    .A2(_0962_),
    .B1(_0346_),
    .B2(motor_control_register_map_cfg_seq_base[6]),
    .X(_0727_));
 sky130_fd_sc_hd__and2_2 _2068_ (.A(_0716_),
    .B(_0727_),
    .X(_0216_));
 sky130_fd_sc_hd__a22o_2 _2069_ (.A1(\u_motor_control_transport_fsm.seq_reg[5] ),
    .A2(_0962_),
    .B1(_0346_),
    .B2(motor_control_register_map_cfg_seq_base[5]),
    .X(_0728_));
 sky130_fd_sc_hd__and2_2 _2070_ (.A(_0716_),
    .B(_0728_),
    .X(_0217_));
 sky130_fd_sc_hd__a22o_2 _2071_ (.A1(\u_motor_control_transport_fsm.seq_reg[4] ),
    .A2(_0962_),
    .B1(_0346_),
    .B2(motor_control_register_map_cfg_seq_base[4]),
    .X(_0729_));
 sky130_fd_sc_hd__and2_2 _2072_ (.A(_0716_),
    .B(_0729_),
    .X(_0218_));
 sky130_fd_sc_hd__a22o_2 _2073_ (.A1(\u_motor_control_transport_fsm.seq_reg[3] ),
    .A2(_0962_),
    .B1(_0346_),
    .B2(motor_control_register_map_cfg_seq_base[3]),
    .X(_0730_));
 sky130_fd_sc_hd__and2_2 _2074_ (.A(_0716_),
    .B(_0730_),
    .X(_0219_));
 sky130_fd_sc_hd__a22o_2 _2075_ (.A1(\u_motor_control_transport_fsm.seq_reg[2] ),
    .A2(_0962_),
    .B1(_0346_),
    .B2(motor_control_register_map_cfg_seq_base[2]),
    .X(_0731_));
 sky130_fd_sc_hd__and2_2 _2076_ (.A(_0716_),
    .B(_0731_),
    .X(_0220_));
 sky130_fd_sc_hd__a22o_2 _2077_ (.A1(\u_motor_control_transport_fsm.seq_reg[1] ),
    .A2(_0962_),
    .B1(_0346_),
    .B2(motor_control_register_map_cfg_seq_base[1]),
    .X(_0732_));
 sky130_fd_sc_hd__and2_2 _2078_ (.A(_0716_),
    .B(_0732_),
    .X(_0221_));
 sky130_fd_sc_hd__a22o_2 _2079_ (.A1(\u_motor_control_transport_fsm.seq_reg[0] ),
    .A2(_0962_),
    .B1(_0346_),
    .B2(motor_control_register_map_cfg_seq_base[0]),
    .X(_0733_));
 sky130_fd_sc_hd__and2_2 _2080_ (.A(_0716_),
    .B(_0733_),
    .X(_0222_));
 sky130_fd_sc_hd__and2_2 _2081_ (.A(motor_control_register_map_cfg_timeout_limit[15]),
    .B(_0717_),
    .X(_0223_));
 sky130_fd_sc_hd__and2_2 _2082_ (.A(motor_control_register_map_cfg_timeout_limit[14]),
    .B(_0717_),
    .X(_0224_));
 sky130_fd_sc_hd__and2_2 _2083_ (.A(motor_control_register_map_cfg_timeout_limit[13]),
    .B(_0717_),
    .X(_0225_));
 sky130_fd_sc_hd__and2_2 _2084_ (.A(motor_control_register_map_cfg_timeout_limit[12]),
    .B(_0717_),
    .X(_0226_));
 sky130_fd_sc_hd__and2_2 _2085_ (.A(motor_control_register_map_cfg_timeout_limit[11]),
    .B(_0717_),
    .X(_0227_));
 sky130_fd_sc_hd__and2_2 _2086_ (.A(motor_control_register_map_cfg_timeout_limit[10]),
    .B(_0717_),
    .X(_0228_));
 sky130_fd_sc_hd__and2_2 _2087_ (.A(motor_control_register_map_cfg_timeout_limit[9]),
    .B(_0717_),
    .X(_0229_));
 sky130_fd_sc_hd__and2_2 _2088_ (.A(motor_control_register_map_cfg_timeout_limit[8]),
    .B(_0717_),
    .X(_0230_));
 sky130_fd_sc_hd__and2_2 _2089_ (.A(motor_control_register_map_cfg_timeout_limit[7]),
    .B(_0717_),
    .X(_0231_));
 sky130_fd_sc_hd__and2_2 _2090_ (.A(motor_control_register_map_cfg_timeout_limit[6]),
    .B(_0717_),
    .X(_0232_));
 sky130_fd_sc_hd__and2_2 _2091_ (.A(motor_control_register_map_cfg_timeout_limit[5]),
    .B(_0717_),
    .X(_0233_));
 sky130_fd_sc_hd__and2_2 _2092_ (.A(motor_control_register_map_cfg_timeout_limit[4]),
    .B(_0717_),
    .X(_0234_));
 sky130_fd_sc_hd__and2_2 _2093_ (.A(motor_control_register_map_cfg_timeout_limit[3]),
    .B(_0717_),
    .X(_0235_));
 sky130_fd_sc_hd__and2_2 _2094_ (.A(motor_control_register_map_cfg_timeout_limit[2]),
    .B(_0717_),
    .X(_0236_));
 sky130_fd_sc_hd__and2_2 _2095_ (.A(motor_control_register_map_cfg_timeout_limit[1]),
    .B(_0717_),
    .X(_0237_));
 sky130_fd_sc_hd__and2_2 _2096_ (.A(motor_control_register_map_cfg_timeout_limit[0]),
    .B(_0717_),
    .X(_0238_));
 sky130_fd_sc_hd__and2_2 _2097_ (.A(motor_control_register_map_cfg_clamp_min[7]),
    .B(_0717_),
    .X(_0239_));
 sky130_fd_sc_hd__and2_2 _2098_ (.A(motor_control_register_map_cfg_clamp_min[6]),
    .B(_0717_),
    .X(_0240_));
 sky130_fd_sc_hd__and2_2 _2099_ (.A(motor_control_register_map_cfg_clamp_min[5]),
    .B(_0717_),
    .X(_0241_));
 sky130_fd_sc_hd__and2_2 _2100_ (.A(motor_control_register_map_cfg_clamp_min[4]),
    .B(_0717_),
    .X(_0242_));
 sky130_fd_sc_hd__and2_2 _2101_ (.A(motor_control_register_map_cfg_clamp_min[3]),
    .B(_0717_),
    .X(_0243_));
 sky130_fd_sc_hd__and2_2 _2102_ (.A(motor_control_register_map_cfg_clamp_min[2]),
    .B(_0717_),
    .X(_0244_));
 sky130_fd_sc_hd__and2_2 _2103_ (.A(motor_control_register_map_cfg_clamp_min[1]),
    .B(_0717_),
    .X(_0245_));
 sky130_fd_sc_hd__and2_2 _2104_ (.A(motor_control_register_map_cfg_clamp_min[0]),
    .B(_0717_),
    .X(_0246_));
 sky130_fd_sc_hd__and2_2 _2105_ (.A(motor_control_register_map_cfg_clamp_max[7]),
    .B(_0717_),
    .X(_0247_));
 sky130_fd_sc_hd__and2_2 _2106_ (.A(motor_control_register_map_cfg_clamp_max[6]),
    .B(_0717_),
    .X(_0248_));
 sky130_fd_sc_hd__and2_2 _2107_ (.A(motor_control_register_map_cfg_clamp_max[5]),
    .B(_0717_),
    .X(_0249_));
 sky130_fd_sc_hd__and2_2 _2108_ (.A(motor_control_register_map_cfg_clamp_max[4]),
    .B(_0717_),
    .X(_0250_));
 sky130_fd_sc_hd__and2_2 _2109_ (.A(motor_control_register_map_cfg_clamp_max[3]),
    .B(_0717_),
    .X(_0251_));
 sky130_fd_sc_hd__and2_2 _2110_ (.A(motor_control_register_map_cfg_clamp_max[2]),
    .B(_0717_),
    .X(_0252_));
 sky130_fd_sc_hd__and2_2 _2111_ (.A(motor_control_register_map_cfg_clamp_max[1]),
    .B(_0717_),
    .X(_0253_));
 sky130_fd_sc_hd__and2_2 _2112_ (.A(motor_control_register_map_cfg_clamp_max[0]),
    .B(_0717_),
    .X(_0254_));
 sky130_fd_sc_hd__o21a_2 _2113_ (.A1(\u_motor_control_transport_fsm.state[2] ),
    .A2(_0346_),
    .B1(reset_n),
    .X(_0255_));
 sky130_fd_sc_hd__sdfxtp_2 _2115_ (.CLK(clk),
    .D(_0008_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2116_ (.CLK(clk),
    .D(_0009_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2117_ (.CLK(clk),
    .D(_0010_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2118_ (.CLK(clk),
    .D(_0011_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2119_ (.CLK(clk),
    .D(_0012_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2120_ (.CLK(clk),
    .D(_0013_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2121_ (.CLK(clk),
    .D(_0014_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2122_ (.CLK(clk),
    .D(_0015_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2123_ (.CLK(clk),
    .D(_0016_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2124_ (.CLK(clk),
    .D(_0017_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2125_ (.CLK(clk),
    .D(_0018_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2126_ (.CLK(clk),
    .D(_0019_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2127_ (.CLK(clk),
    .D(_0020_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2128_ (.CLK(clk),
    .D(_0021_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2129_ (.CLK(clk),
    .D(_0022_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2131_ (.CLK(clk),
    .D(_0024_),
    .Q(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _2130_ (.CLK(clk),
    .D(_0023_),
    .RESET_B(reset_n),
    .SCD(scan_in[0]),
    .SCE(scan_en),
    .Q(motor_control_register_map_cfg_enable_from_u_motor_control_register_map));
 sky130_fd_sc_hd__sdfxtp_2 _2132_ (.CLK(clk),
    .D(_0025_),
    .Q(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2133_ (.CLK(clk),
    .D(_0026_),
    .Q(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2134_ (.CLK(clk),
    .D(_0027_),
    .Q(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2135_ (.CLK(clk),
    .D(_0028_),
    .Q(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2136_ (.CLK(clk),
    .D(_0029_),
    .Q(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2137_ (.CLK(clk),
    .D(_0030_),
    .Q(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2138_ (.CLK(clk),
    .D(_0031_),
    .Q(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2139_ (.CLK(clk),
    .D(_0032_),
    .Q(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2140_ (.CLK(clk),
    .D(_0033_),
    .Q(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2141_ (.CLK(clk),
    .D(_0034_),
    .Q(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2142_ (.CLK(clk),
    .D(_0035_),
    .Q(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2143_ (.CLK(clk),
    .D(_0036_),
    .Q(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2144_ (.CLK(clk),
    .D(_0037_),
    .Q(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2145_ (.CLK(clk),
    .D(_0038_),
    .Q(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2146_ (.CLK(clk),
    .D(_0039_),
    .Q(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2147_ (.CLK(clk),
    .D(_0040_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2148_ (.CLK(clk),
    .D(_0041_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2149_ (.CLK(clk),
    .D(_0042_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2150_ (.CLK(clk),
    .D(_0043_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2151_ (.CLK(clk),
    .D(_0044_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2152_ (.CLK(clk),
    .D(_0045_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2153_ (.CLK(clk),
    .D(_0046_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2154_ (.CLK(clk),
    .D(_0047_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2155_ (.CLK(clk),
    .D(_0048_),
    .Q(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[8] ));
 sky130_fd_sc_hd__sdfxtp_2 _2156_ (.CLK(clk),
    .D(_0049_),
    .Q(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[9] ));
 sky130_fd_sc_hd__sdfxtp_2 _2157_ (.CLK(clk),
    .D(_0050_),
    .Q(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[10] ));
 sky130_fd_sc_hd__sdfxtp_2 _2158_ (.CLK(clk),
    .D(_0051_),
    .Q(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[11] ));
 sky130_fd_sc_hd__sdfxtp_2 _2159_ (.CLK(clk),
    .D(_0052_),
    .Q(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[12] ));
 sky130_fd_sc_hd__sdfxtp_2 _2160_ (.CLK(clk),
    .D(_0053_),
    .Q(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[13] ));
 sky130_fd_sc_hd__sdfxtp_2 _2161_ (.CLK(clk),
    .D(_0054_),
    .Q(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[14] ));
 sky130_fd_sc_hd__sdfxtp_2 _2162_ (.CLK(clk),
    .D(_0055_),
    .Q(\motor_control_register_map_cfg_timeout_limit_from_u_motor_control_register_map[15] ));
 sky130_fd_sc_hd__sdfxtp_2 _2163_ (.CLK(clk),
    .D(_0056_),
    .Q(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[8] ));
 sky130_fd_sc_hd__sdfxtp_2 _2164_ (.CLK(clk),
    .D(_0057_),
    .Q(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[9] ));
 sky130_fd_sc_hd__sdfxtp_2 _2165_ (.CLK(clk),
    .D(_0058_),
    .Q(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[10] ));
 sky130_fd_sc_hd__sdfxtp_2 _2166_ (.CLK(clk),
    .D(_0059_),
    .Q(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[11] ));
 sky130_fd_sc_hd__sdfxtp_2 _2167_ (.CLK(clk),
    .D(_0060_),
    .Q(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[12] ));
 sky130_fd_sc_hd__sdfxtp_2 _2168_ (.CLK(clk),
    .D(_0061_),
    .Q(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[13] ));
 sky130_fd_sc_hd__sdfxtp_2 _2169_ (.CLK(clk),
    .D(_0062_),
    .Q(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[14] ));
 sky130_fd_sc_hd__sdfxtp_2 _2170_ (.CLK(clk),
    .D(_0063_),
    .Q(\motor_control_register_map_cfg_seq_base_from_u_motor_control_register_map[15] ));
 sky130_fd_sc_hd__sdfxtp_2 _2171_ (.CLK(clk),
    .D(_0064_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[24] ));
 sky130_fd_sc_hd__sdfxtp_2 _2172_ (.CLK(clk),
    .D(_0065_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[25] ));
 sky130_fd_sc_hd__sdfxtp_2 _2173_ (.CLK(clk),
    .D(_0066_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[26] ));
 sky130_fd_sc_hd__sdfxtp_2 _2174_ (.CLK(clk),
    .D(_0067_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[27] ));
 sky130_fd_sc_hd__sdfxtp_2 _2175_ (.CLK(clk),
    .D(_0068_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[28] ));
 sky130_fd_sc_hd__sdfxtp_2 _2176_ (.CLK(clk),
    .D(_0069_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[29] ));
 sky130_fd_sc_hd__sdfxtp_2 _2177_ (.CLK(clk),
    .D(_0070_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[30] ));
 sky130_fd_sc_hd__sdfxtp_2 _2178_ (.CLK(clk),
    .D(_0071_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[31] ));
 sky130_fd_sc_hd__sdfxtp_2 _2179_ (.CLK(clk),
    .D(_0072_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[16] ));
 sky130_fd_sc_hd__sdfxtp_2 _2180_ (.CLK(clk),
    .D(_0073_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[17] ));
 sky130_fd_sc_hd__sdfxtp_2 _2181_ (.CLK(clk),
    .D(_0074_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[18] ));
 sky130_fd_sc_hd__sdfxtp_2 _2182_ (.CLK(clk),
    .D(_0075_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[19] ));
 sky130_fd_sc_hd__sdfxtp_2 _2183_ (.CLK(clk),
    .D(_0076_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[20] ));
 sky130_fd_sc_hd__sdfxtp_2 _2184_ (.CLK(clk),
    .D(_0077_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[21] ));
 sky130_fd_sc_hd__sdfxtp_2 _2185_ (.CLK(clk),
    .D(_0078_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[22] ));
 sky130_fd_sc_hd__sdfxtp_2 _2186_ (.CLK(clk),
    .D(_0079_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[23] ));
 sky130_fd_sc_hd__sdfxtp_2 _2187_ (.CLK(clk),
    .D(_0080_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[8] ));
 sky130_fd_sc_hd__sdfxtp_2 _2188_ (.CLK(clk),
    .D(_0081_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[9] ));
 sky130_fd_sc_hd__sdfxtp_2 _2189_ (.CLK(clk),
    .D(_0082_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[10] ));
 sky130_fd_sc_hd__sdfxtp_2 _2190_ (.CLK(clk),
    .D(_0083_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[11] ));
 sky130_fd_sc_hd__sdfxtp_2 _2191_ (.CLK(clk),
    .D(_0084_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[12] ));
 sky130_fd_sc_hd__sdfxtp_2 _2192_ (.CLK(clk),
    .D(_0085_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[13] ));
 sky130_fd_sc_hd__sdfxtp_2 _2193_ (.CLK(clk),
    .D(_0086_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[14] ));
 sky130_fd_sc_hd__sdfxtp_2 _2194_ (.CLK(clk),
    .D(_0087_),
    .Q(\motor_control_register_map_cfg_clamp_min_from_u_motor_control_register_map[15] ));
 sky130_fd_sc_hd__sdfxtp_2 _2195_ (.CLK(clk),
    .D(_0088_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[24] ));
 sky130_fd_sc_hd__sdfxtp_2 _2196_ (.CLK(clk),
    .D(_0089_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[25] ));
 sky130_fd_sc_hd__sdfxtp_2 _2197_ (.CLK(clk),
    .D(_0090_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[26] ));
 sky130_fd_sc_hd__sdfxtp_2 _2198_ (.CLK(clk),
    .D(_0091_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[27] ));
 sky130_fd_sc_hd__sdfxtp_2 _2199_ (.CLK(clk),
    .D(_0092_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[28] ));
 sky130_fd_sc_hd__sdfxtp_2 _2200_ (.CLK(clk),
    .D(_0093_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[29] ));
 sky130_fd_sc_hd__sdfxtp_2 _2201_ (.CLK(clk),
    .D(_0094_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[30] ));
 sky130_fd_sc_hd__sdfxtp_2 _2202_ (.CLK(clk),
    .D(_0095_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[31] ));
 sky130_fd_sc_hd__sdfxtp_2 _2203_ (.CLK(clk),
    .D(_0096_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[16] ));
 sky130_fd_sc_hd__sdfxtp_2 _2204_ (.CLK(clk),
    .D(_0097_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[17] ));
 sky130_fd_sc_hd__sdfxtp_2 _2205_ (.CLK(clk),
    .D(_0098_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[18] ));
 sky130_fd_sc_hd__sdfxtp_2 _2206_ (.CLK(clk),
    .D(_0099_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[19] ));
 sky130_fd_sc_hd__sdfxtp_2 _2207_ (.CLK(clk),
    .D(_0100_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[20] ));
 sky130_fd_sc_hd__sdfxtp_2 _2208_ (.CLK(clk),
    .D(_0101_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[21] ));
 sky130_fd_sc_hd__sdfxtp_2 _2209_ (.CLK(clk),
    .D(_0102_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[22] ));
 sky130_fd_sc_hd__sdfxtp_2 _2210_ (.CLK(clk),
    .D(_0103_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[23] ));
 sky130_fd_sc_hd__sdfxtp_2 _2211_ (.CLK(clk),
    .D(_0104_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[8] ));
 sky130_fd_sc_hd__sdfxtp_2 _2212_ (.CLK(clk),
    .D(_0105_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[9] ));
 sky130_fd_sc_hd__sdfxtp_2 _2213_ (.CLK(clk),
    .D(_0106_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[10] ));
 sky130_fd_sc_hd__sdfxtp_2 _2214_ (.CLK(clk),
    .D(_0107_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[11] ));
 sky130_fd_sc_hd__sdfxtp_2 _2215_ (.CLK(clk),
    .D(_0108_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[12] ));
 sky130_fd_sc_hd__sdfxtp_2 _2216_ (.CLK(clk),
    .D(_0109_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[13] ));
 sky130_fd_sc_hd__sdfxtp_2 _2217_ (.CLK(clk),
    .D(_0110_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[14] ));
 sky130_fd_sc_hd__sdfxtp_2 _2218_ (.CLK(clk),
    .D(_0111_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[15] ));
 sky130_fd_sc_hd__sdfxtp_2 _2219_ (.CLK(clk),
    .D(_0112_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[24] ));
 sky130_fd_sc_hd__sdfxtp_2 _2220_ (.CLK(clk),
    .D(_0113_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[25] ));
 sky130_fd_sc_hd__sdfxtp_2 _2221_ (.CLK(clk),
    .D(_0114_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[26] ));
 sky130_fd_sc_hd__sdfxtp_2 _2222_ (.CLK(clk),
    .D(_0115_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[27] ));
 sky130_fd_sc_hd__sdfxtp_2 _2223_ (.CLK(clk),
    .D(_0116_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[28] ));
 sky130_fd_sc_hd__sdfxtp_2 _2224_ (.CLK(clk),
    .D(_0117_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[29] ));
 sky130_fd_sc_hd__sdfxtp_2 _2225_ (.CLK(clk),
    .D(_0118_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[30] ));
 sky130_fd_sc_hd__sdfxtp_2 _2226_ (.CLK(clk),
    .D(_0119_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[31] ));
 sky130_fd_sc_hd__sdfxtp_2 _2227_ (.CLK(clk),
    .D(_0120_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[16] ));
 sky130_fd_sc_hd__sdfxtp_2 _2228_ (.CLK(clk),
    .D(_0121_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[17] ));
 sky130_fd_sc_hd__sdfxtp_2 _2229_ (.CLK(clk),
    .D(_0122_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[18] ));
 sky130_fd_sc_hd__sdfxtp_2 _2230_ (.CLK(clk),
    .D(_0123_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[19] ));
 sky130_fd_sc_hd__sdfxtp_2 _2231_ (.CLK(clk),
    .D(_0124_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[20] ));
 sky130_fd_sc_hd__sdfxtp_2 _2232_ (.CLK(clk),
    .D(_0125_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[21] ));
 sky130_fd_sc_hd__sdfxtp_2 _2233_ (.CLK(clk),
    .D(_0126_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[22] ));
 sky130_fd_sc_hd__sdfxtp_2 _2234_ (.CLK(clk),
    .D(_0127_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[23] ));
 sky130_fd_sc_hd__sdfxtp_2 _2235_ (.CLK(clk),
    .D(_0128_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[8] ));
 sky130_fd_sc_hd__sdfxtp_2 _2236_ (.CLK(clk),
    .D(_0129_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[9] ));
 sky130_fd_sc_hd__sdfxtp_2 _2237_ (.CLK(clk),
    .D(_0130_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[10] ));
 sky130_fd_sc_hd__sdfxtp_2 _2238_ (.CLK(clk),
    .D(_0131_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[11] ));
 sky130_fd_sc_hd__sdfxtp_2 _2239_ (.CLK(clk),
    .D(_0132_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[12] ));
 sky130_fd_sc_hd__sdfxtp_2 _2240_ (.CLK(clk),
    .D(_0133_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[13] ));
 sky130_fd_sc_hd__sdfxtp_2 _2241_ (.CLK(clk),
    .D(_0134_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[14] ));
 sky130_fd_sc_hd__sdfxtp_2 _2242_ (.CLK(clk),
    .D(_0135_),
    .Q(\motor_control_register_map_cfg_fallback_cmd_from_u_motor_control_register_map[15] ));
 sky130_fd_sc_hd__sdfxtp_2 _2243_ (.CLK(clk),
    .D(_0001_),
    .Q(\u_motor_control_transport_fsm.state[0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2244_ (.CLK(clk),
    .D(_0000_),
    .Q(\u_motor_control_transport_fsm.state[1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2245_ (.CLK(clk),
    .D(_0002_),
    .Q(\u_motor_control_transport_fsm.state[2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2246_ (.CLK(clk),
    .D(_0003_),
    .Q(\u_motor_control_transport_fsm.state[3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2247_ (.CLK(clk),
    .D(_0004_),
    .Q(\u_motor_control_transport_fsm.state[4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2248_ (.CLK(clk),
    .D(_0005_),
    .Q(\u_motor_control_transport_fsm.state[5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2249_ (.CLK(clk),
    .D(_0006_),
    .Q(\u_motor_control_transport_fsm.rsp_ready_next ));
 sky130_fd_sc_hd__sdfxtp_2 _2250_ (.CLK(clk),
    .D(_0136_),
    .Q(\u_motor_control_transport_fsm.timeout_cnt[0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2251_ (.CLK(clk),
    .D(_0137_),
    .Q(\u_motor_control_transport_fsm.timeout_cnt[1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2252_ (.CLK(clk),
    .D(_0138_),
    .Q(\u_motor_control_transport_fsm.timeout_cnt[2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2253_ (.CLK(clk),
    .D(_0139_),
    .Q(\u_motor_control_transport_fsm.timeout_cnt[3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2254_ (.CLK(clk),
    .D(_0140_),
    .Q(\u_motor_control_transport_fsm.timeout_cnt[4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2255_ (.CLK(clk),
    .D(_0141_),
    .Q(\u_motor_control_transport_fsm.timeout_cnt[5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2256_ (.CLK(clk),
    .D(_0142_),
    .Q(\u_motor_control_transport_fsm.timeout_cnt[6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2257_ (.CLK(clk),
    .D(_0143_),
    .Q(\u_motor_control_transport_fsm.timeout_cnt[7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2258_ (.CLK(clk),
    .D(_0144_),
    .Q(\u_motor_control_transport_fsm.timeout_cnt[8] ));
 sky130_fd_sc_hd__sdfxtp_2 _2259_ (.CLK(clk),
    .D(_0145_),
    .Q(\u_motor_control_transport_fsm.timeout_cnt[9] ));
 sky130_fd_sc_hd__sdfxtp_2 _2260_ (.CLK(clk),
    .D(_0146_),
    .Q(\u_motor_control_transport_fsm.timeout_cnt[10] ));
 sky130_fd_sc_hd__sdfxtp_2 _2261_ (.CLK(clk),
    .D(_0147_),
    .Q(\u_motor_control_transport_fsm.timeout_cnt[11] ));
 sky130_fd_sc_hd__sdfxtp_2 _2262_ (.CLK(clk),
    .D(_0148_),
    .Q(\u_motor_control_transport_fsm.timeout_cnt[12] ));
 sky130_fd_sc_hd__sdfxtp_2 _2263_ (.CLK(clk),
    .D(_0149_),
    .Q(\u_motor_control_transport_fsm.timeout_cnt[13] ));
 sky130_fd_sc_hd__sdfxtp_2 _2264_ (.CLK(clk),
    .D(_0150_),
    .Q(\u_motor_control_transport_fsm.timeout_cnt[14] ));
 sky130_fd_sc_hd__sdfxtp_2 _2265_ (.CLK(clk),
    .D(_0151_),
    .Q(\u_motor_control_transport_fsm.timeout_cnt[15] ));
 sky130_fd_sc_hd__sdfxtp_2 _2266_ (.CLK(clk),
    .D(_0152_),
    .Q(\u_motor_control_transport_fsm.seq_reg[0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2267_ (.CLK(clk),
    .D(_0153_),
    .Q(\u_motor_control_transport_fsm.seq_reg[1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2268_ (.CLK(clk),
    .D(_0154_),
    .Q(\u_motor_control_transport_fsm.seq_reg[2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2269_ (.CLK(clk),
    .D(_0155_),
    .Q(\u_motor_control_transport_fsm.seq_reg[3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2270_ (.CLK(clk),
    .D(_0156_),
    .Q(\u_motor_control_transport_fsm.seq_reg[4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2271_ (.CLK(clk),
    .D(_0157_),
    .Q(\u_motor_control_transport_fsm.seq_reg[5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2272_ (.CLK(clk),
    .D(_0158_),
    .Q(\u_motor_control_transport_fsm.seq_reg[6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2273_ (.CLK(clk),
    .D(_0159_),
    .Q(\u_motor_control_transport_fsm.seq_reg[7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2274_ (.CLK(clk),
    .D(_0160_),
    .Q(\u_motor_control_transport_fsm.seq_reg[8] ));
 sky130_fd_sc_hd__sdfxtp_2 _2275_ (.CLK(clk),
    .D(_0161_),
    .Q(\u_motor_control_transport_fsm.seq_reg[9] ));
 sky130_fd_sc_hd__sdfxtp_2 _2276_ (.CLK(clk),
    .D(_0162_),
    .Q(\u_motor_control_transport_fsm.seq_reg[10] ));
 sky130_fd_sc_hd__sdfxtp_2 _2277_ (.CLK(clk),
    .D(_0163_),
    .Q(\u_motor_control_transport_fsm.seq_reg[11] ));
 sky130_fd_sc_hd__sdfxtp_2 _2278_ (.CLK(clk),
    .D(_0164_),
    .Q(\u_motor_control_transport_fsm.seq_reg[12] ));
 sky130_fd_sc_hd__sdfxtp_2 _2279_ (.CLK(clk),
    .D(_0165_),
    .Q(\u_motor_control_transport_fsm.seq_reg[13] ));
 sky130_fd_sc_hd__sdfxtp_2 _2280_ (.CLK(clk),
    .D(_0166_),
    .Q(\u_motor_control_transport_fsm.seq_reg[14] ));
 sky130_fd_sc_hd__sdfxtp_2 _2281_ (.CLK(clk),
    .D(_0167_),
    .Q(\u_motor_control_transport_fsm.seq_reg[15] ));
 sky130_fd_sc_hd__sdfxtp_2 _2282_ (.CLK(clk),
    .D(_0168_),
    .Q(act_cmd[0]));
 sky130_fd_sc_hd__sdfxtp_2 _2283_ (.CLK(clk),
    .D(_0169_),
    .Q(act_cmd[1]));
 sky130_fd_sc_hd__sdfxtp_2 _2284_ (.CLK(clk),
    .D(_0170_),
    .Q(act_cmd[2]));
 sky130_fd_sc_hd__sdfxtp_2 _2285_ (.CLK(clk),
    .D(_0171_),
    .Q(act_cmd[3]));
 sky130_fd_sc_hd__sdfxtp_2 _2286_ (.CLK(clk),
    .D(_0172_),
    .Q(act_cmd[4]));
 sky130_fd_sc_hd__sdfxtp_2 _2287_ (.CLK(clk),
    .D(_0173_),
    .Q(act_cmd[5]));
 sky130_fd_sc_hd__sdfxtp_2 _2288_ (.CLK(clk),
    .D(_0174_),
    .Q(act_cmd[6]));
 sky130_fd_sc_hd__sdfxtp_2 _2289_ (.CLK(clk),
    .D(_0175_),
    .Q(act_cmd[7]));
 sky130_fd_sc_hd__sdfxtp_2 _2290_ (.CLK(clk),
    .D(_0176_),
    .Q(act_cmd[8]));
 sky130_fd_sc_hd__sdfxtp_2 _2291_ (.CLK(clk),
    .D(_0177_),
    .Q(act_cmd[9]));
 sky130_fd_sc_hd__sdfxtp_2 _2292_ (.CLK(clk),
    .D(_0178_),
    .Q(act_cmd[10]));
 sky130_fd_sc_hd__sdfxtp_2 _2293_ (.CLK(clk),
    .D(_0179_),
    .Q(act_cmd[11]));
 sky130_fd_sc_hd__sdfxtp_2 _2294_ (.CLK(clk),
    .D(_0180_),
    .Q(act_cmd[12]));
 sky130_fd_sc_hd__sdfxtp_2 _2295_ (.CLK(clk),
    .D(_0181_),
    .Q(act_cmd[13]));
 sky130_fd_sc_hd__sdfxtp_2 _2296_ (.CLK(clk),
    .D(_0182_),
    .Q(act_cmd[14]));
 sky130_fd_sc_hd__sdfxtp_2 _2297_ (.CLK(clk),
    .D(_0183_),
    .Q(act_cmd[15]));
 sky130_fd_sc_hd__sdfxtp_2 _2298_ (.CLK(clk),
    .D(_0184_),
    .Q(act_cmd[16]));
 sky130_fd_sc_hd__sdfxtp_2 _2299_ (.CLK(clk),
    .D(_0185_),
    .Q(act_cmd[17]));
 sky130_fd_sc_hd__sdfxtp_2 _2300_ (.CLK(clk),
    .D(_0186_),
    .Q(act_cmd[18]));
 sky130_fd_sc_hd__sdfxtp_2 _2301_ (.CLK(clk),
    .D(_0187_),
    .Q(act_cmd[19]));
 sky130_fd_sc_hd__sdfxtp_2 _2302_ (.CLK(clk),
    .D(_0188_),
    .Q(act_cmd[20]));
 sky130_fd_sc_hd__sdfxtp_2 _2303_ (.CLK(clk),
    .D(_0189_),
    .Q(act_cmd[21]));
 sky130_fd_sc_hd__sdfxtp_2 _2304_ (.CLK(clk),
    .D(_0190_),
    .Q(act_cmd[22]));
 sky130_fd_sc_hd__sdfxtp_2 _2305_ (.CLK(clk),
    .D(_0191_),
    .Q(act_cmd[23]));
 sky130_fd_sc_hd__sdfxtp_2 _2306_ (.CLK(clk),
    .D(_0192_),
    .Q(act_cmd[24]));
 sky130_fd_sc_hd__sdfxtp_2 _2307_ (.CLK(clk),
    .D(_0193_),
    .Q(act_cmd[25]));
 sky130_fd_sc_hd__sdfxtp_2 _2308_ (.CLK(clk),
    .D(_0194_),
    .Q(act_cmd[26]));
 sky130_fd_sc_hd__sdfxtp_2 _2309_ (.CLK(clk),
    .D(_0195_),
    .Q(act_cmd[27]));
 sky130_fd_sc_hd__sdfxtp_2 _2310_ (.CLK(clk),
    .D(_0196_),
    .Q(act_cmd[28]));
 sky130_fd_sc_hd__sdfxtp_2 _2311_ (.CLK(clk),
    .D(_0197_),
    .Q(act_cmd[29]));
 sky130_fd_sc_hd__sdfxtp_2 _2312_ (.CLK(clk),
    .D(_0198_),
    .Q(act_cmd[30]));
 sky130_fd_sc_hd__sdfxtp_2 _2313_ (.CLK(clk),
    .D(_0199_),
    .Q(act_cmd[31]));
 sky130_fd_sc_hd__sdfxtp_2 _2314_ (.CLK(clk),
    .D(_0200_),
    .Q(act_cmd_fault));
 sky130_fd_sc_hd__sdfxtp_2 _2315_ (.CLK(clk),
    .D(_0201_),
    .Q(act_cmd_valid));
 sky130_fd_sc_hd__sdfxtp_2 _2316_ (.CLK(clk),
    .D(_0202_),
    .Q(rsp_ready));
 sky130_fd_sc_hd__sdfxtp_2 _2317_ (.CLK(clk),
    .D(_0203_),
    .Q(motor_control_register_map_cfg_safety_override_from_u_motor_control_register_map));
 sky130_fd_sc_hd__sdfxtp_2 _2318_ (.CLK(clk),
    .D(_0204_),
    .Q(motor_control_transport_fsm_status_fault_from_u_motor_control_transport_fsm));
 sky130_fd_sc_hd__sdfxtp_2 _2319_ (.CLK(clk),
    .D(_0205_),
    .Q(req_data[63]));
 sky130_fd_sc_hd__sdfxtp_2 _2320_ (.CLK(clk),
    .D(_0206_),
    .Q(req_data[62]));
 sky130_fd_sc_hd__sdfxtp_2 _2321_ (.CLK(clk),
    .D(_0207_),
    .Q(req_data[61]));
 sky130_fd_sc_hd__sdfxtp_2 _2322_ (.CLK(clk),
    .D(_0208_),
    .Q(req_data[60]));
 sky130_fd_sc_hd__sdfxtp_2 _2323_ (.CLK(clk),
    .D(_0209_),
    .Q(req_data[59]));
 sky130_fd_sc_hd__sdfxtp_2 _2324_ (.CLK(clk),
    .D(_0210_),
    .Q(req_data[58]));
 sky130_fd_sc_hd__sdfxtp_2 _2325_ (.CLK(clk),
    .D(_0211_),
    .Q(req_data[57]));
 sky130_fd_sc_hd__sdfxtp_2 _2326_ (.CLK(clk),
    .D(_0212_),
    .Q(req_data[56]));
 sky130_fd_sc_hd__sdfxtp_2 _2327_ (.CLK(clk),
    .D(_0213_),
    .Q(req_data[55]));
 sky130_fd_sc_hd__sdfxtp_2 _2328_ (.CLK(clk),
    .D(_0214_),
    .Q(req_data[54]));
 sky130_fd_sc_hd__sdfxtp_2 _2329_ (.CLK(clk),
    .D(_0215_),
    .Q(req_data[53]));
 sky130_fd_sc_hd__sdfxtp_2 _2330_ (.CLK(clk),
    .D(_0216_),
    .Q(req_data[52]));
 sky130_fd_sc_hd__sdfxtp_2 _2331_ (.CLK(clk),
    .D(_0217_),
    .Q(req_data[51]));
 sky130_fd_sc_hd__sdfxtp_2 _2332_ (.CLK(clk),
    .D(_0218_),
    .Q(req_data[50]));
 sky130_fd_sc_hd__sdfxtp_2 _2333_ (.CLK(clk),
    .D(_0219_),
    .Q(req_data[49]));
 sky130_fd_sc_hd__sdfxtp_2 _2334_ (.CLK(clk),
    .D(_0220_),
    .Q(req_data[48]));
 sky130_fd_sc_hd__sdfxtp_2 _2335_ (.CLK(clk),
    .D(_0221_),
    .Q(req_data[47]));
 sky130_fd_sc_hd__sdfxtp_2 _2336_ (.CLK(clk),
    .D(_0222_),
    .Q(req_data[46]));
 sky130_fd_sc_hd__sdfxtp_2 _2337_ (.CLK(clk),
    .D(_0223_),
    .Q(req_data[45]));
 sky130_fd_sc_hd__sdfxtp_2 _2338_ (.CLK(clk),
    .D(_0224_),
    .Q(req_data[44]));
 sky130_fd_sc_hd__sdfxtp_2 _2339_ (.CLK(clk),
    .D(_0225_),
    .Q(req_data[43]));
 sky130_fd_sc_hd__sdfxtp_2 _2340_ (.CLK(clk),
    .D(_0226_),
    .Q(req_data[42]));
 sky130_fd_sc_hd__sdfxtp_2 _2341_ (.CLK(clk),
    .D(_0227_),
    .Q(req_data[41]));
 sky130_fd_sc_hd__sdfxtp_2 _2342_ (.CLK(clk),
    .D(_0228_),
    .Q(req_data[40]));
 sky130_fd_sc_hd__sdfxtp_2 _2343_ (.CLK(clk),
    .D(_0229_),
    .Q(req_data[39]));
 sky130_fd_sc_hd__sdfxtp_2 _2344_ (.CLK(clk),
    .D(_0230_),
    .Q(req_data[38]));
 sky130_fd_sc_hd__sdfxtp_2 _2345_ (.CLK(clk),
    .D(_0231_),
    .Q(req_data[37]));
 sky130_fd_sc_hd__sdfxtp_2 _2346_ (.CLK(clk),
    .D(_0232_),
    .Q(req_data[36]));
 sky130_fd_sc_hd__sdfxtp_2 _2347_ (.CLK(clk),
    .D(_0233_),
    .Q(req_data[35]));
 sky130_fd_sc_hd__sdfxtp_2 _2348_ (.CLK(clk),
    .D(_0234_),
    .Q(req_data[34]));
 sky130_fd_sc_hd__sdfxtp_2 _2349_ (.CLK(clk),
    .D(_0235_),
    .Q(req_data[33]));
 sky130_fd_sc_hd__sdfxtp_2 _2350_ (.CLK(clk),
    .D(_0236_),
    .Q(req_data[32]));
 sky130_fd_sc_hd__sdfxtp_2 _2351_ (.CLK(clk),
    .D(_0237_),
    .Q(req_data[31]));
 sky130_fd_sc_hd__sdfxtp_2 _2352_ (.CLK(clk),
    .D(_0238_),
    .Q(req_data[30]));
 sky130_fd_sc_hd__sdfxtp_2 _2353_ (.CLK(clk),
    .D(_0239_),
    .Q(req_data[29]));
 sky130_fd_sc_hd__sdfxtp_2 _2354_ (.CLK(clk),
    .D(_0240_),
    .Q(req_data[28]));
 sky130_fd_sc_hd__sdfxtp_2 _2355_ (.CLK(clk),
    .D(_0241_),
    .Q(req_data[27]));
 sky130_fd_sc_hd__sdfxtp_2 _2356_ (.CLK(clk),
    .D(_0242_),
    .Q(req_data[26]));
 sky130_fd_sc_hd__sdfxtp_2 _2357_ (.CLK(clk),
    .D(_0243_),
    .Q(req_data[25]));
 sky130_fd_sc_hd__sdfxtp_2 _2358_ (.CLK(clk),
    .D(_0244_),
    .Q(req_data[24]));
 sky130_fd_sc_hd__sdfxtp_2 _2359_ (.CLK(clk),
    .D(_0245_),
    .Q(req_data[23]));
 sky130_fd_sc_hd__sdfxtp_2 _2360_ (.CLK(clk),
    .D(_0246_),
    .Q(req_data[22]));
 sky130_fd_sc_hd__sdfxtp_2 _2361_ (.CLK(clk),
    .D(_0247_),
    .Q(req_data[21]));
 sky130_fd_sc_hd__sdfxtp_2 _2362_ (.CLK(clk),
    .D(_0248_),
    .Q(req_data[20]));
 sky130_fd_sc_hd__sdfxtp_2 _2363_ (.CLK(clk),
    .D(_0249_),
    .Q(req_data[19]));
 sky130_fd_sc_hd__sdfxtp_2 _2364_ (.CLK(clk),
    .D(_0250_),
    .Q(req_data[18]));
 sky130_fd_sc_hd__sdfxtp_2 _2365_ (.CLK(clk),
    .D(_0251_),
    .Q(req_data[17]));
 sky130_fd_sc_hd__sdfxtp_2 _2366_ (.CLK(clk),
    .D(_0252_),
    .Q(req_data[16]));
 sky130_fd_sc_hd__sdfxtp_2 _2367_ (.CLK(clk),
    .D(_0253_),
    .Q(req_data[15]));
 sky130_fd_sc_hd__sdfxtp_2 _2368_ (.CLK(clk),
    .D(_0254_),
    .Q(req_data[14]));
 sky130_fd_sc_hd__sdfxtp_2 _2369_ (.CLK(clk),
    .D(_0255_),
    .Q(req_valid));
 sky130_fd_sc_hd__conb_1 _2370_ (.LO(reg_rdata[16]));
 sky130_fd_sc_hd__conb_1 _2371_ (.LO(reg_rdata[17]));
 sky130_fd_sc_hd__conb_1 _2372_ (.LO(reg_rdata[18]));
 sky130_fd_sc_hd__conb_1 _2373_ (.LO(reg_rdata[19]));
 sky130_fd_sc_hd__conb_1 _2374_ (.LO(reg_rdata[20]));
 sky130_fd_sc_hd__conb_1 _2375_ (.LO(reg_rdata[21]));
 sky130_fd_sc_hd__conb_1 _2376_ (.LO(reg_rdata[22]));
 sky130_fd_sc_hd__conb_1 _2377_ (.LO(reg_rdata[23]));
 sky130_fd_sc_hd__conb_1 _2378_ (.LO(reg_rdata[24]));
 sky130_fd_sc_hd__conb_1 _2379_ (.LO(reg_rdata[25]));
 sky130_fd_sc_hd__conb_1 _2380_ (.LO(reg_rdata[26]));
 sky130_fd_sc_hd__conb_1 _2381_ (.LO(reg_rdata[27]));
 sky130_fd_sc_hd__conb_1 _2382_ (.LO(reg_rdata[28]));
 sky130_fd_sc_hd__conb_1 _2383_ (.LO(reg_rdata[29]));
 sky130_fd_sc_hd__conb_1 _2384_ (.LO(reg_rdata[30]));
 sky130_fd_sc_hd__conb_1 _2385_ (.LO(reg_rdata[31]));
 sky130_fd_sc_hd__conb_1 _2386_ (.LO(reg_rdata[32]));
 sky130_fd_sc_hd__conb_1 _2387_ (.LO(reg_rdata[33]));
 sky130_fd_sc_hd__conb_1 _2388_ (.LO(reg_rdata[34]));
 sky130_fd_sc_hd__conb_1 _2389_ (.LO(reg_rdata[35]));
 sky130_fd_sc_hd__conb_1 _2390_ (.LO(reg_rdata[36]));
 sky130_fd_sc_hd__conb_1 _2391_ (.LO(reg_rdata[37]));
 sky130_fd_sc_hd__conb_1 _2392_ (.LO(reg_rdata[38]));
 sky130_fd_sc_hd__conb_1 _2393_ (.LO(reg_rdata[39]));
 sky130_fd_sc_hd__conb_1 _2394_ (.LO(reg_rdata[40]));
 sky130_fd_sc_hd__conb_1 _2395_ (.LO(reg_rdata[41]));
 sky130_fd_sc_hd__conb_1 _2396_ (.LO(reg_rdata[42]));
 sky130_fd_sc_hd__conb_1 _2397_ (.LO(reg_rdata[43]));
 sky130_fd_sc_hd__conb_1 _2398_ (.LO(reg_rdata[44]));
 sky130_fd_sc_hd__conb_1 _2399_ (.LO(reg_rdata[45]));
 sky130_fd_sc_hd__conb_1 _2400_ (.LO(reg_rdata[46]));
 sky130_fd_sc_hd__conb_1 _2401_ (.LO(reg_rdata[47]));
 sky130_fd_sc_hd__conb_1 _2402_ (.LO(reg_rdata[48]));
 sky130_fd_sc_hd__conb_1 _2403_ (.LO(reg_rdata[49]));
 sky130_fd_sc_hd__conb_1 _2404_ (.LO(reg_rdata[50]));
 sky130_fd_sc_hd__conb_1 _2405_ (.LO(reg_rdata[51]));
 sky130_fd_sc_hd__conb_1 _2406_ (.LO(reg_rdata[52]));
 sky130_fd_sc_hd__conb_1 _2407_ (.LO(reg_rdata[53]));
 sky130_fd_sc_hd__conb_1 _2408_ (.LO(reg_rdata[54]));
 sky130_fd_sc_hd__conb_1 _2409_ (.LO(reg_rdata[55]));
 sky130_fd_sc_hd__conb_1 _2410_ (.LO(reg_rdata[56]));
 sky130_fd_sc_hd__conb_1 _2411_ (.LO(reg_rdata[57]));
 sky130_fd_sc_hd__conb_1 _2412_ (.LO(reg_rdata[58]));
 sky130_fd_sc_hd__conb_1 _2413_ (.LO(reg_rdata[59]));
 sky130_fd_sc_hd__conb_1 _2414_ (.LO(reg_rdata[60]));
 sky130_fd_sc_hd__conb_1 _2415_ (.LO(reg_rdata[61]));
 sky130_fd_sc_hd__conb_1 _2416_ (.LO(reg_rdata[62]));
 sky130_fd_sc_hd__conb_1 _2417_ (.LO(reg_rdata[63]));
 sky130_fd_sc_hd__conb_1 _2418_ (.LO(req_data[0]));
 sky130_fd_sc_hd__conb_1 _2419_ (.LO(req_data[1]));
 sky130_fd_sc_hd__conb_1 _2420_ (.LO(req_data[2]));
 sky130_fd_sc_hd__conb_1 _2421_ (.LO(req_data[3]));
 sky130_fd_sc_hd__conb_1 _2422_ (.LO(req_data[4]));
 sky130_fd_sc_hd__conb_1 _2423_ (.LO(req_data[5]));
 sky130_fd_sc_hd__conb_1 _2424_ (.LO(req_data[6]));
 sky130_fd_sc_hd__conb_1 _2425_ (.LO(req_data[7]));
 sky130_fd_sc_hd__conb_1 _2426_ (.LO(req_data[8]));
 sky130_fd_sc_hd__conb_1 _2427_ (.LO(req_data[9]));
 sky130_fd_sc_hd__conb_1 _2428_ (.LO(req_data[10]));
 sky130_fd_sc_hd__conb_1 _2429_ (.LO(req_data[11]));
 sky130_fd_sc_hd__conb_1 _2430_ (.LO(req_data[12]));
 sky130_fd_sc_hd__conb_1 _2431_ (.LO(req_data[13]));
 sky130_fd_sc_hd__buf_2 _2432_ (.A(motor_control_transport_fsm_status_busy),
    .X(motor_control_register_map_status_busy));
 sky130_fd_sc_hd__buf_2 _2433_ (.A(motor_control_transport_fsm_status_fallback_active),
    .X(motor_control_register_map_status_fallback_active));
 sky130_fd_sc_hd__buf_2 _2434_ (.A(motor_control_transport_fsm_status_fault),
    .X(motor_control_register_map_status_fault));
 sky130_fd_sc_hd__buf_2 _2435_ (.A(motor_control_transport_fsm_status_last_seq[0]),
    .X(motor_control_register_map_status_last_seq[0]));
 sky130_fd_sc_hd__buf_2 _2436_ (.A(motor_control_transport_fsm_status_last_seq[1]),
    .X(motor_control_register_map_status_last_seq[1]));
 sky130_fd_sc_hd__buf_2 _2437_ (.A(motor_control_transport_fsm_status_last_seq[2]),
    .X(motor_control_register_map_status_last_seq[2]));
 sky130_fd_sc_hd__buf_2 _2438_ (.A(motor_control_transport_fsm_status_last_seq[3]),
    .X(motor_control_register_map_status_last_seq[3]));
 sky130_fd_sc_hd__buf_2 _2439_ (.A(motor_control_transport_fsm_status_last_seq[4]),
    .X(motor_control_register_map_status_last_seq[4]));
 sky130_fd_sc_hd__buf_2 _2440_ (.A(motor_control_transport_fsm_status_last_seq[5]),
    .X(motor_control_register_map_status_last_seq[5]));
 sky130_fd_sc_hd__buf_2 _2441_ (.A(motor_control_transport_fsm_status_last_seq[6]),
    .X(motor_control_register_map_status_last_seq[6]));
 sky130_fd_sc_hd__buf_2 _2442_ (.A(motor_control_transport_fsm_status_last_seq[7]),
    .X(motor_control_register_map_status_last_seq[7]));
 sky130_fd_sc_hd__buf_2 _2443_ (.A(motor_control_transport_fsm_status_last_seq[8]),
    .X(motor_control_register_map_status_last_seq[8]));
 sky130_fd_sc_hd__buf_2 _2444_ (.A(motor_control_transport_fsm_status_last_seq[9]),
    .X(motor_control_register_map_status_last_seq[9]));
 sky130_fd_sc_hd__buf_2 _2445_ (.A(motor_control_transport_fsm_status_last_seq[10]),
    .X(motor_control_register_map_status_last_seq[10]));
 sky130_fd_sc_hd__buf_2 _2446_ (.A(motor_control_transport_fsm_status_last_seq[11]),
    .X(motor_control_register_map_status_last_seq[11]));
 sky130_fd_sc_hd__buf_2 _2447_ (.A(motor_control_transport_fsm_status_last_seq[12]),
    .X(motor_control_register_map_status_last_seq[12]));
 sky130_fd_sc_hd__buf_2 _2448_ (.A(motor_control_transport_fsm_status_last_seq[13]),
    .X(motor_control_register_map_status_last_seq[13]));
 sky130_fd_sc_hd__buf_2 _2449_ (.A(motor_control_transport_fsm_status_last_seq[14]),
    .X(motor_control_register_map_status_last_seq[14]));
 sky130_fd_sc_hd__buf_2 _2450_ (.A(motor_control_transport_fsm_status_last_seq[15]),
    .X(motor_control_register_map_status_last_seq[15]));
 sky130_fd_sc_hd__buf_2 _2451_ (.A(motor_control_transport_fsm_status_rsp_valid),
    .X(motor_control_register_map_status_rsp_valid));
 sky130_fd_sc_hd__buf_2 _2452_ (.A(motor_control_transport_fsm_status_stale_reject),
    .X(motor_control_register_map_status_stale_reject));
 sky130_fd_sc_hd__buf_2 _2453_ (.A(motor_control_transport_fsm_status_timeout),
    .X(motor_control_register_map_status_timeout));
 sky130_fd_sc_hd__buf_2 _2454_ (.A(motor_control_register_map_cfg_clamp_max[0]),
    .X(motor_control_transport_fsm_cfg_clamp_max[0]));
 sky130_fd_sc_hd__buf_2 _2455_ (.A(motor_control_register_map_cfg_clamp_max[1]),
    .X(motor_control_transport_fsm_cfg_clamp_max[1]));
 sky130_fd_sc_hd__buf_2 _2456_ (.A(motor_control_register_map_cfg_clamp_max[2]),
    .X(motor_control_transport_fsm_cfg_clamp_max[2]));
 sky130_fd_sc_hd__buf_2 _2457_ (.A(motor_control_register_map_cfg_clamp_max[3]),
    .X(motor_control_transport_fsm_cfg_clamp_max[3]));
 sky130_fd_sc_hd__buf_2 _2458_ (.A(motor_control_register_map_cfg_clamp_max[4]),
    .X(motor_control_transport_fsm_cfg_clamp_max[4]));
 sky130_fd_sc_hd__buf_2 _2459_ (.A(motor_control_register_map_cfg_clamp_max[5]),
    .X(motor_control_transport_fsm_cfg_clamp_max[5]));
 sky130_fd_sc_hd__buf_2 _2460_ (.A(motor_control_register_map_cfg_clamp_max[6]),
    .X(motor_control_transport_fsm_cfg_clamp_max[6]));
 sky130_fd_sc_hd__buf_2 _2461_ (.A(motor_control_register_map_cfg_clamp_max[7]),
    .X(motor_control_transport_fsm_cfg_clamp_max[7]));
 sky130_fd_sc_hd__buf_2 _2462_ (.A(motor_control_register_map_cfg_clamp_max[8]),
    .X(motor_control_transport_fsm_cfg_clamp_max[8]));
 sky130_fd_sc_hd__buf_2 _2463_ (.A(motor_control_register_map_cfg_clamp_max[9]),
    .X(motor_control_transport_fsm_cfg_clamp_max[9]));
 sky130_fd_sc_hd__buf_2 _2464_ (.A(motor_control_register_map_cfg_clamp_max[10]),
    .X(motor_control_transport_fsm_cfg_clamp_max[10]));
 sky130_fd_sc_hd__buf_2 _2465_ (.A(motor_control_register_map_cfg_clamp_max[11]),
    .X(motor_control_transport_fsm_cfg_clamp_max[11]));
 sky130_fd_sc_hd__buf_2 _2466_ (.A(motor_control_register_map_cfg_clamp_max[12]),
    .X(motor_control_transport_fsm_cfg_clamp_max[12]));
 sky130_fd_sc_hd__buf_2 _2467_ (.A(motor_control_register_map_cfg_clamp_max[13]),
    .X(motor_control_transport_fsm_cfg_clamp_max[13]));
 sky130_fd_sc_hd__buf_2 _2468_ (.A(motor_control_register_map_cfg_clamp_max[14]),
    .X(motor_control_transport_fsm_cfg_clamp_max[14]));
 sky130_fd_sc_hd__buf_2 _2469_ (.A(motor_control_register_map_cfg_clamp_max[15]),
    .X(motor_control_transport_fsm_cfg_clamp_max[15]));
 sky130_fd_sc_hd__buf_2 _2470_ (.A(motor_control_register_map_cfg_clamp_max[16]),
    .X(motor_control_transport_fsm_cfg_clamp_max[16]));
 sky130_fd_sc_hd__buf_2 _2471_ (.A(motor_control_register_map_cfg_clamp_max[17]),
    .X(motor_control_transport_fsm_cfg_clamp_max[17]));
 sky130_fd_sc_hd__buf_2 _2472_ (.A(motor_control_register_map_cfg_clamp_max[18]),
    .X(motor_control_transport_fsm_cfg_clamp_max[18]));
 sky130_fd_sc_hd__buf_2 _2473_ (.A(motor_control_register_map_cfg_clamp_max[19]),
    .X(motor_control_transport_fsm_cfg_clamp_max[19]));
 sky130_fd_sc_hd__buf_2 _2474_ (.A(motor_control_register_map_cfg_clamp_max[20]),
    .X(motor_control_transport_fsm_cfg_clamp_max[20]));
 sky130_fd_sc_hd__buf_2 _2475_ (.A(motor_control_register_map_cfg_clamp_max[21]),
    .X(motor_control_transport_fsm_cfg_clamp_max[21]));
 sky130_fd_sc_hd__buf_2 _2476_ (.A(motor_control_register_map_cfg_clamp_max[22]),
    .X(motor_control_transport_fsm_cfg_clamp_max[22]));
 sky130_fd_sc_hd__buf_2 _2477_ (.A(motor_control_register_map_cfg_clamp_max[23]),
    .X(motor_control_transport_fsm_cfg_clamp_max[23]));
 sky130_fd_sc_hd__buf_2 _2478_ (.A(motor_control_register_map_cfg_clamp_max[24]),
    .X(motor_control_transport_fsm_cfg_clamp_max[24]));
 sky130_fd_sc_hd__buf_2 _2479_ (.A(motor_control_register_map_cfg_clamp_max[25]),
    .X(motor_control_transport_fsm_cfg_clamp_max[25]));
 sky130_fd_sc_hd__buf_2 _2480_ (.A(motor_control_register_map_cfg_clamp_max[26]),
    .X(motor_control_transport_fsm_cfg_clamp_max[26]));
 sky130_fd_sc_hd__buf_2 _2481_ (.A(motor_control_register_map_cfg_clamp_max[27]),
    .X(motor_control_transport_fsm_cfg_clamp_max[27]));
 sky130_fd_sc_hd__buf_2 _2482_ (.A(motor_control_register_map_cfg_clamp_max[28]),
    .X(motor_control_transport_fsm_cfg_clamp_max[28]));
 sky130_fd_sc_hd__buf_2 _2483_ (.A(motor_control_register_map_cfg_clamp_max[29]),
    .X(motor_control_transport_fsm_cfg_clamp_max[29]));
 sky130_fd_sc_hd__buf_2 _2484_ (.A(motor_control_register_map_cfg_clamp_max[30]),
    .X(motor_control_transport_fsm_cfg_clamp_max[30]));
 sky130_fd_sc_hd__buf_2 _2485_ (.A(motor_control_register_map_cfg_clamp_max[31]),
    .X(motor_control_transport_fsm_cfg_clamp_max[31]));
 sky130_fd_sc_hd__buf_2 _2486_ (.A(motor_control_register_map_cfg_clamp_min[0]),
    .X(motor_control_transport_fsm_cfg_clamp_min[0]));
 sky130_fd_sc_hd__buf_2 _2487_ (.A(motor_control_register_map_cfg_clamp_min[1]),
    .X(motor_control_transport_fsm_cfg_clamp_min[1]));
 sky130_fd_sc_hd__buf_2 _2488_ (.A(motor_control_register_map_cfg_clamp_min[2]),
    .X(motor_control_transport_fsm_cfg_clamp_min[2]));
 sky130_fd_sc_hd__buf_2 _2489_ (.A(motor_control_register_map_cfg_clamp_min[3]),
    .X(motor_control_transport_fsm_cfg_clamp_min[3]));
 sky130_fd_sc_hd__buf_2 _2490_ (.A(motor_control_register_map_cfg_clamp_min[4]),
    .X(motor_control_transport_fsm_cfg_clamp_min[4]));
 sky130_fd_sc_hd__buf_2 _2491_ (.A(motor_control_register_map_cfg_clamp_min[5]),
    .X(motor_control_transport_fsm_cfg_clamp_min[5]));
 sky130_fd_sc_hd__buf_2 _2492_ (.A(motor_control_register_map_cfg_clamp_min[6]),
    .X(motor_control_transport_fsm_cfg_clamp_min[6]));
 sky130_fd_sc_hd__buf_2 _2493_ (.A(motor_control_register_map_cfg_clamp_min[7]),
    .X(motor_control_transport_fsm_cfg_clamp_min[7]));
 sky130_fd_sc_hd__buf_2 _2494_ (.A(motor_control_register_map_cfg_clamp_min[8]),
    .X(motor_control_transport_fsm_cfg_clamp_min[8]));
 sky130_fd_sc_hd__buf_2 _2495_ (.A(motor_control_register_map_cfg_clamp_min[9]),
    .X(motor_control_transport_fsm_cfg_clamp_min[9]));
 sky130_fd_sc_hd__buf_2 _2496_ (.A(motor_control_register_map_cfg_clamp_min[10]),
    .X(motor_control_transport_fsm_cfg_clamp_min[10]));
 sky130_fd_sc_hd__buf_2 _2497_ (.A(motor_control_register_map_cfg_clamp_min[11]),
    .X(motor_control_transport_fsm_cfg_clamp_min[11]));
 sky130_fd_sc_hd__buf_2 _2498_ (.A(motor_control_register_map_cfg_clamp_min[12]),
    .X(motor_control_transport_fsm_cfg_clamp_min[12]));
 sky130_fd_sc_hd__buf_2 _2499_ (.A(motor_control_register_map_cfg_clamp_min[13]),
    .X(motor_control_transport_fsm_cfg_clamp_min[13]));
 sky130_fd_sc_hd__buf_2 _2500_ (.A(motor_control_register_map_cfg_clamp_min[14]),
    .X(motor_control_transport_fsm_cfg_clamp_min[14]));
 sky130_fd_sc_hd__buf_2 _2501_ (.A(motor_control_register_map_cfg_clamp_min[15]),
    .X(motor_control_transport_fsm_cfg_clamp_min[15]));
 sky130_fd_sc_hd__buf_2 _2502_ (.A(motor_control_register_map_cfg_clamp_min[16]),
    .X(motor_control_transport_fsm_cfg_clamp_min[16]));
 sky130_fd_sc_hd__buf_2 _2503_ (.A(motor_control_register_map_cfg_clamp_min[17]),
    .X(motor_control_transport_fsm_cfg_clamp_min[17]));
 sky130_fd_sc_hd__buf_2 _2504_ (.A(motor_control_register_map_cfg_clamp_min[18]),
    .X(motor_control_transport_fsm_cfg_clamp_min[18]));
 sky130_fd_sc_hd__buf_2 _2505_ (.A(motor_control_register_map_cfg_clamp_min[19]),
    .X(motor_control_transport_fsm_cfg_clamp_min[19]));
 sky130_fd_sc_hd__buf_2 _2506_ (.A(motor_control_register_map_cfg_clamp_min[20]),
    .X(motor_control_transport_fsm_cfg_clamp_min[20]));
 sky130_fd_sc_hd__buf_2 _2507_ (.A(motor_control_register_map_cfg_clamp_min[21]),
    .X(motor_control_transport_fsm_cfg_clamp_min[21]));
 sky130_fd_sc_hd__buf_2 _2508_ (.A(motor_control_register_map_cfg_clamp_min[22]),
    .X(motor_control_transport_fsm_cfg_clamp_min[22]));
 sky130_fd_sc_hd__buf_2 _2509_ (.A(motor_control_register_map_cfg_clamp_min[23]),
    .X(motor_control_transport_fsm_cfg_clamp_min[23]));
 sky130_fd_sc_hd__buf_2 _2510_ (.A(motor_control_register_map_cfg_clamp_min[24]),
    .X(motor_control_transport_fsm_cfg_clamp_min[24]));
 sky130_fd_sc_hd__buf_2 _2511_ (.A(motor_control_register_map_cfg_clamp_min[25]),
    .X(motor_control_transport_fsm_cfg_clamp_min[25]));
 sky130_fd_sc_hd__buf_2 _2512_ (.A(motor_control_register_map_cfg_clamp_min[26]),
    .X(motor_control_transport_fsm_cfg_clamp_min[26]));
 sky130_fd_sc_hd__buf_2 _2513_ (.A(motor_control_register_map_cfg_clamp_min[27]),
    .X(motor_control_transport_fsm_cfg_clamp_min[27]));
 sky130_fd_sc_hd__buf_2 _2514_ (.A(motor_control_register_map_cfg_clamp_min[28]),
    .X(motor_control_transport_fsm_cfg_clamp_min[28]));
 sky130_fd_sc_hd__buf_2 _2515_ (.A(motor_control_register_map_cfg_clamp_min[29]),
    .X(motor_control_transport_fsm_cfg_clamp_min[29]));
 sky130_fd_sc_hd__buf_2 _2516_ (.A(motor_control_register_map_cfg_clamp_min[30]),
    .X(motor_control_transport_fsm_cfg_clamp_min[30]));
 sky130_fd_sc_hd__buf_2 _2517_ (.A(motor_control_register_map_cfg_clamp_min[31]),
    .X(motor_control_transport_fsm_cfg_clamp_min[31]));
 sky130_fd_sc_hd__buf_2 _2518_ (.A(motor_control_register_map_cfg_enable),
    .X(motor_control_transport_fsm_cfg_enable));
 sky130_fd_sc_hd__buf_2 _2519_ (.A(motor_control_register_map_cfg_fallback_cmd[0]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[0]));
 sky130_fd_sc_hd__buf_2 _2520_ (.A(motor_control_register_map_cfg_fallback_cmd[1]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[1]));
 sky130_fd_sc_hd__buf_2 _2521_ (.A(motor_control_register_map_cfg_fallback_cmd[2]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[2]));
 sky130_fd_sc_hd__buf_2 _2522_ (.A(motor_control_register_map_cfg_fallback_cmd[3]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[3]));
 sky130_fd_sc_hd__buf_2 _2523_ (.A(motor_control_register_map_cfg_fallback_cmd[4]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[4]));
 sky130_fd_sc_hd__buf_2 _2524_ (.A(motor_control_register_map_cfg_fallback_cmd[5]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[5]));
 sky130_fd_sc_hd__buf_2 _2525_ (.A(motor_control_register_map_cfg_fallback_cmd[6]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[6]));
 sky130_fd_sc_hd__buf_2 _2526_ (.A(motor_control_register_map_cfg_fallback_cmd[7]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[7]));
 sky130_fd_sc_hd__buf_2 _2527_ (.A(motor_control_register_map_cfg_fallback_cmd[8]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[8]));
 sky130_fd_sc_hd__buf_2 _2528_ (.A(motor_control_register_map_cfg_fallback_cmd[9]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[9]));
 sky130_fd_sc_hd__buf_2 _2529_ (.A(motor_control_register_map_cfg_fallback_cmd[10]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[10]));
 sky130_fd_sc_hd__buf_2 _2530_ (.A(motor_control_register_map_cfg_fallback_cmd[11]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[11]));
 sky130_fd_sc_hd__buf_2 _2531_ (.A(motor_control_register_map_cfg_fallback_cmd[12]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[12]));
 sky130_fd_sc_hd__buf_2 _2532_ (.A(motor_control_register_map_cfg_fallback_cmd[13]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[13]));
 sky130_fd_sc_hd__buf_2 _2533_ (.A(motor_control_register_map_cfg_fallback_cmd[14]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[14]));
 sky130_fd_sc_hd__buf_2 _2534_ (.A(motor_control_register_map_cfg_fallback_cmd[15]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[15]));
 sky130_fd_sc_hd__buf_2 _2535_ (.A(motor_control_register_map_cfg_fallback_cmd[16]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[16]));
 sky130_fd_sc_hd__buf_2 _2536_ (.A(motor_control_register_map_cfg_fallback_cmd[17]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[17]));
 sky130_fd_sc_hd__buf_2 _2537_ (.A(motor_control_register_map_cfg_fallback_cmd[18]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[18]));
 sky130_fd_sc_hd__buf_2 _2538_ (.A(motor_control_register_map_cfg_fallback_cmd[19]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[19]));
 sky130_fd_sc_hd__buf_2 _2539_ (.A(motor_control_register_map_cfg_fallback_cmd[20]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[20]));
 sky130_fd_sc_hd__buf_2 _2540_ (.A(motor_control_register_map_cfg_fallback_cmd[21]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[21]));
 sky130_fd_sc_hd__buf_2 _2541_ (.A(motor_control_register_map_cfg_fallback_cmd[22]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[22]));
 sky130_fd_sc_hd__buf_2 _2542_ (.A(motor_control_register_map_cfg_fallback_cmd[23]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[23]));
 sky130_fd_sc_hd__buf_2 _2543_ (.A(motor_control_register_map_cfg_fallback_cmd[24]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[24]));
 sky130_fd_sc_hd__buf_2 _2544_ (.A(motor_control_register_map_cfg_fallback_cmd[25]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[25]));
 sky130_fd_sc_hd__buf_2 _2545_ (.A(motor_control_register_map_cfg_fallback_cmd[26]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[26]));
 sky130_fd_sc_hd__buf_2 _2546_ (.A(motor_control_register_map_cfg_fallback_cmd[27]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[27]));
 sky130_fd_sc_hd__buf_2 _2547_ (.A(motor_control_register_map_cfg_fallback_cmd[28]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[28]));
 sky130_fd_sc_hd__buf_2 _2548_ (.A(motor_control_register_map_cfg_fallback_cmd[29]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[29]));
 sky130_fd_sc_hd__buf_2 _2549_ (.A(motor_control_register_map_cfg_fallback_cmd[30]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[30]));
 sky130_fd_sc_hd__buf_2 _2550_ (.A(motor_control_register_map_cfg_fallback_cmd[31]),
    .X(motor_control_transport_fsm_cfg_fallback_cmd[31]));
 sky130_fd_sc_hd__buf_2 _2551_ (.A(motor_control_register_map_cfg_fault_clear),
    .X(motor_control_transport_fsm_cfg_fault_clear));
 sky130_fd_sc_hd__buf_2 _2552_ (.A(motor_control_register_map_cfg_safety_override),
    .X(motor_control_transport_fsm_cfg_safety_override));
 sky130_fd_sc_hd__buf_2 _2553_ (.A(motor_control_register_map_cfg_seq_base[0]),
    .X(motor_control_transport_fsm_cfg_seq_base[0]));
 sky130_fd_sc_hd__buf_2 _2554_ (.A(motor_control_register_map_cfg_seq_base[1]),
    .X(motor_control_transport_fsm_cfg_seq_base[1]));
 sky130_fd_sc_hd__buf_2 _2555_ (.A(motor_control_register_map_cfg_seq_base[2]),
    .X(motor_control_transport_fsm_cfg_seq_base[2]));
 sky130_fd_sc_hd__buf_2 _2556_ (.A(motor_control_register_map_cfg_seq_base[3]),
    .X(motor_control_transport_fsm_cfg_seq_base[3]));
 sky130_fd_sc_hd__buf_2 _2557_ (.A(motor_control_register_map_cfg_seq_base[4]),
    .X(motor_control_transport_fsm_cfg_seq_base[4]));
 sky130_fd_sc_hd__buf_2 _2558_ (.A(motor_control_register_map_cfg_seq_base[5]),
    .X(motor_control_transport_fsm_cfg_seq_base[5]));
 sky130_fd_sc_hd__buf_2 _2559_ (.A(motor_control_register_map_cfg_seq_base[6]),
    .X(motor_control_transport_fsm_cfg_seq_base[6]));
 sky130_fd_sc_hd__buf_2 _2560_ (.A(motor_control_register_map_cfg_seq_base[7]),
    .X(motor_control_transport_fsm_cfg_seq_base[7]));
 sky130_fd_sc_hd__buf_2 _2561_ (.A(motor_control_register_map_cfg_seq_base[8]),
    .X(motor_control_transport_fsm_cfg_seq_base[8]));
 sky130_fd_sc_hd__buf_2 _2562_ (.A(motor_control_register_map_cfg_seq_base[9]),
    .X(motor_control_transport_fsm_cfg_seq_base[9]));
 sky130_fd_sc_hd__buf_2 _2563_ (.A(motor_control_register_map_cfg_seq_base[10]),
    .X(motor_control_transport_fsm_cfg_seq_base[10]));
 sky130_fd_sc_hd__buf_2 _2564_ (.A(motor_control_register_map_cfg_seq_base[11]),
    .X(motor_control_transport_fsm_cfg_seq_base[11]));
 sky130_fd_sc_hd__buf_2 _2565_ (.A(motor_control_register_map_cfg_seq_base[12]),
    .X(motor_control_transport_fsm_cfg_seq_base[12]));
 sky130_fd_sc_hd__buf_2 _2566_ (.A(motor_control_register_map_cfg_seq_base[13]),
    .X(motor_control_transport_fsm_cfg_seq_base[13]));
 sky130_fd_sc_hd__buf_2 _2567_ (.A(motor_control_register_map_cfg_seq_base[14]),
    .X(motor_control_transport_fsm_cfg_seq_base[14]));
 sky130_fd_sc_hd__buf_2 _2568_ (.A(motor_control_register_map_cfg_seq_base[15]),
    .X(motor_control_transport_fsm_cfg_seq_base[15]));
 sky130_fd_sc_hd__buf_2 _2569_ (.A(motor_control_register_map_cfg_start),
    .X(motor_control_transport_fsm_cfg_start));
 sky130_fd_sc_hd__buf_2 _2570_ (.A(motor_control_register_map_cfg_timeout_limit[0]),
    .X(motor_control_transport_fsm_cfg_timeout_limit[0]));
 sky130_fd_sc_hd__buf_2 _2571_ (.A(motor_control_register_map_cfg_timeout_limit[1]),
    .X(motor_control_transport_fsm_cfg_timeout_limit[1]));
 sky130_fd_sc_hd__buf_2 _2572_ (.A(motor_control_register_map_cfg_timeout_limit[2]),
    .X(motor_control_transport_fsm_cfg_timeout_limit[2]));
 sky130_fd_sc_hd__buf_2 _2573_ (.A(motor_control_register_map_cfg_timeout_limit[3]),
    .X(motor_control_transport_fsm_cfg_timeout_limit[3]));
 sky130_fd_sc_hd__buf_2 _2574_ (.A(motor_control_register_map_cfg_timeout_limit[4]),
    .X(motor_control_transport_fsm_cfg_timeout_limit[4]));
 sky130_fd_sc_hd__buf_2 _2575_ (.A(motor_control_register_map_cfg_timeout_limit[5]),
    .X(motor_control_transport_fsm_cfg_timeout_limit[5]));
 sky130_fd_sc_hd__buf_2 _2576_ (.A(motor_control_register_map_cfg_timeout_limit[6]),
    .X(motor_control_transport_fsm_cfg_timeout_limit[6]));
 sky130_fd_sc_hd__buf_2 _2577_ (.A(motor_control_register_map_cfg_timeout_limit[7]),
    .X(motor_control_transport_fsm_cfg_timeout_limit[7]));
 sky130_fd_sc_hd__buf_2 _2578_ (.A(motor_control_register_map_cfg_timeout_limit[8]),
    .X(motor_control_transport_fsm_cfg_timeout_limit[8]));
 sky130_fd_sc_hd__buf_2 _2579_ (.A(motor_control_register_map_cfg_timeout_limit[9]),
    .X(motor_control_transport_fsm_cfg_timeout_limit[9]));
 sky130_fd_sc_hd__buf_2 _2580_ (.A(motor_control_register_map_cfg_timeout_limit[10]),
    .X(motor_control_transport_fsm_cfg_timeout_limit[10]));
 sky130_fd_sc_hd__buf_2 _2581_ (.A(motor_control_register_map_cfg_timeout_limit[11]),
    .X(motor_control_transport_fsm_cfg_timeout_limit[11]));
 sky130_fd_sc_hd__buf_2 _2582_ (.A(motor_control_register_map_cfg_timeout_limit[12]),
    .X(motor_control_transport_fsm_cfg_timeout_limit[12]));
 sky130_fd_sc_hd__buf_2 _2583_ (.A(motor_control_register_map_cfg_timeout_limit[13]),
    .X(motor_control_transport_fsm_cfg_timeout_limit[13]));
 sky130_fd_sc_hd__buf_2 _2584_ (.A(motor_control_register_map_cfg_timeout_limit[14]),
    .X(motor_control_transport_fsm_cfg_timeout_limit[14]));
 sky130_fd_sc_hd__buf_2 _2585_ (.A(motor_control_register_map_cfg_timeout_limit[15]),
    .X(motor_control_transport_fsm_cfg_timeout_limit[15]));
 sky130_fd_sc_hd__buf_2 _2586_ (.A(reg_cs),
    .X(reg_ready));
 sky130_fd_sc_hd__sdfxtp_2 _2114_ (.CLK(clk),
    .D(_0007_),
    .Q(\motor_control_register_map_cfg_clamp_max_from_u_motor_control_register_map[0] ));
 assign scan_out[0] = motor_control_register_map_cfg_enable_from_u_motor_control_register_map;
 assign scan_out[1] = scan_in[1];
 assign scan_out[2] = scan_in[2];
 assign scan_out[3] = scan_in[3];
endmodule
