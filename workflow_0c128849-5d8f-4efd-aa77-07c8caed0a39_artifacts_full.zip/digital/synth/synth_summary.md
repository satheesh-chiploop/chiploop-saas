# Digital Synthesis Summary

- **Workflow**: 0c128849-5d8f-4efd-aa77-07c8caed0a39
- **Status**: `ok` (rc=0)
- **Top module**: `motor_control_top`
- **Clock**: `clk` @ **10.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0c128849-5d8f-4efd-aa77-07c8caed0a39/17b59b6a-6fa3-4e57-8df9-0060f089b900/digital/arch2tapeout/digital/synth/runs/Digital_Arch2Tapeout_0c128849-5d8f-4efd-aa77-07c8caed0a39/final/metrics.json`
- netlist candidates: 1 found
