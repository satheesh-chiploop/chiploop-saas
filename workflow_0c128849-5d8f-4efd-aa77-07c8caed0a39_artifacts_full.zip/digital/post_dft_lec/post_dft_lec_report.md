# Digital Post-DFT Logic Equivalence Check

- Status: `pass`
- Failure reason: `equivalence_proven`
- Top module: `motor_control_top`
- Synthesis netlist: `motor_control_top_synth.v`
- Post-DFT netlist: `scan_stitched_netlist.v`
- Unproven points: `0`
