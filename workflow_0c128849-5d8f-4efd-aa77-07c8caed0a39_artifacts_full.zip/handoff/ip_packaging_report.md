# IP Packaging & Handoff Report

- Top: `motor_control_top`
- Package: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0c128849-5d8f-4efd-aa77-07c8caed0a39/17b59b6a-6fa3-4e57-8df9-0060f089b900/digital/arch2tapeout/handoff/motor_control_top_ip_package`
- Zip: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0c128849-5d8f-4efd-aa77-07c8caed0a39/17b59b6a-6fa3-4e57-8df9-0060f089b900/digital/arch2tapeout/handoff/motor_control_top_ip_package.zip`

## Bucket counts
- **rtl**: 3
- **spec**: 1
- **arch**: 0
- **microarch**: 0
- **regmap**: 1
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 2
