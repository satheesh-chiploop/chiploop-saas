# IP Packaging & Handoff Report

- Top: `image_dma_pipeline`
- Package: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/9f59a7be-304d-48ed-9788-639dc6ff33b1/0cf23071-1cb5-4c40-ae9b-31a62f94bd9c/digital/arch2synthesis/handoff/image_dma_pipeline_ip_package`
- Zip: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/9f59a7be-304d-48ed-9788-639dc6ff33b1/0cf23071-1cb5-4c40-ae9b-31a62f94bd9c/digital/arch2synthesis/handoff/image_dma_pipeline_ip_package.zip`

## Bucket counts
- **rtl**: 1
- **spec**: 1
- **arch**: 0
- **microarch**: 0
- **regmap**: 0
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 2
