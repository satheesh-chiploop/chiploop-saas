module pwm_fpga_demo (
    input  clk,
    output led
);

reg [7:0] pwm_counter;
reg [7:0] duty_cycle;
reg       direction;
reg [15:0] slow_counter;

assign led = (pwm_counter < duty_cycle);

always @(posedge clk) begin
    pwm_counter <= pwm_counter + 8'd1;
end

always @(posedge clk) begin
    slow_counter <= slow_counter + 16'd1;
    if (slow_counter == 16'hFFFF) begin
        if (direction) begin
            if (duty_cycle == 8'hFF) begin
                direction  <= 1'b0;
                duty_cycle <= 8'hFE;
            end else begin
                duty_cycle <= duty_cycle + 8'd1;
            end
        end else begin
            if (duty_cycle == 8'h00) begin
                direction  <= 1'b1;
                duty_cycle <= 8'h01;
            end else begin
                duty_cycle <= duty_cycle - 8'd1;
            end
        end
    end
end

endmodule
