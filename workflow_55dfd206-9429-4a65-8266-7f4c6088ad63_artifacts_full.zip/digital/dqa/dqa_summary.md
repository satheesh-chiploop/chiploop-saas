# Digital DQA Summary
- workflow_id: `55dfd206-9429-4a65-8266-7f4c6088ad63`
- status: `failed`
- rtl files: `1`
- warning count: `0`

## Stage Status
- rtl_lint: `pass`
- cdc: `unavailable`
- reset_integrity: `unavailable`
- synthesis_readiness: `failed`

## Blocking Issues
- yosys_synthesis_errors
