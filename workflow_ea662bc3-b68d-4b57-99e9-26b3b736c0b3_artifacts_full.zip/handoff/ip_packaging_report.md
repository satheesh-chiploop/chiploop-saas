# IP Packaging & Handoff Report

- Top: `motor_control_top`
- Package: `backend/workflows/ea662bc3-b68d-4b57-99e9-26b3b736c0b3/handoff/motor_control_top_ip_package`
- Zip: `backend/workflows/ea662bc3-b68d-4b57-99e9-26b3b736c0b3/handoff/motor_control_top_ip_package.zip`

## Bucket counts
- **rtl**: 24
- **spec**: 3
- **arch**: 1
- **microarch**: 1
- **regmap**: 2
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 6
