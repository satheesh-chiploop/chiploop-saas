# Arch2RTL Evidence Dashboard

- Lint: warnings
- Flip-flops: 199
- Latches: 0
- Full-cycle paths: 3
- Half-cycle paths: 4
- Input bits: 216
- Output bits: 237
- Input ports: 12
- Output ports: 17
- Clock: clk
- Reset: rst_n
- Modules: 8
- RTL files: 8
