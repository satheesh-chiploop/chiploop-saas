module sram_mbist_demo_controller (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    bist_start,
    rd_data,
    ready,
    bist_done,
    bist_fail,
    irq,
    mem_csb,
    mem_web,
    mem_addr,
    mem_din,
    mem_dout,
    bist_request
);
input clk;
input reset_n;
input wr_en;
input [7:0] wr_addr;
input [31:0] wr_data;
input rd_en;
input [7:0] rd_addr;
input bist_start;
output [31:0] rd_data;
output ready;
output bist_done;
output bist_fail;
output irq;
output mem_csb;
output mem_web;
output [7:0] mem_addr;
output [31:0] mem_din;
input [31:0] mem_dout;
output bist_request;

reg [31:0] rd_data_r;
reg ready_r;
reg bist_done_r;
reg bist_fail_r;
reg irq_r;
reg mem_csb_r;
reg mem_web_r;
reg [7:0] mem_addr_r;
reg [31:0] mem_din_r;
reg bist_request_r;
reg [2:0] control_reg;
reg [7:0] mem_addr_reg;
reg [31:0] mem_wdata_reg;
reg [31:0] mem_rdata_reg;
reg [1:0] mem_control_reg;
reg [1:0] bist_control_reg;
reg [1:0] irq_status_reg;
reg [7:0] last_fail_addr_reg;
reg bist_running_reg;

assign rd_data = rd_data_r;
assign ready = ready_r;
assign bist_done = bist_done_r;
assign bist_fail = bist_fail_r;
assign irq = irq_r;
assign mem_csb = mem_csb_r;
assign mem_web = mem_web_r;
assign mem_addr = mem_addr_r;
assign mem_din = mem_din_r;
assign bist_request = bist_request_r;

always @(posedge clk) begin
    if (!reset_n) begin
        rd_data_r <= 32'h00000000;
        ready_r <= 1'b0;
        bist_done_r <= 1'b0;
        bist_fail_r <= 1'b0;
        irq_r <= 1'b0;
        mem_csb_r <= 1'b1;
        mem_web_r <= 1'b1;
        mem_addr_r <= 8'h00;
        mem_din_r <= 32'h00000000;
        bist_request_r <= 1'b0;
        control_reg <= 3'b000;
        mem_addr_reg <= 8'h00;
        mem_wdata_reg <= 32'h00000000;
        mem_rdata_reg <= 32'h00000000;
        mem_control_reg <= 2'b00;
        bist_control_reg <= 2'b00;
        irq_status_reg <= 2'b00;
        last_fail_addr_reg <= 8'h00;
        bist_running_reg <= 1'b0;
    end else begin
        ready_r <= control_reg[0] & ~bist_running_reg;
        bist_request_r <= bist_start | bist_control_reg[0];
        mem_csb_r <= 1'b1;
        mem_web_r <= 1'b1;
        mem_addr_r <= mem_addr_reg;
        mem_din_r <= mem_wdata_reg;
        if (wr_en) begin
            case (wr_addr)
                8'h00: control_reg <= wr_data[2:0];
                8'h08: mem_addr_reg <= wr_data[7:0];
                8'h0C: mem_wdata_reg <= wr_data;
                8'h14: mem_control_reg <= wr_data[1:0];
                8'h18: bist_control_reg <= wr_data[1:0];
                8'h24: begin
                    irq_status_reg[0] <= irq_status_reg[0] & ~wr_data[0];
                    irq_status_reg[1] <= irq_status_reg[1] & ~wr_data[1];
                end
                default: begin
                end
            endcase
        end
        if (control_reg[1]) begin
            control_reg <= 3'b000;
            bist_done_r <= 1'b0;
            bist_fail_r <= 1'b0;
            irq_status_reg <= 2'b00;
            irq_r <= 1'b0;
            bist_running_reg <= 1'b0;
            last_fail_addr_reg <= 8'h00;
        end
        if (bist_control_reg[1]) begin
            bist_done_r <= 1'b0;
            bist_fail_r <= 1'b0;
            irq_status_reg <= 2'b00;
            irq_r <= 1'b0;
            bist_running_reg <= 1'b0;
            last_fail_addr_reg <= 8'h00;
        end
        if (mem_control_reg[0] && control_reg[0] && !bist_running_reg) begin
            mem_csb_r <= 1'b0;
            mem_web_r <= 1'b0;
        end else if (mem_control_reg[1] && control_reg[0] && !bist_running_reg) begin
            mem_csb_r <= 1'b0;
            mem_web_r <= 1'b1;
            mem_rdata_reg <= mem_dout;
            rd_data_r <= mem_dout;
        end
        if (bist_request_r) begin
            bist_running_reg <= 1'b1;
            bist_done_r <= 1'b1;
            bist_fail_r <= mem_dout[0];
            last_fail_addr_reg <= mem_addr_reg;
            irq_status_reg[0] <= 1'b1;
            if (mem_dout[0]) begin
                irq_status_reg[1] <= 1'b1;
            end
            bist_running_reg <= 1'b0;
        end
        irq_r <= control_reg[2] & (irq_status_reg[0] | irq_status_reg[1]);
    end
end

endmodule
