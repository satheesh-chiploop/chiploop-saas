# IP Packaging & Handoff Report

- Top: `motor_control_top`
- Package: `backend/workflows/b60b529b-ed89-4d1b-9eb4-818e6d39cffa/handoff/motor_control_top_ip_package`
- Zip: `backend/workflows/b60b529b-ed89-4d1b-9eb4-818e6d39cffa/handoff/motor_control_top_ip_package.zip`

## Bucket counts
- **rtl**: 0
- **spec**: 3
- **arch**: 1
- **microarch**: 1
- **regmap**: 2
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 5
