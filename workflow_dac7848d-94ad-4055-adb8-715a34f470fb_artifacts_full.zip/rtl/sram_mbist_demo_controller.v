module sram_mbist_demo_controller (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    bist_start,
    rd_data,
    ready,
    bist_done,
    bist_fail,
    irq,
    sram_csb,
    sram_web,
    sram_addr,
    sram_din,
    sram_dout
);
    input clk;
    input reset_n;
    input wr_en;
    input [7:0] wr_addr;
    input [31:0] wr_data;
    input rd_en;
    input [7:0] rd_addr;
    input bist_start;
    output [31:0] rd_data;
    output ready;
    output bist_done;
    output bist_fail;
    output irq;
    output sram_csb;
    output sram_web;
    output [5:0] sram_addr;
    output [31:0] sram_din;
    input [31:0] sram_dout;

    reg [31:0] rd_data_r;
    reg ready_r;
    reg bist_done_r;
    reg bist_fail_r;
    reg irq_r;

    reg control_enable;
    reg control_soft_reset;
    reg control_irq_enable;

    reg [5:0] mem_addr_r;
    reg [31:0] mem_wdata_r;
    reg mem_write_r;
    reg mem_read_r;

    reg bist_start_r;
    reg bist_clear_result_r;

    reg bist_running_r;
    reg [5:0] last_fail_addr_r;

    reg irq_status_done_r;
    reg irq_status_fail_r;

    reg sram_csb_r;
    reg sram_web_r;
    reg [5:0] sram_addr_r;
    reg [31:0] sram_din_r;

    reg [31:0] readback_mux;
    reg [31:0] status_r;
    reg [31:0] bist_status_r;
    reg [31:0] irq_status_r;

    wire write_control;
    wire write_mem_addr;
    wire write_mem_wdata;
    wire write_mem_control;
    wire write_bist_control;
    wire write_irq_status;
    wire write_irq_clear;
    wire read_control;
    wire read_status;
    wire read_mem_addr;
    wire read_mem_wdata;
    wire read_mem_rdata;
    wire read_mem_control;
    wire read_bist_control;
    wire read_bist_status;
    wire read_irq_status;
    wire read_irq_clear;

    assign rd_data = rd_data_r;
    assign ready = ready_r;
    assign bist_done = bist_done_r;
    assign bist_fail = bist_fail_r;
    assign irq = irq_r;
    assign sram_csb = sram_csb_r;
    assign sram_web = sram_web_r;
    assign sram_addr = sram_addr_r;
    assign sram_din = sram_din_r;

    assign write_control = wr_en & (wr_addr == 8'h00);
    assign write_mem_addr = wr_en & (wr_addr == 8'h08);
    assign write_mem_wdata = wr_en & (wr_addr == 8'h0C);
    assign write_mem_control = wr_en & (wr_addr == 8'h14);
    assign write_bist_control = wr_en & (wr_addr == 8'h18);
    assign write_irq_status = wr_en & (wr_addr == 8'h20);
    assign write_irq_clear = wr_en & (wr_addr == 8'h24);

    assign read_control = rd_en & (rd_addr == 8'h00);
    assign read_status = rd_en & (rd_addr == 8'h04);
    assign read_mem_addr = rd_en & (rd_addr == 8'h08);
    assign read_mem_wdata = rd_en & (rd_addr == 8'h0C);
    assign read_mem_rdata = rd_en & (rd_addr == 8'h10);
    assign read_mem_control = rd_en & (rd_addr == 8'h14);
    assign read_bist_control = rd_en & (rd_addr == 8'h18);
    assign read_bist_status = rd_en & (rd_addr == 8'h1C);
    assign read_irq_status = rd_en & (rd_addr == 8'h20);
    assign read_irq_clear = rd_en & (rd_addr == 8'h24);

    always @(*) begin
        readback_mux = 32'h00000000;
        if (read_control) begin
            readback_mux = {29'b00000000000000000000000000000, control_irq_enable, control_soft_reset, control_enable};
        end else if (read_status) begin
            readback_mux = status_r;
        end else if (read_mem_addr) begin
            readback_mux = {26'b00000000000000000000000000, mem_addr_r};
        end else if (read_mem_wdata) begin
            readback_mux = mem_wdata_r;
        end else if (read_mem_rdata) begin
            readback_mux = sram_dout;
        end else if (read_mem_control) begin
            readback_mux = {30'b000000000000000000000000000000, mem_read_r, mem_write_r};
        end else if (read_bist_control) begin
            readback_mux = {30'b000000000000000000000000000000, bist_clear_result_r, bist_start_r};
        end else if (read_bist_status) begin
            readback_mux = bist_status_r;
        end else if (read_irq_status) begin
            readback_mux = irq_status_r;
        end else if (read_irq_clear) begin
            readback_mux = 32'h00000000;
        end else begin
            readback_mux = 32'h00000000;
        end
    end

    always @(*) begin
        status_r = 32'h00000000;
        status_r[0] = ready_r;
        status_r[1] = bist_done_r;
        status_r[2] = bist_fail_r;
        status_r[3] = bist_running_r;

        bist_status_r = 32'h00000000;
        bist_status_r[0] = bist_done_r;
        bist_status_r[1] = bist_fail_r;
        bist_status_r[2] = bist_running_r;
        bist_status_r[8:3] = last_fail_addr_r;

        irq_status_r = 32'h00000000;
        irq_status_r[0] = irq_status_done_r;
        irq_status_r[1] = irq_status_fail_r;
    end

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            control_enable <= 1'b0;
            control_soft_reset <= 1'b0;
            control_irq_enable <= 1'b0;
            ready_r <= 1'b0;
            bist_done_r <= 1'b0;
            bist_fail_r <= 1'b0;
            irq_r <= 1'b0;
            mem_addr_r <= 6'b000000;
            mem_wdata_r <= 32'h00000000;
            mem_write_r <= 1'b0;
            mem_read_r <= 1'b0;
            bist_start_r <= 1'b0;
            bist_clear_result_r <= 1'b0;
            bist_running_r <= 1'b0;
            last_fail_addr_r <= 6'b000000;
            irq_status_done_r <= 1'b0;
            irq_status_fail_r <= 1'b0;
            rd_data_r <= 32'h00000000;
            sram_csb_r <= 1'b1;
            sram_web_r <= 1'b1;
            sram_addr_r <= 6'b000000;
            sram_din_r <= 32'h00000000;
        end else begin
            if (write_control) begin
                control_enable <= wr_data[0];
                control_soft_reset <= wr_data[1];
                control_irq_enable <= wr_data[2];
            end
            if (write_mem_addr) begin
                mem_addr_r <= wr_data[5:0];
            end
            if (write_mem_wdata) begin
                mem_wdata_r <= wr_data;
            end
            if (write_mem_control) begin
                mem_write_r <= wr_data[0];
                mem_read_r <= wr_data[1];
            end else begin
                mem_write_r <= 1'b0;
                mem_read_r <= 1'b0;
            end
            if (write_bist_control) begin
                bist_start_r <= wr_data[0];
                bist_clear_result_r <= wr_data[1];
            end else begin
                bist_start_r <= 1'b0;
                bist_clear_result_r <= 1'b0;
            end

            if (write_irq_status || write_irq_clear) begin
                if (wr_data[0]) begin
                    irq_status_done_r <= 1'b0;
                    bist_done_r <= 1'b0;
                end
                if (wr_data[1]) begin
                    irq_status_fail_r <= 1'b0;
                    bist_fail_r <= 1'b0;
                end
            end

            if (control_soft_reset || (write_control && wr_data[1])) begin
                ready_r <= 1'b0;
                bist_done_r <= 1'b0;
                bist_fail_r <= 1'b0;
                bist_running_r <= 1'b0;
                irq_status_done_r <= 1'b0;
                irq_status_fail_r <= 1'b0;
                last_fail_addr_r <= 6'b000000;
            end else begin
                ready_r <= control_enable;
            end

            if (bist_start || bist_start_r) begin
                bist_running_r <= 1'b1;
                ready_r <= 1'b0;
            end else if (bist_running_r) begin
                bist_running_r <= 1'b0;
                bist_done_r <= 1'b1;
                irq_status_done_r <= 1'b1;
            end

            if (bist_running_r && control_enable) begin
                bist_fail_r <= 1'b0;
            end

            if (bist_clear_result_r) begin
                bist_done_r <= 1'b0;
                bist_fail_r <= 1'b0;
                irq_status_done_r <= 1'b0;
                irq_status_fail_r <= 1'b0;
                last_fail_addr_r <= 6'b000000;
            end

            if (mem_write_r && control_enable) begin
                sram_csb_r <= 1'b0;
                sram_web_r <= 1'b0;
                sram_addr_r <= mem_addr_r;
                sram_din_r <= mem_wdata_r;
            end else if (mem_read_r && control_enable) begin
                sram_csb_r <= 1'b0;
                sram_web_r <= 1'b1;
                sram_addr_r <= mem_addr_r;
                sram_din_r <= mem_wdata_r;
                rd_data_r <= sram_dout;
            end else begin
                sram_csb_r <= 1'b1;
                sram_web_r <= 1'b1;
                sram_addr_r <= mem_addr_r;
                sram_din_r <= mem_wdata_r;
            end

            if (rd_en) begin
                rd_data_r <= readback_mux;
            end

            irq_r <= control_irq_enable & (irq_status_done_r | irq_status_fail_r);
        end
    end

endmodule
