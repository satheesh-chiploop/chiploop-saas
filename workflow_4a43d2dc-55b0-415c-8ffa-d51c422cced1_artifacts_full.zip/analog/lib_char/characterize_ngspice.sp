.include "/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/4a43d2dc-55b0-415c-8ffa-d51c422cced1/44794d5b-1e3e-41ae-8e6f-fd37f8c578e0/digital/analog/lib_char/temp_sensor_adc_model.spice"
* Placeholder characterization deck. Real Liberty requires block-specific stimuli and measurements.
.control
op
write op.raw
quit
.endc
.end
