.lib "$PDK_ROOT/sky130A/libs.tech/ngspice/sky130.lib.spice" tt

.subckt temp_sensor_adc_model VGND VPWR adc_code adc_code[0] adc_code[10] adc_code[11] adc_code[1] adc_code[2] adc_code[3] adc_code[4] adc_code[5] adc_code[6] adc_code[7] adc_code[8] adc_code[9] adc_valid avdd avss sample_req sensor_temp_celsius sensor_temp_celsius[0] sensor_temp_celsius[10] sensor_temp_celsius[11] sensor_temp_celsius[12] sensor_temp_celsius[13] sensor_temp_celsius[14] sensor_temp_celsius[15] sensor_temp_celsius[1] sensor_temp_celsius[2] sensor_temp_celsius[3] sensor_temp_celsius[4] sensor_temp_celsius[5] sensor_temp_celsius[6] sensor_temp_celsius[7] sensor_temp_celsius[8] sensor_temp_celsius[9]

M0 n_vbp sample_req VPWR VPWR sky130_fd_pr__pfet_01v8 W=1.2 L=0.15
M1 n_vbn sample_req VGND VGND sky130_fd_pr__nfet_01v8 W=1.2 L=0.15

M2 n_temp0 sensor_temp_celsius[0] avdd avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M3 n_temp1 sensor_temp_celsius[1] avdd avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M4 n_temp2 sensor_temp_celsius[2] avdd avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M5 n_temp3 sensor_temp_celsius[3] avdd avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M6 n_temp4 sensor_temp_celsius[4] avdd avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M7 n_temp5 sensor_temp_celsius[5] avdd avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M8 n_temp6 sensor_temp_celsius[6] avdd avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M9 n_temp7 sensor_temp_celsius[7] avdd avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M10 n_temp8 sensor_temp_celsius[8] avdd avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M11 n_temp9 sensor_temp_celsius[9] avdd avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M12 n_temp10 sensor_temp_celsius[10] avdd avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M13 n_temp11 sensor_temp_celsius[11] avdd avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M14 n_temp12 sensor_temp_celsius[12] avdd avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M15 n_temp13 sensor_temp_celsius[13] avdd avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M16 n_temp14 sensor_temp_celsius[14] avdd avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M17 n_temp15 sensor_temp_celsius[15] avdd avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15

M18 n_code0 n_temp0 VGND VGND sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M19 n_code1 n_temp1 VGND VGND sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M20 n_code2 n_temp2 VGND VGND sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M21 n_code3 n_temp3 VGND VGND sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M22 n_code4 n_temp4 VGND VGND sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M23 n_code5 n_temp5 VGND VGND sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M24 n_code6 n_temp6 VGND VGND sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M25 n_code7 n_temp7 VGND VGND sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M26 n_code8 n_temp8 VGND VGND sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M27 n_code9 n_temp9 VGND VGND sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M28 n_code10 n_temp10 VGND VGND sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M29 n_code11 n_temp11 VGND VGND sky130_fd_pr__nfet_01v8 W=0.84 L=0.15

M30 adc_valid sample_req VPWR VPWR sky130_fd_pr__pfet_01v8 W=1.2 L=0.15
M31 adc_valid n_vbn VGND VGND sky130_fd_pr__nfet_01v8 W=1.2 L=0.15

M32 adc_code[0] n_code0 VPWR VPWR sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M33 adc_code[0] n_vbn VGND VGND sky130_fd_pr__nfet_01v8 W=0.84 L=0.15

M34 adc_code[1] n_code1 VPWR VPWR sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M35 adc_code[1] n_vbn VGND VGND sky130_fd_pr__nfet_01v8 W=0.84 L=0.15

M36 adc_code[2] n_code2 VPWR VPWR sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M37 adc_code[2] n_vbn VGND VGND sky130_fd_pr__nfet_01v8 W=0.84 L=0.15

M38 adc_code[3] n_code3 VPWR VPWR sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M39 adc_code[3] n_vbn VGND VGND sky130_fd_pr__nfet_01v8 W=0.84 L=0.15

M40 adc_code[4] n_code4 VPWR VPWR sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M41 adc_code[4] n_vbn VGND VGND sky130_fd_pr__nfet_01v8 W=0.84 L=0.15

M42 adc_code[5] n_code5 VPWR VPWR sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M43 adc_code[5] n_vbn VGND VGND sky130_fd_pr__nfet_01v8 W=0.84 L=0.15

M44 adc_code[6] n_code6 VPWR VPWR sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M45 adc_code[6] n_vbn VGND VGND sky130_fd_pr__nfet_01v8 W=0.84 L=0.15

M46 adc_code[7] n_code7 VPWR VPWR sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M47 adc_code[7] n_vbn VGND VGND sky130_fd_pr__nfet_01v8 W=0.84 L=0.15

M48 adc_code[8] n_code8 VPWR VPWR sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M49 adc_code[8] n_vbn VGND VGND sky130_fd_pr__nfet_01v8 W=0.84 L=0.15

M50 adc_code[9] n_code9 VPWR VPWR sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M51 adc_code[9] n_vbn VGND VGND sky130_fd_pr__nfet_01v8 W=0.84 L=0.15

M52 adc_code[10] n_code10 VPWR VPWR sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M53 adc_code[10] n_vbn VGND VGND sky130_fd_pr__nfet_01v8 W=0.84 L=0.15

M54 adc_code[11] n_code11 VPWR VPWR sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M55 adc_code[11] n_vbn VGND VGND sky130_fd_pr__nfet_01v8 W=0.84 L=0.15

.ends temp_sensor_adc_model
.end
