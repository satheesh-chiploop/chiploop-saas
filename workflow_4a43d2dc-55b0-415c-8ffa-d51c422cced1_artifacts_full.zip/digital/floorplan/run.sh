#!/usr/bin/env bash
set -euo pipefail

echo "== ChipLoop: Digital Floorplan Agent =="
echo "PDK_VARIANT=sky130A"
echo "OPENLANE_IMAGE=ghcr.io/efabless/openlane2:2.4.0.dev1"
echo "WORKDIR=/work"

export OPENLANE_NUM_CORES=2

docker run --rm   -v "/root/chiploop-backend/backend/pdk":/pdk   -v "/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/4a43d2dc-55b0-415c-8ffa-d51c422cced1/44794d5b-1e3e-41ae-8e6f-fd37f8c578e0/digital/digital/run_work":/work   -e PDK=sky130A   -e PDK_ROOT=/pdk   ghcr.io/efabless/openlane2:2.4.0.dev1   bash -lc 'set -e; cd /work && openlane --flow Classic --run-tag System_PD_4a43d2dc-55b0-415c-8ffa-d51c422cced1 --override-config RUN_LINTER=False --to OpenROAD.Floorplan floorplan/config.json'


