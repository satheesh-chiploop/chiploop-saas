/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/4a43d2dc-55b0-415c-8ffa-d51c422cced1/44794d5b-1e3e-41ae-8e6f-fd37f8c578e0/digital/system/imported_rtl/temp_sensor_adc_model.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/4a43d2dc-55b0-415c-8ffa-d51c422cced1/44794d5b-1e3e-41ae-8e6f-fd37f8c578e0/digital/system/imported_rtl/temp_monitor_digital.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/4a43d2dc-55b0-415c-8ffa-d51c422cced1/44794d5b-1e3e-41ae-8e6f-fd37f8c578e0/digital/system/imported_rtl/temp_monitor_soc_phys.sv
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/4a43d2dc-55b0-415c-8ffa-d51c422cced1/44794d5b-1e3e-41ae-8e6f-fd37f8c578e0/digital/system/imported_rtl/temp_monitor_soc_sim.sv
