# Synthesis Readiness Report

- Top: `temp_monitor_soc_sim`
- RTL files: `4`
- Score (heuristic): **84/100**

## Timing/Area Intent Checks
- (info) No clocks found in spec. If synchronous, include clock intent (name + freq/period).
- (info) No performance/timing intent section found (latency/throughput/constraints).
- (info) No area/gatecount intent found. Provide rough bounds if needed.

## Synthesizable Subset Red Flags
Found **1** potential issues (showing up to 30):

- `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/29dbbcf7-c88a-4f5a-8d6c-f133fe15da47/b6295254-9688-4d35-ba31-70159d48c101/digital/system/imported_rtl/temp_sensor_adc_model.v:31` — Use of initial blocks may be non-synthesizable (ASIC) or tool-dependent (FPGA).  
  `...initial begin...`

## Yosys Synthesis Check
- Return code: `0`
- No Yosys ERROR lines detected.

### Warnings (first 20)
- Warning: Driver-driver conflict for \conversion_pending between cell $auto$ff.cc:266:slice$245.Q and constant 1'0 in temp_sensor_adc_model: Resolved using constant.
