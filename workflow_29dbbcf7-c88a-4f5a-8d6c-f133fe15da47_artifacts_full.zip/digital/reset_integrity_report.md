{
  "type": "reset_integrity_report",
  "version": "1.0",
  "rtl_file_count": 8,
  "detected_reset_signals": [
    "reset_n"
  ],
  "async_reset_blocks": [
    {
      "file": "artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/29dbbcf7-c88a-4f5a-8d6c-f133fe15da47/b6295254-9688-4d35-ba31-70159d48c101/digital/system/imported_rtl/temp_monitor_digital.v",
      "reset": "reset_n",
      "edge": "negedge"
    }
  ],
  "reset_usage_locations": [
    {
      "file": "artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/29dbbcf7-c88a-4f5a-8d6c-f133fe15da47/b6295254-9688-4d35-ba31-70159d48c101/digital/system/imported_rtl/temp_monitor_digital.v",
      "reset": "reset_n",
      "context": "if_condition"
    }
  ],
  "findings": [],
  "recommendations": [
    "Prefer async-assert / sync-deassert reset strategy in multi-clock designs.",
    "Ensure reset deassertion is synchronized per clock domain.",
    "Avoid mixing async and sync reset styles without clear intent.",
    "Add reset-specific assertions: no X after reset release; stable reset sequencing."
  ],
  "note": "Heuristic scan only; use signoff reset/CDC checks in enterprise flows when available."
}