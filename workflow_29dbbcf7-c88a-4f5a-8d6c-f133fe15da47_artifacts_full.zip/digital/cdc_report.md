{
  "type": "cdc_analysis_report",
  "version": "1.0",
  "inputs": {
    "clock_reset_intent_present": false,
    "rtl_file_count": 8
  },
  "observations": {
    "inferred_clocks": [
      "clk",
      "sample_req"
    ],
    "inferred_domains": [],
    "per_file": [
      {
        "file": "artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/29dbbcf7-c88a-4f5a-8d6c-f133fe15da47/b6295254-9688-4d35-ba31-70159d48c101/digital/system/imported_rtl/temp_monitor_digital.v",
        "clock": "clk",
        "domain": null
      },
      {
        "file": "artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/29dbbcf7-c88a-4f5a-8d6c-f133fe15da47/b6295254-9688-4d35-ba31-70159d48c101/digital/system/imported_rtl/temp_monitor_soc_phys.sv",
        "clock": null,
        "domain": null
      },
      {
        "file": "artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/29dbbcf7-c88a-4f5a-8d6c-f133fe15da47/b6295254-9688-4d35-ba31-70159d48c101/digital/system/imported_rtl/temp_monitor_soc_phys_pass1.sv",
        "clock": null,
        "domain": null
      },
      {
        "file": "artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/29dbbcf7-c88a-4f5a-8d6c-f133fe15da47/b6295254-9688-4d35-ba31-70159d48c101/digital/system/imported_rtl/temp_monitor_soc_sim.sv",
        "clock": null,
        "domain": null
      },
      {
        "file": "artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/29dbbcf7-c88a-4f5a-8d6c-f133fe15da47/b6295254-9688-4d35-ba31-70159d48c101/digital/system/imported_rtl/temp_monitor_soc_sim_pass1.sv",
        "clock": null,
        "domain": null
      },
      {
        "file": "artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/29dbbcf7-c88a-4f5a-8d6c-f133fe15da47/b6295254-9688-4d35-ba31-70159d48c101/digital/system/imported_rtl/temp_sensor_adc_model.v",
        "clock": "sample_req",
        "domain": null
      },
      {
        "file": "artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/29dbbcf7-c88a-4f5a-8d6c-f133fe15da47/b6295254-9688-4d35-ba31-70159d48c101/digital/vv/tb/temp_monitor_soc_sim_assertions.sv",
        "clock": null,
        "domain": null
      },
      {
        "file": "artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/29dbbcf7-c88a-4f5a-8d6c-f133fe15da47/b6295254-9688-4d35-ba31-70159d48c101/digital/vv/tb/temp_monitor_soc_sim_assertions_bind.sv",
        "clock": null,
        "domain": null
      }
    ]
  },
  "findings": [
    {
      "type": "potential_multi_clock_design",
      "severity": "warning",
      "msg": "Multiple clocks inferred in RTL: ['clk', 'sample_req']. Consider providing clock intent JSON."
    }
  ],
  "recommendations": [
    "Provide clock_reset_arch_intent.json for higher-fidelity CDC intent (domains, allowed crossings).",
    "For single-bit control crossings: use 2-flop synchronizers.",
    "For multi-bit data: use async FIFOs or validated handshake schemes.",
    "Run a real CDC tool in enterprise flow (Questa CDC / SpyGlass CDC / VC CDC) when available."
  ],
  "note": "This agent provides intent-level CDC screening. It is not a replacement for signoff CDC tools."
}