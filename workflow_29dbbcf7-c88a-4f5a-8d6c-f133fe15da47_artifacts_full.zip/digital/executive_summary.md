# Digital Executive Summary
- workflow_id: `29dbbcf7-c88a-4f5a-8d6c-f133fe15da47`
- run_tag: `None`
- run_work_dir: `None`

## Key Metrics (best-effort parsed)
- Cell count: `None`
- Area: `None`
- STA stage used: `None`
- Worst slack: `None`
- TNS: `None`
- DRC violations: `None`
- DRC status: `None`
- LVS status: `None`
- Tapeout status: `None`
- Tapeout LEC status: `None`
- ATPG status: `None`
- Summary status: `ok`

## STA Stage Breakdown
- sta_preplace: worst_slack=`None`, tns=`None`
- sta_postplace: worst_slack=`None`, tns=`None`
- sta_postcts: worst_slack=`None`, tns=`None`
- sta_postroute: worst_slack=`None`, tns=`None`

## GDS Paths (local, only if produced)
- KLayout GDS: `None`
- Magic GDS: `None`

## Artifact Map
- synth_metrics: `None`
- sta_preplace_metrics: `None`
- sta_postplace_metrics: `None`
- sta_postcts_metrics: `None`
- sta_postroute_metrics: `None`
- drc_metrics: `None`
- lvs_metrics: `None`
- tapeout_metrics: `None`

## Next Iteration Suggestions
- If worst_slack < 0: relax constraints or improve synthesis/placement/CTS/route parameters.
- If DRC violations > 0: inspect DRC logs and rerun with adjusted floorplan/route settings.
- If LVS not clean: check extraction/streamout mismatch and netlist naming.