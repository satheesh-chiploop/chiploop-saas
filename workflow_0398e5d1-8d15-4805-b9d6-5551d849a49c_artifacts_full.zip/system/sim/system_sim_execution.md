# System Simulation Execution Report

- Top: `temp_monitor_soc_sim`
- Tests run: 6
- Passed: 5
- Failed: 1
- Total runtime (s): 16.538
- Coverage JSON present: False
- Coverage MD present: False

## Run Matrix
- `system_smoke_test` / seed `1` → FAIL (rc=2, 1.383s)
- `system_smoke_test` / seed `2` → PASS (rc=0, 6.476s)
- `system_smoke_test` / seed `7` → PASS (rc=0, 2.084s)
- `integrated_input_sanity` / seed `1` → PASS (rc=0, 2.218s)
- `integrated_input_sanity` / seed `2` → PASS (rc=0, 2.281s)
- `integrated_input_sanity` / seed `7` → PASS (rc=0, 2.096s)

## Waveforms
- `vv/tb/dump.vcd`
