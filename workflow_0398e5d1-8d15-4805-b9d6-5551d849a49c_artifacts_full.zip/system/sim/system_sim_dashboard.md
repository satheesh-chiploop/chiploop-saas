# System Simulation Summary + Coverage

- Top module: temp_monitor_soc_sim
- Status: partial
- Total simulation runs: 6
- Simulation pass count: 5
- Simulation fail count: 1
- Total runtime (s): 16.538
- Coverage status: ok
- Functional coverage %: 73.33
- Coverage bins hit: 22
- Coverage total bins: 30
- Assertions total: 0
- Assertion failures: 0

## Waveforms
- `vv/tb/dump.vcd`
