# System Simulation Control

Generated files:
- `run_regression.py`: orchestrates multi-seed runs via `make TESTCASE=...`
- `simulation_manifest.json`: consolidated simulation-control manifest for the integrated system DUT

Key resolved inputs:
- Top module: `temp_monitor_soc_sim`
- System integration intent: `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0398e5d1-8d15-4805-b9d6-5551d849a49c/e47e15ab-ee76-45d4-a12c-58d75c9f5d70/digital/system/integration/system_integration_intent.json`
- SoC top (sim): `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0398e5d1-8d15-4805-b9d6-5551d849a49c/e47e15ab-ee76-45d4-a12c-58d75c9f5d70/digital/system/imported_rtl/temp_monitor_soc_sim.sv`
- RTL file count: `8`

Seed management:
- override with `RANDOM_SEED=<int>`

Usage:
```bash
python run_regression.py --tests system_smoke_test integrated_input_sanity --seeds 1 2 3 4 5
```
