# System Simulation Execution Report

- Top: `temp_monitor_soc_sim`
- Tests run: 6
- Passed: 0
- Failed: 6
- Total runtime (s): 14.417
- Coverage JSON present: False
- Coverage MD present: False

## Run Matrix
- `system_smoke_test` / seed `1` → FAIL (rc=2, 6.358s)
- `system_smoke_test` / seed `2` → FAIL (rc=2, 1.726s)
- `system_smoke_test` / seed `7` → FAIL (rc=2, 1.603s)
- `integrated_input_sanity` / seed `1` → FAIL (rc=2, 1.56s)
- `integrated_input_sanity` / seed `2` → FAIL (rc=2, 1.599s)
- `integrated_input_sanity` / seed `7` → FAIL (rc=2, 1.571s)
