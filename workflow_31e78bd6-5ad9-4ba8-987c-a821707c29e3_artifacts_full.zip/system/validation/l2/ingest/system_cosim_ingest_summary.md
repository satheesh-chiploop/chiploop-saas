# CoSim Ingest Summary

- Software package present: False
- Software L1 status: unknown
- Firmware package present: False
- Firmware ELF found: False
- Register map found: False
- Interrupt count: 0
- RTL package present: True
- RTL sim ready: True
- Ready for L2 contract: False
