module temp_sensor_adc_model (
    input  sample_req,
    input  [15:0] sensor_temp_celsius,
    input  avdd,
    input  avss,
    output reg [11:0] adc_code,
    output reg adc_valid
);

    localparam integer SAMPLE_LATENCY = 2;
    localparam integer NOMINAL_CODE_OFFSET = 2048;
    localparam integer TEMP_SCALE_NUM = 10;
    localparam integer TEMP_SCALE_DEN = 1;
    localparam integer GAIN_ERROR_PPM = 0;
    localparam integer OFFSET_ERROR_LSB = 0;

    reg [15:0] temp_sampled;
    reg [31:0] conversion_countdown;
    reg conversion_pending;

    reg [31:0] scaled_temp;
    reg [31:0] gain_adjusted;
    reg signed [33:0] code_calc_signed;
    reg [13:0] code_calc_clamped;

    wire sample_event;
    assign sample_event = sample_req;

    always @(*) begin
        scaled_temp = 32'd0;
        gain_adjusted = 32'd0;
        code_calc_signed = 34'sd0;
        code_calc_clamped = 14'd0;

        scaled_temp = (32'd0 + temp_sampled) * TEMP_SCALE_NUM;
        if (TEMP_SCALE_DEN != 0)
            scaled_temp = scaled_temp / TEMP_SCALE_DEN;

        gain_adjusted = scaled_temp + ((scaled_temp * GAIN_ERROR_PPM) / 1000000);

        code_calc_signed = $signed({1'b0, gain_adjusted}) + NOMINAL_CODE_OFFSET + OFFSET_ERROR_LSB;

        if (code_calc_signed < 0)
            code_calc_clamped = 14'd0;
        else if (code_calc_signed > 34'sd4095)
            code_calc_clamped = 14'd4095;
        else
            code_calc_clamped = code_calc_signed[13:0];
    end

    always @(posedge sample_event) begin
        temp_sampled <= sensor_temp_celsius;
        conversion_pending <= 1'b1;
        conversion_countdown <= SAMPLE_LATENCY[31:0];
    end

    always @(posedge sample_event or posedge conversion_pending) begin
        if (conversion_pending) begin
            if (conversion_countdown != 0) begin
                conversion_countdown <= conversion_countdown - 1'b1;
                adc_valid <= 1'b0;
            end else begin
                adc_code <= code_calc_clamped[11:0];
                adc_valid <= 1'b1;
                conversion_pending <= 1'b0;
            end
        end else begin
            adc_valid <= 1'b0;
        end
    end

    initial begin
        adc_code <= 12'd0;
        adc_valid <= 1'b0;
        temp_sampled <= 16'd0;
        conversion_countdown <= 32'd0;
        conversion_pending <= 1'b0;
    end

endmodule
