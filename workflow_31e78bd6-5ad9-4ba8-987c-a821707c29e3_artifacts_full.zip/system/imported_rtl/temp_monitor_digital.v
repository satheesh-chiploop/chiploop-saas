module temp_monitor_digital (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    adc_code,
    adc_valid,
    rd_data,
    sample_req,
    alert_irq,
    temp_code,
    threshold_code,
    alert_status
);

input clk;
input reset_n;
input wr_en;
input [7:0] wr_addr;
input [15:0] wr_data;
input rd_en;
input [7:0] rd_addr;
input [11:0] adc_code;
input adc_valid;

output [15:0] rd_data;
output sample_req;
output alert_irq;
output [11:0] temp_code;
output [11:0] threshold_code;
output alert_status;

reg [15:0] rd_data_r;
reg sample_req_r;
reg alert_irq_r;
reg [11:0] temp_code_r;
reg [11:0] threshold_code_r;
reg alert_status_r;

reg control_enable;
reg control_irq_enable;

reg status_sample_done;
reg status_alert_pending;
reg status_adc_valid_seen;
reg status_busy;

reg irq_status_alert;
reg irq_status_sample_done;

reg [11:0] latest_temp;
reg [15:0] sample_count;

reg [11:0] prev_adc_code;
reg prev_adc_valid;

wire [12:0] avg_sum_w;
wire [11:0] avg_temp_w;
wire sample_complete_w;
wire sample_start_pulse_w;
wire alert_clear_pulse_w;
wire irq_clear_alert_w;
wire irq_clear_sample_done_w;
wire periodic_sample_w;
wire sample_req_event_w;

assign avg_sum_w = {1'b0, adc_code} + {1'b0, prev_adc_code};
assign avg_temp_w = avg_sum_w[12:1];

assign sample_complete_w = adc_valid;
assign sample_start_pulse_w = wr_en && (wr_addr == 8'h00) && wr_data[1];
assign alert_clear_pulse_w = wr_en && (wr_addr == 8'h00) && wr_data[3];
assign irq_clear_alert_w = wr_en && (wr_addr == 8'h18) && wr_data[0];
assign irq_clear_sample_done_w = wr_en && (wr_addr == 8'h18) && wr_data[1];
assign periodic_sample_w = control_enable && !status_busy;
assign sample_req_event_w = sample_start_pulse_w | periodic_sample_w;

assign rd_data = rd_data_r;
assign sample_req = sample_req_r;
assign alert_irq = alert_irq_r;
assign temp_code = temp_code_r;
assign threshold_code = threshold_code_r;
assign alert_status = alert_status_r;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        rd_data_r <= 16'h0000;
        sample_req_r <= 1'b0;
        alert_irq_r <= 1'b0;
        temp_code_r <= 12'h000;
        threshold_code_r <= 12'h000;
        alert_status_r <= 1'b0;
        control_enable <= 1'b0;
        control_irq_enable <= 1'b0;
        status_sample_done <= 1'b0;
        status_alert_pending <= 1'b0;
        status_adc_valid_seen <= 1'b0;
        status_busy <= 1'b0;
        irq_status_alert <= 1'b0;
        irq_status_sample_done <= 1'b0;
        latest_temp <= 12'h000;
        sample_count <= 16'h0000;
        prev_adc_code <= 12'h000;
        prev_adc_valid <= 1'b0;
    end else begin
        sample_req_r <= sample_req_event_w;
        alert_irq_r <= control_irq_enable && (irq_status_alert || irq_status_sample_done);

        if (wr_en && (wr_addr == 8'h00)) begin
            control_enable <= wr_data[0];
            control_irq_enable <= wr_data[2];
            if (wr_data[3]) begin
                alert_status_r <= 1'b0;
                status_alert_pending <= 1'b0;
            end
        end

        if (wr_en && (wr_addr == 8'h08)) begin
            threshold_code_r <= wr_data[11:0];
        end

        if (wr_en && (wr_addr == 8'h18)) begin
            if (wr_data[0]) begin
                irq_status_alert <= 1'b0;
                alert_status_r <= 1'b0;
                status_alert_pending <= 1'b0;
            end
            if (wr_data[1]) begin
                irq_status_sample_done <= 1'b0;
                status_sample_done <= 1'b0;
            end
        end

        if (sample_complete_w) begin
            prev_adc_code <= adc_code;
            prev_adc_valid <= 1'b1;
            status_adc_valid_seen <= 1'b1;
            status_sample_done <= 1'b1;
            irq_status_sample_done <= 1'b1;
            sample_count <= sample_count + 16'h0001;
            latest_temp <= avg_temp_w;
            temp_code_r <= avg_temp_w;
            status_busy <= 1'b0;
            if (avg_temp_w > threshold_code_r) begin
                alert_status_r <= 1'b1;
                status_alert_pending <= 1'b1;
                irq_status_alert <= 1'b1;
            end
        end

        if (sample_req_event_w) begin
            status_busy <= 1'b1;
        end

        if (rd_en) begin
            case (rd_addr)
                8'h00: rd_data_r <= {12'h000, 1'b0, control_irq_enable, 1'b0, control_enable};
                8'h04: rd_data_r <= {12'h000, status_busy, status_adc_valid_seen, status_alert_pending, status_sample_done};
                8'h08: rd_data_r <= {4'h0, threshold_code_r};
                8'h0C: rd_data_r <= {4'h0, latest_temp};
                8'h10: rd_data_r <= sample_count;
                8'h14: rd_data_r <= {14'h0000, irq_status_sample_done, irq_status_alert};
                8'h18: rd_data_r <= 16'h0000;
                default: rd_data_r <= 16'h0000;
            endcase
        end else begin
            rd_data_r <= rd_data_r;
        end

        if (alert_clear_pulse_w) begin
            alert_status_r <= 1'b0;
            status_alert_pending <= 1'b0;
        end

        if (prev_adc_valid) begin
            prev_adc_valid <= prev_adc_valid;
        end
    end
end

endmodule
