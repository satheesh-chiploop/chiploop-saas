# System Functional Coverage (Cocotb)

Generated:
- `coverage_model.py`       : lightweight system functional coverage sampler
- `coverage_spec.json`      : resolved coverage points derived from integration + top RTL + regmap
- `coverage_generation_report.json` : concise agent output report

Usage (in cocotb tests):
- cov = CoverageModel()
- cov.start(dut)
- cov.sample() at transaction boundaries or checkpoints
- cov.note_register_write(reg_name, value) after software-visible writes when available
- cov.note_register_read(reg_name, value) after software-visible reads when available
- cov.stop()
- cov.write_reports() at end of sim

Reports emitted by CoverageModel:
- `reports/functional_coverage_summary.json`
- `reports/COVERAGE.md`
