# Tapeout Logic Equivalence Check

- Status: `incomplete_stdcell_models`
- Comparison: `synthesis_netlist_vs_tapeout_netlist`
- Top module: `pwm_controller`
- Reference netlist: `pwm_controller_synth.v`
- RTL files: `2`
- Tapeout netlist: `pwm_controller.pnl.v`
- Ignored physical-only gate ports: `VGND, VPWR`
- Ignored reference-only scan ports: `none`
- Standard-cell models loaded: `1`
- Missing standard-cell models: `1`
- Unproven points: `0`
- Return code: `None`
- Failure reason: `standard_cell_verilog_models_incomplete`

This is distinct from synthesis LEC. Tapeout LEC compares the final implementation netlist against the closest available proven reference netlist, falling back to RTL only when no gate reference exists.
