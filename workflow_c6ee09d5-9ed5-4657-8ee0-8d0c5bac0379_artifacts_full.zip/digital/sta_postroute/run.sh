#!/usr/bin/env bash
set -euo pipefail

echo "== ChipLoop: Digital STA PostRoute Agent =="
echo "PDK_VARIANT=sky130A"
echo "OPENLANE_IMAGE=ghcr.io/efabless/openlane2:2.4.0.dev1"
echo "WORKDIR=/work"

export OPENLANE_NUM_CORES=2

docker run --rm   -v "/root/chiploop-backend/backend/pdk":/pdk   -v "/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/c6ee09d5-9ed5-4657-8ee0-8d0c5bac0379/362198fc-5285-4d21-a0b0-582dddb95d2e/digital/arch2tapeout/digital/run_work":/work   -e PDK=sky130A   -e PDK_ROOT=/pdk   ghcr.io/efabless/openlane2:2.4.0.dev1   bash -lc 'set -e; cd /work && openlane --flow Classic --run-tag Digital_Arch2Tapeout_c6ee09d5-9ed5-4657-8ee0-8d0c5bac0379 --override-config RUN_LINTER=False --to OpenROAD.STAPostPNR sta_postroute/config.json'
