# Digital Synthesis Summary

- **Workflow**: c6ee09d5-9ed5-4657-8ee0-8d0c5bac0379
- **Status**: `ok` (rc=0)
- **Top module**: `pwm_controller`
- **Clock**: `clk` @ **10.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/c6ee09d5-9ed5-4657-8ee0-8d0c5bac0379/362198fc-5285-4d21-a0b0-582dddb95d2e/digital/arch2tapeout/digital/synth/runs/Digital_Arch2Tapeout_c6ee09d5-9ed5-4657-8ee0-8d0c5bac0379/final/metrics.json`
- netlist candidates: 1 found
