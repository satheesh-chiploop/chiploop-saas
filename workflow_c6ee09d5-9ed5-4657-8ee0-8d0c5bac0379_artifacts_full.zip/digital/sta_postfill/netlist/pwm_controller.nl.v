module pwm_controller (clk,
    pwm_out,
    rd_en,
    reset_n,
    wr_en,
    counter_value,
    rd_addr,
    rd_data,
    wr_addr,
    wr_data);
 input clk;
 output pwm_out;
 input rd_en;
 input reset_n;
 input wr_en;
 output [7:0] counter_value;
 input [7:0] rd_addr;
 output [7:0] rd_data;
 input [7:0] wr_addr;
 input [7:0] wr_data;

 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire _086_;
 wire _087_;
 wire _088_;
 wire _089_;
 wire _090_;
 wire _091_;
 wire _092_;
 wire _093_;
 wire _094_;
 wire _095_;
 wire _096_;
 wire _097_;
 wire _098_;
 wire _099_;
 wire _100_;
 wire _101_;
 wire _102_;
 wire \duty_cycle_reg[0] ;
 wire \duty_cycle_reg[1] ;
 wire \duty_cycle_reg[2] ;
 wire \duty_cycle_reg[3] ;
 wire \duty_cycle_reg[4] ;
 wire \duty_cycle_reg[5] ;
 wire \duty_cycle_reg[6] ;
 wire \duty_cycle_reg[7] ;
 wire enable_reg;
 wire \period_reg[0] ;
 wire \period_reg[1] ;
 wire \period_reg[2] ;
 wire \period_reg[3] ;
 wire \period_reg[4] ;
 wire \period_reg[5] ;
 wire \period_reg[6] ;
 wire \period_reg[7] ;
 wire net1;
 wire net2;
 wire net3;
 wire net4;
 wire net5;
 wire net6;
 wire net7;
 wire net8;
 wire net9;
 wire net10;
 wire net11;
 wire net12;
 wire net13;
 wire net14;
 wire net15;
 wire net16;
 wire net17;
 wire net18;
 wire net19;
 wire net20;
 wire net21;
 wire net22;
 wire net23;
 wire net24;
 wire net25;
 wire net26;
 wire net27;
 wire net28;
 wire net29;
 wire net30;
 wire net31;
 wire net32;
 wire net33;
 wire net34;
 wire net35;
 wire net36;
 wire net37;
 wire net38;
 wire net39;
 wire net40;
 wire net41;
 wire net42;
 wire net43;
 wire clknet_0_clk;
 wire clknet_1_0__leaf_clk;
 wire clknet_1_1__leaf_clk;

 sky130_fd_sc_hd__inv_2 _103_ (.A(net29),
    .Y(_094_));
 sky130_fd_sc_hd__inv_2 _104_ (.A(net27),
    .Y(_095_));
 sky130_fd_sc_hd__and2_1 _105_ (.A(_089_),
    .B(\duty_cycle_reg[7] ),
    .X(_096_));
 sky130_fd_sc_hd__nand2b_1 _106_ (.A_N(\duty_cycle_reg[1] ),
    .B(net28),
    .Y(_097_));
 sky130_fd_sc_hd__and2b_1 _107_ (.A_N(net29),
    .B(\duty_cycle_reg[2] ),
    .X(_098_));
 sky130_fd_sc_hd__and2b_1 _108_ (.A_N(net28),
    .B(\duty_cycle_reg[1] ),
    .X(_099_));
 sky130_fd_sc_hd__a311o_1 _109_ (.A1(\duty_cycle_reg[0] ),
    .A2(_095_),
    .A3(_097_),
    .B1(_098_),
    .C1(_099_),
    .X(_100_));
 sky130_fd_sc_hd__o22a_1 _110_ (.A1(\duty_cycle_reg[3] ),
    .A2(_093_),
    .B1(\duty_cycle_reg[2] ),
    .B2(_094_),
    .X(_101_));
 sky130_fd_sc_hd__a22o_1 _111_ (.A1(_092_),
    .A2(\duty_cycle_reg[4] ),
    .B1(\duty_cycle_reg[3] ),
    .B2(_093_),
    .X(_102_));
 sky130_fd_sc_hd__a21o_1 _112_ (.A1(_100_),
    .A2(_101_),
    .B1(_102_),
    .X(_025_));
 sky130_fd_sc_hd__o22a_1 _113_ (.A1(\duty_cycle_reg[5] ),
    .A2(_091_),
    .B1(_092_),
    .B2(\duty_cycle_reg[4] ),
    .X(_026_));
 sky130_fd_sc_hd__or4_1 _114_ (.A(\period_reg[1] ),
    .B(\period_reg[0] ),
    .C(\period_reg[3] ),
    .D(\period_reg[2] ),
    .X(_027_));
 sky130_fd_sc_hd__or4_2 _115_ (.A(\period_reg[5] ),
    .B(\period_reg[4] ),
    .C(\period_reg[7] ),
    .D(\period_reg[6] ),
    .X(_028_));
 sky130_fd_sc_hd__o21ai_4 _116_ (.A1(_027_),
    .A2(_028_),
    .B1(enable_reg),
    .Y(_029_));
 sky130_fd_sc_hd__inv_2 _117_ (.A(_029_),
    .Y(_030_));
 sky130_fd_sc_hd__or3_1 _118_ (.A(\duty_cycle_reg[6] ),
    .B(_090_),
    .C(_096_),
    .X(_031_));
 sky130_fd_sc_hd__o21a_1 _119_ (.A1(_089_),
    .A2(\duty_cycle_reg[7] ),
    .B1(_031_),
    .X(_032_));
 sky130_fd_sc_hd__a2bb2o_1 _120_ (.A1_N(_089_),
    .A2_N(\duty_cycle_reg[7] ),
    .B1(\duty_cycle_reg[6] ),
    .B2(_090_),
    .X(_033_));
 sky130_fd_sc_hd__a2bb2o_1 _121_ (.A1_N(\duty_cycle_reg[6] ),
    .A2_N(_090_),
    .B1(\duty_cycle_reg[5] ),
    .B2(_091_),
    .X(_034_));
 sky130_fd_sc_hd__a2111o_1 _122_ (.A1(_025_),
    .A2(_026_),
    .B1(_033_),
    .C1(_034_),
    .D1(_096_),
    .X(_035_));
 sky130_fd_sc_hd__and3_1 _123_ (.A(_030_),
    .B(_032_),
    .C(_035_),
    .X(net35));
 sky130_fd_sc_hd__nor4_1 _124_ (.A(net6),
    .B(net5),
    .C(net8),
    .D(net7),
    .Y(_036_));
 sky130_fd_sc_hd__and4bb_1 _125_ (.A_N(net2),
    .B_N(net1),
    .C(net4),
    .D(_036_),
    .X(_037_));
 sky130_fd_sc_hd__and2b_2 _126_ (.A_N(net3),
    .B(_037_),
    .X(_038_));
 sky130_fd_sc_hd__and2_2 _127_ (.A(net3),
    .B(_037_),
    .X(_039_));
 sky130_fd_sc_hd__mux2_1 _128_ (.A0(enable_reg),
    .A1(\duty_cycle_reg[0] ),
    .S(net3),
    .X(_040_));
 sky130_fd_sc_hd__nor3_1 _129_ (.A(net2),
    .B(net1),
    .C(net4),
    .Y(_041_));
 sky130_fd_sc_hd__and3_1 _130_ (.A(_036_),
    .B(_040_),
    .C(_041_),
    .X(_042_));
 sky130_fd_sc_hd__a221o_1 _131_ (.A1(\period_reg[0] ),
    .A2(_038_),
    .B1(_039_),
    .B2(net27),
    .C1(_042_),
    .X(net36));
 sky130_fd_sc_hd__and3_1 _132_ (.A(net28),
    .B(net3),
    .C(_037_),
    .X(_043_));
 sky130_fd_sc_hd__and3_2 _133_ (.A(net3),
    .B(_036_),
    .C(_041_),
    .X(_044_));
 sky130_fd_sc_hd__a221o_1 _134_ (.A1(\period_reg[1] ),
    .A2(_038_),
    .B1(_044_),
    .B2(\duty_cycle_reg[1] ),
    .C1(_043_),
    .X(net37));
 sky130_fd_sc_hd__and2_1 _135_ (.A(\duty_cycle_reg[2] ),
    .B(_044_),
    .X(_045_));
 sky130_fd_sc_hd__a221o_1 _136_ (.A1(\period_reg[2] ),
    .A2(_038_),
    .B1(_039_),
    .B2(net29),
    .C1(_045_),
    .X(net38));
 sky130_fd_sc_hd__and3_1 _137_ (.A(net30),
    .B(net3),
    .C(_037_),
    .X(_046_));
 sky130_fd_sc_hd__a221o_1 _138_ (.A1(\period_reg[3] ),
    .A2(_038_),
    .B1(_044_),
    .B2(\duty_cycle_reg[3] ),
    .C1(_046_),
    .X(net39));
 sky130_fd_sc_hd__and2_1 _139_ (.A(\duty_cycle_reg[4] ),
    .B(_044_),
    .X(_047_));
 sky130_fd_sc_hd__a221o_1 _140_ (.A1(\period_reg[4] ),
    .A2(_038_),
    .B1(_039_),
    .B2(net31),
    .C1(_047_),
    .X(net40));
 sky130_fd_sc_hd__and2_1 _141_ (.A(\duty_cycle_reg[5] ),
    .B(_044_),
    .X(_048_));
 sky130_fd_sc_hd__a221o_1 _142_ (.A1(\period_reg[5] ),
    .A2(_038_),
    .B1(_039_),
    .B2(net32),
    .C1(_048_),
    .X(net41));
 sky130_fd_sc_hd__and2_1 _143_ (.A(\duty_cycle_reg[6] ),
    .B(_044_),
    .X(_049_));
 sky130_fd_sc_hd__a221o_1 _144_ (.A1(\period_reg[6] ),
    .A2(_038_),
    .B1(_039_),
    .B2(net33),
    .C1(_049_),
    .X(net42));
 sky130_fd_sc_hd__and2_1 _145_ (.A(\duty_cycle_reg[7] ),
    .B(_044_),
    .X(_050_));
 sky130_fd_sc_hd__a221o_1 _146_ (.A1(\period_reg[7] ),
    .A2(_038_),
    .B1(_039_),
    .B2(net34),
    .C1(_050_),
    .X(net43));
 sky130_fd_sc_hd__nor2_1 _147_ (.A(\period_reg[7] ),
    .B(_089_),
    .Y(_051_));
 sky130_fd_sc_hd__nand2b_1 _148_ (.A_N(net34),
    .B(\period_reg[7] ),
    .Y(_052_));
 sky130_fd_sc_hd__o21ai_1 _149_ (.A1(_088_),
    .A2(net33),
    .B1(_052_),
    .Y(_053_));
 sky130_fd_sc_hd__a211o_1 _150_ (.A1(_088_),
    .A2(net33),
    .B1(_051_),
    .C1(_053_),
    .X(_054_));
 sky130_fd_sc_hd__o22a_1 _151_ (.A1(\period_reg[5] ),
    .A2(_091_),
    .B1(_092_),
    .B2(\period_reg[4] ),
    .X(_055_));
 sky130_fd_sc_hd__o22a_1 _152_ (.A1(\period_reg[3] ),
    .A2(_093_),
    .B1(_094_),
    .B2(\period_reg[2] ),
    .X(_056_));
 sky130_fd_sc_hd__nand2b_1 _153_ (.A_N(\period_reg[1] ),
    .B(net28),
    .Y(_057_));
 sky130_fd_sc_hd__and2b_1 _154_ (.A_N(net29),
    .B(\period_reg[2] ),
    .X(_058_));
 sky130_fd_sc_hd__and2b_1 _155_ (.A_N(net28),
    .B(\period_reg[1] ),
    .X(_059_));
 sky130_fd_sc_hd__a311o_1 _156_ (.A1(\period_reg[0] ),
    .A2(_095_),
    .A3(_057_),
    .B1(_058_),
    .C1(_059_),
    .X(_060_));
 sky130_fd_sc_hd__a22o_1 _157_ (.A1(\period_reg[4] ),
    .A2(_092_),
    .B1(_093_),
    .B2(\period_reg[3] ),
    .X(_061_));
 sky130_fd_sc_hd__a21o_1 _158_ (.A1(_056_),
    .A2(_060_),
    .B1(_061_),
    .X(_062_));
 sky130_fd_sc_hd__a221o_2 _159_ (.A1(\period_reg[5] ),
    .A2(_091_),
    .B1(_055_),
    .B2(_062_),
    .C1(_054_),
    .X(_063_));
 sky130_fd_sc_hd__a311oi_4 _160_ (.A1(_088_),
    .A2(net33),
    .A3(_052_),
    .B1(_051_),
    .C1(_029_),
    .Y(_064_));
 sky130_fd_sc_hd__nor2_1 _161_ (.A(_095_),
    .B(_030_),
    .Y(_065_));
 sky130_fd_sc_hd__a31o_1 _162_ (.A1(_095_),
    .A2(_063_),
    .A3(_064_),
    .B1(_065_),
    .X(_000_));
 sky130_fd_sc_hd__xor2_1 _163_ (.A(net28),
    .B(net27),
    .X(_066_));
 sky130_fd_sc_hd__a32o_1 _164_ (.A1(_063_),
    .A2(_064_),
    .A3(_066_),
    .B1(_029_),
    .B2(net28),
    .X(_001_));
 sky130_fd_sc_hd__and3_1 _165_ (.A(net29),
    .B(net28),
    .C(net27),
    .X(_067_));
 sky130_fd_sc_hd__a21oi_1 _166_ (.A1(net28),
    .A2(net27),
    .B1(net29),
    .Y(_068_));
 sky130_fd_sc_hd__nor2_1 _167_ (.A(_067_),
    .B(_068_),
    .Y(_069_));
 sky130_fd_sc_hd__a32o_1 _168_ (.A1(_063_),
    .A2(_064_),
    .A3(_069_),
    .B1(_029_),
    .B2(net29),
    .X(_002_));
 sky130_fd_sc_hd__nor2_1 _169_ (.A(net30),
    .B(_067_),
    .Y(_070_));
 sky130_fd_sc_hd__and4_1 _170_ (.A(net30),
    .B(net29),
    .C(net28),
    .D(net27),
    .X(_071_));
 sky130_fd_sc_hd__nor2_1 _171_ (.A(_070_),
    .B(_071_),
    .Y(_072_));
 sky130_fd_sc_hd__a32o_1 _172_ (.A1(_063_),
    .A2(_064_),
    .A3(_072_),
    .B1(_029_),
    .B2(net30),
    .X(_003_));
 sky130_fd_sc_hd__xnor2_1 _173_ (.A(_092_),
    .B(_071_),
    .Y(_073_));
 sky130_fd_sc_hd__a32o_1 _174_ (.A1(_063_),
    .A2(_064_),
    .A3(_073_),
    .B1(_029_),
    .B2(net31),
    .X(_004_));
 sky130_fd_sc_hd__a21oi_1 _175_ (.A1(net31),
    .A2(_071_),
    .B1(net32),
    .Y(_074_));
 sky130_fd_sc_hd__and3_1 _176_ (.A(net32),
    .B(net31),
    .C(_071_),
    .X(_075_));
 sky130_fd_sc_hd__nor2_1 _177_ (.A(_074_),
    .B(_075_),
    .Y(_076_));
 sky130_fd_sc_hd__a32o_1 _178_ (.A1(_063_),
    .A2(_064_),
    .A3(_076_),
    .B1(_029_),
    .B2(net32),
    .X(_005_));
 sky130_fd_sc_hd__nor2_1 _179_ (.A(net33),
    .B(_075_),
    .Y(_077_));
 sky130_fd_sc_hd__nand2_1 _180_ (.A(net33),
    .B(_075_),
    .Y(_078_));
 sky130_fd_sc_hd__and2b_1 _181_ (.A_N(_077_),
    .B(_078_),
    .X(_079_));
 sky130_fd_sc_hd__a32o_1 _182_ (.A1(_063_),
    .A2(_064_),
    .A3(_079_),
    .B1(_029_),
    .B2(net33),
    .X(_006_));
 sky130_fd_sc_hd__xnor2_1 _183_ (.A(net34),
    .B(_078_),
    .Y(_080_));
 sky130_fd_sc_hd__a32o_1 _184_ (.A1(_063_),
    .A2(_064_),
    .A3(_080_),
    .B1(_029_),
    .B2(net34),
    .X(_007_));
 sky130_fd_sc_hd__or3_1 _185_ (.A(net15),
    .B(net14),
    .C(net17),
    .X(_081_));
 sky130_fd_sc_hd__or3b_1 _186_ (.A(_081_),
    .B(net16),
    .C_N(net26),
    .X(_082_));
 sky130_fd_sc_hd__or2_1 _187_ (.A(net13),
    .B(_082_),
    .X(_083_));
 sky130_fd_sc_hd__or4_1 _188_ (.A(net11),
    .B(net10),
    .C(net12),
    .D(_083_),
    .X(_084_));
 sky130_fd_sc_hd__mux2_1 _189_ (.A0(net18),
    .A1(enable_reg),
    .S(_084_),
    .X(_008_));
 sky130_fd_sc_hd__nor4b_4 _190_ (.A(net11),
    .B(_083_),
    .C(net10),
    .D_N(net12),
    .Y(_085_));
 sky130_fd_sc_hd__mux2_1 _191_ (.A0(\duty_cycle_reg[0] ),
    .A1(net18),
    .S(_085_),
    .X(_009_));
 sky130_fd_sc_hd__mux2_1 _192_ (.A0(\duty_cycle_reg[1] ),
    .A1(net19),
    .S(_085_),
    .X(_010_));
 sky130_fd_sc_hd__mux2_1 _193_ (.A0(\duty_cycle_reg[2] ),
    .A1(net20),
    .S(_085_),
    .X(_011_));
 sky130_fd_sc_hd__mux2_1 _194_ (.A0(\duty_cycle_reg[3] ),
    .A1(net21),
    .S(_085_),
    .X(_012_));
 sky130_fd_sc_hd__mux2_1 _195_ (.A0(\duty_cycle_reg[4] ),
    .A1(net22),
    .S(_085_),
    .X(_013_));
 sky130_fd_sc_hd__mux2_1 _196_ (.A0(\duty_cycle_reg[5] ),
    .A1(net23),
    .S(_085_),
    .X(_014_));
 sky130_fd_sc_hd__mux2_1 _197_ (.A0(\duty_cycle_reg[6] ),
    .A1(net24),
    .S(_085_),
    .X(_015_));
 sky130_fd_sc_hd__mux2_1 _198_ (.A0(\duty_cycle_reg[7] ),
    .A1(net25),
    .S(_085_),
    .X(_016_));
 sky130_fd_sc_hd__or4b_1 _199_ (.A(net11),
    .B(net10),
    .C(net12),
    .D_N(net13),
    .X(_086_));
 sky130_fd_sc_hd__or2_4 _200_ (.A(_082_),
    .B(_086_),
    .X(_087_));
 sky130_fd_sc_hd__mux2_1 _201_ (.A0(net18),
    .A1(\period_reg[0] ),
    .S(_087_),
    .X(_017_));
 sky130_fd_sc_hd__mux2_1 _202_ (.A0(net19),
    .A1(\period_reg[1] ),
    .S(_087_),
    .X(_018_));
 sky130_fd_sc_hd__mux2_1 _203_ (.A0(net20),
    .A1(\period_reg[2] ),
    .S(_087_),
    .X(_019_));
 sky130_fd_sc_hd__mux2_1 _204_ (.A0(net21),
    .A1(\period_reg[3] ),
    .S(_087_),
    .X(_020_));
 sky130_fd_sc_hd__mux2_1 _205_ (.A0(net22),
    .A1(\period_reg[4] ),
    .S(_087_),
    .X(_021_));
 sky130_fd_sc_hd__mux2_1 _206_ (.A0(net23),
    .A1(\period_reg[5] ),
    .S(_087_),
    .X(_022_));
 sky130_fd_sc_hd__mux2_1 _207_ (.A0(net24),
    .A1(\period_reg[6] ),
    .S(_087_),
    .X(_023_));
 sky130_fd_sc_hd__mux2_1 _208_ (.A0(net25),
    .A1(\period_reg[7] ),
    .S(_087_),
    .X(_024_));
 sky130_fd_sc_hd__inv_2 _209_ (.A(\period_reg[6] ),
    .Y(_088_));
 sky130_fd_sc_hd__inv_2 _210_ (.A(net34),
    .Y(_089_));
 sky130_fd_sc_hd__inv_2 _211_ (.A(net33),
    .Y(_090_));
 sky130_fd_sc_hd__inv_2 _212_ (.A(net32),
    .Y(_091_));
 sky130_fd_sc_hd__inv_2 _213_ (.A(net31),
    .Y(_092_));
 sky130_fd_sc_hd__inv_2 _214_ (.A(net30),
    .Y(_093_));
 sky130_fd_sc_hd__dfrtp_4 _215_ (.CLK(clknet_1_1__leaf_clk),
    .D(_000_),
    .RESET_B(net9),
    .Q(net27));
 sky130_fd_sc_hd__dfrtp_4 _216_ (.CLK(clknet_1_1__leaf_clk),
    .D(_001_),
    .RESET_B(net9),
    .Q(net28));
 sky130_fd_sc_hd__dfrtp_4 _217_ (.CLK(clknet_1_1__leaf_clk),
    .D(_002_),
    .RESET_B(net9),
    .Q(net29));
 sky130_fd_sc_hd__dfrtp_2 _218_ (.CLK(clknet_1_1__leaf_clk),
    .D(_003_),
    .RESET_B(net9),
    .Q(net30));
 sky130_fd_sc_hd__dfrtp_2 _219_ (.CLK(clknet_1_1__leaf_clk),
    .D(_004_),
    .RESET_B(net9),
    .Q(net31));
 sky130_fd_sc_hd__dfrtp_2 _220_ (.CLK(clknet_1_1__leaf_clk),
    .D(_005_),
    .RESET_B(net9),
    .Q(net32));
 sky130_fd_sc_hd__dfrtp_4 _221_ (.CLK(clknet_1_1__leaf_clk),
    .D(_006_),
    .RESET_B(net9),
    .Q(net33));
 sky130_fd_sc_hd__dfrtp_2 _222_ (.CLK(clknet_1_1__leaf_clk),
    .D(_007_),
    .RESET_B(net9),
    .Q(net34));
 sky130_fd_sc_hd__dfrtp_2 _223_ (.CLK(clknet_1_0__leaf_clk),
    .D(_008_),
    .RESET_B(net9),
    .Q(enable_reg));
 sky130_fd_sc_hd__dfrtp_1 _224_ (.CLK(clknet_1_0__leaf_clk),
    .D(_009_),
    .RESET_B(net9),
    .Q(\duty_cycle_reg[0] ));
 sky130_fd_sc_hd__dfrtp_1 _225_ (.CLK(clknet_1_0__leaf_clk),
    .D(_010_),
    .RESET_B(net9),
    .Q(\duty_cycle_reg[1] ));
 sky130_fd_sc_hd__dfrtp_1 _226_ (.CLK(clknet_1_0__leaf_clk),
    .D(_011_),
    .RESET_B(net9),
    .Q(\duty_cycle_reg[2] ));
 sky130_fd_sc_hd__dfrtp_1 _227_ (.CLK(clknet_1_0__leaf_clk),
    .D(_012_),
    .RESET_B(net9),
    .Q(\duty_cycle_reg[3] ));
 sky130_fd_sc_hd__dfrtp_1 _228_ (.CLK(clknet_1_0__leaf_clk),
    .D(_013_),
    .RESET_B(net9),
    .Q(\duty_cycle_reg[4] ));
 sky130_fd_sc_hd__dfrtp_1 _229_ (.CLK(clknet_1_0__leaf_clk),
    .D(_014_),
    .RESET_B(net9),
    .Q(\duty_cycle_reg[5] ));
 sky130_fd_sc_hd__dfrtp_1 _230_ (.CLK(clknet_1_0__leaf_clk),
    .D(_015_),
    .RESET_B(net9),
    .Q(\duty_cycle_reg[6] ));
 sky130_fd_sc_hd__dfrtp_1 _231_ (.CLK(clknet_1_0__leaf_clk),
    .D(_016_),
    .RESET_B(net9),
    .Q(\duty_cycle_reg[7] ));
 sky130_fd_sc_hd__dfrtp_1 _232_ (.CLK(clknet_1_0__leaf_clk),
    .D(_017_),
    .RESET_B(net9),
    .Q(\period_reg[0] ));
 sky130_fd_sc_hd__dfrtp_1 _233_ (.CLK(clknet_1_0__leaf_clk),
    .D(_018_),
    .RESET_B(net9),
    .Q(\period_reg[1] ));
 sky130_fd_sc_hd__dfrtp_1 _234_ (.CLK(clknet_1_1__leaf_clk),
    .D(_019_),
    .RESET_B(net9),
    .Q(\period_reg[2] ));
 sky130_fd_sc_hd__dfrtp_1 _235_ (.CLK(clknet_1_0__leaf_clk),
    .D(_020_),
    .RESET_B(net9),
    .Q(\period_reg[3] ));
 sky130_fd_sc_hd__dfrtp_1 _236_ (.CLK(clknet_1_0__leaf_clk),
    .D(_021_),
    .RESET_B(net9),
    .Q(\period_reg[4] ));
 sky130_fd_sc_hd__dfrtp_1 _237_ (.CLK(clknet_1_0__leaf_clk),
    .D(_022_),
    .RESET_B(net9),
    .Q(\period_reg[5] ));
 sky130_fd_sc_hd__dfrtp_1 _238_ (.CLK(clknet_1_0__leaf_clk),
    .D(_023_),
    .RESET_B(net9),
    .Q(\period_reg[6] ));
 sky130_fd_sc_hd__dfrtp_1 _239_ (.CLK(clknet_1_0__leaf_clk),
    .D(_024_),
    .RESET_B(net9),
    .Q(\period_reg[7] ));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_0_Right_0 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_1_Right_1 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_2_Right_2 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_3_Right_3 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_4_Right_4 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_5_Right_5 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_6_Right_6 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_7_Right_7 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_8_Right_8 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_9_Right_9 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_10_Right_10 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_11_Right_11 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_12_Right_12 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_13_Right_13 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_14_Right_14 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_15_Right_15 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_16_Right_16 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_17_Right_17 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_18_Right_18 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_19_Right_19 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_20_Right_20 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_21_Right_21 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_22_Right_22 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_23_Right_23 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_24_Right_24 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_25_Right_25 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_Right_26 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_Right_27 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_Right_28 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_Right_29 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_Right_30 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_31_Right_31 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_32_Right_32 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_0_Left_33 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_1_Left_34 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_2_Left_35 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_3_Left_36 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_4_Left_37 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_5_Left_38 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_6_Left_39 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_7_Left_40 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_8_Left_41 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_9_Left_42 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_10_Left_43 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_11_Left_44 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_12_Left_45 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_13_Left_46 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_14_Left_47 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_15_Left_48 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_16_Left_49 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_17_Left_50 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_18_Left_51 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_19_Left_52 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_20_Left_53 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_21_Left_54 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_22_Left_55 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_23_Left_56 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_24_Left_57 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_25_Left_58 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_Left_59 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_Left_60 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_Left_61 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_Left_62 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_Left_63 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_31_Left_64 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_32_Left_65 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_66 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_67 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_68 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_69 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_70 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_71 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_72 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_73 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_74 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_75 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_76 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_77 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_78 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_79 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_80 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_81 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_82 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_83 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_84 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_85 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_86 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_87 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_88 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_89 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_90 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_91 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_92 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_93 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_94 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_95 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_96 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_97 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_98 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_99 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_100 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_101 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_102 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_103 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_104 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_105 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_106 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_107 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_108 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_109 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_110 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_111 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_112 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_113 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_114 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_115 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_116 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_117 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_118 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_119 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_120 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_121 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_122 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_123 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_124 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_125 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_126 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_127 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_128 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_129 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_130 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_131 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_132 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_133 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_134 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_135 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_136 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_137 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_138 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_139 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_140 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_141 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_142 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_143 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_144 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_145 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_146 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_147 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_148 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_149 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_150 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_151 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_152 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_153 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_154 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_155 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_156 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_157 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_158 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_159 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_160 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_161 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_162 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_163 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_164 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_165 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_166 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_167 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_168 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_169 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_170 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_171 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_172 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_173 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_174 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_175 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_176 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_177 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_178 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_179 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_180 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_181 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_182 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_183 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_184 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_185 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_186 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_187 ();
 sky130_fd_sc_hd__clkbuf_1 input1 (.A(rd_addr[0]),
    .X(net1));
 sky130_fd_sc_hd__clkbuf_1 input2 (.A(rd_addr[1]),
    .X(net2));
 sky130_fd_sc_hd__buf_1 input3 (.A(rd_addr[2]),
    .X(net3));
 sky130_fd_sc_hd__clkbuf_1 input4 (.A(rd_addr[3]),
    .X(net4));
 sky130_fd_sc_hd__clkbuf_1 input5 (.A(rd_addr[4]),
    .X(net5));
 sky130_fd_sc_hd__clkbuf_1 input6 (.A(rd_addr[5]),
    .X(net6));
 sky130_fd_sc_hd__clkbuf_1 input7 (.A(rd_addr[6]),
    .X(net7));
 sky130_fd_sc_hd__clkbuf_1 input8 (.A(rd_addr[7]),
    .X(net8));
 sky130_fd_sc_hd__buf_8 input9 (.A(reset_n),
    .X(net9));
 sky130_fd_sc_hd__buf_1 input10 (.A(wr_addr[0]),
    .X(net10));
 sky130_fd_sc_hd__buf_1 input11 (.A(wr_addr[1]),
    .X(net11));
 sky130_fd_sc_hd__buf_1 input12 (.A(wr_addr[2]),
    .X(net12));
 sky130_fd_sc_hd__clkbuf_1 input13 (.A(wr_addr[3]),
    .X(net13));
 sky130_fd_sc_hd__clkbuf_1 input14 (.A(wr_addr[4]),
    .X(net14));
 sky130_fd_sc_hd__clkbuf_1 input15 (.A(wr_addr[5]),
    .X(net15));
 sky130_fd_sc_hd__clkbuf_1 input16 (.A(wr_addr[6]),
    .X(net16));
 sky130_fd_sc_hd__clkbuf_1 input17 (.A(wr_addr[7]),
    .X(net17));
 sky130_fd_sc_hd__buf_1 input18 (.A(wr_data[0]),
    .X(net18));
 sky130_fd_sc_hd__clkbuf_1 input19 (.A(wr_data[1]),
    .X(net19));
 sky130_fd_sc_hd__clkbuf_1 input20 (.A(wr_data[2]),
    .X(net20));
 sky130_fd_sc_hd__clkbuf_1 input21 (.A(wr_data[3]),
    .X(net21));
 sky130_fd_sc_hd__clkbuf_1 input22 (.A(wr_data[4]),
    .X(net22));
 sky130_fd_sc_hd__clkbuf_1 input23 (.A(wr_data[5]),
    .X(net23));
 sky130_fd_sc_hd__clkbuf_1 input24 (.A(wr_data[6]),
    .X(net24));
 sky130_fd_sc_hd__clkbuf_1 input25 (.A(wr_data[7]),
    .X(net25));
 sky130_fd_sc_hd__clkbuf_1 input26 (.A(wr_en),
    .X(net26));
 sky130_fd_sc_hd__buf_1 output27 (.A(net27),
    .X(counter_value[0]));
 sky130_fd_sc_hd__buf_1 output28 (.A(net28),
    .X(counter_value[1]));
 sky130_fd_sc_hd__buf_1 output29 (.A(net29),
    .X(counter_value[2]));
 sky130_fd_sc_hd__buf_1 output30 (.A(net30),
    .X(counter_value[3]));
 sky130_fd_sc_hd__buf_1 output31 (.A(net31),
    .X(counter_value[4]));
 sky130_fd_sc_hd__buf_1 output32 (.A(net32),
    .X(counter_value[5]));
 sky130_fd_sc_hd__buf_1 output33 (.A(net33),
    .X(counter_value[6]));
 sky130_fd_sc_hd__buf_1 output34 (.A(net34),
    .X(counter_value[7]));
 sky130_fd_sc_hd__buf_1 output35 (.A(net35),
    .X(pwm_out));
 sky130_fd_sc_hd__buf_1 output36 (.A(net36),
    .X(rd_data[0]));
 sky130_fd_sc_hd__buf_1 output37 (.A(net37),
    .X(rd_data[1]));
 sky130_fd_sc_hd__buf_1 output38 (.A(net38),
    .X(rd_data[2]));
 sky130_fd_sc_hd__buf_1 output39 (.A(net39),
    .X(rd_data[3]));
 sky130_fd_sc_hd__buf_1 output40 (.A(net40),
    .X(rd_data[4]));
 sky130_fd_sc_hd__buf_1 output41 (.A(net41),
    .X(rd_data[5]));
 sky130_fd_sc_hd__buf_1 output42 (.A(net42),
    .X(rd_data[6]));
 sky130_fd_sc_hd__buf_1 output43 (.A(net43),
    .X(rd_data[7]));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_0_clk (.A(clk),
    .X(clknet_0_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_1_0__f_clk (.A(clknet_0_clk),
    .X(clknet_1_0__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_1_1__f_clk (.A(clknet_0_clk),
    .X(clknet_1_1__leaf_clk));
 sky130_fd_sc_hd__inv_6 clkload0 (.A(clknet_1_1__leaf_clk));
 sky130_ef_sc_hd__decap_12 FILLER_0_3 ();
 sky130_ef_sc_hd__decap_12 FILLER_0_15 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_27 ();
 sky130_fd_sc_hd__decap_8 FILLER_0_29 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_37 ();
 sky130_ef_sc_hd__decap_12 FILLER_0_41 ();
 sky130_fd_sc_hd__decap_3 FILLER_0_53 ();
 sky130_fd_sc_hd__decap_8 FILLER_0_57 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_65 ();
 sky130_fd_sc_hd__decap_4 FILLER_0_69 ();
 sky130_fd_sc_hd__decap_8 FILLER_0_76 ();
 sky130_ef_sc_hd__decap_12 FILLER_0_85 ();
 sky130_fd_sc_hd__decap_4 FILLER_0_97 ();
 sky130_fd_sc_hd__decap_8 FILLER_0_104 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_113 ();
 sky130_fd_sc_hd__decap_4 FILLER_0_118 ();
 sky130_fd_sc_hd__decap_4 FILLER_0_125 ();
 sky130_fd_sc_hd__decap_4 FILLER_0_132 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_139 ();
 sky130_ef_sc_hd__decap_12 FILLER_0_141 ();
 sky130_ef_sc_hd__decap_12 FILLER_0_153 ();
 sky130_fd_sc_hd__decap_3 FILLER_0_165 ();
 sky130_ef_sc_hd__decap_12 FILLER_0_169 ();
 sky130_ef_sc_hd__decap_12 FILLER_0_181 ();
 sky130_fd_sc_hd__decap_3 FILLER_0_193 ();
 sky130_ef_sc_hd__decap_12 FILLER_1_3 ();
 sky130_ef_sc_hd__decap_12 FILLER_1_15 ();
 sky130_ef_sc_hd__decap_12 FILLER_1_27 ();
 sky130_ef_sc_hd__decap_12 FILLER_1_39 ();
 sky130_fd_sc_hd__decap_4 FILLER_1_51 ();
 sky130_fd_sc_hd__fill_1 FILLER_1_55 ();
 sky130_ef_sc_hd__decap_12 FILLER_1_57 ();
 sky130_ef_sc_hd__decap_12 FILLER_1_69 ();
 sky130_ef_sc_hd__decap_12 FILLER_1_81 ();
 sky130_ef_sc_hd__decap_12 FILLER_1_93 ();
 sky130_fd_sc_hd__decap_6 FILLER_1_105 ();
 sky130_fd_sc_hd__fill_1 FILLER_1_111 ();
 sky130_ef_sc_hd__decap_12 FILLER_1_113 ();
 sky130_ef_sc_hd__decap_12 FILLER_1_125 ();
 sky130_ef_sc_hd__decap_12 FILLER_1_137 ();
 sky130_ef_sc_hd__decap_12 FILLER_1_149 ();
 sky130_fd_sc_hd__decap_6 FILLER_1_161 ();
 sky130_fd_sc_hd__fill_1 FILLER_1_167 ();
 sky130_ef_sc_hd__decap_12 FILLER_1_169 ();
 sky130_ef_sc_hd__decap_12 FILLER_1_181 ();
 sky130_fd_sc_hd__decap_4 FILLER_1_193 ();
 sky130_ef_sc_hd__decap_12 FILLER_2_3 ();
 sky130_ef_sc_hd__decap_12 FILLER_2_15 ();
 sky130_fd_sc_hd__fill_1 FILLER_2_27 ();
 sky130_ef_sc_hd__decap_12 FILLER_2_29 ();
 sky130_ef_sc_hd__decap_12 FILLER_2_41 ();
 sky130_fd_sc_hd__decap_8 FILLER_2_53 ();
 sky130_fd_sc_hd__fill_2 FILLER_2_61 ();
 sky130_fd_sc_hd__fill_1 FILLER_2_83 ();
 sky130_ef_sc_hd__decap_12 FILLER_2_85 ();
 sky130_ef_sc_hd__decap_12 FILLER_2_97 ();
 sky130_fd_sc_hd__decap_8 FILLER_2_109 ();
 sky130_fd_sc_hd__fill_2 FILLER_2_117 ();
 sky130_ef_sc_hd__decap_12 FILLER_2_124 ();
 sky130_fd_sc_hd__decap_4 FILLER_2_136 ();
 sky130_ef_sc_hd__decap_12 FILLER_2_141 ();
 sky130_ef_sc_hd__decap_12 FILLER_2_153 ();
 sky130_ef_sc_hd__decap_12 FILLER_2_165 ();
 sky130_ef_sc_hd__decap_12 FILLER_2_177 ();
 sky130_fd_sc_hd__decap_6 FILLER_2_189 ();
 sky130_fd_sc_hd__fill_1 FILLER_2_195 ();
 sky130_ef_sc_hd__decap_12 FILLER_3_3 ();
 sky130_ef_sc_hd__decap_12 FILLER_3_15 ();
 sky130_fd_sc_hd__decap_6 FILLER_3_27 ();
 sky130_fd_sc_hd__decap_3 FILLER_3_53 ();
 sky130_fd_sc_hd__decap_8 FILLER_3_57 ();
 sky130_ef_sc_hd__decap_12 FILLER_3_94 ();
 sky130_fd_sc_hd__decap_6 FILLER_3_106 ();
 sky130_fd_sc_hd__fill_2 FILLER_3_113 ();
 sky130_ef_sc_hd__decap_12 FILLER_3_131 ();
 sky130_fd_sc_hd__fill_2 FILLER_3_143 ();
 sky130_fd_sc_hd__fill_2 FILLER_3_166 ();
 sky130_ef_sc_hd__decap_12 FILLER_3_169 ();
 sky130_ef_sc_hd__decap_12 FILLER_3_181 ();
 sky130_fd_sc_hd__decap_4 FILLER_3_193 ();
 sky130_ef_sc_hd__decap_12 FILLER_4_3 ();
 sky130_ef_sc_hd__decap_12 FILLER_4_15 ();
 sky130_fd_sc_hd__fill_1 FILLER_4_27 ();
 sky130_fd_sc_hd__decap_4 FILLER_4_29 ();
 sky130_fd_sc_hd__decap_8 FILLER_4_62 ();
 sky130_fd_sc_hd__fill_1 FILLER_4_70 ();
 sky130_fd_sc_hd__decap_4 FILLER_4_80 ();
 sky130_ef_sc_hd__decap_12 FILLER_4_85 ();
 sky130_fd_sc_hd__decap_8 FILLER_4_97 ();
 sky130_fd_sc_hd__fill_1 FILLER_4_105 ();
 sky130_ef_sc_hd__decap_12 FILLER_4_141 ();
 sky130_fd_sc_hd__decap_6 FILLER_4_153 ();
 sky130_fd_sc_hd__fill_2 FILLER_4_182 ();
 sky130_ef_sc_hd__decap_12 FILLER_5_3 ();
 sky130_ef_sc_hd__decap_12 FILLER_5_15 ();
 sky130_ef_sc_hd__decap_12 FILLER_5_27 ();
 sky130_fd_sc_hd__fill_1 FILLER_5_39 ();
 sky130_fd_sc_hd__decap_6 FILLER_5_49 ();
 sky130_fd_sc_hd__fill_1 FILLER_5_55 ();
 sky130_ef_sc_hd__decap_12 FILLER_5_57 ();
 sky130_ef_sc_hd__decap_12 FILLER_5_69 ();
 sky130_ef_sc_hd__decap_12 FILLER_5_81 ();
 sky130_ef_sc_hd__decap_12 FILLER_5_93 ();
 sky130_fd_sc_hd__decap_6 FILLER_5_105 ();
 sky130_fd_sc_hd__fill_1 FILLER_5_111 ();
 sky130_fd_sc_hd__fill_2 FILLER_5_113 ();
 sky130_ef_sc_hd__decap_12 FILLER_5_129 ();
 sky130_fd_sc_hd__decap_8 FILLER_5_141 ();
 sky130_fd_sc_hd__fill_1 FILLER_5_149 ();
 sky130_fd_sc_hd__decap_3 FILLER_5_165 ();
 sky130_ef_sc_hd__decap_12 FILLER_5_177 ();
 sky130_fd_sc_hd__decap_8 FILLER_5_189 ();
 sky130_ef_sc_hd__decap_12 FILLER_6_3 ();
 sky130_ef_sc_hd__decap_12 FILLER_6_15 ();
 sky130_fd_sc_hd__fill_1 FILLER_6_27 ();
 sky130_ef_sc_hd__decap_12 FILLER_6_29 ();
 sky130_ef_sc_hd__decap_12 FILLER_6_41 ();
 sky130_ef_sc_hd__decap_12 FILLER_6_53 ();
 sky130_ef_sc_hd__decap_12 FILLER_6_65 ();
 sky130_fd_sc_hd__decap_6 FILLER_6_77 ();
 sky130_fd_sc_hd__fill_1 FILLER_6_83 ();
 sky130_ef_sc_hd__decap_12 FILLER_6_85 ();
 sky130_fd_sc_hd__decap_3 FILLER_6_97 ();
 sky130_fd_sc_hd__decap_3 FILLER_6_114 ();
 sky130_ef_sc_hd__decap_12 FILLER_6_120 ();
 sky130_fd_sc_hd__decap_8 FILLER_6_132 ();
 sky130_ef_sc_hd__decap_12 FILLER_6_141 ();
 sky130_ef_sc_hd__decap_12 FILLER_6_153 ();
 sky130_ef_sc_hd__decap_12 FILLER_6_177 ();
 sky130_fd_sc_hd__decap_6 FILLER_6_189 ();
 sky130_fd_sc_hd__fill_1 FILLER_6_195 ();
 sky130_ef_sc_hd__decap_12 FILLER_7_3 ();
 sky130_ef_sc_hd__decap_12 FILLER_7_15 ();
 sky130_ef_sc_hd__decap_12 FILLER_7_27 ();
 sky130_ef_sc_hd__decap_12 FILLER_7_39 ();
 sky130_fd_sc_hd__decap_4 FILLER_7_51 ();
 sky130_fd_sc_hd__fill_1 FILLER_7_55 ();
 sky130_ef_sc_hd__decap_12 FILLER_7_57 ();
 sky130_ef_sc_hd__decap_12 FILLER_7_69 ();
 sky130_ef_sc_hd__decap_12 FILLER_7_81 ();
 sky130_fd_sc_hd__fill_1 FILLER_7_93 ();
 sky130_ef_sc_hd__decap_12 FILLER_7_113 ();
 sky130_ef_sc_hd__decap_12 FILLER_7_125 ();
 sky130_ef_sc_hd__decap_12 FILLER_7_137 ();
 sky130_ef_sc_hd__decap_12 FILLER_7_149 ();
 sky130_fd_sc_hd__decap_6 FILLER_7_161 ();
 sky130_fd_sc_hd__fill_1 FILLER_7_167 ();
 sky130_ef_sc_hd__decap_12 FILLER_7_169 ();
 sky130_ef_sc_hd__decap_12 FILLER_7_181 ();
 sky130_fd_sc_hd__decap_4 FILLER_7_193 ();
 sky130_ef_sc_hd__decap_12 FILLER_8_3 ();
 sky130_ef_sc_hd__decap_12 FILLER_8_15 ();
 sky130_fd_sc_hd__fill_1 FILLER_8_27 ();
 sky130_ef_sc_hd__decap_12 FILLER_8_29 ();
 sky130_ef_sc_hd__decap_12 FILLER_8_41 ();
 sky130_ef_sc_hd__decap_12 FILLER_8_53 ();
 sky130_ef_sc_hd__decap_12 FILLER_8_65 ();
 sky130_fd_sc_hd__decap_6 FILLER_8_77 ();
 sky130_fd_sc_hd__fill_1 FILLER_8_83 ();
 sky130_ef_sc_hd__decap_12 FILLER_8_85 ();
 sky130_ef_sc_hd__decap_12 FILLER_8_106 ();
 sky130_ef_sc_hd__decap_12 FILLER_8_118 ();
 sky130_fd_sc_hd__decap_8 FILLER_8_130 ();
 sky130_fd_sc_hd__fill_2 FILLER_8_138 ();
 sky130_ef_sc_hd__decap_12 FILLER_8_141 ();
 sky130_ef_sc_hd__decap_12 FILLER_8_153 ();
 sky130_ef_sc_hd__decap_12 FILLER_8_165 ();
 sky130_ef_sc_hd__decap_12 FILLER_8_177 ();
 sky130_fd_sc_hd__decap_6 FILLER_8_189 ();
 sky130_fd_sc_hd__fill_1 FILLER_8_195 ();
 sky130_ef_sc_hd__decap_12 FILLER_9_3 ();
 sky130_ef_sc_hd__decap_12 FILLER_9_15 ();
 sky130_ef_sc_hd__decap_12 FILLER_9_27 ();
 sky130_ef_sc_hd__decap_12 FILLER_9_39 ();
 sky130_fd_sc_hd__decap_4 FILLER_9_51 ();
 sky130_fd_sc_hd__fill_1 FILLER_9_55 ();
 sky130_ef_sc_hd__decap_12 FILLER_9_57 ();
 sky130_ef_sc_hd__decap_12 FILLER_9_69 ();
 sky130_ef_sc_hd__decap_12 FILLER_9_81 ();
 sky130_fd_sc_hd__decap_8 FILLER_9_93 ();
 sky130_fd_sc_hd__fill_2 FILLER_9_101 ();
 sky130_fd_sc_hd__fill_1 FILLER_9_111 ();
 sky130_ef_sc_hd__decap_12 FILLER_9_113 ();
 sky130_ef_sc_hd__decap_12 FILLER_9_125 ();
 sky130_ef_sc_hd__decap_12 FILLER_9_137 ();
 sky130_ef_sc_hd__decap_12 FILLER_9_149 ();
 sky130_fd_sc_hd__decap_6 FILLER_9_161 ();
 sky130_fd_sc_hd__fill_1 FILLER_9_167 ();
 sky130_ef_sc_hd__decap_12 FILLER_9_169 ();
 sky130_ef_sc_hd__decap_12 FILLER_9_181 ();
 sky130_fd_sc_hd__decap_4 FILLER_9_193 ();
 sky130_ef_sc_hd__decap_12 FILLER_10_3 ();
 sky130_ef_sc_hd__decap_12 FILLER_10_15 ();
 sky130_fd_sc_hd__fill_1 FILLER_10_27 ();
 sky130_ef_sc_hd__decap_12 FILLER_10_29 ();
 sky130_ef_sc_hd__decap_12 FILLER_10_41 ();
 sky130_fd_sc_hd__fill_2 FILLER_10_53 ();
 sky130_fd_sc_hd__decap_8 FILLER_10_75 ();
 sky130_fd_sc_hd__fill_1 FILLER_10_83 ();
 sky130_ef_sc_hd__decap_12 FILLER_10_92 ();
 sky130_fd_sc_hd__decap_4 FILLER_10_104 ();
 sky130_ef_sc_hd__decap_12 FILLER_10_111 ();
 sky130_ef_sc_hd__decap_12 FILLER_10_123 ();
 sky130_fd_sc_hd__decap_4 FILLER_10_135 ();
 sky130_fd_sc_hd__fill_1 FILLER_10_139 ();
 sky130_ef_sc_hd__decap_12 FILLER_10_141 ();
 sky130_ef_sc_hd__decap_12 FILLER_10_153 ();
 sky130_fd_sc_hd__decap_4 FILLER_10_165 ();
 sky130_fd_sc_hd__fill_1 FILLER_10_169 ();
 sky130_ef_sc_hd__decap_12 FILLER_10_173 ();
 sky130_fd_sc_hd__decap_8 FILLER_10_185 ();
 sky130_ef_sc_hd__decap_12 FILLER_11_3 ();
 sky130_ef_sc_hd__decap_12 FILLER_11_35 ();
 sky130_fd_sc_hd__decap_8 FILLER_11_47 ();
 sky130_fd_sc_hd__fill_1 FILLER_11_55 ();
 sky130_ef_sc_hd__decap_12 FILLER_11_86 ();
 sky130_fd_sc_hd__decap_6 FILLER_11_98 ();
 sky130_fd_sc_hd__fill_1 FILLER_11_104 ();
 sky130_fd_sc_hd__fill_2 FILLER_11_125 ();
 sky130_ef_sc_hd__decap_12 FILLER_11_138 ();
 sky130_fd_sc_hd__decap_8 FILLER_11_150 ();
 sky130_fd_sc_hd__fill_2 FILLER_11_158 ();
 sky130_fd_sc_hd__decap_4 FILLER_11_190 ();
 sky130_ef_sc_hd__decap_12 FILLER_12_6 ();
 sky130_fd_sc_hd__fill_1 FILLER_12_18 ();
 sky130_ef_sc_hd__decap_12 FILLER_12_38 ();
 sky130_ef_sc_hd__decap_12 FILLER_12_50 ();
 sky130_fd_sc_hd__fill_1 FILLER_12_62 ();
 sky130_ef_sc_hd__decap_12 FILLER_12_72 ();
 sky130_ef_sc_hd__decap_12 FILLER_12_85 ();
 sky130_ef_sc_hd__decap_12 FILLER_12_97 ();
 sky130_fd_sc_hd__decap_4 FILLER_12_109 ();
 sky130_fd_sc_hd__fill_1 FILLER_12_113 ();
 sky130_fd_sc_hd__fill_1 FILLER_12_128 ();
 sky130_fd_sc_hd__decap_3 FILLER_12_137 ();
 sky130_ef_sc_hd__decap_12 FILLER_12_141 ();
 sky130_ef_sc_hd__decap_12 FILLER_12_153 ();
 sky130_ef_sc_hd__decap_12 FILLER_12_174 ();
 sky130_fd_sc_hd__decap_6 FILLER_12_186 ();
 sky130_fd_sc_hd__fill_1 FILLER_12_192 ();
 sky130_ef_sc_hd__decap_12 FILLER_13_3 ();
 sky130_ef_sc_hd__decap_12 FILLER_13_35 ();
 sky130_fd_sc_hd__decap_8 FILLER_13_47 ();
 sky130_fd_sc_hd__fill_1 FILLER_13_55 ();
 sky130_ef_sc_hd__decap_12 FILLER_13_57 ();
 sky130_ef_sc_hd__decap_12 FILLER_13_69 ();
 sky130_ef_sc_hd__decap_12 FILLER_13_81 ();
 sky130_ef_sc_hd__decap_12 FILLER_13_93 ();
 sky130_fd_sc_hd__decap_6 FILLER_13_105 ();
 sky130_fd_sc_hd__fill_1 FILLER_13_111 ();
 sky130_ef_sc_hd__decap_12 FILLER_13_113 ();
 sky130_ef_sc_hd__decap_12 FILLER_13_125 ();
 sky130_fd_sc_hd__decap_8 FILLER_13_137 ();
 sky130_fd_sc_hd__fill_1 FILLER_13_145 ();
 sky130_fd_sc_hd__decap_4 FILLER_13_149 ();
 sky130_fd_sc_hd__decap_6 FILLER_13_190 ();
 sky130_fd_sc_hd__fill_1 FILLER_13_196 ();
 sky130_ef_sc_hd__decap_12 FILLER_14_3 ();
 sky130_ef_sc_hd__decap_12 FILLER_14_15 ();
 sky130_fd_sc_hd__fill_1 FILLER_14_27 ();
 sky130_ef_sc_hd__decap_12 FILLER_14_29 ();
 sky130_ef_sc_hd__decap_12 FILLER_14_41 ();
 sky130_ef_sc_hd__decap_12 FILLER_14_53 ();
 sky130_ef_sc_hd__decap_12 FILLER_14_65 ();
 sky130_fd_sc_hd__decap_6 FILLER_14_77 ();
 sky130_fd_sc_hd__fill_1 FILLER_14_83 ();
 sky130_ef_sc_hd__decap_12 FILLER_14_85 ();
 sky130_fd_sc_hd__decap_8 FILLER_14_97 ();
 sky130_ef_sc_hd__decap_12 FILLER_14_112 ();
 sky130_ef_sc_hd__decap_12 FILLER_14_124 ();
 sky130_fd_sc_hd__decap_4 FILLER_14_136 ();
 sky130_ef_sc_hd__decap_12 FILLER_14_141 ();
 sky130_ef_sc_hd__decap_12 FILLER_14_153 ();
 sky130_ef_sc_hd__decap_12 FILLER_14_165 ();
 sky130_ef_sc_hd__decap_12 FILLER_14_177 ();
 sky130_fd_sc_hd__decap_4 FILLER_14_189 ();
 sky130_fd_sc_hd__decap_8 FILLER_15_3 ();
 sky130_fd_sc_hd__decap_3 FILLER_15_11 ();
 sky130_ef_sc_hd__decap_12 FILLER_15_34 ();
 sky130_fd_sc_hd__decap_8 FILLER_15_46 ();
 sky130_fd_sc_hd__fill_2 FILLER_15_54 ();
 sky130_fd_sc_hd__decap_6 FILLER_15_57 ();
 sky130_fd_sc_hd__fill_1 FILLER_15_63 ();
 sky130_fd_sc_hd__decap_8 FILLER_15_84 ();
 sky130_fd_sc_hd__fill_1 FILLER_15_120 ();
 sky130_ef_sc_hd__decap_12 FILLER_15_128 ();
 sky130_ef_sc_hd__decap_12 FILLER_15_140 ();
 sky130_ef_sc_hd__decap_12 FILLER_15_152 ();
 sky130_fd_sc_hd__decap_4 FILLER_15_164 ();
 sky130_ef_sc_hd__decap_12 FILLER_15_169 ();
 sky130_ef_sc_hd__decap_12 FILLER_15_181 ();
 sky130_fd_sc_hd__decap_4 FILLER_15_193 ();
 sky130_ef_sc_hd__decap_12 FILLER_16_3 ();
 sky130_ef_sc_hd__decap_12 FILLER_16_15 ();
 sky130_fd_sc_hd__fill_1 FILLER_16_27 ();
 sky130_ef_sc_hd__decap_12 FILLER_16_38 ();
 sky130_ef_sc_hd__decap_12 FILLER_16_50 ();
 sky130_ef_sc_hd__decap_12 FILLER_16_62 ();
 sky130_fd_sc_hd__decap_8 FILLER_16_74 ();
 sky130_fd_sc_hd__fill_2 FILLER_16_82 ();
 sky130_ef_sc_hd__decap_12 FILLER_16_85 ();
 sky130_fd_sc_hd__decap_4 FILLER_16_97 ();
 sky130_fd_sc_hd__fill_1 FILLER_16_101 ();
 sky130_fd_sc_hd__decap_4 FILLER_16_108 ();
 sky130_fd_sc_hd__fill_1 FILLER_16_112 ();
 sky130_fd_sc_hd__fill_1 FILLER_16_119 ();
 sky130_ef_sc_hd__decap_12 FILLER_16_141 ();
 sky130_ef_sc_hd__decap_12 FILLER_16_153 ();
 sky130_ef_sc_hd__decap_12 FILLER_16_165 ();
 sky130_ef_sc_hd__decap_12 FILLER_16_177 ();
 sky130_fd_sc_hd__decap_6 FILLER_16_189 ();
 sky130_fd_sc_hd__fill_1 FILLER_16_195 ();
 sky130_fd_sc_hd__decap_8 FILLER_17_6 ();
 sky130_fd_sc_hd__fill_1 FILLER_17_14 ();
 sky130_ef_sc_hd__decap_12 FILLER_17_35 ();
 sky130_fd_sc_hd__decap_8 FILLER_17_47 ();
 sky130_fd_sc_hd__fill_1 FILLER_17_55 ();
 sky130_ef_sc_hd__decap_12 FILLER_17_77 ();
 sky130_ef_sc_hd__decap_12 FILLER_17_89 ();
 sky130_fd_sc_hd__decap_4 FILLER_17_101 ();
 sky130_ef_sc_hd__decap_12 FILLER_17_120 ();
 sky130_ef_sc_hd__decap_12 FILLER_17_132 ();
 sky130_ef_sc_hd__decap_12 FILLER_17_144 ();
 sky130_ef_sc_hd__decap_12 FILLER_17_156 ();
 sky130_ef_sc_hd__decap_12 FILLER_17_169 ();
 sky130_ef_sc_hd__decap_12 FILLER_17_181 ();
 sky130_fd_sc_hd__decap_4 FILLER_17_193 ();
 sky130_ef_sc_hd__decap_12 FILLER_18_3 ();
 sky130_ef_sc_hd__decap_12 FILLER_18_15 ();
 sky130_fd_sc_hd__fill_1 FILLER_18_27 ();
 sky130_ef_sc_hd__decap_12 FILLER_18_38 ();
 sky130_fd_sc_hd__decap_4 FILLER_18_50 ();
 sky130_fd_sc_hd__fill_1 FILLER_18_54 ();
 sky130_ef_sc_hd__decap_12 FILLER_18_85 ();
 sky130_ef_sc_hd__decap_12 FILLER_18_97 ();
 sky130_fd_sc_hd__decap_4 FILLER_18_109 ();
 sky130_fd_sc_hd__fill_1 FILLER_18_113 ();
 sky130_ef_sc_hd__decap_12 FILLER_18_117 ();
 sky130_fd_sc_hd__decap_8 FILLER_18_129 ();
 sky130_fd_sc_hd__decap_3 FILLER_18_137 ();
 sky130_ef_sc_hd__decap_12 FILLER_18_141 ();
 sky130_ef_sc_hd__decap_12 FILLER_18_153 ();
 sky130_ef_sc_hd__decap_12 FILLER_18_165 ();
 sky130_ef_sc_hd__decap_12 FILLER_18_177 ();
 sky130_fd_sc_hd__decap_6 FILLER_18_189 ();
 sky130_fd_sc_hd__fill_1 FILLER_18_195 ();
 sky130_ef_sc_hd__decap_12 FILLER_19_6 ();
 sky130_ef_sc_hd__decap_12 FILLER_19_18 ();
 sky130_ef_sc_hd__decap_12 FILLER_19_30 ();
 sky130_ef_sc_hd__decap_12 FILLER_19_42 ();
 sky130_fd_sc_hd__fill_2 FILLER_19_54 ();
 sky130_fd_sc_hd__decap_4 FILLER_19_57 ();
 sky130_ef_sc_hd__decap_12 FILLER_19_70 ();
 sky130_ef_sc_hd__decap_12 FILLER_19_82 ();
 sky130_ef_sc_hd__decap_12 FILLER_19_94 ();
 sky130_fd_sc_hd__fill_1 FILLER_19_106 ();
 sky130_fd_sc_hd__fill_1 FILLER_19_113 ();
 sky130_ef_sc_hd__decap_12 FILLER_19_133 ();
 sky130_ef_sc_hd__decap_12 FILLER_19_145 ();
 sky130_fd_sc_hd__decap_8 FILLER_19_157 ();
 sky130_fd_sc_hd__decap_3 FILLER_19_165 ();
 sky130_ef_sc_hd__decap_12 FILLER_19_175 ();
 sky130_fd_sc_hd__decap_6 FILLER_19_187 ();
 sky130_fd_sc_hd__fill_1 FILLER_19_193 ();
 sky130_ef_sc_hd__decap_12 FILLER_20_6 ();
 sky130_fd_sc_hd__decap_8 FILLER_20_18 ();
 sky130_fd_sc_hd__fill_2 FILLER_20_26 ();
 sky130_ef_sc_hd__decap_12 FILLER_20_29 ();
 sky130_ef_sc_hd__decap_12 FILLER_20_41 ();
 sky130_ef_sc_hd__decap_12 FILLER_20_53 ();
 sky130_ef_sc_hd__decap_12 FILLER_20_65 ();
 sky130_fd_sc_hd__fill_1 FILLER_20_77 ();
 sky130_fd_sc_hd__fill_1 FILLER_20_85 ();
 sky130_ef_sc_hd__decap_12 FILLER_20_99 ();
 sky130_fd_sc_hd__fill_1 FILLER_20_111 ();
 sky130_fd_sc_hd__decap_8 FILLER_20_129 ();
 sky130_fd_sc_hd__decap_3 FILLER_20_137 ();
 sky130_ef_sc_hd__decap_12 FILLER_20_141 ();
 sky130_fd_sc_hd__decap_6 FILLER_20_153 ();
 sky130_fd_sc_hd__fill_1 FILLER_20_159 ();
 sky130_fd_sc_hd__fill_2 FILLER_20_191 ();
 sky130_fd_sc_hd__decap_8 FILLER_21_6 ();
 sky130_fd_sc_hd__fill_1 FILLER_21_14 ();
 sky130_ef_sc_hd__decap_12 FILLER_21_20 ();
 sky130_ef_sc_hd__decap_12 FILLER_21_32 ();
 sky130_ef_sc_hd__decap_12 FILLER_21_44 ();
 sky130_ef_sc_hd__decap_12 FILLER_21_57 ();
 sky130_ef_sc_hd__decap_12 FILLER_21_69 ();
 sky130_ef_sc_hd__decap_12 FILLER_21_81 ();
 sky130_ef_sc_hd__decap_12 FILLER_21_93 ();
 sky130_fd_sc_hd__fill_2 FILLER_21_105 ();
 sky130_fd_sc_hd__decap_4 FILLER_21_125 ();
 sky130_fd_sc_hd__fill_1 FILLER_21_129 ();
 sky130_ef_sc_hd__decap_12 FILLER_21_137 ();
 sky130_fd_sc_hd__decap_8 FILLER_21_149 ();
 sky130_fd_sc_hd__decap_3 FILLER_21_157 ();
 sky130_fd_sc_hd__decap_4 FILLER_21_190 ();
 sky130_fd_sc_hd__decap_8 FILLER_22_6 ();
 sky130_fd_sc_hd__decap_6 FILLER_22_21 ();
 sky130_fd_sc_hd__fill_1 FILLER_22_27 ();
 sky130_ef_sc_hd__decap_12 FILLER_22_29 ();
 sky130_ef_sc_hd__decap_12 FILLER_22_41 ();
 sky130_ef_sc_hd__decap_12 FILLER_22_53 ();
 sky130_ef_sc_hd__decap_12 FILLER_22_65 ();
 sky130_fd_sc_hd__decap_6 FILLER_22_77 ();
 sky130_fd_sc_hd__fill_1 FILLER_22_83 ();
 sky130_ef_sc_hd__decap_12 FILLER_22_85 ();
 sky130_ef_sc_hd__decap_12 FILLER_22_97 ();
 sky130_ef_sc_hd__decap_12 FILLER_22_109 ();
 sky130_fd_sc_hd__decap_8 FILLER_22_121 ();
 sky130_fd_sc_hd__decap_8 FILLER_22_132 ();
 sky130_fd_sc_hd__decap_8 FILLER_22_183 ();
 sky130_fd_sc_hd__fill_2 FILLER_22_191 ();
 sky130_ef_sc_hd__decap_12 FILLER_23_3 ();
 sky130_ef_sc_hd__decap_12 FILLER_23_36 ();
 sky130_fd_sc_hd__decap_8 FILLER_23_48 ();
 sky130_fd_sc_hd__fill_1 FILLER_23_57 ();
 sky130_ef_sc_hd__decap_12 FILLER_23_67 ();
 sky130_ef_sc_hd__decap_12 FILLER_23_79 ();
 sky130_ef_sc_hd__decap_12 FILLER_23_91 ();
 sky130_fd_sc_hd__decap_8 FILLER_23_103 ();
 sky130_fd_sc_hd__fill_1 FILLER_23_111 ();
 sky130_ef_sc_hd__decap_12 FILLER_23_121 ();
 sky130_ef_sc_hd__decap_12 FILLER_23_133 ();
 sky130_ef_sc_hd__decap_12 FILLER_23_145 ();
 sky130_fd_sc_hd__decap_8 FILLER_23_157 ();
 sky130_fd_sc_hd__decap_3 FILLER_23_165 ();
 sky130_ef_sc_hd__decap_12 FILLER_23_169 ();
 sky130_ef_sc_hd__decap_12 FILLER_23_181 ();
 sky130_fd_sc_hd__decap_4 FILLER_23_193 ();
 sky130_ef_sc_hd__decap_12 FILLER_24_6 ();
 sky130_fd_sc_hd__decap_8 FILLER_24_18 ();
 sky130_fd_sc_hd__fill_2 FILLER_24_26 ();
 sky130_ef_sc_hd__decap_12 FILLER_24_29 ();
 sky130_fd_sc_hd__decap_8 FILLER_24_41 ();
 sky130_fd_sc_hd__decap_3 FILLER_24_49 ();
 sky130_ef_sc_hd__decap_12 FILLER_24_72 ();
 sky130_ef_sc_hd__decap_12 FILLER_24_85 ();
 sky130_ef_sc_hd__decap_12 FILLER_24_97 ();
 sky130_ef_sc_hd__decap_12 FILLER_24_109 ();
 sky130_ef_sc_hd__decap_12 FILLER_24_121 ();
 sky130_fd_sc_hd__decap_6 FILLER_24_133 ();
 sky130_fd_sc_hd__fill_1 FILLER_24_139 ();
 sky130_ef_sc_hd__decap_12 FILLER_24_141 ();
 sky130_fd_sc_hd__decap_4 FILLER_24_153 ();
 sky130_ef_sc_hd__decap_12 FILLER_24_165 ();
 sky130_ef_sc_hd__decap_12 FILLER_24_177 ();
 sky130_fd_sc_hd__decap_4 FILLER_24_189 ();
 sky130_ef_sc_hd__decap_12 FILLER_25_6 ();
 sky130_fd_sc_hd__fill_2 FILLER_25_18 ();
 sky130_ef_sc_hd__decap_12 FILLER_25_29 ();
 sky130_ef_sc_hd__decap_12 FILLER_25_41 ();
 sky130_fd_sc_hd__decap_3 FILLER_25_53 ();
 sky130_ef_sc_hd__decap_12 FILLER_25_77 ();
 sky130_ef_sc_hd__decap_12 FILLER_25_89 ();
 sky130_fd_sc_hd__decap_6 FILLER_25_101 ();
 sky130_ef_sc_hd__decap_12 FILLER_25_124 ();
 sky130_ef_sc_hd__decap_12 FILLER_25_136 ();
 sky130_ef_sc_hd__decap_12 FILLER_25_148 ();
 sky130_fd_sc_hd__decap_8 FILLER_25_160 ();
 sky130_ef_sc_hd__decap_12 FILLER_25_169 ();
 sky130_ef_sc_hd__decap_12 FILLER_25_181 ();
 sky130_fd_sc_hd__decap_4 FILLER_25_193 ();
 sky130_ef_sc_hd__decap_12 FILLER_26_6 ();
 sky130_fd_sc_hd__decap_3 FILLER_26_25 ();
 sky130_ef_sc_hd__decap_12 FILLER_26_29 ();
 sky130_ef_sc_hd__decap_12 FILLER_26_41 ();
 sky130_fd_sc_hd__decap_4 FILLER_26_53 ();
 sky130_ef_sc_hd__decap_12 FILLER_26_66 ();
 sky130_fd_sc_hd__decap_6 FILLER_26_78 ();
 sky130_ef_sc_hd__decap_12 FILLER_26_85 ();
 sky130_fd_sc_hd__decap_4 FILLER_26_97 ();
 sky130_fd_sc_hd__fill_1 FILLER_26_101 ();
 sky130_ef_sc_hd__decap_12 FILLER_26_111 ();
 sky130_ef_sc_hd__decap_12 FILLER_26_123 ();
 sky130_fd_sc_hd__decap_4 FILLER_26_135 ();
 sky130_fd_sc_hd__fill_1 FILLER_26_139 ();
 sky130_ef_sc_hd__decap_12 FILLER_26_141 ();
 sky130_fd_sc_hd__fill_1 FILLER_26_153 ();
 sky130_ef_sc_hd__decap_12 FILLER_26_177 ();
 sky130_fd_sc_hd__decap_6 FILLER_26_189 ();
 sky130_fd_sc_hd__fill_1 FILLER_26_195 ();
 sky130_ef_sc_hd__decap_12 FILLER_27_31 ();
 sky130_ef_sc_hd__decap_12 FILLER_27_43 ();
 sky130_fd_sc_hd__fill_1 FILLER_27_55 ();
 sky130_ef_sc_hd__decap_12 FILLER_27_57 ();
 sky130_fd_sc_hd__fill_1 FILLER_27_69 ();
 sky130_ef_sc_hd__decap_12 FILLER_27_90 ();
 sky130_fd_sc_hd__decap_8 FILLER_27_102 ();
 sky130_fd_sc_hd__fill_2 FILLER_27_110 ();
 sky130_fd_sc_hd__decap_8 FILLER_27_113 ();
 sky130_fd_sc_hd__fill_2 FILLER_27_121 ();
 sky130_ef_sc_hd__decap_12 FILLER_27_131 ();
 sky130_ef_sc_hd__decap_12 FILLER_27_143 ();
 sky130_fd_sc_hd__fill_2 FILLER_27_155 ();
 sky130_fd_sc_hd__decap_4 FILLER_27_164 ();
 sky130_ef_sc_hd__decap_12 FILLER_27_169 ();
 sky130_ef_sc_hd__decap_12 FILLER_27_181 ();
 sky130_fd_sc_hd__decap_4 FILLER_27_193 ();
 sky130_fd_sc_hd__decap_8 FILLER_28_3 ();
 sky130_fd_sc_hd__decap_3 FILLER_28_11 ();
 sky130_fd_sc_hd__fill_1 FILLER_28_27 ();
 sky130_ef_sc_hd__decap_12 FILLER_28_29 ();
 sky130_ef_sc_hd__decap_12 FILLER_28_41 ();
 sky130_fd_sc_hd__decap_8 FILLER_28_53 ();
 sky130_fd_sc_hd__decap_3 FILLER_28_61 ();
 sky130_ef_sc_hd__decap_12 FILLER_28_94 ();
 sky130_fd_sc_hd__decap_8 FILLER_28_106 ();
 sky130_fd_sc_hd__decap_8 FILLER_28_132 ();
 sky130_ef_sc_hd__decap_12 FILLER_28_141 ();
 sky130_ef_sc_hd__decap_12 FILLER_28_153 ();
 sky130_ef_sc_hd__decap_12 FILLER_28_165 ();
 sky130_ef_sc_hd__decap_12 FILLER_28_177 ();
 sky130_fd_sc_hd__decap_6 FILLER_28_189 ();
 sky130_fd_sc_hd__fill_1 FILLER_28_195 ();
 sky130_ef_sc_hd__decap_12 FILLER_29_6 ();
 sky130_ef_sc_hd__decap_12 FILLER_29_18 ();
 sky130_ef_sc_hd__decap_12 FILLER_29_30 ();
 sky130_ef_sc_hd__decap_12 FILLER_29_42 ();
 sky130_fd_sc_hd__fill_2 FILLER_29_54 ();
 sky130_ef_sc_hd__decap_12 FILLER_29_57 ();
 sky130_fd_sc_hd__decap_4 FILLER_29_69 ();
 sky130_fd_sc_hd__fill_1 FILLER_29_73 ();
 sky130_ef_sc_hd__decap_12 FILLER_29_83 ();
 sky130_ef_sc_hd__decap_12 FILLER_29_95 ();
 sky130_fd_sc_hd__decap_4 FILLER_29_107 ();
 sky130_fd_sc_hd__fill_1 FILLER_29_111 ();
 sky130_ef_sc_hd__decap_12 FILLER_29_127 ();
 sky130_ef_sc_hd__decap_12 FILLER_29_139 ();
 sky130_ef_sc_hd__decap_12 FILLER_29_151 ();
 sky130_fd_sc_hd__decap_4 FILLER_29_163 ();
 sky130_fd_sc_hd__fill_1 FILLER_29_167 ();
 sky130_ef_sc_hd__decap_12 FILLER_29_169 ();
 sky130_ef_sc_hd__decap_12 FILLER_29_181 ();
 sky130_fd_sc_hd__decap_4 FILLER_29_193 ();
 sky130_ef_sc_hd__decap_12 FILLER_30_6 ();
 sky130_fd_sc_hd__decap_8 FILLER_30_18 ();
 sky130_fd_sc_hd__fill_2 FILLER_30_26 ();
 sky130_ef_sc_hd__decap_12 FILLER_30_29 ();
 sky130_ef_sc_hd__decap_12 FILLER_30_41 ();
 sky130_ef_sc_hd__decap_12 FILLER_30_53 ();
 sky130_ef_sc_hd__decap_12 FILLER_30_65 ();
 sky130_fd_sc_hd__decap_6 FILLER_30_77 ();
 sky130_fd_sc_hd__fill_1 FILLER_30_83 ();
 sky130_ef_sc_hd__decap_12 FILLER_30_85 ();
 sky130_ef_sc_hd__decap_12 FILLER_30_97 ();
 sky130_fd_sc_hd__fill_1 FILLER_30_109 ();
 sky130_fd_sc_hd__decap_3 FILLER_30_120 ();
 sky130_fd_sc_hd__decap_3 FILLER_30_137 ();
 sky130_ef_sc_hd__decap_12 FILLER_30_141 ();
 sky130_ef_sc_hd__decap_12 FILLER_30_153 ();
 sky130_ef_sc_hd__decap_12 FILLER_30_165 ();
 sky130_ef_sc_hd__decap_12 FILLER_30_177 ();
 sky130_fd_sc_hd__decap_6 FILLER_30_189 ();
 sky130_fd_sc_hd__fill_1 FILLER_30_195 ();
 sky130_ef_sc_hd__decap_12 FILLER_31_6 ();
 sky130_ef_sc_hd__decap_12 FILLER_31_18 ();
 sky130_ef_sc_hd__decap_12 FILLER_31_30 ();
 sky130_ef_sc_hd__decap_12 FILLER_31_42 ();
 sky130_fd_sc_hd__fill_2 FILLER_31_54 ();
 sky130_ef_sc_hd__decap_12 FILLER_31_57 ();
 sky130_ef_sc_hd__decap_12 FILLER_31_69 ();
 sky130_ef_sc_hd__decap_12 FILLER_31_81 ();
 sky130_ef_sc_hd__decap_12 FILLER_31_93 ();
 sky130_fd_sc_hd__decap_6 FILLER_31_105 ();
 sky130_fd_sc_hd__fill_1 FILLER_31_111 ();
 sky130_ef_sc_hd__decap_12 FILLER_31_113 ();
 sky130_ef_sc_hd__decap_12 FILLER_31_125 ();
 sky130_ef_sc_hd__decap_12 FILLER_31_137 ();
 sky130_ef_sc_hd__decap_12 FILLER_31_149 ();
 sky130_fd_sc_hd__decap_6 FILLER_31_161 ();
 sky130_fd_sc_hd__fill_1 FILLER_31_167 ();
 sky130_ef_sc_hd__decap_12 FILLER_31_169 ();
 sky130_ef_sc_hd__decap_12 FILLER_31_181 ();
 sky130_fd_sc_hd__decap_4 FILLER_31_193 ();
 sky130_ef_sc_hd__decap_12 FILLER_32_3 ();
 sky130_ef_sc_hd__decap_12 FILLER_32_15 ();
 sky130_fd_sc_hd__fill_1 FILLER_32_27 ();
 sky130_ef_sc_hd__decap_12 FILLER_32_29 ();
 sky130_ef_sc_hd__decap_12 FILLER_32_41 ();
 sky130_fd_sc_hd__decap_3 FILLER_32_53 ();
 sky130_ef_sc_hd__decap_12 FILLER_32_57 ();
 sky130_fd_sc_hd__decap_4 FILLER_32_69 ();
 sky130_fd_sc_hd__decap_8 FILLER_32_76 ();
 sky130_fd_sc_hd__fill_2 FILLER_32_85 ();
 sky130_fd_sc_hd__decap_4 FILLER_32_90 ();
 sky130_fd_sc_hd__decap_4 FILLER_32_97 ();
 sky130_fd_sc_hd__decap_4 FILLER_32_104 ();
 sky130_fd_sc_hd__fill_1 FILLER_32_111 ();
 sky130_fd_sc_hd__fill_2 FILLER_32_113 ();
 sky130_fd_sc_hd__decap_4 FILLER_32_118 ();
 sky130_fd_sc_hd__decap_4 FILLER_32_125 ();
 sky130_fd_sc_hd__decap_4 FILLER_32_132 ();
 sky130_fd_sc_hd__fill_1 FILLER_32_139 ();
 sky130_fd_sc_hd__fill_2 FILLER_32_141 ();
 sky130_fd_sc_hd__decap_4 FILLER_32_146 ();
 sky130_fd_sc_hd__decap_8 FILLER_32_153 ();
 sky130_fd_sc_hd__decap_3 FILLER_32_161 ();
 sky130_fd_sc_hd__fill_1 FILLER_32_167 ();
 sky130_ef_sc_hd__decap_12 FILLER_32_169 ();
 sky130_ef_sc_hd__decap_12 FILLER_32_181 ();
 sky130_fd_sc_hd__decap_3 FILLER_32_193 ();
endmodule
