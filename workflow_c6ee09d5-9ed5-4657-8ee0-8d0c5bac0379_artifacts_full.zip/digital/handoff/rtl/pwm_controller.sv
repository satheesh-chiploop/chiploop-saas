module pwm_controller (
    input  wire       clk,
    input  wire       reset_n,
    input  wire       wr_en,
    input  wire [7:0] wr_addr,
    input  wire [7:0] wr_data,
    input  wire       rd_en,
    input  wire [7:0] rd_addr,
    output reg  [7:0] rd_data,
    output reg        pwm_out,
    output reg  [7:0] counter_value
);

reg        enable_reg;
reg [7:0]  duty_cycle_reg;
reg [7:0]  period_reg;
reg [7:0]  counter_reg;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        enable_reg    <= 1'b0;
        duty_cycle_reg <= 8'h00;
        period_reg     <= 8'h00;
        counter_reg    <= 8'h00;
    end else begin
        if (wr_en) begin
            case (wr_addr)
                8'h00: begin
                    enable_reg <= wr_data[0];
                end
                8'h04: begin
                    duty_cycle_reg <= wr_data;
                end
                8'h08: begin
                    period_reg <= wr_data;
                end
                default: begin
                end
            endcase
        end

        if (enable_reg && (period_reg != 8'h00)) begin
            if (counter_reg >= period_reg) begin
                counter_reg <= 8'h00;
            end else begin
                counter_reg <= counter_reg + 8'h01;
            end
        end
    end
end

always @(*) begin
    rd_data = 8'h00;
    case (rd_addr)
        8'h00: begin
            rd_data = {7'b0000000, enable_reg};
        end
        8'h04: begin
            rd_data = duty_cycle_reg;
        end
        8'h08: begin
            rd_data = period_reg;
        end
        8'h0C: begin
            rd_data = counter_reg;
        end
        default: begin
            rd_data = 8'h00;
        end
    endcase
end

always @(*) begin
    counter_value = counter_reg;
    pwm_out = enable_reg && (period_reg != 8'h00) && (counter_reg < duty_cycle_reg);
end

endmodule
