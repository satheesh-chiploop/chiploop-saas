# IP Packaging & Handoff Report

- Top: `imported_from_arch2rtl`
- Package: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/c6ee09d5-9ed5-4657-8ee0-8d0c5bac0379/362198fc-5285-4d21-a0b0-582dddb95d2e/digital/arch2tapeout/handoff/imported_from_arch2rtl_ip_package`
- Zip: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/c6ee09d5-9ed5-4657-8ee0-8d0c5bac0379/362198fc-5285-4d21-a0b0-582dddb95d2e/digital/arch2tapeout/handoff/imported_from_arch2rtl_ip_package.zip`

## Bucket counts
- **rtl**: 1
- **spec**: 1
- **arch**: 0
- **microarch**: 0
- **regmap**: 1
- **constraints**: 0
- **power_intent**: 0
- **verification**: 0
- **reports**: 0
- **other**: 0
