#!/usr/bin/env bash
set -euo pipefail

echo "== ChipLoop: Digital Route Agent =="
echo "PDK_VARIANT=sky130A"
echo "OPENLANE_IMAGE=ghcr.io/efabless/openlane2:2.4.0.dev1"
echo "WORKDIR=/work"

export OPENLANE_NUM_CORES=2

docker run --rm   -v "/root/chiploop-backend/backend/pdk":/pdk   -v "/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/79590f2f-94eb-4577-895e-762a1d33add0/96257140-45a2-4f4a-81c1-40e517b7b6e4/digital/arch2tapeout/digital/run_work":/work   -e PDK=sky130A   -e PDK_ROOT=/pdk   ghcr.io/efabless/openlane2:2.4.0.dev1   bash -lc 'set -e; cd /work && openlane --flow Classic --run-tag Digital_Arch2Tapeout_79590f2f-94eb-4577-895e-762a1d33add0 --override-config RUN_LINTER=False --to OpenROAD.STAPostPNR route/config.json'
