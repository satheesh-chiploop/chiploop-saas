/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/79590f2f-94eb-4577-895e-762a1d33add0/96257140-45a2-4f4a-81c1-40e517b7b6e4/digital/arch2tapeout/handoff/rtl/pwm_controller.v
