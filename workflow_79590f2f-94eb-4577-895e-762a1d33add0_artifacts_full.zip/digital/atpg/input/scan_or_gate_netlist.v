module pwm_controller (clk,
    pwm_out,
    rd_en,
    reset_n,
    scan_en,
    wr_en,
    counter_value,
    rd_addr,
    rd_data,
    scan_in,
    scan_out,
    wr_addr,
    wr_data);
 input clk;
 output pwm_out;
 input rd_en;
 input reset_n;
 input scan_en;
 input wr_en;
 output [7:0] counter_value;
 input [7:0] rd_addr;
 output [7:0] rd_data;
 input [3:0] scan_in;
 output [3:0] scan_out;
 input [7:0] wr_addr;
 input [7:0] wr_data;

 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire _086_;
 wire _087_;
 wire _088_;
 wire _089_;
 wire _090_;
 wire _091_;
 wire _092_;
 wire _093_;
 wire _094_;
 wire _095_;
 wire _096_;
 wire _097_;
 wire _098_;
 wire _099_;
 wire _100_;
 wire _101_;
 wire _102_;
 wire _103_;
 wire _104_;
 wire _105_;
 wire _106_;
 wire _107_;
 wire _108_;
 wire _109_;
 wire _110_;
 wire _111_;
 wire control_reg;
 wire \duty_cycle_reg[0] ;
 wire \duty_cycle_reg[1] ;
 wire \duty_cycle_reg[2] ;
 wire \duty_cycle_reg[3] ;
 wire \duty_cycle_reg[4] ;
 wire \duty_cycle_reg[5] ;
 wire \duty_cycle_reg[6] ;
 wire \duty_cycle_reg[7] ;
 wire \period_reg[0] ;
 wire \period_reg[1] ;
 wire \period_reg[2] ;
 wire \period_reg[3] ;
 wire \period_reg[4] ;
 wire \period_reg[5] ;
 wire \period_reg[6] ;
 wire \period_reg[7] ;

 sky130_fd_sc_hd__and2_2 _112_ (.A(\period_reg[2] ),
    .B(_047_),
    .X(_054_));
 sky130_fd_sc_hd__a22o_2 _113_ (.A1(\duty_cycle_reg[2] ),
    .A2(_045_),
    .B1(_049_),
    .B2(counter_value[2]),
    .X(_055_));
 sky130_fd_sc_hd__o21a_2 _114_ (.A1(_054_),
    .A2(_055_),
    .B1(rd_en),
    .X(_011_));
 sky130_fd_sc_hd__and2_2 _115_ (.A(\period_reg[3] ),
    .B(_047_),
    .X(_056_));
 sky130_fd_sc_hd__a22o_2 _116_ (.A1(\duty_cycle_reg[3] ),
    .A2(_045_),
    .B1(_049_),
    .B2(counter_value[3]),
    .X(_057_));
 sky130_fd_sc_hd__o21a_2 _117_ (.A1(_056_),
    .A2(_057_),
    .B1(rd_en),
    .X(_012_));
 sky130_fd_sc_hd__and2_2 _118_ (.A(\period_reg[4] ),
    .B(_047_),
    .X(_058_));
 sky130_fd_sc_hd__a22o_2 _119_ (.A1(\duty_cycle_reg[4] ),
    .A2(_045_),
    .B1(_049_),
    .B2(counter_value[4]),
    .X(_059_));
 sky130_fd_sc_hd__o21a_2 _120_ (.A1(_058_),
    .A2(_059_),
    .B1(rd_en),
    .X(_013_));
 sky130_fd_sc_hd__and2_2 _121_ (.A(\duty_cycle_reg[5] ),
    .B(_045_),
    .X(_060_));
 sky130_fd_sc_hd__a22o_2 _122_ (.A1(\period_reg[5] ),
    .A2(_047_),
    .B1(_049_),
    .B2(counter_value[5]),
    .X(_061_));
 sky130_fd_sc_hd__o21a_2 _123_ (.A1(_060_),
    .A2(_061_),
    .B1(rd_en),
    .X(_014_));
 sky130_fd_sc_hd__and2_2 _124_ (.A(\duty_cycle_reg[6] ),
    .B(_045_),
    .X(_062_));
 sky130_fd_sc_hd__a22o_2 _125_ (.A1(\period_reg[6] ),
    .A2(_047_),
    .B1(_049_),
    .B2(counter_value[6]),
    .X(_063_));
 sky130_fd_sc_hd__o21a_2 _126_ (.A1(_062_),
    .A2(_063_),
    .B1(rd_en),
    .X(_015_));
 sky130_fd_sc_hd__and2_2 _127_ (.A(\duty_cycle_reg[7] ),
    .B(_045_),
    .X(_064_));
 sky130_fd_sc_hd__a22o_2 _128_ (.A1(\period_reg[7] ),
    .A2(_047_),
    .B1(_049_),
    .B2(counter_value[7]),
    .X(_065_));
 sky130_fd_sc_hd__o21a_2 _129_ (.A1(_064_),
    .A2(_065_),
    .B1(rd_en),
    .X(_016_));
 sky130_fd_sc_hd__xor2_2 _130_ (.A(counter_value[4]),
    .B(\period_reg[4] ),
    .X(_066_));
 sky130_fd_sc_hd__xor2_2 _131_ (.A(counter_value[7]),
    .B(\period_reg[7] ),
    .X(_067_));
 sky130_fd_sc_hd__xor2_2 _132_ (.A(counter_value[2]),
    .B(\period_reg[2] ),
    .X(_068_));
 sky130_fd_sc_hd__xor2_2 _133_ (.A(counter_value[3]),
    .B(\period_reg[3] ),
    .X(_069_));
 sky130_fd_sc_hd__or4_2 _134_ (.A(_066_),
    .B(_067_),
    .C(_068_),
    .D(_069_),
    .X(_070_));
 sky130_fd_sc_hd__xor2_2 _135_ (.A(counter_value[0]),
    .B(\period_reg[0] ),
    .X(_071_));
 sky130_fd_sc_hd__xor2_2 _136_ (.A(counter_value[6]),
    .B(\period_reg[6] ),
    .X(_072_));
 sky130_fd_sc_hd__xor2_2 _137_ (.A(counter_value[1]),
    .B(\period_reg[1] ),
    .X(_073_));
 sky130_fd_sc_hd__xor2_2 _138_ (.A(counter_value[5]),
    .B(\period_reg[5] ),
    .X(_074_));
 sky130_fd_sc_hd__or4_2 _139_ (.A(_071_),
    .B(_072_),
    .C(_073_),
    .D(_074_),
    .X(_075_));
 sky130_fd_sc_hd__or4_2 _140_ (.A(\period_reg[4] ),
    .B(\period_reg[5] ),
    .C(\period_reg[6] ),
    .D(\period_reg[7] ),
    .X(_076_));
 sky130_fd_sc_hd__or4_2 _141_ (.A(\period_reg[0] ),
    .B(\period_reg[1] ),
    .C(\period_reg[2] ),
    .D(\period_reg[3] ),
    .X(_077_));
 sky130_fd_sc_hd__o211a_2 _142_ (.A1(_076_),
    .A2(_077_),
    .B1(control_reg),
    .C1(reset_n),
    .X(_078_));
 sky130_fd_sc_hd__o21a_2 _143_ (.A1(_070_),
    .A2(_075_),
    .B1(_078_),
    .X(_079_));
 sky130_fd_sc_hd__and2b_2 _144_ (.A_N(counter_value[0]),
    .B(_079_),
    .X(_000_));
 sky130_fd_sc_hd__nand2_2 _145_ (.A(counter_value[1]),
    .B(counter_value[0]),
    .Y(_080_));
 sky130_fd_sc_hd__or2_2 _146_ (.A(counter_value[1]),
    .B(counter_value[0]),
    .X(_081_));
 sky130_fd_sc_hd__and3_2 _147_ (.A(_079_),
    .B(_080_),
    .C(_081_),
    .X(_001_));
 sky130_fd_sc_hd__a21o_2 _148_ (.A1(counter_value[1]),
    .A2(counter_value[0]),
    .B1(counter_value[2]),
    .X(_082_));
 sky130_fd_sc_hd__nand3_2 _149_ (.A(counter_value[2]),
    .B(counter_value[1]),
    .C(counter_value[0]),
    .Y(_083_));
 sky130_fd_sc_hd__and3_2 _150_ (.A(_079_),
    .B(_082_),
    .C(_083_),
    .X(_002_));
 sky130_fd_sc_hd__and4_2 _151_ (.A(counter_value[3]),
    .B(counter_value[2]),
    .C(counter_value[1]),
    .D(counter_value[0]),
    .X(_084_));
 sky130_fd_sc_hd__a31o_2 _152_ (.A1(counter_value[2]),
    .A2(counter_value[1]),
    .A3(counter_value[0]),
    .B1(counter_value[3]),
    .X(_085_));
 sky130_fd_sc_hd__and3b_2 _153_ (.A_N(_084_),
    .B(_085_),
    .C(_079_),
    .X(_003_));
 sky130_fd_sc_hd__or2_2 _154_ (.A(counter_value[4]),
    .B(_084_),
    .X(_086_));
 sky130_fd_sc_hd__nand2_2 _155_ (.A(counter_value[4]),
    .B(_084_),
    .Y(_087_));
 sky130_fd_sc_hd__and3_2 _156_ (.A(_079_),
    .B(_086_),
    .C(_087_),
    .X(_004_));
 sky130_fd_sc_hd__or2_2 _157_ (.A(_099_),
    .B(_087_),
    .X(_088_));
 sky130_fd_sc_hd__nand2_2 _158_ (.A(_099_),
    .B(_087_),
    .Y(_089_));
 sky130_fd_sc_hd__and3_2 _159_ (.A(_079_),
    .B(_088_),
    .C(_089_),
    .X(_005_));
 sky130_fd_sc_hd__a31o_2 _160_ (.A1(counter_value[5]),
    .A2(counter_value[4]),
    .A3(_084_),
    .B1(counter_value[6]),
    .X(_090_));
 sky130_fd_sc_hd__and4_2 _161_ (.A(counter_value[6]),
    .B(counter_value[5]),
    .C(counter_value[4]),
    .D(_084_),
    .X(_091_));
 sky130_fd_sc_hd__and3b_2 _162_ (.A_N(_091_),
    .B(_079_),
    .C(_090_),
    .X(_006_));
 sky130_fd_sc_hd__or2_2 _163_ (.A(counter_value[7]),
    .B(_091_),
    .X(_092_));
 sky130_fd_sc_hd__nand2_2 _164_ (.A(counter_value[7]),
    .B(_091_),
    .Y(_093_));
 sky130_fd_sc_hd__and3_2 _165_ (.A(_079_),
    .B(_092_),
    .C(_093_),
    .X(_007_));
 sky130_fd_sc_hd__or4_2 _166_ (.A(wr_addr[5]),
    .B(wr_addr[4]),
    .C(wr_addr[7]),
    .D(wr_addr[6]),
    .X(_094_));
 sky130_fd_sc_hd__nor3_2 _167_ (.A(wr_addr[1]),
    .B(wr_addr[0]),
    .C(_094_),
    .Y(_095_));
 sky130_fd_sc_hd__and4b_2 _168_ (.A_N(wr_addr[2]),
    .B(wr_en),
    .C(_095_),
    .D(wr_addr[3]),
    .X(_096_));
 sky130_fd_sc_hd__mux2_1 _169_ (.A0(\period_reg[0] ),
    .A1(wr_data[0]),
    .S(_096_),
    .X(_017_));
 sky130_fd_sc_hd__mux2_1 _170_ (.A0(\period_reg[1] ),
    .A1(wr_data[1]),
    .S(_096_),
    .X(_018_));
 sky130_fd_sc_hd__mux2_1 _171_ (.A0(\period_reg[2] ),
    .A1(wr_data[2]),
    .S(_096_),
    .X(_019_));
 sky130_fd_sc_hd__mux2_1 _172_ (.A0(\period_reg[3] ),
    .A1(wr_data[3]),
    .S(_096_),
    .X(_020_));
 sky130_fd_sc_hd__mux2_1 _173_ (.A0(\period_reg[4] ),
    .A1(wr_data[4]),
    .S(_096_),
    .X(_021_));
 sky130_fd_sc_hd__mux2_1 _174_ (.A0(\period_reg[5] ),
    .A1(wr_data[5]),
    .S(_096_),
    .X(_022_));
 sky130_fd_sc_hd__mux2_1 _175_ (.A0(\period_reg[6] ),
    .A1(wr_data[6]),
    .S(_096_),
    .X(_023_));
 sky130_fd_sc_hd__mux2_1 _176_ (.A0(\period_reg[7] ),
    .A1(wr_data[7]),
    .S(_096_),
    .X(_024_));
 sky130_fd_sc_hd__and4bb_2 _177_ (.A_N(wr_addr[3]),
    .B_N(wr_addr[2]),
    .C(wr_en),
    .D(_095_),
    .X(_097_));
 sky130_fd_sc_hd__mux2_1 _178_ (.A0(control_reg),
    .A1(wr_data[0]),
    .S(_097_),
    .X(_025_));
 sky130_fd_sc_hd__nand4b_2 _179_ (.A_N(wr_addr[3]),
    .B(wr_addr[2]),
    .C(wr_en),
    .D(_095_),
    .Y(_098_));
 sky130_fd_sc_hd__mux2_1 _180_ (.A0(wr_data[0]),
    .A1(\duty_cycle_reg[0] ),
    .S(_098_),
    .X(_026_));
 sky130_fd_sc_hd__mux2_1 _181_ (.A0(wr_data[1]),
    .A1(\duty_cycle_reg[1] ),
    .S(_098_),
    .X(_027_));
 sky130_fd_sc_hd__mux2_1 _182_ (.A0(wr_data[2]),
    .A1(\duty_cycle_reg[2] ),
    .S(_098_),
    .X(_028_));
 sky130_fd_sc_hd__mux2_1 _183_ (.A0(wr_data[3]),
    .A1(\duty_cycle_reg[3] ),
    .S(_098_),
    .X(_029_));
 sky130_fd_sc_hd__mux2_1 _184_ (.A0(wr_data[4]),
    .A1(\duty_cycle_reg[4] ),
    .S(_098_),
    .X(_030_));
 sky130_fd_sc_hd__mux2_1 _185_ (.A0(wr_data[5]),
    .A1(\duty_cycle_reg[5] ),
    .S(_098_),
    .X(_031_));
 sky130_fd_sc_hd__mux2_1 _186_ (.A0(wr_data[6]),
    .A1(\duty_cycle_reg[6] ),
    .S(_098_),
    .X(_032_));
 sky130_fd_sc_hd__mux2_1 _187_ (.A0(wr_data[7]),
    .A1(\duty_cycle_reg[7] ),
    .S(_098_),
    .X(_033_));
 sky130_fd_sc_hd__inv_2 _188_ (.A(counter_value[5]),
    .Y(_099_));
 sky130_fd_sc_hd__inv_2 _189_ (.A(\duty_cycle_reg[4] ),
    .Y(_100_));
 sky130_fd_sc_hd__inv_2 _190_ (.A(\duty_cycle_reg[3] ),
    .Y(_101_));
 sky130_fd_sc_hd__inv_2 _191_ (.A(\duty_cycle_reg[2] ),
    .Y(_102_));
 sky130_fd_sc_hd__inv_2 _192_ (.A(\duty_cycle_reg[1] ),
    .Y(_103_));
 sky130_fd_sc_hd__inv_2 _193_ (.A(\duty_cycle_reg[0] ),
    .Y(_104_));
 sky130_fd_sc_hd__a22o_2 _194_ (.A1(_101_),
    .A2(counter_value[3]),
    .B1(_102_),
    .B2(counter_value[2]),
    .X(_105_));
 sky130_fd_sc_hd__a211o_2 _195_ (.A1(_103_),
    .A2(counter_value[1]),
    .B1(_104_),
    .C1(counter_value[0]),
    .X(_106_));
 sky130_fd_sc_hd__o22a_2 _196_ (.A1(_102_),
    .A2(counter_value[2]),
    .B1(_103_),
    .B2(counter_value[1]),
    .X(_107_));
 sky130_fd_sc_hd__a21o_2 _197_ (.A1(_106_),
    .A2(_107_),
    .B1(_105_),
    .X(_108_));
 sky130_fd_sc_hd__nand2b_2 _198_ (.A_N(\duty_cycle_reg[6] ),
    .B(counter_value[6]),
    .Y(_109_));
 sky130_fd_sc_hd__nand2b_2 _199_ (.A_N(\duty_cycle_reg[7] ),
    .B(counter_value[7]),
    .Y(_110_));
 sky130_fd_sc_hd__nand2b_2 _200_ (.A_N(counter_value[7]),
    .B(\duty_cycle_reg[7] ),
    .Y(_111_));
 sky130_fd_sc_hd__nand2b_2 _201_ (.A_N(counter_value[6]),
    .B(\duty_cycle_reg[6] ),
    .Y(_034_));
 sky130_fd_sc_hd__and4_2 _202_ (.A(_109_),
    .B(_110_),
    .C(_111_),
    .D(_034_),
    .X(_035_));
 sky130_fd_sc_hd__o2bb2a_2 _203_ (.A1_N(counter_value[4]),
    .A2_N(_100_),
    .B1(\duty_cycle_reg[5] ),
    .B2(_099_),
    .X(_036_));
 sky130_fd_sc_hd__nand2b_2 _204_ (.A_N(counter_value[5]),
    .B(\duty_cycle_reg[5] ),
    .Y(_037_));
 sky130_fd_sc_hd__o221a_2 _205_ (.A1(counter_value[4]),
    .A2(_100_),
    .B1(_101_),
    .B2(counter_value[3]),
    .C1(_037_),
    .X(_038_));
 sky130_fd_sc_hd__and3_2 _206_ (.A(_035_),
    .B(_036_),
    .C(_038_),
    .X(_039_));
 sky130_fd_sc_hd__and3b_2 _207_ (.A_N(_036_),
    .B(_037_),
    .C(_035_),
    .X(_040_));
 sky130_fd_sc_hd__a21bo_2 _208_ (.A1(_109_),
    .A2(_110_),
    .B1_N(_111_),
    .X(_041_));
 sky130_fd_sc_hd__nand2_2 _209_ (.A(control_reg),
    .B(_041_),
    .Y(_042_));
 sky130_fd_sc_hd__a211oi_2 _210_ (.A1(_108_),
    .A2(_039_),
    .B1(_040_),
    .C1(_042_),
    .Y(_008_));
 sky130_fd_sc_hd__nor4_2 _211_ (.A(rd_addr[5]),
    .B(rd_addr[4]),
    .C(rd_addr[7]),
    .D(rd_addr[6]),
    .Y(_043_));
 sky130_fd_sc_hd__nor2_2 _212_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .Y(_044_));
 sky130_fd_sc_hd__and4b_2 _213_ (.A_N(rd_addr[3]),
    .B(_043_),
    .C(_044_),
    .D(rd_addr[2]),
    .X(_045_));
 sky130_fd_sc_hd__nor3_2 _214_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .C(rd_addr[2]),
    .Y(_046_));
 sky130_fd_sc_hd__and3_2 _215_ (.A(rd_addr[3]),
    .B(_043_),
    .C(_046_),
    .X(_047_));
 sky130_fd_sc_hd__and2_2 _216_ (.A(\period_reg[0] ),
    .B(_047_),
    .X(_048_));
 sky130_fd_sc_hd__and4_2 _217_ (.A(rd_addr[2]),
    .B(rd_addr[3]),
    .C(_043_),
    .D(_044_),
    .X(_049_));
 sky130_fd_sc_hd__and4b_2 _218_ (.A_N(rd_addr[3]),
    .B(_043_),
    .C(_046_),
    .D(control_reg),
    .X(_050_));
 sky130_fd_sc_hd__a221o_2 _219_ (.A1(\duty_cycle_reg[0] ),
    .A2(_045_),
    .B1(_049_),
    .B2(counter_value[0]),
    .C1(_050_),
    .X(_051_));
 sky130_fd_sc_hd__o21a_2 _220_ (.A1(_048_),
    .A2(_051_),
    .B1(rd_en),
    .X(_009_));
 sky130_fd_sc_hd__and2_2 _221_ (.A(\duty_cycle_reg[1] ),
    .B(_045_),
    .X(_052_));
 sky130_fd_sc_hd__a22o_2 _222_ (.A1(\period_reg[1] ),
    .A2(_047_),
    .B1(_049_),
    .B2(counter_value[1]),
    .X(_053_));
 sky130_fd_sc_hd__o21a_2 _223_ (.A1(_052_),
    .A2(_053_),
    .B1(rd_en),
    .X(_010_));
 sky130_fd_sc_hd__sdfrtp_2 _224_ (.CLK(clk),
    .D(_017_),
    .RESET_B(reset_n),
    .SCD(scan_in[0]),
    .SCE(scan_en),
    .Q(\period_reg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _225_ (.CLK(clk),
    .D(_018_),
    .RESET_B(reset_n),
    .SCD(scan_in[1]),
    .SCE(scan_en),
    .Q(\period_reg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _226_ (.CLK(clk),
    .D(_019_),
    .RESET_B(reset_n),
    .SCD(scan_in[2]),
    .SCE(scan_en),
    .Q(\period_reg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _227_ (.CLK(clk),
    .D(_020_),
    .RESET_B(reset_n),
    .SCD(scan_in[3]),
    .SCE(scan_en),
    .Q(\period_reg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _228_ (.CLK(clk),
    .D(_021_),
    .RESET_B(reset_n),
    .SCD(\period_reg[0] ),
    .SCE(scan_en),
    .Q(\period_reg[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _229_ (.CLK(clk),
    .D(_022_),
    .RESET_B(reset_n),
    .SCD(\period_reg[1] ),
    .SCE(scan_en),
    .Q(\period_reg[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _230_ (.CLK(clk),
    .D(_023_),
    .RESET_B(reset_n),
    .SCD(\period_reg[2] ),
    .SCE(scan_en),
    .Q(\period_reg[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _231_ (.CLK(clk),
    .D(_024_),
    .RESET_B(reset_n),
    .SCD(\period_reg[3] ),
    .SCE(scan_en),
    .Q(\period_reg[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _232_ (.CLK(clk),
    .D(_025_),
    .RESET_B(reset_n),
    .SCD(\period_reg[4] ),
    .SCE(scan_en),
    .Q(control_reg));
 sky130_fd_sc_hd__sdfrtp_2 _233_ (.CLK(clk),
    .D(_026_),
    .RESET_B(reset_n),
    .SCD(\period_reg[5] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _234_ (.CLK(clk),
    .D(_027_),
    .RESET_B(reset_n),
    .SCD(\period_reg[6] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _235_ (.CLK(clk),
    .D(_028_),
    .RESET_B(reset_n),
    .SCD(\period_reg[7] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _236_ (.CLK(clk),
    .D(_029_),
    .RESET_B(reset_n),
    .SCD(control_reg),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _237_ (.CLK(clk),
    .D(_030_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[0] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _238_ (.CLK(clk),
    .D(_031_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[1] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _239_ (.CLK(clk),
    .D(_032_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[2] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _240_ (.CLK(clk),
    .D(_033_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[3] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _241_ (.CLK(clk),
    .D(_000_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[4] ),
    .SCE(scan_en),
    .Q(counter_value[0]));
 sky130_fd_sc_hd__sdfrtp_2 _242_ (.CLK(clk),
    .D(_001_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[5] ),
    .SCE(scan_en),
    .Q(counter_value[1]));
 sky130_fd_sc_hd__sdfrtp_2 _243_ (.CLK(clk),
    .D(_002_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[6] ),
    .SCE(scan_en),
    .Q(counter_value[2]));
 sky130_fd_sc_hd__sdfrtp_2 _244_ (.CLK(clk),
    .D(_003_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[7] ),
    .SCE(scan_en),
    .Q(counter_value[3]));
 sky130_fd_sc_hd__sdfrtp_2 _245_ (.CLK(clk),
    .D(_004_),
    .RESET_B(reset_n),
    .SCD(counter_value[0]),
    .SCE(scan_en),
    .Q(counter_value[4]));
 sky130_fd_sc_hd__sdfrtp_2 _246_ (.CLK(clk),
    .D(_005_),
    .RESET_B(reset_n),
    .SCD(counter_value[1]),
    .SCE(scan_en),
    .Q(counter_value[5]));
 sky130_fd_sc_hd__sdfrtp_2 _247_ (.CLK(clk),
    .D(_006_),
    .RESET_B(reset_n),
    .SCD(counter_value[2]),
    .SCE(scan_en),
    .Q(counter_value[6]));
 sky130_fd_sc_hd__sdfrtp_2 _248_ (.CLK(clk),
    .D(_007_),
    .RESET_B(reset_n),
    .SCD(counter_value[3]),
    .SCE(scan_en),
    .Q(counter_value[7]));
 sky130_fd_sc_hd__sdfrtp_2 _249_ (.CLK(clk),
    .D(_009_),
    .RESET_B(reset_n),
    .SCD(counter_value[4]),
    .SCE(scan_en),
    .Q(rd_data[0]));
 sky130_fd_sc_hd__sdfrtp_2 _250_ (.CLK(clk),
    .D(_010_),
    .RESET_B(reset_n),
    .SCD(counter_value[5]),
    .SCE(scan_en),
    .Q(rd_data[1]));
 sky130_fd_sc_hd__sdfrtp_2 _251_ (.CLK(clk),
    .D(_011_),
    .RESET_B(reset_n),
    .SCD(counter_value[6]),
    .SCE(scan_en),
    .Q(rd_data[2]));
 sky130_fd_sc_hd__sdfrtp_2 _252_ (.CLK(clk),
    .D(_012_),
    .RESET_B(reset_n),
    .SCD(counter_value[7]),
    .SCE(scan_en),
    .Q(rd_data[3]));
 sky130_fd_sc_hd__sdfrtp_2 _253_ (.CLK(clk),
    .D(_013_),
    .RESET_B(reset_n),
    .SCD(rd_data[0]),
    .SCE(scan_en),
    .Q(rd_data[4]));
 sky130_fd_sc_hd__sdfrtp_2 _254_ (.CLK(clk),
    .D(_014_),
    .RESET_B(reset_n),
    .SCD(rd_data[1]),
    .SCE(scan_en),
    .Q(rd_data[5]));
 sky130_fd_sc_hd__sdfrtp_2 _255_ (.CLK(clk),
    .D(_015_),
    .RESET_B(reset_n),
    .SCD(rd_data[2]),
    .SCE(scan_en),
    .Q(rd_data[6]));
 sky130_fd_sc_hd__sdfrtp_2 _256_ (.CLK(clk),
    .D(_016_),
    .RESET_B(reset_n),
    .SCD(rd_data[3]),
    .SCE(scan_en),
    .Q(rd_data[7]));
 sky130_fd_sc_hd__sdfrtp_2 _257_ (.CLK(clk),
    .D(_008_),
    .RESET_B(reset_n),
    .SCD(rd_data[4]),
    .SCE(scan_en),
    .Q(pwm_out));
 assign scan_out[1] = pwm_out;
 assign scan_out[2] = rd_data[5];
 assign scan_out[3] = rd_data[6];
 assign scan_out[0] = rd_data[7];
endmodule
