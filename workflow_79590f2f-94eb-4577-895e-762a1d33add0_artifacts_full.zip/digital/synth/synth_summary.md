# Digital Synthesis Summary

- **Workflow**: 79590f2f-94eb-4577-895e-762a1d33add0
- **Status**: `ok` (rc=0)
- **Top module**: `pwm_controller`
- **Clock**: `clk` @ **9.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/79590f2f-94eb-4577-895e-762a1d33add0/96257140-45a2-4f4a-81c1-40e517b7b6e4/digital/arch2tapeout/digital/synth/runs/Digital_Arch2Tapeout_79590f2f-94eb-4577-895e-762a1d33add0/final/metrics.json`
- netlist candidates: 2 found
