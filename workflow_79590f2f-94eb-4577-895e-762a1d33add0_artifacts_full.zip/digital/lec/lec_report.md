# Logic Equivalence Check

- Status: `inconclusive`
- Tool: `yosys`
- Top module: `pwm_controller`
- RTL files: `1`
- Synth netlist: `pwm_controller_synth.v`
- Liberty files discovered: `1`
- Standard-cell Verilog models loaded: `1`
- Standard-cell model strategy: `generated_functional_wrappers_from_gate_netlist`
- Missing standard-cell models: `0`
- Unproven points: `3`
- Return code: `1`
- Failure reason: `equivalence_points_unproven`

If this is inconclusive, inspect `digital/lec/logs/yosys_lec.log` and `digital/lec/lec_summary.json` for unsupported cells, black boxes, or reset/initial-state assumptions.
