module pwm_fpga_demo (
    clk,
    led
);

input clk;
output led;

reg [7:0] pwm_counter;
reg [7:0] duty_cycle;
reg       direction;
reg [23:0] slow_counter;

wire pwm_on;
wire slow_tick;
wire at_low;
wire at_high;

assign pwm_on = (pwm_counter < duty_cycle);
assign led = pwm_on;
assign slow_tick = (slow_counter == 24'd0);
assign at_low = (duty_cycle == 8'h00);
assign at_high = (duty_cycle == 8'hFF);

always @(posedge clk) begin
    pwm_counter <= pwm_counter + 8'd1;

    if (slow_counter == 24'd12499999)
        slow_counter <= 24'd0;
    else
        slow_counter <= slow_counter + 24'd1;

    if (slow_tick) begin
        if (direction) begin
            if (at_high) begin
                direction <= 1'b0;
                duty_cycle <= 8'hFE;
            end else begin
                duty_cycle <= duty_cycle + 8'd1;
            end
        end else begin
            if (at_low) begin
                direction <= 1'b1;
                duty_cycle <= 8'h01;
            end else begin
                duty_cycle <= duty_cycle - 8'd1;
            end
        end
    end
end

endmodule
