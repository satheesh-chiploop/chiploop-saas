// ASSUMPTION: Interrupt decode is software-mediated using firmware-visible status/interrupt bits.
// ASSUMPTION: No MCU-style external vector table is generated unless the hardware contract explicitly requires one.

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum InterruptSource {
    FaultClearPattern,
    FaultLatched,
    FaultCtrl,
}

#[inline]
pub fn interrupt_count() -> usize {
    3
}

pub const FAULT_CLEAR_PATTERN_BIT: u32 = 0;
pub const FAULT_LATCHED_BIT: u32 = 1;
pub const FAULT_CTRL_BIT: u32 = 2;

#[inline]
pub fn handle_fault_clear_pattern() {
    // Default ISR scaffold: replace with concrete firmware behavior as needed.
}

#[inline]
pub fn handle_fault_latched() {
    // Default ISR scaffold: replace with concrete firmware behavior as needed.
}

#[inline]
pub fn handle_fault_ctrl() {
    // Default ISR scaffold: replace with concrete firmware behavior as needed.
}

#[inline]
pub fn dispatch_interrupt(bit_index: u32) -> bool {
    match bit_index {
        FAULT_CLEAR_PATTERN_BIT => { handle_fault_clear_pattern(); true }
        FAULT_LATCHED_BIT => { handle_fault_latched(); true }
        FAULT_CTRL_BIT => { handle_fault_ctrl(); true }
        _ => false,
    }
}
