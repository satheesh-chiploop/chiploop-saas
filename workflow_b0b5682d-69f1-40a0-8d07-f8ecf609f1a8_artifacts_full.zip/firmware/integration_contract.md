# firmware/integration_contract.md

## Contract Overview
- Target platform: `ulx3s_ecp5_45f_esp32` with ESP32 as hard CPU and FPGA as SPI-attached peripheral.
- Firmware responsibility: host-side control plane over `spi_register` transport; no claim of a deployable binary unless platform contract gate is satisfied.
- Transport contract: SPI mode 0, MSB-first full-duplex frames, 224-bit frame length, 12 leading padding bits, 4 trailing padding bits.
- Command model: transaction `N` is committed on CS rising edge; response for transaction `N` is observed in frame `N+2`.
- Firmware owns frame packing/unpacking, request sequencing, timeout handling, status/error reporting, and register access policy on the ESP32.
- FPGA register collateral is the source of truth for exposed register semantics; firmware must not invent undocumented control bits or side effects.
- System/host software owns higher-level policy, orchestration, and validation against this contract.
- Validation is required against the declared bit maps, latency, and interframe timing before any deployment claim.

## Contract Version + Compatibility Policy
- Contract schema: `chiploop.application_intelligence.target_refinement.v1`
- Contract version: `1.0.0`
- Compatibility policy:
  - Backward compatible changes only within the same major version.
  - Any change to frame length, bit mapping, response latency, or SPI mode requires a major version bump.
  - New optional registers or status bits may be added only in unused bits and must preserve existing bit positions.
  - Firmware must reject or flag mismatched transport parameters at runtime if detected from platform metadata or self-test.
  - Validation artifacts must record the exact contract version and target refinement revision used for build/test.

## Interfaces

### Transport Interface
| Name | Direction | Type | Definition |
|---|---:|---|---|
| `spi_sclk` | FW -> FPGA | SPI clock | ESP32 GPIO 14 |
| `spi_cs_n` | FW -> FPGA | Chip select, active low | ESP32 GPIO 13 |
| `spi_mosi` | FW -> FPGA | MOSI | ESP32 GPIO 15 |
| `spi_miso` | FPGA -> FW | MISO | ESP32 GPIO 2 |

### SPI Transaction Parameters
| Parameter | Value |
|---|---:|
| SPI mode | 0 |
| Bit order | MSB-first |
| Maximum SPI clock | 10 MHz |
| Minimum interframe delay | 1 µs |
| Frame size | 224 bits / 28 bytes |
| Leading padding | 12 bits |
| Trailing padding | 4 bits |
| Response latency | 2 frames |
| Transaction commit | On CS rising edge |

### Serialized Frame Layout
#### Input bit map
| LSB | Width | Field | Direction | Notes |
|---:|---:|---|---|---|
| 0 | 8 | `cfg_bus_addr` | FW -> FPGA | Configuration bus address |
| 8 | 64 | `cfg_bus_wdata` | FW -> FPGA | Configuration bus write data |
| 72 | 1 | `cfg_bus_valid` | FW -> FPGA | Valid strobe |
| 73 | 1 | `cfg_bus_write` | FW -> FPGA | Write enable |
| 74 | 1 | `req_ready` | FW -> FPGA | Request ready signal |
| 75 | 128 | `rsp_data` | FPGA -> FW | Response data payload |
| 203 | 1 | `rsp_valid` | FPGA -> FW | Response valid strobe |
| 204 | 8 | `seq_next` | FPGA -> FW | Next sequence token |

#### Output bit map
| LSB | Width | Field | Direction | Notes |
|---:|---:|---|---|---|
| 0 | 8 | `fault_out` | FPGA -> FW | Fault/status code |
| 8 | 16 | `act_cmd` | FPGA -> FW | Action command |
| 24 | 1 | `rsp_ready` | FPGA -> FW | Response ready handshake |
| 25 | 1 | `req_valid` | FPGA -> FW | Request valid handshake |
| 26 | 128 | `req_data` | FPGA -> FW | Request payload |
| 154 | 1 | `cfg_bus_rvalid` | FPGA -> FW | Config read valid |
| 155 | 1 | `cfg_bus_ready` | FPGA -> FW | Config bus ready |
| 156 | 64 | `cfg_bus_rdata` | FPGA -> FW | Config bus read data |

### Firmware APIs
| API | Prototype/Behavior | Ownership |
|---|---|---|
| `fw_transport_init()` | Initialize SPI peripheral and GPIOs using contract parameters. Return status code. | Firmware |
| `fw_transport_deinit()` | Disable SPI peripheral and release GPIOs. | Firmware |
| `fw_frame_txrx(const uint8_t *tx, uint8_t *rx, size_t len)` | Exchange one 28-byte frame over SPI with CS framing and timing constraints. | Firmware |
| `fw_reg_write(uint8_t addr, uint64_t value)` | Issue config bus write transaction via transport frame packing. | Firmware |
| `fw_reg_read(uint8_t addr, uint64_t *value)` | Issue config bus read transaction and return data when valid. | Firmware |
| `fw_get_fault(uint8_t *fault_out)` | Read latest latched fault/status value from transport response. | Firmware |
| `fw_get_version(struct fw_version *v)` | Return firmware contract version and build metadata. | Firmware |
| `fw_self_test(void)` | Verify transport, frame packing, and baseline handshake behavior. | Firmware |

### Logging and Error Codes
| Category | Code | Meaning | Ownership |
|---|---:|---|---|
| OK | 0 | Success | Firmware |
| Transport | 1 | SPI init or transfer failure | Firmware |
| Timeout | 2 | Expected response not observed within allowed frame window | Firmware |
| Protocol | 3 | Frame size, padding, or sequencing mismatch | Firmware |
| Contract | 4 | Unsupported target refinement or transport parameters | Firmware |
| Fault | 5 | `fault_out` indicates device-side fault condition | Firmware |
| Unavailable | 6 | Requested feature not present in approved collateral | Firmware |

### Logging Schema
| Field | Type | Description |
|---|---|---|
| `ts_us` | integer | Monotonic timestamp in microseconds |
| `level` | string | `DEBUG`, `INFO`, `WARN`, `ERROR` |
| `component` | string | Fixed string `fw.transport` or `fw.reg` |
| `event` | string | Event name such as `spi_init`, `frame_txrx`, `reg_read`, `fault_seen` |
| `seq` | integer | Frame sequence token |
| `status` | integer | Error code or zero |
| `detail` | string | Compact human-readable detail |
| `fault_out` | integer | Latched device fault code when present |

## Ownership Boundaries

| Area | Firmware | System/Host | Validation |
|---|---|---|---|
| SPI transport setup | Owns GPIO/SPI configuration and frame timing | Consumes status only | Verifies parameters match contract |
| Frame encoding/decoding | Owns bit packing/unpacking | Must not manipulate raw frame bits directly | Confirms bit positions and endianness |
| Register access sequencing | Owns low-level transaction sequencing | Requests register operations through API | Checks read/write behavior and latency |
| Error reporting | Owns error codes and logging emission | Consumes errors and decides recovery policy | Injects faults and validates codes |
| Platform policy | Does not own application policy | Owns higher-level orchestration | Ensures policy does not violate contract |

## Assumptions
- The approved partition and RTL register collateral are authoritative for any exposed register semantics.
- The ESP32 runs `esp-idf` on `xtensa-lx6` with CMake-based build flow.
- The FPGA side already implements the declared SPI register protocol and frame layout.
- `deployable_binary_ready` being true only indicates contract gate readiness, not that this document claims a built artifact.
- No additional device-layer jobs or interfaces are assumed beyond the declared SPI transport and register access path.
- Any undocumented register field must be treated as reserved.
- Timing compliance is measured at the SPI transaction boundary, not at higher-level application calls.

## Validation Hooks
- Verify SPI configuration matches mode 0, MSB-first, and ≤10 MHz clock.
- Capture raw frames and confirm 28-byte length, 12 leading padding bits, and 4 trailing padding bits.
- Perform write/read loopback checks for representative config bus addresses and confirm returned data aligns with the declared bit map.
- Validate response timing by issuing transaction `N` and confirming response `N` is observable in frame `N+2`.
- Confirm CS deassertion commits a transaction and interframe delay is at least 1 µs.
- Inject protocol faults and confirm error code mapping, especially timeout, protocol, and contract errors.
- Verify `fault_out` propagation into logs and API status returns.
- Run build-time checks that fail if frame size, SPI mode, bit order, or target board metadata diverge from contract.
- Record validation artifacts with contract version, target refinement identifier, and build hash.