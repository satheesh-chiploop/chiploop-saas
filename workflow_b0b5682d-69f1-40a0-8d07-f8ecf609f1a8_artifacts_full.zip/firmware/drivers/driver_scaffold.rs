use crate::hal::registers::*;

pub struct DigitalSubsystemDriver;

impl DigitalSubsystemDriver {
    #[inline]
    pub const fn new() -> Self {
        Self
    }

    #[inline]
    pub fn read_ctrl(&self) -> u32 {
        read_ctrl()
    }

    #[inline]
    pub fn write_ctrl(&self, value: u32) {
        write_ctrl(value)
    }

    #[inline]
    pub fn get_ctrl_enable(&self) -> bool {
        get_ctrl_enable() != 0
    }

    #[inline]
    pub fn set_ctrl_enable(&self, value: bool) {
        set_ctrl_enable(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_ctrl_mode(&self) -> u8 {
        get_ctrl_mode() as u8
    }

    #[inline]
    pub fn set_ctrl_mode(&self, value: u8) {
        set_ctrl_mode(value as u32)
    }

    #[inline]
    pub fn get_ctrl_ref_mode(&self) -> bool {
        get_ctrl_ref_mode() != 0
    }

    #[inline]
    pub fn set_ctrl_ref_mode(&self, value: bool) {
        set_ctrl_ref_mode(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_ctrl_arm_key(&self) -> u16 {
        get_ctrl_arm_key() as u16
    }

    #[inline]
    pub fn set_ctrl_arm_key(&self, value: u16) {
        set_ctrl_arm_key(value as u32)
    }

    #[inline]
    pub fn get_ctrl_clear_ack(&self) -> u8 {
        get_ctrl_clear_ack() as u8
    }

    #[inline]
    pub fn set_ctrl_clear_ack(&self, value: u8) {
        set_ctrl_clear_ack(value as u32)
    }

    #[inline]
    pub fn get_ctrl_reserved(&self) -> u32 {
        get_ctrl_reserved() as u32
    }

    #[inline]
    pub fn set_ctrl_reserved(&self, value: u32) {
        set_ctrl_reserved(value as u32)
    }

    #[inline]
    pub fn read_velocity_bounds(&self) -> u32 {
        read_velocity_bounds()
    }

    #[inline]
    pub fn write_velocity_bounds(&self, value: u32) {
        write_velocity_bounds(value)
    }

    #[inline]
    pub fn get_velocity_bounds_velocity_min(&self) -> u16 {
        get_velocity_bounds_velocity_min() as u16
    }

    #[inline]
    pub fn set_velocity_bounds_velocity_min(&self, value: u16) {
        set_velocity_bounds_velocity_min(value as u32)
    }

    #[inline]
    pub fn get_velocity_bounds_velocity_max(&self) -> u16 {
        get_velocity_bounds_velocity_max() as u16
    }

    #[inline]
    pub fn set_velocity_bounds_velocity_max(&self, value: u16) {
        set_velocity_bounds_velocity_max(value as u32)
    }

    #[inline]
    pub fn get_velocity_bounds_nominal_velocity(&self) -> u16 {
        get_velocity_bounds_nominal_velocity() as u16
    }

    #[inline]
    pub fn set_velocity_bounds_nominal_velocity(&self, value: u16) {
        set_velocity_bounds_nominal_velocity(value as u32)
    }

    #[inline]
    pub fn get_velocity_bounds_reserved(&self) -> u16 {
        get_velocity_bounds_reserved() as u16
    }

    #[inline]
    pub fn set_velocity_bounds_reserved(&self, value: u16) {
        set_velocity_bounds_reserved(value as u32)
    }

    #[inline]
    pub fn read_timeout_and_limits(&self) -> u32 {
        read_timeout_and_limits()
    }

    #[inline]
    pub fn write_timeout_and_limits(&self, value: u32) {
        write_timeout_and_limits(value)
    }

    #[inline]
    pub fn get_timeout_and_limits_timeout_cycles(&self) -> u16 {
        get_timeout_and_limits_timeout_cycles() as u16
    }

    #[inline]
    pub fn set_timeout_and_limits_timeout_cycles(&self, value: u16) {
        set_timeout_and_limits_timeout_cycles(value as u32)
    }

    #[inline]
    pub fn get_timeout_and_limits_clamp_min(&self) -> u16 {
        get_timeout_and_limits_clamp_min() as u16
    }

    #[inline]
    pub fn set_timeout_and_limits_clamp_min(&self, value: u16) {
        set_timeout_and_limits_clamp_min(value as u32)
    }

    #[inline]
    pub fn get_timeout_and_limits_clamp_max(&self) -> u16 {
        get_timeout_and_limits_clamp_max() as u16
    }

    #[inline]
    pub fn set_timeout_and_limits_clamp_max(&self, value: u16) {
        set_timeout_and_limits_clamp_max(value as u32)
    }

    #[inline]
    pub fn get_timeout_and_limits_clamp_rate(&self) -> u8 {
        get_timeout_and_limits_clamp_rate() as u8
    }

    #[inline]
    pub fn set_timeout_and_limits_clamp_rate(&self, value: u8) {
        set_timeout_and_limits_clamp_rate(value as u32)
    }

    #[inline]
    pub fn get_timeout_and_limits_req_limit(&self) -> u8 {
        get_timeout_and_limits_req_limit() as u8
    }

    #[inline]
    pub fn set_timeout_and_limits_req_limit(&self, value: u8) {
        set_timeout_and_limits_req_limit(value as u32)
    }

    #[inline]
    pub fn read_geometry_and_ref(&self) -> u32 {
        read_geometry_and_ref()
    }

    #[inline]
    pub fn write_geometry_and_ref(&self, value: u32) {
        write_geometry_and_ref(value)
    }

    #[inline]
    pub fn get_geometry_and_ref_geometry_token(&self) -> u8 {
        get_geometry_and_ref_geometry_token() as u8
    }

    #[inline]
    pub fn set_geometry_and_ref_geometry_token(&self, value: u8) {
        set_geometry_and_ref_geometry_token(value as u32)
    }

    #[inline]
    pub fn get_geometry_and_ref_ref_cmd(&self) -> u16 {
        get_geometry_and_ref_ref_cmd() as u16
    }

    #[inline]
    pub fn set_geometry_and_ref_ref_cmd(&self, value: u16) {
        set_geometry_and_ref_ref_cmd(value as u32)
    }

    #[inline]
    pub fn get_geometry_and_ref_fault_clear_pattern(&self) -> u8 {
        get_geometry_and_ref_fault_clear_pattern() as u8
    }

    #[inline]
    pub fn set_geometry_and_ref_fault_clear_pattern(&self, value: u8) {
        set_geometry_and_ref_fault_clear_pattern(value as u32)
    }

    #[inline]
    pub fn get_geometry_and_ref_rearm_key_shadow(&self) -> u16 {
        get_geometry_and_ref_rearm_key_shadow() as u16
    }

    #[inline]
    pub fn set_geometry_and_ref_rearm_key_shadow(&self, value: u16) {
        set_geometry_and_ref_rearm_key_shadow(value as u32)
    }

    #[inline]
    pub fn get_geometry_and_ref_reserved(&self) -> u16 {
        get_geometry_and_ref_reserved() as u16
    }

    #[inline]
    pub fn set_geometry_and_ref_reserved(&self, value: u16) {
        set_geometry_and_ref_reserved(value as u32)
    }

    #[inline]
    pub fn read_status(&self) -> u32 {
        read_status()
    }

    #[inline]
    pub fn get_status_seq_issued(&self) -> u8 {
        get_status_seq_issued() as u8
    }

    #[inline]
    pub fn get_status_seq_accepted(&self) -> u8 {
        get_status_seq_accepted() as u8
    }

    #[inline]
    pub fn get_status_fault_latched(&self) -> u8 {
        get_status_fault_latched() as u8
    }

    #[inline]
    pub fn get_status_state_bits(&self) -> u8 {
        get_status_state_bits() as u8
    }

    #[inline]
    pub fn get_status_cfg_valid(&self) -> bool {
        get_status_cfg_valid() != 0
    }

    #[inline]
    pub fn get_status_enable_gate_ok(&self) -> bool {
        get_status_enable_gate_ok() != 0
    }

    #[inline]
    pub fn get_status_reserved(&self) -> u32 {
        get_status_reserved() as u32
    }

    #[inline]
    pub fn read_req_frame_low(&self) -> u32 {
        read_req_frame_low()
    }

    #[inline]
    pub fn get_req_frame_low_req_frame_low(&self) -> u32 {
        get_req_frame_low_req_frame_low() as u32
    }

    #[inline]
    pub fn read_req_frame_high(&self) -> u32 {
        read_req_frame_high()
    }

    #[inline]
    pub fn get_req_frame_high_req_frame_high(&self) -> u32 {
        get_req_frame_high_req_frame_high() as u32
    }

    #[inline]
    pub fn read_rsp_summary(&self) -> u32 {
        read_rsp_summary()
    }

    #[inline]
    pub fn get_rsp_summary_rsp_seq_echo(&self) -> u8 {
        get_rsp_summary_rsp_seq_echo() as u8
    }

    #[inline]
    pub fn get_rsp_summary_rsp_status_bits(&self) -> u8 {
        get_rsp_summary_rsp_status_bits() as u8
    }

    #[inline]
    pub fn get_rsp_summary_rsp_drag_summary(&self) -> u16 {
        get_rsp_summary_rsp_drag_summary() as u16
    }

    #[inline]
    pub fn get_rsp_summary_rsp_lift_summary(&self) -> u16 {
        get_rsp_summary_rsp_lift_summary() as u16
    }

    #[inline]
    pub fn get_rsp_summary_reserved(&self) -> u16 {
        get_rsp_summary_reserved() as u16
    }

    #[inline]
    pub fn read_fault_ctrl(&self) -> u32 {
        read_fault_ctrl()
    }

    #[inline]
    pub fn write_fault_ctrl(&self, value: u32) {
        write_fault_ctrl(value)
    }

    #[inline]
    pub fn get_fault_ctrl_clear_ack_accept(&self) -> bool {
        get_fault_ctrl_clear_ack_accept() != 0
    }

    #[inline]
    pub fn set_fault_ctrl_clear_ack_accept(&self, value: bool) {
        set_fault_ctrl_clear_ack_accept(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_fault_ctrl_reserved(&self) -> u32 {
        get_fault_ctrl_reserved() as u32
    }

    #[inline]
    pub fn set_fault_ctrl_reserved(&self, value: u32) {
        set_fault_ctrl_reserved(value as u32)
    }

}
