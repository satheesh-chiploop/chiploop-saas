use core::ptr::{read_volatile, write_volatile};

pub const BASE_ADDRESS: usize = 0x00000000;

pub const CTRL_OFFSET: usize = 0x00000000;
pub const CTRL_ENABLE_SHIFT: u32 = 0;
pub const CTRL_ENABLE_WIDTH: u32 = 1;
pub const CTRL_ENABLE_MASK: u64 = 0x0000000000000001;
pub const CTRL_MODE_SHIFT: u32 = 1;
pub const CTRL_MODE_WIDTH: u32 = 2;
pub const CTRL_MODE_MASK: u64 = 0x0000000000000006;
pub const CTRL_REF_MODE_SHIFT: u32 = 3;
pub const CTRL_REF_MODE_WIDTH: u32 = 1;
pub const CTRL_REF_MODE_MASK: u64 = 0x0000000000000008;
pub const CTRL_ARM_KEY_SHIFT: u32 = 4;
pub const CTRL_ARM_KEY_WIDTH: u32 = 16;
pub const CTRL_ARM_KEY_MASK: u64 = 0x00000000000FFFF0;
pub const CTRL_CLEAR_ACK_SHIFT: u32 = 20;
pub const CTRL_CLEAR_ACK_WIDTH: u32 = 8;
pub const CTRL_CLEAR_ACK_MASK: u64 = 0x000000000FF00000;
pub const CTRL_RESERVED_SHIFT: u32 = 28;
pub const CTRL_RESERVED_WIDTH: u32 = 36;
pub const CTRL_RESERVED_MASK: u64 = 0xFFFFFFFFF0000000;
pub const VELOCITY_BOUNDS_OFFSET: usize = 0x00000008;
pub const VELOCITY_BOUNDS_VELOCITY_MIN_SHIFT: u32 = 0;
pub const VELOCITY_BOUNDS_VELOCITY_MIN_WIDTH: u32 = 16;
pub const VELOCITY_BOUNDS_VELOCITY_MIN_MASK: u64 = 0x000000000000FFFF;
pub const VELOCITY_BOUNDS_VELOCITY_MAX_SHIFT: u32 = 16;
pub const VELOCITY_BOUNDS_VELOCITY_MAX_WIDTH: u32 = 16;
pub const VELOCITY_BOUNDS_VELOCITY_MAX_MASK: u64 = 0x00000000FFFF0000;
pub const VELOCITY_BOUNDS_NOMINAL_VELOCITY_SHIFT: u32 = 32;
pub const VELOCITY_BOUNDS_NOMINAL_VELOCITY_WIDTH: u32 = 16;
pub const VELOCITY_BOUNDS_NOMINAL_VELOCITY_MASK: u64 = 0x0000FFFF00000000;
pub const VELOCITY_BOUNDS_RESERVED_SHIFT: u32 = 48;
pub const VELOCITY_BOUNDS_RESERVED_WIDTH: u32 = 16;
pub const VELOCITY_BOUNDS_RESERVED_MASK: u64 = 0xFFFF000000000000;
pub const TIMEOUT_AND_LIMITS_OFFSET: usize = 0x00000010;
pub const TIMEOUT_AND_LIMITS_TIMEOUT_CYCLES_SHIFT: u32 = 0;
pub const TIMEOUT_AND_LIMITS_TIMEOUT_CYCLES_WIDTH: u32 = 16;
pub const TIMEOUT_AND_LIMITS_TIMEOUT_CYCLES_MASK: u64 = 0x000000000000FFFF;
pub const TIMEOUT_AND_LIMITS_CLAMP_MIN_SHIFT: u32 = 16;
pub const TIMEOUT_AND_LIMITS_CLAMP_MIN_WIDTH: u32 = 16;
pub const TIMEOUT_AND_LIMITS_CLAMP_MIN_MASK: u64 = 0x00000000FFFF0000;
pub const TIMEOUT_AND_LIMITS_CLAMP_MAX_SHIFT: u32 = 32;
pub const TIMEOUT_AND_LIMITS_CLAMP_MAX_WIDTH: u32 = 16;
pub const TIMEOUT_AND_LIMITS_CLAMP_MAX_MASK: u64 = 0x0000FFFF00000000;
pub const TIMEOUT_AND_LIMITS_CLAMP_RATE_SHIFT: u32 = 48;
pub const TIMEOUT_AND_LIMITS_CLAMP_RATE_WIDTH: u32 = 8;
pub const TIMEOUT_AND_LIMITS_CLAMP_RATE_MASK: u64 = 0x00FF000000000000;
pub const TIMEOUT_AND_LIMITS_REQ_LIMIT_SHIFT: u32 = 56;
pub const TIMEOUT_AND_LIMITS_REQ_LIMIT_WIDTH: u32 = 8;
pub const TIMEOUT_AND_LIMITS_REQ_LIMIT_MASK: u64 = 0xFF00000000000000;
pub const GEOMETRY_AND_REF_OFFSET: usize = 0x00000018;
pub const GEOMETRY_AND_REF_GEOMETRY_TOKEN_SHIFT: u32 = 0;
pub const GEOMETRY_AND_REF_GEOMETRY_TOKEN_WIDTH: u32 = 8;
pub const GEOMETRY_AND_REF_GEOMETRY_TOKEN_MASK: u64 = 0x00000000000000FF;
pub const GEOMETRY_AND_REF_REF_CMD_SHIFT: u32 = 8;
pub const GEOMETRY_AND_REF_REF_CMD_WIDTH: u32 = 16;
pub const GEOMETRY_AND_REF_REF_CMD_MASK: u64 = 0x0000000000FFFF00;
pub const GEOMETRY_AND_REF_FAULT_CLEAR_PATTERN_SHIFT: u32 = 24;
pub const GEOMETRY_AND_REF_FAULT_CLEAR_PATTERN_WIDTH: u32 = 8;
pub const GEOMETRY_AND_REF_FAULT_CLEAR_PATTERN_MASK: u64 = 0x00000000FF000000;
pub const GEOMETRY_AND_REF_REARM_KEY_SHADOW_SHIFT: u32 = 32;
pub const GEOMETRY_AND_REF_REARM_KEY_SHADOW_WIDTH: u32 = 16;
pub const GEOMETRY_AND_REF_REARM_KEY_SHADOW_MASK: u64 = 0x0000FFFF00000000;
pub const GEOMETRY_AND_REF_RESERVED_SHIFT: u32 = 48;
pub const GEOMETRY_AND_REF_RESERVED_WIDTH: u32 = 16;
pub const GEOMETRY_AND_REF_RESERVED_MASK: u64 = 0xFFFF000000000000;
pub const STATUS_OFFSET: usize = 0x00000020;
pub const STATUS_SEQ_ISSUED_SHIFT: u32 = 0;
pub const STATUS_SEQ_ISSUED_WIDTH: u32 = 8;
pub const STATUS_SEQ_ISSUED_MASK: u64 = 0x00000000000000FF;
pub const STATUS_SEQ_ACCEPTED_SHIFT: u32 = 8;
pub const STATUS_SEQ_ACCEPTED_WIDTH: u32 = 8;
pub const STATUS_SEQ_ACCEPTED_MASK: u64 = 0x000000000000FF00;
pub const STATUS_FAULT_LATCHED_SHIFT: u32 = 16;
pub const STATUS_FAULT_LATCHED_WIDTH: u32 = 8;
pub const STATUS_FAULT_LATCHED_MASK: u64 = 0x0000000000FF0000;
pub const STATUS_STATE_BITS_SHIFT: u32 = 24;
pub const STATUS_STATE_BITS_WIDTH: u32 = 2;
pub const STATUS_STATE_BITS_MASK: u64 = 0x0000000003000000;
pub const STATUS_CFG_VALID_SHIFT: u32 = 26;
pub const STATUS_CFG_VALID_WIDTH: u32 = 1;
pub const STATUS_CFG_VALID_MASK: u64 = 0x0000000004000000;
pub const STATUS_ENABLE_GATE_OK_SHIFT: u32 = 27;
pub const STATUS_ENABLE_GATE_OK_WIDTH: u32 = 1;
pub const STATUS_ENABLE_GATE_OK_MASK: u64 = 0x0000000008000000;
pub const STATUS_RESERVED_SHIFT: u32 = 28;
pub const STATUS_RESERVED_WIDTH: u32 = 36;
pub const STATUS_RESERVED_MASK: u64 = 0xFFFFFFFFF0000000;
pub const REQ_FRAME_LOW_OFFSET: usize = 0x00000028;
pub const REQ_FRAME_LOW_REQ_FRAME_LOW_SHIFT: u32 = 0;
pub const REQ_FRAME_LOW_REQ_FRAME_LOW_WIDTH: u32 = 64;
pub const REQ_FRAME_LOW_REQ_FRAME_LOW_MASK: u64 = 0xFFFFFFFFFFFFFFFF;
pub const REQ_FRAME_HIGH_OFFSET: usize = 0x00000030;
pub const REQ_FRAME_HIGH_REQ_FRAME_HIGH_SHIFT: u32 = 0;
pub const REQ_FRAME_HIGH_REQ_FRAME_HIGH_WIDTH: u32 = 64;
pub const REQ_FRAME_HIGH_REQ_FRAME_HIGH_MASK: u64 = 0xFFFFFFFFFFFFFFFF;
pub const RSP_SUMMARY_OFFSET: usize = 0x00000038;
pub const RSP_SUMMARY_RSP_SEQ_ECHO_SHIFT: u32 = 0;
pub const RSP_SUMMARY_RSP_SEQ_ECHO_WIDTH: u32 = 8;
pub const RSP_SUMMARY_RSP_SEQ_ECHO_MASK: u64 = 0x00000000000000FF;
pub const RSP_SUMMARY_RSP_STATUS_BITS_SHIFT: u32 = 8;
pub const RSP_SUMMARY_RSP_STATUS_BITS_WIDTH: u32 = 8;
pub const RSP_SUMMARY_RSP_STATUS_BITS_MASK: u64 = 0x000000000000FF00;
pub const RSP_SUMMARY_RSP_DRAG_SUMMARY_SHIFT: u32 = 16;
pub const RSP_SUMMARY_RSP_DRAG_SUMMARY_WIDTH: u32 = 16;
pub const RSP_SUMMARY_RSP_DRAG_SUMMARY_MASK: u64 = 0x00000000FFFF0000;
pub const RSP_SUMMARY_RSP_LIFT_SUMMARY_SHIFT: u32 = 32;
pub const RSP_SUMMARY_RSP_LIFT_SUMMARY_WIDTH: u32 = 16;
pub const RSP_SUMMARY_RSP_LIFT_SUMMARY_MASK: u64 = 0x0000FFFF00000000;
pub const RSP_SUMMARY_RESERVED_SHIFT: u32 = 48;
pub const RSP_SUMMARY_RESERVED_WIDTH: u32 = 16;
pub const RSP_SUMMARY_RESERVED_MASK: u64 = 0xFFFF000000000000;
pub const FAULT_CTRL_OFFSET: usize = 0x00000040;
pub const FAULT_CTRL_CLEAR_ACK_ACCEPT_SHIFT: u32 = 0;
pub const FAULT_CTRL_CLEAR_ACK_ACCEPT_WIDTH: u32 = 1;
pub const FAULT_CTRL_CLEAR_ACK_ACCEPT_MASK: u64 = 0x0000000000000001;
pub const FAULT_CTRL_RESERVED_SHIFT: u32 = 1;
pub const FAULT_CTRL_RESERVED_WIDTH: u32 = 63;
pub const FAULT_CTRL_RESERVED_MASK: u64 = 0xFFFFFFFFFFFFFFFE;

#[inline]
fn reg_ptr(offset: usize) -> *mut u64 {
    (BASE_ADDRESS + offset) as *mut u64
}

#[inline]
fn read_reg(offset: usize) -> u64 {
    unsafe { read_volatile(reg_ptr(offset) as *const u64) }
}

#[inline]
fn write_reg(offset: usize, value: u64) {
    unsafe { write_volatile(reg_ptr(offset), value) }
}

#[inline]
pub fn read_ctrl() -> u64 {
    read_reg(CTRL_OFFSET)
}

#[inline]
pub fn write_ctrl(value: u64) {
    write_reg(CTRL_OFFSET, value)
}

#[inline]
pub fn get_ctrl_enable() -> u64 {
    (read_ctrl() & CTRL_ENABLE_MASK) >> CTRL_ENABLE_SHIFT
}

#[inline]
pub fn set_ctrl_enable(value: u64) {
    let current = read_ctrl();
    let next = (current & !CTRL_ENABLE_MASK) | ((value << CTRL_ENABLE_SHIFT) & CTRL_ENABLE_MASK);
    write_ctrl(next);
}

#[inline]
pub fn get_ctrl_mode() -> u64 {
    (read_ctrl() & CTRL_MODE_MASK) >> CTRL_MODE_SHIFT
}

#[inline]
pub fn set_ctrl_mode(value: u64) {
    let current = read_ctrl();
    let next = (current & !CTRL_MODE_MASK) | ((value << CTRL_MODE_SHIFT) & CTRL_MODE_MASK);
    write_ctrl(next);
}

#[inline]
pub fn get_ctrl_ref_mode() -> u64 {
    (read_ctrl() & CTRL_REF_MODE_MASK) >> CTRL_REF_MODE_SHIFT
}

#[inline]
pub fn set_ctrl_ref_mode(value: u64) {
    let current = read_ctrl();
    let next = (current & !CTRL_REF_MODE_MASK) | ((value << CTRL_REF_MODE_SHIFT) & CTRL_REF_MODE_MASK);
    write_ctrl(next);
}

#[inline]
pub fn get_ctrl_arm_key() -> u64 {
    (read_ctrl() & CTRL_ARM_KEY_MASK) >> CTRL_ARM_KEY_SHIFT
}

#[inline]
pub fn set_ctrl_arm_key(value: u64) {
    let current = read_ctrl();
    let next = (current & !CTRL_ARM_KEY_MASK) | ((value << CTRL_ARM_KEY_SHIFT) & CTRL_ARM_KEY_MASK);
    write_ctrl(next);
}

#[inline]
pub fn get_ctrl_clear_ack() -> u64 {
    (read_ctrl() & CTRL_CLEAR_ACK_MASK) >> CTRL_CLEAR_ACK_SHIFT
}

#[inline]
pub fn set_ctrl_clear_ack(value: u64) {
    let current = read_ctrl();
    let next = (current & !CTRL_CLEAR_ACK_MASK) | ((value << CTRL_CLEAR_ACK_SHIFT) & CTRL_CLEAR_ACK_MASK);
    write_ctrl(next);
}

#[inline]
pub fn get_ctrl_reserved() -> u64 {
    (read_ctrl() & CTRL_RESERVED_MASK) >> CTRL_RESERVED_SHIFT
}

#[inline]
pub fn set_ctrl_reserved(value: u64) {
    let current = read_ctrl();
    let next = (current & !CTRL_RESERVED_MASK) | ((value << CTRL_RESERVED_SHIFT) & CTRL_RESERVED_MASK);
    write_ctrl(next);
}

#[inline]
pub fn read_velocity_bounds() -> u64 {
    read_reg(VELOCITY_BOUNDS_OFFSET)
}

#[inline]
pub fn write_velocity_bounds(value: u64) {
    write_reg(VELOCITY_BOUNDS_OFFSET, value)
}

#[inline]
pub fn get_velocity_bounds_velocity_min() -> u64 {
    (read_velocity_bounds() & VELOCITY_BOUNDS_VELOCITY_MIN_MASK) >> VELOCITY_BOUNDS_VELOCITY_MIN_SHIFT
}

#[inline]
pub fn set_velocity_bounds_velocity_min(value: u64) {
    let current = read_velocity_bounds();
    let next = (current & !VELOCITY_BOUNDS_VELOCITY_MIN_MASK) | ((value << VELOCITY_BOUNDS_VELOCITY_MIN_SHIFT) & VELOCITY_BOUNDS_VELOCITY_MIN_MASK);
    write_velocity_bounds(next);
}

#[inline]
pub fn get_velocity_bounds_velocity_max() -> u64 {
    (read_velocity_bounds() & VELOCITY_BOUNDS_VELOCITY_MAX_MASK) >> VELOCITY_BOUNDS_VELOCITY_MAX_SHIFT
}

#[inline]
pub fn set_velocity_bounds_velocity_max(value: u64) {
    let current = read_velocity_bounds();
    let next = (current & !VELOCITY_BOUNDS_VELOCITY_MAX_MASK) | ((value << VELOCITY_BOUNDS_VELOCITY_MAX_SHIFT) & VELOCITY_BOUNDS_VELOCITY_MAX_MASK);
    write_velocity_bounds(next);
}

#[inline]
pub fn get_velocity_bounds_nominal_velocity() -> u64 {
    (read_velocity_bounds() & VELOCITY_BOUNDS_NOMINAL_VELOCITY_MASK) >> VELOCITY_BOUNDS_NOMINAL_VELOCITY_SHIFT
}

#[inline]
pub fn set_velocity_bounds_nominal_velocity(value: u64) {
    let current = read_velocity_bounds();
    let next = (current & !VELOCITY_BOUNDS_NOMINAL_VELOCITY_MASK) | ((value << VELOCITY_BOUNDS_NOMINAL_VELOCITY_SHIFT) & VELOCITY_BOUNDS_NOMINAL_VELOCITY_MASK);
    write_velocity_bounds(next);
}

#[inline]
pub fn get_velocity_bounds_reserved() -> u64 {
    (read_velocity_bounds() & VELOCITY_BOUNDS_RESERVED_MASK) >> VELOCITY_BOUNDS_RESERVED_SHIFT
}

#[inline]
pub fn set_velocity_bounds_reserved(value: u64) {
    let current = read_velocity_bounds();
    let next = (current & !VELOCITY_BOUNDS_RESERVED_MASK) | ((value << VELOCITY_BOUNDS_RESERVED_SHIFT) & VELOCITY_BOUNDS_RESERVED_MASK);
    write_velocity_bounds(next);
}

#[inline]
pub fn read_timeout_and_limits() -> u64 {
    read_reg(TIMEOUT_AND_LIMITS_OFFSET)
}

#[inline]
pub fn write_timeout_and_limits(value: u64) {
    write_reg(TIMEOUT_AND_LIMITS_OFFSET, value)
}

#[inline]
pub fn get_timeout_and_limits_timeout_cycles() -> u64 {
    (read_timeout_and_limits() & TIMEOUT_AND_LIMITS_TIMEOUT_CYCLES_MASK) >> TIMEOUT_AND_LIMITS_TIMEOUT_CYCLES_SHIFT
}

#[inline]
pub fn set_timeout_and_limits_timeout_cycles(value: u64) {
    let current = read_timeout_and_limits();
    let next = (current & !TIMEOUT_AND_LIMITS_TIMEOUT_CYCLES_MASK) | ((value << TIMEOUT_AND_LIMITS_TIMEOUT_CYCLES_SHIFT) & TIMEOUT_AND_LIMITS_TIMEOUT_CYCLES_MASK);
    write_timeout_and_limits(next);
}

#[inline]
pub fn get_timeout_and_limits_clamp_min() -> u64 {
    (read_timeout_and_limits() & TIMEOUT_AND_LIMITS_CLAMP_MIN_MASK) >> TIMEOUT_AND_LIMITS_CLAMP_MIN_SHIFT
}

#[inline]
pub fn set_timeout_and_limits_clamp_min(value: u64) {
    let current = read_timeout_and_limits();
    let next = (current & !TIMEOUT_AND_LIMITS_CLAMP_MIN_MASK) | ((value << TIMEOUT_AND_LIMITS_CLAMP_MIN_SHIFT) & TIMEOUT_AND_LIMITS_CLAMP_MIN_MASK);
    write_timeout_and_limits(next);
}

#[inline]
pub fn get_timeout_and_limits_clamp_max() -> u64 {
    (read_timeout_and_limits() & TIMEOUT_AND_LIMITS_CLAMP_MAX_MASK) >> TIMEOUT_AND_LIMITS_CLAMP_MAX_SHIFT
}

#[inline]
pub fn set_timeout_and_limits_clamp_max(value: u64) {
    let current = read_timeout_and_limits();
    let next = (current & !TIMEOUT_AND_LIMITS_CLAMP_MAX_MASK) | ((value << TIMEOUT_AND_LIMITS_CLAMP_MAX_SHIFT) & TIMEOUT_AND_LIMITS_CLAMP_MAX_MASK);
    write_timeout_and_limits(next);
}

#[inline]
pub fn get_timeout_and_limits_clamp_rate() -> u64 {
    (read_timeout_and_limits() & TIMEOUT_AND_LIMITS_CLAMP_RATE_MASK) >> TIMEOUT_AND_LIMITS_CLAMP_RATE_SHIFT
}

#[inline]
pub fn set_timeout_and_limits_clamp_rate(value: u64) {
    let current = read_timeout_and_limits();
    let next = (current & !TIMEOUT_AND_LIMITS_CLAMP_RATE_MASK) | ((value << TIMEOUT_AND_LIMITS_CLAMP_RATE_SHIFT) & TIMEOUT_AND_LIMITS_CLAMP_RATE_MASK);
    write_timeout_and_limits(next);
}

#[inline]
pub fn get_timeout_and_limits_req_limit() -> u64 {
    (read_timeout_and_limits() & TIMEOUT_AND_LIMITS_REQ_LIMIT_MASK) >> TIMEOUT_AND_LIMITS_REQ_LIMIT_SHIFT
}

#[inline]
pub fn set_timeout_and_limits_req_limit(value: u64) {
    let current = read_timeout_and_limits();
    let next = (current & !TIMEOUT_AND_LIMITS_REQ_LIMIT_MASK) | ((value << TIMEOUT_AND_LIMITS_REQ_LIMIT_SHIFT) & TIMEOUT_AND_LIMITS_REQ_LIMIT_MASK);
    write_timeout_and_limits(next);
}

#[inline]
pub fn read_geometry_and_ref() -> u64 {
    read_reg(GEOMETRY_AND_REF_OFFSET)
}

#[inline]
pub fn write_geometry_and_ref(value: u64) {
    write_reg(GEOMETRY_AND_REF_OFFSET, value)
}

#[inline]
pub fn get_geometry_and_ref_geometry_token() -> u64 {
    (read_geometry_and_ref() & GEOMETRY_AND_REF_GEOMETRY_TOKEN_MASK) >> GEOMETRY_AND_REF_GEOMETRY_TOKEN_SHIFT
}

#[inline]
pub fn set_geometry_and_ref_geometry_token(value: u64) {
    let current = read_geometry_and_ref();
    let next = (current & !GEOMETRY_AND_REF_GEOMETRY_TOKEN_MASK) | ((value << GEOMETRY_AND_REF_GEOMETRY_TOKEN_SHIFT) & GEOMETRY_AND_REF_GEOMETRY_TOKEN_MASK);
    write_geometry_and_ref(next);
}

#[inline]
pub fn get_geometry_and_ref_ref_cmd() -> u64 {
    (read_geometry_and_ref() & GEOMETRY_AND_REF_REF_CMD_MASK) >> GEOMETRY_AND_REF_REF_CMD_SHIFT
}

#[inline]
pub fn set_geometry_and_ref_ref_cmd(value: u64) {
    let current = read_geometry_and_ref();
    let next = (current & !GEOMETRY_AND_REF_REF_CMD_MASK) | ((value << GEOMETRY_AND_REF_REF_CMD_SHIFT) & GEOMETRY_AND_REF_REF_CMD_MASK);
    write_geometry_and_ref(next);
}

#[inline]
pub fn get_geometry_and_ref_fault_clear_pattern() -> u64 {
    (read_geometry_and_ref() & GEOMETRY_AND_REF_FAULT_CLEAR_PATTERN_MASK) >> GEOMETRY_AND_REF_FAULT_CLEAR_PATTERN_SHIFT
}

#[inline]
pub fn set_geometry_and_ref_fault_clear_pattern(value: u64) {
    let current = read_geometry_and_ref();
    let next = (current & !GEOMETRY_AND_REF_FAULT_CLEAR_PATTERN_MASK) | ((value << GEOMETRY_AND_REF_FAULT_CLEAR_PATTERN_SHIFT) & GEOMETRY_AND_REF_FAULT_CLEAR_PATTERN_MASK);
    write_geometry_and_ref(next);
}

#[inline]
pub fn get_geometry_and_ref_rearm_key_shadow() -> u64 {
    (read_geometry_and_ref() & GEOMETRY_AND_REF_REARM_KEY_SHADOW_MASK) >> GEOMETRY_AND_REF_REARM_KEY_SHADOW_SHIFT
}

#[inline]
pub fn set_geometry_and_ref_rearm_key_shadow(value: u64) {
    let current = read_geometry_and_ref();
    let next = (current & !GEOMETRY_AND_REF_REARM_KEY_SHADOW_MASK) | ((value << GEOMETRY_AND_REF_REARM_KEY_SHADOW_SHIFT) & GEOMETRY_AND_REF_REARM_KEY_SHADOW_MASK);
    write_geometry_and_ref(next);
}

#[inline]
pub fn get_geometry_and_ref_reserved() -> u64 {
    (read_geometry_and_ref() & GEOMETRY_AND_REF_RESERVED_MASK) >> GEOMETRY_AND_REF_RESERVED_SHIFT
}

#[inline]
pub fn set_geometry_and_ref_reserved(value: u64) {
    let current = read_geometry_and_ref();
    let next = (current & !GEOMETRY_AND_REF_RESERVED_MASK) | ((value << GEOMETRY_AND_REF_RESERVED_SHIFT) & GEOMETRY_AND_REF_RESERVED_MASK);
    write_geometry_and_ref(next);
}

#[inline]
pub fn read_status() -> u64 {
    read_reg(STATUS_OFFSET)
}

#[inline]
pub fn get_status_seq_issued() -> u64 {
    (read_status() & STATUS_SEQ_ISSUED_MASK) >> STATUS_SEQ_ISSUED_SHIFT
}

#[inline]
pub fn get_status_seq_accepted() -> u64 {
    (read_status() & STATUS_SEQ_ACCEPTED_MASK) >> STATUS_SEQ_ACCEPTED_SHIFT
}

#[inline]
pub fn get_status_fault_latched() -> u64 {
    (read_status() & STATUS_FAULT_LATCHED_MASK) >> STATUS_FAULT_LATCHED_SHIFT
}

#[inline]
pub fn get_status_state_bits() -> u64 {
    (read_status() & STATUS_STATE_BITS_MASK) >> STATUS_STATE_BITS_SHIFT
}

#[inline]
pub fn get_status_cfg_valid() -> u64 {
    (read_status() & STATUS_CFG_VALID_MASK) >> STATUS_CFG_VALID_SHIFT
}

#[inline]
pub fn get_status_enable_gate_ok() -> u64 {
    (read_status() & STATUS_ENABLE_GATE_OK_MASK) >> STATUS_ENABLE_GATE_OK_SHIFT
}

#[inline]
pub fn get_status_reserved() -> u64 {
    (read_status() & STATUS_RESERVED_MASK) >> STATUS_RESERVED_SHIFT
}

#[inline]
pub fn read_req_frame_low() -> u64 {
    read_reg(REQ_FRAME_LOW_OFFSET)
}

#[inline]
pub fn get_req_frame_low_req_frame_low() -> u64 {
    (read_req_frame_low() & REQ_FRAME_LOW_REQ_FRAME_LOW_MASK) >> REQ_FRAME_LOW_REQ_FRAME_LOW_SHIFT
}

#[inline]
pub fn read_req_frame_high() -> u64 {
    read_reg(REQ_FRAME_HIGH_OFFSET)
}

#[inline]
pub fn get_req_frame_high_req_frame_high() -> u64 {
    (read_req_frame_high() & REQ_FRAME_HIGH_REQ_FRAME_HIGH_MASK) >> REQ_FRAME_HIGH_REQ_FRAME_HIGH_SHIFT
}

#[inline]
pub fn read_rsp_summary() -> u64 {
    read_reg(RSP_SUMMARY_OFFSET)
}

#[inline]
pub fn get_rsp_summary_rsp_seq_echo() -> u64 {
    (read_rsp_summary() & RSP_SUMMARY_RSP_SEQ_ECHO_MASK) >> RSP_SUMMARY_RSP_SEQ_ECHO_SHIFT
}

#[inline]
pub fn get_rsp_summary_rsp_status_bits() -> u64 {
    (read_rsp_summary() & RSP_SUMMARY_RSP_STATUS_BITS_MASK) >> RSP_SUMMARY_RSP_STATUS_BITS_SHIFT
}

#[inline]
pub fn get_rsp_summary_rsp_drag_summary() -> u64 {
    (read_rsp_summary() & RSP_SUMMARY_RSP_DRAG_SUMMARY_MASK) >> RSP_SUMMARY_RSP_DRAG_SUMMARY_SHIFT
}

#[inline]
pub fn get_rsp_summary_rsp_lift_summary() -> u64 {
    (read_rsp_summary() & RSP_SUMMARY_RSP_LIFT_SUMMARY_MASK) >> RSP_SUMMARY_RSP_LIFT_SUMMARY_SHIFT
}

#[inline]
pub fn get_rsp_summary_reserved() -> u64 {
    (read_rsp_summary() & RSP_SUMMARY_RESERVED_MASK) >> RSP_SUMMARY_RESERVED_SHIFT
}

#[inline]
pub fn read_fault_ctrl() -> u64 {
    read_reg(FAULT_CTRL_OFFSET)
}

#[inline]
pub fn write_fault_ctrl(value: u64) {
    write_reg(FAULT_CTRL_OFFSET, value)
}

#[inline]
pub fn get_fault_ctrl_clear_ack_accept() -> u64 {
    (read_fault_ctrl() & FAULT_CTRL_CLEAR_ACK_ACCEPT_MASK) >> FAULT_CTRL_CLEAR_ACK_ACCEPT_SHIFT
}

#[inline]
pub fn set_fault_ctrl_clear_ack_accept(value: u64) {
    let current = read_fault_ctrl();
    let next = (current & !FAULT_CTRL_CLEAR_ACK_ACCEPT_MASK) | ((value << FAULT_CTRL_CLEAR_ACK_ACCEPT_SHIFT) & FAULT_CTRL_CLEAR_ACK_ACCEPT_MASK);
    write_fault_ctrl(next);
}

#[inline]
pub fn get_fault_ctrl_reserved() -> u64 {
    (read_fault_ctrl() & FAULT_CTRL_RESERVED_MASK) >> FAULT_CTRL_RESERVED_SHIFT
}

#[inline]
pub fn set_fault_ctrl_reserved(value: u64) {
    let current = read_fault_ctrl();
    let next = (current & !FAULT_CTRL_RESERVED_MASK) | ((value << FAULT_CTRL_RESERVED_SHIFT) & FAULT_CTRL_RESERVED_MASK);
    write_fault_ctrl(next);
}

