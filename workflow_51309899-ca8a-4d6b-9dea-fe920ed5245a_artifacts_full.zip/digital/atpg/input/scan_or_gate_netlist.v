module temp_monitor_soc_phys (alert_irq,
    alert_status,
    avdd,
    avss,
    clk,
    rd_en,
    reset_n,
    scan_en,
    wr_en,
    rd_addr,
    rd_data,
    scan_in,
    scan_out,
    sensor_temp_celsius,
    temp_code,
    threshold_code,
    wr_addr,
    wr_data);
 output alert_irq;
 output alert_status;
 input avdd;
 input avss;
 input clk;
 input rd_en;
 input reset_n;
 input scan_en;
 input wr_en;
 input [7:0] rd_addr;
 output [15:0] rd_data;
 input [3:0] scan_in;
 output [3:0] scan_out;
 input [15:0] sensor_temp_celsius;
 output [11:0] temp_code;
 output [11:0] threshold_code;
 input [7:0] wr_addr;
 input [15:0] wr_data;

 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire _086_;
 wire _087_;
 wire _088_;
 wire _089_;
 wire _090_;
 wire _091_;
 wire _092_;
 wire _093_;
 wire _094_;
 wire _095_;
 wire _096_;
 wire _097_;
 wire _098_;
 wire _099_;
 wire _100_;
 wire _101_;
 wire _102_;
 wire _103_;
 wire _104_;
 wire _105_;
 wire _106_;
 wire _107_;
 wire _108_;
 wire _109_;
 wire _110_;
 wire _111_;
 wire _112_;
 wire _113_;
 wire _114_;
 wire _115_;
 wire _116_;
 wire _117_;
 wire _118_;
 wire _119_;
 wire _120_;
 wire _121_;
 wire _122_;
 wire _123_;
 wire _124_;
 wire _125_;
 wire _126_;
 wire _127_;
 wire _128_;
 wire _129_;
 wire _130_;
 wire _131_;
 wire _132_;
 wire _133_;
 wire _134_;
 wire _135_;
 wire _136_;
 wire _137_;
 wire _138_;
 wire _139_;
 wire _140_;
 wire _141_;
 wire _142_;
 wire _143_;
 wire _144_;
 wire _145_;
 wire _146_;
 wire _147_;
 wire _148_;
 wire _149_;
 wire _150_;
 wire _151_;
 wire _152_;
 wire _153_;
 wire _154_;
 wire _155_;
 wire _156_;
 wire _157_;
 wire _158_;
 wire _159_;
 wire _160_;
 wire _161_;
 wire _162_;
 wire _163_;
 wire _164_;
 wire _165_;
 wire _166_;
 wire _167_;
 wire _168_;
 wire _169_;
 wire _170_;
 wire _171_;
 wire _172_;
 wire _173_;
 wire _174_;
 wire _175_;
 wire _176_;
 wire _177_;
 wire _178_;
 wire _179_;
 wire _180_;
 wire _181_;
 wire _182_;
 wire _183_;
 wire _184_;
 wire _185_;
 wire _186_;
 wire _187_;
 wire _188_;
 wire _189_;
 wire _190_;
 wire _191_;
 wire _192_;
 wire _193_;
 wire _194_;
 wire _195_;
 wire _196_;
 wire _197_;
 wire _198_;
 wire _199_;
 wire _200_;
 wire _201_;
 wire _202_;
 wire _203_;
 wire _204_;
 wire _205_;
 wire _206_;
 wire _207_;
 wire _208_;
 wire _209_;
 wire _210_;
 wire _211_;
 wire _212_;
 wire _213_;
 wire _214_;
 wire _215_;
 wire _216_;
 wire _217_;
 wire _218_;
 wire _219_;
 wire _220_;
 wire _221_;
 wire _222_;
 wire _223_;
 wire _224_;
 wire _225_;
 wire _226_;
 wire _227_;
 wire _228_;
 wire _229_;
 wire _230_;
 wire _231_;
 wire _232_;
 wire _233_;
 wire _234_;
 wire _235_;
 wire _236_;
 wire _237_;
 wire _238_;
 wire _239_;
 wire _240_;
 wire _241_;
 wire _242_;
 wire _243_;
 wire _244_;
 wire _245_;
 wire _246_;
 wire _247_;
 wire _248_;
 wire _249_;
 wire _250_;
 wire _251_;
 wire _252_;
 wire _253_;
 wire _254_;
 wire _255_;
 wire _256_;
 wire \u_digital.adc_code[0] ;
 wire \u_digital.adc_code[10] ;
 wire \u_digital.adc_code[11] ;
 wire \u_digital.adc_code[1] ;
 wire \u_digital.adc_code[2] ;
 wire \u_digital.adc_code[3] ;
 wire \u_digital.adc_code[4] ;
 wire \u_digital.adc_code[5] ;
 wire \u_digital.adc_code[6] ;
 wire \u_digital.adc_code[7] ;
 wire \u_digital.adc_code[8] ;
 wire \u_digital.adc_code[9] ;
 wire \u_digital.adc_valid ;
 wire \u_digital.alert_irq_next ;
 wire \u_digital.alert_status_next ;
 wire \u_digital.enable_reg ;
 wire \u_digital.enable_reg_next ;
 wire \u_digital.irq_enable_reg ;
 wire \u_digital.irq_enable_reg_next ;
 wire \u_digital.irq_status_alert ;
 wire \u_digital.irq_status_alert_next ;
 wire \u_digital.irq_status_sample_done ;
 wire \u_digital.irq_status_sample_done_next ;
 wire \u_digital.prev_sample[0] ;
 wire \u_digital.prev_sample[10] ;
 wire \u_digital.prev_sample[11] ;
 wire \u_digital.prev_sample[1] ;
 wire \u_digital.prev_sample[2] ;
 wire \u_digital.prev_sample[3] ;
 wire \u_digital.prev_sample[4] ;
 wire \u_digital.prev_sample[5] ;
 wire \u_digital.prev_sample[6] ;
 wire \u_digital.prev_sample[7] ;
 wire \u_digital.prev_sample[8] ;
 wire \u_digital.prev_sample[9] ;
 wire \u_digital.prev_sample_valid ;
 wire \u_digital.read_data_next[0] ;
 wire \u_digital.read_data_next[10] ;
 wire \u_digital.read_data_next[11] ;
 wire \u_digital.read_data_next[12] ;
 wire \u_digital.read_data_next[13] ;
 wire \u_digital.read_data_next[14] ;
 wire \u_digital.read_data_next[15] ;
 wire \u_digital.read_data_next[1] ;
 wire \u_digital.read_data_next[2] ;
 wire \u_digital.read_data_next[3] ;
 wire \u_digital.read_data_next[4] ;
 wire \u_digital.read_data_next[5] ;
 wire \u_digital.read_data_next[6] ;
 wire \u_digital.read_data_next[7] ;
 wire \u_digital.read_data_next[8] ;
 wire \u_digital.read_data_next[9] ;
 wire \u_digital.sample_count[0] ;
 wire \u_digital.sample_count[10] ;
 wire \u_digital.sample_count[11] ;
 wire \u_digital.sample_count[12] ;
 wire \u_digital.sample_count[13] ;
 wire \u_digital.sample_count[14] ;
 wire \u_digital.sample_count[15] ;
 wire \u_digital.sample_count[1] ;
 wire \u_digital.sample_count[2] ;
 wire \u_digital.sample_count[3] ;
 wire \u_digital.sample_count[4] ;
 wire \u_digital.sample_count[5] ;
 wire \u_digital.sample_count[6] ;
 wire \u_digital.sample_count[7] ;
 wire \u_digital.sample_count[8] ;
 wire \u_digital.sample_count[9] ;
 wire \u_digital.sample_req ;
 wire \u_digital.sample_req_next ;
 wire \u_digital.sample_req_pending ;
 wire \u_digital.sample_req_pending_next ;
 wire \u_digital.status_alert_pending ;
 wire \u_digital.status_alert_pending_next ;
 wire \u_digital.status_busy ;
 wire \u_digital.status_sample_done ;
 wire \u_digital.status_sample_done_next ;
 wire \u_digital.threshold_code_next[0] ;
 wire \u_digital.threshold_code_next[10] ;
 wire \u_digital.threshold_code_next[11] ;
 wire \u_digital.threshold_code_next[1] ;
 wire \u_digital.threshold_code_next[2] ;
 wire \u_digital.threshold_code_next[3] ;
 wire \u_digital.threshold_code_next[4] ;
 wire \u_digital.threshold_code_next[5] ;
 wire \u_digital.threshold_code_next[6] ;
 wire \u_digital.threshold_code_next[7] ;
 wire \u_digital.threshold_code_next[8] ;
 wire \u_digital.threshold_code_next[9] ;

 sky130_fd_sc_hd__inv_2 _257_ (.A(wr_data[1]),
    .Y(_042_));
 sky130_fd_sc_hd__inv_2 _258_ (.A(wr_en),
    .Y(_043_));
 sky130_fd_sc_hd__inv_2 _259_ (.A(rd_addr[3]),
    .Y(_044_));
 sky130_fd_sc_hd__inv_2 _260_ (.A(\u_digital.prev_sample_valid ),
    .Y(_045_));
 sky130_fd_sc_hd__inv_2 _261_ (.A(\u_digital.adc_code[4] ),
    .Y(_046_));
 sky130_fd_sc_hd__or4_2 _262_ (.A(wr_addr[5]),
    .B(wr_addr[4]),
    .C(wr_addr[7]),
    .D(wr_addr[6]),
    .X(_047_));
 sky130_fd_sc_hd__or4_2 _263_ (.A(wr_addr[1]),
    .B(wr_addr[0]),
    .C(wr_addr[2]),
    .D(wr_addr[3]),
    .X(_048_));
 sky130_fd_sc_hd__nor2_2 _264_ (.A(_047_),
    .B(_048_),
    .Y(_049_));
 sky130_fd_sc_hd__nand2_2 _265_ (.A(wr_en),
    .B(_049_),
    .Y(_050_));
 sky130_fd_sc_hd__mux2_1 _266_ (.A0(wr_data[0]),
    .A1(\u_digital.enable_reg ),
    .S(_050_),
    .X(\u_digital.enable_reg_next ));
 sky130_fd_sc_hd__mux2_1 _267_ (.A0(wr_data[2]),
    .A1(\u_digital.irq_enable_reg ),
    .S(_050_),
    .X(\u_digital.irq_enable_reg_next ));
 sky130_fd_sc_hd__or4b_2 _268_ (.A(wr_addr[1]),
    .B(wr_addr[0]),
    .C(wr_addr[2]),
    .D_N(wr_addr[3]),
    .X(_051_));
 sky130_fd_sc_hd__or3_2 _269_ (.A(_043_),
    .B(_047_),
    .C(_051_),
    .X(_052_));
 sky130_fd_sc_hd__mux2_1 _270_ (.A0(wr_data[0]),
    .A1(threshold_code[0]),
    .S(_052_),
    .X(\u_digital.threshold_code_next[0] ));
 sky130_fd_sc_hd__mux2_1 _271_ (.A0(wr_data[1]),
    .A1(threshold_code[1]),
    .S(_052_),
    .X(\u_digital.threshold_code_next[1] ));
 sky130_fd_sc_hd__mux2_1 _272_ (.A0(wr_data[2]),
    .A1(threshold_code[2]),
    .S(_052_),
    .X(\u_digital.threshold_code_next[2] ));
 sky130_fd_sc_hd__inv_2 _273_ (.A(\u_digital.threshold_code_next[2] ),
    .Y(_053_));
 sky130_fd_sc_hd__mux2_1 _274_ (.A0(wr_data[3]),
    .A1(threshold_code[3]),
    .S(_052_),
    .X(\u_digital.threshold_code_next[3] ));
 sky130_fd_sc_hd__mux2_1 _275_ (.A0(wr_data[4]),
    .A1(threshold_code[4]),
    .S(_052_),
    .X(\u_digital.threshold_code_next[4] ));
 sky130_fd_sc_hd__mux2_1 _276_ (.A0(wr_data[5]),
    .A1(threshold_code[5]),
    .S(_052_),
    .X(\u_digital.threshold_code_next[5] ));
 sky130_fd_sc_hd__mux2_1 _277_ (.A0(wr_data[6]),
    .A1(threshold_code[6]),
    .S(_052_),
    .X(\u_digital.threshold_code_next[6] ));
 sky130_fd_sc_hd__inv_2 _278_ (.A(\u_digital.threshold_code_next[6] ),
    .Y(_054_));
 sky130_fd_sc_hd__mux2_1 _279_ (.A0(wr_data[7]),
    .A1(threshold_code[7]),
    .S(_052_),
    .X(\u_digital.threshold_code_next[7] ));
 sky130_fd_sc_hd__mux2_1 _280_ (.A0(wr_data[8]),
    .A1(threshold_code[8]),
    .S(_052_),
    .X(\u_digital.threshold_code_next[8] ));
 sky130_fd_sc_hd__mux2_1 _281_ (.A0(wr_data[9]),
    .A1(threshold_code[9]),
    .S(_052_),
    .X(\u_digital.threshold_code_next[9] ));
 sky130_fd_sc_hd__inv_2 _282_ (.A(\u_digital.threshold_code_next[9] ),
    .Y(_055_));
 sky130_fd_sc_hd__mux2_1 _283_ (.A0(wr_data[10]),
    .A1(threshold_code[10]),
    .S(_052_),
    .X(\u_digital.threshold_code_next[10] ));
 sky130_fd_sc_hd__inv_2 _284_ (.A(\u_digital.threshold_code_next[10] ),
    .Y(_056_));
 sky130_fd_sc_hd__mux2_1 _285_ (.A0(wr_data[11]),
    .A1(threshold_code[11]),
    .S(_052_),
    .X(\u_digital.threshold_code_next[11] ));
 sky130_fd_sc_hd__or4_2 _286_ (.A(rd_addr[5]),
    .B(rd_addr[4]),
    .C(rd_addr[7]),
    .D(rd_addr[6]),
    .X(_057_));
 sky130_fd_sc_hd__or2_2 _287_ (.A(_044_),
    .B(_057_),
    .X(_058_));
 sky130_fd_sc_hd__nor4_2 _288_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .C(rd_addr[2]),
    .D(_058_),
    .Y(_059_));
 sky130_fd_sc_hd__or3b_2 _289_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .C_N(rd_addr[2]),
    .X(_060_));
 sky130_fd_sc_hd__nor2_2 _290_ (.A(_058_),
    .B(_060_),
    .Y(_061_));
 sky130_fd_sc_hd__or4b_2 _291_ (.A(rd_addr[5]),
    .B(rd_addr[7]),
    .C(rd_addr[6]),
    .D_N(rd_addr[4]),
    .X(_062_));
 sky130_fd_sc_hd__or4_2 _292_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .C(rd_addr[3]),
    .D(rd_addr[2]),
    .X(_063_));
 sky130_fd_sc_hd__nor2_2 _293_ (.A(_062_),
    .B(_063_),
    .Y(_064_));
 sky130_fd_sc_hd__a22o_2 _294_ (.A1(temp_code[0]),
    .A2(_061_),
    .B1(_064_),
    .B2(\u_digital.sample_count[0] ),
    .X(_065_));
 sky130_fd_sc_hd__or2_2 _295_ (.A(rd_addr[3]),
    .B(_060_),
    .X(_066_));
 sky130_fd_sc_hd__nor2_2 _296_ (.A(_057_),
    .B(_066_),
    .Y(_067_));
 sky130_fd_sc_hd__or4b_2 _297_ (.A(wr_addr[5]),
    .B(wr_addr[7]),
    .C(wr_addr[6]),
    .D_N(wr_addr[4]),
    .X(_068_));
 sky130_fd_sc_hd__nor2_2 _298_ (.A(_051_),
    .B(_068_),
    .Y(_069_));
 sky130_fd_sc_hd__and2_2 _299_ (.A(wr_en),
    .B(_069_),
    .X(_070_));
 sky130_fd_sc_hd__nand2_2 _300_ (.A(wr_data[1]),
    .B(_070_),
    .Y(_071_));
 sky130_fd_sc_hd__a21boi_2 _301_ (.A1(wr_data[0]),
    .A2(_070_),
    .B1_N(\u_digital.irq_status_alert ),
    .Y(_072_));
 sky130_fd_sc_hd__nor2_2 _302_ (.A(_062_),
    .B(_066_),
    .Y(_073_));
 sky130_fd_sc_hd__and2_2 _303_ (.A(_072_),
    .B(_073_),
    .X(_074_));
 sky130_fd_sc_hd__a32o_2 _304_ (.A1(\u_digital.status_sample_done ),
    .A2(_067_),
    .A3(_071_),
    .B1(\u_digital.threshold_code_next[0] ),
    .B2(_059_),
    .X(_075_));
 sky130_fd_sc_hd__o31a_2 _305_ (.A1(_065_),
    .A2(_074_),
    .A3(_075_),
    .B1(rd_en),
    .X(\u_digital.read_data_next[0] ));
 sky130_fd_sc_hd__mux2_1 _306_ (.A0(_049_),
    .A1(wr_data[0]),
    .S(_069_),
    .X(_076_));
 sky130_fd_sc_hd__o311a_2 _307_ (.A1(wr_data[3]),
    .A2(_047_),
    .A3(_048_),
    .B1(_076_),
    .C1(wr_en),
    .X(_077_));
 sky130_fd_sc_hd__inv_2 _308_ (.A(_077_),
    .Y(_078_));
 sky130_fd_sc_hd__and2_2 _309_ (.A(\u_digital.status_alert_pending ),
    .B(_078_),
    .X(_079_));
 sky130_fd_sc_hd__and2_2 _310_ (.A(\u_digital.irq_status_sample_done ),
    .B(_071_),
    .X(_080_));
 sky130_fd_sc_hd__nor2_2 _311_ (.A(_057_),
    .B(_063_),
    .Y(_081_));
 sky130_fd_sc_hd__a22o_2 _312_ (.A1(_073_),
    .A2(_080_),
    .B1(_081_),
    .B2(\u_digital.irq_enable_reg_next ),
    .X(_082_));
 sky130_fd_sc_hd__a221o_2 _313_ (.A1(temp_code[1]),
    .A2(_061_),
    .B1(_064_),
    .B2(\u_digital.sample_count[1] ),
    .C1(_082_),
    .X(_083_));
 sky130_fd_sc_hd__a22o_2 _314_ (.A1(\u_digital.threshold_code_next[1] ),
    .A2(_059_),
    .B1(_067_),
    .B2(_079_),
    .X(_084_));
 sky130_fd_sc_hd__o21a_2 _315_ (.A1(_083_),
    .A2(_084_),
    .B1(rd_en),
    .X(\u_digital.read_data_next[1] ));
 sky130_fd_sc_hd__a22o_2 _316_ (.A1(temp_code[2]),
    .A2(_061_),
    .B1(_067_),
    .B2(\u_digital.prev_sample_valid ),
    .X(_085_));
 sky130_fd_sc_hd__a22o_2 _317_ (.A1(\u_digital.threshold_code_next[2] ),
    .A2(_059_),
    .B1(_064_),
    .B2(\u_digital.sample_count[2] ),
    .X(_086_));
 sky130_fd_sc_hd__o21a_2 _318_ (.A1(_085_),
    .A2(_086_),
    .B1(rd_en),
    .X(\u_digital.read_data_next[2] ));
 sky130_fd_sc_hd__and2_2 _319_ (.A(\u_digital.enable_reg_next ),
    .B(_081_),
    .X(_087_));
 sky130_fd_sc_hd__a22o_2 _320_ (.A1(\u_digital.sample_count[3] ),
    .A2(_064_),
    .B1(_067_),
    .B2(\u_digital.status_busy ),
    .X(_088_));
 sky130_fd_sc_hd__a221o_2 _321_ (.A1(\u_digital.threshold_code_next[3] ),
    .A2(_059_),
    .B1(_061_),
    .B2(temp_code[3]),
    .C1(_088_),
    .X(_089_));
 sky130_fd_sc_hd__o21a_2 _322_ (.A1(_087_),
    .A2(_089_),
    .B1(rd_en),
    .X(\u_digital.read_data_next[3] ));
 sky130_fd_sc_hd__and2_2 _323_ (.A(temp_code[4]),
    .B(_061_),
    .X(_090_));
 sky130_fd_sc_hd__a22o_2 _324_ (.A1(\u_digital.threshold_code_next[4] ),
    .A2(_059_),
    .B1(_064_),
    .B2(\u_digital.sample_count[4] ),
    .X(_091_));
 sky130_fd_sc_hd__o21a_2 _325_ (.A1(_090_),
    .A2(_091_),
    .B1(rd_en),
    .X(\u_digital.read_data_next[4] ));
 sky130_fd_sc_hd__and2_2 _326_ (.A(temp_code[5]),
    .B(_061_),
    .X(_092_));
 sky130_fd_sc_hd__a22o_2 _327_ (.A1(\u_digital.threshold_code_next[5] ),
    .A2(_059_),
    .B1(_064_),
    .B2(\u_digital.sample_count[5] ),
    .X(_093_));
 sky130_fd_sc_hd__o21a_2 _328_ (.A1(_092_),
    .A2(_093_),
    .B1(rd_en),
    .X(\u_digital.read_data_next[5] ));
 sky130_fd_sc_hd__and2_2 _329_ (.A(temp_code[6]),
    .B(_061_),
    .X(_094_));
 sky130_fd_sc_hd__a22o_2 _330_ (.A1(\u_digital.threshold_code_next[6] ),
    .A2(_059_),
    .B1(_064_),
    .B2(\u_digital.sample_count[6] ),
    .X(_095_));
 sky130_fd_sc_hd__o21a_2 _331_ (.A1(_094_),
    .A2(_095_),
    .B1(rd_en),
    .X(\u_digital.read_data_next[6] ));
 sky130_fd_sc_hd__and2_2 _332_ (.A(temp_code[7]),
    .B(_061_),
    .X(_096_));
 sky130_fd_sc_hd__a22o_2 _333_ (.A1(\u_digital.threshold_code_next[7] ),
    .A2(_059_),
    .B1(_064_),
    .B2(\u_digital.sample_count[7] ),
    .X(_097_));
 sky130_fd_sc_hd__o21a_2 _334_ (.A1(_096_),
    .A2(_097_),
    .B1(rd_en),
    .X(\u_digital.read_data_next[7] ));
 sky130_fd_sc_hd__and2_2 _335_ (.A(temp_code[8]),
    .B(_061_),
    .X(_098_));
 sky130_fd_sc_hd__a22o_2 _336_ (.A1(\u_digital.threshold_code_next[8] ),
    .A2(_059_),
    .B1(_064_),
    .B2(\u_digital.sample_count[8] ),
    .X(_099_));
 sky130_fd_sc_hd__o21a_2 _337_ (.A1(_098_),
    .A2(_099_),
    .B1(rd_en),
    .X(\u_digital.read_data_next[8] ));
 sky130_fd_sc_hd__and2_2 _338_ (.A(temp_code[9]),
    .B(_061_),
    .X(_100_));
 sky130_fd_sc_hd__a22o_2 _339_ (.A1(\u_digital.threshold_code_next[9] ),
    .A2(_059_),
    .B1(_064_),
    .B2(\u_digital.sample_count[9] ),
    .X(_101_));
 sky130_fd_sc_hd__o21a_2 _340_ (.A1(_100_),
    .A2(_101_),
    .B1(rd_en),
    .X(\u_digital.read_data_next[9] ));
 sky130_fd_sc_hd__and2_2 _341_ (.A(temp_code[10]),
    .B(_061_),
    .X(_102_));
 sky130_fd_sc_hd__a22o_2 _342_ (.A1(\u_digital.threshold_code_next[10] ),
    .A2(_059_),
    .B1(_064_),
    .B2(\u_digital.sample_count[10] ),
    .X(_103_));
 sky130_fd_sc_hd__o21a_2 _343_ (.A1(_102_),
    .A2(_103_),
    .B1(rd_en),
    .X(\u_digital.read_data_next[10] ));
 sky130_fd_sc_hd__and2_2 _344_ (.A(temp_code[11]),
    .B(_061_),
    .X(_104_));
 sky130_fd_sc_hd__a22o_2 _345_ (.A1(\u_digital.threshold_code_next[11] ),
    .A2(_059_),
    .B1(_064_),
    .B2(\u_digital.sample_count[11] ),
    .X(_105_));
 sky130_fd_sc_hd__o21a_2 _346_ (.A1(_104_),
    .A2(_105_),
    .B1(rd_en),
    .X(\u_digital.read_data_next[11] ));
 sky130_fd_sc_hd__and3_2 _347_ (.A(rd_en),
    .B(\u_digital.sample_count[12] ),
    .C(_064_),
    .X(\u_digital.read_data_next[12] ));
 sky130_fd_sc_hd__and3_2 _348_ (.A(rd_en),
    .B(\u_digital.sample_count[13] ),
    .C(_064_),
    .X(\u_digital.read_data_next[13] ));
 sky130_fd_sc_hd__and3_2 _349_ (.A(rd_en),
    .B(\u_digital.sample_count[14] ),
    .C(_064_),
    .X(\u_digital.read_data_next[14] ));
 sky130_fd_sc_hd__and3_2 _350_ (.A(rd_en),
    .B(\u_digital.sample_count[15] ),
    .C(_064_),
    .X(\u_digital.read_data_next[15] ));
 sky130_fd_sc_hd__or2_2 _351_ (.A(\u_digital.prev_sample_valid ),
    .B(\u_digital.adc_code[10] ),
    .X(_106_));
 sky130_fd_sc_hd__nand2_2 _352_ (.A(\u_digital.adc_code[10] ),
    .B(\u_digital.prev_sample[10] ),
    .Y(_107_));
 sky130_fd_sc_hd__or2_2 _353_ (.A(\u_digital.adc_code[10] ),
    .B(\u_digital.prev_sample[10] ),
    .X(_108_));
 sky130_fd_sc_hd__or2_2 _354_ (.A(\u_digital.prev_sample[9] ),
    .B(\u_digital.adc_code[9] ),
    .X(_109_));
 sky130_fd_sc_hd__and2_2 _355_ (.A(\u_digital.prev_sample[8] ),
    .B(\u_digital.adc_code[8] ),
    .X(_110_));
 sky130_fd_sc_hd__nor2_2 _356_ (.A(\u_digital.prev_sample[8] ),
    .B(\u_digital.adc_code[8] ),
    .Y(_111_));
 sky130_fd_sc_hd__or2_2 _357_ (.A(_110_),
    .B(_111_),
    .X(_112_));
 sky130_fd_sc_hd__and2_2 _358_ (.A(\u_digital.prev_sample[4] ),
    .B(\u_digital.adc_code[4] ),
    .X(_113_));
 sky130_fd_sc_hd__nor2_2 _359_ (.A(\u_digital.prev_sample[4] ),
    .B(\u_digital.adc_code[4] ),
    .Y(_114_));
 sky130_fd_sc_hd__nor2_2 _360_ (.A(_113_),
    .B(_114_),
    .Y(_115_));
 sky130_fd_sc_hd__or2_2 _361_ (.A(\u_digital.prev_sample[3] ),
    .B(\u_digital.adc_code[3] ),
    .X(_116_));
 sky130_fd_sc_hd__and2_2 _362_ (.A(\u_digital.prev_sample[2] ),
    .B(\u_digital.adc_code[2] ),
    .X(_117_));
 sky130_fd_sc_hd__or2_2 _363_ (.A(\u_digital.prev_sample[2] ),
    .B(\u_digital.adc_code[2] ),
    .X(_118_));
 sky130_fd_sc_hd__and2b_2 _364_ (.A_N(_117_),
    .B(_118_),
    .X(_119_));
 sky130_fd_sc_hd__and2_2 _365_ (.A(\u_digital.prev_sample[1] ),
    .B(\u_digital.adc_code[1] ),
    .X(_120_));
 sky130_fd_sc_hd__nand2_2 _366_ (.A(\u_digital.prev_sample[1] ),
    .B(\u_digital.adc_code[1] ),
    .Y(_121_));
 sky130_fd_sc_hd__or2_2 _367_ (.A(\u_digital.prev_sample[1] ),
    .B(\u_digital.adc_code[1] ),
    .X(_122_));
 sky130_fd_sc_hd__a31o_2 _368_ (.A1(\u_digital.prev_sample[0] ),
    .A2(\u_digital.adc_code[0] ),
    .A3(_122_),
    .B1(_120_),
    .X(_123_));
 sky130_fd_sc_hd__nand2_2 _369_ (.A(\u_digital.prev_sample[3] ),
    .B(\u_digital.adc_code[3] ),
    .Y(_124_));
 sky130_fd_sc_hd__a221o_2 _370_ (.A1(\u_digital.prev_sample[3] ),
    .A2(\u_digital.adc_code[3] ),
    .B1(_118_),
    .B2(_123_),
    .C1(_117_),
    .X(_125_));
 sky130_fd_sc_hd__and3_2 _371_ (.A(_115_),
    .B(_116_),
    .C(_125_),
    .X(_126_));
 sky130_fd_sc_hd__nand2_2 _372_ (.A(\u_digital.prev_sample[5] ),
    .B(\u_digital.adc_code[5] ),
    .Y(_127_));
 sky130_fd_sc_hd__or2_2 _373_ (.A(\u_digital.prev_sample[5] ),
    .B(\u_digital.adc_code[5] ),
    .X(_128_));
 sky130_fd_sc_hd__nand2_2 _374_ (.A(_127_),
    .B(_128_),
    .Y(_129_));
 sky130_fd_sc_hd__nand2_2 _375_ (.A(\u_digital.prev_sample[6] ),
    .B(\u_digital.adc_code[6] ),
    .Y(_130_));
 sky130_fd_sc_hd__or2_2 _376_ (.A(\u_digital.prev_sample[6] ),
    .B(\u_digital.adc_code[6] ),
    .X(_131_));
 sky130_fd_sc_hd__and2_2 _377_ (.A(_130_),
    .B(_131_),
    .X(_132_));
 sky130_fd_sc_hd__nand2_2 _378_ (.A(\u_digital.prev_sample[7] ),
    .B(\u_digital.adc_code[7] ),
    .Y(_133_));
 sky130_fd_sc_hd__nor2_2 _379_ (.A(\u_digital.prev_sample[7] ),
    .B(\u_digital.adc_code[7] ),
    .Y(_134_));
 sky130_fd_sc_hd__or2_2 _380_ (.A(\u_digital.prev_sample[7] ),
    .B(\u_digital.adc_code[7] ),
    .X(_135_));
 sky130_fd_sc_hd__nand2_2 _381_ (.A(_133_),
    .B(_135_),
    .Y(_136_));
 sky130_fd_sc_hd__nand3_2 _382_ (.A(_132_),
    .B(_133_),
    .C(_135_),
    .Y(_137_));
 sky130_fd_sc_hd__or3_2 _383_ (.A(_113_),
    .B(_114_),
    .C(_129_),
    .X(_138_));
 sky130_fd_sc_hd__or4bb_2 _384_ (.A(_137_),
    .B(_138_),
    .C_N(_116_),
    .D_N(_125_),
    .X(_139_));
 sky130_fd_sc_hd__nand2b_2 _385_ (.A_N(_113_),
    .B(_127_),
    .Y(_140_));
 sky130_fd_sc_hd__nand2_2 _386_ (.A(_128_),
    .B(_140_),
    .Y(_141_));
 sky130_fd_sc_hd__o221a_2 _387_ (.A1(_130_),
    .A2(_134_),
    .B1(_137_),
    .B2(_141_),
    .C1(_133_),
    .X(_142_));
 sky130_fd_sc_hd__a21oi_2 _388_ (.A1(_139_),
    .A2(_142_),
    .B1(_112_),
    .Y(_143_));
 sky130_fd_sc_hd__and2_2 _389_ (.A(\u_digital.prev_sample[9] ),
    .B(\u_digital.adc_code[9] ),
    .X(_144_));
 sky130_fd_sc_hd__nand2_2 _390_ (.A(\u_digital.prev_sample[9] ),
    .B(\u_digital.adc_code[9] ),
    .Y(_145_));
 sky130_fd_sc_hd__or2_2 _391_ (.A(_110_),
    .B(_144_),
    .X(_146_));
 sky130_fd_sc_hd__a31o_2 _392_ (.A1(\u_digital.prev_sample[8] ),
    .A2(\u_digital.adc_code[8] ),
    .A3(_109_),
    .B1(_144_),
    .X(_147_));
 sky130_fd_sc_hd__nand2_2 _393_ (.A(_109_),
    .B(_145_),
    .Y(_148_));
 sky130_fd_sc_hd__inv_2 _394_ (.A(_148_),
    .Y(_149_));
 sky130_fd_sc_hd__o2111ai_2 _395_ (.A1(_143_),
    .A2(_146_),
    .B1(_107_),
    .C1(_108_),
    .D1(_109_),
    .Y(_150_));
 sky130_fd_sc_hd__xor2_2 _396_ (.A(\u_digital.adc_code[11] ),
    .B(\u_digital.prev_sample[11] ),
    .X(_151_));
 sky130_fd_sc_hd__and3_2 _397_ (.A(_107_),
    .B(_150_),
    .C(_151_),
    .X(_152_));
 sky130_fd_sc_hd__a21oi_2 _398_ (.A1(_107_),
    .A2(_150_),
    .B1(_151_),
    .Y(_153_));
 sky130_fd_sc_hd__o31a_2 _399_ (.A1(_045_),
    .A2(_152_),
    .A3(_153_),
    .B1(_106_),
    .X(_154_));
 sky130_fd_sc_hd__nand2_2 _400_ (.A(_045_),
    .B(\u_digital.adc_code[11] ),
    .Y(_155_));
 sky130_fd_sc_hd__inv_2 _401_ (.A(_155_),
    .Y(_156_));
 sky130_fd_sc_hd__nor2_2 _402_ (.A(\u_digital.threshold_code_next[11] ),
    .B(_155_),
    .Y(_157_));
 sky130_fd_sc_hd__nand2_2 _403_ (.A(\u_digital.threshold_code_next[11] ),
    .B(_155_),
    .Y(_158_));
 sky130_fd_sc_hd__and2b_2 _404_ (.A_N(_157_),
    .B(_158_),
    .X(_159_));
 sky130_fd_sc_hd__xnor2_2 _405_ (.A(\u_digital.threshold_code_next[10] ),
    .B(_154_),
    .Y(_160_));
 sky130_fd_sc_hd__o21ai_2 _406_ (.A1(_110_),
    .A2(_143_),
    .B1(_148_),
    .Y(_161_));
 sky130_fd_sc_hd__o31a_2 _407_ (.A1(_110_),
    .A2(_143_),
    .A3(_148_),
    .B1(\u_digital.prev_sample_valid ),
    .X(_162_));
 sky130_fd_sc_hd__a2bb2o_2 _408_ (.A1_N(\u_digital.prev_sample_valid ),
    .A2_N(\u_digital.adc_code[8] ),
    .B1(_161_),
    .B2(_162_),
    .X(_163_));
 sky130_fd_sc_hd__inv_2 _409_ (.A(_163_),
    .Y(_164_));
 sky130_fd_sc_hd__and2_2 _410_ (.A(_045_),
    .B(\u_digital.adc_code[9] ),
    .X(_165_));
 sky130_fd_sc_hd__a221o_2 _411_ (.A1(_107_),
    .A2(_108_),
    .B1(_143_),
    .B2(_149_),
    .C1(_147_),
    .X(_166_));
 sky130_fd_sc_hd__a31o_2 _412_ (.A1(\u_digital.prev_sample_valid ),
    .A2(_150_),
    .A3(_166_),
    .B1(_165_),
    .X(_167_));
 sky130_fd_sc_hd__o2bb2a_2 _413_ (.A1_N(_167_),
    .A2_N(_055_),
    .B1(\u_digital.threshold_code_next[8] ),
    .B2(_163_),
    .X(_168_));
 sky130_fd_sc_hd__or2_2 _414_ (.A(_055_),
    .B(_167_),
    .X(_169_));
 sky130_fd_sc_hd__nand2_2 _415_ (.A(\u_digital.threshold_code_next[8] ),
    .B(_163_),
    .Y(_170_));
 sky130_fd_sc_hd__and3_2 _416_ (.A(_168_),
    .B(_169_),
    .C(_170_),
    .X(_171_));
 sky130_fd_sc_hd__and3_2 _417_ (.A(_159_),
    .B(_160_),
    .C(_171_),
    .X(_172_));
 sky130_fd_sc_hd__a31o_2 _418_ (.A1(_115_),
    .A2(_116_),
    .A3(_125_),
    .B1(_140_),
    .X(_173_));
 sky130_fd_sc_hd__a32o_2 _419_ (.A1(_128_),
    .A2(_132_),
    .A3(_173_),
    .B1(\u_digital.adc_code[6] ),
    .B2(\u_digital.prev_sample[6] ),
    .X(_174_));
 sky130_fd_sc_hd__xnor2_2 _420_ (.A(_136_),
    .B(_174_),
    .Y(_175_));
 sky130_fd_sc_hd__and2_2 _421_ (.A(_045_),
    .B(\u_digital.adc_code[6] ),
    .X(_176_));
 sky130_fd_sc_hd__or2_2 _422_ (.A(\u_digital.prev_sample_valid ),
    .B(\u_digital.adc_code[6] ),
    .X(_177_));
 sky130_fd_sc_hd__a21o_2 _423_ (.A1(\u_digital.prev_sample_valid ),
    .A2(_175_),
    .B1(_176_),
    .X(_178_));
 sky130_fd_sc_hd__a211o_2 _424_ (.A1(\u_digital.prev_sample_valid ),
    .A2(_175_),
    .B1(_176_),
    .C1(_054_),
    .X(_179_));
 sky130_fd_sc_hd__o211ai_2 _425_ (.A1(_045_),
    .A2(_175_),
    .B1(_177_),
    .C1(_054_),
    .Y(_180_));
 sky130_fd_sc_hd__nand2_2 _426_ (.A(_045_),
    .B(\u_digital.adc_code[7] ),
    .Y(_181_));
 sky130_fd_sc_hd__and3_2 _427_ (.A(_112_),
    .B(_139_),
    .C(_142_),
    .X(_182_));
 sky130_fd_sc_hd__o31a_2 _428_ (.A1(_045_),
    .A2(_143_),
    .A3(_182_),
    .B1(_181_),
    .X(_183_));
 sky130_fd_sc_hd__a21oi_2 _429_ (.A1(_128_),
    .A2(_173_),
    .B1(_132_),
    .Y(_184_));
 sky130_fd_sc_hd__a31o_2 _430_ (.A1(_128_),
    .A2(_132_),
    .A3(_173_),
    .B1(_045_),
    .X(_185_));
 sky130_fd_sc_hd__a2bb2o_2 _431_ (.A1_N(_185_),
    .A2_N(_184_),
    .B1(\u_digital.adc_code[5] ),
    .B2(_045_),
    .X(_186_));
 sky130_fd_sc_hd__inv_2 _432_ (.A(_186_),
    .Y(_187_));
 sky130_fd_sc_hd__nand2b_2 _433_ (.A_N(_186_),
    .B(\u_digital.threshold_code_next[5] ),
    .Y(_188_));
 sky130_fd_sc_hd__nor2_2 _434_ (.A(\u_digital.threshold_code_next[7] ),
    .B(_183_),
    .Y(_189_));
 sky130_fd_sc_hd__xor2_2 _435_ (.A(\u_digital.threshold_code_next[7] ),
    .B(_183_),
    .X(_190_));
 sky130_fd_sc_hd__nand4_2 _436_ (.A(_179_),
    .B(_180_),
    .C(_188_),
    .D(_190_),
    .Y(_191_));
 sky130_fd_sc_hd__nor2_2 _437_ (.A(_113_),
    .B(_126_),
    .Y(_192_));
 sky130_fd_sc_hd__xnor2_2 _438_ (.A(_129_),
    .B(_192_),
    .Y(_193_));
 sky130_fd_sc_hd__mux2_1 _439_ (.A0(_046_),
    .A1(_193_),
    .S(\u_digital.prev_sample_valid ),
    .X(_194_));
 sky130_fd_sc_hd__inv_2 _440_ (.A(_194_),
    .Y(_195_));
 sky130_fd_sc_hd__o22a_2 _441_ (.A1(\u_digital.threshold_code_next[5] ),
    .A2(_187_),
    .B1(_194_),
    .B2(\u_digital.threshold_code_next[4] ),
    .X(_196_));
 sky130_fd_sc_hd__nand2_2 _442_ (.A(\u_digital.threshold_code_next[4] ),
    .B(_194_),
    .Y(_197_));
 sky130_fd_sc_hd__nand2_2 _443_ (.A(_196_),
    .B(_197_),
    .Y(_198_));
 sky130_fd_sc_hd__nand2_2 _444_ (.A(_045_),
    .B(\u_digital.adc_code[3] ),
    .Y(_199_));
 sky130_fd_sc_hd__a21oi_2 _445_ (.A1(_116_),
    .A2(_125_),
    .B1(_115_),
    .Y(_200_));
 sky130_fd_sc_hd__o31a_2 _446_ (.A1(_045_),
    .A2(_126_),
    .A3(_200_),
    .B1(_199_),
    .X(_201_));
 sky130_fd_sc_hd__inv_2 _447_ (.A(_201_),
    .Y(_202_));
 sky130_fd_sc_hd__nand2_2 _448_ (.A(\u_digital.threshold_code_next[3] ),
    .B(_201_),
    .Y(_203_));
 sky130_fd_sc_hd__or2_2 _449_ (.A(\u_digital.prev_sample_valid ),
    .B(\u_digital.adc_code[2] ),
    .X(_204_));
 sky130_fd_sc_hd__a21oi_2 _450_ (.A1(_118_),
    .A2(_123_),
    .B1(_117_),
    .Y(_205_));
 sky130_fd_sc_hd__and3_2 _451_ (.A(_116_),
    .B(_124_),
    .C(_205_),
    .X(_206_));
 sky130_fd_sc_hd__a21oi_2 _452_ (.A1(_116_),
    .A2(_124_),
    .B1(_205_),
    .Y(_207_));
 sky130_fd_sc_hd__o31a_2 _453_ (.A1(_045_),
    .A2(_206_),
    .A3(_207_),
    .B1(_204_),
    .X(_208_));
 sky130_fd_sc_hd__a2bb2o_2 _454_ (.A1_N(\u_digital.threshold_code_next[3] ),
    .A2_N(_201_),
    .B1(_208_),
    .B2(_053_),
    .X(_209_));
 sky130_fd_sc_hd__nor2_2 _455_ (.A(_053_),
    .B(_208_),
    .Y(_210_));
 sky130_fd_sc_hd__or3b_2 _456_ (.A(_209_),
    .B(_210_),
    .C_N(_203_),
    .X(_211_));
 sky130_fd_sc_hd__nor2_2 _457_ (.A(_119_),
    .B(_123_),
    .Y(_212_));
 sky130_fd_sc_hd__a21o_2 _458_ (.A1(_119_),
    .A2(_123_),
    .B1(_045_),
    .X(_213_));
 sky130_fd_sc_hd__o2bb2a_2 _459_ (.A1_N(_045_),
    .A2_N(\u_digital.adc_code[1] ),
    .B1(_212_),
    .B2(_213_),
    .X(_214_));
 sky130_fd_sc_hd__inv_2 _460_ (.A(_214_),
    .Y(_215_));
 sky130_fd_sc_hd__a22oi_2 _461_ (.A1(\u_digital.prev_sample[0] ),
    .A2(\u_digital.adc_code[0] ),
    .B1(_121_),
    .B2(_122_),
    .Y(_216_));
 sky130_fd_sc_hd__a41o_2 _462_ (.A1(\u_digital.prev_sample[0] ),
    .A2(\u_digital.adc_code[0] ),
    .A3(_121_),
    .A4(_122_),
    .B1(_045_),
    .X(_217_));
 sky130_fd_sc_hd__o2bb2a_2 _463_ (.A1_N(_045_),
    .A2_N(\u_digital.adc_code[0] ),
    .B1(_216_),
    .B2(_217_),
    .X(_218_));
 sky130_fd_sc_hd__inv_2 _464_ (.A(_218_),
    .Y(_219_));
 sky130_fd_sc_hd__a22o_2 _465_ (.A1(\u_digital.threshold_code_next[1] ),
    .A2(_214_),
    .B1(_218_),
    .B2(\u_digital.threshold_code_next[0] ),
    .X(_220_));
 sky130_fd_sc_hd__o21a_2 _466_ (.A1(\u_digital.threshold_code_next[1] ),
    .A2(_214_),
    .B1(_220_),
    .X(_221_));
 sky130_fd_sc_hd__a2bb2o_2 _467_ (.A1_N(_211_),
    .A2_N(_221_),
    .B1(_203_),
    .B2(_209_),
    .X(_222_));
 sky130_fd_sc_hd__and4b_2 _468_ (.A_N(_191_),
    .B(_196_),
    .C(_197_),
    .D(_222_),
    .X(_223_));
 sky130_fd_sc_hd__nor2_2 _469_ (.A(_191_),
    .B(_196_),
    .Y(_224_));
 sky130_fd_sc_hd__a21oi_2 _470_ (.A1(\u_digital.threshold_code_next[7] ),
    .A2(_183_),
    .B1(_180_),
    .Y(_225_));
 sky130_fd_sc_hd__or4_2 _471_ (.A(_189_),
    .B(_223_),
    .C(_224_),
    .D(_225_),
    .X(_226_));
 sky130_fd_sc_hd__and4b_2 _472_ (.A_N(_168_),
    .B(_169_),
    .C(_159_),
    .D(_160_),
    .X(_227_));
 sky130_fd_sc_hd__a31o_2 _473_ (.A1(_056_),
    .A2(_154_),
    .A3(_158_),
    .B1(_157_),
    .X(_228_));
 sky130_fd_sc_hd__a211o_2 _474_ (.A1(_172_),
    .A2(_226_),
    .B1(_227_),
    .C1(_228_),
    .X(_229_));
 sky130_fd_sc_hd__o22a_2 _475_ (.A1(\u_digital.threshold_code_next[1] ),
    .A2(_214_),
    .B1(_218_),
    .B2(\u_digital.threshold_code_next[0] ),
    .X(_230_));
 sky130_fd_sc_hd__or3b_2 _476_ (.A(_211_),
    .B(_220_),
    .C_N(_230_),
    .X(_231_));
 sky130_fd_sc_hd__nor3_2 _477_ (.A(_191_),
    .B(_198_),
    .C(_231_),
    .Y(_232_));
 sky130_fd_sc_hd__a21boi_2 _478_ (.A1(_172_),
    .A2(_232_),
    .B1_N(\u_digital.adc_valid ),
    .Y(_233_));
 sky130_fd_sc_hd__a22o_2 _479_ (.A1(alert_status),
    .A2(_078_),
    .B1(_229_),
    .B2(_233_),
    .X(\u_digital.alert_status_next ));
 sky130_fd_sc_hd__a21o_2 _480_ (.A1(_229_),
    .A2(_233_),
    .B1(_079_),
    .X(\u_digital.status_alert_pending_next ));
 sky130_fd_sc_hd__a21o_2 _481_ (.A1(_229_),
    .A2(_233_),
    .B1(_072_),
    .X(\u_digital.irq_status_alert_next ));
 sky130_fd_sc_hd__a31o_2 _482_ (.A1(wr_data[1]),
    .A2(wr_en),
    .A3(_049_),
    .B1(\u_digital.sample_req_pending ),
    .X(_234_));
 sky130_fd_sc_hd__o21ba_2 _483_ (.A1(\u_digital.enable_reg_next ),
    .A2(_234_),
    .B1_N(\u_digital.adc_valid ),
    .X(\u_digital.sample_req_pending_next ));
 sky130_fd_sc_hd__a21o_2 _484_ (.A1(\u_digital.status_sample_done ),
    .A2(_071_),
    .B1(\u_digital.adc_valid ),
    .X(\u_digital.status_sample_done_next ));
 sky130_fd_sc_hd__or2_2 _485_ (.A(\u_digital.adc_valid ),
    .B(_080_),
    .X(\u_digital.irq_status_sample_done_next ));
 sky130_fd_sc_hd__nor2_2 _486_ (.A(\u_digital.adc_valid ),
    .B(\u_digital.sample_req_pending ),
    .Y(_235_));
 sky130_fd_sc_hd__a2bb2o_2 _487_ (.A1_N(_042_),
    .A2_N(_050_),
    .B1(\u_digital.enable_reg_next ),
    .B2(_235_),
    .X(\u_digital.sample_req_next ));
 sky130_fd_sc_hd__o31a_2 _488_ (.A1(\u_digital.adc_valid ),
    .A2(_072_),
    .A3(_080_),
    .B1(\u_digital.irq_enable_reg_next ),
    .X(\u_digital.alert_irq_next ));
 sky130_fd_sc_hd__or2_2 _489_ (.A(\u_digital.adc_valid ),
    .B(\u_digital.prev_sample_valid ),
    .X(_000_));
 sky130_fd_sc_hd__o21ba_2 _490_ (.A1(\u_digital.status_busy ),
    .A2(_234_),
    .B1_N(\u_digital.adc_valid ),
    .X(_001_));
 sky130_fd_sc_hd__mux2_1 _491_ (.A0(temp_code[0]),
    .A1(_219_),
    .S(\u_digital.adc_valid ),
    .X(_002_));
 sky130_fd_sc_hd__mux2_1 _492_ (.A0(temp_code[1]),
    .A1(_215_),
    .S(\u_digital.adc_valid ),
    .X(_003_));
 sky130_fd_sc_hd__mux2_1 _493_ (.A0(temp_code[2]),
    .A1(_208_),
    .S(\u_digital.adc_valid ),
    .X(_004_));
 sky130_fd_sc_hd__mux2_1 _494_ (.A0(temp_code[3]),
    .A1(_202_),
    .S(\u_digital.adc_valid ),
    .X(_005_));
 sky130_fd_sc_hd__mux2_1 _495_ (.A0(temp_code[4]),
    .A1(_195_),
    .S(\u_digital.adc_valid ),
    .X(_006_));
 sky130_fd_sc_hd__mux2_1 _496_ (.A0(temp_code[5]),
    .A1(_186_),
    .S(\u_digital.adc_valid ),
    .X(_007_));
 sky130_fd_sc_hd__mux2_1 _497_ (.A0(temp_code[6]),
    .A1(_178_),
    .S(\u_digital.adc_valid ),
    .X(_008_));
 sky130_fd_sc_hd__nor2_2 _498_ (.A(\u_digital.adc_valid ),
    .B(temp_code[7]),
    .Y(_236_));
 sky130_fd_sc_hd__a21oi_2 _499_ (.A1(\u_digital.adc_valid ),
    .A2(_183_),
    .B1(_236_),
    .Y(_009_));
 sky130_fd_sc_hd__mux2_1 _500_ (.A0(temp_code[8]),
    .A1(_164_),
    .S(\u_digital.adc_valid ),
    .X(_010_));
 sky130_fd_sc_hd__mux2_1 _501_ (.A0(temp_code[9]),
    .A1(_167_),
    .S(\u_digital.adc_valid ),
    .X(_011_));
 sky130_fd_sc_hd__mux2_1 _502_ (.A0(temp_code[10]),
    .A1(_154_),
    .S(\u_digital.adc_valid ),
    .X(_012_));
 sky130_fd_sc_hd__mux2_1 _503_ (.A0(temp_code[11]),
    .A1(_156_),
    .S(\u_digital.adc_valid ),
    .X(_013_));
 sky130_fd_sc_hd__xor2_2 _504_ (.A(\u_digital.adc_valid ),
    .B(\u_digital.sample_count[0] ),
    .X(_014_));
 sky130_fd_sc_hd__and3_2 _505_ (.A(\u_digital.adc_valid ),
    .B(\u_digital.sample_count[0] ),
    .C(\u_digital.sample_count[1] ),
    .X(_237_));
 sky130_fd_sc_hd__a21oi_2 _506_ (.A1(\u_digital.adc_valid ),
    .A2(\u_digital.sample_count[0] ),
    .B1(\u_digital.sample_count[1] ),
    .Y(_238_));
 sky130_fd_sc_hd__nor2_2 _507_ (.A(_237_),
    .B(_238_),
    .Y(_015_));
 sky130_fd_sc_hd__and2_2 _508_ (.A(\u_digital.sample_count[2] ),
    .B(_237_),
    .X(_239_));
 sky130_fd_sc_hd__nor2_2 _509_ (.A(\u_digital.sample_count[2] ),
    .B(_237_),
    .Y(_240_));
 sky130_fd_sc_hd__nor2_2 _510_ (.A(_239_),
    .B(_240_),
    .Y(_016_));
 sky130_fd_sc_hd__xor2_2 _511_ (.A(\u_digital.sample_count[3] ),
    .B(_239_),
    .X(_017_));
 sky130_fd_sc_hd__and3_2 _512_ (.A(\u_digital.sample_count[3] ),
    .B(\u_digital.sample_count[4] ),
    .C(_239_),
    .X(_241_));
 sky130_fd_sc_hd__a21oi_2 _513_ (.A1(\u_digital.sample_count[3] ),
    .A2(_239_),
    .B1(\u_digital.sample_count[4] ),
    .Y(_242_));
 sky130_fd_sc_hd__nor2_2 _514_ (.A(_241_),
    .B(_242_),
    .Y(_018_));
 sky130_fd_sc_hd__and2_2 _515_ (.A(\u_digital.sample_count[5] ),
    .B(_241_),
    .X(_243_));
 sky130_fd_sc_hd__nor2_2 _516_ (.A(\u_digital.sample_count[5] ),
    .B(_241_),
    .Y(_244_));
 sky130_fd_sc_hd__nor2_2 _517_ (.A(_243_),
    .B(_244_),
    .Y(_019_));
 sky130_fd_sc_hd__xor2_2 _518_ (.A(\u_digital.sample_count[6] ),
    .B(_243_),
    .X(_020_));
 sky130_fd_sc_hd__and3_2 _519_ (.A(\u_digital.sample_count[6] ),
    .B(\u_digital.sample_count[7] ),
    .C(_243_),
    .X(_245_));
 sky130_fd_sc_hd__a21oi_2 _520_ (.A1(\u_digital.sample_count[6] ),
    .A2(_243_),
    .B1(\u_digital.sample_count[7] ),
    .Y(_246_));
 sky130_fd_sc_hd__nor2_2 _521_ (.A(_245_),
    .B(_246_),
    .Y(_021_));
 sky130_fd_sc_hd__and2_2 _522_ (.A(\u_digital.sample_count[8] ),
    .B(_245_),
    .X(_247_));
 sky130_fd_sc_hd__nor2_2 _523_ (.A(\u_digital.sample_count[8] ),
    .B(_245_),
    .Y(_248_));
 sky130_fd_sc_hd__nor2_2 _524_ (.A(_247_),
    .B(_248_),
    .Y(_022_));
 sky130_fd_sc_hd__xor2_2 _525_ (.A(\u_digital.sample_count[9] ),
    .B(_247_),
    .X(_023_));
 sky130_fd_sc_hd__and3_2 _526_ (.A(\u_digital.sample_count[9] ),
    .B(\u_digital.sample_count[10] ),
    .C(_247_),
    .X(_249_));
 sky130_fd_sc_hd__a21oi_2 _527_ (.A1(\u_digital.sample_count[9] ),
    .A2(_247_),
    .B1(\u_digital.sample_count[10] ),
    .Y(_250_));
 sky130_fd_sc_hd__nor2_2 _528_ (.A(_249_),
    .B(_250_),
    .Y(_024_));
 sky130_fd_sc_hd__and2_2 _529_ (.A(\u_digital.sample_count[11] ),
    .B(_249_),
    .X(_251_));
 sky130_fd_sc_hd__nor2_2 _530_ (.A(\u_digital.sample_count[11] ),
    .B(_249_),
    .Y(_252_));
 sky130_fd_sc_hd__nor2_2 _531_ (.A(_251_),
    .B(_252_),
    .Y(_025_));
 sky130_fd_sc_hd__xor2_2 _532_ (.A(\u_digital.sample_count[12] ),
    .B(_251_),
    .X(_026_));
 sky130_fd_sc_hd__and3_2 _533_ (.A(\u_digital.sample_count[12] ),
    .B(\u_digital.sample_count[13] ),
    .C(_251_),
    .X(_253_));
 sky130_fd_sc_hd__a21oi_2 _534_ (.A1(\u_digital.sample_count[12] ),
    .A2(_251_),
    .B1(\u_digital.sample_count[13] ),
    .Y(_254_));
 sky130_fd_sc_hd__nor2_2 _535_ (.A(_253_),
    .B(_254_),
    .Y(_027_));
 sky130_fd_sc_hd__nand2_2 _536_ (.A(\u_digital.sample_count[14] ),
    .B(_253_),
    .Y(_255_));
 sky130_fd_sc_hd__or2_2 _537_ (.A(\u_digital.sample_count[14] ),
    .B(_253_),
    .X(_256_));
 sky130_fd_sc_hd__and2_2 _538_ (.A(_255_),
    .B(_256_),
    .X(_028_));
 sky130_fd_sc_hd__xnor2_2 _539_ (.A(\u_digital.sample_count[15] ),
    .B(_255_),
    .Y(_029_));
 sky130_fd_sc_hd__mux2_1 _540_ (.A0(\u_digital.prev_sample[0] ),
    .A1(\u_digital.adc_code[0] ),
    .S(\u_digital.adc_valid ),
    .X(_030_));
 sky130_fd_sc_hd__mux2_1 _541_ (.A0(\u_digital.prev_sample[1] ),
    .A1(\u_digital.adc_code[1] ),
    .S(\u_digital.adc_valid ),
    .X(_031_));
 sky130_fd_sc_hd__mux2_1 _542_ (.A0(\u_digital.prev_sample[2] ),
    .A1(\u_digital.adc_code[2] ),
    .S(\u_digital.adc_valid ),
    .X(_032_));
 sky130_fd_sc_hd__mux2_1 _543_ (.A0(\u_digital.prev_sample[3] ),
    .A1(\u_digital.adc_code[3] ),
    .S(\u_digital.adc_valid ),
    .X(_033_));
 sky130_fd_sc_hd__mux2_1 _544_ (.A0(\u_digital.prev_sample[4] ),
    .A1(\u_digital.adc_code[4] ),
    .S(\u_digital.adc_valid ),
    .X(_034_));
 sky130_fd_sc_hd__mux2_1 _545_ (.A0(\u_digital.prev_sample[5] ),
    .A1(\u_digital.adc_code[5] ),
    .S(\u_digital.adc_valid ),
    .X(_035_));
 sky130_fd_sc_hd__mux2_1 _546_ (.A0(\u_digital.prev_sample[6] ),
    .A1(\u_digital.adc_code[6] ),
    .S(\u_digital.adc_valid ),
    .X(_036_));
 sky130_fd_sc_hd__mux2_1 _547_ (.A0(\u_digital.prev_sample[7] ),
    .A1(\u_digital.adc_code[7] ),
    .S(\u_digital.adc_valid ),
    .X(_037_));
 sky130_fd_sc_hd__mux2_1 _548_ (.A0(\u_digital.prev_sample[8] ),
    .A1(\u_digital.adc_code[8] ),
    .S(\u_digital.adc_valid ),
    .X(_038_));
 sky130_fd_sc_hd__mux2_1 _549_ (.A0(\u_digital.prev_sample[9] ),
    .A1(\u_digital.adc_code[9] ),
    .S(\u_digital.adc_valid ),
    .X(_039_));
 sky130_fd_sc_hd__mux2_1 _550_ (.A0(\u_digital.prev_sample[10] ),
    .A1(\u_digital.adc_code[10] ),
    .S(\u_digital.adc_valid ),
    .X(_040_));
 sky130_fd_sc_hd__mux2_1 _551_ (.A0(\u_digital.prev_sample[11] ),
    .A1(\u_digital.adc_code[11] ),
    .S(\u_digital.adc_valid ),
    .X(_041_));
 sky130_fd_sc_hd__sdfrtp_2 _552_ (.CLK(clk),
    .D(_000_),
    .RESET_B(reset_n),
    .SCD(scan_in[0]),
    .SCE(scan_en),
    .Q(\u_digital.prev_sample_valid ));
 sky130_fd_sc_hd__sdfrtp_2 _553_ (.CLK(clk),
    .D(\u_digital.irq_status_alert_next ),
    .RESET_B(reset_n),
    .SCD(scan_in[1]),
    .SCE(scan_en),
    .Q(\u_digital.irq_status_alert ));
 sky130_fd_sc_hd__sdfrtp_2 _554_ (.CLK(clk),
    .D(_001_),
    .RESET_B(reset_n),
    .SCD(scan_in[2]),
    .SCE(scan_en),
    .Q(\u_digital.status_busy ));
 sky130_fd_sc_hd__sdfrtp_2 _555_ (.CLK(clk),
    .D(_002_),
    .RESET_B(reset_n),
    .SCD(scan_in[3]),
    .SCE(scan_en),
    .Q(temp_code[0]));
 sky130_fd_sc_hd__sdfrtp_2 _556_ (.CLK(clk),
    .D(_003_),
    .RESET_B(reset_n),
    .SCD(\u_digital.prev_sample_valid ),
    .SCE(scan_en),
    .Q(temp_code[1]));
 sky130_fd_sc_hd__sdfrtp_2 _557_ (.CLK(clk),
    .D(_004_),
    .RESET_B(reset_n),
    .SCD(\u_digital.irq_status_alert ),
    .SCE(scan_en),
    .Q(temp_code[2]));
 sky130_fd_sc_hd__sdfrtp_2 _558_ (.CLK(clk),
    .D(_005_),
    .RESET_B(reset_n),
    .SCD(\u_digital.status_busy ),
    .SCE(scan_en),
    .Q(temp_code[3]));
 sky130_fd_sc_hd__sdfrtp_2 _559_ (.CLK(clk),
    .D(_006_),
    .RESET_B(reset_n),
    .SCD(temp_code[0]),
    .SCE(scan_en),
    .Q(temp_code[4]));
 sky130_fd_sc_hd__sdfrtp_2 _560_ (.CLK(clk),
    .D(_007_),
    .RESET_B(reset_n),
    .SCD(temp_code[1]),
    .SCE(scan_en),
    .Q(temp_code[5]));
 sky130_fd_sc_hd__sdfrtp_2 _561_ (.CLK(clk),
    .D(_008_),
    .RESET_B(reset_n),
    .SCD(temp_code[2]),
    .SCE(scan_en),
    .Q(temp_code[6]));
 sky130_fd_sc_hd__sdfrtp_2 _562_ (.CLK(clk),
    .D(_009_),
    .RESET_B(reset_n),
    .SCD(temp_code[3]),
    .SCE(scan_en),
    .Q(temp_code[7]));
 sky130_fd_sc_hd__sdfrtp_2 _563_ (.CLK(clk),
    .D(_010_),
    .RESET_B(reset_n),
    .SCD(temp_code[4]),
    .SCE(scan_en),
    .Q(temp_code[8]));
 sky130_fd_sc_hd__sdfrtp_2 _564_ (.CLK(clk),
    .D(_011_),
    .RESET_B(reset_n),
    .SCD(temp_code[5]),
    .SCE(scan_en),
    .Q(temp_code[9]));
 sky130_fd_sc_hd__sdfrtp_2 _565_ (.CLK(clk),
    .D(_012_),
    .RESET_B(reset_n),
    .SCD(temp_code[6]),
    .SCE(scan_en),
    .Q(temp_code[10]));
 sky130_fd_sc_hd__sdfrtp_2 _566_ (.CLK(clk),
    .D(_013_),
    .RESET_B(reset_n),
    .SCD(temp_code[7]),
    .SCE(scan_en),
    .Q(temp_code[11]));
 sky130_fd_sc_hd__sdfrtp_2 _567_ (.CLK(clk),
    .D(\u_digital.status_alert_pending_next ),
    .RESET_B(reset_n),
    .SCD(temp_code[8]),
    .SCE(scan_en),
    .Q(\u_digital.status_alert_pending ));
 sky130_fd_sc_hd__sdfrtp_2 _568_ (.CLK(clk),
    .D(\u_digital.status_sample_done_next ),
    .RESET_B(reset_n),
    .SCD(temp_code[9]),
    .SCE(scan_en),
    .Q(\u_digital.status_sample_done ));
 sky130_fd_sc_hd__sdfrtp_2 _569_ (.CLK(clk),
    .D(_014_),
    .RESET_B(reset_n),
    .SCD(temp_code[10]),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _570_ (.CLK(clk),
    .D(_015_),
    .RESET_B(reset_n),
    .SCD(temp_code[11]),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _571_ (.CLK(clk),
    .D(_016_),
    .RESET_B(reset_n),
    .SCD(\u_digital.status_alert_pending ),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _572_ (.CLK(clk),
    .D(_017_),
    .RESET_B(reset_n),
    .SCD(\u_digital.status_sample_done ),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _573_ (.CLK(clk),
    .D(_018_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[0] ),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _574_ (.CLK(clk),
    .D(_019_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[1] ),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _575_ (.CLK(clk),
    .D(_020_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[2] ),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _576_ (.CLK(clk),
    .D(_021_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[3] ),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _577_ (.CLK(clk),
    .D(_022_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[4] ),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[8] ));
 sky130_fd_sc_hd__sdfrtp_2 _578_ (.CLK(clk),
    .D(_023_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[5] ),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[9] ));
 sky130_fd_sc_hd__sdfrtp_2 _579_ (.CLK(clk),
    .D(_024_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[6] ),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[10] ));
 sky130_fd_sc_hd__sdfrtp_2 _580_ (.CLK(clk),
    .D(_025_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[7] ),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[11] ));
 sky130_fd_sc_hd__sdfrtp_2 _581_ (.CLK(clk),
    .D(_026_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[8] ),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[12] ));
 sky130_fd_sc_hd__sdfrtp_2 _582_ (.CLK(clk),
    .D(_027_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[9] ),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[13] ));
 sky130_fd_sc_hd__sdfrtp_2 _583_ (.CLK(clk),
    .D(_028_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[10] ),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[14] ));
 sky130_fd_sc_hd__sdfrtp_2 _584_ (.CLK(clk),
    .D(_029_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[11] ),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[15] ));
 sky130_fd_sc_hd__sdfrtp_2 _585_ (.CLK(clk),
    .D(\u_digital.irq_enable_reg_next ),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[12] ),
    .SCE(scan_en),
    .Q(\u_digital.irq_enable_reg ));
 sky130_fd_sc_hd__sdfrtp_2 _586_ (.CLK(clk),
    .D(\u_digital.enable_reg_next ),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[13] ),
    .SCE(scan_en),
    .Q(\u_digital.enable_reg ));
 sky130_fd_sc_hd__sdfrtp_2 _587_ (.CLK(clk),
    .D(\u_digital.irq_status_sample_done_next ),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[14] ),
    .SCE(scan_en),
    .Q(\u_digital.irq_status_sample_done ));
 sky130_fd_sc_hd__sdfrtp_2 _588_ (.CLK(clk),
    .D(\u_digital.alert_status_next ),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[15] ),
    .SCE(scan_en),
    .Q(alert_status));
 sky130_fd_sc_hd__sdfrtp_2 _589_ (.CLK(clk),
    .D(_030_),
    .RESET_B(reset_n),
    .SCD(\u_digital.irq_enable_reg ),
    .SCE(scan_en),
    .Q(\u_digital.prev_sample[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _590_ (.CLK(clk),
    .D(_031_),
    .RESET_B(reset_n),
    .SCD(\u_digital.enable_reg ),
    .SCE(scan_en),
    .Q(\u_digital.prev_sample[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _591_ (.CLK(clk),
    .D(_032_),
    .RESET_B(reset_n),
    .SCD(\u_digital.irq_status_sample_done ),
    .SCE(scan_en),
    .Q(\u_digital.prev_sample[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _592_ (.CLK(clk),
    .D(_033_),
    .RESET_B(reset_n),
    .SCD(alert_status),
    .SCE(scan_en),
    .Q(\u_digital.prev_sample[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _593_ (.CLK(clk),
    .D(_034_),
    .RESET_B(reset_n),
    .SCD(\u_digital.prev_sample[0] ),
    .SCE(scan_en),
    .Q(\u_digital.prev_sample[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _594_ (.CLK(clk),
    .D(_035_),
    .RESET_B(reset_n),
    .SCD(\u_digital.prev_sample[1] ),
    .SCE(scan_en),
    .Q(\u_digital.prev_sample[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _595_ (.CLK(clk),
    .D(_036_),
    .RESET_B(reset_n),
    .SCD(\u_digital.prev_sample[2] ),
    .SCE(scan_en),
    .Q(\u_digital.prev_sample[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _596_ (.CLK(clk),
    .D(_037_),
    .RESET_B(reset_n),
    .SCD(\u_digital.prev_sample[3] ),
    .SCE(scan_en),
    .Q(\u_digital.prev_sample[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _597_ (.CLK(clk),
    .D(_038_),
    .RESET_B(reset_n),
    .SCD(\u_digital.prev_sample[4] ),
    .SCE(scan_en),
    .Q(\u_digital.prev_sample[8] ));
 sky130_fd_sc_hd__sdfrtp_2 _598_ (.CLK(clk),
    .D(_039_),
    .RESET_B(reset_n),
    .SCD(\u_digital.prev_sample[5] ),
    .SCE(scan_en),
    .Q(\u_digital.prev_sample[9] ));
 sky130_fd_sc_hd__sdfrtp_2 _599_ (.CLK(clk),
    .D(_040_),
    .RESET_B(reset_n),
    .SCD(\u_digital.prev_sample[6] ),
    .SCE(scan_en),
    .Q(\u_digital.prev_sample[10] ));
 sky130_fd_sc_hd__sdfrtp_2 _600_ (.CLK(clk),
    .D(_041_),
    .RESET_B(reset_n),
    .SCD(\u_digital.prev_sample[7] ),
    .SCE(scan_en),
    .Q(\u_digital.prev_sample[11] ));
 sky130_fd_sc_hd__sdfrtp_2 _601_ (.CLK(clk),
    .D(\u_digital.threshold_code_next[0] ),
    .RESET_B(reset_n),
    .SCD(\u_digital.prev_sample[8] ),
    .SCE(scan_en),
    .Q(threshold_code[0]));
 sky130_fd_sc_hd__sdfrtp_2 _602_ (.CLK(clk),
    .D(\u_digital.threshold_code_next[1] ),
    .RESET_B(reset_n),
    .SCD(\u_digital.prev_sample[9] ),
    .SCE(scan_en),
    .Q(threshold_code[1]));
 sky130_fd_sc_hd__sdfrtp_2 _603_ (.CLK(clk),
    .D(\u_digital.threshold_code_next[2] ),
    .RESET_B(reset_n),
    .SCD(\u_digital.prev_sample[10] ),
    .SCE(scan_en),
    .Q(threshold_code[2]));
 sky130_fd_sc_hd__sdfrtp_2 _604_ (.CLK(clk),
    .D(\u_digital.threshold_code_next[3] ),
    .RESET_B(reset_n),
    .SCD(\u_digital.prev_sample[11] ),
    .SCE(scan_en),
    .Q(threshold_code[3]));
 sky130_fd_sc_hd__sdfrtp_2 _605_ (.CLK(clk),
    .D(\u_digital.threshold_code_next[4] ),
    .RESET_B(reset_n),
    .SCD(threshold_code[0]),
    .SCE(scan_en),
    .Q(threshold_code[4]));
 sky130_fd_sc_hd__sdfrtp_2 _606_ (.CLK(clk),
    .D(\u_digital.threshold_code_next[5] ),
    .RESET_B(reset_n),
    .SCD(threshold_code[1]),
    .SCE(scan_en),
    .Q(threshold_code[5]));
 sky130_fd_sc_hd__sdfrtp_2 _607_ (.CLK(clk),
    .D(\u_digital.threshold_code_next[6] ),
    .RESET_B(reset_n),
    .SCD(threshold_code[2]),
    .SCE(scan_en),
    .Q(threshold_code[6]));
 sky130_fd_sc_hd__sdfrtp_2 _608_ (.CLK(clk),
    .D(\u_digital.threshold_code_next[7] ),
    .RESET_B(reset_n),
    .SCD(threshold_code[3]),
    .SCE(scan_en),
    .Q(threshold_code[7]));
 sky130_fd_sc_hd__sdfrtp_2 _609_ (.CLK(clk),
    .D(\u_digital.threshold_code_next[8] ),
    .RESET_B(reset_n),
    .SCD(threshold_code[4]),
    .SCE(scan_en),
    .Q(threshold_code[8]));
 sky130_fd_sc_hd__sdfrtp_2 _610_ (.CLK(clk),
    .D(\u_digital.threshold_code_next[9] ),
    .RESET_B(reset_n),
    .SCD(threshold_code[5]),
    .SCE(scan_en),
    .Q(threshold_code[9]));
 sky130_fd_sc_hd__sdfrtp_2 _611_ (.CLK(clk),
    .D(\u_digital.threshold_code_next[10] ),
    .RESET_B(reset_n),
    .SCD(threshold_code[6]),
    .SCE(scan_en),
    .Q(threshold_code[10]));
 sky130_fd_sc_hd__sdfrtp_2 _612_ (.CLK(clk),
    .D(\u_digital.threshold_code_next[11] ),
    .RESET_B(reset_n),
    .SCD(threshold_code[7]),
    .SCE(scan_en),
    .Q(threshold_code[11]));
 sky130_fd_sc_hd__sdfrtp_2 _613_ (.CLK(clk),
    .D(\u_digital.alert_irq_next ),
    .RESET_B(reset_n),
    .SCD(threshold_code[8]),
    .SCE(scan_en),
    .Q(alert_irq));
 sky130_fd_sc_hd__sdfrtp_2 _614_ (.CLK(clk),
    .D(\u_digital.sample_req_pending_next ),
    .RESET_B(reset_n),
    .SCD(threshold_code[9]),
    .SCE(scan_en),
    .Q(\u_digital.sample_req_pending ));
 sky130_fd_sc_hd__sdfrtp_2 _615_ (.CLK(clk),
    .D(\u_digital.sample_req_next ),
    .RESET_B(reset_n),
    .SCD(threshold_code[10]),
    .SCE(scan_en),
    .Q(\u_digital.sample_req ));
 sky130_fd_sc_hd__sdfrtp_2 _616_ (.CLK(clk),
    .D(\u_digital.read_data_next[0] ),
    .RESET_B(reset_n),
    .SCD(threshold_code[11]),
    .SCE(scan_en),
    .Q(rd_data[0]));
 sky130_fd_sc_hd__sdfrtp_2 _617_ (.CLK(clk),
    .D(\u_digital.read_data_next[1] ),
    .RESET_B(reset_n),
    .SCD(alert_irq),
    .SCE(scan_en),
    .Q(rd_data[1]));
 sky130_fd_sc_hd__sdfrtp_2 _618_ (.CLK(clk),
    .D(\u_digital.read_data_next[2] ),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_req_pending ),
    .SCE(scan_en),
    .Q(rd_data[2]));
 sky130_fd_sc_hd__sdfrtp_2 _619_ (.CLK(clk),
    .D(\u_digital.read_data_next[3] ),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_req ),
    .SCE(scan_en),
    .Q(rd_data[3]));
 sky130_fd_sc_hd__sdfrtp_2 _620_ (.CLK(clk),
    .D(\u_digital.read_data_next[4] ),
    .RESET_B(reset_n),
    .SCD(rd_data[0]),
    .SCE(scan_en),
    .Q(rd_data[4]));
 sky130_fd_sc_hd__sdfrtp_2 _621_ (.CLK(clk),
    .D(\u_digital.read_data_next[5] ),
    .RESET_B(reset_n),
    .SCD(rd_data[1]),
    .SCE(scan_en),
    .Q(rd_data[5]));
 sky130_fd_sc_hd__sdfrtp_2 _622_ (.CLK(clk),
    .D(\u_digital.read_data_next[6] ),
    .RESET_B(reset_n),
    .SCD(rd_data[2]),
    .SCE(scan_en),
    .Q(rd_data[6]));
 sky130_fd_sc_hd__sdfrtp_2 _623_ (.CLK(clk),
    .D(\u_digital.read_data_next[7] ),
    .RESET_B(reset_n),
    .SCD(rd_data[3]),
    .SCE(scan_en),
    .Q(rd_data[7]));
 sky130_fd_sc_hd__sdfrtp_2 _624_ (.CLK(clk),
    .D(\u_digital.read_data_next[8] ),
    .RESET_B(reset_n),
    .SCD(rd_data[4]),
    .SCE(scan_en),
    .Q(rd_data[8]));
 sky130_fd_sc_hd__sdfrtp_2 _625_ (.CLK(clk),
    .D(\u_digital.read_data_next[9] ),
    .RESET_B(reset_n),
    .SCD(rd_data[5]),
    .SCE(scan_en),
    .Q(rd_data[9]));
 sky130_fd_sc_hd__sdfrtp_2 _626_ (.CLK(clk),
    .D(\u_digital.read_data_next[10] ),
    .RESET_B(reset_n),
    .SCD(rd_data[6]),
    .SCE(scan_en),
    .Q(rd_data[10]));
 sky130_fd_sc_hd__sdfrtp_2 _627_ (.CLK(clk),
    .D(\u_digital.read_data_next[11] ),
    .RESET_B(reset_n),
    .SCD(rd_data[7]),
    .SCE(scan_en),
    .Q(rd_data[11]));
 sky130_fd_sc_hd__sdfrtp_2 _628_ (.CLK(clk),
    .D(\u_digital.read_data_next[12] ),
    .RESET_B(reset_n),
    .SCD(rd_data[8]),
    .SCE(scan_en),
    .Q(rd_data[12]));
 sky130_fd_sc_hd__sdfrtp_2 _629_ (.CLK(clk),
    .D(\u_digital.read_data_next[13] ),
    .RESET_B(reset_n),
    .SCD(rd_data[9]),
    .SCE(scan_en),
    .Q(rd_data[13]));
 sky130_fd_sc_hd__sdfrtp_2 _630_ (.CLK(clk),
    .D(\u_digital.read_data_next[14] ),
    .RESET_B(reset_n),
    .SCD(rd_data[10]),
    .SCE(scan_en),
    .Q(rd_data[14]));
 sky130_fd_sc_hd__sdfrtp_2 _631_ (.CLK(clk),
    .D(\u_digital.read_data_next[15] ),
    .RESET_B(reset_n),
    .SCD(rd_data[11]),
    .SCE(scan_en),
    .Q(rd_data[15]));
 assign scan_out[0] = rd_data[12];
 assign scan_out[1] = rd_data[13];
 assign scan_out[2] = rd_data[14];
 assign scan_out[3] = rd_data[15];
endmodule
