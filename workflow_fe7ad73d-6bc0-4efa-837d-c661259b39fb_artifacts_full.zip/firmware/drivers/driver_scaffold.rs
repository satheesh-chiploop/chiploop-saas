use crate::hal::registers::*;

pub struct DigitalSubsystemDriver;

impl DigitalSubsystemDriver {
    #[inline]
    pub const fn new() -> Self {
        Self
    }

    #[inline]
    pub fn read_ctrl(&self) -> u32 {
        read_ctrl()
    }

    #[inline]
    pub fn write_ctrl(&self, value: u32) {
        write_ctrl(value)
    }

    #[inline]
    pub fn get_ctrl_enable(&self) -> bool {
        get_ctrl_enable() != 0
    }

    #[inline]
    pub fn set_ctrl_enable(&self, value: bool) {
        set_ctrl_enable(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_ctrl_mode_select(&self) -> u8 {
        get_ctrl_mode_select() as u8
    }

    #[inline]
    pub fn set_ctrl_mode_select(&self, value: u8) {
        set_ctrl_mode_select(value as u32)
    }

    #[inline]
    pub fn get_ctrl_status_clear(&self) -> bool {
        get_ctrl_status_clear() != 0
    }

    #[inline]
    pub fn set_ctrl_status_clear(&self, value: bool) {
        set_ctrl_status_clear(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_ctrl_update_strobe(&self) -> bool {
        get_ctrl_update_strobe() != 0
    }

    #[inline]
    pub fn set_ctrl_update_strobe(&self, value: bool) {
        set_ctrl_update_strobe(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_ctrl_reserved0(&self) -> u32 {
        get_ctrl_reserved0() as u32
    }

    #[inline]
    pub fn read_timeout(&self) -> u32 {
        read_timeout()
    }

    #[inline]
    pub fn write_timeout(&self, value: u32) {
        write_timeout(value)
    }

    #[inline]
    pub fn get_timeout_timeout_cycles(&self) -> u32 {
        get_timeout_timeout_cycles() as u32
    }

    #[inline]
    pub fn set_timeout_timeout_cycles(&self, value: u32) {
        set_timeout_timeout_cycles(value as u32)
    }

    #[inline]
    pub fn get_timeout_seq_seed(&self) -> u32 {
        get_timeout_seq_seed() as u32
    }

    #[inline]
    pub fn set_timeout_seq_seed(&self, value: u32) {
        set_timeout_seq_seed(value as u32)
    }

    #[inline]
    pub fn read_limits(&self) -> u32 {
        read_limits()
    }

    #[inline]
    pub fn write_limits(&self, value: u32) {
        write_limits(value)
    }

    #[inline]
    pub fn get_limits_min_cmd(&self) -> u16 {
        get_limits_min_cmd() as u16
    }

    #[inline]
    pub fn set_limits_min_cmd(&self, value: u16) {
        set_limits_min_cmd(value as u32)
    }

    #[inline]
    pub fn get_limits_max_cmd(&self) -> u16 {
        get_limits_max_cmd() as u16
    }

    #[inline]
    pub fn set_limits_max_cmd(&self, value: u16) {
        set_limits_max_cmd(value as u32)
    }

    #[inline]
    pub fn get_limits_rate_limit(&self) -> u16 {
        get_limits_rate_limit() as u16
    }

    #[inline]
    pub fn set_limits_rate_limit(&self, value: u16) {
        set_limits_rate_limit(value as u32)
    }

    #[inline]
    pub fn get_limits_reserved1(&self) -> u16 {
        get_limits_reserved1() as u16
    }

    #[inline]
    pub fn read_status(&self) -> u32 {
        read_status()
    }

    #[inline]
    pub fn get_status_busy(&self) -> bool {
        get_status_busy() != 0
    }

    #[inline]
    pub fn get_status_fresh_response(&self) -> bool {
        get_status_fresh_response() != 0
    }

    #[inline]
    pub fn get_status_stale_fault(&self) -> bool {
        get_status_stale_fault() != 0
    }

    #[inline]
    pub fn get_status_timeout_fault(&self) -> bool {
        get_status_timeout_fault() != 0
    }

    #[inline]
    pub fn get_status_format_fault(&self) -> bool {
        get_status_format_fault() != 0
    }

    #[inline]
    pub fn get_status_clamp_active(&self) -> bool {
        get_status_clamp_active() != 0
    }

    #[inline]
    pub fn get_status_fallback_active(&self) -> bool {
        get_status_fallback_active() != 0
    }

    #[inline]
    pub fn get_status_last_seq_id(&self) -> u16 {
        get_status_last_seq_id() as u16
    }

    #[inline]
    pub fn get_status_safe_mode(&self) -> bool {
        get_status_safe_mode() != 0
    }

    #[inline]
    pub fn get_status_reserved2(&self) -> u32 {
        get_status_reserved2() as u32
    }

}
