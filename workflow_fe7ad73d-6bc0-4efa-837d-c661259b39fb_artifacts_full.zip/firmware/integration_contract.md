# Firmware Integration Contract: intelligent_active_aerodynamics_controller

## 1) Contract overview
- Target platform: `ulx3s_ecp5_45f_esp32`
- Deployment architecture: `fpga_onboard_cpu` with ESP32 firmware acting as SPI transport controller to FPGA fabric.
- Approved transport: SPI mode 0, MSB-first, 10 MHz max, 27-byte fixed frame, 1 µs minimum inter-frame delay.
- Firmware scope: host-side control, framing, command commit, response capture, safety reporting, and telemetry exposure.
- Register/transport contract is mailbox-based: command data is held stable until synchronized commit on chip-select rise.
- Response latency is fixed at 2 frames; response data is snapshot-held stable for complete SPI frames.
- Do not claim deployable system availability beyond this contract; platform gate status is `ready`, but firmware must still conform to this interface contract before release.
- No device-layer jobs are assigned in the spec; integration is interface-driven only.

## 2) Contract version + compatibility policy
- **Contract name:** `chiploop.application_intelligence.target_refinement.v1`
- **Contract version:** `v1`
- **Compatibility policy:** backward-compatible within `v1` for:
  - unchanged frame size, bit ordering, and commit semantics
  - preserved register addresses and field widths
  - additive-only status/telemetry fields, provided serialized bit counts remain unchanged
- **Breaking changes require:** new major version and explicit re-validation of frame maps, timing, and safety behavior.
- **Firmware implementation rule:** any mismatch between firmware frame packing and RTL collateral is a contract violation, not a tolerated runtime variation.

## 3) Interfaces

### 3.1 Interface summary

| Interface | Purpose | Data types | Mapped targets | FW role |
|---|---|---|---|---|
| `geometry_input_interface` | Accept vehicle geometry and metadata | STL, structured metadata | software, cpu_software | consume/forward; no geometry parsing in transport layer |
| `operating_condition_interface` | Provide stream velocity and environmental inputs | numeric scalar, structured configuration | software, cpu_software | consume/forward; condition snapshot may influence command generation |
| `surrogate_and_reference_output_interface` | Expose aerodynamic estimates and reference outputs | numeric fields, diagnostic fields | gpu_service, cpu_software | expose via response/telemetry path when available |
| `control_command_interface` | Deliver actuator commands and command metadata | bounded numeric commands, timestamps, status flags | fpga, firmware | primary owned interface; frame-pack and commit commands |
| `safety_status_interface` | Report stale-data detection, timeout handling, clamping, fallback activation | boolean flags, error codes, health metrics | fpga, firmware, software | primary owned interface; generate and report safety state |
| `validation_and_telemetry_interface` | Expose validation results, diagnostics, regression evidence | metrics, logs, test summaries | software, cpu_software | firmware emits minimal diagnostics; validation system owns collection and analysis |

### 3.2 SPI transport frame contract

| Item | Value |
|---|---|
| Transport | `spi_mode_0_shift_transport` |
| Frame size | 216 bits total |
| Frame bytes | 27 bytes |
| Serialized input bits | 204 |
| Serialized output bits | 213 |
| Command leading padding | 12 bits |
| Response trailing padding | 3 bits |
| Bit order | MSB-first byte-aligned full-duplex |
| SPI max clock | 10.0 MHz |
| Minimum inter-frame delay | 1 µs |
| Transaction model | Command `N` commits on CS rising edge; response `N` is read in frame `N+2` |
| CDC model | Bundled-data mailboxes held stable between frame commits |
| Command data path | Held stable until synchronized commit |
| Control path | `spi_cs_n` two-flop synchronized into core clock |
| Reset release | Asynchronous assertion, synchronous two-flop release |
| Response data path | Snapshot-held stable for complete SPI frames |

### 3.3 Input bit map

| LSB | Port | Width | Notes |
|---:|---|---:|---|
| 0 | `reg_addr` | 8 | Register address |
| 8 | `reg_wdata` | 64 | Write data payload |
| 72 | `reg_valid` | 1 | Valid qualifier |
| 73 | `reg_write_en` | 1 | Write enable |
| 74 | `req_stream_ready` | 1 | Downstream ready indication |
| 75 | `resp_stream_valid` | 1 | Response valid indication |
| 76 | `resp_stream_data` | 128 | Response data payload |

### 3.4 Output bit map

| LSB | Port | Width | Notes |
|---:|---|---:|---|
| 149 | `reg_rdata` | 64 | Read data payload |
| 148 | `reg_ready` | 1 | Register access ready |
| 147 | `req_stream_valid` | 1 | Request valid indication |
| 19 | `req_stream_data` | 128 | Request data payload |
| 18 | `resp_stream_ready` | 1 | Response ready indication |
| 2 | `actuator_cmd` | 16 | Downstream actuator command |
| 1 | `status_irq` | 1 | Status interrupt/event flag |
| 0 | `safe_mode` | 1 | Safe-mode indicator |

## 4) Ownership boundaries

| Area | Firmware | System/Host | Validation |
|---|---|---|---|
| SPI framing and bit packing | Owns | Consumes contract | Verifies bit-accurate packing |
| Register commit timing | Owns | Must respect commit semantics | Tests CS-rise commit behavior |
| Safety state generation | Owns | May observe and log | Checks stale/timeout/clamp/fallback cases |
| Geometry ingestion | No parsing beyond transport handoff | Owns content preparation | Confirms metadata reachability |
| Operating condition ingestion | Owns transport delivery | Owns source correctness | Validates freshness and range |
| Surrogate/reference outputs | Owns exposure path | Consumes for control/analysis | Compares against expected outputs |
| Regression evidence collection | Minimal emit only | Owns storage/reporting | Owns pass/fail criteria and traceability |

## 5) Assumptions
- ESP32 firmware uses ESP-IDF with CMake and `idf_target=esp32`.
- SPI wiring follows the provided GPIO mapping:
  - SCLK GPIO14
  - CS_N GPIO13
  - MOSI GPIO15
  - MISO GPIO2
- FPGA peripheral implements the provided register and stream bit maps exactly.
- No extra DMA, interrupt, or power-mode requirements were provided beyond the transport contract, so they are out of scope for this document.
- `deployable_binary_ready=true` in the refinement metadata is accepted only as platform readiness; release still depends on contract-conformant implementation and validation.
- `safe_mode` must be asserted by firmware when contract violations, stale inputs, or transport faults are detected.
- `status_irq` is treated as an observable status event flag; exact IRQ servicing model is not specified here.

## 6) Validation hooks
- **Frame packing test:** verify 27-byte SPI frames, MSB-first ordering, and exact input/output bit placement against the bit maps.
- **Commit semantics test:** assert that a command becomes visible to the FPGA only on CS rising edge.
- **Latency test:** confirm response `N` is returned in frame `N+2` and remains stable across the full frame.
- **Clocking test:** run SPI at 10 MHz max and verify no contract violations at or below limit.
- **Inter-frame timing test:** enforce minimum 1 µs gap between frames.
- **Safety tests:** inject stale data, timeout, clamping, and fallback conditions and verify `safe_mode`, `status_irq`, and safety status reporting.
- **Read/write register test:** confirm `reg_ready`, `reg_rdata`, `reg_valid`, and `reg_write_en` behavior matches the collateral.
- **Regression evidence test:** record frame traces, status snapshots, and pass/fail summaries under `validation_and_telemetry_interface`.
- **Compatibility test:** verify that any firmware update preserves `v1` framing, widths, and transaction semantics.