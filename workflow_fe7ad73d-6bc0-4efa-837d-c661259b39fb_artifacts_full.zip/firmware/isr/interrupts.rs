// ASSUMPTION: Interrupt decode is software-mediated using firmware-visible status/interrupt bits.
// ASSUMPTION: No MCU-style external vector table is generated unless the hardware contract explicitly requires one.

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum InterruptSource {
    StaleFault,
    TimeoutFault,
    FormatFault,
}

#[inline]
pub fn interrupt_count() -> usize {
    3
}

pub const STALE_FAULT_BIT: u32 = 0;
pub const TIMEOUT_FAULT_BIT: u32 = 1;
pub const FORMAT_FAULT_BIT: u32 = 2;

#[inline]
pub fn handle_stale_fault() {
    // Default ISR scaffold: replace with concrete firmware behavior as needed.
}

#[inline]
pub fn handle_timeout_fault() {
    // Default ISR scaffold: replace with concrete firmware behavior as needed.
}

#[inline]
pub fn handle_format_fault() {
    // Default ISR scaffold: replace with concrete firmware behavior as needed.
}

#[inline]
pub fn dispatch_interrupt(bit_index: u32) -> bool {
    match bit_index {
        STALE_FAULT_BIT => { handle_stale_fault(); true }
        TIMEOUT_FAULT_BIT => { handle_timeout_fault(); true }
        FORMAT_FAULT_BIT => { handle_format_fault(); true }
        _ => false,
    }
}
