use core::ptr::{read_volatile, write_volatile};

pub const BASE_ADDRESS: usize = 0x00000000;

pub const CTRL_OFFSET: usize = 0x00000000;
pub const CTRL_ENABLE_SHIFT: u32 = 0;
pub const CTRL_ENABLE_WIDTH: u32 = 1;
pub const CTRL_ENABLE_MASK: u64 = 0x0000000000000001;
pub const CTRL_MODE_SELECT_SHIFT: u32 = 1;
pub const CTRL_MODE_SELECT_WIDTH: u32 = 3;
pub const CTRL_MODE_SELECT_MASK: u64 = 0x000000000000000E;
pub const CTRL_STATUS_CLEAR_SHIFT: u32 = 4;
pub const CTRL_STATUS_CLEAR_WIDTH: u32 = 1;
pub const CTRL_STATUS_CLEAR_MASK: u64 = 0x0000000000000010;
pub const CTRL_UPDATE_STROBE_SHIFT: u32 = 5;
pub const CTRL_UPDATE_STROBE_WIDTH: u32 = 1;
pub const CTRL_UPDATE_STROBE_MASK: u64 = 0x0000000000000020;
pub const CTRL_RESERVED0_SHIFT: u32 = 6;
pub const CTRL_RESERVED0_WIDTH: u32 = 58;
pub const CTRL_RESERVED0_MASK: u64 = 0xFFFFFFFFFFFFFFC0;
pub const TIMEOUT_OFFSET: usize = 0x00000008;
pub const TIMEOUT_TIMEOUT_CYCLES_SHIFT: u32 = 0;
pub const TIMEOUT_TIMEOUT_CYCLES_WIDTH: u32 = 32;
pub const TIMEOUT_TIMEOUT_CYCLES_MASK: u64 = 0x00000000FFFFFFFF;
pub const TIMEOUT_SEQ_SEED_SHIFT: u32 = 32;
pub const TIMEOUT_SEQ_SEED_WIDTH: u32 = 32;
pub const TIMEOUT_SEQ_SEED_MASK: u64 = 0xFFFFFFFF00000000;
pub const LIMITS_OFFSET: usize = 0x00000010;
pub const LIMITS_MIN_CMD_SHIFT: u32 = 0;
pub const LIMITS_MIN_CMD_WIDTH: u32 = 16;
pub const LIMITS_MIN_CMD_MASK: u64 = 0x000000000000FFFF;
pub const LIMITS_MAX_CMD_SHIFT: u32 = 16;
pub const LIMITS_MAX_CMD_WIDTH: u32 = 16;
pub const LIMITS_MAX_CMD_MASK: u64 = 0x00000000FFFF0000;
pub const LIMITS_RATE_LIMIT_SHIFT: u32 = 32;
pub const LIMITS_RATE_LIMIT_WIDTH: u32 = 16;
pub const LIMITS_RATE_LIMIT_MASK: u64 = 0x0000FFFF00000000;
pub const LIMITS_RESERVED1_SHIFT: u32 = 48;
pub const LIMITS_RESERVED1_WIDTH: u32 = 16;
pub const LIMITS_RESERVED1_MASK: u64 = 0xFFFF000000000000;
pub const STATUS_OFFSET: usize = 0x00000018;
pub const STATUS_BUSY_SHIFT: u32 = 0;
pub const STATUS_BUSY_WIDTH: u32 = 1;
pub const STATUS_BUSY_MASK: u64 = 0x0000000000000001;
pub const STATUS_FRESH_RESPONSE_SHIFT: u32 = 1;
pub const STATUS_FRESH_RESPONSE_WIDTH: u32 = 1;
pub const STATUS_FRESH_RESPONSE_MASK: u64 = 0x0000000000000002;
pub const STATUS_STALE_FAULT_SHIFT: u32 = 2;
pub const STATUS_STALE_FAULT_WIDTH: u32 = 1;
pub const STATUS_STALE_FAULT_MASK: u64 = 0x0000000000000004;
pub const STATUS_TIMEOUT_FAULT_SHIFT: u32 = 3;
pub const STATUS_TIMEOUT_FAULT_WIDTH: u32 = 1;
pub const STATUS_TIMEOUT_FAULT_MASK: u64 = 0x0000000000000008;
pub const STATUS_FORMAT_FAULT_SHIFT: u32 = 4;
pub const STATUS_FORMAT_FAULT_WIDTH: u32 = 1;
pub const STATUS_FORMAT_FAULT_MASK: u64 = 0x0000000000000010;
pub const STATUS_CLAMP_ACTIVE_SHIFT: u32 = 5;
pub const STATUS_CLAMP_ACTIVE_WIDTH: u32 = 1;
pub const STATUS_CLAMP_ACTIVE_MASK: u64 = 0x0000000000000020;
pub const STATUS_FALLBACK_ACTIVE_SHIFT: u32 = 6;
pub const STATUS_FALLBACK_ACTIVE_WIDTH: u32 = 1;
pub const STATUS_FALLBACK_ACTIVE_MASK: u64 = 0x0000000000000040;
pub const STATUS_LAST_SEQ_ID_SHIFT: u32 = 16;
pub const STATUS_LAST_SEQ_ID_WIDTH: u32 = 16;
pub const STATUS_LAST_SEQ_ID_MASK: u64 = 0x00000000FFFF0000;
pub const STATUS_SAFE_MODE_SHIFT: u32 = 32;
pub const STATUS_SAFE_MODE_WIDTH: u32 = 1;
pub const STATUS_SAFE_MODE_MASK: u64 = 0x0000000100000000;
pub const STATUS_RESERVED2_SHIFT: u32 = 33;
pub const STATUS_RESERVED2_WIDTH: u32 = 31;
pub const STATUS_RESERVED2_MASK: u64 = 0xFFFFFFFE00000000;

#[inline]
fn reg_ptr(offset: usize) -> *mut u64 {
    (BASE_ADDRESS + offset) as *mut u64
}

#[inline]
fn read_reg(offset: usize) -> u64 {
    unsafe { read_volatile(reg_ptr(offset) as *const u64) }
}

#[inline]
fn write_reg(offset: usize, value: u64) {
    unsafe { write_volatile(reg_ptr(offset), value) }
}

#[inline]
pub fn read_ctrl() -> u64 {
    read_reg(CTRL_OFFSET)
}

#[inline]
pub fn write_ctrl(value: u64) {
    write_reg(CTRL_OFFSET, value)
}

#[inline]
pub fn get_ctrl_enable() -> u64 {
    (read_ctrl() & CTRL_ENABLE_MASK) >> CTRL_ENABLE_SHIFT
}

#[inline]
pub fn set_ctrl_enable(value: u64) {
    let current = read_ctrl();
    let next = (current & !CTRL_ENABLE_MASK) | ((value << CTRL_ENABLE_SHIFT) & CTRL_ENABLE_MASK);
    write_ctrl(next);
}

#[inline]
pub fn get_ctrl_mode_select() -> u64 {
    (read_ctrl() & CTRL_MODE_SELECT_MASK) >> CTRL_MODE_SELECT_SHIFT
}

#[inline]
pub fn set_ctrl_mode_select(value: u64) {
    let current = read_ctrl();
    let next = (current & !CTRL_MODE_SELECT_MASK) | ((value << CTRL_MODE_SELECT_SHIFT) & CTRL_MODE_SELECT_MASK);
    write_ctrl(next);
}

#[inline]
pub fn get_ctrl_status_clear() -> u64 {
    (read_ctrl() & CTRL_STATUS_CLEAR_MASK) >> CTRL_STATUS_CLEAR_SHIFT
}

#[inline]
pub fn set_ctrl_status_clear(value: u64) {
    let current = read_ctrl();
    let next = (current & !CTRL_STATUS_CLEAR_MASK) | ((value << CTRL_STATUS_CLEAR_SHIFT) & CTRL_STATUS_CLEAR_MASK);
    write_ctrl(next);
}

#[inline]
pub fn get_ctrl_update_strobe() -> u64 {
    (read_ctrl() & CTRL_UPDATE_STROBE_MASK) >> CTRL_UPDATE_STROBE_SHIFT
}

#[inline]
pub fn set_ctrl_update_strobe(value: u64) {
    let current = read_ctrl();
    let next = (current & !CTRL_UPDATE_STROBE_MASK) | ((value << CTRL_UPDATE_STROBE_SHIFT) & CTRL_UPDATE_STROBE_MASK);
    write_ctrl(next);
}

#[inline]
pub fn get_ctrl_reserved0() -> u64 {
    (read_ctrl() & CTRL_RESERVED0_MASK) >> CTRL_RESERVED0_SHIFT
}

#[inline]
pub fn read_timeout() -> u64 {
    read_reg(TIMEOUT_OFFSET)
}

#[inline]
pub fn write_timeout(value: u64) {
    write_reg(TIMEOUT_OFFSET, value)
}

#[inline]
pub fn get_timeout_timeout_cycles() -> u64 {
    (read_timeout() & TIMEOUT_TIMEOUT_CYCLES_MASK) >> TIMEOUT_TIMEOUT_CYCLES_SHIFT
}

#[inline]
pub fn set_timeout_timeout_cycles(value: u64) {
    let current = read_timeout();
    let next = (current & !TIMEOUT_TIMEOUT_CYCLES_MASK) | ((value << TIMEOUT_TIMEOUT_CYCLES_SHIFT) & TIMEOUT_TIMEOUT_CYCLES_MASK);
    write_timeout(next);
}

#[inline]
pub fn get_timeout_seq_seed() -> u64 {
    (read_timeout() & TIMEOUT_SEQ_SEED_MASK) >> TIMEOUT_SEQ_SEED_SHIFT
}

#[inline]
pub fn set_timeout_seq_seed(value: u64) {
    let current = read_timeout();
    let next = (current & !TIMEOUT_SEQ_SEED_MASK) | ((value << TIMEOUT_SEQ_SEED_SHIFT) & TIMEOUT_SEQ_SEED_MASK);
    write_timeout(next);
}

#[inline]
pub fn read_limits() -> u64 {
    read_reg(LIMITS_OFFSET)
}

#[inline]
pub fn write_limits(value: u64) {
    write_reg(LIMITS_OFFSET, value)
}

#[inline]
pub fn get_limits_min_cmd() -> u64 {
    (read_limits() & LIMITS_MIN_CMD_MASK) >> LIMITS_MIN_CMD_SHIFT
}

#[inline]
pub fn set_limits_min_cmd(value: u64) {
    let current = read_limits();
    let next = (current & !LIMITS_MIN_CMD_MASK) | ((value << LIMITS_MIN_CMD_SHIFT) & LIMITS_MIN_CMD_MASK);
    write_limits(next);
}

#[inline]
pub fn get_limits_max_cmd() -> u64 {
    (read_limits() & LIMITS_MAX_CMD_MASK) >> LIMITS_MAX_CMD_SHIFT
}

#[inline]
pub fn set_limits_max_cmd(value: u64) {
    let current = read_limits();
    let next = (current & !LIMITS_MAX_CMD_MASK) | ((value << LIMITS_MAX_CMD_SHIFT) & LIMITS_MAX_CMD_MASK);
    write_limits(next);
}

#[inline]
pub fn get_limits_rate_limit() -> u64 {
    (read_limits() & LIMITS_RATE_LIMIT_MASK) >> LIMITS_RATE_LIMIT_SHIFT
}

#[inline]
pub fn set_limits_rate_limit(value: u64) {
    let current = read_limits();
    let next = (current & !LIMITS_RATE_LIMIT_MASK) | ((value << LIMITS_RATE_LIMIT_SHIFT) & LIMITS_RATE_LIMIT_MASK);
    write_limits(next);
}

#[inline]
pub fn get_limits_reserved1() -> u64 {
    (read_limits() & LIMITS_RESERVED1_MASK) >> LIMITS_RESERVED1_SHIFT
}

#[inline]
pub fn read_status() -> u64 {
    read_reg(STATUS_OFFSET)
}

#[inline]
pub fn get_status_busy() -> u64 {
    (read_status() & STATUS_BUSY_MASK) >> STATUS_BUSY_SHIFT
}

#[inline]
pub fn get_status_fresh_response() -> u64 {
    (read_status() & STATUS_FRESH_RESPONSE_MASK) >> STATUS_FRESH_RESPONSE_SHIFT
}

#[inline]
pub fn get_status_stale_fault() -> u64 {
    (read_status() & STATUS_STALE_FAULT_MASK) >> STATUS_STALE_FAULT_SHIFT
}

#[inline]
pub fn get_status_timeout_fault() -> u64 {
    (read_status() & STATUS_TIMEOUT_FAULT_MASK) >> STATUS_TIMEOUT_FAULT_SHIFT
}

#[inline]
pub fn get_status_format_fault() -> u64 {
    (read_status() & STATUS_FORMAT_FAULT_MASK) >> STATUS_FORMAT_FAULT_SHIFT
}

#[inline]
pub fn get_status_clamp_active() -> u64 {
    (read_status() & STATUS_CLAMP_ACTIVE_MASK) >> STATUS_CLAMP_ACTIVE_SHIFT
}

#[inline]
pub fn get_status_fallback_active() -> u64 {
    (read_status() & STATUS_FALLBACK_ACTIVE_MASK) >> STATUS_FALLBACK_ACTIVE_SHIFT
}

#[inline]
pub fn get_status_last_seq_id() -> u64 {
    (read_status() & STATUS_LAST_SEQ_ID_MASK) >> STATUS_LAST_SEQ_ID_SHIFT
}

#[inline]
pub fn get_status_safe_mode() -> u64 {
    (read_status() & STATUS_SAFE_MODE_MASK) >> STATUS_SAFE_MODE_SHIFT
}

#[inline]
pub fn get_status_reserved2() -> u64 {
    (read_status() & STATUS_RESERVED2_MASK) >> STATUS_RESERVED2_SHIFT
}

