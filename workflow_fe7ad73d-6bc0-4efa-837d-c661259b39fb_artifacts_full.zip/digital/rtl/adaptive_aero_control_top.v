module adaptive_aero_control_top (
    input         clk,
    input         clk_rst_n,
    input  [7:0] reg_addr,
    input  [63:0] reg_wdata,
    output [63:0] reg_rdata,
    input         reg_valid,
    input         reg_write_en,
    output        reg_ready,
    output        req_stream_valid,
    input         req_stream_ready,
    output [127:0] req_stream_data,
    input         resp_stream_valid,
    output        resp_stream_ready,
    input  [127:0] resp_stream_data,
    output [15:0] actuator_cmd,
    output        status_irq,
    output        safe_mode
);

    localparam [7:0] ADDR_CTRL    = 8'h00;
    localparam [7:0] ADDR_TIMEOUT = 8'h08;
    localparam [7:0] ADDR_LIMITS  = 8'h10;
    localparam [7:0] ADDR_STATUS  = 8'h18;

    localparam [2:0] ST_IDLE     = 3'd0;
    localparam [2:0] ST_ISSUE_REQ = 3'd1;
    localparam [2:0] ST_WAIT_RESP = 3'd2;
    localparam [2:0] ST_APPLY_RESP= 3'd3;
    localparam [2:0] ST_FAULT     = 3'd4;

    reg [2:0]  state;
    reg [2:0]  next_state;

    reg        enable_reg;
    reg [2:0]  mode_select_reg;
    reg [31:0] timeout_cycles_reg;
    reg [31:0] seq_seed_reg;
    reg [15:0] min_cmd_reg;
    reg [15:0] max_cmd_reg;
    reg [15:0] rate_limit_reg;

    reg        busy_reg;
    reg        fresh_response_reg;
    reg        stale_fault_reg;
    reg        timeout_fault_reg;
    reg        format_fault_reg;
    reg        clamp_active_reg;
    reg        fallback_active_reg;
    reg [15:0] last_seq_id_reg;
    reg        safe_mode_reg;

    reg [15:0] sequence_reg;
    reg [15:0] outstanding_seq_reg;
    reg [31:0] timeout_cnt_reg;
    reg [15:0] current_cmd_reg;
    reg [15:0] pending_cmd_reg;
    reg [15:0] last_applied_cmd_reg;
    reg        req_valid_reg;
    reg [127:0] req_data_reg;
    reg [63:0] reg_rdata_reg;
    reg        reg_ready_reg;
    reg        resp_ready_reg;
    reg        status_irq_reg;
    reg [15:0] actuator_cmd_reg;
    wire reg_access;
    wire reg_write;
    wire reg_read;
    wire request_fire;
    wire response_fire;
    wire response_seq_match;
    wire response_format_ok;
    wire response_fresh_ok;
    wire timeout_hit;
    wire config_update;
    wire status_clear_pulse;

    assign reg_access = reg_valid;
    assign reg_write  = reg_valid & reg_write_en;
    assign reg_read   = reg_valid & ~reg_write_en;
    assign request_fire = req_valid_reg & req_stream_ready;
    assign response_fire = resp_stream_valid & resp_ready_reg;
    assign response_seq_match = (resp_stream_data[15:0] == outstanding_seq_reg);
    assign response_format_ok = (resp_stream_data[31:24] == 8'hA5) && (resp_stream_data[23:16] <= 8'hFF);
    assign response_fresh_ok = response_seq_match & response_format_ok & ~timeout_hit;
    assign timeout_hit = busy_reg && (timeout_cycles_reg != 32'd0) && (timeout_cnt_reg >= timeout_cycles_reg);
    assign config_update = reg_write && (reg_addr == ADDR_CTRL) && reg_wdata[5];
    assign status_clear_pulse = reg_write && (reg_addr == ADDR_CTRL) && reg_wdata[4];

    assign reg_rdata = reg_rdata_reg;
    assign reg_ready = reg_ready_reg;
    assign req_stream_valid = req_valid_reg;
    assign req_stream_data = req_data_reg;
    assign resp_stream_ready = resp_ready_reg;
    assign actuator_cmd = actuator_cmd_reg;
    assign status_irq = status_irq_reg;
    assign safe_mode = safe_mode_reg;

    always @(*) begin
        next_state = state;
        reg_ready_reg = 1'b1;
        resp_ready_reg = 1'b0;
        reg_rdata_reg = 64'd0;
        status_irq_reg = stale_fault_reg | timeout_fault_reg | format_fault_reg | (fallback_active_reg & ~safe_mode_reg);

        case (state)
            ST_IDLE: begin
                resp_ready_reg = enable_reg;
                if (reg_access && reg_read) begin
                    case (reg_addr)
                        ADDR_CTRL:    reg_rdata_reg = {55'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, mode_select_reg, enable_reg};
                        ADDR_TIMEOUT: reg_rdata_reg = {seq_seed_reg, timeout_cycles_reg};
                        ADDR_LIMITS:  reg_rdata_reg = {16'd0, rate_limit_reg, max_cmd_reg, min_cmd_reg};
                        ADDR_STATUS:   reg_rdata_reg = {8'b0, 31'd0, safe_mode_reg, last_seq_id_reg, 1'b0, fallback_active_reg, clamp_active_reg, format_fault_reg, timeout_fault_reg, stale_fault_reg, fresh_response_reg, busy_reg};
                        default:       reg_rdata_reg = 64'd0;
                    endcase
                end
                if (config_update && enable_reg) begin
                    next_state = ST_ISSUE_REQ;
                end
            end
            ST_ISSUE_REQ: begin
                resp_ready_reg = 1'b0;
                if (request_fire) begin
                    next_state = ST_WAIT_RESP;
                end
            end
            ST_WAIT_RESP: begin
                resp_ready_reg = enable_reg;
                if (response_fire) begin
                    if (response_fresh_ok) begin
                        next_state = ST_APPLY_RESP;
                    end else begin
                        next_state = ST_FAULT;
                    end
                end else if (timeout_hit) begin
                    next_state = ST_FAULT;
                end
            end
            ST_APPLY_RESP: begin
                resp_ready_reg = 1'b0;
                next_state = ST_IDLE;
            end
            ST_FAULT: begin
                resp_ready_reg = 1'b0;
                next_state = ST_FAULT;
            end
            default: begin
                next_state = ST_IDLE;
                resp_ready_reg = 1'b0;
            end
        endcase
    end

    always @(posedge clk or negedge clk_rst_n) begin
        if (!clk_rst_n) begin
            state <= ST_IDLE;
            enable_reg <= 1'b0;
            mode_select_reg <= 3'd0;
            timeout_cycles_reg <= 32'd1024;
            seq_seed_reg <= 32'd1;
            min_cmd_reg <= 16'd0;
            max_cmd_reg <= 16'hFFFF;
            rate_limit_reg <= 16'd0;
            busy_reg <= 1'b0;
            fresh_response_reg <= 1'b0;
            stale_fault_reg <= 1'b0;
            timeout_fault_reg <= 1'b0;
            format_fault_reg <= 1'b0;
            clamp_active_reg <= 1'b0;
            fallback_active_reg <= 1'b0;
            last_seq_id_reg <= 16'd0;
            safe_mode_reg <= 1'b1;
            sequence_reg <= 16'd0;
            outstanding_seq_reg <= 16'd0;
            timeout_cnt_reg <= 32'd0;
            current_cmd_reg <= 16'd0;
            pending_cmd_reg <= 16'd0;
            last_applied_cmd_reg <= 16'd0;
            req_valid_reg <= 1'b0;
            req_data_reg <= 128'd0;
            actuator_cmd_reg <= 16'd0;
        end else begin
            state <= next_state;

            fresh_response_reg <= 1'b0;

            if (reg_write && (reg_addr == ADDR_CTRL)) begin
                if (!enable_reg || reg_wdata[5]) begin
                    enable_reg <= reg_wdata[0];
                    mode_select_reg <= reg_wdata[3:1];
                end
                if (reg_wdata[4]) begin
                    stale_fault_reg <= 1'b0;
                    timeout_fault_reg <= 1'b0;
                    format_fault_reg <= 1'b0;
                    fallback_active_reg <= 1'b0;
                    clamp_active_reg <= 1'b0;
                    safe_mode_reg <= 1'b1;
                end
            end

            if (reg_write && (reg_addr == ADDR_TIMEOUT)) begin
                if (!enable_reg || reg_wdata[5]) begin
                    timeout_cycles_reg <= reg_wdata[31:0];
                    seq_seed_reg <= reg_wdata[63:32];
                end
            end

            if (reg_write && (reg_addr == ADDR_LIMITS)) begin
                if (!enable_reg || reg_wdata[5]) begin
                    min_cmd_reg <= reg_wdata[15:0];
                    max_cmd_reg <= reg_wdata[31:16];
                    rate_limit_reg <= reg_wdata[47:32];
                end
            end

            if (state == ST_IDLE) begin
                busy_reg <= 1'b0;
                req_valid_reg <= 1'b0;
                timeout_cnt_reg <= 32'd0;
                if (config_update && enable_reg) begin
                    busy_reg <= 1'b1;
                    req_valid_reg <= 1'b1;
                    outstanding_seq_reg <= sequence_reg;
                    last_seq_id_reg <= sequence_reg;
                    req_data_reg <= {seq_seed_reg, 16'd0, mode_select_reg, timeout_cycles_reg, min_cmd_reg, max_cmd_reg, rate_limit_reg, sequence_reg, 64'd0};
                    sequence_reg <= sequence_reg + 16'd1;
                    safe_mode_reg <= 1'b1;
                    fallback_active_reg <= 1'b1;
                end
            end else if (state == ST_ISSUE_REQ) begin
                busy_reg <= 1'b1;
                if (req_valid_reg && req_stream_ready) begin
                    req_valid_reg <= 1'b0;
                    timeout_cnt_reg <= 32'd0;
                end
            end else if (state == ST_WAIT_RESP) begin
                busy_reg <= 1'b1;
                timeout_cnt_reg <= timeout_cnt_reg + 32'd1;
                if (resp_stream_valid && resp_ready_reg) begin
                    if (response_fresh_ok) begin
                        pending_cmd_reg <= resp_stream_data[15:0];
                    end else begin
                        if (response_seq_match) begin
                            format_fault_reg <= 1'b1;
                        end else begin
                            stale_fault_reg <= 1'b1;
                        end
                        fallback_active_reg <= 1'b1;
                        safe_mode_reg <= 1'b1;
                    end
                end else if (timeout_hit) begin
                    timeout_fault_reg <= 1'b1;
                    fallback_active_reg <= 1'b1;
                    safe_mode_reg <= 1'b1;
                end
            end else if (state == ST_APPLY_RESP) begin
                busy_reg <= 1'b0;
                fresh_response_reg <= 1'b1;
                current_cmd_reg <= pending_cmd_reg;
                if (pending_cmd_reg < min_cmd_reg) begin
                    current_cmd_reg <= min_cmd_reg;
                    clamp_active_reg <= 1'b1;
                end else if (pending_cmd_reg > max_cmd_reg) begin
                    current_cmd_reg <= max_cmd_reg;
                    clamp_active_reg <= 1'b1;
                end else begin
                    clamp_active_reg <= 1'b0;
                end
                if (rate_limit_reg != 16'd0) begin
                    if (pending_cmd_reg > last_applied_cmd_reg) begin
                        if ((pending_cmd_reg - last_applied_cmd_reg) > rate_limit_reg) begin
                            current_cmd_reg <= last_applied_cmd_reg + rate_limit_reg;
                            clamp_active_reg <= 1'b1;
                        end
                    end else if ((last_applied_cmd_reg - pending_cmd_reg) > rate_limit_reg) begin
                        current_cmd_reg <= last_applied_cmd_reg - rate_limit_reg;
                        clamp_active_reg <= 1'b1;
                    end
                end
                last_applied_cmd_reg <= current_cmd_reg;
                actuator_cmd_reg <= current_cmd_reg;
                safe_mode_reg <= 1'b0;
                fallback_active_reg <= 1'b0;
            end else begin
                busy_reg <= 1'b0;
                req_valid_reg <= 1'b0;
                fallback_active_reg <= 1'b1;
                safe_mode_reg <= 1'b1;
            end
        end
    end

endmodule
