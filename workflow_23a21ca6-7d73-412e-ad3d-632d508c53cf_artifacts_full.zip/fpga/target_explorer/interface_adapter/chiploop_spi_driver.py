"""Generated ChipLoop SPI Mode-0 host transport.

Command N is committed when chip-select rises.  The response visible during
that exchange is the previous core snapshot, so callers should pipeline or
perform a second exchange when they need the response to command N.
"""
from typing import Callable, Mapping

INPUT_BITS = 135
OUTPUT_BITS = 177
FRAME_BITS = 177
FRAME_BYTES = (FRAME_BITS + 7) // 8
INPUT_MAP = [{'port': 'reg_wr_en', 'width': 1, 'lsb': 0}, {'port': 'reg_rd_en', 'width': 1, 'lsb': 1}, {'port': 'reg_addr', 'width': 8, 'lsb': 2}, {'port': 'reg_wdata', 'width': 64, 'lsb': 10}, {'port': 'sensor_valid', 'width': 1, 'lsb': 74}, {'port': 'sensor_speed_mps', 'width': 16, 'lsb': 75}, {'port': 'sensor_health', 'width': 8, 'lsb': 91}, {'port': 'model_req_ready', 'width': 1, 'lsb': 99}, {'port': 'model_rsp_valid', 'width': 1, 'lsb': 100}, {'port': 'model_rsp_data', 'width': 32, 'lsb': 101}, {'port': 'actuator_cmd_ready', 'width': 1, 'lsb': 133}, {'port': 'heartbeat_in', 'width': 1, 'lsb': 134}]
OUTPUT_MAP = [{'port': 'reg_rdata', 'width': 64, 'lsb': 113}, {'port': 'reg_ready', 'width': 1, 'lsb': 112}, {'port': 'sensor_ready', 'width': 1, 'lsb': 111}, {'port': 'model_req_valid', 'width': 1, 'lsb': 110}, {'port': 'model_req_data', 'width': 32, 'lsb': 78}, {'port': 'model_rsp_ready', 'width': 1, 'lsb': 77}, {'port': 'actuator_cmd_valid', 'width': 1, 'lsb': 76}, {'port': 'actuator_cmd_data', 'width': 32, 'lsb': 44}, {'port': 'status_busy', 'width': 1, 'lsb': 43}, {'port': 'status_ready', 'width': 1, 'lsb': 42}, {'port': 'status_enabled', 'width': 1, 'lsb': 41}, {'port': 'status_mode', 'width': 3, 'lsb': 38}, {'port': 'status_speed_mps', 'width': 16, 'lsb': 22}, {'port': 'status_stale_fault', 'width': 1, 'lsb': 21}, {'port': 'status_timeout_fault', 'width': 1, 'lsb': 20}, {'port': 'status_invalid_cmd_fault', 'width': 1, 'lsb': 19}, {'port': 'status_clamp_event', 'width': 1, 'lsb': 18}, {'port': 'status_fallback_active', 'width': 1, 'lsb': 17}, {'port': 'status_last_seq', 'width': 16, 'lsb': 1}, {'port': 'irq', 'width': 1, 'lsb': 0}]

def _mask(width: int) -> int:
    return (1 << width) - 1

def pack_command(values: Mapping[str, int]) -> bytes:
    frame = 0
    for field in INPUT_MAP:
        value = int(values.get(field["port"], 0))
        if value < 0 or value > _mask(field["width"]):
            raise ValueError(f'{field["port"]} exceeds {field["width"]} bits')
        frame |= value << field["lsb"]
    return frame.to_bytes(FRAME_BYTES, "big")

def unpack_response(raw: bytes) -> dict[str, int]:
    if len(raw) != FRAME_BYTES:
        raise ValueError(f"expected {FRAME_BYTES} response bytes, got {len(raw)}")
    # Response bits leave the FPGA first and are followed by zero padding when
    # the command side determines a longer full-duplex frame.
    value = int.from_bytes(raw, "big") >> (FRAME_BYTES * 8 - OUTPUT_BITS)
    return {field["port"]: (value >> field["lsb"]) & _mask(field["width"]) for field in OUTPUT_MAP}

class ChipLoopSpiDevice:
    def __init__(self, transfer: Callable[[bytes], bytes]):
        self._transfer = transfer

    def exchange(self, values: Mapping[str, int]) -> dict[str, int]:
        response = self._transfer(pack_command(values))
        return unpack_response(response)
