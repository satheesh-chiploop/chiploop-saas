# Digital DQA Summary
- workflow_id: `4d3d96d7-118f-4491-9279-483251a55f2a`
- status: `failed`
- rtl files: `1`
- warning count: `0`

## Stage Status
- rtl_lint: `pass`
- cdc: `unavailable`
- reset_integrity: `unavailable`
- synthesis_readiness: `failed`

## Blocking Issues
- yosys_synthesis_errors
