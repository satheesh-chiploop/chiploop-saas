module pwm_fpga_demo (
    input  clk,
    output led
);

reg [7:0] pwm_counter;
reg [7:0] duty_cycle;
reg       direction;
reg [15:0] slow_counter;

wire pwm_out;

assign pwm_out = (pwm_counter < duty_cycle);
assign led = pwm_out;

always @(posedge clk) begin
    pwm_counter <= pwm_counter + 8'd1;

    if (slow_counter == 16'd49999) begin
        slow_counter <= 16'd0;

        if (direction == 1'b0) begin
            if (duty_cycle == 8'hFF) begin
                duty_cycle <= 8'hFF;
                direction <= 1'b1;
            end else begin
                duty_cycle <= duty_cycle + 8'd1;
                direction <= 1'b0;
            end
        end else begin
            if (duty_cycle == 8'h00) begin
                duty_cycle <= 8'h00;
                direction <= 1'b0;
            end else begin
                duty_cycle <= duty_cycle - 8'd1;
                direction <= 1'b1;
            end
        end
    end else begin
        slow_counter <= slow_counter + 16'd1;
    end
end

endmodule
