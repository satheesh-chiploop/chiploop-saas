# System PD Signoff Closure Plan

- closure_complete: `False`
- selected_restart_stage: `Digital Tapeout Logic Equivalence Check Agent`
- dominant_issue: `tapeout_lec`
- max_iterations: `1`
- stop_reason: `repair_plan_created`

## Post-Fill Timing
- setup WNS: `0`
- setup TNS: `0`
- setup violations: `0`
- hold WNS: `0`
- hold TNS: `0`
- hold violations: `0`

## Repair Actions
- `tapeout_lec` from `Digital Tapeout Logic Equivalence Check Agent`: Repair final gate-vs-reference LEC after tapeout artifacts are otherwise clean.

## Skipped Repairs
- none