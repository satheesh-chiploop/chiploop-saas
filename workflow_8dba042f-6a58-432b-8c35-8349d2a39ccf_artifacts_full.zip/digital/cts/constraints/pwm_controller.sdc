# Auto-generated from ChipLoop clock intent
create_clock -name clk -period 4.444 [get_ports {clk}]
