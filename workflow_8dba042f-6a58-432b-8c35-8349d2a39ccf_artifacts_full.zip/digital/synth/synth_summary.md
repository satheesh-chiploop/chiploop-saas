# Digital Synthesis Summary

- **Workflow**: 8dba042f-6a58-432b-8c35-8349d2a39ccf
- **Status**: `ok` (rc=0)
- **Top module**: `pwm_controller`
- **Clock**: `clk` @ **10.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/8dba042f-6a58-432b-8c35-8349d2a39ccf/07de22c8-e66c-4fda-b779-6ca37e74bf33/digital/arch2tapeout/digital/synth/runs/Digital_Arch2Tapeout_8dba042f-6a58-432b-8c35-8349d2a39ccf/final/metrics.json`
- netlist candidates: 1 found
