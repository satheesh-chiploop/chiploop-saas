/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/8dba042f-6a58-432b-8c35-8349d2a39ccf/07de22c8-e66c-4fda-b779-6ca37e74bf33/digital/arch2tapeout/handoff/rtl/pwm_controller.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/8dba042f-6a58-432b-8c35-8349d2a39ccf/07de22c8-e66c-4fda-b779-6ca37e74bf33/digital/arch2tapeout/handoff/rtl/pwm_controller_regs.v
