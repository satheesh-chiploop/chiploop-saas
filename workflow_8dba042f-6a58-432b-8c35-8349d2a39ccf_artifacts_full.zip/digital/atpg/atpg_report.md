# Scan ATPG Coverage

- Status: `not_applicable`
- Reason: `enable_scan_dft_disabled`
