# Digital Executive Summary
- workflow_id: `8dba042f-6a58-432b-8c35-8349d2a39ccf`
- run_tag: `Digital_Arch2Tapeout_8dba042f-6a58-432b-8c35-8349d2a39ccf`
- run_work_dir: `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/8dba042f-6a58-432b-8c35-8349d2a39ccf/07de22c8-e66c-4fda-b779-6ca37e74bf33/digital/arch2tapeout/digital/run_work`

## Key Metrics (best-effort parsed)
- Cell count: `147`
- Area: `1915.5872`
- Flip-flops: `33`
- Latches: `0`
- STA stage used: `sta_postfill`
- Worst slack: `0.07668887963949725`
- TNS: `0`
- DRC violations: `0`
- DRC status: `clean`
- LVS status: `clean`
- Tapeout status: `ok`
- Tapeout LEC status: `inconclusive_unresolved_cells`
- ATPG status: `not_applicable`
- Summary status: `failed`

## STA Stage Breakdown
- sta_preplace: worst_slack=`-0.29941561189000043`, tns=`-1.0751551064875995`
- sta_postplace: worst_slack=`2.22579`, tns=`0`
- sta_postcts: worst_slack=`None`, tns=`None`
- sta_postroute: worst_slack=`0.07668887963949725`, tns=`0`
- sta_postfill: worst_slack=`0.07668887963949725`, tns=`0`

## GDS Paths (local, only if produced)
- KLayout GDS: `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/8dba042f-6a58-432b-8c35-8349d2a39ccf/07de22c8-e66c-4fda-b779-6ca37e74bf33/digital/arch2tapeout/digital/tapeout/gds/klayout.gds`
- Magic GDS: `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/8dba042f-6a58-432b-8c35-8349d2a39ccf/07de22c8-e66c-4fda-b779-6ca37e74bf33/digital/arch2tapeout/digital/tapeout/gds/magic.gds`

## Artifact Map
- synth_metrics: `digital/synth/metrics.json`
- sta_preplace_metrics: `digital/sta_preplace/metrics.json`
- sta_postplace_metrics: `digital/sta_postplace/metrics.json`
- sta_postcts_metrics: `None`
- sta_postroute_metrics: `digital/sta_postroute/metrics.json`
- sta_postfill_metrics: `digital/sta_postfill/metrics.json`
- drc_metrics: `None`
- lvs_metrics: `None`
- tapeout_metrics: `digital/tapeout/metrics.json`

## Next Iteration Suggestions
- If worst_slack < 0: relax constraints or improve synthesis/placement/CTS/route parameters.
- If DRC violations > 0: inspect DRC logs and rerun with adjusted floorplan/route settings.
- If LVS not clean: check extraction/streamout mismatch and netlist naming.