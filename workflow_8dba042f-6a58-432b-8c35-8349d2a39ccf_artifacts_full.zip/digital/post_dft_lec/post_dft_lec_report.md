# Digital Post-DFT Logic Equivalence Check

- Status: `inconclusive`
- Failure reason: `missing_post_dft_netlist`
- Top module: `pwm_controller`
- Synthesis netlist: `pwm_controller_synth.v`
- Post-DFT netlist: `missing`
- Unproven points: `0`
