# IP Packaging & Handoff Report

- Top: `pwm_controller`
- Package: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/8dba042f-6a58-432b-8c35-8349d2a39ccf/07de22c8-e66c-4fda-b779-6ca37e74bf33/digital/arch2tapeout/handoff/pwm_controller_ip_package`
- Zip: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/8dba042f-6a58-432b-8c35-8349d2a39ccf/07de22c8-e66c-4fda-b779-6ca37e74bf33/digital/arch2tapeout/handoff/pwm_controller_ip_package.zip`

## Bucket counts
- **rtl**: 2
- **spec**: 1
- **arch**: 0
- **microarch**: 0
- **regmap**: 1
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 0
