# IP Packaging & Handoff Report

- Top: `motor_control_top`
- Package: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/94eba140-54a6-46d6-8818-df066a3e5763/0ae4c836-91a4-4a16-936a-40745eab4855/digital/arch2tapeout/handoff/motor_control_top_ip_package`
- Zip: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/94eba140-54a6-46d6-8818-df066a3e5763/0ae4c836-91a4-4a16-936a-40745eab4855/digital/arch2tapeout/handoff/motor_control_top_ip_package.zip`

## Bucket counts
- **rtl**: 1
- **spec**: 1
- **arch**: 0
- **microarch**: 0
- **regmap**: 1
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 2
