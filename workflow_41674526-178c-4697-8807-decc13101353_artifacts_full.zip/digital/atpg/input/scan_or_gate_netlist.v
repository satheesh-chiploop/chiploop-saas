module uart_packet_engine (clk,
    irq,
    rd_en,
    reset_n,
    scan_en,
    uart_rx,
    uart_tx,
    wr_en,
    packet_count,
    rd_addr,
    rd_data,
    rx_fifo_level,
    scan_in,
    scan_out,
    tx_fifo_level,
    wr_addr,
    wr_data);
 input clk;
 output irq;
 input rd_en;
 input reset_n;
 input scan_en;
 input uart_rx;
 output uart_tx;
 input wr_en;
 output [15:0] packet_count;
 input [7:0] rd_addr;
 output [7:0] rd_data;
 output [5:0] rx_fifo_level;
 input [3:0] scan_in;
 output [3:0] scan_out;
 output [5:0] tx_fifo_level;
 input [7:0] wr_addr;
 input [7:0] wr_data;

 wire _0000_;
 wire _0001_;
 wire _0002_;
 wire _0003_;
 wire _0004_;
 wire _0005_;
 wire _0006_;
 wire _0007_;
 wire _0008_;
 wire _0009_;
 wire _0010_;
 wire _0011_;
 wire _0012_;
 wire _0013_;
 wire _0014_;
 wire _0015_;
 wire _0016_;
 wire _0017_;
 wire _0018_;
 wire _0019_;
 wire _0020_;
 wire _0021_;
 wire _0022_;
 wire _0023_;
 wire _0024_;
 wire _0025_;
 wire _0026_;
 wire _0027_;
 wire _0028_;
 wire _0029_;
 wire _0030_;
 wire _0031_;
 wire _0032_;
 wire _0033_;
 wire _0034_;
 wire _0035_;
 wire _0036_;
 wire _0037_;
 wire _0038_;
 wire _0039_;
 wire _0040_;
 wire _0041_;
 wire _0042_;
 wire _0043_;
 wire _0044_;
 wire _0045_;
 wire _0046_;
 wire _0047_;
 wire _0048_;
 wire _0049_;
 wire _0050_;
 wire _0051_;
 wire _0052_;
 wire _0053_;
 wire _0054_;
 wire _0055_;
 wire _0056_;
 wire _0057_;
 wire _0058_;
 wire _0059_;
 wire _0060_;
 wire _0061_;
 wire _0062_;
 wire _0063_;
 wire _0064_;
 wire _0065_;
 wire _0066_;
 wire _0067_;
 wire _0068_;
 wire _0069_;
 wire _0070_;
 wire _0071_;
 wire _0072_;
 wire _0073_;
 wire _0074_;
 wire _0075_;
 wire _0076_;
 wire _0077_;
 wire _0078_;
 wire _0079_;
 wire _0080_;
 wire _0081_;
 wire _0082_;
 wire _0083_;
 wire _0084_;
 wire _0085_;
 wire _0086_;
 wire _0087_;
 wire _0088_;
 wire _0089_;
 wire _0090_;
 wire _0091_;
 wire _0092_;
 wire _0093_;
 wire _0094_;
 wire _0095_;
 wire _0096_;
 wire _0097_;
 wire _0098_;
 wire _0099_;
 wire _0100_;
 wire _0101_;
 wire _0102_;
 wire _0103_;
 wire _0104_;
 wire _0105_;
 wire _0106_;
 wire _0107_;
 wire _0108_;
 wire _0109_;
 wire _0110_;
 wire _0111_;
 wire _0112_;
 wire _0113_;
 wire _0114_;
 wire _0115_;
 wire _0116_;
 wire _0117_;
 wire _0118_;
 wire _0119_;
 wire _0120_;
 wire _0121_;
 wire _0122_;
 wire _0123_;
 wire _0124_;
 wire _0125_;
 wire _0126_;
 wire _0127_;
 wire _0128_;
 wire _0129_;
 wire _0130_;
 wire _0131_;
 wire _0132_;
 wire _0133_;
 wire _0134_;
 wire _0135_;
 wire _0136_;
 wire _0137_;
 wire _0138_;
 wire _0139_;
 wire _0140_;
 wire _0141_;
 wire _0142_;
 wire _0143_;
 wire _0144_;
 wire _0145_;
 wire _0146_;
 wire _0147_;
 wire _0148_;
 wire _0149_;
 wire _0150_;
 wire _0151_;
 wire _0152_;
 wire _0153_;
 wire _0154_;
 wire _0155_;
 wire _0156_;
 wire _0157_;
 wire _0158_;
 wire _0159_;
 wire _0160_;
 wire _0161_;
 wire _0162_;
 wire _0163_;
 wire _0164_;
 wire _0165_;
 wire _0166_;
 wire _0167_;
 wire _0168_;
 wire _0169_;
 wire _0170_;
 wire _0171_;
 wire _0172_;
 wire _0173_;
 wire _0174_;
 wire _0175_;
 wire _0176_;
 wire _0177_;
 wire _0178_;
 wire _0179_;
 wire _0180_;
 wire _0181_;
 wire _0182_;
 wire _0183_;
 wire _0184_;
 wire _0185_;
 wire _0186_;
 wire _0187_;
 wire _0188_;
 wire _0189_;
 wire _0190_;
 wire _0191_;
 wire _0192_;
 wire _0193_;
 wire _0194_;
 wire _0195_;
 wire _0196_;
 wire _0197_;
 wire _0198_;
 wire _0199_;
 wire _0200_;
 wire _0201_;
 wire _0202_;
 wire _0203_;
 wire _0204_;
 wire _0205_;
 wire _0206_;
 wire _0207_;
 wire _0208_;
 wire _0209_;
 wire _0210_;
 wire _0211_;
 wire _0212_;
 wire _0213_;
 wire _0214_;
 wire _0215_;
 wire _0216_;
 wire _0217_;
 wire _0218_;
 wire _0219_;
 wire _0220_;
 wire _0221_;
 wire _0222_;
 wire _0223_;
 wire _0224_;
 wire _0225_;
 wire _0226_;
 wire _0227_;
 wire _0228_;
 wire _0229_;
 wire _0230_;
 wire _0231_;
 wire _0232_;
 wire _0233_;
 wire _0234_;
 wire _0235_;
 wire _0236_;
 wire _0237_;
 wire _0238_;
 wire _0239_;
 wire _0240_;
 wire _0241_;
 wire _0242_;
 wire _0243_;
 wire _0244_;
 wire _0245_;
 wire _0246_;
 wire _0247_;
 wire _0248_;
 wire _0249_;
 wire _0250_;
 wire _0251_;
 wire _0252_;
 wire _0253_;
 wire _0254_;
 wire _0255_;
 wire _0256_;
 wire _0257_;
 wire _0258_;
 wire _0259_;
 wire _0260_;
 wire _0261_;
 wire _0262_;
 wire _0263_;
 wire _0264_;
 wire _0265_;
 wire _0266_;
 wire _0267_;
 wire _0268_;
 wire _0269_;
 wire _0270_;
 wire _0271_;
 wire _0272_;
 wire _0273_;
 wire _0274_;
 wire _0275_;
 wire _0276_;
 wire _0277_;
 wire _0278_;
 wire _0279_;
 wire _0280_;
 wire _0281_;
 wire _0282_;
 wire _0283_;
 wire _0284_;
 wire _0285_;
 wire _0286_;
 wire _0287_;
 wire _0288_;
 wire _0289_;
 wire _0290_;
 wire _0291_;
 wire _0292_;
 wire _0293_;
 wire _0294_;
 wire _0295_;
 wire _0296_;
 wire _0297_;
 wire _0298_;
 wire _0299_;
 wire _0300_;
 wire _0301_;
 wire _0302_;
 wire _0303_;
 wire _0304_;
 wire _0305_;
 wire _0306_;
 wire _0307_;
 wire _0308_;
 wire _0309_;
 wire _0310_;
 wire _0311_;
 wire _0312_;
 wire _0313_;
 wire _0314_;
 wire _0315_;
 wire _0316_;
 wire _0317_;
 wire _0318_;
 wire _0319_;
 wire _0320_;
 wire _0321_;
 wire _0322_;
 wire _0323_;
 wire _0324_;
 wire _0325_;
 wire _0326_;
 wire _0327_;
 wire _0328_;
 wire _0329_;
 wire _0330_;
 wire _0331_;
 wire _0332_;
 wire _0333_;
 wire _0334_;
 wire _0335_;
 wire _0336_;
 wire _0337_;
 wire _0338_;
 wire _0339_;
 wire _0340_;
 wire _0341_;
 wire _0342_;
 wire _0343_;
 wire _0344_;
 wire _0345_;
 wire _0346_;
 wire _0347_;
 wire _0348_;
 wire _0349_;
 wire _0350_;
 wire _0351_;
 wire _0352_;
 wire _0353_;
 wire _0354_;
 wire _0355_;
 wire _0356_;
 wire _0357_;
 wire _0358_;
 wire _0359_;
 wire _0360_;
 wire _0361_;
 wire _0362_;
 wire _0363_;
 wire _0364_;
 wire _0365_;
 wire _0366_;
 wire _0367_;
 wire _0368_;
 wire _0369_;
 wire _0370_;
 wire _0371_;
 wire _0372_;
 wire _0373_;
 wire _0374_;
 wire _0375_;
 wire _0376_;
 wire _0377_;
 wire _0378_;
 wire _0379_;
 wire _0380_;
 wire _0381_;
 wire _0382_;
 wire _0383_;
 wire _0384_;
 wire _0385_;
 wire _0386_;
 wire _0387_;
 wire _0388_;
 wire _0389_;
 wire _0390_;
 wire _0391_;
 wire _0392_;
 wire _0393_;
 wire _0394_;
 wire _0395_;
 wire _0396_;
 wire _0397_;
 wire _0398_;
 wire _0399_;
 wire _0400_;
 wire _0401_;
 wire _0402_;
 wire _0403_;
 wire _0404_;
 wire _0405_;
 wire _0406_;
 wire _0407_;
 wire _0408_;
 wire _0409_;
 wire _0410_;
 wire _0411_;
 wire _0412_;
 wire _0413_;
 wire _0414_;
 wire _0415_;
 wire _0416_;
 wire _0417_;
 wire _0418_;
 wire _0419_;
 wire _0420_;
 wire _0421_;
 wire _0422_;
 wire _0423_;
 wire _0424_;
 wire _0425_;
 wire _0426_;
 wire _0427_;
 wire _0428_;
 wire _0429_;
 wire _0430_;
 wire _0431_;
 wire _0432_;
 wire _0433_;
 wire _0434_;
 wire _0435_;
 wire _0436_;
 wire _0437_;
 wire _0438_;
 wire _0439_;
 wire _0440_;
 wire _0441_;
 wire _0442_;
 wire _0443_;
 wire _0444_;
 wire _0445_;
 wire _0446_;
 wire _0447_;
 wire _0448_;
 wire _0449_;
 wire _0450_;
 wire _0451_;
 wire _0452_;
 wire _0453_;
 wire _0454_;
 wire _0455_;
 wire _0456_;
 wire _0457_;
 wire _0458_;
 wire _0459_;
 wire _0460_;
 wire _0461_;
 wire _0462_;
 wire _0463_;
 wire _0464_;
 wire _0465_;
 wire _0466_;
 wire _0467_;
 wire _0468_;
 wire _0469_;
 wire _0470_;
 wire _0471_;
 wire _0472_;
 wire _0473_;
 wire _0474_;
 wire _0475_;
 wire _0476_;
 wire _0477_;
 wire _0478_;
 wire _0479_;
 wire _0480_;
 wire _0481_;
 wire _0482_;
 wire _0483_;
 wire _0484_;
 wire _0485_;
 wire _0486_;
 wire _0487_;
 wire _0488_;
 wire _0489_;
 wire _0490_;
 wire _0491_;
 wire _0492_;
 wire _0493_;
 wire _0494_;
 wire _0495_;
 wire _0496_;
 wire _0497_;
 wire _0498_;
 wire _0499_;
 wire _0500_;
 wire _0501_;
 wire _0502_;
 wire _0503_;
 wire _0504_;
 wire _0505_;
 wire _0506_;
 wire _0507_;
 wire _0508_;
 wire _0509_;
 wire _0510_;
 wire _0511_;
 wire _0512_;
 wire _0513_;
 wire _0514_;
 wire _0515_;
 wire _0516_;
 wire _0517_;
 wire _0518_;
 wire _0519_;
 wire _0520_;
 wire _0521_;
 wire _0522_;
 wire _0523_;
 wire _0524_;
 wire _0525_;
 wire _0526_;
 wire _0527_;
 wire _0528_;
 wire _0529_;
 wire _0530_;
 wire _0531_;
 wire _0532_;
 wire _0533_;
 wire _0534_;
 wire _0535_;
 wire _0536_;
 wire _0537_;
 wire _0538_;
 wire _0539_;
 wire _0540_;
 wire _0541_;
 wire _0542_;
 wire _0543_;
 wire _0544_;
 wire _0545_;
 wire _0546_;
 wire _0547_;
 wire _0548_;
 wire _0549_;
 wire _0550_;
 wire _0551_;
 wire _0552_;
 wire _0553_;
 wire _0554_;
 wire _0555_;
 wire _0556_;
 wire _0557_;
 wire _0558_;
 wire _0559_;
 wire _0560_;
 wire _0561_;
 wire _0562_;
 wire _0563_;
 wire _0564_;
 wire _0565_;
 wire _0566_;
 wire _0567_;
 wire _0568_;
 wire _0569_;
 wire _0570_;
 wire _0571_;
 wire _0572_;
 wire _0573_;
 wire _0574_;
 wire _0575_;
 wire _0576_;
 wire _0577_;
 wire _0578_;
 wire _0579_;
 wire _0580_;
 wire _0581_;
 wire _0582_;
 wire _0583_;
 wire _0584_;
 wire _0585_;
 wire _0586_;
 wire _0587_;
 wire _0588_;
 wire _0589_;
 wire _0590_;
 wire _0591_;
 wire _0592_;
 wire _0593_;
 wire _0594_;
 wire _0595_;
 wire _0596_;
 wire _0597_;
 wire _0598_;
 wire _0599_;
 wire _0600_;
 wire _0601_;
 wire _0602_;
 wire _0603_;
 wire _0604_;
 wire _0605_;
 wire _0606_;
 wire _0607_;
 wire _0608_;
 wire _0609_;
 wire _0610_;
 wire _0611_;
 wire _0612_;
 wire _0613_;
 wire _0614_;
 wire _0615_;
 wire _0616_;
 wire _0617_;
 wire _0618_;
 wire _0619_;
 wire _0620_;
 wire _0621_;
 wire _0622_;
 wire _0623_;
 wire _0624_;
 wire _0625_;
 wire _0626_;
 wire _0627_;
 wire _0628_;
 wire _0629_;
 wire _0630_;
 wire _0631_;
 wire _0632_;
 wire _0633_;
 wire _0634_;
 wire _0635_;
 wire _0636_;
 wire _0637_;
 wire _0638_;
 wire _0639_;
 wire _0640_;
 wire _0641_;
 wire _0642_;
 wire _0643_;
 wire _0644_;
 wire _0645_;
 wire _0646_;
 wire _0647_;
 wire _0648_;
 wire _0649_;
 wire _0650_;
 wire _0651_;
 wire _0652_;
 wire _0653_;
 wire _0654_;
 wire _0655_;
 wire _0656_;
 wire _0657_;
 wire _0658_;
 wire _0659_;
 wire _0660_;
 wire _0661_;
 wire _0662_;
 wire _0663_;
 wire _0664_;
 wire _0665_;
 wire _0666_;
 wire _0667_;
 wire _0668_;
 wire _0669_;
 wire _0670_;
 wire _0671_;
 wire _0672_;
 wire _0673_;
 wire _0674_;
 wire _0675_;
 wire _0676_;
 wire _0677_;
 wire _0678_;
 wire _0679_;
 wire _0680_;
 wire _0681_;
 wire _0682_;
 wire _0683_;
 wire _0684_;
 wire _0685_;
 wire _0686_;
 wire _0687_;
 wire _0688_;
 wire _0689_;
 wire _0690_;
 wire _0691_;
 wire _0692_;
 wire _0693_;
 wire _0694_;
 wire _0695_;
 wire _0696_;
 wire _0697_;
 wire _0698_;
 wire _0699_;
 wire _0700_;
 wire _0701_;
 wire _0702_;
 wire _0703_;
 wire _0704_;
 wire _0705_;
 wire _0706_;
 wire _0707_;
 wire _0708_;
 wire _0709_;
 wire _0710_;
 wire _0711_;
 wire _0712_;
 wire _0713_;
 wire _0714_;
 wire _0715_;
 wire _0716_;
 wire _0717_;
 wire _0718_;
 wire _0719_;
 wire _0720_;
 wire _0721_;
 wire _0722_;
 wire _0723_;
 wire _0724_;
 wire _0725_;
 wire _0726_;
 wire _0727_;
 wire _0728_;
 wire _0729_;
 wire _0730_;
 wire _0731_;
 wire _0732_;
 wire _0733_;
 wire _0734_;
 wire _0735_;
 wire _0736_;
 wire _0737_;
 wire _0738_;
 wire _0739_;
 wire _0740_;
 wire _0741_;
 wire _0742_;
 wire _0743_;
 wire _0744_;
 wire _0745_;
 wire _0746_;
 wire _0747_;
 wire _0748_;
 wire _0749_;
 wire _0750_;
 wire _0751_;
 wire _0752_;
 wire _0753_;
 wire _0754_;
 wire _0755_;
 wire _0756_;
 wire _0757_;
 wire _0758_;
 wire _0759_;
 wire _0760_;
 wire _0761_;
 wire _0762_;
 wire _0763_;
 wire _0764_;
 wire _0765_;
 wire _0766_;
 wire _0767_;
 wire _0768_;
 wire _0769_;
 wire _0770_;
 wire _0771_;
 wire _0772_;
 wire _0773_;
 wire _0774_;
 wire _0775_;
 wire _0776_;
 wire _0777_;
 wire _0778_;
 wire _0779_;
 wire _0780_;
 wire _0781_;
 wire _0782_;
 wire _0783_;
 wire _0784_;
 wire _0785_;
 wire _0786_;
 wire _0787_;
 wire _0788_;
 wire _0789_;
 wire _0790_;
 wire _0791_;
 wire _0792_;
 wire _0793_;
 wire _0794_;
 wire _0795_;
 wire _0796_;
 wire _0797_;
 wire _0798_;
 wire _0799_;
 wire _0800_;
 wire _0801_;
 wire _0802_;
 wire _0803_;
 wire _0804_;
 wire _0805_;
 wire _0806_;
 wire _0807_;
 wire _0808_;
 wire _0809_;
 wire _0810_;
 wire _0811_;
 wire _0812_;
 wire _0813_;
 wire _0814_;
 wire _0815_;
 wire _0816_;
 wire _0817_;
 wire _0818_;
 wire _0819_;
 wire _0820_;
 wire _0821_;
 wire _0822_;
 wire _0823_;
 wire _0824_;
 wire _0825_;
 wire _0826_;
 wire _0827_;
 wire _0828_;
 wire _0829_;
 wire _0830_;
 wire _0831_;
 wire _0832_;
 wire _0833_;
 wire _0834_;
 wire _0835_;
 wire _0836_;
 wire _0837_;
 wire _0838_;
 wire _0839_;
 wire _0840_;
 wire _0841_;
 wire _0842_;
 wire _0843_;
 wire _0844_;
 wire _0845_;
 wire _0846_;
 wire _0847_;
 wire _0848_;
 wire _0849_;
 wire _0850_;
 wire _0851_;
 wire _0852_;
 wire _0853_;
 wire _0854_;
 wire _0855_;
 wire _0856_;
 wire _0857_;
 wire _0858_;
 wire _0859_;
 wire _0860_;
 wire _0861_;
 wire _0862_;
 wire _0863_;
 wire _0864_;
 wire _0865_;
 wire _0866_;
 wire _0867_;
 wire _0868_;
 wire _0869_;
 wire _0870_;
 wire _0871_;
 wire _0872_;
 wire _0873_;
 wire _0874_;
 wire _0875_;
 wire _0876_;
 wire _0877_;
 wire _0878_;
 wire _0879_;
 wire _0880_;
 wire _0881_;
 wire _0882_;
 wire _0883_;
 wire _0884_;
 wire _0885_;
 wire _0886_;
 wire _0887_;
 wire _0888_;
 wire _0889_;
 wire _0890_;
 wire _0891_;
 wire _0892_;
 wire _0893_;
 wire _0894_;
 wire _0895_;
 wire _0896_;
 wire _0897_;
 wire _0898_;
 wire _0899_;
 wire _0900_;
 wire _0901_;
 wire _0902_;
 wire _0903_;
 wire _0904_;
 wire _0905_;
 wire _0906_;
 wire _0907_;
 wire _0908_;
 wire _0909_;
 wire _0910_;
 wire _0911_;
 wire _0912_;
 wire _0913_;
 wire _0914_;
 wire _0915_;
 wire _0916_;
 wire _0917_;
 wire _0918_;
 wire _0919_;
 wire _0920_;
 wire _0921_;
 wire _0922_;
 wire _0923_;
 wire _0924_;
 wire _0925_;
 wire _0926_;
 wire _0927_;
 wire _0928_;
 wire _0929_;
 wire _0930_;
 wire _0931_;
 wire _0932_;
 wire _0933_;
 wire _0934_;
 wire _0935_;
 wire _0936_;
 wire _0937_;
 wire _0938_;
 wire _0939_;
 wire _0940_;
 wire _0941_;
 wire _0942_;
 wire _0943_;
 wire _0944_;
 wire _0945_;
 wire _0946_;
 wire _0947_;
 wire _0948_;
 wire _0949_;
 wire _0950_;
 wire _0951_;
 wire _0952_;
 wire _0953_;
 wire _0954_;
 wire _0955_;
 wire _0956_;
 wire _0957_;
 wire _0958_;
 wire _0959_;
 wire _0960_;
 wire _0961_;
 wire _0962_;
 wire _0963_;
 wire _0964_;
 wire _0965_;
 wire _0966_;
 wire _0967_;
 wire _0968_;
 wire _0969_;
 wire _0970_;
 wire _0971_;
 wire _0972_;
 wire _0973_;
 wire _0974_;
 wire _0975_;
 wire _0976_;
 wire _0977_;
 wire _0978_;
 wire _0979_;
 wire _0980_;
 wire _0981_;
 wire _0982_;
 wire _0983_;
 wire _0984_;
 wire _0985_;
 wire _0986_;
 wire _0987_;
 wire _0988_;
 wire _0989_;
 wire _0990_;
 wire _0991_;
 wire _0992_;
 wire _0993_;
 wire _0994_;
 wire _0995_;
 wire _0996_;
 wire _0997_;
 wire _0998_;
 wire _0999_;
 wire _1000_;
 wire _1001_;
 wire _1002_;
 wire _1003_;
 wire _1004_;
 wire _1005_;
 wire _1006_;
 wire _1007_;
 wire _1008_;
 wire _1009_;
 wire _1010_;
 wire _1011_;
 wire _1012_;
 wire _1013_;
 wire _1014_;
 wire _1015_;
 wire _1016_;
 wire _1017_;
 wire _1018_;
 wire _1019_;
 wire _1020_;
 wire _1021_;
 wire _1022_;
 wire _1023_;
 wire _1024_;
 wire _1025_;
 wire _1026_;
 wire _1027_;
 wire _1028_;
 wire _1029_;
 wire _1030_;
 wire _1031_;
 wire _1032_;
 wire _1033_;
 wire _1034_;
 wire _1035_;
 wire _1036_;
 wire _1037_;
 wire _1038_;
 wire _1039_;
 wire _1040_;
 wire _1041_;
 wire _1042_;
 wire _1043_;
 wire _1044_;
 wire _1045_;
 wire _1046_;
 wire _1047_;
 wire _1048_;
 wire _1049_;
 wire _1050_;
 wire _1051_;
 wire _1052_;
 wire _1053_;
 wire _1054_;
 wire _1055_;
 wire _1056_;
 wire _1057_;
 wire _1058_;
 wire _1059_;
 wire _1060_;
 wire _1061_;
 wire _1062_;
 wire _1063_;
 wire _1064_;
 wire _1065_;
 wire _1066_;
 wire _1067_;
 wire _1068_;
 wire _1069_;
 wire _1070_;
 wire _1071_;
 wire _1072_;
 wire _1073_;
 wire _1074_;
 wire _1075_;
 wire _1076_;
 wire _1077_;
 wire _1078_;
 wire _1079_;
 wire _1080_;
 wire _1081_;
 wire _1082_;
 wire _1083_;
 wire _1084_;
 wire _1085_;
 wire _1086_;
 wire _1087_;
 wire _1088_;
 wire _1089_;
 wire _1090_;
 wire _1091_;
 wire _1092_;
 wire _1093_;
 wire _1094_;
 wire _1095_;
 wire _1096_;
 wire _1097_;
 wire _1098_;
 wire _1099_;
 wire _1100_;
 wire _1101_;
 wire _1102_;
 wire _1103_;
 wire _1104_;
 wire _1105_;
 wire _1106_;
 wire _1107_;
 wire _1108_;
 wire _1109_;
 wire _1110_;
 wire _1111_;
 wire _1112_;
 wire _1113_;
 wire _1114_;
 wire _1115_;
 wire _1116_;
 wire _1117_;
 wire _1118_;
 wire _1119_;
 wire _1120_;
 wire _1121_;
 wire _1122_;
 wire _1123_;
 wire _1124_;
 wire _1125_;
 wire _1126_;
 wire _1127_;
 wire _1128_;
 wire _1129_;
 wire _1130_;
 wire _1131_;
 wire _1132_;
 wire _1133_;
 wire _1134_;
 wire _1135_;
 wire _1136_;
 wire _1137_;
 wire _1138_;
 wire _1139_;
 wire _1140_;
 wire _1141_;
 wire _1142_;
 wire _1143_;
 wire _1144_;
 wire _1145_;
 wire _1146_;
 wire _1147_;
 wire _1148_;
 wire _1149_;
 wire _1150_;
 wire _1151_;
 wire _1152_;
 wire _1153_;
 wire _1154_;
 wire _1155_;
 wire _1156_;
 wire _1157_;
 wire _1158_;
 wire _1159_;
 wire _1160_;
 wire _1161_;
 wire _1162_;
 wire _1163_;
 wire _1164_;
 wire _1165_;
 wire _1166_;
 wire _1167_;
 wire _1168_;
 wire _1169_;
 wire _1170_;
 wire _1171_;
 wire _1172_;
 wire _1173_;
 wire _1174_;
 wire _1175_;
 wire _1176_;
 wire _1177_;
 wire _1178_;
 wire _1179_;
 wire _1180_;
 wire _1181_;
 wire _1182_;
 wire _1183_;
 wire _1184_;
 wire _1185_;
 wire _1186_;
 wire _1187_;
 wire _1188_;
 wire _1189_;
 wire _1190_;
 wire _1191_;
 wire _1192_;
 wire _1193_;
 wire _1194_;
 wire _1195_;
 wire _1196_;
 wire _1197_;
 wire _1198_;
 wire _1199_;
 wire _1200_;
 wire _1201_;
 wire \baud_cnt[0] ;
 wire \baud_cnt[10] ;
 wire \baud_cnt[11] ;
 wire \baud_cnt[12] ;
 wire \baud_cnt[13] ;
 wire \baud_cnt[14] ;
 wire \baud_cnt[15] ;
 wire \baud_cnt[1] ;
 wire \baud_cnt[2] ;
 wire \baud_cnt[3] ;
 wire \baud_cnt[4] ;
 wire \baud_cnt[5] ;
 wire \baud_cnt[6] ;
 wire \baud_cnt[7] ;
 wire \baud_cnt[8] ;
 wire \baud_cnt[9] ;
 wire \baud_div_reg[0] ;
 wire \baud_div_reg[10] ;
 wire \baud_div_reg[11] ;
 wire \baud_div_reg[12] ;
 wire \baud_div_reg[13] ;
 wire \baud_div_reg[14] ;
 wire \baud_div_reg[15] ;
 wire \baud_div_reg[1] ;
 wire \baud_div_reg[2] ;
 wire \baud_div_reg[3] ;
 wire \baud_div_reg[4] ;
 wire \baud_div_reg[5] ;
 wire \baud_div_reg[6] ;
 wire \baud_div_reg[7] ;
 wire \baud_div_reg[8] ;
 wire \baud_div_reg[9] ;
 wire baud_tick;
 wire enable;
 wire error_r;
 wire irq_enable;
 wire \irq_status_reg[0] ;
 wire \irq_status_reg[1] ;
 wire \irq_status_reg[2] ;
 wire \irq_status_reg[3] ;
 wire \irq_status_reg[4] ;
 wire \irq_status_reg[5] ;
 wire \irq_status_reg[7] ;
 wire loopback;
 wire \loopback_byte[0] ;
 wire \loopback_byte[1] ;
 wire \loopback_byte[2] ;
 wire \loopback_byte[3] ;
 wire \loopback_byte[4] ;
 wire \loopback_byte[5] ;
 wire \loopback_byte[6] ;
 wire \loopback_byte[7] ;
 wire loopback_valid;
 wire packet_active_r;
 wire \packet_len_reg[0] ;
 wire \packet_len_reg[1] ;
 wire \packet_len_reg[2] ;
 wire \packet_len_reg[3] ;
 wire \packet_len_reg[4] ;
 wire \packet_len_reg[5] ;
 wire \packet_len_reg[6] ;
 wire \packet_len_reg[7] ;
 wire \rx_bit_cnt[0] ;
 wire \rx_bit_cnt[1] ;
 wire \rx_bit_cnt[2] ;
 wire \rx_bit_cnt[3] ;
 wire rx_busy_r;
 wire \rx_count[0] ;
 wire \rx_count[1] ;
 wire \rx_count[2] ;
 wire \rx_count[3] ;
 wire \rx_count[4] ;
 wire rx_enable;
 wire \rx_fifo_mem[0][0] ;
 wire \rx_fifo_mem[0][1] ;
 wire \rx_fifo_mem[0][2] ;
 wire \rx_fifo_mem[0][3] ;
 wire \rx_fifo_mem[0][4] ;
 wire \rx_fifo_mem[0][5] ;
 wire \rx_fifo_mem[0][6] ;
 wire \rx_fifo_mem[0][7] ;
 wire \rx_fifo_mem[10][0] ;
 wire \rx_fifo_mem[10][1] ;
 wire \rx_fifo_mem[10][2] ;
 wire \rx_fifo_mem[10][3] ;
 wire \rx_fifo_mem[10][4] ;
 wire \rx_fifo_mem[10][5] ;
 wire \rx_fifo_mem[10][6] ;
 wire \rx_fifo_mem[10][7] ;
 wire \rx_fifo_mem[11][0] ;
 wire \rx_fifo_mem[11][1] ;
 wire \rx_fifo_mem[11][2] ;
 wire \rx_fifo_mem[11][3] ;
 wire \rx_fifo_mem[11][4] ;
 wire \rx_fifo_mem[11][5] ;
 wire \rx_fifo_mem[11][6] ;
 wire \rx_fifo_mem[11][7] ;
 wire \rx_fifo_mem[12][0] ;
 wire \rx_fifo_mem[12][1] ;
 wire \rx_fifo_mem[12][2] ;
 wire \rx_fifo_mem[12][3] ;
 wire \rx_fifo_mem[12][4] ;
 wire \rx_fifo_mem[12][5] ;
 wire \rx_fifo_mem[12][6] ;
 wire \rx_fifo_mem[12][7] ;
 wire \rx_fifo_mem[13][0] ;
 wire \rx_fifo_mem[13][1] ;
 wire \rx_fifo_mem[13][2] ;
 wire \rx_fifo_mem[13][3] ;
 wire \rx_fifo_mem[13][4] ;
 wire \rx_fifo_mem[13][5] ;
 wire \rx_fifo_mem[13][6] ;
 wire \rx_fifo_mem[13][7] ;
 wire \rx_fifo_mem[14][0] ;
 wire \rx_fifo_mem[14][1] ;
 wire \rx_fifo_mem[14][2] ;
 wire \rx_fifo_mem[14][3] ;
 wire \rx_fifo_mem[14][4] ;
 wire \rx_fifo_mem[14][5] ;
 wire \rx_fifo_mem[14][6] ;
 wire \rx_fifo_mem[14][7] ;
 wire \rx_fifo_mem[15][0] ;
 wire \rx_fifo_mem[15][1] ;
 wire \rx_fifo_mem[15][2] ;
 wire \rx_fifo_mem[15][3] ;
 wire \rx_fifo_mem[15][4] ;
 wire \rx_fifo_mem[15][5] ;
 wire \rx_fifo_mem[15][6] ;
 wire \rx_fifo_mem[15][7] ;
 wire \rx_fifo_mem[1][0] ;
 wire \rx_fifo_mem[1][1] ;
 wire \rx_fifo_mem[1][2] ;
 wire \rx_fifo_mem[1][3] ;
 wire \rx_fifo_mem[1][4] ;
 wire \rx_fifo_mem[1][5] ;
 wire \rx_fifo_mem[1][6] ;
 wire \rx_fifo_mem[1][7] ;
 wire \rx_fifo_mem[2][0] ;
 wire \rx_fifo_mem[2][1] ;
 wire \rx_fifo_mem[2][2] ;
 wire \rx_fifo_mem[2][3] ;
 wire \rx_fifo_mem[2][4] ;
 wire \rx_fifo_mem[2][5] ;
 wire \rx_fifo_mem[2][6] ;
 wire \rx_fifo_mem[2][7] ;
 wire \rx_fifo_mem[3][0] ;
 wire \rx_fifo_mem[3][1] ;
 wire \rx_fifo_mem[3][2] ;
 wire \rx_fifo_mem[3][3] ;
 wire \rx_fifo_mem[3][4] ;
 wire \rx_fifo_mem[3][5] ;
 wire \rx_fifo_mem[3][6] ;
 wire \rx_fifo_mem[3][7] ;
 wire \rx_fifo_mem[4][0] ;
 wire \rx_fifo_mem[4][1] ;
 wire \rx_fifo_mem[4][2] ;
 wire \rx_fifo_mem[4][3] ;
 wire \rx_fifo_mem[4][4] ;
 wire \rx_fifo_mem[4][5] ;
 wire \rx_fifo_mem[4][6] ;
 wire \rx_fifo_mem[4][7] ;
 wire \rx_fifo_mem[5][0] ;
 wire \rx_fifo_mem[5][1] ;
 wire \rx_fifo_mem[5][2] ;
 wire \rx_fifo_mem[5][3] ;
 wire \rx_fifo_mem[5][4] ;
 wire \rx_fifo_mem[5][5] ;
 wire \rx_fifo_mem[5][6] ;
 wire \rx_fifo_mem[5][7] ;
 wire \rx_fifo_mem[6][0] ;
 wire \rx_fifo_mem[6][1] ;
 wire \rx_fifo_mem[6][2] ;
 wire \rx_fifo_mem[6][3] ;
 wire \rx_fifo_mem[6][4] ;
 wire \rx_fifo_mem[6][5] ;
 wire \rx_fifo_mem[6][6] ;
 wire \rx_fifo_mem[6][7] ;
 wire \rx_fifo_mem[7][0] ;
 wire \rx_fifo_mem[7][1] ;
 wire \rx_fifo_mem[7][2] ;
 wire \rx_fifo_mem[7][3] ;
 wire \rx_fifo_mem[7][4] ;
 wire \rx_fifo_mem[7][5] ;
 wire \rx_fifo_mem[7][6] ;
 wire \rx_fifo_mem[7][7] ;
 wire \rx_fifo_mem[8][0] ;
 wire \rx_fifo_mem[8][1] ;
 wire \rx_fifo_mem[8][2] ;
 wire \rx_fifo_mem[8][3] ;
 wire \rx_fifo_mem[8][4] ;
 wire \rx_fifo_mem[8][5] ;
 wire \rx_fifo_mem[8][6] ;
 wire \rx_fifo_mem[8][7] ;
 wire \rx_fifo_mem[9][0] ;
 wire \rx_fifo_mem[9][1] ;
 wire \rx_fifo_mem[9][2] ;
 wire \rx_fifo_mem[9][3] ;
 wire \rx_fifo_mem[9][4] ;
 wire \rx_fifo_mem[9][5] ;
 wire \rx_fifo_mem[9][6] ;
 wire \rx_fifo_mem[9][7] ;
 wire \rx_rd_ptr[0] ;
 wire \rx_rd_ptr[1] ;
 wire \rx_rd_ptr[2] ;
 wire \rx_rd_ptr[3] ;
 wire \rx_shift[0] ;
 wire \rx_shift[1] ;
 wire \rx_shift[2] ;
 wire \rx_shift[3] ;
 wire \rx_shift[4] ;
 wire \rx_shift[5] ;
 wire \rx_shift[6] ;
 wire \rx_shift[7] ;
 wire \rx_state[0] ;
 wire \rx_state[1] ;
 wire \rx_state[2] ;
 wire \rx_state[3] ;
 wire \rx_wr_ptr[0] ;
 wire \rx_wr_ptr[1] ;
 wire \rx_wr_ptr[2] ;
 wire \rx_wr_ptr[3] ;
 wire \tx_bit_cnt[0] ;
 wire \tx_bit_cnt[1] ;
 wire \tx_bit_cnt[2] ;
 wire \tx_bit_cnt[3] ;
 wire tx_busy_r;
 wire \tx_count[0] ;
 wire \tx_count[1] ;
 wire \tx_count[2] ;
 wire \tx_count[3] ;
 wire \tx_count[4] ;
 wire tx_enable;
 wire \tx_fifo_mem[0][0] ;
 wire \tx_fifo_mem[0][1] ;
 wire \tx_fifo_mem[0][2] ;
 wire \tx_fifo_mem[0][3] ;
 wire \tx_fifo_mem[0][4] ;
 wire \tx_fifo_mem[0][5] ;
 wire \tx_fifo_mem[0][6] ;
 wire \tx_fifo_mem[0][7] ;
 wire \tx_fifo_mem[10][0] ;
 wire \tx_fifo_mem[10][1] ;
 wire \tx_fifo_mem[10][2] ;
 wire \tx_fifo_mem[10][3] ;
 wire \tx_fifo_mem[10][4] ;
 wire \tx_fifo_mem[10][5] ;
 wire \tx_fifo_mem[10][6] ;
 wire \tx_fifo_mem[10][7] ;
 wire \tx_fifo_mem[11][0] ;
 wire \tx_fifo_mem[11][1] ;
 wire \tx_fifo_mem[11][2] ;
 wire \tx_fifo_mem[11][3] ;
 wire \tx_fifo_mem[11][4] ;
 wire \tx_fifo_mem[11][5] ;
 wire \tx_fifo_mem[11][6] ;
 wire \tx_fifo_mem[11][7] ;
 wire \tx_fifo_mem[12][0] ;
 wire \tx_fifo_mem[12][1] ;
 wire \tx_fifo_mem[12][2] ;
 wire \tx_fifo_mem[12][3] ;
 wire \tx_fifo_mem[12][4] ;
 wire \tx_fifo_mem[12][5] ;
 wire \tx_fifo_mem[12][6] ;
 wire \tx_fifo_mem[12][7] ;
 wire \tx_fifo_mem[13][0] ;
 wire \tx_fifo_mem[13][1] ;
 wire \tx_fifo_mem[13][2] ;
 wire \tx_fifo_mem[13][3] ;
 wire \tx_fifo_mem[13][4] ;
 wire \tx_fifo_mem[13][5] ;
 wire \tx_fifo_mem[13][6] ;
 wire \tx_fifo_mem[13][7] ;
 wire \tx_fifo_mem[14][0] ;
 wire \tx_fifo_mem[14][1] ;
 wire \tx_fifo_mem[14][2] ;
 wire \tx_fifo_mem[14][3] ;
 wire \tx_fifo_mem[14][4] ;
 wire \tx_fifo_mem[14][5] ;
 wire \tx_fifo_mem[14][6] ;
 wire \tx_fifo_mem[14][7] ;
 wire \tx_fifo_mem[15][0] ;
 wire \tx_fifo_mem[15][1] ;
 wire \tx_fifo_mem[15][2] ;
 wire \tx_fifo_mem[15][3] ;
 wire \tx_fifo_mem[15][4] ;
 wire \tx_fifo_mem[15][5] ;
 wire \tx_fifo_mem[15][6] ;
 wire \tx_fifo_mem[15][7] ;
 wire \tx_fifo_mem[1][0] ;
 wire \tx_fifo_mem[1][1] ;
 wire \tx_fifo_mem[1][2] ;
 wire \tx_fifo_mem[1][3] ;
 wire \tx_fifo_mem[1][4] ;
 wire \tx_fifo_mem[1][5] ;
 wire \tx_fifo_mem[1][6] ;
 wire \tx_fifo_mem[1][7] ;
 wire \tx_fifo_mem[2][0] ;
 wire \tx_fifo_mem[2][1] ;
 wire \tx_fifo_mem[2][2] ;
 wire \tx_fifo_mem[2][3] ;
 wire \tx_fifo_mem[2][4] ;
 wire \tx_fifo_mem[2][5] ;
 wire \tx_fifo_mem[2][6] ;
 wire \tx_fifo_mem[2][7] ;
 wire \tx_fifo_mem[3][0] ;
 wire \tx_fifo_mem[3][1] ;
 wire \tx_fifo_mem[3][2] ;
 wire \tx_fifo_mem[3][3] ;
 wire \tx_fifo_mem[3][4] ;
 wire \tx_fifo_mem[3][5] ;
 wire \tx_fifo_mem[3][6] ;
 wire \tx_fifo_mem[3][7] ;
 wire \tx_fifo_mem[4][0] ;
 wire \tx_fifo_mem[4][1] ;
 wire \tx_fifo_mem[4][2] ;
 wire \tx_fifo_mem[4][3] ;
 wire \tx_fifo_mem[4][4] ;
 wire \tx_fifo_mem[4][5] ;
 wire \tx_fifo_mem[4][6] ;
 wire \tx_fifo_mem[4][7] ;
 wire \tx_fifo_mem[5][0] ;
 wire \tx_fifo_mem[5][1] ;
 wire \tx_fifo_mem[5][2] ;
 wire \tx_fifo_mem[5][3] ;
 wire \tx_fifo_mem[5][4] ;
 wire \tx_fifo_mem[5][5] ;
 wire \tx_fifo_mem[5][6] ;
 wire \tx_fifo_mem[5][7] ;
 wire \tx_fifo_mem[6][0] ;
 wire \tx_fifo_mem[6][1] ;
 wire \tx_fifo_mem[6][2] ;
 wire \tx_fifo_mem[6][3] ;
 wire \tx_fifo_mem[6][4] ;
 wire \tx_fifo_mem[6][5] ;
 wire \tx_fifo_mem[6][6] ;
 wire \tx_fifo_mem[6][7] ;
 wire \tx_fifo_mem[7][0] ;
 wire \tx_fifo_mem[7][1] ;
 wire \tx_fifo_mem[7][2] ;
 wire \tx_fifo_mem[7][3] ;
 wire \tx_fifo_mem[7][4] ;
 wire \tx_fifo_mem[7][5] ;
 wire \tx_fifo_mem[7][6] ;
 wire \tx_fifo_mem[7][7] ;
 wire \tx_fifo_mem[8][0] ;
 wire \tx_fifo_mem[8][1] ;
 wire \tx_fifo_mem[8][2] ;
 wire \tx_fifo_mem[8][3] ;
 wire \tx_fifo_mem[8][4] ;
 wire \tx_fifo_mem[8][5] ;
 wire \tx_fifo_mem[8][6] ;
 wire \tx_fifo_mem[8][7] ;
 wire \tx_fifo_mem[9][0] ;
 wire \tx_fifo_mem[9][1] ;
 wire \tx_fifo_mem[9][2] ;
 wire \tx_fifo_mem[9][3] ;
 wire \tx_fifo_mem[9][4] ;
 wire \tx_fifo_mem[9][5] ;
 wire \tx_fifo_mem[9][6] ;
 wire \tx_fifo_mem[9][7] ;
 wire \tx_hold_byte[0] ;
 wire \tx_hold_byte[1] ;
 wire \tx_hold_byte[2] ;
 wire \tx_hold_byte[3] ;
 wire \tx_hold_byte[4] ;
 wire \tx_hold_byte[5] ;
 wire \tx_hold_byte[6] ;
 wire \tx_hold_byte[7] ;
 wire \tx_rd_ptr[0] ;
 wire \tx_rd_ptr[1] ;
 wire \tx_rd_ptr[2] ;
 wire \tx_rd_ptr[3] ;
 wire \tx_shift[0] ;
 wire \tx_shift[1] ;
 wire \tx_shift[2] ;
 wire \tx_shift[3] ;
 wire \tx_shift[4] ;
 wire \tx_shift[5] ;
 wire \tx_shift[6] ;
 wire \tx_shift[7] ;
 wire \tx_state[0] ;
 wire \tx_state[1] ;
 wire \tx_state[2] ;
 wire \tx_state[3] ;
 wire \tx_wr_ptr[0] ;
 wire \tx_wr_ptr[1] ;
 wire \tx_wr_ptr[2] ;
 wire \tx_wr_ptr[3] ;

 sky130_fd_sc_hd__inv_2 _1202_ (.A(baud_tick),
    .Y(_1071_));
 sky130_fd_sc_hd__inv_2 _1203_ (.A(\tx_state[0] ),
    .Y(_1072_));
 sky130_fd_sc_hd__inv_2 _1204_ (.A(\tx_count[4] ),
    .Y(_1073_));
 sky130_fd_sc_hd__inv_2 _1205_ (.A(\rx_count[3] ),
    .Y(_1074_));
 sky130_fd_sc_hd__inv_2 _1206_ (.A(\rx_count[4] ),
    .Y(_1075_));
 sky130_fd_sc_hd__inv_2 _1207_ (.A(\rx_state[0] ),
    .Y(_1076_));
 sky130_fd_sc_hd__inv_2 _1208_ (.A(\rx_state[2] ),
    .Y(_1077_));
 sky130_fd_sc_hd__inv_2 _1209_ (.A(\tx_state[1] ),
    .Y(_1078_));
 sky130_fd_sc_hd__inv_2 _1210_ (.A(rd_en),
    .Y(_1079_));
 sky130_fd_sc_hd__inv_2 _1211_ (.A(wr_addr[0]),
    .Y(_1080_));
 sky130_fd_sc_hd__inv_2 _1212_ (.A(\baud_cnt[8] ),
    .Y(_1081_));
 sky130_fd_sc_hd__inv_2 _1213_ (.A(reset_n),
    .Y(_1082_));
 sky130_fd_sc_hd__nand2_2 _1214_ (.A(\rx_bit_cnt[1] ),
    .B(\rx_bit_cnt[0] ),
    .Y(_1083_));
 sky130_fd_sc_hd__nand3_2 _1215_ (.A(\rx_bit_cnt[1] ),
    .B(\rx_bit_cnt[0] ),
    .C(\rx_bit_cnt[2] ),
    .Y(_1084_));
 sky130_fd_sc_hd__nor2_2 _1216_ (.A(\rx_bit_cnt[3] ),
    .B(_1084_),
    .Y(_1085_));
 sky130_fd_sc_hd__nand2_2 _1217_ (.A(enable),
    .B(rx_enable),
    .Y(_1086_));
 sky130_fd_sc_hd__o31a_2 _1218_ (.A1(_1076_),
    .A2(uart_rx),
    .A3(_1086_),
    .B1(baud_tick),
    .X(_1087_));
 sky130_fd_sc_hd__and2_2 _1219_ (.A(\rx_state[1] ),
    .B(_1087_),
    .X(_1088_));
 sky130_fd_sc_hd__a22o_2 _1220_ (.A1(_1071_),
    .A2(\rx_state[3] ),
    .B1(_1085_),
    .B2(_1088_),
    .X(_0058_));
 sky130_fd_sc_hd__nor2_2 _1221_ (.A(\tx_count[0] ),
    .B(\tx_count[1] ),
    .Y(_1089_));
 sky130_fd_sc_hd__or3_2 _1222_ (.A(\tx_count[0] ),
    .B(\tx_count[1] ),
    .C(\tx_count[2] ),
    .X(_1090_));
 sky130_fd_sc_hd__or3_2 _1223_ (.A(\tx_count[4] ),
    .B(\tx_count[3] ),
    .C(_1090_),
    .X(_1091_));
 sky130_fd_sc_hd__and2_2 _1224_ (.A(enable),
    .B(tx_enable),
    .X(_1092_));
 sky130_fd_sc_hd__nand2_2 _1225_ (.A(enable),
    .B(tx_enable),
    .Y(_1093_));
 sky130_fd_sc_hd__and3_2 _1226_ (.A(baud_tick),
    .B(_1091_),
    .C(_1092_),
    .X(_1094_));
 sky130_fd_sc_hd__inv_2 _1227_ (.A(_1094_),
    .Y(_1095_));
 sky130_fd_sc_hd__a22o_2 _1228_ (.A1(baud_tick),
    .A2(\tx_state[3] ),
    .B1(_1095_),
    .B2(\tx_state[0] ),
    .X(_0059_));
 sky130_fd_sc_hd__nand2_2 _1229_ (.A(\tx_bit_cnt[1] ),
    .B(\tx_bit_cnt[0] ),
    .Y(_1096_));
 sky130_fd_sc_hd__nand3_2 _1230_ (.A(\tx_bit_cnt[1] ),
    .B(\tx_bit_cnt[0] ),
    .C(\tx_bit_cnt[2] ),
    .Y(_1097_));
 sky130_fd_sc_hd__nor2_2 _1231_ (.A(\tx_bit_cnt[3] ),
    .B(_1097_),
    .Y(_1098_));
 sky130_fd_sc_hd__nand2_2 _1232_ (.A(baud_tick),
    .B(_1098_),
    .Y(_1099_));
 sky130_fd_sc_hd__a22o_2 _1233_ (.A1(baud_tick),
    .A2(\tx_state[2] ),
    .B1(_1099_),
    .B2(\tx_state[1] ),
    .X(_0060_));
 sky130_fd_sc_hd__nand2_2 _1234_ (.A(baud_tick),
    .B(\tx_state[0] ),
    .Y(_1100_));
 sky130_fd_sc_hd__nor2_2 _1235_ (.A(_1072_),
    .B(_1095_),
    .Y(_1101_));
 sky130_fd_sc_hd__nand2_2 _1236_ (.A(\tx_state[0] ),
    .B(_1094_),
    .Y(_1102_));
 sky130_fd_sc_hd__a21o_2 _1237_ (.A1(_1071_),
    .A2(\tx_state[2] ),
    .B1(_1101_),
    .X(_0061_));
 sky130_fd_sc_hd__a2bb2o_2 _1238_ (.A1_N(_1078_),
    .A2_N(_1099_),
    .B1(_1071_),
    .B2(\tx_state[3] ),
    .X(_0062_));
 sky130_fd_sc_hd__and3b_2 _1239_ (.A_N(uart_rx),
    .B(\rx_state[2] ),
    .C(_1087_),
    .X(_1103_));
 sky130_fd_sc_hd__nand2_2 _1240_ (.A(baud_tick),
    .B(_1085_),
    .Y(_1104_));
 sky130_fd_sc_hd__or4_2 _1241_ (.A(_1071_),
    .B(_1076_),
    .C(uart_rx),
    .D(_1086_),
    .X(_1105_));
 sky130_fd_sc_hd__a31o_2 _1242_ (.A1(\rx_state[1] ),
    .A2(_1104_),
    .A3(_1105_),
    .B1(_1103_),
    .X(_0057_));
 sky130_fd_sc_hd__and2_2 _1243_ (.A(uart_rx),
    .B(\rx_state[2] ),
    .X(_1106_));
 sky130_fd_sc_hd__o21a_2 _1244_ (.A1(\rx_state[3] ),
    .A2(_1106_),
    .B1(baud_tick),
    .X(_1107_));
 sky130_fd_sc_hd__o21a_2 _1245_ (.A1(\rx_state[0] ),
    .A2(_1107_),
    .B1(_1105_),
    .X(_0056_));
 sky130_fd_sc_hd__or3_2 _1246_ (.A(wr_addr[5]),
    .B(wr_addr[7]),
    .C(wr_addr[6]),
    .X(_1108_));
 sky130_fd_sc_hd__or4b_2 _1247_ (.A(wr_addr[1]),
    .B(wr_addr[0]),
    .C(_1108_),
    .D_N(wr_addr[3]),
    .X(_1109_));
 sky130_fd_sc_hd__inv_2 _1248_ (.A(_1109_),
    .Y(_1110_));
 sky130_fd_sc_hd__and4_2 _1249_ (.A(wr_en),
    .B(wr_addr[4]),
    .C(wr_addr[2]),
    .D(_1110_),
    .X(_1111_));
 sky130_fd_sc_hd__nand2_2 _1250_ (.A(wr_data[5]),
    .B(_1111_),
    .Y(_1112_));
 sky130_fd_sc_hd__nand3_2 _1251_ (.A(baud_tick),
    .B(uart_rx),
    .C(\rx_state[3] ),
    .Y(_1113_));
 sky130_fd_sc_hd__a31o_2 _1252_ (.A1(baud_tick),
    .A2(uart_rx),
    .A3(\rx_state[3] ),
    .B1(loopback_valid),
    .X(_1114_));
 sky130_fd_sc_hd__or2_2 _1253_ (.A(\rx_count[1] ),
    .B(\rx_count[0] ),
    .X(_1115_));
 sky130_fd_sc_hd__or4_2 _1254_ (.A(\rx_count[1] ),
    .B(\rx_count[0] ),
    .C(\rx_count[3] ),
    .D(\rx_count[2] ),
    .X(_1116_));
 sky130_fd_sc_hd__or2_2 _1255_ (.A(_1075_),
    .B(_1116_),
    .X(_1117_));
 sky130_fd_sc_hd__and3_2 _1256_ (.A(enable),
    .B(rx_enable),
    .C(_1117_),
    .X(_1118_));
 sky130_fd_sc_hd__and3_2 _1257_ (.A(enable),
    .B(rx_enable),
    .C(_1114_),
    .X(_1119_));
 sky130_fd_sc_hd__and2_2 _1258_ (.A(_1117_),
    .B(_1119_),
    .X(_1120_));
 sky130_fd_sc_hd__nand2_2 _1259_ (.A(_1117_),
    .B(_1119_),
    .Y(_1121_));
 sky130_fd_sc_hd__a21o_2 _1260_ (.A1(baud_tick),
    .A2(\tx_state[3] ),
    .B1(_1120_),
    .X(_1122_));
 sky130_fd_sc_hd__and3_2 _1261_ (.A(packet_count[0]),
    .B(packet_count[1]),
    .C(packet_count[2]),
    .X(_1123_));
 sky130_fd_sc_hd__and2_2 _1262_ (.A(packet_count[3]),
    .B(_1123_),
    .X(_1124_));
 sky130_fd_sc_hd__and3_2 _1263_ (.A(packet_count[4]),
    .B(packet_count[5]),
    .C(_1124_),
    .X(_1125_));
 sky130_fd_sc_hd__and2_2 _1264_ (.A(packet_count[6]),
    .B(_1125_),
    .X(_1126_));
 sky130_fd_sc_hd__xor2_2 _1265_ (.A(packet_count[7]),
    .B(_1126_),
    .X(_1127_));
 sky130_fd_sc_hd__xnor2_2 _1266_ (.A(\packet_len_reg[7] ),
    .B(_1127_),
    .Y(_1128_));
 sky130_fd_sc_hd__nor2_2 _1267_ (.A(packet_count[6]),
    .B(_1125_),
    .Y(_1129_));
 sky130_fd_sc_hd__o21ai_2 _1268_ (.A1(_1126_),
    .A2(_1129_),
    .B1(\packet_len_reg[6] ),
    .Y(_1130_));
 sky130_fd_sc_hd__or3_2 _1269_ (.A(\packet_len_reg[6] ),
    .B(_1126_),
    .C(_1129_),
    .X(_1131_));
 sky130_fd_sc_hd__a21oi_2 _1270_ (.A1(packet_count[4]),
    .A2(_1124_),
    .B1(packet_count[5]),
    .Y(_1132_));
 sky130_fd_sc_hd__o21ai_2 _1271_ (.A1(_1125_),
    .A2(_1132_),
    .B1(\packet_len_reg[5] ),
    .Y(_1133_));
 sky130_fd_sc_hd__or3_2 _1272_ (.A(\packet_len_reg[5] ),
    .B(_1125_),
    .C(_1132_),
    .X(_1134_));
 sky130_fd_sc_hd__xor2_2 _1273_ (.A(packet_count[4]),
    .B(_1124_),
    .X(_1135_));
 sky130_fd_sc_hd__xnor2_2 _1274_ (.A(\packet_len_reg[4] ),
    .B(_1135_),
    .Y(_1136_));
 sky130_fd_sc_hd__nor2_2 _1275_ (.A(packet_count[3]),
    .B(_1123_),
    .Y(_1137_));
 sky130_fd_sc_hd__nor2_2 _1276_ (.A(_1124_),
    .B(_1137_),
    .Y(_1138_));
 sky130_fd_sc_hd__xnor2_2 _1277_ (.A(\packet_len_reg[3] ),
    .B(_1138_),
    .Y(_1139_));
 sky130_fd_sc_hd__xor2_2 _1278_ (.A(packet_count[0]),
    .B(packet_count[1]),
    .X(_1140_));
 sky130_fd_sc_hd__xnor2_2 _1279_ (.A(\packet_len_reg[1] ),
    .B(_1140_),
    .Y(_1141_));
 sky130_fd_sc_hd__or4_2 _1280_ (.A(\packet_len_reg[5] ),
    .B(\packet_len_reg[4] ),
    .C(\packet_len_reg[7] ),
    .D(\packet_len_reg[6] ),
    .X(_1142_));
 sky130_fd_sc_hd__or4_2 _1281_ (.A(\packet_len_reg[1] ),
    .B(\packet_len_reg[0] ),
    .C(\packet_len_reg[3] ),
    .D(\packet_len_reg[2] ),
    .X(_1143_));
 sky130_fd_sc_hd__or2_2 _1282_ (.A(_1142_),
    .B(_1143_),
    .X(_1144_));
 sky130_fd_sc_hd__or2_2 _1283_ (.A(\packet_len_reg[0] ),
    .B(packet_count[0]),
    .X(_1145_));
 sky130_fd_sc_hd__nand2_2 _1284_ (.A(\packet_len_reg[0] ),
    .B(packet_count[0]),
    .Y(_1146_));
 sky130_fd_sc_hd__and4_2 _1285_ (.A(_1141_),
    .B(_1144_),
    .C(_1145_),
    .D(_1146_),
    .X(_1147_));
 sky130_fd_sc_hd__a21oi_2 _1286_ (.A1(packet_count[0]),
    .A2(packet_count[1]),
    .B1(packet_count[2]),
    .Y(_1148_));
 sky130_fd_sc_hd__nor2_2 _1287_ (.A(_1123_),
    .B(_1148_),
    .Y(_1149_));
 sky130_fd_sc_hd__xnor2_2 _1288_ (.A(\packet_len_reg[2] ),
    .B(_1149_),
    .Y(_1150_));
 sky130_fd_sc_hd__and4_2 _1289_ (.A(_1136_),
    .B(_1139_),
    .C(_1147_),
    .D(_1150_),
    .X(_1151_));
 sky130_fd_sc_hd__and3_2 _1290_ (.A(_1133_),
    .B(_1134_),
    .C(_1151_),
    .X(_1152_));
 sky130_fd_sc_hd__and4_2 _1291_ (.A(_1128_),
    .B(_1130_),
    .C(_1131_),
    .D(_1152_),
    .X(_1153_));
 sky130_fd_sc_hd__a22o_2 _1292_ (.A1(\irq_status_reg[5] ),
    .A2(_1112_),
    .B1(_1122_),
    .B2(_1153_),
    .X(_0024_));
 sky130_fd_sc_hd__o21a_2 _1293_ (.A1(\rx_state[3] ),
    .A2(_1106_),
    .B1(_1087_),
    .X(_1154_));
 sky130_fd_sc_hd__a21boi_2 _1294_ (.A1(uart_rx),
    .A2(_1077_),
    .B1_N(_1154_),
    .Y(_1155_));
 sky130_fd_sc_hd__nand2_2 _1295_ (.A(wr_data[4]),
    .B(_1111_),
    .Y(_1156_));
 sky130_fd_sc_hd__a21o_2 _1296_ (.A1(\irq_status_reg[4] ),
    .A2(_1156_),
    .B1(_1155_),
    .X(_0023_));
 sky130_fd_sc_hd__nand2_2 _1297_ (.A(wr_data[0]),
    .B(_1111_),
    .Y(_1157_));
 sky130_fd_sc_hd__a21o_2 _1298_ (.A1(\irq_status_reg[0] ),
    .A2(_1157_),
    .B1(_1120_),
    .X(_0019_));
 sky130_fd_sc_hd__nor3_2 _1299_ (.A(_1091_),
    .B(_1093_),
    .C(_1100_),
    .Y(_1158_));
 sky130_fd_sc_hd__nand2_2 _1300_ (.A(wr_data[3]),
    .B(_1111_),
    .Y(_1159_));
 sky130_fd_sc_hd__a21o_2 _1301_ (.A1(\irq_status_reg[3] ),
    .A2(_1159_),
    .B1(_1158_),
    .X(_0022_));
 sky130_fd_sc_hd__a21boi_2 _1302_ (.A1(wr_data[1]),
    .A2(_1111_),
    .B1_N(\irq_status_reg[1] ),
    .Y(_1160_));
 sky130_fd_sc_hd__a31o_2 _1303_ (.A1(baud_tick),
    .A2(\tx_state[3] ),
    .A3(_1153_),
    .B1(_1160_),
    .X(_0020_));
 sky130_fd_sc_hd__nand2_2 _1304_ (.A(wr_data[2]),
    .B(_1111_),
    .Y(_1161_));
 sky130_fd_sc_hd__nor2_2 _1305_ (.A(_1086_),
    .B(_1117_),
    .Y(_1162_));
 sky130_fd_sc_hd__or3_2 _1306_ (.A(_1073_),
    .B(\tx_count[3] ),
    .C(_1090_),
    .X(_1163_));
 sky130_fd_sc_hd__and2_2 _1307_ (.A(_1092_),
    .B(_1163_),
    .X(_1164_));
 sky130_fd_sc_hd__nand3b_2 _1308_ (.A_N(wr_addr[4]),
    .B(wr_addr[2]),
    .C(wr_en),
    .Y(_1165_));
 sky130_fd_sc_hd__nor2_2 _1309_ (.A(_1109_),
    .B(_1165_),
    .Y(_1166_));
 sky130_fd_sc_hd__or2_2 _1310_ (.A(_1109_),
    .B(_1165_),
    .X(_1167_));
 sky130_fd_sc_hd__nor2_2 _1311_ (.A(_1164_),
    .B(_1167_),
    .Y(_1168_));
 sky130_fd_sc_hd__a21o_2 _1312_ (.A1(\irq_status_reg[2] ),
    .A2(_1161_),
    .B1(_1168_),
    .X(_1169_));
 sky130_fd_sc_hd__or3b_2 _1313_ (.A(_1109_),
    .B(wr_addr[4]),
    .C_N(wr_addr[2]),
    .X(_1170_));
 sky130_fd_sc_hd__inv_2 _1314_ (.A(_1170_),
    .Y(_1171_));
 sky130_fd_sc_hd__a21o_2 _1315_ (.A1(_1114_),
    .A2(_1162_),
    .B1(_1169_),
    .X(_0021_));
 sky130_fd_sc_hd__or3_2 _1316_ (.A(\baud_div_reg[0] ),
    .B(\baud_div_reg[1] ),
    .C(\baud_div_reg[2] ),
    .X(_1172_));
 sky130_fd_sc_hd__or4_2 _1317_ (.A(\baud_div_reg[0] ),
    .B(\baud_div_reg[1] ),
    .C(\baud_div_reg[2] ),
    .D(\baud_div_reg[3] ),
    .X(_1173_));
 sky130_fd_sc_hd__nor2_2 _1318_ (.A(\baud_div_reg[4] ),
    .B(_1173_),
    .Y(_1174_));
 sky130_fd_sc_hd__or4_2 _1319_ (.A(\baud_div_reg[4] ),
    .B(\baud_div_reg[5] ),
    .C(\baud_div_reg[6] ),
    .D(_1173_),
    .X(_1175_));
 sky130_fd_sc_hd__or2_2 _1320_ (.A(\baud_div_reg[8] ),
    .B(\baud_div_reg[9] ),
    .X(_1176_));
 sky130_fd_sc_hd__or2_2 _1321_ (.A(\baud_div_reg[10] ),
    .B(\baud_div_reg[11] ),
    .X(_1177_));
 sky130_fd_sc_hd__or4_2 _1322_ (.A(\baud_div_reg[7] ),
    .B(_1175_),
    .C(_1176_),
    .D(_1177_),
    .X(_1178_));
 sky130_fd_sc_hd__nor2_2 _1323_ (.A(\baud_div_reg[12] ),
    .B(_1178_),
    .Y(_1179_));
 sky130_fd_sc_hd__or4_2 _1324_ (.A(\baud_div_reg[12] ),
    .B(\baud_div_reg[13] ),
    .C(\baud_div_reg[14] ),
    .D(_1178_),
    .X(_1180_));
 sky130_fd_sc_hd__or2_2 _1325_ (.A(\baud_div_reg[15] ),
    .B(_1180_),
    .X(_1181_));
 sky130_fd_sc_hd__o31ai_2 _1326_ (.A1(\baud_div_reg[12] ),
    .A2(\baud_div_reg[13] ),
    .A3(_1178_),
    .B1(\baud_div_reg[14] ),
    .Y(_1182_));
 sky130_fd_sc_hd__and3_2 _1327_ (.A(\baud_cnt[14] ),
    .B(_1180_),
    .C(_1182_),
    .X(_1183_));
 sky130_fd_sc_hd__xnor2_2 _1328_ (.A(\baud_div_reg[13] ),
    .B(_1179_),
    .Y(_1184_));
 sky130_fd_sc_hd__xor2_2 _1329_ (.A(\baud_div_reg[12] ),
    .B(_1178_),
    .X(_1185_));
 sky130_fd_sc_hd__a21oi_2 _1330_ (.A1(_1180_),
    .A2(_1182_),
    .B1(\baud_cnt[14] ),
    .Y(_1186_));
 sky130_fd_sc_hd__or4_2 _1331_ (.A(\baud_div_reg[7] ),
    .B(\baud_div_reg[10] ),
    .C(_1175_),
    .D(_1176_),
    .X(_1187_));
 sky130_fd_sc_hd__a21boi_2 _1332_ (.A1(\baud_div_reg[11] ),
    .A2(_1187_),
    .B1_N(_1178_),
    .Y(_1188_));
 sky130_fd_sc_hd__o31ai_2 _1333_ (.A1(\baud_div_reg[0] ),
    .A2(\baud_div_reg[1] ),
    .A3(\baud_div_reg[2] ),
    .B1(\baud_div_reg[3] ),
    .Y(_1189_));
 sky130_fd_sc_hd__and3_2 _1334_ (.A(\baud_cnt[3] ),
    .B(_1173_),
    .C(_1189_),
    .X(_1190_));
 sky130_fd_sc_hd__a21oi_2 _1335_ (.A1(_1173_),
    .A2(_1189_),
    .B1(\baud_cnt[3] ),
    .Y(_1191_));
 sky130_fd_sc_hd__xor2_2 _1336_ (.A(\baud_div_reg[1] ),
    .B(\baud_cnt[1] ),
    .X(_1192_));
 sky130_fd_sc_hd__and2b_2 _1337_ (.A_N(\baud_div_reg[0] ),
    .B(\baud_cnt[0] ),
    .X(_1193_));
 sky130_fd_sc_hd__nor2_2 _1338_ (.A(\baud_cnt[0] ),
    .B(_1192_),
    .Y(_1194_));
 sky130_fd_sc_hd__a22oi_2 _1339_ (.A1(_1192_),
    .A2(_1193_),
    .B1(_1194_),
    .B2(\baud_div_reg[0] ),
    .Y(_1195_));
 sky130_fd_sc_hd__o21ai_2 _1340_ (.A1(\baud_div_reg[0] ),
    .A2(\baud_div_reg[1] ),
    .B1(\baud_div_reg[2] ),
    .Y(_1196_));
 sky130_fd_sc_hd__and3_2 _1341_ (.A(\baud_cnt[2] ),
    .B(_1172_),
    .C(_1196_),
    .X(_1197_));
 sky130_fd_sc_hd__a21oi_2 _1342_ (.A1(_1172_),
    .A2(_1196_),
    .B1(\baud_cnt[2] ),
    .Y(_1198_));
 sky130_fd_sc_hd__or3_2 _1343_ (.A(_1190_),
    .B(_1191_),
    .C(_1198_),
    .X(_1199_));
 sky130_fd_sc_hd__xor2_2 _1344_ (.A(\baud_div_reg[4] ),
    .B(_1173_),
    .X(_1200_));
 sky130_fd_sc_hd__xnor2_2 _1345_ (.A(\baud_cnt[4] ),
    .B(_1200_),
    .Y(_1201_));
 sky130_fd_sc_hd__or4_2 _1346_ (.A(_1195_),
    .B(_1197_),
    .C(_1199_),
    .D(_1201_),
    .X(_0414_));
 sky130_fd_sc_hd__xnor2_2 _1347_ (.A(\baud_div_reg[5] ),
    .B(_1174_),
    .Y(_0415_));
 sky130_fd_sc_hd__xnor2_2 _1348_ (.A(\baud_cnt[5] ),
    .B(_0415_),
    .Y(_0416_));
 sky130_fd_sc_hd__o31ai_2 _1349_ (.A1(\baud_div_reg[4] ),
    .A2(\baud_div_reg[5] ),
    .A3(_1173_),
    .B1(\baud_div_reg[6] ),
    .Y(_0417_));
 sky130_fd_sc_hd__nand2_2 _1350_ (.A(_1175_),
    .B(_0417_),
    .Y(_0418_));
 sky130_fd_sc_hd__xor2_2 _1351_ (.A(\baud_cnt[6] ),
    .B(_0418_),
    .X(_0419_));
 sky130_fd_sc_hd__xor2_2 _1352_ (.A(\baud_div_reg[7] ),
    .B(_1175_),
    .X(_0420_));
 sky130_fd_sc_hd__xnor2_2 _1353_ (.A(\baud_cnt[7] ),
    .B(_0420_),
    .Y(_0421_));
 sky130_fd_sc_hd__or4_2 _1354_ (.A(_0414_),
    .B(_0416_),
    .C(_0419_),
    .D(_0421_),
    .X(_0422_));
 sky130_fd_sc_hd__xor2_2 _1355_ (.A(\baud_cnt[9] ),
    .B(\baud_div_reg[9] ),
    .X(_0423_));
 sky130_fd_sc_hd__a21o_2 _1356_ (.A1(_1081_),
    .A2(\baud_div_reg[8] ),
    .B1(_0423_),
    .X(_0424_));
 sky130_fd_sc_hd__o32a_2 _1357_ (.A1(\baud_div_reg[7] ),
    .A2(_1175_),
    .A3(_0423_),
    .B1(_1081_),
    .B2(\baud_div_reg[8] ),
    .X(_0425_));
 sky130_fd_sc_hd__or3b_2 _1358_ (.A(\baud_div_reg[7] ),
    .B(_1175_),
    .C_N(_0424_),
    .X(_0426_));
 sky130_fd_sc_hd__mux2_1 _1359_ (.A0(_0426_),
    .A1(_0424_),
    .S(_0425_),
    .X(_0427_));
 sky130_fd_sc_hd__o31ai_2 _1360_ (.A1(\baud_div_reg[7] ),
    .A2(_1175_),
    .A3(_1176_),
    .B1(\baud_div_reg[10] ),
    .Y(_0428_));
 sky130_fd_sc_hd__and2_2 _1361_ (.A(_1187_),
    .B(_0428_),
    .X(_0429_));
 sky130_fd_sc_hd__nand2_2 _1362_ (.A(\baud_cnt[10] ),
    .B(_0429_),
    .Y(_0430_));
 sky130_fd_sc_hd__nor2_2 _1363_ (.A(\baud_cnt[10] ),
    .B(_0429_),
    .Y(_0431_));
 sky130_fd_sc_hd__or4b_2 _1364_ (.A(_0422_),
    .B(_0431_),
    .C(_0427_),
    .D_N(_0430_),
    .X(_0432_));
 sky130_fd_sc_hd__xnor2_2 _1365_ (.A(\baud_cnt[13] ),
    .B(_1184_),
    .Y(_0433_));
 sky130_fd_sc_hd__nand3_2 _1366_ (.A(\baud_cnt[15] ),
    .B(\baud_div_reg[15] ),
    .C(_1180_),
    .Y(_0434_));
 sky130_fd_sc_hd__a21o_2 _1367_ (.A1(\baud_div_reg[15] ),
    .A2(_1180_),
    .B1(\baud_cnt[15] ),
    .X(_0435_));
 sky130_fd_sc_hd__o2bb2a_2 _1368_ (.A1_N(\baud_cnt[11] ),
    .A2_N(_1188_),
    .B1(_1185_),
    .B2(\baud_cnt[12] ),
    .X(_0436_));
 sky130_fd_sc_hd__a2bb2o_2 _1369_ (.A1_N(\baud_cnt[11] ),
    .A2_N(_1188_),
    .B1(_1185_),
    .B2(\baud_cnt[12] ),
    .X(_0437_));
 sky130_fd_sc_hd__or4b_2 _1370_ (.A(_1183_),
    .B(_0437_),
    .C(_1186_),
    .D_N(_0436_),
    .X(_0438_));
 sky130_fd_sc_hd__a2111o_2 _1371_ (.A1(_0434_),
    .A2(_0435_),
    .B1(_0438_),
    .C1(_0433_),
    .D1(_0432_),
    .X(_0439_));
 sky130_fd_sc_hd__nand2_2 _1372_ (.A(_1181_),
    .B(_0439_),
    .Y(_0016_));
 sky130_fd_sc_hd__and3b_2 _1373_ (.A_N(\baud_cnt[0] ),
    .B(_1181_),
    .C(_0439_),
    .X(_0000_));
 sky130_fd_sc_hd__or2_2 _1374_ (.A(\baud_cnt[0] ),
    .B(\baud_cnt[1] ),
    .X(_0440_));
 sky130_fd_sc_hd__nand2_2 _1375_ (.A(\baud_cnt[0] ),
    .B(\baud_cnt[1] ),
    .Y(_0441_));
 sky130_fd_sc_hd__and4_2 _1376_ (.A(_1181_),
    .B(_0439_),
    .C(_0440_),
    .D(_0441_),
    .X(_0007_));
 sky130_fd_sc_hd__and3_2 _1377_ (.A(\baud_cnt[0] ),
    .B(\baud_cnt[1] ),
    .C(\baud_cnt[2] ),
    .X(_0442_));
 sky130_fd_sc_hd__a21oi_2 _1378_ (.A1(\baud_cnt[0] ),
    .A2(\baud_cnt[1] ),
    .B1(\baud_cnt[2] ),
    .Y(_0443_));
 sky130_fd_sc_hd__nor2_2 _1379_ (.A(_0442_),
    .B(_0443_),
    .Y(_0444_));
 sky130_fd_sc_hd__and3_2 _1380_ (.A(_1181_),
    .B(_0439_),
    .C(_0444_),
    .X(_0008_));
 sky130_fd_sc_hd__and4_2 _1381_ (.A(\baud_cnt[0] ),
    .B(\baud_cnt[1] ),
    .C(\baud_cnt[2] ),
    .D(\baud_cnt[3] ),
    .X(_0445_));
 sky130_fd_sc_hd__nor2_2 _1382_ (.A(\baud_cnt[3] ),
    .B(_0442_),
    .Y(_0446_));
 sky130_fd_sc_hd__nor2_2 _1383_ (.A(_0445_),
    .B(_0446_),
    .Y(_0447_));
 sky130_fd_sc_hd__and3_2 _1384_ (.A(_1181_),
    .B(_0439_),
    .C(_0447_),
    .X(_0009_));
 sky130_fd_sc_hd__nand2_2 _1385_ (.A(\baud_cnt[4] ),
    .B(_0445_),
    .Y(_0448_));
 sky130_fd_sc_hd__or2_2 _1386_ (.A(\baud_cnt[4] ),
    .B(_0445_),
    .X(_0449_));
 sky130_fd_sc_hd__and4_2 _1387_ (.A(_1181_),
    .B(_0439_),
    .C(_0448_),
    .D(_0449_),
    .X(_0010_));
 sky130_fd_sc_hd__and3_2 _1388_ (.A(\baud_cnt[4] ),
    .B(\baud_cnt[5] ),
    .C(_0445_),
    .X(_0450_));
 sky130_fd_sc_hd__a21oi_2 _1389_ (.A1(\baud_cnt[4] ),
    .A2(_0445_),
    .B1(\baud_cnt[5] ),
    .Y(_0451_));
 sky130_fd_sc_hd__nor2_2 _1390_ (.A(_0450_),
    .B(_0451_),
    .Y(_0452_));
 sky130_fd_sc_hd__and3_2 _1391_ (.A(_1181_),
    .B(_0439_),
    .C(_0452_),
    .X(_0011_));
 sky130_fd_sc_hd__and4_2 _1392_ (.A(\baud_cnt[4] ),
    .B(\baud_cnt[5] ),
    .C(\baud_cnt[6] ),
    .D(_0445_),
    .X(_0453_));
 sky130_fd_sc_hd__nor2_2 _1393_ (.A(\baud_cnt[6] ),
    .B(_0450_),
    .Y(_0454_));
 sky130_fd_sc_hd__nor2_2 _1394_ (.A(_0453_),
    .B(_0454_),
    .Y(_0455_));
 sky130_fd_sc_hd__and3_2 _1395_ (.A(_1181_),
    .B(_0439_),
    .C(_0455_),
    .X(_0012_));
 sky130_fd_sc_hd__nand2_2 _1396_ (.A(\baud_cnt[7] ),
    .B(_0453_),
    .Y(_0456_));
 sky130_fd_sc_hd__or2_2 _1397_ (.A(\baud_cnt[7] ),
    .B(_0453_),
    .X(_0457_));
 sky130_fd_sc_hd__and4_2 _1398_ (.A(_1181_),
    .B(_0439_),
    .C(_0456_),
    .D(_0457_),
    .X(_0013_));
 sky130_fd_sc_hd__and3_2 _1399_ (.A(\baud_cnt[7] ),
    .B(\baud_cnt[8] ),
    .C(_0453_),
    .X(_0458_));
 sky130_fd_sc_hd__a21oi_2 _1400_ (.A1(\baud_cnt[7] ),
    .A2(_0453_),
    .B1(\baud_cnt[8] ),
    .Y(_0459_));
 sky130_fd_sc_hd__nor2_2 _1401_ (.A(_0458_),
    .B(_0459_),
    .Y(_0460_));
 sky130_fd_sc_hd__and3_2 _1402_ (.A(_1181_),
    .B(_0439_),
    .C(_0460_),
    .X(_0014_));
 sky130_fd_sc_hd__and4_2 _1403_ (.A(\baud_cnt[7] ),
    .B(\baud_cnt[8] ),
    .C(\baud_cnt[9] ),
    .D(_0453_),
    .X(_0461_));
 sky130_fd_sc_hd__nor2_2 _1404_ (.A(\baud_cnt[9] ),
    .B(_0458_),
    .Y(_0462_));
 sky130_fd_sc_hd__nor2_2 _1405_ (.A(_0461_),
    .B(_0462_),
    .Y(_0463_));
 sky130_fd_sc_hd__and3_2 _1406_ (.A(_1181_),
    .B(_0439_),
    .C(_0463_),
    .X(_0015_));
 sky130_fd_sc_hd__nand2_2 _1407_ (.A(\baud_cnt[10] ),
    .B(_0461_),
    .Y(_0464_));
 sky130_fd_sc_hd__or2_2 _1408_ (.A(\baud_cnt[10] ),
    .B(_0461_),
    .X(_0465_));
 sky130_fd_sc_hd__and4_2 _1409_ (.A(_1181_),
    .B(_0439_),
    .C(_0464_),
    .D(_0465_),
    .X(_0001_));
 sky130_fd_sc_hd__and3_2 _1410_ (.A(\baud_cnt[10] ),
    .B(\baud_cnt[11] ),
    .C(_0461_),
    .X(_0466_));
 sky130_fd_sc_hd__a21oi_2 _1411_ (.A1(\baud_cnt[10] ),
    .A2(_0461_),
    .B1(\baud_cnt[11] ),
    .Y(_0467_));
 sky130_fd_sc_hd__nor2_2 _1412_ (.A(_0466_),
    .B(_0467_),
    .Y(_0468_));
 sky130_fd_sc_hd__and3_2 _1413_ (.A(_1181_),
    .B(_0439_),
    .C(_0468_),
    .X(_0002_));
 sky130_fd_sc_hd__and2_2 _1414_ (.A(\baud_cnt[12] ),
    .B(_0466_),
    .X(_0469_));
 sky130_fd_sc_hd__nor2_2 _1415_ (.A(\baud_cnt[12] ),
    .B(_0466_),
    .Y(_0470_));
 sky130_fd_sc_hd__nor2_2 _1416_ (.A(_0469_),
    .B(_0470_),
    .Y(_0471_));
 sky130_fd_sc_hd__and3_2 _1417_ (.A(_1181_),
    .B(_0439_),
    .C(_0471_),
    .X(_0003_));
 sky130_fd_sc_hd__nand2_2 _1418_ (.A(\baud_cnt[13] ),
    .B(_0469_),
    .Y(_0472_));
 sky130_fd_sc_hd__or2_2 _1419_ (.A(\baud_cnt[13] ),
    .B(_0469_),
    .X(_0473_));
 sky130_fd_sc_hd__and4_2 _1420_ (.A(_1181_),
    .B(_0439_),
    .C(_0472_),
    .D(_0473_),
    .X(_0004_));
 sky130_fd_sc_hd__and3_2 _1421_ (.A(\baud_cnt[13] ),
    .B(\baud_cnt[14] ),
    .C(_0469_),
    .X(_0474_));
 sky130_fd_sc_hd__a21oi_2 _1422_ (.A1(\baud_cnt[13] ),
    .A2(_0469_),
    .B1(\baud_cnt[14] ),
    .Y(_0475_));
 sky130_fd_sc_hd__nor2_2 _1423_ (.A(_0474_),
    .B(_0475_),
    .Y(_0476_));
 sky130_fd_sc_hd__and3_2 _1424_ (.A(_1181_),
    .B(_0439_),
    .C(_0476_),
    .X(_0005_));
 sky130_fd_sc_hd__xor2_2 _1425_ (.A(\baud_cnt[15] ),
    .B(_0474_),
    .X(_0477_));
 sky130_fd_sc_hd__and3_2 _1426_ (.A(_1181_),
    .B(_0439_),
    .C(_0477_),
    .X(_0006_));
 sky130_fd_sc_hd__o22a_2 _1427_ (.A1(loopback_valid),
    .A2(_1154_),
    .B1(_1155_),
    .B2(_1162_),
    .X(_0478_));
 sky130_fd_sc_hd__or4_2 _1428_ (.A(error_r),
    .B(_1158_),
    .C(_1168_),
    .D(_0478_),
    .X(_0017_));
 sky130_fd_sc_hd__and3_2 _1429_ (.A(baud_tick),
    .B(\tx_state[3] ),
    .C(loopback),
    .X(_0479_));
 sky130_fd_sc_hd__and2b_2 _1430_ (.A_N(loopback_valid),
    .B(_0479_),
    .X(_0025_));
 sky130_fd_sc_hd__or4b_2 _1431_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .C(rd_addr[5]),
    .D_N(rd_addr[4]),
    .X(_0480_));
 sky130_fd_sc_hd__nor3_2 _1432_ (.A(rd_addr[7]),
    .B(rd_addr[6]),
    .C(_0480_),
    .Y(_0481_));
 sky130_fd_sc_hd__or4b_2 _1433_ (.A(_1079_),
    .B(rd_addr[2]),
    .C(rd_addr[3]),
    .D_N(_0481_),
    .X(_0482_));
 sky130_fd_sc_hd__a21bo_2 _1434_ (.A1(_1121_),
    .A2(_0482_),
    .B1_N(\rx_count[0] ),
    .X(_0483_));
 sky130_fd_sc_hd__nor2_2 _1435_ (.A(\rx_count[4] ),
    .B(_1116_),
    .Y(_0484_));
 sky130_fd_sc_hd__or2_2 _1436_ (.A(\rx_count[4] ),
    .B(_1116_),
    .X(_0485_));
 sky130_fd_sc_hd__and4bb_2 _1437_ (.A_N(rd_addr[2]),
    .B_N(rd_addr[3]),
    .C(_0481_),
    .D(_0485_),
    .X(_0486_));
 sky130_fd_sc_hd__nor2_2 _1438_ (.A(_0482_),
    .B(_0484_),
    .Y(_0487_));
 sky130_fd_sc_hd__nand2_2 _1439_ (.A(rd_en),
    .B(_0486_),
    .Y(_0488_));
 sky130_fd_sc_hd__o31a_2 _1440_ (.A1(\rx_count[0] ),
    .A2(_1120_),
    .A3(_0487_),
    .B1(_0483_),
    .X(_0042_));
 sky130_fd_sc_hd__nand2_2 _1441_ (.A(\rx_count[1] ),
    .B(\rx_count[0] ),
    .Y(_0489_));
 sky130_fd_sc_hd__o21ai_2 _1442_ (.A1(\rx_count[0] ),
    .A2(_0482_),
    .B1(\rx_count[1] ),
    .Y(_0490_));
 sky130_fd_sc_hd__or3_2 _1443_ (.A(\rx_count[1] ),
    .B(\rx_count[0] ),
    .C(_0488_),
    .X(_0491_));
 sky130_fd_sc_hd__a21oi_2 _1444_ (.A1(_0490_),
    .A2(_0491_),
    .B1(_1120_),
    .Y(_0492_));
 sky130_fd_sc_hd__a31o_2 _1445_ (.A1(_1115_),
    .A2(_1119_),
    .A3(_0489_),
    .B1(_0492_),
    .X(_0043_));
 sky130_fd_sc_hd__nand3_2 _1446_ (.A(\rx_count[1] ),
    .B(\rx_count[0] ),
    .C(\rx_count[2] ),
    .Y(_0493_));
 sky130_fd_sc_hd__a21o_2 _1447_ (.A1(\rx_count[1] ),
    .A2(\rx_count[0] ),
    .B1(\rx_count[2] ),
    .X(_0494_));
 sky130_fd_sc_hd__xnor2_2 _1448_ (.A(\rx_count[2] ),
    .B(_0491_),
    .Y(_0495_));
 sky130_fd_sc_hd__a32o_2 _1449_ (.A1(_1119_),
    .A2(_0493_),
    .A3(_0494_),
    .B1(_0495_),
    .B2(_1121_),
    .X(_0044_));
 sky130_fd_sc_hd__or2_2 _1450_ (.A(_1074_),
    .B(_0493_),
    .X(_0496_));
 sky130_fd_sc_hd__nand2_2 _1451_ (.A(_1074_),
    .B(_0493_),
    .Y(_0497_));
 sky130_fd_sc_hd__and3_2 _1452_ (.A(_1119_),
    .B(_0496_),
    .C(_0497_),
    .X(_0498_));
 sky130_fd_sc_hd__a21o_2 _1453_ (.A1(_0496_),
    .A2(_0497_),
    .B1(_1121_),
    .X(_0499_));
 sky130_fd_sc_hd__o31a_2 _1454_ (.A1(\rx_count[2] ),
    .A2(_1115_),
    .A3(_0482_),
    .B1(\rx_count[3] ),
    .X(_0500_));
 sky130_fd_sc_hd__nor2_2 _1455_ (.A(_1117_),
    .B(_0482_),
    .Y(_0501_));
 sky130_fd_sc_hd__o31a_2 _1456_ (.A1(_0498_),
    .A2(_0500_),
    .A3(_0501_),
    .B1(_0499_),
    .X(_0045_));
 sky130_fd_sc_hd__or3b_2 _1457_ (.A(_1086_),
    .B(_0496_),
    .C_N(_1114_),
    .X(_0502_));
 sky130_fd_sc_hd__o21a_2 _1458_ (.A1(_1116_),
    .A2(_0482_),
    .B1(\rx_count[4] ),
    .X(_0503_));
 sky130_fd_sc_hd__xnor2_2 _1459_ (.A(_0502_),
    .B(_0503_),
    .Y(_0046_));
 sky130_fd_sc_hd__and3_2 _1460_ (.A(wr_en),
    .B(_1164_),
    .C(_1171_),
    .X(_0504_));
 sky130_fd_sc_hd__nor2_2 _1461_ (.A(_1101_),
    .B(_0504_),
    .Y(_0505_));
 sky130_fd_sc_hd__xnor2_2 _1462_ (.A(\tx_count[0] ),
    .B(_0505_),
    .Y(_0051_));
 sky130_fd_sc_hd__and2_2 _1463_ (.A(\tx_count[0] ),
    .B(\tx_count[1] ),
    .X(_0506_));
 sky130_fd_sc_hd__nor3_2 _1464_ (.A(_1089_),
    .B(_1093_),
    .C(_0506_),
    .Y(_0507_));
 sky130_fd_sc_hd__a211o_2 _1465_ (.A1(\tx_count[1] ),
    .A2(_1093_),
    .B1(_1167_),
    .C1(_0507_),
    .X(_0508_));
 sky130_fd_sc_hd__o211a_2 _1466_ (.A1(\tx_count[1] ),
    .A2(_1166_),
    .B1(_0508_),
    .C1(_1100_),
    .X(_0509_));
 sky130_fd_sc_hd__mux2_1 _1467_ (.A0(\tx_count[1] ),
    .A1(_1091_),
    .S(_1092_),
    .X(_0510_));
 sky130_fd_sc_hd__and2b_2 _1468_ (.A_N(_0507_),
    .B(_0510_),
    .X(_0511_));
 sky130_fd_sc_hd__a31o_2 _1469_ (.A1(baud_tick),
    .A2(\tx_state[0] ),
    .A3(_0511_),
    .B1(_0509_),
    .X(_0052_));
 sky130_fd_sc_hd__and3_2 _1470_ (.A(_1092_),
    .B(_1166_),
    .C(_0506_),
    .X(_0512_));
 sky130_fd_sc_hd__mux2_1 _1471_ (.A0(_1089_),
    .A1(_0512_),
    .S(_1102_),
    .X(_0513_));
 sky130_fd_sc_hd__xor2_2 _1472_ (.A(\tx_count[2] ),
    .B(_0513_),
    .X(_0053_));
 sky130_fd_sc_hd__and3_2 _1473_ (.A(\tx_count[2] ),
    .B(_1102_),
    .C(_0512_),
    .X(_0514_));
 sky130_fd_sc_hd__nand2_2 _1474_ (.A(\tx_count[3] ),
    .B(_0514_),
    .Y(_0515_));
 sky130_fd_sc_hd__nor3_2 _1475_ (.A(_1093_),
    .B(_1100_),
    .C(_1163_),
    .Y(_0516_));
 sky130_fd_sc_hd__o21a_2 _1476_ (.A1(_1090_),
    .A2(_1102_),
    .B1(\tx_count[3] ),
    .X(_0517_));
 sky130_fd_sc_hd__o31a_2 _1477_ (.A1(_0514_),
    .A2(_0516_),
    .A3(_0517_),
    .B1(_0515_),
    .X(_0054_));
 sky130_fd_sc_hd__nor2_2 _1478_ (.A(_1073_),
    .B(_0515_),
    .Y(_0518_));
 sky130_fd_sc_hd__a211oi_2 _1479_ (.A1(_1073_),
    .A2(_0515_),
    .B1(_0516_),
    .C1(_0518_),
    .Y(_0055_));
 sky130_fd_sc_hd__xor2_2 _1480_ (.A(\rx_wr_ptr[0] ),
    .B(_1120_),
    .X(_0047_));
 sky130_fd_sc_hd__and3_2 _1481_ (.A(\rx_wr_ptr[0] ),
    .B(\rx_wr_ptr[1] ),
    .C(_1120_),
    .X(_0519_));
 sky130_fd_sc_hd__a21oi_2 _1482_ (.A1(\rx_wr_ptr[0] ),
    .A2(_1120_),
    .B1(\rx_wr_ptr[1] ),
    .Y(_0520_));
 sky130_fd_sc_hd__nor2_2 _1483_ (.A(_0519_),
    .B(_0520_),
    .Y(_0048_));
 sky130_fd_sc_hd__nand2_2 _1484_ (.A(\rx_wr_ptr[2] ),
    .B(_0519_),
    .Y(_0521_));
 sky130_fd_sc_hd__or2_2 _1485_ (.A(\rx_wr_ptr[2] ),
    .B(_0519_),
    .X(_0522_));
 sky130_fd_sc_hd__and2_2 _1486_ (.A(_0521_),
    .B(_0522_),
    .X(_0049_));
 sky130_fd_sc_hd__and2b_2 _1487_ (.A_N(\rx_wr_ptr[3] ),
    .B(\rx_wr_ptr[2] ),
    .X(_0523_));
 sky130_fd_sc_hd__and2_2 _1488_ (.A(\rx_wr_ptr[2] ),
    .B(\rx_wr_ptr[3] ),
    .X(_0524_));
 sky130_fd_sc_hd__a22o_2 _1489_ (.A1(\rx_wr_ptr[3] ),
    .A2(_0521_),
    .B1(_0523_),
    .B2(_0519_),
    .X(_0050_));
 sky130_fd_sc_hd__nor2_2 _1490_ (.A(baud_tick),
    .B(_1120_),
    .Y(_0525_));
 sky130_fd_sc_hd__a21oi_2 _1491_ (.A1(\tx_state[3] ),
    .A2(_1144_),
    .B1(_1120_),
    .Y(_0526_));
 sky130_fd_sc_hd__nor2_2 _1492_ (.A(_0525_),
    .B(_0526_),
    .Y(_0527_));
 sky130_fd_sc_hd__inv_2 _1493_ (.A(_0527_),
    .Y(_0528_));
 sky130_fd_sc_hd__xor2_2 _1494_ (.A(packet_count[0]),
    .B(_0527_),
    .X(_0026_));
 sky130_fd_sc_hd__mux2_1 _1495_ (.A0(packet_count[1]),
    .A1(_1140_),
    .S(_0527_),
    .X(_0033_));
 sky130_fd_sc_hd__mux2_1 _1496_ (.A0(packet_count[2]),
    .A1(_1149_),
    .S(_0527_),
    .X(_0034_));
 sky130_fd_sc_hd__mux2_1 _1497_ (.A0(packet_count[3]),
    .A1(_1138_),
    .S(_0527_),
    .X(_0035_));
 sky130_fd_sc_hd__mux2_1 _1498_ (.A0(packet_count[4]),
    .A1(_1135_),
    .S(_0527_),
    .X(_0036_));
 sky130_fd_sc_hd__nand2_2 _1499_ (.A(_1125_),
    .B(_0527_),
    .Y(_0529_));
 sky130_fd_sc_hd__o21ai_2 _1500_ (.A1(packet_count[5]),
    .A2(_0527_),
    .B1(_0529_),
    .Y(_0530_));
 sky130_fd_sc_hd__nor2_2 _1501_ (.A(_1132_),
    .B(_0530_),
    .Y(_0037_));
 sky130_fd_sc_hd__xnor2_2 _1502_ (.A(packet_count[6]),
    .B(_0529_),
    .Y(_0038_));
 sky130_fd_sc_hd__a21o_2 _1503_ (.A1(_1126_),
    .A2(_0525_),
    .B1(_0526_),
    .X(_0531_));
 sky130_fd_sc_hd__o22a_2 _1504_ (.A1(packet_count[7]),
    .A2(_0527_),
    .B1(_0531_),
    .B2(_1127_),
    .X(_0039_));
 sky130_fd_sc_hd__a211o_2 _1505_ (.A1(packet_count[7]),
    .A2(_1126_),
    .B1(_0526_),
    .C1(packet_count[8]),
    .X(_0532_));
 sky130_fd_sc_hd__and3_2 _1506_ (.A(packet_count[7]),
    .B(packet_count[8]),
    .C(_1126_),
    .X(_0533_));
 sky130_fd_sc_hd__nand2_2 _1507_ (.A(_0527_),
    .B(_0533_),
    .Y(_0534_));
 sky130_fd_sc_hd__o211a_2 _1508_ (.A1(packet_count[8]),
    .A2(_0527_),
    .B1(_0532_),
    .C1(_0534_),
    .X(_0040_));
 sky130_fd_sc_hd__xnor2_2 _1509_ (.A(packet_count[9]),
    .B(_0534_),
    .Y(_0041_));
 sky130_fd_sc_hd__a31oi_2 _1510_ (.A1(packet_count[9]),
    .A2(_0527_),
    .A3(_0533_),
    .B1(packet_count[10]),
    .Y(_0535_));
 sky130_fd_sc_hd__and4_2 _1511_ (.A(packet_count[9]),
    .B(packet_count[10]),
    .C(_0527_),
    .D(_0533_),
    .X(_0536_));
 sky130_fd_sc_hd__nor2_2 _1512_ (.A(_0535_),
    .B(_0536_),
    .Y(_0027_));
 sky130_fd_sc_hd__nand2_2 _1513_ (.A(packet_count[11]),
    .B(_0536_),
    .Y(_0537_));
 sky130_fd_sc_hd__xor2_2 _1514_ (.A(packet_count[11]),
    .B(_0536_),
    .X(_0028_));
 sky130_fd_sc_hd__and3_2 _1515_ (.A(packet_count[10]),
    .B(packet_count[11]),
    .C(packet_count[12]),
    .X(_0538_));
 sky130_fd_sc_hd__and4_2 _1516_ (.A(packet_count[9]),
    .B(_0527_),
    .C(_0533_),
    .D(_0538_),
    .X(_0539_));
 sky130_fd_sc_hd__xnor2_2 _1517_ (.A(packet_count[12]),
    .B(_0537_),
    .Y(_0029_));
 sky130_fd_sc_hd__xor2_2 _1518_ (.A(packet_count[13]),
    .B(_0539_),
    .X(_0030_));
 sky130_fd_sc_hd__a21oi_2 _1519_ (.A1(packet_count[13]),
    .A2(_0539_),
    .B1(packet_count[14]),
    .Y(_0540_));
 sky130_fd_sc_hd__and3_2 _1520_ (.A(packet_count[13]),
    .B(packet_count[14]),
    .C(_0539_),
    .X(_0541_));
 sky130_fd_sc_hd__nor2_2 _1521_ (.A(_0540_),
    .B(_0541_),
    .Y(_0031_));
 sky130_fd_sc_hd__and3_2 _1522_ (.A(packet_count[13]),
    .B(packet_count[14]),
    .C(_0538_),
    .X(_0542_));
 sky130_fd_sc_hd__nand3_2 _1523_ (.A(packet_count[9]),
    .B(_0533_),
    .C(_0542_),
    .Y(_0543_));
 sky130_fd_sc_hd__o21ai_2 _1524_ (.A1(_0528_),
    .A2(_0543_),
    .B1(packet_count[15]),
    .Y(_0544_));
 sky130_fd_sc_hd__o31ai_2 _1525_ (.A1(packet_count[15]),
    .A2(_0528_),
    .A3(_0543_),
    .B1(_0544_),
    .Y(_0032_));
 sky130_fd_sc_hd__or2_2 _1526_ (.A(\irq_status_reg[1] ),
    .B(\irq_status_reg[0] ),
    .X(_0545_));
 sky130_fd_sc_hd__or4_2 _1527_ (.A(\irq_status_reg[5] ),
    .B(\irq_status_reg[4] ),
    .C(\irq_status_reg[7] ),
    .D(_0545_),
    .X(_0546_));
 sky130_fd_sc_hd__o31a_2 _1528_ (.A1(\irq_status_reg[3] ),
    .A2(\irq_status_reg[2] ),
    .A3(_0546_),
    .B1(irq_enable),
    .X(_0018_));
 sky130_fd_sc_hd__a21oi_2 _1529_ (.A1(_1071_),
    .A2(_1077_),
    .B1(_1087_),
    .Y(_0063_));
 sky130_fd_sc_hd__or2_2 _1530_ (.A(error_r),
    .B(\irq_status_reg[7] ),
    .X(_0064_));
 sky130_fd_sc_hd__or2_2 _1531_ (.A(wr_addr[3]),
    .B(wr_addr[1]),
    .X(_0547_));
 sky130_fd_sc_hd__or4_2 _1532_ (.A(wr_addr[0]),
    .B(_1108_),
    .C(_1165_),
    .D(_0547_),
    .X(_0548_));
 sky130_fd_sc_hd__mux2_1 _1533_ (.A0(wr_data[0]),
    .A1(\baud_div_reg[0] ),
    .S(_0548_),
    .X(_0065_));
 sky130_fd_sc_hd__mux2_1 _1534_ (.A0(wr_data[1]),
    .A1(\baud_div_reg[1] ),
    .S(_0548_),
    .X(_0066_));
 sky130_fd_sc_hd__mux2_1 _1535_ (.A0(wr_data[2]),
    .A1(\baud_div_reg[2] ),
    .S(_0548_),
    .X(_0067_));
 sky130_fd_sc_hd__mux2_1 _1536_ (.A0(wr_data[3]),
    .A1(\baud_div_reg[3] ),
    .S(_0548_),
    .X(_0068_));
 sky130_fd_sc_hd__mux2_1 _1537_ (.A0(wr_data[4]),
    .A1(\baud_div_reg[4] ),
    .S(_0548_),
    .X(_0069_));
 sky130_fd_sc_hd__mux2_1 _1538_ (.A0(wr_data[5]),
    .A1(\baud_div_reg[5] ),
    .S(_0548_),
    .X(_0070_));
 sky130_fd_sc_hd__mux2_1 _1539_ (.A0(wr_data[6]),
    .A1(\baud_div_reg[6] ),
    .S(_0548_),
    .X(_0071_));
 sky130_fd_sc_hd__mux2_1 _1540_ (.A0(wr_data[7]),
    .A1(\baud_div_reg[7] ),
    .S(_0548_),
    .X(_0072_));
 sky130_fd_sc_hd__and3_2 _1541_ (.A(\rx_wr_ptr[0] ),
    .B(\rx_wr_ptr[1] ),
    .C(reset_n),
    .X(_0549_));
 sky130_fd_sc_hd__nand3_2 _1542_ (.A(\rx_wr_ptr[0] ),
    .B(\rx_wr_ptr[1] ),
    .C(_0524_),
    .Y(_0550_));
 sky130_fd_sc_hd__nor2_2 _1543_ (.A(_1082_),
    .B(_0550_),
    .Y(_0551_));
 sky130_fd_sc_hd__inv_2 _1544_ (.A(_0551_),
    .Y(_0552_));
 sky130_fd_sc_hd__and2b_2 _1545_ (.A_N(_1113_),
    .B(_1118_),
    .X(_0553_));
 sky130_fd_sc_hd__or3b_2 _1546_ (.A(_1086_),
    .B(_1113_),
    .C_N(_1117_),
    .X(_0554_));
 sky130_fd_sc_hd__nand2_2 _1547_ (.A(loopback_valid),
    .B(_1118_),
    .Y(_0555_));
 sky130_fd_sc_hd__nand2_2 _1548_ (.A(reset_n),
    .B(_0555_),
    .Y(_0556_));
 sky130_fd_sc_hd__a21oi_2 _1549_ (.A1(\rx_shift[0] ),
    .A2(_0553_),
    .B1(_0556_),
    .Y(_0557_));
 sky130_fd_sc_hd__nor2_2 _1550_ (.A(_0552_),
    .B(_0557_),
    .Y(_0558_));
 sky130_fd_sc_hd__mux2_1 _1551_ (.A0(\rx_shift[0] ),
    .A1(\loopback_byte[0] ),
    .S(_0554_),
    .X(_0559_));
 sky130_fd_sc_hd__or2_2 _1552_ (.A(_1121_),
    .B(_0559_),
    .X(_0560_));
 sky130_fd_sc_hd__nand2_2 _1553_ (.A(_1120_),
    .B(_0551_),
    .Y(_0561_));
 sky130_fd_sc_hd__o22a_2 _1554_ (.A1(\rx_fifo_mem[15][0] ),
    .A2(_0558_),
    .B1(_0560_),
    .B2(_0552_),
    .X(_0073_));
 sky130_fd_sc_hd__nor2_2 _1555_ (.A(_0550_),
    .B(_0555_),
    .Y(_0562_));
 sky130_fd_sc_hd__nor2_2 _1556_ (.A(_0550_),
    .B(_0554_),
    .Y(_0563_));
 sky130_fd_sc_hd__a32o_2 _1557_ (.A1(\loopback_byte[1] ),
    .A2(_0554_),
    .A3(_0562_),
    .B1(_0563_),
    .B2(\rx_shift[1] ),
    .X(_0564_));
 sky130_fd_sc_hd__a22o_2 _1558_ (.A1(\rx_fifo_mem[15][1] ),
    .A2(_0561_),
    .B1(_0564_),
    .B2(reset_n),
    .X(_0074_));
 sky130_fd_sc_hd__a211o_2 _1559_ (.A1(\loopback_byte[2] ),
    .A2(_0554_),
    .B1(_0550_),
    .C1(_1121_),
    .X(_0565_));
 sky130_fd_sc_hd__or2_2 _1560_ (.A(\rx_fifo_mem[15][2] ),
    .B(_0562_),
    .X(_0566_));
 sky130_fd_sc_hd__a32o_2 _1561_ (.A1(\rx_shift[2] ),
    .A2(_0551_),
    .A3(_0553_),
    .B1(_1082_),
    .B2(\rx_fifo_mem[15][2] ),
    .X(_0567_));
 sky130_fd_sc_hd__a31o_2 _1562_ (.A1(reset_n),
    .A2(_0565_),
    .A3(_0566_),
    .B1(_0567_),
    .X(_0075_));
 sky130_fd_sc_hd__mux2_1 _1563_ (.A0(\rx_fifo_mem[15][3] ),
    .A1(\loopback_byte[3] ),
    .S(_0562_),
    .X(_0568_));
 sky130_fd_sc_hd__and3b_2 _1564_ (.A_N(_0563_),
    .B(_0568_),
    .C(reset_n),
    .X(_0569_));
 sky130_fd_sc_hd__and2_2 _1565_ (.A(\rx_shift[3] ),
    .B(_0553_),
    .X(_0570_));
 sky130_fd_sc_hd__a221o_2 _1566_ (.A1(\rx_fifo_mem[15][3] ),
    .A2(_1082_),
    .B1(_0551_),
    .B2(_0570_),
    .C1(_0569_),
    .X(_0076_));
 sky130_fd_sc_hd__or2_2 _1567_ (.A(\rx_fifo_mem[15][4] ),
    .B(_0562_),
    .X(_0571_));
 sky130_fd_sc_hd__a211o_2 _1568_ (.A1(\loopback_byte[4] ),
    .A2(_0554_),
    .B1(_0550_),
    .C1(_1121_),
    .X(_0572_));
 sky130_fd_sc_hd__a221o_2 _1569_ (.A1(\rx_shift[4] ),
    .A2(_0563_),
    .B1(_0571_),
    .B2(_0572_),
    .C1(_1082_),
    .X(_0573_));
 sky130_fd_sc_hd__o21a_2 _1570_ (.A1(\rx_fifo_mem[15][4] ),
    .A2(reset_n),
    .B1(_0573_),
    .X(_0077_));
 sky130_fd_sc_hd__or2_2 _1571_ (.A(\rx_fifo_mem[15][5] ),
    .B(_0562_),
    .X(_0574_));
 sky130_fd_sc_hd__a211o_2 _1572_ (.A1(\loopback_byte[5] ),
    .A2(_0554_),
    .B1(_0550_),
    .C1(_1121_),
    .X(_0575_));
 sky130_fd_sc_hd__a221o_2 _1573_ (.A1(\rx_shift[5] ),
    .A2(_0563_),
    .B1(_0574_),
    .B2(_0575_),
    .C1(_1082_),
    .X(_0576_));
 sky130_fd_sc_hd__o21a_2 _1574_ (.A1(\rx_fifo_mem[15][5] ),
    .A2(reset_n),
    .B1(_0576_),
    .X(_0078_));
 sky130_fd_sc_hd__or2_2 _1575_ (.A(\rx_fifo_mem[15][6] ),
    .B(_0562_),
    .X(_0577_));
 sky130_fd_sc_hd__a211o_2 _1576_ (.A1(\loopback_byte[6] ),
    .A2(_0554_),
    .B1(_0550_),
    .C1(_1121_),
    .X(_0578_));
 sky130_fd_sc_hd__a221o_2 _1577_ (.A1(\rx_shift[6] ),
    .A2(_0563_),
    .B1(_0577_),
    .B2(_0578_),
    .C1(_1082_),
    .X(_0579_));
 sky130_fd_sc_hd__o21a_2 _1578_ (.A1(\rx_fifo_mem[15][6] ),
    .A2(reset_n),
    .B1(_0579_),
    .X(_0079_));
 sky130_fd_sc_hd__or2_2 _1579_ (.A(\rx_fifo_mem[15][7] ),
    .B(_0562_),
    .X(_0580_));
 sky130_fd_sc_hd__a211o_2 _1580_ (.A1(\loopback_byte[7] ),
    .A2(_0554_),
    .B1(_0550_),
    .C1(_1121_),
    .X(_0581_));
 sky130_fd_sc_hd__a221o_2 _1581_ (.A1(\rx_shift[7] ),
    .A2(_0563_),
    .B1(_0580_),
    .B2(_0581_),
    .C1(_1082_),
    .X(_0582_));
 sky130_fd_sc_hd__o21a_2 _1582_ (.A1(\rx_fifo_mem[15][7] ),
    .A2(reset_n),
    .B1(_0582_),
    .X(_0080_));
 sky130_fd_sc_hd__or3b_2 _1583_ (.A(wr_addr[4]),
    .B(wr_addr[2]),
    .C_N(wr_en),
    .X(_0583_));
 sky130_fd_sc_hd__or4_2 _1584_ (.A(wr_addr[0]),
    .B(_1108_),
    .C(_0547_),
    .D(_0583_),
    .X(_0584_));
 sky130_fd_sc_hd__mux2_1 _1585_ (.A0(wr_data[0]),
    .A1(enable),
    .S(_0584_),
    .X(_0081_));
 sky130_fd_sc_hd__mux2_1 _1586_ (.A0(wr_data[1]),
    .A1(rx_enable),
    .S(_0584_),
    .X(_0082_));
 sky130_fd_sc_hd__mux2_1 _1587_ (.A0(wr_data[2]),
    .A1(tx_enable),
    .S(_0584_),
    .X(_0083_));
 sky130_fd_sc_hd__mux2_1 _1588_ (.A0(wr_data[3]),
    .A1(loopback),
    .S(_0584_),
    .X(_0084_));
 sky130_fd_sc_hd__mux2_1 _1589_ (.A0(wr_data[4]),
    .A1(irq_enable),
    .S(_0584_),
    .X(_0085_));
 sky130_fd_sc_hd__nand2b_2 _1590_ (.A_N(\rx_rd_ptr[0] ),
    .B(\rx_rd_ptr[1] ),
    .Y(_0585_));
 sky130_fd_sc_hd__nand2b_2 _1591_ (.A_N(\rx_rd_ptr[3] ),
    .B(\rx_rd_ptr[2] ),
    .Y(_0586_));
 sky130_fd_sc_hd__nor2_2 _1592_ (.A(_0585_),
    .B(_0586_),
    .Y(_0587_));
 sky130_fd_sc_hd__nand2b_2 _1593_ (.A_N(\rx_rd_ptr[1] ),
    .B(\rx_rd_ptr[0] ),
    .Y(_0588_));
 sky130_fd_sc_hd__nor2_2 _1594_ (.A(_0586_),
    .B(_0588_),
    .Y(_0589_));
 sky130_fd_sc_hd__nand2_2 _1595_ (.A(\rx_rd_ptr[2] ),
    .B(\rx_rd_ptr[3] ),
    .Y(_0590_));
 sky130_fd_sc_hd__nor2_2 _1596_ (.A(_0585_),
    .B(_0590_),
    .Y(_0591_));
 sky130_fd_sc_hd__nand2_2 _1597_ (.A(\rx_rd_ptr[1] ),
    .B(\rx_rd_ptr[0] ),
    .Y(_0592_));
 sky130_fd_sc_hd__nor2_2 _1598_ (.A(_0590_),
    .B(_0592_),
    .Y(_0593_));
 sky130_fd_sc_hd__or2_2 _1599_ (.A(\rx_rd_ptr[2] ),
    .B(\rx_rd_ptr[3] ),
    .X(_0594_));
 sky130_fd_sc_hd__or2_2 _1600_ (.A(\rx_rd_ptr[1] ),
    .B(\rx_rd_ptr[0] ),
    .X(_0595_));
 sky130_fd_sc_hd__nor2_2 _1601_ (.A(_0594_),
    .B(_0595_),
    .Y(_0596_));
 sky130_fd_sc_hd__or2_2 _1602_ (.A(_0594_),
    .B(_0595_),
    .X(_0597_));
 sky130_fd_sc_hd__nor2_2 _1603_ (.A(_0590_),
    .B(_0595_),
    .Y(_0598_));
 sky130_fd_sc_hd__nor2_2 _1604_ (.A(_0586_),
    .B(_0592_),
    .Y(_0599_));
 sky130_fd_sc_hd__nor2_2 _1605_ (.A(_0592_),
    .B(_0594_),
    .Y(_0600_));
 sky130_fd_sc_hd__nand2b_2 _1606_ (.A_N(\rx_rd_ptr[2] ),
    .B(\rx_rd_ptr[3] ),
    .Y(_0601_));
 sky130_fd_sc_hd__nor2_2 _1607_ (.A(_0588_),
    .B(_0601_),
    .Y(_0602_));
 sky130_fd_sc_hd__nor2_2 _1608_ (.A(_0588_),
    .B(_0594_),
    .Y(_0603_));
 sky130_fd_sc_hd__nor2_2 _1609_ (.A(_0588_),
    .B(_0590_),
    .Y(_0604_));
 sky130_fd_sc_hd__nor2_2 _1610_ (.A(_0586_),
    .B(_0595_),
    .Y(_0605_));
 sky130_fd_sc_hd__nor2_2 _1611_ (.A(_0585_),
    .B(_0594_),
    .Y(_0606_));
 sky130_fd_sc_hd__nor2_2 _1612_ (.A(_0585_),
    .B(_0601_),
    .Y(_0607_));
 sky130_fd_sc_hd__nor2_2 _1613_ (.A(_0595_),
    .B(_0601_),
    .Y(_0608_));
 sky130_fd_sc_hd__nor2_2 _1614_ (.A(_0592_),
    .B(_0601_),
    .Y(_0609_));
 sky130_fd_sc_hd__a22o_2 _1615_ (.A1(\rx_fifo_mem[6][0] ),
    .A2(_0587_),
    .B1(_0606_),
    .B2(\rx_fifo_mem[2][0] ),
    .X(_0610_));
 sky130_fd_sc_hd__a221o_2 _1616_ (.A1(\rx_fifo_mem[14][0] ),
    .A2(_0591_),
    .B1(_0599_),
    .B2(\rx_fifo_mem[7][0] ),
    .C1(_0610_),
    .X(_0611_));
 sky130_fd_sc_hd__a22o_2 _1617_ (.A1(\rx_fifo_mem[9][0] ),
    .A2(_0602_),
    .B1(_0608_),
    .B2(\rx_fifo_mem[8][0] ),
    .X(_0612_));
 sky130_fd_sc_hd__a221o_2 _1618_ (.A1(\rx_fifo_mem[5][0] ),
    .A2(_0589_),
    .B1(_0593_),
    .B2(\rx_fifo_mem[15][0] ),
    .C1(_0612_),
    .X(_0613_));
 sky130_fd_sc_hd__a22o_2 _1619_ (.A1(\rx_fifo_mem[10][0] ),
    .A2(_0607_),
    .B1(_0609_),
    .B2(\rx_fifo_mem[11][0] ),
    .X(_0614_));
 sky130_fd_sc_hd__a221o_2 _1620_ (.A1(\rx_fifo_mem[3][0] ),
    .A2(_0600_),
    .B1(_0604_),
    .B2(\rx_fifo_mem[13][0] ),
    .C1(_0614_),
    .X(_0615_));
 sky130_fd_sc_hd__a22o_2 _1621_ (.A1(\rx_fifo_mem[12][0] ),
    .A2(_0598_),
    .B1(_0605_),
    .B2(\rx_fifo_mem[4][0] ),
    .X(_0616_));
 sky130_fd_sc_hd__a2111o_2 _1622_ (.A1(\rx_fifo_mem[1][0] ),
    .A2(_0603_),
    .B1(_0615_),
    .C1(_0616_),
    .D1(_0596_),
    .X(_0617_));
 sky130_fd_sc_hd__or3_2 _1623_ (.A(_0611_),
    .B(_0613_),
    .C(_0617_),
    .X(_0618_));
 sky130_fd_sc_hd__o211a_2 _1624_ (.A1(\rx_fifo_mem[0][0] ),
    .A2(_0597_),
    .B1(_0618_),
    .C1(_0486_),
    .X(_0619_));
 sky130_fd_sc_hd__or3_2 _1625_ (.A(rd_addr[4]),
    .B(rd_addr[7]),
    .C(rd_addr[6]),
    .X(_0620_));
 sky130_fd_sc_hd__or4_2 _1626_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .C(rd_addr[5]),
    .D(_0620_),
    .X(_0621_));
 sky130_fd_sc_hd__nor3_2 _1627_ (.A(rd_addr[2]),
    .B(rd_addr[3]),
    .C(_0621_),
    .Y(_0622_));
 sky130_fd_sc_hd__nor3b_2 _1628_ (.A(_0621_),
    .B(rd_addr[2]),
    .C_N(rd_addr[3]),
    .Y(_0623_));
 sky130_fd_sc_hd__and3b_2 _1629_ (.A_N(rd_addr[2]),
    .B(rd_addr[3]),
    .C(_0481_),
    .X(_0624_));
 sky130_fd_sc_hd__and2b_2 _1630_ (.A_N(rd_addr[3]),
    .B(rd_addr[2]),
    .X(_0625_));
 sky130_fd_sc_hd__or4b_2 _1631_ (.A(rd_addr[2]),
    .B(_0620_),
    .C(rd_addr[3]),
    .D_N(rd_addr[5]),
    .X(_0626_));
 sky130_fd_sc_hd__nor3_2 _1632_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .C(_0626_),
    .Y(_0627_));
 sky130_fd_sc_hd__nor3b_2 _1633_ (.A(_0626_),
    .B(rd_addr[1]),
    .C_N(rd_addr[0]),
    .Y(_0628_));
 sky130_fd_sc_hd__and2_2 _1634_ (.A(_0481_),
    .B(_0625_),
    .X(_0629_));
 sky130_fd_sc_hd__nand2_2 _1635_ (.A(_0481_),
    .B(_0625_),
    .Y(_0630_));
 sky130_fd_sc_hd__nor2_2 _1636_ (.A(_1091_),
    .B(_0630_),
    .Y(_0631_));
 sky130_fd_sc_hd__and2b_2 _1637_ (.A_N(_0621_),
    .B(_0625_),
    .X(_0632_));
 sky130_fd_sc_hd__a221o_2 _1638_ (.A1(\packet_len_reg[0] ),
    .A2(_0623_),
    .B1(_0628_),
    .B2(packet_count[8]),
    .C1(_0631_),
    .X(_0633_));
 sky130_fd_sc_hd__a22o_2 _1639_ (.A1(enable),
    .A2(_0622_),
    .B1(_0624_),
    .B2(\irq_status_reg[0] ),
    .X(_0634_));
 sky130_fd_sc_hd__a211o_2 _1640_ (.A1(packet_count[0]),
    .A2(_0627_),
    .B1(_0634_),
    .C1(_1079_),
    .X(_0635_));
 sky130_fd_sc_hd__or4bb_2 _1641_ (.A(rd_addr[1]),
    .B(rd_addr[5]),
    .C_N(_0625_),
    .D_N(rd_addr[0]),
    .X(_0636_));
 sky130_fd_sc_hd__nor2_2 _1642_ (.A(_0620_),
    .B(_0636_),
    .Y(_0637_));
 sky130_fd_sc_hd__a221o_2 _1643_ (.A1(\baud_div_reg[0] ),
    .A2(_0632_),
    .B1(_0637_),
    .B2(\baud_div_reg[8] ),
    .C1(_0635_),
    .X(_0638_));
 sky130_fd_sc_hd__o32a_2 _1644_ (.A1(_0619_),
    .A2(_0633_),
    .A3(_0638_),
    .B1(rd_data[0]),
    .B2(rd_en),
    .X(_0086_));
 sky130_fd_sc_hd__a22o_2 _1645_ (.A1(\rx_fifo_mem[12][1] ),
    .A2(_0598_),
    .B1(_0606_),
    .B2(\rx_fifo_mem[2][1] ),
    .X(_0639_));
 sky130_fd_sc_hd__a22o_2 _1646_ (.A1(\rx_fifo_mem[4][1] ),
    .A2(_0605_),
    .B1(_0607_),
    .B2(\rx_fifo_mem[10][1] ),
    .X(_0640_));
 sky130_fd_sc_hd__a22o_2 _1647_ (.A1(\rx_fifo_mem[6][1] ),
    .A2(_0587_),
    .B1(_0599_),
    .B2(\rx_fifo_mem[7][1] ),
    .X(_0641_));
 sky130_fd_sc_hd__a221o_2 _1648_ (.A1(\rx_fifo_mem[15][1] ),
    .A2(_0593_),
    .B1(_0600_),
    .B2(\rx_fifo_mem[3][1] ),
    .C1(_0641_),
    .X(_0642_));
 sky130_fd_sc_hd__a221o_2 _1649_ (.A1(\rx_fifo_mem[5][1] ),
    .A2(_0589_),
    .B1(_0609_),
    .B2(\rx_fifo_mem[11][1] ),
    .C1(_0639_),
    .X(_0643_));
 sky130_fd_sc_hd__a221o_2 _1650_ (.A1(\rx_fifo_mem[9][1] ),
    .A2(_0602_),
    .B1(_0604_),
    .B2(\rx_fifo_mem[13][1] ),
    .C1(_0640_),
    .X(_0644_));
 sky130_fd_sc_hd__a22o_2 _1651_ (.A1(\rx_fifo_mem[1][1] ),
    .A2(_0603_),
    .B1(_0608_),
    .B2(\rx_fifo_mem[8][1] ),
    .X(_0645_));
 sky130_fd_sc_hd__a2111o_2 _1652_ (.A1(\rx_fifo_mem[14][1] ),
    .A2(_0591_),
    .B1(_0596_),
    .C1(_0644_),
    .D1(_0645_),
    .X(_0646_));
 sky130_fd_sc_hd__or3_2 _1653_ (.A(_0642_),
    .B(_0643_),
    .C(_0646_),
    .X(_0647_));
 sky130_fd_sc_hd__o211a_2 _1654_ (.A1(\rx_fifo_mem[0][1] ),
    .A2(_0597_),
    .B1(_0647_),
    .C1(_0486_),
    .X(_0648_));
 sky130_fd_sc_hd__nor2_2 _1655_ (.A(_1163_),
    .B(_0630_),
    .Y(_0649_));
 sky130_fd_sc_hd__a22o_2 _1656_ (.A1(\baud_div_reg[1] ),
    .A2(_0632_),
    .B1(_0637_),
    .B2(\baud_div_reg[9] ),
    .X(_0650_));
 sky130_fd_sc_hd__a221o_2 _1657_ (.A1(rx_enable),
    .A2(_0622_),
    .B1(_0624_),
    .B2(\irq_status_reg[1] ),
    .C1(_0649_),
    .X(_0651_));
 sky130_fd_sc_hd__a22o_2 _1658_ (.A1(\packet_len_reg[1] ),
    .A2(_0623_),
    .B1(_0627_),
    .B2(packet_count[1]),
    .X(_0652_));
 sky130_fd_sc_hd__a2111o_2 _1659_ (.A1(packet_count[9]),
    .A2(_0628_),
    .B1(_0650_),
    .C1(_0652_),
    .D1(_1079_),
    .X(_0653_));
 sky130_fd_sc_hd__o32a_2 _1660_ (.A1(_0648_),
    .A2(_0651_),
    .A3(_0653_),
    .B1(rd_data[1]),
    .B2(rd_en),
    .X(_0087_));
 sky130_fd_sc_hd__a22o_2 _1661_ (.A1(\rx_fifo_mem[6][2] ),
    .A2(_0587_),
    .B1(_0608_),
    .B2(\rx_fifo_mem[8][2] ),
    .X(_0654_));
 sky130_fd_sc_hd__a221o_2 _1662_ (.A1(\rx_fifo_mem[12][2] ),
    .A2(_0598_),
    .B1(_0609_),
    .B2(\rx_fifo_mem[11][2] ),
    .C1(_0654_),
    .X(_0655_));
 sky130_fd_sc_hd__a22o_2 _1663_ (.A1(\rx_fifo_mem[3][2] ),
    .A2(_0600_),
    .B1(_0607_),
    .B2(\rx_fifo_mem[10][2] ),
    .X(_0656_));
 sky130_fd_sc_hd__a2111o_2 _1664_ (.A1(\rx_fifo_mem[4][2] ),
    .A2(_0605_),
    .B1(_0655_),
    .C1(_0656_),
    .D1(_0596_),
    .X(_0657_));
 sky130_fd_sc_hd__a22o_2 _1665_ (.A1(\rx_fifo_mem[9][2] ),
    .A2(_0602_),
    .B1(_0606_),
    .B2(\rx_fifo_mem[2][2] ),
    .X(_0658_));
 sky130_fd_sc_hd__a221o_2 _1666_ (.A1(\rx_fifo_mem[14][2] ),
    .A2(_0591_),
    .B1(_0593_),
    .B2(\rx_fifo_mem[15][2] ),
    .C1(_0658_),
    .X(_0659_));
 sky130_fd_sc_hd__a22o_2 _1667_ (.A1(\rx_fifo_mem[7][2] ),
    .A2(_0599_),
    .B1(_0603_),
    .B2(\rx_fifo_mem[1][2] ),
    .X(_0660_));
 sky130_fd_sc_hd__a221o_2 _1668_ (.A1(\rx_fifo_mem[5][2] ),
    .A2(_0589_),
    .B1(_0604_),
    .B2(\rx_fifo_mem[13][2] ),
    .C1(_0660_),
    .X(_0661_));
 sky130_fd_sc_hd__or3_2 _1669_ (.A(_0657_),
    .B(_0659_),
    .C(_0661_),
    .X(_0662_));
 sky130_fd_sc_hd__o211a_2 _1670_ (.A1(\rx_fifo_mem[0][2] ),
    .A2(_0597_),
    .B1(_0662_),
    .C1(_0486_),
    .X(_0663_));
 sky130_fd_sc_hd__a22o_2 _1671_ (.A1(packet_count[2]),
    .A2(_0627_),
    .B1(_0628_),
    .B2(packet_count[10]),
    .X(_0664_));
 sky130_fd_sc_hd__a21o_2 _1672_ (.A1(tx_enable),
    .A2(_0622_),
    .B1(_0664_),
    .X(_0665_));
 sky130_fd_sc_hd__a22o_2 _1673_ (.A1(\irq_status_reg[2] ),
    .A2(_0624_),
    .B1(_0629_),
    .B2(_0484_),
    .X(_0666_));
 sky130_fd_sc_hd__a211o_2 _1674_ (.A1(\packet_len_reg[2] ),
    .A2(_0623_),
    .B1(_0666_),
    .C1(_1079_),
    .X(_0667_));
 sky130_fd_sc_hd__a221o_2 _1675_ (.A1(\baud_div_reg[2] ),
    .A2(_0632_),
    .B1(_0637_),
    .B2(\baud_div_reg[10] ),
    .C1(_0667_),
    .X(_0668_));
 sky130_fd_sc_hd__o32a_2 _1676_ (.A1(_0663_),
    .A2(_0665_),
    .A3(_0668_),
    .B1(rd_data[2]),
    .B2(rd_en),
    .X(_0088_));
 sky130_fd_sc_hd__a22o_2 _1677_ (.A1(\rx_fifo_mem[14][3] ),
    .A2(_0591_),
    .B1(_0603_),
    .B2(\rx_fifo_mem[1][3] ),
    .X(_0669_));
 sky130_fd_sc_hd__a22o_2 _1678_ (.A1(\rx_fifo_mem[15][3] ),
    .A2(_0593_),
    .B1(_0607_),
    .B2(\rx_fifo_mem[10][3] ),
    .X(_0670_));
 sky130_fd_sc_hd__a22o_2 _1679_ (.A1(\rx_fifo_mem[4][3] ),
    .A2(_0605_),
    .B1(_0606_),
    .B2(\rx_fifo_mem[2][3] ),
    .X(_0671_));
 sky130_fd_sc_hd__a22o_2 _1680_ (.A1(\rx_fifo_mem[5][3] ),
    .A2(_0589_),
    .B1(_0604_),
    .B2(\rx_fifo_mem[13][3] ),
    .X(_0672_));
 sky130_fd_sc_hd__a221o_2 _1681_ (.A1(\rx_fifo_mem[7][3] ),
    .A2(_0599_),
    .B1(_0609_),
    .B2(\rx_fifo_mem[11][3] ),
    .C1(_0672_),
    .X(_0673_));
 sky130_fd_sc_hd__a221o_2 _1682_ (.A1(\rx_fifo_mem[3][3] ),
    .A2(_0600_),
    .B1(_0608_),
    .B2(\rx_fifo_mem[8][3] ),
    .C1(_0670_),
    .X(_0674_));
 sky130_fd_sc_hd__a221o_2 _1683_ (.A1(\rx_fifo_mem[6][3] ),
    .A2(_0587_),
    .B1(_0602_),
    .B2(\rx_fifo_mem[9][3] ),
    .C1(_0671_),
    .X(_0675_));
 sky130_fd_sc_hd__a2111o_2 _1684_ (.A1(\rx_fifo_mem[12][3] ),
    .A2(_0598_),
    .B1(_0669_),
    .C1(_0675_),
    .D1(_0596_),
    .X(_0676_));
 sky130_fd_sc_hd__or3_2 _1685_ (.A(_0673_),
    .B(_0674_),
    .C(_0676_),
    .X(_0677_));
 sky130_fd_sc_hd__o211a_2 _1686_ (.A1(\rx_fifo_mem[0][3] ),
    .A2(_0597_),
    .B1(_0677_),
    .C1(_0486_),
    .X(_0678_));
 sky130_fd_sc_hd__a22o_2 _1687_ (.A1(\irq_status_reg[3] ),
    .A2(_0624_),
    .B1(_0628_),
    .B2(packet_count[11]),
    .X(_0679_));
 sky130_fd_sc_hd__nor2_2 _1688_ (.A(_1117_),
    .B(_0630_),
    .Y(_0680_));
 sky130_fd_sc_hd__a221o_2 _1689_ (.A1(loopback),
    .A2(_0622_),
    .B1(_0623_),
    .B2(\packet_len_reg[3] ),
    .C1(_0680_),
    .X(_0681_));
 sky130_fd_sc_hd__a211o_2 _1690_ (.A1(packet_count[3]),
    .A2(_0627_),
    .B1(_0679_),
    .C1(_1079_),
    .X(_0682_));
 sky130_fd_sc_hd__a221o_2 _1691_ (.A1(\baud_div_reg[3] ),
    .A2(_0632_),
    .B1(_0637_),
    .B2(\baud_div_reg[11] ),
    .C1(_0682_),
    .X(_0683_));
 sky130_fd_sc_hd__o32a_2 _1692_ (.A1(_0678_),
    .A2(_0681_),
    .A3(_0683_),
    .B1(rd_data[3]),
    .B2(rd_en),
    .X(_0089_));
 sky130_fd_sc_hd__or2_2 _1693_ (.A(rd_en),
    .B(rd_data[4]),
    .X(_0684_));
 sky130_fd_sc_hd__a22o_2 _1694_ (.A1(\rx_fifo_mem[5][4] ),
    .A2(_0589_),
    .B1(_0608_),
    .B2(\rx_fifo_mem[8][4] ),
    .X(_0685_));
 sky130_fd_sc_hd__a22o_2 _1695_ (.A1(\rx_fifo_mem[4][4] ),
    .A2(_0605_),
    .B1(_0607_),
    .B2(\rx_fifo_mem[10][4] ),
    .X(_0686_));
 sky130_fd_sc_hd__a221o_2 _1696_ (.A1(\rx_fifo_mem[12][4] ),
    .A2(_0598_),
    .B1(_0606_),
    .B2(\rx_fifo_mem[2][4] ),
    .C1(_0686_),
    .X(_0687_));
 sky130_fd_sc_hd__a22o_2 _1697_ (.A1(\rx_fifo_mem[1][4] ),
    .A2(_0603_),
    .B1(_0604_),
    .B2(\rx_fifo_mem[13][4] ),
    .X(_0688_));
 sky130_fd_sc_hd__a221o_2 _1698_ (.A1(\rx_fifo_mem[14][4] ),
    .A2(_0591_),
    .B1(_0593_),
    .B2(\rx_fifo_mem[15][4] ),
    .C1(_0688_),
    .X(_0689_));
 sky130_fd_sc_hd__a221o_2 _1699_ (.A1(\rx_fifo_mem[7][4] ),
    .A2(_0599_),
    .B1(_0609_),
    .B2(\rx_fifo_mem[11][4] ),
    .C1(_0685_),
    .X(_0690_));
 sky130_fd_sc_hd__a22o_2 _1700_ (.A1(\rx_fifo_mem[6][4] ),
    .A2(_0587_),
    .B1(_0600_),
    .B2(\rx_fifo_mem[3][4] ),
    .X(_0691_));
 sky130_fd_sc_hd__a2111o_2 _1701_ (.A1(\rx_fifo_mem[9][4] ),
    .A2(_0602_),
    .B1(_0690_),
    .C1(_0691_),
    .D1(_0596_),
    .X(_0692_));
 sky130_fd_sc_hd__or3_2 _1702_ (.A(_0687_),
    .B(_0689_),
    .C(_0692_),
    .X(_0693_));
 sky130_fd_sc_hd__o211a_2 _1703_ (.A1(\rx_fifo_mem[0][4] ),
    .A2(_0597_),
    .B1(_0693_),
    .C1(_0486_),
    .X(_0694_));
 sky130_fd_sc_hd__a22o_2 _1704_ (.A1(\packet_len_reg[4] ),
    .A2(_0623_),
    .B1(_0624_),
    .B2(\irq_status_reg[4] ),
    .X(_0695_));
 sky130_fd_sc_hd__a221o_2 _1705_ (.A1(irq_enable),
    .A2(_0622_),
    .B1(_0637_),
    .B2(\baud_div_reg[12] ),
    .C1(_0695_),
    .X(_0696_));
 sky130_fd_sc_hd__a221o_2 _1706_ (.A1(packet_count[12]),
    .A2(_0628_),
    .B1(_0629_),
    .B2(tx_busy_r),
    .C1(_1079_),
    .X(_0697_));
 sky130_fd_sc_hd__a221o_2 _1707_ (.A1(packet_count[4]),
    .A2(_0627_),
    .B1(_0632_),
    .B2(\baud_div_reg[4] ),
    .C1(_0697_),
    .X(_0698_));
 sky130_fd_sc_hd__o31a_2 _1708_ (.A1(_0694_),
    .A2(_0696_),
    .A3(_0698_),
    .B1(_0684_),
    .X(_0090_));
 sky130_fd_sc_hd__a22o_2 _1709_ (.A1(\rx_fifo_mem[10][5] ),
    .A2(_0607_),
    .B1(_0608_),
    .B2(\rx_fifo_mem[8][5] ),
    .X(_0699_));
 sky130_fd_sc_hd__a221o_2 _1710_ (.A1(\rx_fifo_mem[14][5] ),
    .A2(_0591_),
    .B1(_0593_),
    .B2(\rx_fifo_mem[15][5] ),
    .C1(_0699_),
    .X(_0700_));
 sky130_fd_sc_hd__a22o_2 _1711_ (.A1(\rx_fifo_mem[6][5] ),
    .A2(_0587_),
    .B1(_0598_),
    .B2(\rx_fifo_mem[12][5] ),
    .X(_0701_));
 sky130_fd_sc_hd__a221o_2 _1712_ (.A1(\rx_fifo_mem[1][5] ),
    .A2(_0603_),
    .B1(_0609_),
    .B2(\rx_fifo_mem[11][5] ),
    .C1(_0701_),
    .X(_0702_));
 sky130_fd_sc_hd__a22o_2 _1713_ (.A1(\rx_fifo_mem[5][5] ),
    .A2(_0589_),
    .B1(_0605_),
    .B2(\rx_fifo_mem[4][5] ),
    .X(_0703_));
 sky130_fd_sc_hd__a221o_2 _1714_ (.A1(\rx_fifo_mem[13][5] ),
    .A2(_0604_),
    .B1(_0606_),
    .B2(\rx_fifo_mem[2][5] ),
    .C1(_0703_),
    .X(_0704_));
 sky130_fd_sc_hd__a22o_2 _1715_ (.A1(\rx_fifo_mem[3][5] ),
    .A2(_0600_),
    .B1(_0602_),
    .B2(\rx_fifo_mem[9][5] ),
    .X(_0705_));
 sky130_fd_sc_hd__a2111o_2 _1716_ (.A1(\rx_fifo_mem[7][5] ),
    .A2(_0599_),
    .B1(_0704_),
    .C1(_0705_),
    .D1(_0596_),
    .X(_0706_));
 sky130_fd_sc_hd__or3_2 _1717_ (.A(_0700_),
    .B(_0702_),
    .C(_0706_),
    .X(_0707_));
 sky130_fd_sc_hd__o211a_2 _1718_ (.A1(\rx_fifo_mem[0][5] ),
    .A2(_0597_),
    .B1(_0707_),
    .C1(_0486_),
    .X(_0708_));
 sky130_fd_sc_hd__a22o_2 _1719_ (.A1(packet_count[5]),
    .A2(_0627_),
    .B1(_0628_),
    .B2(packet_count[13]),
    .X(_0709_));
 sky130_fd_sc_hd__a21o_2 _1720_ (.A1(\baud_div_reg[13] ),
    .A2(_0637_),
    .B1(_0709_),
    .X(_0710_));
 sky130_fd_sc_hd__a221o_2 _1721_ (.A1(\irq_status_reg[5] ),
    .A2(_0624_),
    .B1(_0629_),
    .B2(rx_busy_r),
    .C1(_1079_),
    .X(_0711_));
 sky130_fd_sc_hd__a221o_2 _1722_ (.A1(\packet_len_reg[5] ),
    .A2(_0623_),
    .B1(_0632_),
    .B2(\baud_div_reg[5] ),
    .C1(_0711_),
    .X(_0712_));
 sky130_fd_sc_hd__o32a_2 _1723_ (.A1(_0708_),
    .A2(_0710_),
    .A3(_0712_),
    .B1(rd_data[5]),
    .B2(rd_en),
    .X(_0091_));
 sky130_fd_sc_hd__a22o_2 _1724_ (.A1(\rx_fifo_mem[14][6] ),
    .A2(_0591_),
    .B1(_0598_),
    .B2(\rx_fifo_mem[12][6] ),
    .X(_0713_));
 sky130_fd_sc_hd__a22o_2 _1725_ (.A1(\rx_fifo_mem[5][6] ),
    .A2(_0589_),
    .B1(_0609_),
    .B2(\rx_fifo_mem[11][6] ),
    .X(_0714_));
 sky130_fd_sc_hd__a221o_2 _1726_ (.A1(\rx_fifo_mem[6][6] ),
    .A2(_0587_),
    .B1(_0604_),
    .B2(\rx_fifo_mem[13][6] ),
    .C1(_0714_),
    .X(_0715_));
 sky130_fd_sc_hd__a211o_2 _1727_ (.A1(\rx_fifo_mem[3][6] ),
    .A2(_0600_),
    .B1(_0713_),
    .C1(_0715_),
    .X(_0716_));
 sky130_fd_sc_hd__a22o_2 _1728_ (.A1(\rx_fifo_mem[2][6] ),
    .A2(_0606_),
    .B1(_0607_),
    .B2(\rx_fifo_mem[10][6] ),
    .X(_0717_));
 sky130_fd_sc_hd__a221o_2 _1729_ (.A1(\rx_fifo_mem[15][6] ),
    .A2(_0593_),
    .B1(_0605_),
    .B2(\rx_fifo_mem[4][6] ),
    .C1(_0717_),
    .X(_0718_));
 sky130_fd_sc_hd__a22o_2 _1730_ (.A1(\rx_fifo_mem[9][6] ),
    .A2(_0602_),
    .B1(_0603_),
    .B2(\rx_fifo_mem[1][6] ),
    .X(_0719_));
 sky130_fd_sc_hd__a21o_2 _1731_ (.A1(\rx_fifo_mem[8][6] ),
    .A2(_0608_),
    .B1(_0596_),
    .X(_0720_));
 sky130_fd_sc_hd__a211o_2 _1732_ (.A1(\rx_fifo_mem[7][6] ),
    .A2(_0599_),
    .B1(_0719_),
    .C1(_0720_),
    .X(_0721_));
 sky130_fd_sc_hd__or3_2 _1733_ (.A(_0716_),
    .B(_0718_),
    .C(_0721_),
    .X(_0722_));
 sky130_fd_sc_hd__o211a_2 _1734_ (.A1(\rx_fifo_mem[0][6] ),
    .A2(_0597_),
    .B1(_0722_),
    .C1(_0486_),
    .X(_0723_));
 sky130_fd_sc_hd__a22o_2 _1735_ (.A1(\packet_len_reg[6] ),
    .A2(_0623_),
    .B1(_0637_),
    .B2(\baud_div_reg[14] ),
    .X(_0724_));
 sky130_fd_sc_hd__a221o_2 _1736_ (.A1(packet_count[14]),
    .A2(_0628_),
    .B1(_0629_),
    .B2(packet_active_r),
    .C1(_1079_),
    .X(_0725_));
 sky130_fd_sc_hd__a221o_2 _1737_ (.A1(packet_count[6]),
    .A2(_0627_),
    .B1(_0632_),
    .B2(\baud_div_reg[6] ),
    .C1(_0724_),
    .X(_0726_));
 sky130_fd_sc_hd__o32a_2 _1738_ (.A1(_0723_),
    .A2(_0725_),
    .A3(_0726_),
    .B1(rd_data[6]),
    .B2(rd_en),
    .X(_0092_));
 sky130_fd_sc_hd__a22o_2 _1739_ (.A1(\rx_fifo_mem[6][7] ),
    .A2(_0587_),
    .B1(_0591_),
    .B2(\rx_fifo_mem[14][7] ),
    .X(_0727_));
 sky130_fd_sc_hd__a221o_2 _1740_ (.A1(\rx_fifo_mem[4][7] ),
    .A2(_0605_),
    .B1(_0607_),
    .B2(\rx_fifo_mem[10][7] ),
    .C1(_0727_),
    .X(_0728_));
 sky130_fd_sc_hd__a22o_2 _1741_ (.A1(\rx_fifo_mem[7][7] ),
    .A2(_0599_),
    .B1(_0608_),
    .B2(\rx_fifo_mem[8][7] ),
    .X(_0729_));
 sky130_fd_sc_hd__a211o_2 _1742_ (.A1(\rx_fifo_mem[3][7] ),
    .A2(_0600_),
    .B1(_0729_),
    .C1(_0596_),
    .X(_0730_));
 sky130_fd_sc_hd__a22o_2 _1743_ (.A1(\rx_fifo_mem[5][7] ),
    .A2(_0589_),
    .B1(_0602_),
    .B2(\rx_fifo_mem[9][7] ),
    .X(_0731_));
 sky130_fd_sc_hd__a221o_2 _1744_ (.A1(\rx_fifo_mem[15][7] ),
    .A2(_0593_),
    .B1(_0598_),
    .B2(\rx_fifo_mem[12][7] ),
    .C1(_0731_),
    .X(_0732_));
 sky130_fd_sc_hd__a22o_2 _1745_ (.A1(\rx_fifo_mem[1][7] ),
    .A2(_0603_),
    .B1(_0609_),
    .B2(\rx_fifo_mem[11][7] ),
    .X(_0733_));
 sky130_fd_sc_hd__a22o_2 _1746_ (.A1(\rx_fifo_mem[13][7] ),
    .A2(_0604_),
    .B1(_0606_),
    .B2(\rx_fifo_mem[2][7] ),
    .X(_0734_));
 sky130_fd_sc_hd__or3_2 _1747_ (.A(_0732_),
    .B(_0733_),
    .C(_0734_),
    .X(_0735_));
 sky130_fd_sc_hd__or3_2 _1748_ (.A(_0728_),
    .B(_0730_),
    .C(_0735_),
    .X(_0736_));
 sky130_fd_sc_hd__o211a_2 _1749_ (.A1(\rx_fifo_mem[0][7] ),
    .A2(_0597_),
    .B1(_0736_),
    .C1(_0486_),
    .X(_0737_));
 sky130_fd_sc_hd__a22o_2 _1750_ (.A1(\irq_status_reg[7] ),
    .A2(_0624_),
    .B1(_0629_),
    .B2(error_r),
    .X(_0738_));
 sky130_fd_sc_hd__a221o_2 _1751_ (.A1(packet_count[7]),
    .A2(_0627_),
    .B1(_0628_),
    .B2(packet_count[15]),
    .C1(_0738_),
    .X(_0739_));
 sky130_fd_sc_hd__a22o_2 _1752_ (.A1(\baud_div_reg[7] ),
    .A2(_0632_),
    .B1(_0637_),
    .B2(\baud_div_reg[15] ),
    .X(_0740_));
 sky130_fd_sc_hd__a211o_2 _1753_ (.A1(\packet_len_reg[7] ),
    .A2(_0623_),
    .B1(_0740_),
    .C1(_1079_),
    .X(_0741_));
 sky130_fd_sc_hd__o32a_2 _1754_ (.A1(_0737_),
    .A2(_0739_),
    .A3(_0741_),
    .B1(rd_data[7]),
    .B2(rd_en),
    .X(_0093_));
 sky130_fd_sc_hd__or3_2 _1755_ (.A(\tx_state[0] ),
    .B(\tx_state[1] ),
    .C(\tx_state[2] ),
    .X(_0742_));
 sky130_fd_sc_hd__inv_2 _1756_ (.A(_0742_),
    .Y(_0743_));
 sky130_fd_sc_hd__nand2_2 _1757_ (.A(baud_tick),
    .B(_1072_),
    .Y(_0744_));
 sky130_fd_sc_hd__a21o_2 _1758_ (.A1(\tx_state[1] ),
    .A2(\tx_shift[0] ),
    .B1(\tx_state[3] ),
    .X(_0745_));
 sky130_fd_sc_hd__o21a_2 _1759_ (.A1(\tx_state[3] ),
    .A2(_0742_),
    .B1(baud_tick),
    .X(_0746_));
 sky130_fd_sc_hd__o32a_2 _1760_ (.A1(_0743_),
    .A2(_0744_),
    .A3(_0745_),
    .B1(_0746_),
    .B2(uart_tx),
    .X(_0094_));
 sky130_fd_sc_hd__nor4_2 _1761_ (.A(_1080_),
    .B(_1108_),
    .C(_1165_),
    .D(_0547_),
    .Y(_0747_));
 sky130_fd_sc_hd__mux2_1 _1762_ (.A0(\baud_div_reg[8] ),
    .A1(wr_data[0]),
    .S(_0747_),
    .X(_0095_));
 sky130_fd_sc_hd__mux2_1 _1763_ (.A0(\baud_div_reg[9] ),
    .A1(wr_data[1]),
    .S(_0747_),
    .X(_0096_));
 sky130_fd_sc_hd__mux2_1 _1764_ (.A0(\baud_div_reg[10] ),
    .A1(wr_data[2]),
    .S(_0747_),
    .X(_0097_));
 sky130_fd_sc_hd__mux2_1 _1765_ (.A0(\baud_div_reg[11] ),
    .A1(wr_data[3]),
    .S(_0747_),
    .X(_0098_));
 sky130_fd_sc_hd__mux2_1 _1766_ (.A0(\baud_div_reg[12] ),
    .A1(wr_data[4]),
    .S(_0747_),
    .X(_0099_));
 sky130_fd_sc_hd__mux2_1 _1767_ (.A0(\baud_div_reg[13] ),
    .A1(wr_data[5]),
    .S(_0747_),
    .X(_0100_));
 sky130_fd_sc_hd__mux2_1 _1768_ (.A0(\baud_div_reg[14] ),
    .A1(wr_data[6]),
    .S(_0747_),
    .X(_0101_));
 sky130_fd_sc_hd__mux2_1 _1769_ (.A0(\baud_div_reg[15] ),
    .A1(wr_data[7]),
    .S(_0747_),
    .X(_0102_));
 sky130_fd_sc_hd__or2_2 _1770_ (.A(_1109_),
    .B(_0583_),
    .X(_0748_));
 sky130_fd_sc_hd__mux2_1 _1771_ (.A0(wr_data[0]),
    .A1(\packet_len_reg[0] ),
    .S(_0748_),
    .X(_0103_));
 sky130_fd_sc_hd__mux2_1 _1772_ (.A0(wr_data[1]),
    .A1(\packet_len_reg[1] ),
    .S(_0748_),
    .X(_0104_));
 sky130_fd_sc_hd__mux2_1 _1773_ (.A0(wr_data[2]),
    .A1(\packet_len_reg[2] ),
    .S(_0748_),
    .X(_0105_));
 sky130_fd_sc_hd__mux2_1 _1774_ (.A0(wr_data[3]),
    .A1(\packet_len_reg[3] ),
    .S(_0748_),
    .X(_0106_));
 sky130_fd_sc_hd__mux2_1 _1775_ (.A0(wr_data[4]),
    .A1(\packet_len_reg[4] ),
    .S(_0748_),
    .X(_0107_));
 sky130_fd_sc_hd__mux2_1 _1776_ (.A0(wr_data[5]),
    .A1(\packet_len_reg[5] ),
    .S(_0748_),
    .X(_0108_));
 sky130_fd_sc_hd__mux2_1 _1777_ (.A0(wr_data[6]),
    .A1(\packet_len_reg[6] ),
    .S(_0748_),
    .X(_0109_));
 sky130_fd_sc_hd__mux2_1 _1778_ (.A0(wr_data[7]),
    .A1(\packet_len_reg[7] ),
    .S(_0748_),
    .X(_0110_));
 sky130_fd_sc_hd__nor2_2 _1779_ (.A(\tx_wr_ptr[0] ),
    .B(_0504_),
    .Y(_0749_));
 sky130_fd_sc_hd__and3_2 _1780_ (.A(\tx_wr_ptr[0] ),
    .B(_1164_),
    .C(_1166_),
    .X(_0750_));
 sky130_fd_sc_hd__nor2_2 _1781_ (.A(_0749_),
    .B(_0750_),
    .Y(_0111_));
 sky130_fd_sc_hd__xor2_2 _1782_ (.A(\tx_wr_ptr[1] ),
    .B(_0750_),
    .X(_0112_));
 sky130_fd_sc_hd__a21oi_2 _1783_ (.A1(\tx_wr_ptr[1] ),
    .A2(_0750_),
    .B1(\tx_wr_ptr[2] ),
    .Y(_0751_));
 sky130_fd_sc_hd__and3_2 _1784_ (.A(\tx_wr_ptr[1] ),
    .B(\tx_wr_ptr[2] ),
    .C(_0750_),
    .X(_0752_));
 sky130_fd_sc_hd__nor2_2 _1785_ (.A(_0751_),
    .B(_0752_),
    .Y(_0113_));
 sky130_fd_sc_hd__xor2_2 _1786_ (.A(\tx_wr_ptr[3] ),
    .B(_0752_),
    .X(_0114_));
 sky130_fd_sc_hd__xnor2_2 _1787_ (.A(\tx_rd_ptr[0] ),
    .B(_1102_),
    .Y(_0115_));
 sky130_fd_sc_hd__nand2_2 _1788_ (.A(\tx_rd_ptr[1] ),
    .B(\tx_rd_ptr[0] ),
    .Y(_0753_));
 sky130_fd_sc_hd__nor2_2 _1789_ (.A(_1102_),
    .B(_0753_),
    .Y(_0754_));
 sky130_fd_sc_hd__a21oi_2 _1790_ (.A1(\tx_rd_ptr[0] ),
    .A2(_1101_),
    .B1(\tx_rd_ptr[1] ),
    .Y(_0755_));
 sky130_fd_sc_hd__nor2_2 _1791_ (.A(_0754_),
    .B(_0755_),
    .Y(_0116_));
 sky130_fd_sc_hd__xor2_2 _1792_ (.A(\tx_rd_ptr[2] ),
    .B(_0754_),
    .X(_0117_));
 sky130_fd_sc_hd__a21boi_2 _1793_ (.A1(\tx_rd_ptr[2] ),
    .A2(_0754_),
    .B1_N(\tx_rd_ptr[3] ),
    .Y(_0756_));
 sky130_fd_sc_hd__nand2b_2 _1794_ (.A_N(\tx_rd_ptr[3] ),
    .B(\tx_rd_ptr[2] ),
    .Y(_0757_));
 sky130_fd_sc_hd__nor2_2 _1795_ (.A(_0753_),
    .B(_0757_),
    .Y(_0758_));
 sky130_fd_sc_hd__a21o_2 _1796_ (.A1(_1101_),
    .A2(_0758_),
    .B1(_0756_),
    .X(_0118_));
 sky130_fd_sc_hd__xnor2_2 _1797_ (.A(\rx_rd_ptr[0] ),
    .B(_0488_),
    .Y(_0119_));
 sky130_fd_sc_hd__a21oi_2 _1798_ (.A1(\rx_rd_ptr[0] ),
    .A2(_0487_),
    .B1(\rx_rd_ptr[1] ),
    .Y(_0759_));
 sky130_fd_sc_hd__nor2_2 _1799_ (.A(_0488_),
    .B(_0592_),
    .Y(_0760_));
 sky130_fd_sc_hd__nor2_2 _1800_ (.A(_0759_),
    .B(_0760_),
    .Y(_0120_));
 sky130_fd_sc_hd__nor2_2 _1801_ (.A(\rx_rd_ptr[2] ),
    .B(_0760_),
    .Y(_0761_));
 sky130_fd_sc_hd__nand2_2 _1802_ (.A(\rx_rd_ptr[2] ),
    .B(_0760_),
    .Y(_0762_));
 sky130_fd_sc_hd__and2b_2 _1803_ (.A_N(_0761_),
    .B(_0762_),
    .X(_0121_));
 sky130_fd_sc_hd__a22o_2 _1804_ (.A1(_0487_),
    .A2(_0599_),
    .B1(_0762_),
    .B2(\rx_rd_ptr[3] ),
    .X(_0122_));
 sky130_fd_sc_hd__nand2_2 _1805_ (.A(_1095_),
    .B(_0744_),
    .Y(_0763_));
 sky130_fd_sc_hd__nand2_2 _1806_ (.A(_0742_),
    .B(_0763_),
    .Y(_0764_));
 sky130_fd_sc_hd__nor2_2 _1807_ (.A(_1078_),
    .B(_0764_),
    .Y(_0765_));
 sky130_fd_sc_hd__mux2_1 _1808_ (.A0(_0765_),
    .A1(_0764_),
    .S(\tx_bit_cnt[0] ),
    .X(_0123_));
 sky130_fd_sc_hd__or2_2 _1809_ (.A(\tx_bit_cnt[1] ),
    .B(\tx_bit_cnt[0] ),
    .X(_0766_));
 sky130_fd_sc_hd__a32o_2 _1810_ (.A1(_1096_),
    .A2(_0765_),
    .A3(_0766_),
    .B1(_0764_),
    .B2(\tx_bit_cnt[1] ),
    .X(_0124_));
 sky130_fd_sc_hd__a21o_2 _1811_ (.A1(\tx_bit_cnt[1] ),
    .A2(\tx_bit_cnt[0] ),
    .B1(\tx_bit_cnt[2] ),
    .X(_0767_));
 sky130_fd_sc_hd__a32o_2 _1812_ (.A1(_1097_),
    .A2(_0765_),
    .A3(_0767_),
    .B1(_0764_),
    .B2(\tx_bit_cnt[2] ),
    .X(_0125_));
 sky130_fd_sc_hd__a21o_2 _1813_ (.A1(\tx_state[1] ),
    .A2(_1097_),
    .B1(_0764_),
    .X(_0768_));
 sky130_fd_sc_hd__a22o_2 _1814_ (.A1(_1098_),
    .A2(_0765_),
    .B1(_0768_),
    .B2(\tx_bit_cnt[3] ),
    .X(_0126_));
 sky130_fd_sc_hd__and2b_2 _1815_ (.A_N(_1106_),
    .B(_1088_),
    .X(_0769_));
 sky130_fd_sc_hd__nor2_2 _1816_ (.A(_1103_),
    .B(_0769_),
    .Y(_0770_));
 sky130_fd_sc_hd__mux2_1 _1817_ (.A0(_0769_),
    .A1(_0770_),
    .S(\rx_bit_cnt[0] ),
    .X(_0127_));
 sky130_fd_sc_hd__or2_2 _1818_ (.A(\rx_bit_cnt[1] ),
    .B(\rx_bit_cnt[0] ),
    .X(_0771_));
 sky130_fd_sc_hd__a32o_2 _1819_ (.A1(_1083_),
    .A2(_0769_),
    .A3(_0771_),
    .B1(_0770_),
    .B2(\rx_bit_cnt[1] ),
    .X(_0128_));
 sky130_fd_sc_hd__a21o_2 _1820_ (.A1(\rx_bit_cnt[1] ),
    .A2(\rx_bit_cnt[0] ),
    .B1(\rx_bit_cnt[2] ),
    .X(_0772_));
 sky130_fd_sc_hd__a32o_2 _1821_ (.A1(_1084_),
    .A2(_0769_),
    .A3(_0772_),
    .B1(_0770_),
    .B2(\rx_bit_cnt[2] ),
    .X(_0129_));
 sky130_fd_sc_hd__a21o_2 _1822_ (.A1(\rx_state[1] ),
    .A2(_1084_),
    .B1(_0770_),
    .X(_0773_));
 sky130_fd_sc_hd__a22o_2 _1823_ (.A1(_1085_),
    .A2(_0769_),
    .B1(_0773_),
    .B2(\rx_bit_cnt[3] ),
    .X(_0130_));
 sky130_fd_sc_hd__or2_2 _1824_ (.A(\tx_rd_ptr[1] ),
    .B(\tx_rd_ptr[0] ),
    .X(_0774_));
 sky130_fd_sc_hd__or2_2 _1825_ (.A(\tx_rd_ptr[2] ),
    .B(\tx_rd_ptr[3] ),
    .X(_0775_));
 sky130_fd_sc_hd__nor2_2 _1826_ (.A(_0774_),
    .B(_0775_),
    .Y(_0776_));
 sky130_fd_sc_hd__or2_2 _1827_ (.A(_0774_),
    .B(_0775_),
    .X(_0777_));
 sky130_fd_sc_hd__nand2b_2 _1828_ (.A_N(\tx_rd_ptr[2] ),
    .B(\tx_rd_ptr[3] ),
    .Y(_0778_));
 sky130_fd_sc_hd__nand2b_2 _1829_ (.A_N(\tx_rd_ptr[1] ),
    .B(\tx_rd_ptr[0] ),
    .Y(_0779_));
 sky130_fd_sc_hd__nor2_2 _1830_ (.A(_0778_),
    .B(_0779_),
    .Y(_0780_));
 sky130_fd_sc_hd__nor2_2 _1831_ (.A(_0774_),
    .B(_0778_),
    .Y(_0781_));
 sky130_fd_sc_hd__nand2_2 _1832_ (.A(\tx_rd_ptr[2] ),
    .B(\tx_rd_ptr[3] ),
    .Y(_0782_));
 sky130_fd_sc_hd__and4b_2 _1833_ (.A_N(\tx_rd_ptr[1] ),
    .B(\tx_rd_ptr[0] ),
    .C(\tx_rd_ptr[2] ),
    .D(\tx_rd_ptr[3] ),
    .X(_0783_));
 sky130_fd_sc_hd__nor2_2 _1834_ (.A(_0753_),
    .B(_0782_),
    .Y(_0784_));
 sky130_fd_sc_hd__nor2_2 _1835_ (.A(_0753_),
    .B(_0778_),
    .Y(_0785_));
 sky130_fd_sc_hd__nor2_2 _1836_ (.A(_0757_),
    .B(_0779_),
    .Y(_0786_));
 sky130_fd_sc_hd__nand2b_2 _1837_ (.A_N(\tx_rd_ptr[0] ),
    .B(\tx_rd_ptr[1] ),
    .Y(_0787_));
 sky130_fd_sc_hd__nor2_2 _1838_ (.A(_0778_),
    .B(_0787_),
    .Y(_0788_));
 sky130_fd_sc_hd__nor2_2 _1839_ (.A(_0782_),
    .B(_0787_),
    .Y(_0789_));
 sky130_fd_sc_hd__nor2_2 _1840_ (.A(_0757_),
    .B(_0787_),
    .Y(_0790_));
 sky130_fd_sc_hd__nor2_2 _1841_ (.A(_0753_),
    .B(_0775_),
    .Y(_0791_));
 sky130_fd_sc_hd__nor2_2 _1842_ (.A(_0775_),
    .B(_0787_),
    .Y(_0792_));
 sky130_fd_sc_hd__nor2_2 _1843_ (.A(_0775_),
    .B(_0779_),
    .Y(_0793_));
 sky130_fd_sc_hd__a22o_2 _1844_ (.A1(\tx_fifo_mem[2][0] ),
    .A2(_0792_),
    .B1(_0793_),
    .B2(\tx_fifo_mem[1][0] ),
    .X(_0794_));
 sky130_fd_sc_hd__nor2_2 _1845_ (.A(_0757_),
    .B(_0774_),
    .Y(_0795_));
 sky130_fd_sc_hd__and4bb_2 _1846_ (.A_N(\tx_rd_ptr[1] ),
    .B_N(\tx_rd_ptr[0] ),
    .C(\tx_rd_ptr[2] ),
    .D(\tx_rd_ptr[3] ),
    .X(_0796_));
 sky130_fd_sc_hd__a22o_2 _1847_ (.A1(\tx_fifo_mem[5][0] ),
    .A2(_0786_),
    .B1(_0791_),
    .B2(\tx_fifo_mem[3][0] ),
    .X(_0797_));
 sky130_fd_sc_hd__a22o_2 _1848_ (.A1(\tx_fifo_mem[15][0] ),
    .A2(_0784_),
    .B1(_0796_),
    .B2(\tx_fifo_mem[12][0] ),
    .X(_0798_));
 sky130_fd_sc_hd__a22o_2 _1849_ (.A1(\tx_fifo_mem[10][0] ),
    .A2(_0788_),
    .B1(_0795_),
    .B2(\tx_fifo_mem[4][0] ),
    .X(_0799_));
 sky130_fd_sc_hd__a221o_2 _1850_ (.A1(\tx_fifo_mem[11][0] ),
    .A2(_0785_),
    .B1(_0790_),
    .B2(\tx_fifo_mem[6][0] ),
    .C1(_0799_),
    .X(_0800_));
 sky130_fd_sc_hd__a2111o_2 _1851_ (.A1(\tx_fifo_mem[14][0] ),
    .A2(_0789_),
    .B1(_0797_),
    .C1(_0800_),
    .D1(_0776_),
    .X(_0801_));
 sky130_fd_sc_hd__a22o_2 _1852_ (.A1(\tx_fifo_mem[7][0] ),
    .A2(_0758_),
    .B1(_0780_),
    .B2(\tx_fifo_mem[9][0] ),
    .X(_0802_));
 sky130_fd_sc_hd__a22o_2 _1853_ (.A1(\tx_fifo_mem[8][0] ),
    .A2(_0781_),
    .B1(_0783_),
    .B2(\tx_fifo_mem[13][0] ),
    .X(_0803_));
 sky130_fd_sc_hd__or4_2 _1854_ (.A(_0794_),
    .B(_0798_),
    .C(_0802_),
    .D(_0803_),
    .X(_0804_));
 sky130_fd_sc_hd__o22a_2 _1855_ (.A1(\tx_fifo_mem[0][0] ),
    .A2(_0777_),
    .B1(_0801_),
    .B2(_0804_),
    .X(_0805_));
 sky130_fd_sc_hd__o21ai_2 _1856_ (.A1(\tx_state[0] ),
    .A2(\tx_state[1] ),
    .B1(_0763_),
    .Y(_0806_));
 sky130_fd_sc_hd__mux2_1 _1857_ (.A0(\tx_shift[1] ),
    .A1(_0805_),
    .S(_1078_),
    .X(_0807_));
 sky130_fd_sc_hd__mux2_1 _1858_ (.A0(_0807_),
    .A1(\tx_shift[0] ),
    .S(_0806_),
    .X(_0131_));
 sky130_fd_sc_hd__a22o_2 _1859_ (.A1(\tx_fifo_mem[11][1] ),
    .A2(_0785_),
    .B1(_0796_),
    .B2(\tx_fifo_mem[12][1] ),
    .X(_0808_));
 sky130_fd_sc_hd__a22o_2 _1860_ (.A1(\tx_fifo_mem[10][1] ),
    .A2(_0788_),
    .B1(_0790_),
    .B2(\tx_fifo_mem[6][1] ),
    .X(_0809_));
 sky130_fd_sc_hd__a211o_2 _1861_ (.A1(\tx_fifo_mem[9][1] ),
    .A2(_0780_),
    .B1(_0809_),
    .C1(_0776_),
    .X(_0810_));
 sky130_fd_sc_hd__a22o_2 _1862_ (.A1(\tx_fifo_mem[2][1] ),
    .A2(_0792_),
    .B1(_0793_),
    .B2(\tx_fifo_mem[1][1] ),
    .X(_0811_));
 sky130_fd_sc_hd__a221o_2 _1863_ (.A1(\tx_fifo_mem[15][1] ),
    .A2(_0784_),
    .B1(_0789_),
    .B2(\tx_fifo_mem[14][1] ),
    .C1(_0811_),
    .X(_0812_));
 sky130_fd_sc_hd__a22o_2 _1864_ (.A1(\tx_fifo_mem[7][1] ),
    .A2(_0758_),
    .B1(_0783_),
    .B2(\tx_fifo_mem[13][1] ),
    .X(_0813_));
 sky130_fd_sc_hd__a22o_2 _1865_ (.A1(\tx_fifo_mem[5][1] ),
    .A2(_0786_),
    .B1(_0791_),
    .B2(\tx_fifo_mem[3][1] ),
    .X(_0814_));
 sky130_fd_sc_hd__a2111o_2 _1866_ (.A1(\tx_fifo_mem[4][1] ),
    .A2(_0795_),
    .B1(_0808_),
    .C1(_0813_),
    .D1(_0814_),
    .X(_0815_));
 sky130_fd_sc_hd__a211o_2 _1867_ (.A1(\tx_fifo_mem[8][1] ),
    .A2(_0781_),
    .B1(_0812_),
    .C1(_0815_),
    .X(_0816_));
 sky130_fd_sc_hd__o22ai_2 _1868_ (.A1(\tx_fifo_mem[0][1] ),
    .A2(_0777_),
    .B1(_0810_),
    .B2(_0816_),
    .Y(_0817_));
 sky130_fd_sc_hd__inv_2 _1869_ (.A(_0817_),
    .Y(_0818_));
 sky130_fd_sc_hd__nand2_2 _1870_ (.A(\tx_state[1] ),
    .B(\tx_shift[2] ),
    .Y(_0819_));
 sky130_fd_sc_hd__o21ai_2 _1871_ (.A1(\tx_state[1] ),
    .A2(_0817_),
    .B1(_0819_),
    .Y(_0820_));
 sky130_fd_sc_hd__mux2_1 _1872_ (.A0(_0820_),
    .A1(\tx_shift[1] ),
    .S(_0806_),
    .X(_0132_));
 sky130_fd_sc_hd__a22o_2 _1873_ (.A1(\tx_fifo_mem[7][2] ),
    .A2(_0758_),
    .B1(_0796_),
    .B2(\tx_fifo_mem[12][2] ),
    .X(_0821_));
 sky130_fd_sc_hd__a22o_2 _1874_ (.A1(\tx_fifo_mem[13][2] ),
    .A2(_0783_),
    .B1(_0789_),
    .B2(\tx_fifo_mem[14][2] ),
    .X(_0822_));
 sky130_fd_sc_hd__a221o_2 _1875_ (.A1(\tx_fifo_mem[9][2] ),
    .A2(_0780_),
    .B1(_0788_),
    .B2(\tx_fifo_mem[10][2] ),
    .C1(_0822_),
    .X(_0823_));
 sky130_fd_sc_hd__a22o_2 _1876_ (.A1(\tx_fifo_mem[15][2] ),
    .A2(_0784_),
    .B1(_0786_),
    .B2(\tx_fifo_mem[5][2] ),
    .X(_0824_));
 sky130_fd_sc_hd__a2111o_2 _1877_ (.A1(\tx_fifo_mem[3][2] ),
    .A2(_0791_),
    .B1(_0823_),
    .C1(_0824_),
    .D1(_0776_),
    .X(_0825_));
 sky130_fd_sc_hd__a22o_2 _1878_ (.A1(\tx_fifo_mem[6][2] ),
    .A2(_0790_),
    .B1(_0792_),
    .B2(\tx_fifo_mem[2][2] ),
    .X(_0826_));
 sky130_fd_sc_hd__a22o_2 _1879_ (.A1(\tx_fifo_mem[1][2] ),
    .A2(_0793_),
    .B1(_0795_),
    .B2(\tx_fifo_mem[4][2] ),
    .X(_0827_));
 sky130_fd_sc_hd__a22o_2 _1880_ (.A1(\tx_fifo_mem[8][2] ),
    .A2(_0781_),
    .B1(_0785_),
    .B2(\tx_fifo_mem[11][2] ),
    .X(_0828_));
 sky130_fd_sc_hd__or4_2 _1881_ (.A(_0821_),
    .B(_0826_),
    .C(_0827_),
    .D(_0828_),
    .X(_0829_));
 sky130_fd_sc_hd__o22a_2 _1882_ (.A1(\tx_fifo_mem[0][2] ),
    .A2(_0777_),
    .B1(_0825_),
    .B2(_0829_),
    .X(_0830_));
 sky130_fd_sc_hd__mux2_1 _1883_ (.A0(\tx_shift[3] ),
    .A1(_0830_),
    .S(_1078_),
    .X(_0831_));
 sky130_fd_sc_hd__mux2_1 _1884_ (.A0(_0831_),
    .A1(\tx_shift[2] ),
    .S(_0806_),
    .X(_0133_));
 sky130_fd_sc_hd__a22o_2 _1885_ (.A1(\tx_fifo_mem[7][3] ),
    .A2(_0758_),
    .B1(_0788_),
    .B2(\tx_fifo_mem[10][3] ),
    .X(_0832_));
 sky130_fd_sc_hd__a221o_2 _1886_ (.A1(\tx_fifo_mem[5][3] ),
    .A2(_0786_),
    .B1(_0793_),
    .B2(\tx_fifo_mem[1][3] ),
    .C1(_0832_),
    .X(_0833_));
 sky130_fd_sc_hd__a22o_2 _1887_ (.A1(\tx_fifo_mem[15][3] ),
    .A2(_0784_),
    .B1(_0790_),
    .B2(\tx_fifo_mem[6][3] ),
    .X(_0834_));
 sky130_fd_sc_hd__a2111o_2 _1888_ (.A1(\tx_fifo_mem[13][3] ),
    .A2(_0783_),
    .B1(_0833_),
    .C1(_0834_),
    .D1(_0776_),
    .X(_0835_));
 sky130_fd_sc_hd__a22o_2 _1889_ (.A1(\tx_fifo_mem[2][3] ),
    .A2(_0792_),
    .B1(_0795_),
    .B2(\tx_fifo_mem[4][3] ),
    .X(_0836_));
 sky130_fd_sc_hd__a22o_2 _1890_ (.A1(\tx_fifo_mem[8][3] ),
    .A2(_0781_),
    .B1(_0791_),
    .B2(\tx_fifo_mem[3][3] ),
    .X(_0837_));
 sky130_fd_sc_hd__a22o_2 _1891_ (.A1(\tx_fifo_mem[11][3] ),
    .A2(_0785_),
    .B1(_0796_),
    .B2(\tx_fifo_mem[12][3] ),
    .X(_0838_));
 sky130_fd_sc_hd__a22o_2 _1892_ (.A1(\tx_fifo_mem[9][3] ),
    .A2(_0780_),
    .B1(_0789_),
    .B2(\tx_fifo_mem[14][3] ),
    .X(_0839_));
 sky130_fd_sc_hd__or4_2 _1893_ (.A(_0836_),
    .B(_0837_),
    .C(_0838_),
    .D(_0839_),
    .X(_0840_));
 sky130_fd_sc_hd__o22a_2 _1894_ (.A1(\tx_fifo_mem[0][3] ),
    .A2(_0777_),
    .B1(_0835_),
    .B2(_0840_),
    .X(_0841_));
 sky130_fd_sc_hd__mux2_1 _1895_ (.A0(\tx_shift[4] ),
    .A1(_0841_),
    .S(_1078_),
    .X(_0842_));
 sky130_fd_sc_hd__mux2_1 _1896_ (.A0(_0842_),
    .A1(\tx_shift[3] ),
    .S(_0806_),
    .X(_0134_));
 sky130_fd_sc_hd__a22o_2 _1897_ (.A1(\tx_fifo_mem[14][4] ),
    .A2(_0789_),
    .B1(_0792_),
    .B2(\tx_fifo_mem[2][4] ),
    .X(_0843_));
 sky130_fd_sc_hd__a211o_2 _1898_ (.A1(\tx_fifo_mem[1][4] ),
    .A2(_0793_),
    .B1(_0843_),
    .C1(_0776_),
    .X(_0844_));
 sky130_fd_sc_hd__a22o_2 _1899_ (.A1(\tx_fifo_mem[10][4] ),
    .A2(_0788_),
    .B1(_0790_),
    .B2(\tx_fifo_mem[6][4] ),
    .X(_0845_));
 sky130_fd_sc_hd__a221o_2 _1900_ (.A1(\tx_fifo_mem[9][4] ),
    .A2(_0780_),
    .B1(_0781_),
    .B2(\tx_fifo_mem[8][4] ),
    .C1(_0845_),
    .X(_0846_));
 sky130_fd_sc_hd__a22o_2 _1901_ (.A1(\tx_fifo_mem[7][4] ),
    .A2(_0758_),
    .B1(_0795_),
    .B2(\tx_fifo_mem[4][4] ),
    .X(_0847_));
 sky130_fd_sc_hd__a22o_2 _1902_ (.A1(\tx_fifo_mem[13][4] ),
    .A2(_0783_),
    .B1(_0796_),
    .B2(\tx_fifo_mem[12][4] ),
    .X(_0848_));
 sky130_fd_sc_hd__a221o_2 _1903_ (.A1(\tx_fifo_mem[5][4] ),
    .A2(_0786_),
    .B1(_0791_),
    .B2(\tx_fifo_mem[3][4] ),
    .C1(_0848_),
    .X(_0849_));
 sky130_fd_sc_hd__a211o_2 _1904_ (.A1(\tx_fifo_mem[15][4] ),
    .A2(_0784_),
    .B1(_0847_),
    .C1(_0849_),
    .X(_0850_));
 sky130_fd_sc_hd__a211o_2 _1905_ (.A1(\tx_fifo_mem[11][4] ),
    .A2(_0785_),
    .B1(_0846_),
    .C1(_0850_),
    .X(_0851_));
 sky130_fd_sc_hd__o22a_2 _1906_ (.A1(\tx_fifo_mem[0][4] ),
    .A2(_0777_),
    .B1(_0844_),
    .B2(_0851_),
    .X(_0852_));
 sky130_fd_sc_hd__mux2_1 _1907_ (.A0(\tx_shift[5] ),
    .A1(_0852_),
    .S(_1078_),
    .X(_0853_));
 sky130_fd_sc_hd__mux2_1 _1908_ (.A0(_0853_),
    .A1(\tx_shift[4] ),
    .S(_0806_),
    .X(_0135_));
 sky130_fd_sc_hd__a22o_2 _1909_ (.A1(\tx_fifo_mem[14][5] ),
    .A2(_0789_),
    .B1(_0795_),
    .B2(\tx_fifo_mem[4][5] ),
    .X(_0854_));
 sky130_fd_sc_hd__a221o_2 _1910_ (.A1(\tx_fifo_mem[13][5] ),
    .A2(_0783_),
    .B1(_0784_),
    .B2(\tx_fifo_mem[15][5] ),
    .C1(_0854_),
    .X(_0855_));
 sky130_fd_sc_hd__a22o_2 _1911_ (.A1(\tx_fifo_mem[5][5] ),
    .A2(_0786_),
    .B1(_0790_),
    .B2(\tx_fifo_mem[6][5] ),
    .X(_0856_));
 sky130_fd_sc_hd__a2111o_2 _1912_ (.A1(\tx_fifo_mem[1][5] ),
    .A2(_0793_),
    .B1(_0855_),
    .C1(_0856_),
    .D1(_0776_),
    .X(_0857_));
 sky130_fd_sc_hd__a22o_2 _1913_ (.A1(\tx_fifo_mem[9][5] ),
    .A2(_0780_),
    .B1(_0785_),
    .B2(\tx_fifo_mem[11][5] ),
    .X(_0858_));
 sky130_fd_sc_hd__a22o_2 _1914_ (.A1(\tx_fifo_mem[8][5] ),
    .A2(_0781_),
    .B1(_0796_),
    .B2(\tx_fifo_mem[12][5] ),
    .X(_0859_));
 sky130_fd_sc_hd__a22o_2 _1915_ (.A1(\tx_fifo_mem[10][5] ),
    .A2(_0788_),
    .B1(_0792_),
    .B2(\tx_fifo_mem[2][5] ),
    .X(_0860_));
 sky130_fd_sc_hd__a22o_2 _1916_ (.A1(\tx_fifo_mem[7][5] ),
    .A2(_0758_),
    .B1(_0791_),
    .B2(\tx_fifo_mem[3][5] ),
    .X(_0861_));
 sky130_fd_sc_hd__or4_2 _1917_ (.A(_0858_),
    .B(_0859_),
    .C(_0860_),
    .D(_0861_),
    .X(_0862_));
 sky130_fd_sc_hd__o22a_2 _1918_ (.A1(\tx_fifo_mem[0][5] ),
    .A2(_0777_),
    .B1(_0857_),
    .B2(_0862_),
    .X(_0863_));
 sky130_fd_sc_hd__mux2_1 _1919_ (.A0(\tx_shift[6] ),
    .A1(_0863_),
    .S(_1078_),
    .X(_0864_));
 sky130_fd_sc_hd__mux2_1 _1920_ (.A0(_0864_),
    .A1(\tx_shift[5] ),
    .S(_0806_),
    .X(_0136_));
 sky130_fd_sc_hd__a22o_2 _1921_ (.A1(\tx_fifo_mem[13][6] ),
    .A2(_0783_),
    .B1(_0785_),
    .B2(\tx_fifo_mem[11][6] ),
    .X(_0865_));
 sky130_fd_sc_hd__a221o_2 _1922_ (.A1(\tx_fifo_mem[8][6] ),
    .A2(_0781_),
    .B1(_0784_),
    .B2(\tx_fifo_mem[15][6] ),
    .C1(_0865_),
    .X(_0866_));
 sky130_fd_sc_hd__a22o_2 _1923_ (.A1(\tx_fifo_mem[1][6] ),
    .A2(_0793_),
    .B1(_0796_),
    .B2(\tx_fifo_mem[12][6] ),
    .X(_0867_));
 sky130_fd_sc_hd__a2111o_2 _1924_ (.A1(\tx_fifo_mem[3][6] ),
    .A2(_0791_),
    .B1(_0866_),
    .C1(_0867_),
    .D1(_0776_),
    .X(_0868_));
 sky130_fd_sc_hd__a22o_2 _1925_ (.A1(\tx_fifo_mem[14][6] ),
    .A2(_0789_),
    .B1(_0795_),
    .B2(\tx_fifo_mem[4][6] ),
    .X(_0869_));
 sky130_fd_sc_hd__a22o_2 _1926_ (.A1(\tx_fifo_mem[5][6] ),
    .A2(_0786_),
    .B1(_0792_),
    .B2(\tx_fifo_mem[2][6] ),
    .X(_0870_));
 sky130_fd_sc_hd__a22o_2 _1927_ (.A1(\tx_fifo_mem[9][6] ),
    .A2(_0780_),
    .B1(_0790_),
    .B2(\tx_fifo_mem[6][6] ),
    .X(_0871_));
 sky130_fd_sc_hd__a22o_2 _1928_ (.A1(\tx_fifo_mem[7][6] ),
    .A2(_0758_),
    .B1(_0788_),
    .B2(\tx_fifo_mem[10][6] ),
    .X(_0872_));
 sky130_fd_sc_hd__or4_2 _1929_ (.A(_0869_),
    .B(_0870_),
    .C(_0871_),
    .D(_0872_),
    .X(_0873_));
 sky130_fd_sc_hd__o22a_2 _1930_ (.A1(\tx_fifo_mem[0][6] ),
    .A2(_0777_),
    .B1(_0868_),
    .B2(_0873_),
    .X(_0874_));
 sky130_fd_sc_hd__mux2_1 _1931_ (.A0(\tx_shift[7] ),
    .A1(_0874_),
    .S(_1078_),
    .X(_0875_));
 sky130_fd_sc_hd__mux2_1 _1932_ (.A0(_0875_),
    .A1(\tx_shift[6] ),
    .S(_0806_),
    .X(_0137_));
 sky130_fd_sc_hd__a22o_2 _1933_ (.A1(\tx_fifo_mem[3][7] ),
    .A2(_0791_),
    .B1(_0796_),
    .B2(\tx_fifo_mem[12][7] ),
    .X(_0876_));
 sky130_fd_sc_hd__a22o_2 _1934_ (.A1(\tx_fifo_mem[14][7] ),
    .A2(_0789_),
    .B1(_0793_),
    .B2(\tx_fifo_mem[1][7] ),
    .X(_0877_));
 sky130_fd_sc_hd__a221o_2 _1935_ (.A1(\tx_fifo_mem[7][7] ),
    .A2(_0758_),
    .B1(_0783_),
    .B2(\tx_fifo_mem[13][7] ),
    .C1(_0877_),
    .X(_0878_));
 sky130_fd_sc_hd__a22o_2 _1936_ (.A1(\tx_fifo_mem[15][7] ),
    .A2(_0784_),
    .B1(_0795_),
    .B2(\tx_fifo_mem[4][7] ),
    .X(_0879_));
 sky130_fd_sc_hd__a221o_2 _1937_ (.A1(\tx_fifo_mem[5][7] ),
    .A2(_0786_),
    .B1(_0792_),
    .B2(\tx_fifo_mem[2][7] ),
    .C1(_0879_),
    .X(_0880_));
 sky130_fd_sc_hd__a22o_2 _1938_ (.A1(\tx_fifo_mem[9][7] ),
    .A2(_0780_),
    .B1(_0790_),
    .B2(\tx_fifo_mem[6][7] ),
    .X(_0881_));
 sky130_fd_sc_hd__a221o_2 _1939_ (.A1(\tx_fifo_mem[8][7] ),
    .A2(_0781_),
    .B1(_0788_),
    .B2(\tx_fifo_mem[10][7] ),
    .C1(_0881_),
    .X(_0882_));
 sky130_fd_sc_hd__a211o_2 _1940_ (.A1(\tx_fifo_mem[11][7] ),
    .A2(_0785_),
    .B1(_0876_),
    .C1(_0776_),
    .X(_0883_));
 sky130_fd_sc_hd__or3_2 _1941_ (.A(_0880_),
    .B(_0882_),
    .C(_0883_),
    .X(_0884_));
 sky130_fd_sc_hd__o221a_2 _1942_ (.A1(\tx_fifo_mem[0][7] ),
    .A2(_0777_),
    .B1(_0878_),
    .B2(_0884_),
    .C1(_1094_),
    .X(_0885_));
 sky130_fd_sc_hd__nand2_2 _1943_ (.A(\tx_state[0] ),
    .B(_0885_),
    .Y(_0886_));
 sky130_fd_sc_hd__a2bb2o_2 _1944_ (.A1_N(\tx_state[1] ),
    .A2_N(_0886_),
    .B1(_0806_),
    .B2(\tx_shift[7] ),
    .X(_0138_));
 sky130_fd_sc_hd__a22o_2 _1945_ (.A1(\rx_shift[1] ),
    .A2(_0769_),
    .B1(_0770_),
    .B2(\rx_shift[0] ),
    .X(_0139_));
 sky130_fd_sc_hd__a22o_2 _1946_ (.A1(\rx_shift[2] ),
    .A2(_0769_),
    .B1(_0770_),
    .B2(\rx_shift[1] ),
    .X(_0140_));
 sky130_fd_sc_hd__a22o_2 _1947_ (.A1(\rx_shift[3] ),
    .A2(_0769_),
    .B1(_0770_),
    .B2(\rx_shift[2] ),
    .X(_0141_));
 sky130_fd_sc_hd__a22o_2 _1948_ (.A1(\rx_shift[4] ),
    .A2(_0769_),
    .B1(_0770_),
    .B2(\rx_shift[3] ),
    .X(_0142_));
 sky130_fd_sc_hd__a22o_2 _1949_ (.A1(\rx_shift[5] ),
    .A2(_0769_),
    .B1(_0770_),
    .B2(\rx_shift[4] ),
    .X(_0143_));
 sky130_fd_sc_hd__a22o_2 _1950_ (.A1(\rx_shift[6] ),
    .A2(_0769_),
    .B1(_0770_),
    .B2(\rx_shift[5] ),
    .X(_0144_));
 sky130_fd_sc_hd__a22o_2 _1951_ (.A1(\rx_shift[7] ),
    .A2(_0769_),
    .B1(_0770_),
    .B2(\rx_shift[6] ),
    .X(_0145_));
 sky130_fd_sc_hd__a32o_2 _1952_ (.A1(uart_rx),
    .A2(_1077_),
    .A3(_1088_),
    .B1(_0770_),
    .B2(\rx_shift[7] ),
    .X(_0146_));
 sky130_fd_sc_hd__mux2_1 _1953_ (.A0(\tx_hold_byte[0] ),
    .A1(_0805_),
    .S(_1101_),
    .X(_0147_));
 sky130_fd_sc_hd__mux2_1 _1954_ (.A0(\tx_hold_byte[1] ),
    .A1(_0818_),
    .S(_1101_),
    .X(_0148_));
 sky130_fd_sc_hd__mux2_1 _1955_ (.A0(\tx_hold_byte[2] ),
    .A1(_0830_),
    .S(_1101_),
    .X(_0149_));
 sky130_fd_sc_hd__mux2_1 _1956_ (.A0(\tx_hold_byte[3] ),
    .A1(_0841_),
    .S(_1101_),
    .X(_0150_));
 sky130_fd_sc_hd__mux2_1 _1957_ (.A0(\tx_hold_byte[4] ),
    .A1(_0852_),
    .S(_1101_),
    .X(_0151_));
 sky130_fd_sc_hd__mux2_1 _1958_ (.A0(\tx_hold_byte[5] ),
    .A1(_0863_),
    .S(_1101_),
    .X(_0152_));
 sky130_fd_sc_hd__mux2_1 _1959_ (.A0(\tx_hold_byte[6] ),
    .A1(_0874_),
    .S(_1101_),
    .X(_0153_));
 sky130_fd_sc_hd__a21bo_2 _1960_ (.A1(\tx_hold_byte[7] ),
    .A2(_1102_),
    .B1_N(_0886_),
    .X(_0154_));
 sky130_fd_sc_hd__mux2_1 _1961_ (.A0(\loopback_byte[0] ),
    .A1(\tx_hold_byte[0] ),
    .S(_0479_),
    .X(_0155_));
 sky130_fd_sc_hd__mux2_1 _1962_ (.A0(\loopback_byte[1] ),
    .A1(\tx_hold_byte[1] ),
    .S(_0479_),
    .X(_0156_));
 sky130_fd_sc_hd__mux2_1 _1963_ (.A0(\loopback_byte[2] ),
    .A1(\tx_hold_byte[2] ),
    .S(_0479_),
    .X(_0157_));
 sky130_fd_sc_hd__mux2_1 _1964_ (.A0(\loopback_byte[3] ),
    .A1(\tx_hold_byte[3] ),
    .S(_0479_),
    .X(_0158_));
 sky130_fd_sc_hd__mux2_1 _1965_ (.A0(\loopback_byte[4] ),
    .A1(\tx_hold_byte[4] ),
    .S(_0479_),
    .X(_0159_));
 sky130_fd_sc_hd__mux2_1 _1966_ (.A0(\loopback_byte[5] ),
    .A1(\tx_hold_byte[5] ),
    .S(_0479_),
    .X(_0160_));
 sky130_fd_sc_hd__mux2_1 _1967_ (.A0(\loopback_byte[6] ),
    .A1(\tx_hold_byte[6] ),
    .S(_0479_),
    .X(_0161_));
 sky130_fd_sc_hd__mux2_1 _1968_ (.A0(\loopback_byte[7] ),
    .A1(\tx_hold_byte[7] ),
    .S(_0479_),
    .X(_0162_));
 sky130_fd_sc_hd__and2_2 _1969_ (.A(tx_busy_r),
    .B(_1100_),
    .X(_0887_));
 sky130_fd_sc_hd__o2bb2a_2 _1970_ (.A1_N(baud_tick),
    .A2_N(\tx_state[3] ),
    .B1(_1101_),
    .B2(_0887_),
    .X(_0163_));
 sky130_fd_sc_hd__or3_2 _1971_ (.A(_1071_),
    .B(_1088_),
    .C(_1103_),
    .X(_0888_));
 sky130_fd_sc_hd__a21bo_2 _1972_ (.A1(rx_busy_r),
    .A2(_0888_),
    .B1_N(_1105_),
    .X(_0164_));
 sky130_fd_sc_hd__o41ai_2 _1973_ (.A1(_1072_),
    .A2(_1076_),
    .A3(_1091_),
    .A4(_0485_),
    .B1(_1095_),
    .Y(_0889_));
 sky130_fd_sc_hd__a221o_2 _1974_ (.A1(_1144_),
    .A2(_0545_),
    .B1(_0744_),
    .B2(_0889_),
    .C1(packet_active_r),
    .X(_0890_));
 sky130_fd_sc_hd__o41a_2 _1975_ (.A1(_1072_),
    .A2(_1076_),
    .A3(_1091_),
    .A4(_0485_),
    .B1(_0890_),
    .X(_0165_));
 sky130_fd_sc_hd__or3_2 _1976_ (.A(\tx_wr_ptr[1] ),
    .B(\tx_wr_ptr[0] ),
    .C(_1170_),
    .X(_0891_));
 sky130_fd_sc_hd__nand3_2 _1977_ (.A(wr_en),
    .B(reset_n),
    .C(_1164_),
    .Y(_0892_));
 sky130_fd_sc_hd__or3_2 _1978_ (.A(\tx_wr_ptr[2] ),
    .B(\tx_wr_ptr[3] ),
    .C(_0892_),
    .X(_0893_));
 sky130_fd_sc_hd__or2_2 _1979_ (.A(_0891_),
    .B(_0893_),
    .X(_0894_));
 sky130_fd_sc_hd__mux2_1 _1980_ (.A0(wr_data[0]),
    .A1(\tx_fifo_mem[0][0] ),
    .S(_0894_),
    .X(_0166_));
 sky130_fd_sc_hd__mux2_1 _1981_ (.A0(wr_data[1]),
    .A1(\tx_fifo_mem[0][1] ),
    .S(_0894_),
    .X(_0167_));
 sky130_fd_sc_hd__mux2_1 _1982_ (.A0(wr_data[2]),
    .A1(\tx_fifo_mem[0][2] ),
    .S(_0894_),
    .X(_0168_));
 sky130_fd_sc_hd__mux2_1 _1983_ (.A0(wr_data[3]),
    .A1(\tx_fifo_mem[0][3] ),
    .S(_0894_),
    .X(_0169_));
 sky130_fd_sc_hd__mux2_1 _1984_ (.A0(wr_data[4]),
    .A1(\tx_fifo_mem[0][4] ),
    .S(_0894_),
    .X(_0170_));
 sky130_fd_sc_hd__mux2_1 _1985_ (.A0(wr_data[5]),
    .A1(\tx_fifo_mem[0][5] ),
    .S(_0894_),
    .X(_0171_));
 sky130_fd_sc_hd__mux2_1 _1986_ (.A0(wr_data[6]),
    .A1(\tx_fifo_mem[0][6] ),
    .S(_0894_),
    .X(_0172_));
 sky130_fd_sc_hd__mux2_1 _1987_ (.A0(wr_data[7]),
    .A1(\tx_fifo_mem[0][7] ),
    .S(_0894_),
    .X(_0173_));
 sky130_fd_sc_hd__or3b_2 _1988_ (.A(_1170_),
    .B(\tx_wr_ptr[1] ),
    .C_N(\tx_wr_ptr[0] ),
    .X(_0895_));
 sky130_fd_sc_hd__or2_2 _1989_ (.A(_0893_),
    .B(_0895_),
    .X(_0896_));
 sky130_fd_sc_hd__mux2_1 _1990_ (.A0(wr_data[0]),
    .A1(\tx_fifo_mem[1][0] ),
    .S(_0896_),
    .X(_0174_));
 sky130_fd_sc_hd__mux2_1 _1991_ (.A0(wr_data[1]),
    .A1(\tx_fifo_mem[1][1] ),
    .S(_0896_),
    .X(_0175_));
 sky130_fd_sc_hd__mux2_1 _1992_ (.A0(wr_data[2]),
    .A1(\tx_fifo_mem[1][2] ),
    .S(_0896_),
    .X(_0176_));
 sky130_fd_sc_hd__mux2_1 _1993_ (.A0(wr_data[3]),
    .A1(\tx_fifo_mem[1][3] ),
    .S(_0896_),
    .X(_0177_));
 sky130_fd_sc_hd__mux2_1 _1994_ (.A0(wr_data[4]),
    .A1(\tx_fifo_mem[1][4] ),
    .S(_0896_),
    .X(_0178_));
 sky130_fd_sc_hd__mux2_1 _1995_ (.A0(wr_data[5]),
    .A1(\tx_fifo_mem[1][5] ),
    .S(_0896_),
    .X(_0179_));
 sky130_fd_sc_hd__mux2_1 _1996_ (.A0(wr_data[6]),
    .A1(\tx_fifo_mem[1][6] ),
    .S(_0896_),
    .X(_0180_));
 sky130_fd_sc_hd__mux2_1 _1997_ (.A0(wr_data[7]),
    .A1(\tx_fifo_mem[1][7] ),
    .S(_0896_),
    .X(_0181_));
 sky130_fd_sc_hd__or3b_2 _1998_ (.A(\tx_wr_ptr[0] ),
    .B(_1170_),
    .C_N(\tx_wr_ptr[1] ),
    .X(_0897_));
 sky130_fd_sc_hd__or2_2 _1999_ (.A(_0893_),
    .B(_0897_),
    .X(_0898_));
 sky130_fd_sc_hd__mux2_1 _2000_ (.A0(wr_data[0]),
    .A1(\tx_fifo_mem[2][0] ),
    .S(_0898_),
    .X(_0182_));
 sky130_fd_sc_hd__mux2_1 _2001_ (.A0(wr_data[1]),
    .A1(\tx_fifo_mem[2][1] ),
    .S(_0898_),
    .X(_0183_));
 sky130_fd_sc_hd__mux2_1 _2002_ (.A0(wr_data[2]),
    .A1(\tx_fifo_mem[2][2] ),
    .S(_0898_),
    .X(_0184_));
 sky130_fd_sc_hd__mux2_1 _2003_ (.A0(wr_data[3]),
    .A1(\tx_fifo_mem[2][3] ),
    .S(_0898_),
    .X(_0185_));
 sky130_fd_sc_hd__mux2_1 _2004_ (.A0(wr_data[4]),
    .A1(\tx_fifo_mem[2][4] ),
    .S(_0898_),
    .X(_0186_));
 sky130_fd_sc_hd__mux2_1 _2005_ (.A0(wr_data[5]),
    .A1(\tx_fifo_mem[2][5] ),
    .S(_0898_),
    .X(_0187_));
 sky130_fd_sc_hd__mux2_1 _2006_ (.A0(wr_data[6]),
    .A1(\tx_fifo_mem[2][6] ),
    .S(_0898_),
    .X(_0188_));
 sky130_fd_sc_hd__mux2_1 _2007_ (.A0(wr_data[7]),
    .A1(\tx_fifo_mem[2][7] ),
    .S(_0898_),
    .X(_0189_));
 sky130_fd_sc_hd__nand3_2 _2008_ (.A(\tx_wr_ptr[1] ),
    .B(\tx_wr_ptr[0] ),
    .C(_1171_),
    .Y(_0899_));
 sky130_fd_sc_hd__nor2_2 _2009_ (.A(_0893_),
    .B(_0899_),
    .Y(_0900_));
 sky130_fd_sc_hd__mux2_1 _2010_ (.A0(\tx_fifo_mem[3][0] ),
    .A1(wr_data[0]),
    .S(_0900_),
    .X(_0190_));
 sky130_fd_sc_hd__mux2_1 _2011_ (.A0(\tx_fifo_mem[3][1] ),
    .A1(wr_data[1]),
    .S(_0900_),
    .X(_0191_));
 sky130_fd_sc_hd__mux2_1 _2012_ (.A0(\tx_fifo_mem[3][2] ),
    .A1(wr_data[2]),
    .S(_0900_),
    .X(_0192_));
 sky130_fd_sc_hd__mux2_1 _2013_ (.A0(\tx_fifo_mem[3][3] ),
    .A1(wr_data[3]),
    .S(_0900_),
    .X(_0193_));
 sky130_fd_sc_hd__mux2_1 _2014_ (.A0(\tx_fifo_mem[3][4] ),
    .A1(wr_data[4]),
    .S(_0900_),
    .X(_0194_));
 sky130_fd_sc_hd__mux2_1 _2015_ (.A0(\tx_fifo_mem[3][5] ),
    .A1(wr_data[5]),
    .S(_0900_),
    .X(_0195_));
 sky130_fd_sc_hd__mux2_1 _2016_ (.A0(\tx_fifo_mem[3][6] ),
    .A1(wr_data[6]),
    .S(_0900_),
    .X(_0196_));
 sky130_fd_sc_hd__mux2_1 _2017_ (.A0(\tx_fifo_mem[3][7] ),
    .A1(wr_data[7]),
    .S(_0900_),
    .X(_0197_));
 sky130_fd_sc_hd__or3b_2 _2018_ (.A(\tx_wr_ptr[3] ),
    .B(_0892_),
    .C_N(\tx_wr_ptr[2] ),
    .X(_0901_));
 sky130_fd_sc_hd__or2_2 _2019_ (.A(_0891_),
    .B(_0901_),
    .X(_0902_));
 sky130_fd_sc_hd__mux2_1 _2020_ (.A0(wr_data[0]),
    .A1(\tx_fifo_mem[4][0] ),
    .S(_0902_),
    .X(_0198_));
 sky130_fd_sc_hd__mux2_1 _2021_ (.A0(wr_data[1]),
    .A1(\tx_fifo_mem[4][1] ),
    .S(_0902_),
    .X(_0199_));
 sky130_fd_sc_hd__mux2_1 _2022_ (.A0(wr_data[2]),
    .A1(\tx_fifo_mem[4][2] ),
    .S(_0902_),
    .X(_0200_));
 sky130_fd_sc_hd__mux2_1 _2023_ (.A0(wr_data[3]),
    .A1(\tx_fifo_mem[4][3] ),
    .S(_0902_),
    .X(_0201_));
 sky130_fd_sc_hd__mux2_1 _2024_ (.A0(wr_data[4]),
    .A1(\tx_fifo_mem[4][4] ),
    .S(_0902_),
    .X(_0202_));
 sky130_fd_sc_hd__mux2_1 _2025_ (.A0(wr_data[5]),
    .A1(\tx_fifo_mem[4][5] ),
    .S(_0902_),
    .X(_0203_));
 sky130_fd_sc_hd__mux2_1 _2026_ (.A0(wr_data[6]),
    .A1(\tx_fifo_mem[4][6] ),
    .S(_0902_),
    .X(_0204_));
 sky130_fd_sc_hd__mux2_1 _2027_ (.A0(wr_data[7]),
    .A1(\tx_fifo_mem[4][7] ),
    .S(_0902_),
    .X(_0205_));
 sky130_fd_sc_hd__or2_2 _2028_ (.A(_0895_),
    .B(_0901_),
    .X(_0903_));
 sky130_fd_sc_hd__mux2_1 _2029_ (.A0(wr_data[0]),
    .A1(\tx_fifo_mem[5][0] ),
    .S(_0903_),
    .X(_0206_));
 sky130_fd_sc_hd__mux2_1 _2030_ (.A0(wr_data[1]),
    .A1(\tx_fifo_mem[5][1] ),
    .S(_0903_),
    .X(_0207_));
 sky130_fd_sc_hd__mux2_1 _2031_ (.A0(wr_data[2]),
    .A1(\tx_fifo_mem[5][2] ),
    .S(_0903_),
    .X(_0208_));
 sky130_fd_sc_hd__mux2_1 _2032_ (.A0(wr_data[3]),
    .A1(\tx_fifo_mem[5][3] ),
    .S(_0903_),
    .X(_0209_));
 sky130_fd_sc_hd__mux2_1 _2033_ (.A0(wr_data[4]),
    .A1(\tx_fifo_mem[5][4] ),
    .S(_0903_),
    .X(_0210_));
 sky130_fd_sc_hd__mux2_1 _2034_ (.A0(wr_data[5]),
    .A1(\tx_fifo_mem[5][5] ),
    .S(_0903_),
    .X(_0211_));
 sky130_fd_sc_hd__mux2_1 _2035_ (.A0(wr_data[6]),
    .A1(\tx_fifo_mem[5][6] ),
    .S(_0903_),
    .X(_0212_));
 sky130_fd_sc_hd__mux2_1 _2036_ (.A0(wr_data[7]),
    .A1(\tx_fifo_mem[5][7] ),
    .S(_0903_),
    .X(_0213_));
 sky130_fd_sc_hd__or2_2 _2037_ (.A(_0897_),
    .B(_0901_),
    .X(_0904_));
 sky130_fd_sc_hd__mux2_1 _2038_ (.A0(wr_data[0]),
    .A1(\tx_fifo_mem[6][0] ),
    .S(_0904_),
    .X(_0214_));
 sky130_fd_sc_hd__mux2_1 _2039_ (.A0(wr_data[1]),
    .A1(\tx_fifo_mem[6][1] ),
    .S(_0904_),
    .X(_0215_));
 sky130_fd_sc_hd__mux2_1 _2040_ (.A0(wr_data[2]),
    .A1(\tx_fifo_mem[6][2] ),
    .S(_0904_),
    .X(_0216_));
 sky130_fd_sc_hd__mux2_1 _2041_ (.A0(wr_data[3]),
    .A1(\tx_fifo_mem[6][3] ),
    .S(_0904_),
    .X(_0217_));
 sky130_fd_sc_hd__mux2_1 _2042_ (.A0(wr_data[4]),
    .A1(\tx_fifo_mem[6][4] ),
    .S(_0904_),
    .X(_0218_));
 sky130_fd_sc_hd__mux2_1 _2043_ (.A0(wr_data[5]),
    .A1(\tx_fifo_mem[6][5] ),
    .S(_0904_),
    .X(_0219_));
 sky130_fd_sc_hd__mux2_1 _2044_ (.A0(wr_data[6]),
    .A1(\tx_fifo_mem[6][6] ),
    .S(_0904_),
    .X(_0220_));
 sky130_fd_sc_hd__mux2_1 _2045_ (.A0(wr_data[7]),
    .A1(\tx_fifo_mem[6][7] ),
    .S(_0904_),
    .X(_0221_));
 sky130_fd_sc_hd__nor2_2 _2046_ (.A(_0899_),
    .B(_0901_),
    .Y(_0905_));
 sky130_fd_sc_hd__mux2_1 _2047_ (.A0(\tx_fifo_mem[7][0] ),
    .A1(wr_data[0]),
    .S(_0905_),
    .X(_0222_));
 sky130_fd_sc_hd__mux2_1 _2048_ (.A0(\tx_fifo_mem[7][1] ),
    .A1(wr_data[1]),
    .S(_0905_),
    .X(_0223_));
 sky130_fd_sc_hd__mux2_1 _2049_ (.A0(\tx_fifo_mem[7][2] ),
    .A1(wr_data[2]),
    .S(_0905_),
    .X(_0224_));
 sky130_fd_sc_hd__mux2_1 _2050_ (.A0(\tx_fifo_mem[7][3] ),
    .A1(wr_data[3]),
    .S(_0905_),
    .X(_0225_));
 sky130_fd_sc_hd__mux2_1 _2051_ (.A0(\tx_fifo_mem[7][4] ),
    .A1(wr_data[4]),
    .S(_0905_),
    .X(_0226_));
 sky130_fd_sc_hd__mux2_1 _2052_ (.A0(\tx_fifo_mem[7][5] ),
    .A1(wr_data[5]),
    .S(_0905_),
    .X(_0227_));
 sky130_fd_sc_hd__mux2_1 _2053_ (.A0(\tx_fifo_mem[7][6] ),
    .A1(wr_data[6]),
    .S(_0905_),
    .X(_0228_));
 sky130_fd_sc_hd__mux2_1 _2054_ (.A0(\tx_fifo_mem[7][7] ),
    .A1(wr_data[7]),
    .S(_0905_),
    .X(_0229_));
 sky130_fd_sc_hd__or3b_2 _2055_ (.A(_0892_),
    .B(\tx_wr_ptr[2] ),
    .C_N(\tx_wr_ptr[3] ),
    .X(_0906_));
 sky130_fd_sc_hd__or2_2 _2056_ (.A(_0891_),
    .B(_0906_),
    .X(_0907_));
 sky130_fd_sc_hd__mux2_1 _2057_ (.A0(wr_data[0]),
    .A1(\tx_fifo_mem[8][0] ),
    .S(_0907_),
    .X(_0230_));
 sky130_fd_sc_hd__mux2_1 _2058_ (.A0(wr_data[1]),
    .A1(\tx_fifo_mem[8][1] ),
    .S(_0907_),
    .X(_0231_));
 sky130_fd_sc_hd__mux2_1 _2059_ (.A0(wr_data[2]),
    .A1(\tx_fifo_mem[8][2] ),
    .S(_0907_),
    .X(_0232_));
 sky130_fd_sc_hd__mux2_1 _2060_ (.A0(wr_data[3]),
    .A1(\tx_fifo_mem[8][3] ),
    .S(_0907_),
    .X(_0233_));
 sky130_fd_sc_hd__mux2_1 _2061_ (.A0(wr_data[4]),
    .A1(\tx_fifo_mem[8][4] ),
    .S(_0907_),
    .X(_0234_));
 sky130_fd_sc_hd__mux2_1 _2062_ (.A0(wr_data[5]),
    .A1(\tx_fifo_mem[8][5] ),
    .S(_0907_),
    .X(_0235_));
 sky130_fd_sc_hd__mux2_1 _2063_ (.A0(wr_data[6]),
    .A1(\tx_fifo_mem[8][6] ),
    .S(_0907_),
    .X(_0236_));
 sky130_fd_sc_hd__mux2_1 _2064_ (.A0(wr_data[7]),
    .A1(\tx_fifo_mem[8][7] ),
    .S(_0907_),
    .X(_0237_));
 sky130_fd_sc_hd__or2_2 _2065_ (.A(_0895_),
    .B(_0906_),
    .X(_0908_));
 sky130_fd_sc_hd__mux2_1 _2066_ (.A0(wr_data[0]),
    .A1(\tx_fifo_mem[9][0] ),
    .S(_0908_),
    .X(_0238_));
 sky130_fd_sc_hd__mux2_1 _2067_ (.A0(wr_data[1]),
    .A1(\tx_fifo_mem[9][1] ),
    .S(_0908_),
    .X(_0239_));
 sky130_fd_sc_hd__mux2_1 _2068_ (.A0(wr_data[2]),
    .A1(\tx_fifo_mem[9][2] ),
    .S(_0908_),
    .X(_0240_));
 sky130_fd_sc_hd__mux2_1 _2069_ (.A0(wr_data[3]),
    .A1(\tx_fifo_mem[9][3] ),
    .S(_0908_),
    .X(_0241_));
 sky130_fd_sc_hd__mux2_1 _2070_ (.A0(wr_data[4]),
    .A1(\tx_fifo_mem[9][4] ),
    .S(_0908_),
    .X(_0242_));
 sky130_fd_sc_hd__mux2_1 _2071_ (.A0(wr_data[5]),
    .A1(\tx_fifo_mem[9][5] ),
    .S(_0908_),
    .X(_0243_));
 sky130_fd_sc_hd__mux2_1 _2072_ (.A0(wr_data[6]),
    .A1(\tx_fifo_mem[9][6] ),
    .S(_0908_),
    .X(_0244_));
 sky130_fd_sc_hd__mux2_1 _2073_ (.A0(wr_data[7]),
    .A1(\tx_fifo_mem[9][7] ),
    .S(_0908_),
    .X(_0245_));
 sky130_fd_sc_hd__or2_2 _2074_ (.A(_0897_),
    .B(_0906_),
    .X(_0909_));
 sky130_fd_sc_hd__mux2_1 _2075_ (.A0(wr_data[0]),
    .A1(\tx_fifo_mem[10][0] ),
    .S(_0909_),
    .X(_0246_));
 sky130_fd_sc_hd__mux2_1 _2076_ (.A0(wr_data[1]),
    .A1(\tx_fifo_mem[10][1] ),
    .S(_0909_),
    .X(_0247_));
 sky130_fd_sc_hd__mux2_1 _2077_ (.A0(wr_data[2]),
    .A1(\tx_fifo_mem[10][2] ),
    .S(_0909_),
    .X(_0248_));
 sky130_fd_sc_hd__mux2_1 _2078_ (.A0(wr_data[3]),
    .A1(\tx_fifo_mem[10][3] ),
    .S(_0909_),
    .X(_0249_));
 sky130_fd_sc_hd__mux2_1 _2079_ (.A0(wr_data[4]),
    .A1(\tx_fifo_mem[10][4] ),
    .S(_0909_),
    .X(_0250_));
 sky130_fd_sc_hd__mux2_1 _2080_ (.A0(wr_data[5]),
    .A1(\tx_fifo_mem[10][5] ),
    .S(_0909_),
    .X(_0251_));
 sky130_fd_sc_hd__mux2_1 _2081_ (.A0(wr_data[6]),
    .A1(\tx_fifo_mem[10][6] ),
    .S(_0909_),
    .X(_0252_));
 sky130_fd_sc_hd__mux2_1 _2082_ (.A0(wr_data[7]),
    .A1(\tx_fifo_mem[10][7] ),
    .S(_0909_),
    .X(_0253_));
 sky130_fd_sc_hd__nor2_2 _2083_ (.A(_0899_),
    .B(_0906_),
    .Y(_0910_));
 sky130_fd_sc_hd__mux2_1 _2084_ (.A0(\tx_fifo_mem[11][0] ),
    .A1(wr_data[0]),
    .S(_0910_),
    .X(_0254_));
 sky130_fd_sc_hd__mux2_1 _2085_ (.A0(\tx_fifo_mem[11][1] ),
    .A1(wr_data[1]),
    .S(_0910_),
    .X(_0255_));
 sky130_fd_sc_hd__mux2_1 _2086_ (.A0(\tx_fifo_mem[11][2] ),
    .A1(wr_data[2]),
    .S(_0910_),
    .X(_0256_));
 sky130_fd_sc_hd__mux2_1 _2087_ (.A0(\tx_fifo_mem[11][3] ),
    .A1(wr_data[3]),
    .S(_0910_),
    .X(_0257_));
 sky130_fd_sc_hd__mux2_1 _2088_ (.A0(\tx_fifo_mem[11][4] ),
    .A1(wr_data[4]),
    .S(_0910_),
    .X(_0258_));
 sky130_fd_sc_hd__mux2_1 _2089_ (.A0(\tx_fifo_mem[11][5] ),
    .A1(wr_data[5]),
    .S(_0910_),
    .X(_0259_));
 sky130_fd_sc_hd__mux2_1 _2090_ (.A0(\tx_fifo_mem[11][6] ),
    .A1(wr_data[6]),
    .S(_0910_),
    .X(_0260_));
 sky130_fd_sc_hd__mux2_1 _2091_ (.A0(\tx_fifo_mem[11][7] ),
    .A1(wr_data[7]),
    .S(_0910_),
    .X(_0261_));
 sky130_fd_sc_hd__nand2_2 _2092_ (.A(\tx_wr_ptr[2] ),
    .B(\tx_wr_ptr[3] ),
    .Y(_0911_));
 sky130_fd_sc_hd__or2_2 _2093_ (.A(_0892_),
    .B(_0911_),
    .X(_0912_));
 sky130_fd_sc_hd__or2_2 _2094_ (.A(_0891_),
    .B(_0912_),
    .X(_0913_));
 sky130_fd_sc_hd__mux2_1 _2095_ (.A0(wr_data[0]),
    .A1(\tx_fifo_mem[12][0] ),
    .S(_0913_),
    .X(_0262_));
 sky130_fd_sc_hd__mux2_1 _2096_ (.A0(wr_data[1]),
    .A1(\tx_fifo_mem[12][1] ),
    .S(_0913_),
    .X(_0263_));
 sky130_fd_sc_hd__mux2_1 _2097_ (.A0(wr_data[2]),
    .A1(\tx_fifo_mem[12][2] ),
    .S(_0913_),
    .X(_0264_));
 sky130_fd_sc_hd__mux2_1 _2098_ (.A0(wr_data[3]),
    .A1(\tx_fifo_mem[12][3] ),
    .S(_0913_),
    .X(_0265_));
 sky130_fd_sc_hd__mux2_1 _2099_ (.A0(wr_data[4]),
    .A1(\tx_fifo_mem[12][4] ),
    .S(_0913_),
    .X(_0266_));
 sky130_fd_sc_hd__mux2_1 _2100_ (.A0(wr_data[5]),
    .A1(\tx_fifo_mem[12][5] ),
    .S(_0913_),
    .X(_0267_));
 sky130_fd_sc_hd__mux2_1 _2101_ (.A0(wr_data[6]),
    .A1(\tx_fifo_mem[12][6] ),
    .S(_0913_),
    .X(_0268_));
 sky130_fd_sc_hd__mux2_1 _2102_ (.A0(wr_data[7]),
    .A1(\tx_fifo_mem[12][7] ),
    .S(_0913_),
    .X(_0269_));
 sky130_fd_sc_hd__or2_2 _2103_ (.A(_0895_),
    .B(_0912_),
    .X(_0914_));
 sky130_fd_sc_hd__mux2_1 _2104_ (.A0(wr_data[0]),
    .A1(\tx_fifo_mem[13][0] ),
    .S(_0914_),
    .X(_0270_));
 sky130_fd_sc_hd__mux2_1 _2105_ (.A0(wr_data[1]),
    .A1(\tx_fifo_mem[13][1] ),
    .S(_0914_),
    .X(_0271_));
 sky130_fd_sc_hd__mux2_1 _2106_ (.A0(wr_data[2]),
    .A1(\tx_fifo_mem[13][2] ),
    .S(_0914_),
    .X(_0272_));
 sky130_fd_sc_hd__mux2_1 _2107_ (.A0(wr_data[3]),
    .A1(\tx_fifo_mem[13][3] ),
    .S(_0914_),
    .X(_0273_));
 sky130_fd_sc_hd__mux2_1 _2108_ (.A0(wr_data[4]),
    .A1(\tx_fifo_mem[13][4] ),
    .S(_0914_),
    .X(_0274_));
 sky130_fd_sc_hd__mux2_1 _2109_ (.A0(wr_data[5]),
    .A1(\tx_fifo_mem[13][5] ),
    .S(_0914_),
    .X(_0275_));
 sky130_fd_sc_hd__mux2_1 _2110_ (.A0(wr_data[6]),
    .A1(\tx_fifo_mem[13][6] ),
    .S(_0914_),
    .X(_0276_));
 sky130_fd_sc_hd__mux2_1 _2111_ (.A0(wr_data[7]),
    .A1(\tx_fifo_mem[13][7] ),
    .S(_0914_),
    .X(_0277_));
 sky130_fd_sc_hd__or2_2 _2112_ (.A(_0897_),
    .B(_0912_),
    .X(_0915_));
 sky130_fd_sc_hd__mux2_1 _2113_ (.A0(wr_data[0]),
    .A1(\tx_fifo_mem[14][0] ),
    .S(_0915_),
    .X(_0278_));
 sky130_fd_sc_hd__mux2_1 _2114_ (.A0(wr_data[1]),
    .A1(\tx_fifo_mem[14][1] ),
    .S(_0915_),
    .X(_0279_));
 sky130_fd_sc_hd__mux2_1 _2115_ (.A0(wr_data[2]),
    .A1(\tx_fifo_mem[14][2] ),
    .S(_0915_),
    .X(_0280_));
 sky130_fd_sc_hd__mux2_1 _2116_ (.A0(wr_data[3]),
    .A1(\tx_fifo_mem[14][3] ),
    .S(_0915_),
    .X(_0281_));
 sky130_fd_sc_hd__mux2_1 _2117_ (.A0(wr_data[4]),
    .A1(\tx_fifo_mem[14][4] ),
    .S(_0915_),
    .X(_0282_));
 sky130_fd_sc_hd__mux2_1 _2118_ (.A0(wr_data[5]),
    .A1(\tx_fifo_mem[14][5] ),
    .S(_0915_),
    .X(_0283_));
 sky130_fd_sc_hd__mux2_1 _2119_ (.A0(wr_data[6]),
    .A1(\tx_fifo_mem[14][6] ),
    .S(_0915_),
    .X(_0284_));
 sky130_fd_sc_hd__mux2_1 _2120_ (.A0(wr_data[7]),
    .A1(\tx_fifo_mem[14][7] ),
    .S(_0915_),
    .X(_0285_));
 sky130_fd_sc_hd__nor2_2 _2121_ (.A(_0899_),
    .B(_0912_),
    .Y(_0916_));
 sky130_fd_sc_hd__mux2_1 _2122_ (.A0(\tx_fifo_mem[15][0] ),
    .A1(wr_data[0]),
    .S(_0916_),
    .X(_0286_));
 sky130_fd_sc_hd__mux2_1 _2123_ (.A0(\tx_fifo_mem[15][1] ),
    .A1(wr_data[1]),
    .S(_0916_),
    .X(_0287_));
 sky130_fd_sc_hd__mux2_1 _2124_ (.A0(\tx_fifo_mem[15][2] ),
    .A1(wr_data[2]),
    .S(_0916_),
    .X(_0288_));
 sky130_fd_sc_hd__mux2_1 _2125_ (.A0(\tx_fifo_mem[15][3] ),
    .A1(wr_data[3]),
    .S(_0916_),
    .X(_0289_));
 sky130_fd_sc_hd__mux2_1 _2126_ (.A0(\tx_fifo_mem[15][4] ),
    .A1(wr_data[4]),
    .S(_0916_),
    .X(_0290_));
 sky130_fd_sc_hd__mux2_1 _2127_ (.A0(\tx_fifo_mem[15][5] ),
    .A1(wr_data[5]),
    .S(_0916_),
    .X(_0291_));
 sky130_fd_sc_hd__mux2_1 _2128_ (.A0(\tx_fifo_mem[15][6] ),
    .A1(wr_data[6]),
    .S(_0916_),
    .X(_0292_));
 sky130_fd_sc_hd__mux2_1 _2129_ (.A0(\tx_fifo_mem[15][7] ),
    .A1(wr_data[7]),
    .S(_0916_),
    .X(_0293_));
 sky130_fd_sc_hd__or3_2 _2130_ (.A(\rx_wr_ptr[0] ),
    .B(\rx_wr_ptr[1] ),
    .C(_1082_),
    .X(_0917_));
 sky130_fd_sc_hd__or3_2 _2131_ (.A(\rx_wr_ptr[2] ),
    .B(\rx_wr_ptr[3] ),
    .C(_0917_),
    .X(_0918_));
 sky130_fd_sc_hd__nor2_2 _2132_ (.A(_0557_),
    .B(_0918_),
    .Y(_0919_));
 sky130_fd_sc_hd__o22a_2 _2133_ (.A1(_0560_),
    .A2(_0918_),
    .B1(_0919_),
    .B2(\rx_fifo_mem[0][0] ),
    .X(_0294_));
 sky130_fd_sc_hd__a21oi_2 _2134_ (.A1(\rx_shift[1] ),
    .A2(_0553_),
    .B1(_0556_),
    .Y(_0920_));
 sky130_fd_sc_hd__nor2_2 _2135_ (.A(_0918_),
    .B(_0920_),
    .Y(_0921_));
 sky130_fd_sc_hd__mux2_1 _2136_ (.A0(\rx_shift[1] ),
    .A1(\loopback_byte[1] ),
    .S(_0554_),
    .X(_0922_));
 sky130_fd_sc_hd__or2_2 _2137_ (.A(_1121_),
    .B(_0922_),
    .X(_0923_));
 sky130_fd_sc_hd__o22a_2 _2138_ (.A1(\rx_fifo_mem[0][1] ),
    .A2(_0921_),
    .B1(_0923_),
    .B2(_0918_),
    .X(_0295_));
 sky130_fd_sc_hd__a21oi_2 _2139_ (.A1(\rx_shift[2] ),
    .A2(_0553_),
    .B1(_0556_),
    .Y(_0924_));
 sky130_fd_sc_hd__nor2_2 _2140_ (.A(_0918_),
    .B(_0924_),
    .Y(_0925_));
 sky130_fd_sc_hd__a221o_2 _2141_ (.A1(\loopback_byte[2] ),
    .A2(_1113_),
    .B1(_0553_),
    .B2(\rx_shift[2] ),
    .C1(_1121_),
    .X(_0926_));
 sky130_fd_sc_hd__o22a_2 _2142_ (.A1(\rx_fifo_mem[0][2] ),
    .A2(_0925_),
    .B1(_0926_),
    .B2(_0918_),
    .X(_0296_));
 sky130_fd_sc_hd__nor2_2 _2143_ (.A(_0556_),
    .B(_0570_),
    .Y(_0927_));
 sky130_fd_sc_hd__nor2_2 _2144_ (.A(_0918_),
    .B(_0927_),
    .Y(_0928_));
 sky130_fd_sc_hd__a211o_2 _2145_ (.A1(\loopback_byte[3] ),
    .A2(_0554_),
    .B1(_0570_),
    .C1(_1121_),
    .X(_0929_));
 sky130_fd_sc_hd__o22a_2 _2146_ (.A1(\rx_fifo_mem[0][3] ),
    .A2(_0928_),
    .B1(_0929_),
    .B2(_0918_),
    .X(_0297_));
 sky130_fd_sc_hd__a21oi_2 _2147_ (.A1(\rx_shift[4] ),
    .A2(_0553_),
    .B1(_0556_),
    .Y(_0930_));
 sky130_fd_sc_hd__nor2_2 _2148_ (.A(_0918_),
    .B(_0930_),
    .Y(_0931_));
 sky130_fd_sc_hd__a221o_2 _2149_ (.A1(\loopback_byte[4] ),
    .A2(_1113_),
    .B1(_0553_),
    .B2(\rx_shift[4] ),
    .C1(_1121_),
    .X(_0932_));
 sky130_fd_sc_hd__o22a_2 _2150_ (.A1(\rx_fifo_mem[0][4] ),
    .A2(_0931_),
    .B1(_0932_),
    .B2(_0918_),
    .X(_0298_));
 sky130_fd_sc_hd__a21oi_2 _2151_ (.A1(\rx_shift[5] ),
    .A2(_0553_),
    .B1(_0556_),
    .Y(_0933_));
 sky130_fd_sc_hd__nor2_2 _2152_ (.A(_0918_),
    .B(_0933_),
    .Y(_0934_));
 sky130_fd_sc_hd__a221o_2 _2153_ (.A1(\loopback_byte[5] ),
    .A2(_1113_),
    .B1(_0553_),
    .B2(\rx_shift[5] ),
    .C1(_1121_),
    .X(_0935_));
 sky130_fd_sc_hd__o22a_2 _2154_ (.A1(\rx_fifo_mem[0][5] ),
    .A2(_0934_),
    .B1(_0935_),
    .B2(_0918_),
    .X(_0299_));
 sky130_fd_sc_hd__a21oi_2 _2155_ (.A1(\rx_shift[6] ),
    .A2(_0553_),
    .B1(_0556_),
    .Y(_0936_));
 sky130_fd_sc_hd__nor2_2 _2156_ (.A(_0918_),
    .B(_0936_),
    .Y(_0937_));
 sky130_fd_sc_hd__a221o_2 _2157_ (.A1(\loopback_byte[6] ),
    .A2(_1113_),
    .B1(_0553_),
    .B2(\rx_shift[6] ),
    .C1(_1121_),
    .X(_0938_));
 sky130_fd_sc_hd__o22a_2 _2158_ (.A1(\rx_fifo_mem[0][6] ),
    .A2(_0937_),
    .B1(_0938_),
    .B2(_0918_),
    .X(_0300_));
 sky130_fd_sc_hd__a21oi_2 _2159_ (.A1(\rx_shift[7] ),
    .A2(_0553_),
    .B1(_0556_),
    .Y(_0939_));
 sky130_fd_sc_hd__nor2_2 _2160_ (.A(_0918_),
    .B(_0939_),
    .Y(_0940_));
 sky130_fd_sc_hd__a221o_2 _2161_ (.A1(\loopback_byte[7] ),
    .A2(_1113_),
    .B1(_0553_),
    .B2(\rx_shift[7] ),
    .C1(_1121_),
    .X(_0941_));
 sky130_fd_sc_hd__o22a_2 _2162_ (.A1(\rx_fifo_mem[0][7] ),
    .A2(_0940_),
    .B1(_0941_),
    .B2(_0918_),
    .X(_0301_));
 sky130_fd_sc_hd__and3b_2 _2163_ (.A_N(\rx_wr_ptr[1] ),
    .B(reset_n),
    .C(\rx_wr_ptr[0] ),
    .X(_0942_));
 sky130_fd_sc_hd__or3b_2 _2164_ (.A(\rx_wr_ptr[2] ),
    .B(\rx_wr_ptr[3] ),
    .C_N(_0942_),
    .X(_0943_));
 sky130_fd_sc_hd__nor2_2 _2165_ (.A(_0557_),
    .B(_0943_),
    .Y(_0944_));
 sky130_fd_sc_hd__o22a_2 _2166_ (.A1(_0560_),
    .A2(_0943_),
    .B1(_0944_),
    .B2(\rx_fifo_mem[1][0] ),
    .X(_0302_));
 sky130_fd_sc_hd__nor2_2 _2167_ (.A(_0920_),
    .B(_0943_),
    .Y(_0945_));
 sky130_fd_sc_hd__o22a_2 _2168_ (.A1(_0923_),
    .A2(_0943_),
    .B1(_0945_),
    .B2(\rx_fifo_mem[1][1] ),
    .X(_0303_));
 sky130_fd_sc_hd__nor2_2 _2169_ (.A(_0924_),
    .B(_0943_),
    .Y(_0946_));
 sky130_fd_sc_hd__o22a_2 _2170_ (.A1(_0926_),
    .A2(_0943_),
    .B1(_0946_),
    .B2(\rx_fifo_mem[1][2] ),
    .X(_0304_));
 sky130_fd_sc_hd__nor2_2 _2171_ (.A(_0927_),
    .B(_0943_),
    .Y(_0947_));
 sky130_fd_sc_hd__o22a_2 _2172_ (.A1(_0929_),
    .A2(_0943_),
    .B1(_0947_),
    .B2(\rx_fifo_mem[1][3] ),
    .X(_0305_));
 sky130_fd_sc_hd__nor2_2 _2173_ (.A(_0930_),
    .B(_0943_),
    .Y(_0948_));
 sky130_fd_sc_hd__o22a_2 _2174_ (.A1(_0932_),
    .A2(_0943_),
    .B1(_0948_),
    .B2(\rx_fifo_mem[1][4] ),
    .X(_0306_));
 sky130_fd_sc_hd__nor2_2 _2175_ (.A(_0933_),
    .B(_0943_),
    .Y(_0949_));
 sky130_fd_sc_hd__o22a_2 _2176_ (.A1(_0935_),
    .A2(_0943_),
    .B1(_0949_),
    .B2(\rx_fifo_mem[1][5] ),
    .X(_0307_));
 sky130_fd_sc_hd__nor2_2 _2177_ (.A(_0936_),
    .B(_0943_),
    .Y(_0950_));
 sky130_fd_sc_hd__o22a_2 _2178_ (.A1(_0938_),
    .A2(_0943_),
    .B1(_0950_),
    .B2(\rx_fifo_mem[1][6] ),
    .X(_0308_));
 sky130_fd_sc_hd__nor2_2 _2179_ (.A(_0939_),
    .B(_0943_),
    .Y(_0951_));
 sky130_fd_sc_hd__o22a_2 _2180_ (.A1(_0941_),
    .A2(_0943_),
    .B1(_0951_),
    .B2(\rx_fifo_mem[1][7] ),
    .X(_0309_));
 sky130_fd_sc_hd__and3b_2 _2181_ (.A_N(\rx_wr_ptr[0] ),
    .B(\rx_wr_ptr[1] ),
    .C(reset_n),
    .X(_0952_));
 sky130_fd_sc_hd__or3b_2 _2182_ (.A(\rx_wr_ptr[2] ),
    .B(\rx_wr_ptr[3] ),
    .C_N(_0952_),
    .X(_0953_));
 sky130_fd_sc_hd__nor2_2 _2183_ (.A(_0557_),
    .B(_0953_),
    .Y(_0954_));
 sky130_fd_sc_hd__o22a_2 _2184_ (.A1(_0560_),
    .A2(_0953_),
    .B1(_0954_),
    .B2(\rx_fifo_mem[2][0] ),
    .X(_0310_));
 sky130_fd_sc_hd__nor2_2 _2185_ (.A(_0920_),
    .B(_0953_),
    .Y(_0955_));
 sky130_fd_sc_hd__o22a_2 _2186_ (.A1(_0923_),
    .A2(_0953_),
    .B1(_0955_),
    .B2(\rx_fifo_mem[2][1] ),
    .X(_0311_));
 sky130_fd_sc_hd__nor2_2 _2187_ (.A(_0924_),
    .B(_0953_),
    .Y(_0956_));
 sky130_fd_sc_hd__o22a_2 _2188_ (.A1(_0926_),
    .A2(_0953_),
    .B1(_0956_),
    .B2(\rx_fifo_mem[2][2] ),
    .X(_0312_));
 sky130_fd_sc_hd__nor2_2 _2189_ (.A(_0927_),
    .B(_0953_),
    .Y(_0957_));
 sky130_fd_sc_hd__o22a_2 _2190_ (.A1(_0929_),
    .A2(_0953_),
    .B1(_0957_),
    .B2(\rx_fifo_mem[2][3] ),
    .X(_0313_));
 sky130_fd_sc_hd__nor2_2 _2191_ (.A(_0930_),
    .B(_0953_),
    .Y(_0958_));
 sky130_fd_sc_hd__o22a_2 _2192_ (.A1(_0932_),
    .A2(_0953_),
    .B1(_0958_),
    .B2(\rx_fifo_mem[2][4] ),
    .X(_0314_));
 sky130_fd_sc_hd__nor2_2 _2193_ (.A(_0933_),
    .B(_0953_),
    .Y(_0959_));
 sky130_fd_sc_hd__o22a_2 _2194_ (.A1(_0935_),
    .A2(_0953_),
    .B1(_0959_),
    .B2(\rx_fifo_mem[2][5] ),
    .X(_0315_));
 sky130_fd_sc_hd__nor2_2 _2195_ (.A(_0936_),
    .B(_0953_),
    .Y(_0960_));
 sky130_fd_sc_hd__o22a_2 _2196_ (.A1(_0938_),
    .A2(_0953_),
    .B1(_0960_),
    .B2(\rx_fifo_mem[2][6] ),
    .X(_0316_));
 sky130_fd_sc_hd__nor2_2 _2197_ (.A(_0939_),
    .B(_0953_),
    .Y(_0961_));
 sky130_fd_sc_hd__o22a_2 _2198_ (.A1(_0941_),
    .A2(_0953_),
    .B1(_0961_),
    .B2(\rx_fifo_mem[2][7] ),
    .X(_0317_));
 sky130_fd_sc_hd__or3b_2 _2199_ (.A(\rx_wr_ptr[2] ),
    .B(\rx_wr_ptr[3] ),
    .C_N(_0549_),
    .X(_0962_));
 sky130_fd_sc_hd__nor2_2 _2200_ (.A(_0557_),
    .B(_0962_),
    .Y(_0963_));
 sky130_fd_sc_hd__o22a_2 _2201_ (.A1(_0560_),
    .A2(_0962_),
    .B1(_0963_),
    .B2(\rx_fifo_mem[3][0] ),
    .X(_0318_));
 sky130_fd_sc_hd__nor2_2 _2202_ (.A(_0920_),
    .B(_0962_),
    .Y(_0964_));
 sky130_fd_sc_hd__o22a_2 _2203_ (.A1(_0923_),
    .A2(_0962_),
    .B1(_0964_),
    .B2(\rx_fifo_mem[3][1] ),
    .X(_0319_));
 sky130_fd_sc_hd__nor2_2 _2204_ (.A(_0924_),
    .B(_0962_),
    .Y(_0965_));
 sky130_fd_sc_hd__o22a_2 _2205_ (.A1(_0926_),
    .A2(_0962_),
    .B1(_0965_),
    .B2(\rx_fifo_mem[3][2] ),
    .X(_0320_));
 sky130_fd_sc_hd__nor2_2 _2206_ (.A(_0927_),
    .B(_0962_),
    .Y(_0966_));
 sky130_fd_sc_hd__o22a_2 _2207_ (.A1(_0929_),
    .A2(_0962_),
    .B1(_0966_),
    .B2(\rx_fifo_mem[3][3] ),
    .X(_0321_));
 sky130_fd_sc_hd__nor2_2 _2208_ (.A(_0930_),
    .B(_0962_),
    .Y(_0967_));
 sky130_fd_sc_hd__o22a_2 _2209_ (.A1(_0932_),
    .A2(_0962_),
    .B1(_0967_),
    .B2(\rx_fifo_mem[3][4] ),
    .X(_0322_));
 sky130_fd_sc_hd__nor2_2 _2210_ (.A(_0933_),
    .B(_0962_),
    .Y(_0968_));
 sky130_fd_sc_hd__o22a_2 _2211_ (.A1(_0935_),
    .A2(_0962_),
    .B1(_0968_),
    .B2(\rx_fifo_mem[3][5] ),
    .X(_0323_));
 sky130_fd_sc_hd__nor2_2 _2212_ (.A(_0936_),
    .B(_0962_),
    .Y(_0969_));
 sky130_fd_sc_hd__o22a_2 _2213_ (.A1(_0938_),
    .A2(_0962_),
    .B1(_0969_),
    .B2(\rx_fifo_mem[3][6] ),
    .X(_0324_));
 sky130_fd_sc_hd__nor2_2 _2214_ (.A(_0939_),
    .B(_0962_),
    .Y(_0970_));
 sky130_fd_sc_hd__o22a_2 _2215_ (.A1(_0941_),
    .A2(_0962_),
    .B1(_0970_),
    .B2(\rx_fifo_mem[3][7] ),
    .X(_0325_));
 sky130_fd_sc_hd__or3b_2 _2216_ (.A(\rx_wr_ptr[3] ),
    .B(_0917_),
    .C_N(\rx_wr_ptr[2] ),
    .X(_0971_));
 sky130_fd_sc_hd__nor2_2 _2217_ (.A(_0557_),
    .B(_0971_),
    .Y(_0972_));
 sky130_fd_sc_hd__o22a_2 _2218_ (.A1(_0560_),
    .A2(_0971_),
    .B1(_0972_),
    .B2(\rx_fifo_mem[4][0] ),
    .X(_0326_));
 sky130_fd_sc_hd__nor2_2 _2219_ (.A(_0920_),
    .B(_0971_),
    .Y(_0973_));
 sky130_fd_sc_hd__o22a_2 _2220_ (.A1(_0923_),
    .A2(_0971_),
    .B1(_0973_),
    .B2(\rx_fifo_mem[4][1] ),
    .X(_0327_));
 sky130_fd_sc_hd__nor2_2 _2221_ (.A(_0924_),
    .B(_0971_),
    .Y(_0974_));
 sky130_fd_sc_hd__o22a_2 _2222_ (.A1(_0926_),
    .A2(_0971_),
    .B1(_0974_),
    .B2(\rx_fifo_mem[4][2] ),
    .X(_0328_));
 sky130_fd_sc_hd__nor2_2 _2223_ (.A(_0927_),
    .B(_0971_),
    .Y(_0975_));
 sky130_fd_sc_hd__o22a_2 _2224_ (.A1(_0929_),
    .A2(_0971_),
    .B1(_0975_),
    .B2(\rx_fifo_mem[4][3] ),
    .X(_0329_));
 sky130_fd_sc_hd__nor2_2 _2225_ (.A(_0930_),
    .B(_0971_),
    .Y(_0976_));
 sky130_fd_sc_hd__o22a_2 _2226_ (.A1(_0932_),
    .A2(_0971_),
    .B1(_0976_),
    .B2(\rx_fifo_mem[4][4] ),
    .X(_0330_));
 sky130_fd_sc_hd__nor2_2 _2227_ (.A(_0933_),
    .B(_0971_),
    .Y(_0977_));
 sky130_fd_sc_hd__o22a_2 _2228_ (.A1(_0935_),
    .A2(_0971_),
    .B1(_0977_),
    .B2(\rx_fifo_mem[4][5] ),
    .X(_0331_));
 sky130_fd_sc_hd__nor2_2 _2229_ (.A(_0936_),
    .B(_0971_),
    .Y(_0978_));
 sky130_fd_sc_hd__o22a_2 _2230_ (.A1(_0938_),
    .A2(_0971_),
    .B1(_0978_),
    .B2(\rx_fifo_mem[4][6] ),
    .X(_0332_));
 sky130_fd_sc_hd__nor2_2 _2231_ (.A(_0939_),
    .B(_0971_),
    .Y(_0979_));
 sky130_fd_sc_hd__o22a_2 _2232_ (.A1(_0941_),
    .A2(_0971_),
    .B1(_0979_),
    .B2(\rx_fifo_mem[4][7] ),
    .X(_0333_));
 sky130_fd_sc_hd__nand2_2 _2233_ (.A(_0523_),
    .B(_0942_),
    .Y(_0980_));
 sky130_fd_sc_hd__nor2_2 _2234_ (.A(_0557_),
    .B(_0980_),
    .Y(_0981_));
 sky130_fd_sc_hd__o22a_2 _2235_ (.A1(_0560_),
    .A2(_0980_),
    .B1(_0981_),
    .B2(\rx_fifo_mem[5][0] ),
    .X(_0334_));
 sky130_fd_sc_hd__nor2_2 _2236_ (.A(_0920_),
    .B(_0980_),
    .Y(_0982_));
 sky130_fd_sc_hd__o22a_2 _2237_ (.A1(_0923_),
    .A2(_0980_),
    .B1(_0982_),
    .B2(\rx_fifo_mem[5][1] ),
    .X(_0335_));
 sky130_fd_sc_hd__nor2_2 _2238_ (.A(_0924_),
    .B(_0980_),
    .Y(_0983_));
 sky130_fd_sc_hd__o22a_2 _2239_ (.A1(_0926_),
    .A2(_0980_),
    .B1(_0983_),
    .B2(\rx_fifo_mem[5][2] ),
    .X(_0336_));
 sky130_fd_sc_hd__nor2_2 _2240_ (.A(_0927_),
    .B(_0980_),
    .Y(_0984_));
 sky130_fd_sc_hd__o22a_2 _2241_ (.A1(_0929_),
    .A2(_0980_),
    .B1(_0984_),
    .B2(\rx_fifo_mem[5][3] ),
    .X(_0337_));
 sky130_fd_sc_hd__nor2_2 _2242_ (.A(_0930_),
    .B(_0980_),
    .Y(_0985_));
 sky130_fd_sc_hd__o22a_2 _2243_ (.A1(_0932_),
    .A2(_0980_),
    .B1(_0985_),
    .B2(\rx_fifo_mem[5][4] ),
    .X(_0338_));
 sky130_fd_sc_hd__nor2_2 _2244_ (.A(_0933_),
    .B(_0980_),
    .Y(_0986_));
 sky130_fd_sc_hd__o22a_2 _2245_ (.A1(_0935_),
    .A2(_0980_),
    .B1(_0986_),
    .B2(\rx_fifo_mem[5][5] ),
    .X(_0339_));
 sky130_fd_sc_hd__nor2_2 _2246_ (.A(_0936_),
    .B(_0980_),
    .Y(_0987_));
 sky130_fd_sc_hd__o22a_2 _2247_ (.A1(_0938_),
    .A2(_0980_),
    .B1(_0987_),
    .B2(\rx_fifo_mem[5][6] ),
    .X(_0340_));
 sky130_fd_sc_hd__nor2_2 _2248_ (.A(_0939_),
    .B(_0980_),
    .Y(_0988_));
 sky130_fd_sc_hd__o22a_2 _2249_ (.A1(_0941_),
    .A2(_0980_),
    .B1(_0988_),
    .B2(\rx_fifo_mem[5][7] ),
    .X(_0341_));
 sky130_fd_sc_hd__nand2_2 _2250_ (.A(_0523_),
    .B(_0952_),
    .Y(_0989_));
 sky130_fd_sc_hd__nor2_2 _2251_ (.A(_0557_),
    .B(_0989_),
    .Y(_0990_));
 sky130_fd_sc_hd__o22a_2 _2252_ (.A1(_0560_),
    .A2(_0989_),
    .B1(_0990_),
    .B2(\rx_fifo_mem[6][0] ),
    .X(_0342_));
 sky130_fd_sc_hd__nor2_2 _2253_ (.A(_0920_),
    .B(_0989_),
    .Y(_0991_));
 sky130_fd_sc_hd__o22a_2 _2254_ (.A1(_0923_),
    .A2(_0989_),
    .B1(_0991_),
    .B2(\rx_fifo_mem[6][1] ),
    .X(_0343_));
 sky130_fd_sc_hd__nor2_2 _2255_ (.A(_0924_),
    .B(_0989_),
    .Y(_0992_));
 sky130_fd_sc_hd__o22a_2 _2256_ (.A1(_0926_),
    .A2(_0989_),
    .B1(_0992_),
    .B2(\rx_fifo_mem[6][2] ),
    .X(_0344_));
 sky130_fd_sc_hd__nor2_2 _2257_ (.A(_0927_),
    .B(_0989_),
    .Y(_0993_));
 sky130_fd_sc_hd__o22a_2 _2258_ (.A1(_0929_),
    .A2(_0989_),
    .B1(_0993_),
    .B2(\rx_fifo_mem[6][3] ),
    .X(_0345_));
 sky130_fd_sc_hd__nor2_2 _2259_ (.A(_0930_),
    .B(_0989_),
    .Y(_0994_));
 sky130_fd_sc_hd__o22a_2 _2260_ (.A1(_0932_),
    .A2(_0989_),
    .B1(_0994_),
    .B2(\rx_fifo_mem[6][4] ),
    .X(_0346_));
 sky130_fd_sc_hd__nor2_2 _2261_ (.A(_0933_),
    .B(_0989_),
    .Y(_0995_));
 sky130_fd_sc_hd__o22a_2 _2262_ (.A1(_0935_),
    .A2(_0989_),
    .B1(_0995_),
    .B2(\rx_fifo_mem[6][5] ),
    .X(_0347_));
 sky130_fd_sc_hd__nor2_2 _2263_ (.A(_0936_),
    .B(_0989_),
    .Y(_0996_));
 sky130_fd_sc_hd__o22a_2 _2264_ (.A1(_0938_),
    .A2(_0989_),
    .B1(_0996_),
    .B2(\rx_fifo_mem[6][6] ),
    .X(_0348_));
 sky130_fd_sc_hd__nor2_2 _2265_ (.A(_0939_),
    .B(_0989_),
    .Y(_0997_));
 sky130_fd_sc_hd__o22a_2 _2266_ (.A1(_0941_),
    .A2(_0989_),
    .B1(_0997_),
    .B2(\rx_fifo_mem[6][7] ),
    .X(_0349_));
 sky130_fd_sc_hd__nand2_2 _2267_ (.A(_0523_),
    .B(_0549_),
    .Y(_0998_));
 sky130_fd_sc_hd__nor2_2 _2268_ (.A(_0557_),
    .B(_0998_),
    .Y(_0999_));
 sky130_fd_sc_hd__o22a_2 _2269_ (.A1(_0560_),
    .A2(_0998_),
    .B1(_0999_),
    .B2(\rx_fifo_mem[7][0] ),
    .X(_0350_));
 sky130_fd_sc_hd__nor2_2 _2270_ (.A(_0920_),
    .B(_0998_),
    .Y(_1000_));
 sky130_fd_sc_hd__o22a_2 _2271_ (.A1(_0923_),
    .A2(_0998_),
    .B1(_1000_),
    .B2(\rx_fifo_mem[7][1] ),
    .X(_0351_));
 sky130_fd_sc_hd__nor2_2 _2272_ (.A(_0924_),
    .B(_0998_),
    .Y(_1001_));
 sky130_fd_sc_hd__o22a_2 _2273_ (.A1(_0926_),
    .A2(_0998_),
    .B1(_1001_),
    .B2(\rx_fifo_mem[7][2] ),
    .X(_0352_));
 sky130_fd_sc_hd__nor2_2 _2274_ (.A(_0927_),
    .B(_0998_),
    .Y(_1002_));
 sky130_fd_sc_hd__o22a_2 _2275_ (.A1(_0929_),
    .A2(_0998_),
    .B1(_1002_),
    .B2(\rx_fifo_mem[7][3] ),
    .X(_0353_));
 sky130_fd_sc_hd__nor2_2 _2276_ (.A(_0930_),
    .B(_0998_),
    .Y(_1003_));
 sky130_fd_sc_hd__o22a_2 _2277_ (.A1(_0932_),
    .A2(_0998_),
    .B1(_1003_),
    .B2(\rx_fifo_mem[7][4] ),
    .X(_0354_));
 sky130_fd_sc_hd__nor2_2 _2278_ (.A(_0933_),
    .B(_0998_),
    .Y(_1004_));
 sky130_fd_sc_hd__o22a_2 _2279_ (.A1(_0935_),
    .A2(_0998_),
    .B1(_1004_),
    .B2(\rx_fifo_mem[7][5] ),
    .X(_0355_));
 sky130_fd_sc_hd__nor2_2 _2280_ (.A(_0936_),
    .B(_0998_),
    .Y(_1005_));
 sky130_fd_sc_hd__o22a_2 _2281_ (.A1(_0938_),
    .A2(_0998_),
    .B1(_1005_),
    .B2(\rx_fifo_mem[7][6] ),
    .X(_0356_));
 sky130_fd_sc_hd__nor2_2 _2282_ (.A(_0939_),
    .B(_0998_),
    .Y(_1006_));
 sky130_fd_sc_hd__o22a_2 _2283_ (.A1(_0941_),
    .A2(_0998_),
    .B1(_1006_),
    .B2(\rx_fifo_mem[7][7] ),
    .X(_0357_));
 sky130_fd_sc_hd__and2b_2 _2284_ (.A_N(\rx_wr_ptr[2] ),
    .B(\rx_wr_ptr[3] ),
    .X(_1007_));
 sky130_fd_sc_hd__nand2b_2 _2285_ (.A_N(_0917_),
    .B(_1007_),
    .Y(_1008_));
 sky130_fd_sc_hd__nor2_2 _2286_ (.A(_0557_),
    .B(_1008_),
    .Y(_1009_));
 sky130_fd_sc_hd__o22a_2 _2287_ (.A1(_0560_),
    .A2(_1008_),
    .B1(_1009_),
    .B2(\rx_fifo_mem[8][0] ),
    .X(_0358_));
 sky130_fd_sc_hd__nor2_2 _2288_ (.A(_0920_),
    .B(_1008_),
    .Y(_1010_));
 sky130_fd_sc_hd__o22a_2 _2289_ (.A1(_0923_),
    .A2(_1008_),
    .B1(_1010_),
    .B2(\rx_fifo_mem[8][1] ),
    .X(_0359_));
 sky130_fd_sc_hd__nor2_2 _2290_ (.A(_0924_),
    .B(_1008_),
    .Y(_1011_));
 sky130_fd_sc_hd__o22a_2 _2291_ (.A1(_0926_),
    .A2(_1008_),
    .B1(_1011_),
    .B2(\rx_fifo_mem[8][2] ),
    .X(_0360_));
 sky130_fd_sc_hd__nor2_2 _2292_ (.A(_0927_),
    .B(_1008_),
    .Y(_1012_));
 sky130_fd_sc_hd__o22a_2 _2293_ (.A1(_0929_),
    .A2(_1008_),
    .B1(_1012_),
    .B2(\rx_fifo_mem[8][3] ),
    .X(_0361_));
 sky130_fd_sc_hd__nor2_2 _2294_ (.A(_0930_),
    .B(_1008_),
    .Y(_1013_));
 sky130_fd_sc_hd__o22a_2 _2295_ (.A1(_0932_),
    .A2(_1008_),
    .B1(_1013_),
    .B2(\rx_fifo_mem[8][4] ),
    .X(_0362_));
 sky130_fd_sc_hd__nor2_2 _2296_ (.A(_0933_),
    .B(_1008_),
    .Y(_1014_));
 sky130_fd_sc_hd__o22a_2 _2297_ (.A1(_0935_),
    .A2(_1008_),
    .B1(_1014_),
    .B2(\rx_fifo_mem[8][5] ),
    .X(_0363_));
 sky130_fd_sc_hd__nor2_2 _2298_ (.A(_0936_),
    .B(_1008_),
    .Y(_1015_));
 sky130_fd_sc_hd__o22a_2 _2299_ (.A1(_0938_),
    .A2(_1008_),
    .B1(_1015_),
    .B2(\rx_fifo_mem[8][6] ),
    .X(_0364_));
 sky130_fd_sc_hd__nor2_2 _2300_ (.A(_0939_),
    .B(_1008_),
    .Y(_1016_));
 sky130_fd_sc_hd__o22a_2 _2301_ (.A1(_0941_),
    .A2(_1008_),
    .B1(_1016_),
    .B2(\rx_fifo_mem[8][7] ),
    .X(_0365_));
 sky130_fd_sc_hd__nand2_2 _2302_ (.A(_0942_),
    .B(_1007_),
    .Y(_1017_));
 sky130_fd_sc_hd__nor2_2 _2303_ (.A(_0557_),
    .B(_1017_),
    .Y(_1018_));
 sky130_fd_sc_hd__o22a_2 _2304_ (.A1(_0560_),
    .A2(_1017_),
    .B1(_1018_),
    .B2(\rx_fifo_mem[9][0] ),
    .X(_0366_));
 sky130_fd_sc_hd__nor2_2 _2305_ (.A(_0920_),
    .B(_1017_),
    .Y(_1019_));
 sky130_fd_sc_hd__o22a_2 _2306_ (.A1(_0923_),
    .A2(_1017_),
    .B1(_1019_),
    .B2(\rx_fifo_mem[9][1] ),
    .X(_0367_));
 sky130_fd_sc_hd__nor2_2 _2307_ (.A(_0924_),
    .B(_1017_),
    .Y(_1020_));
 sky130_fd_sc_hd__o22a_2 _2308_ (.A1(_0926_),
    .A2(_1017_),
    .B1(_1020_),
    .B2(\rx_fifo_mem[9][2] ),
    .X(_0368_));
 sky130_fd_sc_hd__nor2_2 _2309_ (.A(_0927_),
    .B(_1017_),
    .Y(_1021_));
 sky130_fd_sc_hd__o22a_2 _2310_ (.A1(_0929_),
    .A2(_1017_),
    .B1(_1021_),
    .B2(\rx_fifo_mem[9][3] ),
    .X(_0369_));
 sky130_fd_sc_hd__nor2_2 _2311_ (.A(_0930_),
    .B(_1017_),
    .Y(_1022_));
 sky130_fd_sc_hd__o22a_2 _2312_ (.A1(_0932_),
    .A2(_1017_),
    .B1(_1022_),
    .B2(\rx_fifo_mem[9][4] ),
    .X(_0370_));
 sky130_fd_sc_hd__nor2_2 _2313_ (.A(_0933_),
    .B(_1017_),
    .Y(_1023_));
 sky130_fd_sc_hd__o22a_2 _2314_ (.A1(_0935_),
    .A2(_1017_),
    .B1(_1023_),
    .B2(\rx_fifo_mem[9][5] ),
    .X(_0371_));
 sky130_fd_sc_hd__nor2_2 _2315_ (.A(_0936_),
    .B(_1017_),
    .Y(_1024_));
 sky130_fd_sc_hd__o22a_2 _2316_ (.A1(_0938_),
    .A2(_1017_),
    .B1(_1024_),
    .B2(\rx_fifo_mem[9][6] ),
    .X(_0372_));
 sky130_fd_sc_hd__nor2_2 _2317_ (.A(_0939_),
    .B(_1017_),
    .Y(_1025_));
 sky130_fd_sc_hd__o22a_2 _2318_ (.A1(_0941_),
    .A2(_1017_),
    .B1(_1025_),
    .B2(\rx_fifo_mem[9][7] ),
    .X(_0373_));
 sky130_fd_sc_hd__nand2_2 _2319_ (.A(_0952_),
    .B(_1007_),
    .Y(_1026_));
 sky130_fd_sc_hd__nor2_2 _2320_ (.A(_0557_),
    .B(_1026_),
    .Y(_1027_));
 sky130_fd_sc_hd__o22a_2 _2321_ (.A1(_0560_),
    .A2(_1026_),
    .B1(_1027_),
    .B2(\rx_fifo_mem[10][0] ),
    .X(_0374_));
 sky130_fd_sc_hd__nor2_2 _2322_ (.A(_0920_),
    .B(_1026_),
    .Y(_1028_));
 sky130_fd_sc_hd__o22a_2 _2323_ (.A1(_0923_),
    .A2(_1026_),
    .B1(_1028_),
    .B2(\rx_fifo_mem[10][1] ),
    .X(_0375_));
 sky130_fd_sc_hd__nor2_2 _2324_ (.A(_0924_),
    .B(_1026_),
    .Y(_1029_));
 sky130_fd_sc_hd__o22a_2 _2325_ (.A1(_0926_),
    .A2(_1026_),
    .B1(_1029_),
    .B2(\rx_fifo_mem[10][2] ),
    .X(_0376_));
 sky130_fd_sc_hd__nor2_2 _2326_ (.A(_0927_),
    .B(_1026_),
    .Y(_1030_));
 sky130_fd_sc_hd__o22a_2 _2327_ (.A1(_0929_),
    .A2(_1026_),
    .B1(_1030_),
    .B2(\rx_fifo_mem[10][3] ),
    .X(_0377_));
 sky130_fd_sc_hd__nor2_2 _2328_ (.A(_0930_),
    .B(_1026_),
    .Y(_1031_));
 sky130_fd_sc_hd__o22a_2 _2329_ (.A1(_0932_),
    .A2(_1026_),
    .B1(_1031_),
    .B2(\rx_fifo_mem[10][4] ),
    .X(_0378_));
 sky130_fd_sc_hd__nor2_2 _2330_ (.A(_0933_),
    .B(_1026_),
    .Y(_1032_));
 sky130_fd_sc_hd__o22a_2 _2331_ (.A1(_0935_),
    .A2(_1026_),
    .B1(_1032_),
    .B2(\rx_fifo_mem[10][5] ),
    .X(_0379_));
 sky130_fd_sc_hd__nor2_2 _2332_ (.A(_0936_),
    .B(_1026_),
    .Y(_1033_));
 sky130_fd_sc_hd__o22a_2 _2333_ (.A1(_0938_),
    .A2(_1026_),
    .B1(_1033_),
    .B2(\rx_fifo_mem[10][6] ),
    .X(_0380_));
 sky130_fd_sc_hd__nor2_2 _2334_ (.A(_0939_),
    .B(_1026_),
    .Y(_1034_));
 sky130_fd_sc_hd__o22a_2 _2335_ (.A1(_0941_),
    .A2(_1026_),
    .B1(_1034_),
    .B2(\rx_fifo_mem[10][7] ),
    .X(_0381_));
 sky130_fd_sc_hd__nand2_2 _2336_ (.A(_0549_),
    .B(_1007_),
    .Y(_1035_));
 sky130_fd_sc_hd__nor2_2 _2337_ (.A(_0557_),
    .B(_1035_),
    .Y(_1036_));
 sky130_fd_sc_hd__o22a_2 _2338_ (.A1(_0560_),
    .A2(_1035_),
    .B1(_1036_),
    .B2(\rx_fifo_mem[11][0] ),
    .X(_0382_));
 sky130_fd_sc_hd__nor2_2 _2339_ (.A(_0920_),
    .B(_1035_),
    .Y(_1037_));
 sky130_fd_sc_hd__o22a_2 _2340_ (.A1(_0923_),
    .A2(_1035_),
    .B1(_1037_),
    .B2(\rx_fifo_mem[11][1] ),
    .X(_0383_));
 sky130_fd_sc_hd__nor2_2 _2341_ (.A(_0924_),
    .B(_1035_),
    .Y(_1038_));
 sky130_fd_sc_hd__o22a_2 _2342_ (.A1(_0926_),
    .A2(_1035_),
    .B1(_1038_),
    .B2(\rx_fifo_mem[11][2] ),
    .X(_0384_));
 sky130_fd_sc_hd__nor2_2 _2343_ (.A(_0927_),
    .B(_1035_),
    .Y(_1039_));
 sky130_fd_sc_hd__o22a_2 _2344_ (.A1(_0929_),
    .A2(_1035_),
    .B1(_1039_),
    .B2(\rx_fifo_mem[11][3] ),
    .X(_0385_));
 sky130_fd_sc_hd__nor2_2 _2345_ (.A(_0930_),
    .B(_1035_),
    .Y(_1040_));
 sky130_fd_sc_hd__o22a_2 _2346_ (.A1(_0932_),
    .A2(_1035_),
    .B1(_1040_),
    .B2(\rx_fifo_mem[11][4] ),
    .X(_0386_));
 sky130_fd_sc_hd__nor2_2 _2347_ (.A(_0933_),
    .B(_1035_),
    .Y(_1041_));
 sky130_fd_sc_hd__o22a_2 _2348_ (.A1(_0935_),
    .A2(_1035_),
    .B1(_1041_),
    .B2(\rx_fifo_mem[11][5] ),
    .X(_0387_));
 sky130_fd_sc_hd__nor2_2 _2349_ (.A(_0936_),
    .B(_1035_),
    .Y(_1042_));
 sky130_fd_sc_hd__o22a_2 _2350_ (.A1(_0938_),
    .A2(_1035_),
    .B1(_1042_),
    .B2(\rx_fifo_mem[11][6] ),
    .X(_0388_));
 sky130_fd_sc_hd__nor2_2 _2351_ (.A(_0939_),
    .B(_1035_),
    .Y(_1043_));
 sky130_fd_sc_hd__o22a_2 _2352_ (.A1(_0941_),
    .A2(_1035_),
    .B1(_1043_),
    .B2(\rx_fifo_mem[11][7] ),
    .X(_0389_));
 sky130_fd_sc_hd__or4b_2 _2353_ (.A(\rx_wr_ptr[0] ),
    .B(\rx_wr_ptr[1] ),
    .C(_1082_),
    .D_N(_0524_),
    .X(_1044_));
 sky130_fd_sc_hd__nor2_2 _2354_ (.A(_0557_),
    .B(_1044_),
    .Y(_1045_));
 sky130_fd_sc_hd__o22a_2 _2355_ (.A1(_0560_),
    .A2(_1044_),
    .B1(_1045_),
    .B2(\rx_fifo_mem[12][0] ),
    .X(_0390_));
 sky130_fd_sc_hd__nor2_2 _2356_ (.A(_0920_),
    .B(_1044_),
    .Y(_1046_));
 sky130_fd_sc_hd__o22a_2 _2357_ (.A1(_0923_),
    .A2(_1044_),
    .B1(_1046_),
    .B2(\rx_fifo_mem[12][1] ),
    .X(_0391_));
 sky130_fd_sc_hd__nor2_2 _2358_ (.A(_0924_),
    .B(_1044_),
    .Y(_1047_));
 sky130_fd_sc_hd__o22a_2 _2359_ (.A1(_0926_),
    .A2(_1044_),
    .B1(_1047_),
    .B2(\rx_fifo_mem[12][2] ),
    .X(_0392_));
 sky130_fd_sc_hd__nor2_2 _2360_ (.A(_0927_),
    .B(_1044_),
    .Y(_1048_));
 sky130_fd_sc_hd__o22a_2 _2361_ (.A1(_0929_),
    .A2(_1044_),
    .B1(_1048_),
    .B2(\rx_fifo_mem[12][3] ),
    .X(_0393_));
 sky130_fd_sc_hd__nor2_2 _2362_ (.A(_0930_),
    .B(_1044_),
    .Y(_1049_));
 sky130_fd_sc_hd__o22a_2 _2363_ (.A1(_0932_),
    .A2(_1044_),
    .B1(_1049_),
    .B2(\rx_fifo_mem[12][4] ),
    .X(_0394_));
 sky130_fd_sc_hd__nor2_2 _2364_ (.A(_0933_),
    .B(_1044_),
    .Y(_1050_));
 sky130_fd_sc_hd__o22a_2 _2365_ (.A1(_0935_),
    .A2(_1044_),
    .B1(_1050_),
    .B2(\rx_fifo_mem[12][5] ),
    .X(_0395_));
 sky130_fd_sc_hd__nor2_2 _2366_ (.A(_0936_),
    .B(_1044_),
    .Y(_1051_));
 sky130_fd_sc_hd__o22a_2 _2367_ (.A1(_0938_),
    .A2(_1044_),
    .B1(_1051_),
    .B2(\rx_fifo_mem[12][6] ),
    .X(_0396_));
 sky130_fd_sc_hd__nor2_2 _2368_ (.A(_0939_),
    .B(_1044_),
    .Y(_1052_));
 sky130_fd_sc_hd__o22a_2 _2369_ (.A1(_0941_),
    .A2(_1044_),
    .B1(_1052_),
    .B2(\rx_fifo_mem[12][7] ),
    .X(_0397_));
 sky130_fd_sc_hd__nand2_2 _2370_ (.A(_0524_),
    .B(_0942_),
    .Y(_1053_));
 sky130_fd_sc_hd__nor2_2 _2371_ (.A(_0557_),
    .B(_1053_),
    .Y(_1054_));
 sky130_fd_sc_hd__o22a_2 _2372_ (.A1(_0560_),
    .A2(_1053_),
    .B1(_1054_),
    .B2(\rx_fifo_mem[13][0] ),
    .X(_0398_));
 sky130_fd_sc_hd__nor2_2 _2373_ (.A(_0920_),
    .B(_1053_),
    .Y(_1055_));
 sky130_fd_sc_hd__o22a_2 _2374_ (.A1(_0923_),
    .A2(_1053_),
    .B1(_1055_),
    .B2(\rx_fifo_mem[13][1] ),
    .X(_0399_));
 sky130_fd_sc_hd__nor2_2 _2375_ (.A(_0924_),
    .B(_1053_),
    .Y(_1056_));
 sky130_fd_sc_hd__o22a_2 _2376_ (.A1(_0926_),
    .A2(_1053_),
    .B1(_1056_),
    .B2(\rx_fifo_mem[13][2] ),
    .X(_0400_));
 sky130_fd_sc_hd__nor2_2 _2377_ (.A(_0927_),
    .B(_1053_),
    .Y(_1057_));
 sky130_fd_sc_hd__o22a_2 _2378_ (.A1(_0929_),
    .A2(_1053_),
    .B1(_1057_),
    .B2(\rx_fifo_mem[13][3] ),
    .X(_0401_));
 sky130_fd_sc_hd__nor2_2 _2379_ (.A(_0930_),
    .B(_1053_),
    .Y(_1058_));
 sky130_fd_sc_hd__o22a_2 _2380_ (.A1(_0932_),
    .A2(_1053_),
    .B1(_1058_),
    .B2(\rx_fifo_mem[13][4] ),
    .X(_0402_));
 sky130_fd_sc_hd__nor2_2 _2381_ (.A(_0933_),
    .B(_1053_),
    .Y(_1059_));
 sky130_fd_sc_hd__o22a_2 _2382_ (.A1(_0935_),
    .A2(_1053_),
    .B1(_1059_),
    .B2(\rx_fifo_mem[13][5] ),
    .X(_0403_));
 sky130_fd_sc_hd__nor2_2 _2383_ (.A(_0936_),
    .B(_1053_),
    .Y(_1060_));
 sky130_fd_sc_hd__o22a_2 _2384_ (.A1(_0938_),
    .A2(_1053_),
    .B1(_1060_),
    .B2(\rx_fifo_mem[13][6] ),
    .X(_0404_));
 sky130_fd_sc_hd__nor2_2 _2385_ (.A(_0939_),
    .B(_1053_),
    .Y(_1061_));
 sky130_fd_sc_hd__o22a_2 _2386_ (.A1(_0941_),
    .A2(_1053_),
    .B1(_1061_),
    .B2(\rx_fifo_mem[13][7] ),
    .X(_0405_));
 sky130_fd_sc_hd__nand2_2 _2387_ (.A(_0524_),
    .B(_0952_),
    .Y(_1062_));
 sky130_fd_sc_hd__nor2_2 _2388_ (.A(_0557_),
    .B(_1062_),
    .Y(_1063_));
 sky130_fd_sc_hd__o22a_2 _2389_ (.A1(_0560_),
    .A2(_1062_),
    .B1(_1063_),
    .B2(\rx_fifo_mem[14][0] ),
    .X(_0406_));
 sky130_fd_sc_hd__nor2_2 _2390_ (.A(_0920_),
    .B(_1062_),
    .Y(_1064_));
 sky130_fd_sc_hd__o22a_2 _2391_ (.A1(_0923_),
    .A2(_1062_),
    .B1(_1064_),
    .B2(\rx_fifo_mem[14][1] ),
    .X(_0407_));
 sky130_fd_sc_hd__nor2_2 _2392_ (.A(_0924_),
    .B(_1062_),
    .Y(_1065_));
 sky130_fd_sc_hd__o22a_2 _2393_ (.A1(_0926_),
    .A2(_1062_),
    .B1(_1065_),
    .B2(\rx_fifo_mem[14][2] ),
    .X(_0408_));
 sky130_fd_sc_hd__nor2_2 _2394_ (.A(_0927_),
    .B(_1062_),
    .Y(_1066_));
 sky130_fd_sc_hd__o22a_2 _2395_ (.A1(_0929_),
    .A2(_1062_),
    .B1(_1066_),
    .B2(\rx_fifo_mem[14][3] ),
    .X(_0409_));
 sky130_fd_sc_hd__nor2_2 _2396_ (.A(_0930_),
    .B(_1062_),
    .Y(_1067_));
 sky130_fd_sc_hd__o22a_2 _2397_ (.A1(_0932_),
    .A2(_1062_),
    .B1(_1067_),
    .B2(\rx_fifo_mem[14][4] ),
    .X(_0410_));
 sky130_fd_sc_hd__nor2_2 _2398_ (.A(_0933_),
    .B(_1062_),
    .Y(_1068_));
 sky130_fd_sc_hd__o22a_2 _2399_ (.A1(_0935_),
    .A2(_1062_),
    .B1(_1068_),
    .B2(\rx_fifo_mem[14][5] ),
    .X(_0411_));
 sky130_fd_sc_hd__nor2_2 _2400_ (.A(_0936_),
    .B(_1062_),
    .Y(_1069_));
 sky130_fd_sc_hd__o22a_2 _2401_ (.A1(_0938_),
    .A2(_1062_),
    .B1(_1069_),
    .B2(\rx_fifo_mem[14][6] ),
    .X(_0412_));
 sky130_fd_sc_hd__nor2_2 _2402_ (.A(_0939_),
    .B(_1062_),
    .Y(_1070_));
 sky130_fd_sc_hd__o22a_2 _2403_ (.A1(_0941_),
    .A2(_1062_),
    .B1(_1070_),
    .B2(\rx_fifo_mem[14][7] ),
    .X(_0413_));
 sky130_fd_sc_hd__sdfrtp_2 _2404_ (.CLK(clk),
    .D(_0063_),
    .RESET_B(reset_n),
    .SCD(scan_in[0]),
    .SCE(scan_en),
    .Q(\rx_state[2] ));
 sky130_fd_sc_hd__sdfsbp_2 _2428_ (.CLK(clk),
    .D(_0059_),
    .SET_B(reset_n),
    .Q(\tx_state[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _2406_ (.CLK(clk),
    .D(_0057_),
    .RESET_B(reset_n),
    .SCD(scan_in[1]),
    .SCE(scan_en),
    .Q(\rx_state[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _2407_ (.CLK(clk),
    .D(_0058_),
    .RESET_B(reset_n),
    .SCD(scan_in[2]),
    .SCE(scan_en),
    .Q(\rx_state[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _2408_ (.CLK(clk),
    .D(\rx_count[0] ),
    .RESET_B(reset_n),
    .SCD(scan_in[3]),
    .SCE(scan_en),
    .Q(rx_fifo_level[0]));
 sky130_fd_sc_hd__sdfrtp_2 _2409_ (.CLK(clk),
    .D(\rx_count[1] ),
    .RESET_B(reset_n),
    .SCD(\rx_state[2] ),
    .SCE(scan_en),
    .Q(rx_fifo_level[1]));
 sky130_fd_sc_hd__sdfrtp_2 _2410_ (.CLK(clk),
    .D(\rx_count[2] ),
    .RESET_B(reset_n),
    .SCD(\rx_state[1] ),
    .SCE(scan_en),
    .Q(rx_fifo_level[2]));
 sky130_fd_sc_hd__sdfrtp_2 _2411_ (.CLK(clk),
    .D(\rx_count[3] ),
    .RESET_B(reset_n),
    .SCD(\rx_state[3] ),
    .SCE(scan_en),
    .Q(rx_fifo_level[3]));
 sky130_fd_sc_hd__sdfrtp_2 _2412_ (.CLK(clk),
    .D(\rx_count[4] ),
    .RESET_B(reset_n),
    .SCD(rx_fifo_level[0]),
    .SCE(scan_en),
    .Q(rx_fifo_level[4]));
 sky130_fd_sc_hd__sdfrtp_2 _2413_ (.CLK(clk),
    .D(_0064_),
    .RESET_B(reset_n),
    .SCD(rx_fifo_level[1]),
    .SCE(scan_en),
    .Q(\irq_status_reg[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _2414_ (.CLK(clk),
    .D(_0019_),
    .RESET_B(reset_n),
    .SCD(rx_fifo_level[2]),
    .SCE(scan_en),
    .Q(\irq_status_reg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _2415_ (.CLK(clk),
    .D(_0020_),
    .RESET_B(reset_n),
    .SCD(rx_fifo_level[3]),
    .SCE(scan_en),
    .Q(\irq_status_reg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _2416_ (.CLK(clk),
    .D(_0021_),
    .RESET_B(reset_n),
    .SCD(rx_fifo_level[4]),
    .SCE(scan_en),
    .Q(\irq_status_reg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _2417_ (.CLK(clk),
    .D(_0022_),
    .RESET_B(reset_n),
    .SCD(\irq_status_reg[7] ),
    .SCE(scan_en),
    .Q(\irq_status_reg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _2418_ (.CLK(clk),
    .D(_0023_),
    .RESET_B(reset_n),
    .SCD(\irq_status_reg[0] ),
    .SCE(scan_en),
    .Q(\irq_status_reg[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _2419_ (.CLK(clk),
    .D(_0024_),
    .RESET_B(reset_n),
    .SCD(\irq_status_reg[1] ),
    .SCE(scan_en),
    .Q(\irq_status_reg[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _2420_ (.CLK(clk),
    .D(_0065_),
    .RESET_B(reset_n),
    .SCD(\irq_status_reg[2] ),
    .SCE(scan_en),
    .Q(\baud_div_reg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _2421_ (.CLK(clk),
    .D(_0066_),
    .RESET_B(reset_n),
    .SCD(\irq_status_reg[3] ),
    .SCE(scan_en),
    .Q(\baud_div_reg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _2422_ (.CLK(clk),
    .D(_0067_),
    .RESET_B(reset_n),
    .SCD(\irq_status_reg[4] ),
    .SCE(scan_en),
    .Q(\baud_div_reg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _2423_ (.CLK(clk),
    .D(_0068_),
    .RESET_B(reset_n),
    .SCD(\irq_status_reg[5] ),
    .SCE(scan_en),
    .Q(\baud_div_reg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _2424_ (.CLK(clk),
    .D(_0069_),
    .RESET_B(reset_n),
    .SCD(\baud_div_reg[0] ),
    .SCE(scan_en),
    .Q(\baud_div_reg[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _2425_ (.CLK(clk),
    .D(_0070_),
    .RESET_B(reset_n),
    .SCD(\baud_div_reg[1] ),
    .SCE(scan_en),
    .Q(\baud_div_reg[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _2426_ (.CLK(clk),
    .D(_0071_),
    .RESET_B(reset_n),
    .SCD(\baud_div_reg[2] ),
    .SCE(scan_en),
    .Q(\baud_div_reg[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _2427_ (.CLK(clk),
    .D(_0072_),
    .RESET_B(reset_n),
    .SCD(\baud_div_reg[3] ),
    .SCE(scan_en),
    .Q(\baud_div_reg[7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2432_ (.CLK(clk),
    .D(_0073_),
    .Q(\rx_fifo_mem[15][0] ));
 sky130_fd_sc_hd__sdfrtp_2 _2429_ (.CLK(clk),
    .D(_0060_),
    .RESET_B(reset_n),
    .SCD(\baud_div_reg[4] ),
    .SCE(scan_en),
    .Q(\tx_state[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _2430_ (.CLK(clk),
    .D(_0061_),
    .RESET_B(reset_n),
    .SCD(\baud_div_reg[5] ),
    .SCE(scan_en),
    .Q(\tx_state[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _2431_ (.CLK(clk),
    .D(_0062_),
    .RESET_B(reset_n),
    .SCD(\baud_div_reg[6] ),
    .SCE(scan_en),
    .Q(\tx_state[3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2433_ (.CLK(clk),
    .D(_0074_),
    .Q(\rx_fifo_mem[15][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2434_ (.CLK(clk),
    .D(_0075_),
    .Q(\rx_fifo_mem[15][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2435_ (.CLK(clk),
    .D(_0076_),
    .Q(\rx_fifo_mem[15][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2436_ (.CLK(clk),
    .D(_0077_),
    .Q(\rx_fifo_mem[15][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2437_ (.CLK(clk),
    .D(_0078_),
    .Q(\rx_fifo_mem[15][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2438_ (.CLK(clk),
    .D(_0079_),
    .Q(\rx_fifo_mem[15][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2439_ (.CLK(clk),
    .D(_0080_),
    .Q(\rx_fifo_mem[15][7] ));
 sky130_fd_sc_hd__sdfsbp_2 _2475_ (.CLK(clk),
    .D(_0094_),
    .SET_B(reset_n),
    .Q(uart_tx));
 sky130_fd_sc_hd__sdfrtp_2 _2440_ (.CLK(clk),
    .D(_0081_),
    .RESET_B(reset_n),
    .SCD(\baud_div_reg[7] ),
    .SCE(scan_en),
    .Q(enable));
 sky130_fd_sc_hd__sdfrtp_2 _2441_ (.CLK(clk),
    .D(_0082_),
    .RESET_B(reset_n),
    .SCD(\tx_state[1] ),
    .SCE(scan_en),
    .Q(rx_enable));
 sky130_fd_sc_hd__sdfrtp_2 _2442_ (.CLK(clk),
    .D(_0083_),
    .RESET_B(reset_n),
    .SCD(\tx_state[2] ),
    .SCE(scan_en),
    .Q(tx_enable));
 sky130_fd_sc_hd__sdfrtp_2 _2443_ (.CLK(clk),
    .D(_0084_),
    .RESET_B(reset_n),
    .SCD(\tx_state[3] ),
    .SCE(scan_en),
    .Q(loopback));
 sky130_fd_sc_hd__sdfrtp_2 _2444_ (.CLK(clk),
    .D(_0085_),
    .RESET_B(reset_n),
    .SCD(enable),
    .SCE(scan_en),
    .Q(irq_enable));
 sky130_fd_sc_hd__sdfrtp_2 _2445_ (.CLK(clk),
    .D(_0086_),
    .RESET_B(reset_n),
    .SCD(rx_enable),
    .SCE(scan_en),
    .Q(rd_data[0]));
 sky130_fd_sc_hd__sdfrtp_2 _2446_ (.CLK(clk),
    .D(_0087_),
    .RESET_B(reset_n),
    .SCD(tx_enable),
    .SCE(scan_en),
    .Q(rd_data[1]));
 sky130_fd_sc_hd__sdfrtp_2 _2447_ (.CLK(clk),
    .D(_0088_),
    .RESET_B(reset_n),
    .SCD(loopback),
    .SCE(scan_en),
    .Q(rd_data[2]));
 sky130_fd_sc_hd__sdfrtp_2 _2448_ (.CLK(clk),
    .D(_0089_),
    .RESET_B(reset_n),
    .SCD(irq_enable),
    .SCE(scan_en),
    .Q(rd_data[3]));
 sky130_fd_sc_hd__sdfrtp_2 _2449_ (.CLK(clk),
    .D(_0090_),
    .RESET_B(reset_n),
    .SCD(rd_data[0]),
    .SCE(scan_en),
    .Q(rd_data[4]));
 sky130_fd_sc_hd__sdfrtp_2 _2450_ (.CLK(clk),
    .D(_0091_),
    .RESET_B(reset_n),
    .SCD(rd_data[1]),
    .SCE(scan_en),
    .Q(rd_data[5]));
 sky130_fd_sc_hd__sdfrtp_2 _2451_ (.CLK(clk),
    .D(_0092_),
    .RESET_B(reset_n),
    .SCD(rd_data[2]),
    .SCE(scan_en),
    .Q(rd_data[6]));
 sky130_fd_sc_hd__sdfrtp_2 _2452_ (.CLK(clk),
    .D(_0093_),
    .RESET_B(reset_n),
    .SCD(rd_data[3]),
    .SCE(scan_en),
    .Q(rd_data[7]));
 sky130_fd_sc_hd__sdfrtp_2 _2453_ (.CLK(clk),
    .D(_0018_),
    .RESET_B(reset_n),
    .SCD(rd_data[4]),
    .SCE(scan_en),
    .Q(irq));
 sky130_fd_sc_hd__sdfrtp_2 _2454_ (.CLK(clk),
    .D(\tx_count[0] ),
    .RESET_B(reset_n),
    .SCD(rd_data[5]),
    .SCE(scan_en),
    .Q(tx_fifo_level[0]));
 sky130_fd_sc_hd__sdfrtp_2 _2455_ (.CLK(clk),
    .D(\tx_count[1] ),
    .RESET_B(reset_n),
    .SCD(rd_data[6]),
    .SCE(scan_en),
    .Q(tx_fifo_level[1]));
 sky130_fd_sc_hd__sdfrtp_2 _2456_ (.CLK(clk),
    .D(\tx_count[2] ),
    .RESET_B(reset_n),
    .SCD(rd_data[7]),
    .SCE(scan_en),
    .Q(tx_fifo_level[2]));
 sky130_fd_sc_hd__sdfrtp_2 _2457_ (.CLK(clk),
    .D(\tx_count[3] ),
    .RESET_B(reset_n),
    .SCD(irq),
    .SCE(scan_en),
    .Q(tx_fifo_level[3]));
 sky130_fd_sc_hd__sdfrtp_2 _2458_ (.CLK(clk),
    .D(\tx_count[4] ),
    .RESET_B(reset_n),
    .SCD(tx_fifo_level[0]),
    .SCE(scan_en),
    .Q(tx_fifo_level[4]));
 sky130_fd_sc_hd__sdfrtp_2 _2459_ (.CLK(clk),
    .D(_0026_),
    .RESET_B(reset_n),
    .SCD(tx_fifo_level[1]),
    .SCE(scan_en),
    .Q(packet_count[0]));
 sky130_fd_sc_hd__sdfrtp_2 _2460_ (.CLK(clk),
    .D(_0033_),
    .RESET_B(reset_n),
    .SCD(tx_fifo_level[2]),
    .SCE(scan_en),
    .Q(packet_count[1]));
 sky130_fd_sc_hd__sdfrtp_2 _2461_ (.CLK(clk),
    .D(_0034_),
    .RESET_B(reset_n),
    .SCD(tx_fifo_level[3]),
    .SCE(scan_en),
    .Q(packet_count[2]));
 sky130_fd_sc_hd__sdfrtp_2 _2462_ (.CLK(clk),
    .D(_0035_),
    .RESET_B(reset_n),
    .SCD(tx_fifo_level[4]),
    .SCE(scan_en),
    .Q(packet_count[3]));
 sky130_fd_sc_hd__sdfrtp_2 _2463_ (.CLK(clk),
    .D(_0036_),
    .RESET_B(reset_n),
    .SCD(packet_count[0]),
    .SCE(scan_en),
    .Q(packet_count[4]));
 sky130_fd_sc_hd__sdfrtp_2 _2464_ (.CLK(clk),
    .D(_0037_),
    .RESET_B(reset_n),
    .SCD(packet_count[1]),
    .SCE(scan_en),
    .Q(packet_count[5]));
 sky130_fd_sc_hd__sdfrtp_2 _2465_ (.CLK(clk),
    .D(_0038_),
    .RESET_B(reset_n),
    .SCD(packet_count[2]),
    .SCE(scan_en),
    .Q(packet_count[6]));
 sky130_fd_sc_hd__sdfrtp_2 _2466_ (.CLK(clk),
    .D(_0039_),
    .RESET_B(reset_n),
    .SCD(packet_count[3]),
    .SCE(scan_en),
    .Q(packet_count[7]));
 sky130_fd_sc_hd__sdfrtp_2 _2467_ (.CLK(clk),
    .D(_0040_),
    .RESET_B(reset_n),
    .SCD(packet_count[4]),
    .SCE(scan_en),
    .Q(packet_count[8]));
 sky130_fd_sc_hd__sdfrtp_2 _2468_ (.CLK(clk),
    .D(_0041_),
    .RESET_B(reset_n),
    .SCD(packet_count[5]),
    .SCE(scan_en),
    .Q(packet_count[9]));
 sky130_fd_sc_hd__sdfrtp_2 _2469_ (.CLK(clk),
    .D(_0027_),
    .RESET_B(reset_n),
    .SCD(packet_count[6]),
    .SCE(scan_en),
    .Q(packet_count[10]));
 sky130_fd_sc_hd__sdfrtp_2 _2470_ (.CLK(clk),
    .D(_0028_),
    .RESET_B(reset_n),
    .SCD(packet_count[7]),
    .SCE(scan_en),
    .Q(packet_count[11]));
 sky130_fd_sc_hd__sdfrtp_2 _2471_ (.CLK(clk),
    .D(_0029_),
    .RESET_B(reset_n),
    .SCD(packet_count[8]),
    .SCE(scan_en),
    .Q(packet_count[12]));
 sky130_fd_sc_hd__sdfrtp_2 _2472_ (.CLK(clk),
    .D(_0030_),
    .RESET_B(reset_n),
    .SCD(packet_count[9]),
    .SCE(scan_en),
    .Q(packet_count[13]));
 sky130_fd_sc_hd__sdfrtp_2 _2473_ (.CLK(clk),
    .D(_0031_),
    .RESET_B(reset_n),
    .SCD(packet_count[10]),
    .SCE(scan_en),
    .Q(packet_count[14]));
 sky130_fd_sc_hd__sdfrtp_2 _2474_ (.CLK(clk),
    .D(_0032_),
    .RESET_B(reset_n),
    .SCD(packet_count[11]),
    .SCE(scan_en),
    .Q(packet_count[15]));
 sky130_fd_sc_hd__sdfxtp_2 _2580_ (.CLK(clk),
    .D(_0166_),
    .Q(\tx_fifo_mem[0][0] ));
 sky130_fd_sc_hd__sdfrtp_2 _2476_ (.CLK(clk),
    .D(_0095_),
    .RESET_B(reset_n),
    .SCD(packet_count[12]),
    .SCE(scan_en),
    .Q(\baud_div_reg[8] ));
 sky130_fd_sc_hd__sdfrtp_2 _2477_ (.CLK(clk),
    .D(_0096_),
    .RESET_B(reset_n),
    .SCD(packet_count[13]),
    .SCE(scan_en),
    .Q(\baud_div_reg[9] ));
 sky130_fd_sc_hd__sdfrtp_2 _2478_ (.CLK(clk),
    .D(_0097_),
    .RESET_B(reset_n),
    .SCD(packet_count[14]),
    .SCE(scan_en),
    .Q(\baud_div_reg[10] ));
 sky130_fd_sc_hd__sdfrtp_2 _2479_ (.CLK(clk),
    .D(_0098_),
    .RESET_B(reset_n),
    .SCD(packet_count[15]),
    .SCE(scan_en),
    .Q(\baud_div_reg[11] ));
 sky130_fd_sc_hd__sdfrtp_2 _2480_ (.CLK(clk),
    .D(_0099_),
    .RESET_B(reset_n),
    .SCD(\baud_div_reg[8] ),
    .SCE(scan_en),
    .Q(\baud_div_reg[12] ));
 sky130_fd_sc_hd__sdfrtp_2 _2481_ (.CLK(clk),
    .D(_0100_),
    .RESET_B(reset_n),
    .SCD(\baud_div_reg[9] ),
    .SCE(scan_en),
    .Q(\baud_div_reg[13] ));
 sky130_fd_sc_hd__sdfrtp_2 _2482_ (.CLK(clk),
    .D(_0101_),
    .RESET_B(reset_n),
    .SCD(\baud_div_reg[10] ),
    .SCE(scan_en),
    .Q(\baud_div_reg[14] ));
 sky130_fd_sc_hd__sdfrtp_2 _2483_ (.CLK(clk),
    .D(_0102_),
    .RESET_B(reset_n),
    .SCD(\baud_div_reg[11] ),
    .SCE(scan_en),
    .Q(\baud_div_reg[15] ));
 sky130_fd_sc_hd__sdfrtp_2 _2484_ (.CLK(clk),
    .D(_0103_),
    .RESET_B(reset_n),
    .SCD(\baud_div_reg[12] ),
    .SCE(scan_en),
    .Q(\packet_len_reg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _2485_ (.CLK(clk),
    .D(_0104_),
    .RESET_B(reset_n),
    .SCD(\baud_div_reg[13] ),
    .SCE(scan_en),
    .Q(\packet_len_reg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _2486_ (.CLK(clk),
    .D(_0105_),
    .RESET_B(reset_n),
    .SCD(\baud_div_reg[14] ),
    .SCE(scan_en),
    .Q(\packet_len_reg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _2487_ (.CLK(clk),
    .D(_0106_),
    .RESET_B(reset_n),
    .SCD(\baud_div_reg[15] ),
    .SCE(scan_en),
    .Q(\packet_len_reg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _2488_ (.CLK(clk),
    .D(_0107_),
    .RESET_B(reset_n),
    .SCD(\packet_len_reg[0] ),
    .SCE(scan_en),
    .Q(\packet_len_reg[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _2489_ (.CLK(clk),
    .D(_0108_),
    .RESET_B(reset_n),
    .SCD(\packet_len_reg[1] ),
    .SCE(scan_en),
    .Q(\packet_len_reg[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _2490_ (.CLK(clk),
    .D(_0109_),
    .RESET_B(reset_n),
    .SCD(\packet_len_reg[2] ),
    .SCE(scan_en),
    .Q(\packet_len_reg[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _2491_ (.CLK(clk),
    .D(_0110_),
    .RESET_B(reset_n),
    .SCD(\packet_len_reg[3] ),
    .SCE(scan_en),
    .Q(\packet_len_reg[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _2492_ (.CLK(clk),
    .D(_0111_),
    .RESET_B(reset_n),
    .SCD(\packet_len_reg[4] ),
    .SCE(scan_en),
    .Q(\tx_wr_ptr[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _2493_ (.CLK(clk),
    .D(_0112_),
    .RESET_B(reset_n),
    .SCD(\packet_len_reg[5] ),
    .SCE(scan_en),
    .Q(\tx_wr_ptr[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _2494_ (.CLK(clk),
    .D(_0113_),
    .RESET_B(reset_n),
    .SCD(\packet_len_reg[6] ),
    .SCE(scan_en),
    .Q(\tx_wr_ptr[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _2495_ (.CLK(clk),
    .D(_0114_),
    .RESET_B(reset_n),
    .SCD(\packet_len_reg[7] ),
    .SCE(scan_en),
    .Q(\tx_wr_ptr[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _2496_ (.CLK(clk),
    .D(_0047_),
    .RESET_B(reset_n),
    .SCD(\tx_wr_ptr[0] ),
    .SCE(scan_en),
    .Q(\rx_wr_ptr[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _2497_ (.CLK(clk),
    .D(_0048_),
    .RESET_B(reset_n),
    .SCD(\tx_wr_ptr[1] ),
    .SCE(scan_en),
    .Q(\rx_wr_ptr[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _2498_ (.CLK(clk),
    .D(_0049_),
    .RESET_B(reset_n),
    .SCD(\tx_wr_ptr[2] ),
    .SCE(scan_en),
    .Q(\rx_wr_ptr[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _2499_ (.CLK(clk),
    .D(_0050_),
    .RESET_B(reset_n),
    .SCD(\tx_wr_ptr[3] ),
    .SCE(scan_en),
    .Q(\rx_wr_ptr[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _2500_ (.CLK(clk),
    .D(_0115_),
    .RESET_B(reset_n),
    .SCD(\rx_wr_ptr[0] ),
    .SCE(scan_en),
    .Q(\tx_rd_ptr[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _2501_ (.CLK(clk),
    .D(_0116_),
    .RESET_B(reset_n),
    .SCD(\rx_wr_ptr[1] ),
    .SCE(scan_en),
    .Q(\tx_rd_ptr[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _2502_ (.CLK(clk),
    .D(_0117_),
    .RESET_B(reset_n),
    .SCD(\rx_wr_ptr[2] ),
    .SCE(scan_en),
    .Q(\tx_rd_ptr[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _2503_ (.CLK(clk),
    .D(_0118_),
    .RESET_B(reset_n),
    .SCD(\rx_wr_ptr[3] ),
    .SCE(scan_en),
    .Q(\tx_rd_ptr[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _2504_ (.CLK(clk),
    .D(_0051_),
    .RESET_B(reset_n),
    .SCD(\tx_rd_ptr[0] ),
    .SCE(scan_en),
    .Q(\tx_count[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _2505_ (.CLK(clk),
    .D(_0052_),
    .RESET_B(reset_n),
    .SCD(\tx_rd_ptr[1] ),
    .SCE(scan_en),
    .Q(\tx_count[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _2506_ (.CLK(clk),
    .D(_0053_),
    .RESET_B(reset_n),
    .SCD(\tx_rd_ptr[2] ),
    .SCE(scan_en),
    .Q(\tx_count[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _2507_ (.CLK(clk),
    .D(_0054_),
    .RESET_B(reset_n),
    .SCD(\tx_rd_ptr[3] ),
    .SCE(scan_en),
    .Q(\tx_count[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _2508_ (.CLK(clk),
    .D(_0055_),
    .RESET_B(reset_n),
    .SCD(\tx_count[0] ),
    .SCE(scan_en),
    .Q(\tx_count[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _2509_ (.CLK(clk),
    .D(_0042_),
    .RESET_B(reset_n),
    .SCD(\tx_count[1] ),
    .SCE(scan_en),
    .Q(\rx_count[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _2510_ (.CLK(clk),
    .D(_0043_),
    .RESET_B(reset_n),
    .SCD(\tx_count[2] ),
    .SCE(scan_en),
    .Q(\rx_count[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _2511_ (.CLK(clk),
    .D(_0044_),
    .RESET_B(reset_n),
    .SCD(\tx_count[3] ),
    .SCE(scan_en),
    .Q(\rx_count[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _2512_ (.CLK(clk),
    .D(_0045_),
    .RESET_B(reset_n),
    .SCD(\tx_count[4] ),
    .SCE(scan_en),
    .Q(\rx_count[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _2513_ (.CLK(clk),
    .D(_0046_),
    .RESET_B(reset_n),
    .SCD(\rx_count[0] ),
    .SCE(scan_en),
    .Q(\rx_count[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _2514_ (.CLK(clk),
    .D(_0000_),
    .RESET_B(reset_n),
    .SCD(\rx_count[1] ),
    .SCE(scan_en),
    .Q(\baud_cnt[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _2515_ (.CLK(clk),
    .D(_0007_),
    .RESET_B(reset_n),
    .SCD(\rx_count[2] ),
    .SCE(scan_en),
    .Q(\baud_cnt[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _2516_ (.CLK(clk),
    .D(_0008_),
    .RESET_B(reset_n),
    .SCD(\rx_count[3] ),
    .SCE(scan_en),
    .Q(\baud_cnt[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _2517_ (.CLK(clk),
    .D(_0009_),
    .RESET_B(reset_n),
    .SCD(\rx_count[4] ),
    .SCE(scan_en),
    .Q(\baud_cnt[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _2518_ (.CLK(clk),
    .D(_0010_),
    .RESET_B(reset_n),
    .SCD(\baud_cnt[0] ),
    .SCE(scan_en),
    .Q(\baud_cnt[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _2519_ (.CLK(clk),
    .D(_0011_),
    .RESET_B(reset_n),
    .SCD(\baud_cnt[1] ),
    .SCE(scan_en),
    .Q(\baud_cnt[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _2520_ (.CLK(clk),
    .D(_0012_),
    .RESET_B(reset_n),
    .SCD(\baud_cnt[2] ),
    .SCE(scan_en),
    .Q(\baud_cnt[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _2521_ (.CLK(clk),
    .D(_0013_),
    .RESET_B(reset_n),
    .SCD(\baud_cnt[3] ),
    .SCE(scan_en),
    .Q(\baud_cnt[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _2522_ (.CLK(clk),
    .D(_0014_),
    .RESET_B(reset_n),
    .SCD(\baud_cnt[4] ),
    .SCE(scan_en),
    .Q(\baud_cnt[8] ));
 sky130_fd_sc_hd__sdfrtp_2 _2523_ (.CLK(clk),
    .D(_0015_),
    .RESET_B(reset_n),
    .SCD(\baud_cnt[5] ),
    .SCE(scan_en),
    .Q(\baud_cnt[9] ));
 sky130_fd_sc_hd__sdfrtp_2 _2524_ (.CLK(clk),
    .D(_0001_),
    .RESET_B(reset_n),
    .SCD(\baud_cnt[6] ),
    .SCE(scan_en),
    .Q(\baud_cnt[10] ));
 sky130_fd_sc_hd__sdfrtp_2 _2525_ (.CLK(clk),
    .D(_0002_),
    .RESET_B(reset_n),
    .SCD(\baud_cnt[7] ),
    .SCE(scan_en),
    .Q(\baud_cnt[11] ));
 sky130_fd_sc_hd__sdfrtp_2 _2526_ (.CLK(clk),
    .D(_0003_),
    .RESET_B(reset_n),
    .SCD(\baud_cnt[8] ),
    .SCE(scan_en),
    .Q(\baud_cnt[12] ));
 sky130_fd_sc_hd__sdfrtp_2 _2527_ (.CLK(clk),
    .D(_0004_),
    .RESET_B(reset_n),
    .SCD(\baud_cnt[9] ),
    .SCE(scan_en),
    .Q(\baud_cnt[13] ));
 sky130_fd_sc_hd__sdfrtp_2 _2528_ (.CLK(clk),
    .D(_0005_),
    .RESET_B(reset_n),
    .SCD(\baud_cnt[10] ),
    .SCE(scan_en),
    .Q(\baud_cnt[14] ));
 sky130_fd_sc_hd__sdfrtp_2 _2529_ (.CLK(clk),
    .D(_0006_),
    .RESET_B(reset_n),
    .SCD(\baud_cnt[11] ),
    .SCE(scan_en),
    .Q(\baud_cnt[15] ));
 sky130_fd_sc_hd__sdfrtp_2 _2530_ (.CLK(clk),
    .D(_0016_),
    .RESET_B(reset_n),
    .SCD(\baud_cnt[12] ),
    .SCE(scan_en),
    .Q(baud_tick));
 sky130_fd_sc_hd__sdfrtp_2 _2531_ (.CLK(clk),
    .D(_0119_),
    .RESET_B(reset_n),
    .SCD(\baud_cnt[13] ),
    .SCE(scan_en),
    .Q(\rx_rd_ptr[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _2532_ (.CLK(clk),
    .D(_0120_),
    .RESET_B(reset_n),
    .SCD(\baud_cnt[14] ),
    .SCE(scan_en),
    .Q(\rx_rd_ptr[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _2533_ (.CLK(clk),
    .D(_0121_),
    .RESET_B(reset_n),
    .SCD(\baud_cnt[15] ),
    .SCE(scan_en),
    .Q(\rx_rd_ptr[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _2534_ (.CLK(clk),
    .D(_0122_),
    .RESET_B(reset_n),
    .SCD(baud_tick),
    .SCE(scan_en),
    .Q(\rx_rd_ptr[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _2535_ (.CLK(clk),
    .D(_0123_),
    .RESET_B(reset_n),
    .SCD(\rx_rd_ptr[0] ),
    .SCE(scan_en),
    .Q(\tx_bit_cnt[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _2536_ (.CLK(clk),
    .D(_0124_),
    .RESET_B(reset_n),
    .SCD(\rx_rd_ptr[1] ),
    .SCE(scan_en),
    .Q(\tx_bit_cnt[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _2537_ (.CLK(clk),
    .D(_0125_),
    .RESET_B(reset_n),
    .SCD(\rx_rd_ptr[2] ),
    .SCE(scan_en),
    .Q(\tx_bit_cnt[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _2538_ (.CLK(clk),
    .D(_0126_),
    .RESET_B(reset_n),
    .SCD(\rx_rd_ptr[3] ),
    .SCE(scan_en),
    .Q(\tx_bit_cnt[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _2539_ (.CLK(clk),
    .D(_0127_),
    .RESET_B(reset_n),
    .SCD(\tx_bit_cnt[0] ),
    .SCE(scan_en),
    .Q(\rx_bit_cnt[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _2540_ (.CLK(clk),
    .D(_0128_),
    .RESET_B(reset_n),
    .SCD(\tx_bit_cnt[1] ),
    .SCE(scan_en),
    .Q(\rx_bit_cnt[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _2541_ (.CLK(clk),
    .D(_0129_),
    .RESET_B(reset_n),
    .SCD(\tx_bit_cnt[2] ),
    .SCE(scan_en),
    .Q(\rx_bit_cnt[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _2542_ (.CLK(clk),
    .D(_0130_),
    .RESET_B(reset_n),
    .SCD(\tx_bit_cnt[3] ),
    .SCE(scan_en),
    .Q(\rx_bit_cnt[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _2543_ (.CLK(clk),
    .D(_0131_),
    .RESET_B(reset_n),
    .SCD(\rx_bit_cnt[0] ),
    .SCE(scan_en),
    .Q(\tx_shift[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _2544_ (.CLK(clk),
    .D(_0132_),
    .RESET_B(reset_n),
    .SCD(\rx_bit_cnt[1] ),
    .SCE(scan_en),
    .Q(\tx_shift[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _2545_ (.CLK(clk),
    .D(_0133_),
    .RESET_B(reset_n),
    .SCD(\rx_bit_cnt[2] ),
    .SCE(scan_en),
    .Q(\tx_shift[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _2546_ (.CLK(clk),
    .D(_0134_),
    .RESET_B(reset_n),
    .SCD(\rx_bit_cnt[3] ),
    .SCE(scan_en),
    .Q(\tx_shift[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _2547_ (.CLK(clk),
    .D(_0135_),
    .RESET_B(reset_n),
    .SCD(\tx_shift[0] ),
    .SCE(scan_en),
    .Q(\tx_shift[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _2548_ (.CLK(clk),
    .D(_0136_),
    .RESET_B(reset_n),
    .SCD(\tx_shift[1] ),
    .SCE(scan_en),
    .Q(\tx_shift[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _2549_ (.CLK(clk),
    .D(_0137_),
    .RESET_B(reset_n),
    .SCD(\tx_shift[2] ),
    .SCE(scan_en),
    .Q(\tx_shift[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _2550_ (.CLK(clk),
    .D(_0138_),
    .RESET_B(reset_n),
    .SCD(\tx_shift[3] ),
    .SCE(scan_en),
    .Q(\tx_shift[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _2551_ (.CLK(clk),
    .D(_0139_),
    .RESET_B(reset_n),
    .SCD(\tx_shift[4] ),
    .SCE(scan_en),
    .Q(\rx_shift[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _2552_ (.CLK(clk),
    .D(_0140_),
    .RESET_B(reset_n),
    .SCD(\tx_shift[5] ),
    .SCE(scan_en),
    .Q(\rx_shift[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _2553_ (.CLK(clk),
    .D(_0141_),
    .RESET_B(reset_n),
    .SCD(\tx_shift[6] ),
    .SCE(scan_en),
    .Q(\rx_shift[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _2554_ (.CLK(clk),
    .D(_0142_),
    .RESET_B(reset_n),
    .SCD(\tx_shift[7] ),
    .SCE(scan_en),
    .Q(\rx_shift[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _2555_ (.CLK(clk),
    .D(_0143_),
    .RESET_B(reset_n),
    .SCD(\rx_shift[0] ),
    .SCE(scan_en),
    .Q(\rx_shift[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _2556_ (.CLK(clk),
    .D(_0144_),
    .RESET_B(reset_n),
    .SCD(\rx_shift[1] ),
    .SCE(scan_en),
    .Q(\rx_shift[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _2557_ (.CLK(clk),
    .D(_0145_),
    .RESET_B(reset_n),
    .SCD(\rx_shift[2] ),
    .SCE(scan_en),
    .Q(\rx_shift[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _2558_ (.CLK(clk),
    .D(_0146_),
    .RESET_B(reset_n),
    .SCD(\rx_shift[3] ),
    .SCE(scan_en),
    .Q(\rx_shift[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _2559_ (.CLK(clk),
    .D(_0147_),
    .RESET_B(reset_n),
    .SCD(\rx_shift[4] ),
    .SCE(scan_en),
    .Q(\tx_hold_byte[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _2560_ (.CLK(clk),
    .D(_0148_),
    .RESET_B(reset_n),
    .SCD(\rx_shift[5] ),
    .SCE(scan_en),
    .Q(\tx_hold_byte[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _2561_ (.CLK(clk),
    .D(_0149_),
    .RESET_B(reset_n),
    .SCD(\rx_shift[6] ),
    .SCE(scan_en),
    .Q(\tx_hold_byte[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _2562_ (.CLK(clk),
    .D(_0150_),
    .RESET_B(reset_n),
    .SCD(\rx_shift[7] ),
    .SCE(scan_en),
    .Q(\tx_hold_byte[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _2563_ (.CLK(clk),
    .D(_0151_),
    .RESET_B(reset_n),
    .SCD(\tx_hold_byte[0] ),
    .SCE(scan_en),
    .Q(\tx_hold_byte[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _2564_ (.CLK(clk),
    .D(_0152_),
    .RESET_B(reset_n),
    .SCD(\tx_hold_byte[1] ),
    .SCE(scan_en),
    .Q(\tx_hold_byte[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _2565_ (.CLK(clk),
    .D(_0153_),
    .RESET_B(reset_n),
    .SCD(\tx_hold_byte[2] ),
    .SCE(scan_en),
    .Q(\tx_hold_byte[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _2566_ (.CLK(clk),
    .D(_0154_),
    .RESET_B(reset_n),
    .SCD(\tx_hold_byte[3] ),
    .SCE(scan_en),
    .Q(\tx_hold_byte[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _2567_ (.CLK(clk),
    .D(_0025_),
    .RESET_B(reset_n),
    .SCD(\tx_hold_byte[4] ),
    .SCE(scan_en),
    .Q(loopback_valid));
 sky130_fd_sc_hd__sdfrtp_2 _2568_ (.CLK(clk),
    .D(_0155_),
    .RESET_B(reset_n),
    .SCD(\tx_hold_byte[5] ),
    .SCE(scan_en),
    .Q(\loopback_byte[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _2569_ (.CLK(clk),
    .D(_0156_),
    .RESET_B(reset_n),
    .SCD(\tx_hold_byte[6] ),
    .SCE(scan_en),
    .Q(\loopback_byte[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _2570_ (.CLK(clk),
    .D(_0157_),
    .RESET_B(reset_n),
    .SCD(\tx_hold_byte[7] ),
    .SCE(scan_en),
    .Q(\loopback_byte[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _2571_ (.CLK(clk),
    .D(_0158_),
    .RESET_B(reset_n),
    .SCD(loopback_valid),
    .SCE(scan_en),
    .Q(\loopback_byte[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _2572_ (.CLK(clk),
    .D(_0159_),
    .RESET_B(reset_n),
    .SCD(\loopback_byte[0] ),
    .SCE(scan_en),
    .Q(\loopback_byte[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _2573_ (.CLK(clk),
    .D(_0160_),
    .RESET_B(reset_n),
    .SCD(\loopback_byte[1] ),
    .SCE(scan_en),
    .Q(\loopback_byte[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _2574_ (.CLK(clk),
    .D(_0161_),
    .RESET_B(reset_n),
    .SCD(\loopback_byte[2] ),
    .SCE(scan_en),
    .Q(\loopback_byte[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _2575_ (.CLK(clk),
    .D(_0162_),
    .RESET_B(reset_n),
    .SCD(\loopback_byte[3] ),
    .SCE(scan_en),
    .Q(\loopback_byte[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _2576_ (.CLK(clk),
    .D(_0163_),
    .RESET_B(reset_n),
    .SCD(\loopback_byte[4] ),
    .SCE(scan_en),
    .Q(tx_busy_r));
 sky130_fd_sc_hd__sdfrtp_2 _2577_ (.CLK(clk),
    .D(_0164_),
    .RESET_B(reset_n),
    .SCD(\loopback_byte[5] ),
    .SCE(scan_en),
    .Q(rx_busy_r));
 sky130_fd_sc_hd__sdfrtp_2 _2578_ (.CLK(clk),
    .D(_0017_),
    .RESET_B(reset_n),
    .SCD(\loopback_byte[6] ),
    .SCE(scan_en),
    .Q(error_r));
 sky130_fd_sc_hd__sdfrtp_2 _2579_ (.CLK(clk),
    .D(_0165_),
    .RESET_B(reset_n),
    .SCD(\loopback_byte[7] ),
    .SCE(scan_en),
    .Q(packet_active_r));
 sky130_fd_sc_hd__sdfxtp_2 _2581_ (.CLK(clk),
    .D(_0167_),
    .Q(\tx_fifo_mem[0][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2582_ (.CLK(clk),
    .D(_0168_),
    .Q(\tx_fifo_mem[0][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2583_ (.CLK(clk),
    .D(_0169_),
    .Q(\tx_fifo_mem[0][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2584_ (.CLK(clk),
    .D(_0170_),
    .Q(\tx_fifo_mem[0][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2585_ (.CLK(clk),
    .D(_0171_),
    .Q(\tx_fifo_mem[0][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2586_ (.CLK(clk),
    .D(_0172_),
    .Q(\tx_fifo_mem[0][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2587_ (.CLK(clk),
    .D(_0173_),
    .Q(\tx_fifo_mem[0][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2588_ (.CLK(clk),
    .D(_0174_),
    .Q(\tx_fifo_mem[1][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2589_ (.CLK(clk),
    .D(_0175_),
    .Q(\tx_fifo_mem[1][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2590_ (.CLK(clk),
    .D(_0176_),
    .Q(\tx_fifo_mem[1][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2591_ (.CLK(clk),
    .D(_0177_),
    .Q(\tx_fifo_mem[1][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2592_ (.CLK(clk),
    .D(_0178_),
    .Q(\tx_fifo_mem[1][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2593_ (.CLK(clk),
    .D(_0179_),
    .Q(\tx_fifo_mem[1][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2594_ (.CLK(clk),
    .D(_0180_),
    .Q(\tx_fifo_mem[1][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2595_ (.CLK(clk),
    .D(_0181_),
    .Q(\tx_fifo_mem[1][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2596_ (.CLK(clk),
    .D(_0182_),
    .Q(\tx_fifo_mem[2][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2597_ (.CLK(clk),
    .D(_0183_),
    .Q(\tx_fifo_mem[2][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2598_ (.CLK(clk),
    .D(_0184_),
    .Q(\tx_fifo_mem[2][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2599_ (.CLK(clk),
    .D(_0185_),
    .Q(\tx_fifo_mem[2][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2600_ (.CLK(clk),
    .D(_0186_),
    .Q(\tx_fifo_mem[2][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2601_ (.CLK(clk),
    .D(_0187_),
    .Q(\tx_fifo_mem[2][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2602_ (.CLK(clk),
    .D(_0188_),
    .Q(\tx_fifo_mem[2][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2603_ (.CLK(clk),
    .D(_0189_),
    .Q(\tx_fifo_mem[2][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2604_ (.CLK(clk),
    .D(_0190_),
    .Q(\tx_fifo_mem[3][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2605_ (.CLK(clk),
    .D(_0191_),
    .Q(\tx_fifo_mem[3][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2606_ (.CLK(clk),
    .D(_0192_),
    .Q(\tx_fifo_mem[3][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2607_ (.CLK(clk),
    .D(_0193_),
    .Q(\tx_fifo_mem[3][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2608_ (.CLK(clk),
    .D(_0194_),
    .Q(\tx_fifo_mem[3][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2609_ (.CLK(clk),
    .D(_0195_),
    .Q(\tx_fifo_mem[3][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2610_ (.CLK(clk),
    .D(_0196_),
    .Q(\tx_fifo_mem[3][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2611_ (.CLK(clk),
    .D(_0197_),
    .Q(\tx_fifo_mem[3][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2612_ (.CLK(clk),
    .D(_0198_),
    .Q(\tx_fifo_mem[4][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2613_ (.CLK(clk),
    .D(_0199_),
    .Q(\tx_fifo_mem[4][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2614_ (.CLK(clk),
    .D(_0200_),
    .Q(\tx_fifo_mem[4][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2615_ (.CLK(clk),
    .D(_0201_),
    .Q(\tx_fifo_mem[4][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2616_ (.CLK(clk),
    .D(_0202_),
    .Q(\tx_fifo_mem[4][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2617_ (.CLK(clk),
    .D(_0203_),
    .Q(\tx_fifo_mem[4][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2618_ (.CLK(clk),
    .D(_0204_),
    .Q(\tx_fifo_mem[4][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2619_ (.CLK(clk),
    .D(_0205_),
    .Q(\tx_fifo_mem[4][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2620_ (.CLK(clk),
    .D(_0206_),
    .Q(\tx_fifo_mem[5][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2621_ (.CLK(clk),
    .D(_0207_),
    .Q(\tx_fifo_mem[5][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2622_ (.CLK(clk),
    .D(_0208_),
    .Q(\tx_fifo_mem[5][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2623_ (.CLK(clk),
    .D(_0209_),
    .Q(\tx_fifo_mem[5][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2624_ (.CLK(clk),
    .D(_0210_),
    .Q(\tx_fifo_mem[5][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2625_ (.CLK(clk),
    .D(_0211_),
    .Q(\tx_fifo_mem[5][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2626_ (.CLK(clk),
    .D(_0212_),
    .Q(\tx_fifo_mem[5][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2627_ (.CLK(clk),
    .D(_0213_),
    .Q(\tx_fifo_mem[5][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2628_ (.CLK(clk),
    .D(_0214_),
    .Q(\tx_fifo_mem[6][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2629_ (.CLK(clk),
    .D(_0215_),
    .Q(\tx_fifo_mem[6][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2630_ (.CLK(clk),
    .D(_0216_),
    .Q(\tx_fifo_mem[6][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2631_ (.CLK(clk),
    .D(_0217_),
    .Q(\tx_fifo_mem[6][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2632_ (.CLK(clk),
    .D(_0218_),
    .Q(\tx_fifo_mem[6][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2633_ (.CLK(clk),
    .D(_0219_),
    .Q(\tx_fifo_mem[6][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2634_ (.CLK(clk),
    .D(_0220_),
    .Q(\tx_fifo_mem[6][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2635_ (.CLK(clk),
    .D(_0221_),
    .Q(\tx_fifo_mem[6][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2636_ (.CLK(clk),
    .D(_0222_),
    .Q(\tx_fifo_mem[7][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2637_ (.CLK(clk),
    .D(_0223_),
    .Q(\tx_fifo_mem[7][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2638_ (.CLK(clk),
    .D(_0224_),
    .Q(\tx_fifo_mem[7][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2639_ (.CLK(clk),
    .D(_0225_),
    .Q(\tx_fifo_mem[7][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2640_ (.CLK(clk),
    .D(_0226_),
    .Q(\tx_fifo_mem[7][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2641_ (.CLK(clk),
    .D(_0227_),
    .Q(\tx_fifo_mem[7][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2642_ (.CLK(clk),
    .D(_0228_),
    .Q(\tx_fifo_mem[7][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2643_ (.CLK(clk),
    .D(_0229_),
    .Q(\tx_fifo_mem[7][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2644_ (.CLK(clk),
    .D(_0230_),
    .Q(\tx_fifo_mem[8][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2645_ (.CLK(clk),
    .D(_0231_),
    .Q(\tx_fifo_mem[8][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2646_ (.CLK(clk),
    .D(_0232_),
    .Q(\tx_fifo_mem[8][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2647_ (.CLK(clk),
    .D(_0233_),
    .Q(\tx_fifo_mem[8][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2648_ (.CLK(clk),
    .D(_0234_),
    .Q(\tx_fifo_mem[8][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2649_ (.CLK(clk),
    .D(_0235_),
    .Q(\tx_fifo_mem[8][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2650_ (.CLK(clk),
    .D(_0236_),
    .Q(\tx_fifo_mem[8][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2651_ (.CLK(clk),
    .D(_0237_),
    .Q(\tx_fifo_mem[8][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2652_ (.CLK(clk),
    .D(_0238_),
    .Q(\tx_fifo_mem[9][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2653_ (.CLK(clk),
    .D(_0239_),
    .Q(\tx_fifo_mem[9][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2654_ (.CLK(clk),
    .D(_0240_),
    .Q(\tx_fifo_mem[9][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2655_ (.CLK(clk),
    .D(_0241_),
    .Q(\tx_fifo_mem[9][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2656_ (.CLK(clk),
    .D(_0242_),
    .Q(\tx_fifo_mem[9][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2657_ (.CLK(clk),
    .D(_0243_),
    .Q(\tx_fifo_mem[9][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2658_ (.CLK(clk),
    .D(_0244_),
    .Q(\tx_fifo_mem[9][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2659_ (.CLK(clk),
    .D(_0245_),
    .Q(\tx_fifo_mem[9][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2660_ (.CLK(clk),
    .D(_0246_),
    .Q(\tx_fifo_mem[10][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2661_ (.CLK(clk),
    .D(_0247_),
    .Q(\tx_fifo_mem[10][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2662_ (.CLK(clk),
    .D(_0248_),
    .Q(\tx_fifo_mem[10][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2663_ (.CLK(clk),
    .D(_0249_),
    .Q(\tx_fifo_mem[10][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2664_ (.CLK(clk),
    .D(_0250_),
    .Q(\tx_fifo_mem[10][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2665_ (.CLK(clk),
    .D(_0251_),
    .Q(\tx_fifo_mem[10][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2666_ (.CLK(clk),
    .D(_0252_),
    .Q(\tx_fifo_mem[10][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2667_ (.CLK(clk),
    .D(_0253_),
    .Q(\tx_fifo_mem[10][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2668_ (.CLK(clk),
    .D(_0254_),
    .Q(\tx_fifo_mem[11][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2669_ (.CLK(clk),
    .D(_0255_),
    .Q(\tx_fifo_mem[11][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2670_ (.CLK(clk),
    .D(_0256_),
    .Q(\tx_fifo_mem[11][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2671_ (.CLK(clk),
    .D(_0257_),
    .Q(\tx_fifo_mem[11][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2672_ (.CLK(clk),
    .D(_0258_),
    .Q(\tx_fifo_mem[11][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2673_ (.CLK(clk),
    .D(_0259_),
    .Q(\tx_fifo_mem[11][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2674_ (.CLK(clk),
    .D(_0260_),
    .Q(\tx_fifo_mem[11][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2675_ (.CLK(clk),
    .D(_0261_),
    .Q(\tx_fifo_mem[11][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2676_ (.CLK(clk),
    .D(_0262_),
    .Q(\tx_fifo_mem[12][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2677_ (.CLK(clk),
    .D(_0263_),
    .Q(\tx_fifo_mem[12][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2678_ (.CLK(clk),
    .D(_0264_),
    .Q(\tx_fifo_mem[12][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2679_ (.CLK(clk),
    .D(_0265_),
    .Q(\tx_fifo_mem[12][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2680_ (.CLK(clk),
    .D(_0266_),
    .Q(\tx_fifo_mem[12][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2681_ (.CLK(clk),
    .D(_0267_),
    .Q(\tx_fifo_mem[12][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2682_ (.CLK(clk),
    .D(_0268_),
    .Q(\tx_fifo_mem[12][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2683_ (.CLK(clk),
    .D(_0269_),
    .Q(\tx_fifo_mem[12][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2684_ (.CLK(clk),
    .D(_0270_),
    .Q(\tx_fifo_mem[13][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2685_ (.CLK(clk),
    .D(_0271_),
    .Q(\tx_fifo_mem[13][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2686_ (.CLK(clk),
    .D(_0272_),
    .Q(\tx_fifo_mem[13][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2687_ (.CLK(clk),
    .D(_0273_),
    .Q(\tx_fifo_mem[13][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2688_ (.CLK(clk),
    .D(_0274_),
    .Q(\tx_fifo_mem[13][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2689_ (.CLK(clk),
    .D(_0275_),
    .Q(\tx_fifo_mem[13][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2690_ (.CLK(clk),
    .D(_0276_),
    .Q(\tx_fifo_mem[13][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2691_ (.CLK(clk),
    .D(_0277_),
    .Q(\tx_fifo_mem[13][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2692_ (.CLK(clk),
    .D(_0278_),
    .Q(\tx_fifo_mem[14][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2693_ (.CLK(clk),
    .D(_0279_),
    .Q(\tx_fifo_mem[14][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2694_ (.CLK(clk),
    .D(_0280_),
    .Q(\tx_fifo_mem[14][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2695_ (.CLK(clk),
    .D(_0281_),
    .Q(\tx_fifo_mem[14][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2696_ (.CLK(clk),
    .D(_0282_),
    .Q(\tx_fifo_mem[14][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2697_ (.CLK(clk),
    .D(_0283_),
    .Q(\tx_fifo_mem[14][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2698_ (.CLK(clk),
    .D(_0284_),
    .Q(\tx_fifo_mem[14][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2699_ (.CLK(clk),
    .D(_0285_),
    .Q(\tx_fifo_mem[14][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2700_ (.CLK(clk),
    .D(_0286_),
    .Q(\tx_fifo_mem[15][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2701_ (.CLK(clk),
    .D(_0287_),
    .Q(\tx_fifo_mem[15][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2702_ (.CLK(clk),
    .D(_0288_),
    .Q(\tx_fifo_mem[15][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2703_ (.CLK(clk),
    .D(_0289_),
    .Q(\tx_fifo_mem[15][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2704_ (.CLK(clk),
    .D(_0290_),
    .Q(\tx_fifo_mem[15][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2705_ (.CLK(clk),
    .D(_0291_),
    .Q(\tx_fifo_mem[15][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2706_ (.CLK(clk),
    .D(_0292_),
    .Q(\tx_fifo_mem[15][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2707_ (.CLK(clk),
    .D(_0293_),
    .Q(\tx_fifo_mem[15][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2708_ (.CLK(clk),
    .D(_0294_),
    .Q(\rx_fifo_mem[0][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2709_ (.CLK(clk),
    .D(_0295_),
    .Q(\rx_fifo_mem[0][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2710_ (.CLK(clk),
    .D(_0296_),
    .Q(\rx_fifo_mem[0][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2711_ (.CLK(clk),
    .D(_0297_),
    .Q(\rx_fifo_mem[0][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2712_ (.CLK(clk),
    .D(_0298_),
    .Q(\rx_fifo_mem[0][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2713_ (.CLK(clk),
    .D(_0299_),
    .Q(\rx_fifo_mem[0][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2714_ (.CLK(clk),
    .D(_0300_),
    .Q(\rx_fifo_mem[0][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2715_ (.CLK(clk),
    .D(_0301_),
    .Q(\rx_fifo_mem[0][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2716_ (.CLK(clk),
    .D(_0302_),
    .Q(\rx_fifo_mem[1][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2717_ (.CLK(clk),
    .D(_0303_),
    .Q(\rx_fifo_mem[1][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2718_ (.CLK(clk),
    .D(_0304_),
    .Q(\rx_fifo_mem[1][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2719_ (.CLK(clk),
    .D(_0305_),
    .Q(\rx_fifo_mem[1][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2720_ (.CLK(clk),
    .D(_0306_),
    .Q(\rx_fifo_mem[1][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2721_ (.CLK(clk),
    .D(_0307_),
    .Q(\rx_fifo_mem[1][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2722_ (.CLK(clk),
    .D(_0308_),
    .Q(\rx_fifo_mem[1][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2723_ (.CLK(clk),
    .D(_0309_),
    .Q(\rx_fifo_mem[1][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2724_ (.CLK(clk),
    .D(_0310_),
    .Q(\rx_fifo_mem[2][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2725_ (.CLK(clk),
    .D(_0311_),
    .Q(\rx_fifo_mem[2][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2726_ (.CLK(clk),
    .D(_0312_),
    .Q(\rx_fifo_mem[2][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2727_ (.CLK(clk),
    .D(_0313_),
    .Q(\rx_fifo_mem[2][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2728_ (.CLK(clk),
    .D(_0314_),
    .Q(\rx_fifo_mem[2][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2729_ (.CLK(clk),
    .D(_0315_),
    .Q(\rx_fifo_mem[2][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2730_ (.CLK(clk),
    .D(_0316_),
    .Q(\rx_fifo_mem[2][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2731_ (.CLK(clk),
    .D(_0317_),
    .Q(\rx_fifo_mem[2][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2732_ (.CLK(clk),
    .D(_0318_),
    .Q(\rx_fifo_mem[3][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2733_ (.CLK(clk),
    .D(_0319_),
    .Q(\rx_fifo_mem[3][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2734_ (.CLK(clk),
    .D(_0320_),
    .Q(\rx_fifo_mem[3][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2735_ (.CLK(clk),
    .D(_0321_),
    .Q(\rx_fifo_mem[3][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2736_ (.CLK(clk),
    .D(_0322_),
    .Q(\rx_fifo_mem[3][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2737_ (.CLK(clk),
    .D(_0323_),
    .Q(\rx_fifo_mem[3][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2738_ (.CLK(clk),
    .D(_0324_),
    .Q(\rx_fifo_mem[3][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2739_ (.CLK(clk),
    .D(_0325_),
    .Q(\rx_fifo_mem[3][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2740_ (.CLK(clk),
    .D(_0326_),
    .Q(\rx_fifo_mem[4][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2741_ (.CLK(clk),
    .D(_0327_),
    .Q(\rx_fifo_mem[4][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2742_ (.CLK(clk),
    .D(_0328_),
    .Q(\rx_fifo_mem[4][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2743_ (.CLK(clk),
    .D(_0329_),
    .Q(\rx_fifo_mem[4][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2744_ (.CLK(clk),
    .D(_0330_),
    .Q(\rx_fifo_mem[4][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2745_ (.CLK(clk),
    .D(_0331_),
    .Q(\rx_fifo_mem[4][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2746_ (.CLK(clk),
    .D(_0332_),
    .Q(\rx_fifo_mem[4][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2747_ (.CLK(clk),
    .D(_0333_),
    .Q(\rx_fifo_mem[4][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2748_ (.CLK(clk),
    .D(_0334_),
    .Q(\rx_fifo_mem[5][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2749_ (.CLK(clk),
    .D(_0335_),
    .Q(\rx_fifo_mem[5][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2750_ (.CLK(clk),
    .D(_0336_),
    .Q(\rx_fifo_mem[5][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2751_ (.CLK(clk),
    .D(_0337_),
    .Q(\rx_fifo_mem[5][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2752_ (.CLK(clk),
    .D(_0338_),
    .Q(\rx_fifo_mem[5][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2753_ (.CLK(clk),
    .D(_0339_),
    .Q(\rx_fifo_mem[5][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2754_ (.CLK(clk),
    .D(_0340_),
    .Q(\rx_fifo_mem[5][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2755_ (.CLK(clk),
    .D(_0341_),
    .Q(\rx_fifo_mem[5][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2756_ (.CLK(clk),
    .D(_0342_),
    .Q(\rx_fifo_mem[6][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2757_ (.CLK(clk),
    .D(_0343_),
    .Q(\rx_fifo_mem[6][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2758_ (.CLK(clk),
    .D(_0344_),
    .Q(\rx_fifo_mem[6][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2759_ (.CLK(clk),
    .D(_0345_),
    .Q(\rx_fifo_mem[6][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2760_ (.CLK(clk),
    .D(_0346_),
    .Q(\rx_fifo_mem[6][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2761_ (.CLK(clk),
    .D(_0347_),
    .Q(\rx_fifo_mem[6][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2762_ (.CLK(clk),
    .D(_0348_),
    .Q(\rx_fifo_mem[6][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2763_ (.CLK(clk),
    .D(_0349_),
    .Q(\rx_fifo_mem[6][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2764_ (.CLK(clk),
    .D(_0350_),
    .Q(\rx_fifo_mem[7][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2765_ (.CLK(clk),
    .D(_0351_),
    .Q(\rx_fifo_mem[7][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2766_ (.CLK(clk),
    .D(_0352_),
    .Q(\rx_fifo_mem[7][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2767_ (.CLK(clk),
    .D(_0353_),
    .Q(\rx_fifo_mem[7][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2768_ (.CLK(clk),
    .D(_0354_),
    .Q(\rx_fifo_mem[7][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2769_ (.CLK(clk),
    .D(_0355_),
    .Q(\rx_fifo_mem[7][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2770_ (.CLK(clk),
    .D(_0356_),
    .Q(\rx_fifo_mem[7][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2771_ (.CLK(clk),
    .D(_0357_),
    .Q(\rx_fifo_mem[7][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2772_ (.CLK(clk),
    .D(_0358_),
    .Q(\rx_fifo_mem[8][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2773_ (.CLK(clk),
    .D(_0359_),
    .Q(\rx_fifo_mem[8][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2774_ (.CLK(clk),
    .D(_0360_),
    .Q(\rx_fifo_mem[8][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2775_ (.CLK(clk),
    .D(_0361_),
    .Q(\rx_fifo_mem[8][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2776_ (.CLK(clk),
    .D(_0362_),
    .Q(\rx_fifo_mem[8][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2777_ (.CLK(clk),
    .D(_0363_),
    .Q(\rx_fifo_mem[8][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2778_ (.CLK(clk),
    .D(_0364_),
    .Q(\rx_fifo_mem[8][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2779_ (.CLK(clk),
    .D(_0365_),
    .Q(\rx_fifo_mem[8][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2780_ (.CLK(clk),
    .D(_0366_),
    .Q(\rx_fifo_mem[9][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2781_ (.CLK(clk),
    .D(_0367_),
    .Q(\rx_fifo_mem[9][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2782_ (.CLK(clk),
    .D(_0368_),
    .Q(\rx_fifo_mem[9][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2783_ (.CLK(clk),
    .D(_0369_),
    .Q(\rx_fifo_mem[9][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2784_ (.CLK(clk),
    .D(_0370_),
    .Q(\rx_fifo_mem[9][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2785_ (.CLK(clk),
    .D(_0371_),
    .Q(\rx_fifo_mem[9][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2786_ (.CLK(clk),
    .D(_0372_),
    .Q(\rx_fifo_mem[9][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2787_ (.CLK(clk),
    .D(_0373_),
    .Q(\rx_fifo_mem[9][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2788_ (.CLK(clk),
    .D(_0374_),
    .Q(\rx_fifo_mem[10][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2789_ (.CLK(clk),
    .D(_0375_),
    .Q(\rx_fifo_mem[10][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2790_ (.CLK(clk),
    .D(_0376_),
    .Q(\rx_fifo_mem[10][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2791_ (.CLK(clk),
    .D(_0377_),
    .Q(\rx_fifo_mem[10][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2792_ (.CLK(clk),
    .D(_0378_),
    .Q(\rx_fifo_mem[10][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2793_ (.CLK(clk),
    .D(_0379_),
    .Q(\rx_fifo_mem[10][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2794_ (.CLK(clk),
    .D(_0380_),
    .Q(\rx_fifo_mem[10][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2795_ (.CLK(clk),
    .D(_0381_),
    .Q(\rx_fifo_mem[10][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2796_ (.CLK(clk),
    .D(_0382_),
    .Q(\rx_fifo_mem[11][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2797_ (.CLK(clk),
    .D(_0383_),
    .Q(\rx_fifo_mem[11][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2798_ (.CLK(clk),
    .D(_0384_),
    .Q(\rx_fifo_mem[11][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2799_ (.CLK(clk),
    .D(_0385_),
    .Q(\rx_fifo_mem[11][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2800_ (.CLK(clk),
    .D(_0386_),
    .Q(\rx_fifo_mem[11][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2801_ (.CLK(clk),
    .D(_0387_),
    .Q(\rx_fifo_mem[11][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2802_ (.CLK(clk),
    .D(_0388_),
    .Q(\rx_fifo_mem[11][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2803_ (.CLK(clk),
    .D(_0389_),
    .Q(\rx_fifo_mem[11][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2804_ (.CLK(clk),
    .D(_0390_),
    .Q(\rx_fifo_mem[12][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2805_ (.CLK(clk),
    .D(_0391_),
    .Q(\rx_fifo_mem[12][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2806_ (.CLK(clk),
    .D(_0392_),
    .Q(\rx_fifo_mem[12][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2807_ (.CLK(clk),
    .D(_0393_),
    .Q(\rx_fifo_mem[12][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2808_ (.CLK(clk),
    .D(_0394_),
    .Q(\rx_fifo_mem[12][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2809_ (.CLK(clk),
    .D(_0395_),
    .Q(\rx_fifo_mem[12][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2810_ (.CLK(clk),
    .D(_0396_),
    .Q(\rx_fifo_mem[12][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2811_ (.CLK(clk),
    .D(_0397_),
    .Q(\rx_fifo_mem[12][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2812_ (.CLK(clk),
    .D(_0398_),
    .Q(\rx_fifo_mem[13][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2813_ (.CLK(clk),
    .D(_0399_),
    .Q(\rx_fifo_mem[13][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2814_ (.CLK(clk),
    .D(_0400_),
    .Q(\rx_fifo_mem[13][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2815_ (.CLK(clk),
    .D(_0401_),
    .Q(\rx_fifo_mem[13][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2816_ (.CLK(clk),
    .D(_0402_),
    .Q(\rx_fifo_mem[13][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2817_ (.CLK(clk),
    .D(_0403_),
    .Q(\rx_fifo_mem[13][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2818_ (.CLK(clk),
    .D(_0404_),
    .Q(\rx_fifo_mem[13][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2819_ (.CLK(clk),
    .D(_0405_),
    .Q(\rx_fifo_mem[13][7] ));
 sky130_fd_sc_hd__sdfxtp_2 _2820_ (.CLK(clk),
    .D(_0406_),
    .Q(\rx_fifo_mem[14][0] ));
 sky130_fd_sc_hd__sdfxtp_2 _2821_ (.CLK(clk),
    .D(_0407_),
    .Q(\rx_fifo_mem[14][1] ));
 sky130_fd_sc_hd__sdfxtp_2 _2822_ (.CLK(clk),
    .D(_0408_),
    .Q(\rx_fifo_mem[14][2] ));
 sky130_fd_sc_hd__sdfxtp_2 _2823_ (.CLK(clk),
    .D(_0409_),
    .Q(\rx_fifo_mem[14][3] ));
 sky130_fd_sc_hd__sdfxtp_2 _2824_ (.CLK(clk),
    .D(_0410_),
    .Q(\rx_fifo_mem[14][4] ));
 sky130_fd_sc_hd__sdfxtp_2 _2825_ (.CLK(clk),
    .D(_0411_),
    .Q(\rx_fifo_mem[14][5] ));
 sky130_fd_sc_hd__sdfxtp_2 _2826_ (.CLK(clk),
    .D(_0412_),
    .Q(\rx_fifo_mem[14][6] ));
 sky130_fd_sc_hd__sdfxtp_2 _2827_ (.CLK(clk),
    .D(_0413_),
    .Q(\rx_fifo_mem[14][7] ));
 sky130_fd_sc_hd__conb_1 _2828_ (.LO(rx_fifo_level[5]));
 sky130_fd_sc_hd__conb_1 _2829_ (.LO(tx_fifo_level[5]));
 sky130_fd_sc_hd__sdfsbp_2 _2405_ (.CLK(clk),
    .D(_0056_),
    .SET_B(reset_n),
    .Q(\rx_state[0] ));
 assign scan_out[3] = error_r;
 assign scan_out[0] = packet_active_r;
 assign scan_out[2] = rx_busy_r;
 assign scan_out[1] = tx_busy_r;
endmodule
