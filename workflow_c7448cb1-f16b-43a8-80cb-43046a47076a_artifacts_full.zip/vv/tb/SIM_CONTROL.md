# System Simulation Control

Generated files:
- `run_regression.py`: orchestrates multi-seed runs via `make TESTCASE=...`
- `simulation_manifest.json`: consolidated simulation-control manifest for the integrated system DUT

Key resolved inputs:
- Top module: `temp_monitor_soc_sim`
- System integration intent: `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/c7448cb1-f16b-43a8-80cb-43046a47076a/2c5e0c4d-f6fc-4a4f-854b-4f47864a7191/digital/system/integration/system_integration_intent.json`
- SoC top (sim): `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/c7448cb1-f16b-43a8-80cb-43046a47076a/2c5e0c4d-f6fc-4a4f-854b-4f47864a7191/digital/system/imported_rtl/temp_monitor_soc_sim.sv`
- RTL file count: `4`

Seed management:
- override with `RANDOM_SEED=<int>`

Usage:
```bash
python run_regression.py --tests system_smoke_test integrated_input_sanity --seeds 1 2 3 4 5
```
