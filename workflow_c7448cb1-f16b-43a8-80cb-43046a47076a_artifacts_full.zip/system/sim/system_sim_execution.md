# System Simulation Execution Report

- Top: `temp_monitor_soc_sim`
- Tests run: 6
- Passed: 0
- Failed: 6
- Total runtime (s): 7.356
- Coverage JSON present: False
- Coverage MD present: False

## Run Matrix
- `system_smoke_test` / seed `1` → FAIL (rc=2, 1.287s)
- `system_smoke_test` / seed `2` → FAIL (rc=2, 1.215s)
- `system_smoke_test` / seed `7` → FAIL (rc=2, 1.231s)
- `integrated_input_sanity` / seed `1` → FAIL (rc=2, 1.198s)
- `integrated_input_sanity` / seed `2` → FAIL (rc=2, 1.237s)
- `integrated_input_sanity` / seed `7` → FAIL (rc=2, 1.188s)
