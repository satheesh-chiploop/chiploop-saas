/*
 * Auto-generated SVA bind file.
 * Uses only spec-declared signals.
 */
bind adaptive_aero_control_top adaptive_aero_control_top_assertions u_adaptive_aero_control_top_assertions (
  .clk(clk),
  .clk_rst_n(clk_rst_n),
  .cfg_bus_addr(cfg_bus_addr),
  .cfg_bus_wdata(cfg_bus_wdata),
  .cfg_bus_valid(cfg_bus_valid),
  .cfg_bus_write(cfg_bus_write),
  .cfg_bus_rdata(cfg_bus_rdata),
  .cfg_bus_ready(cfg_bus_ready),
  .cfg_bus_rvalid(cfg_bus_rvalid),
  .req_data(req_data),
  .req_valid(req_valid),
  .req_ready(req_ready),
  .rsp_data(rsp_data),
  .rsp_valid(rsp_valid),
  .rsp_ready(rsp_ready),
  .act_cmd(act_cmd),
  .fault_out(fault_out),
  .seq_next(seq_next)
);
