/*
 * Auto-generated SVA scaffold.
 * Derived from spec_json / digital_spec_json.
 * No hardcoded design-specific signal assumptions.
 */

module adaptive_aero_control_top_assertions (
  input logic [15:0] act_cmd,
  input logic [7:0] cfg_bus_addr,
  input logic [63:0] cfg_bus_rdata,
  input logic cfg_bus_ready,
  input logic cfg_bus_rvalid,
  input logic cfg_bus_valid,
  input logic [63:0] cfg_bus_wdata,
  input logic cfg_bus_write,
  input logic clk,
  input logic clk_rst_n,
  input logic [7:0] fault_out,
  input logic [127:0] req_data,
  input logic req_ready,
  input logic req_valid,
  input logic [127:0] rsp_data,
  input logic rsp_ready,
  input logic rsp_valid,
  input logic [7:0] seq_next
);

  property p_reset_known;
    @(posedge clk)
      !$isunknown(clk_rst_n);
  endproperty

  a_reset_known: assert property(p_reset_known)
    else $error("Reset signal has X/Z state.");
  property p_cfg_bus_rdata_known_after_reset;
    @(posedge clk) disable iff (!clk_rst_n)
      !$isunknown(cfg_bus_rdata);
  endproperty

  a_cfg_bus_rdata_known_after_reset: assert property(p_cfg_bus_rdata_known_after_reset)
    else $error("Signal cfg_bus_rdata has X/Z after reset release.");
  property p_cfg_bus_ready_known_after_reset;
    @(posedge clk) disable iff (!clk_rst_n)
      !$isunknown(cfg_bus_ready);
  endproperty

  a_cfg_bus_ready_known_after_reset: assert property(p_cfg_bus_ready_known_after_reset)
    else $error("Signal cfg_bus_ready has X/Z after reset release.");
  property p_cfg_bus_rvalid_known_after_reset;
    @(posedge clk) disable iff (!clk_rst_n)
      !$isunknown(cfg_bus_rvalid);
  endproperty

  a_cfg_bus_rvalid_known_after_reset: assert property(p_cfg_bus_rvalid_known_after_reset)
    else $error("Signal cfg_bus_rvalid has X/Z after reset release.");
  property p_req_data_known_after_reset;
    @(posedge clk) disable iff (!clk_rst_n)
      !$isunknown(req_data);
  endproperty

  a_req_data_known_after_reset: assert property(p_req_data_known_after_reset)
    else $error("Signal req_data has X/Z after reset release.");
  property p_req_valid_known_after_reset;
    @(posedge clk) disable iff (!clk_rst_n)
      !$isunknown(req_valid);
  endproperty

  a_req_valid_known_after_reset: assert property(p_req_valid_known_after_reset)
    else $error("Signal req_valid has X/Z after reset release.");
  property p_rsp_ready_known_after_reset;
    @(posedge clk) disable iff (!clk_rst_n)
      !$isunknown(rsp_ready);
  endproperty

  a_rsp_ready_known_after_reset: assert property(p_rsp_ready_known_after_reset)
    else $error("Signal rsp_ready has X/Z after reset release.");
  property p_act_cmd_known_after_reset;
    @(posedge clk) disable iff (!clk_rst_n)
      !$isunknown(act_cmd);
  endproperty

  a_act_cmd_known_after_reset: assert property(p_act_cmd_known_after_reset)
    else $error("Signal act_cmd has X/Z after reset release.");
  property p_fault_out_known_after_reset;
    @(posedge clk) disable iff (!clk_rst_n)
      !$isunknown(fault_out);
  endproperty

  a_fault_out_known_after_reset: assert property(p_fault_out_known_after_reset)
    else $error("Signal fault_out has X/Z after reset release.");

endmodule
