# Functional Coverage Summary

- Top module: adaptive_aero_control_top
- Functional coverage: 61.11%
- Bins hit: 22
- Total bins: 36

## Outputs
- cfg_bus_rdata: samples=25, bins=1/2
- cfg_bus_ready: samples=25, bins=1/2
- cfg_bus_rvalid: samples=25, bins=1/2
- req_data: samples=25, bins=1/2
- req_valid: samples=25, bins=1/2
- rsp_ready: samples=25, bins=1/2
- act_cmd: samples=25, bins=1/2
- fault_out: samples=25, bins=1/2

## Inputs
- clk: samples=25, bins=1/2
- clk_rst_n: samples=25, bins=1/2
- cfg_bus_addr: samples=25, bins=1/2
- cfg_bus_wdata: samples=25, bins=1/2
- cfg_bus_valid: samples=25, bins=2/2
- cfg_bus_write: samples=25, bins=2/2
- req_ready: samples=25, bins=2/2
- rsp_data: samples=25, bins=1/2
- rsp_valid: samples=25, bins=2/2
- seq_next: samples=25, bins=1/2
