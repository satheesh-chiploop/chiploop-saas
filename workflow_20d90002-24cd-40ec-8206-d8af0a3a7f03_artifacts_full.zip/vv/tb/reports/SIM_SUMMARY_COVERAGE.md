# Simulation Summary + Coverage

- Total simulation runs: 8
- Simulation pass count: 8
- Simulation fail count: 0
- Coverage status: ok
- Functional coverage %: 72.22
- Coverage bins hit: 26
- Coverage total bins: 36
- Functional bin gaps: 10
- Code line coverage: 45.01%
- Code branch coverage: 16.59%
- Code condition coverage: 16.59%
- Code toggle coverage: 28.59%
- SVA/assertion status: ok
- SVA/assertion pass %: 100.0%
- Formal status: not_enabled
- Golden model status: not_enabled
- Simulator tool: verilator
- Code coverage tool: verilator_coverage
- Formal tool: none
- Golden model tool: none

## Functional Coverage Not Met
- outputs.act_cmd: bins 1/2, missing nonzero, seen values [0]
- outputs.cfg_bus_rdata: bins 1/2, missing nonzero, seen values [0]
- outputs.cfg_bus_ready: bins 1/2, missing nonzero, seen values [0]
- outputs.cfg_bus_rvalid: bins 1/2, missing nonzero, seen values [0]
- outputs.fault_out: bins 1/2, missing nonzero, seen values [0]
- outputs.req_data: bins 1/2, missing nonzero, seen values [0]
- outputs.req_valid: bins 1/2, missing nonzero, seen values [0]
- outputs.rsp_ready: bins 1/2, missing zero, seen values [1]
- inputs.clk: bins 1/2, missing zero, seen values [1]
- inputs.clk_rst_n: bins 1/2, missing zero, seen values [1]
