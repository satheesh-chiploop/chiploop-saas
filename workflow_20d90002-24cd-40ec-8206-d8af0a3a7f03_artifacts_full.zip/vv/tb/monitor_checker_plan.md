# Monitor And Checker Plan

- Source: generated_from_spec
- Top module: `adaptive_aero_control_top`
- Clock observations: `clk`, `clk_rst_n`
- Reset observations: `clk_rst_n`

## Monitors
- Clock/reset monitor: observe reset sequencing and active simulation edges.
- Input stimulus monitor: record values driven on declared inputs.
- Output response monitor: sample declared outputs after reset and stimulus changes.
- Coverage monitor: call `CoverageModel.sample()` at transaction/checkpoint boundaries.

## Observed Inputs
- `clk`
- `clk_rst_n`
- `cfg_bus_addr`
- `cfg_bus_wdata`
- `cfg_bus_valid`
- `cfg_bus_write`
- `req_ready`
- `rsp_data`
- `rsp_valid`
- `seq_next`

## Observed Outputs
- `cfg_bus_rdata`
- `cfg_bus_ready`
- `cfg_bus_rvalid`
- `req_data`
- `req_valid`
- `rsp_ready`
- `act_cmd`
- `fault_out`

## Checkers
- Reset known-value checker: outputs should settle after reset release.
- Width/value checker: sampled signals use spec-declared widths.
- Scenario checker: directed tests should encode expected responses from the verification plan.
- Scoreboard hook: compare expected versus observed transactions when `scoreboard.py` is present.
- SVA hook: include generated assertion bind files when available.

## Coverage Coupling
- Functional output points: `cfg_bus_rdata`, `cfg_bus_ready`, `cfg_bus_rvalid`, `req_data`, `req_valid`, `rsp_ready`, `act_cmd`, `fault_out`
- Functional input points: `clk`, `clk_rst_n`, `cfg_bus_addr`, `cfg_bus_wdata`, `cfg_bus_valid`, `cfg_bus_write`, `req_ready`, `rsp_data`, `rsp_valid`, `seq_next`

## Review Checklist
- Every important requirement should have a monitor point.
- Every monitor should feed a checker, scoreboard, assertion, or coverage point.
- Add custom scoreboard logic for behavior that cannot be inferred from ports alone.
