# Coverage Point Plan

- Source: generated_from_spec
- Top module: `adaptive_aero_control_top`

## Output Coverpoints
- Cover `cfg_bus_rdata` zero and non-zero/value-transition bins.
- Cover `cfg_bus_ready` zero and non-zero/value-transition bins.
- Cover `cfg_bus_rvalid` zero and non-zero/value-transition bins.
- Cover `req_data` zero and non-zero/value-transition bins.
- Cover `req_valid` zero and non-zero/value-transition bins.
- Cover `rsp_ready` zero and non-zero/value-transition bins.
- Cover `act_cmd` zero and non-zero/value-transition bins.
- Cover `fault_out` zero and non-zero/value-transition bins.

## Input Coverpoints
- Cover `clk` zero and non-zero/input-stimulus bins.
- Cover `clk_rst_n` zero and non-zero/input-stimulus bins.
- Cover `cfg_bus_addr` zero and non-zero/input-stimulus bins.
- Cover `cfg_bus_wdata` zero and non-zero/input-stimulus bins.
- Cover `cfg_bus_valid` zero and non-zero/input-stimulus bins.
- Cover `cfg_bus_write` zero and non-zero/input-stimulus bins.
- Cover `req_ready` zero and non-zero/input-stimulus bins.
- Cover `rsp_data` zero and non-zero/input-stimulus bins.
- Cover `rsp_valid` zero and non-zero/input-stimulus bins.
- Cover `seq_next` zero and non-zero/input-stimulus bins.

## Cross Coverage Candidates
- Cross reset release with first observed output activity.
- Cross primary control inputs with output response bins when both are present.

## Closure Guidance
- Add directed tests for missed bins.
- Waive bins only with reviewer rationale.
