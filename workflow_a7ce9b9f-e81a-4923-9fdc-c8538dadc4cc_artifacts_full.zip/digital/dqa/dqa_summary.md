# Digital DQA Summary
- workflow_id: `a7ce9b9f-e81a-4923-9fdc-c8538dadc4cc`
- status: `pass`
- rtl files: `2`
- warning count: `0`

## Stage Status
- rtl_lint: `warn`
- cdc: `pass`
- reset_integrity: `pass`
- synthesis_readiness: `pass`
