module adaptive_aero_control_top (
    input         clk,
    input         reset_n,
    input         mmio_req_valid,
    output        mmio_req_ready,
    input         mmio_req_write,
    input  [7:0] mmio_req_addr,
    input  [31:0] mmio_req_wdata,
    output        mmio_req_rvalid,
    input         mmio_req_rready,
    output [31:0] mmio_req_rdata,
    output        model_req_valid,
    input         model_req_ready,
    output [63:0] model_req_data,
    input         model_rsp_valid,
    output        model_rsp_ready,
    input  [63:0] model_rsp_data,
    output        actuator_cmd_valid,
    input         actuator_cmd_ready,
    output [31:0] actuator_cmd_data,
    output        irq_status
);

    localparam [2:0] ST_IDLE        = 3'd0;
    localparam [2:0] ST_ISSUE_REQ   = 3'd1;
    localparam [2:0] ST_WAIT_RSP    = 3'd2;
    localparam [2:0] ST_VALIDATE    = 3'd3;
    localparam [2:0] ST_APPLY_CMD   = 3'd4;
    localparam [2:0] ST_SAFE_FB     = 3'd5;

    reg [2:0]  state, state_next;

    reg        ctrl_enable;
    reg [15:0] seq_id_reg;
    reg [15:0] stale_threshold_reg;
    reg [15:0] timeout_threshold_reg;
    reg [31:0] cmd_min_reg;
    reg [31:0] cmd_max_reg;
    reg [31:0] fallback_cmd_reg;

    reg        sticky_stale_reject;
    reg        sticky_timeout_error;
    reg        sticky_service_error;
    reg        sticky_clamp_active;
    reg        response_valid_reg;
    reg        fallback_active_reg;
    reg        busy_reg;
    reg        outstanding_reg;
    reg        req_issued_reg;
    reg [15:0] outstanding_seq_id_reg;
    reg [13:0] timeout_count_reg;
    reg [31:0] accepted_cmd_reg;
    reg [31:0] safe_cmd_reg;

    reg        mmio_req_ready_r;
    reg        mmio_req_rvalid_r;
    reg [31:0] mmio_req_rdata_r;
    reg        model_req_valid_r;
    reg [63:0] model_req_data_r;
    reg        model_rsp_ready_r;
    reg        actuator_cmd_valid_r;
    reg [31:0] actuator_cmd_data_r;
    reg        irq_status_r;

    wire [31:0] clamped_fallback_cmd;
    wire [31:0] clamped_accepted_cmd;
    wire [31:0] current_safe_cmd;
    wire        any_fault;
    wire [31:0] status_reg_read;
    wire [31:0] req_status_read;

    reg [31:0] read_mux;

    reg [31:0] response_cmd_candidate;
    reg [15:0] response_seq_candidate;
    reg [15:0] response_age_candidate;
    reg        response_seq_match;
    reg        response_fresh;
    reg        response_accept;

    assign mmio_req_ready   = mmio_req_ready_r;
    assign mmio_req_rvalid   = mmio_req_rvalid_r;
    assign mmio_req_rdata    = mmio_req_rdata_r;
    assign model_req_valid   = model_req_valid_r;
    assign model_req_data    = model_req_data_r;
    assign model_rsp_ready   = model_rsp_ready_r;
    assign actuator_cmd_valid = actuator_cmd_valid_r;
    assign actuator_cmd_data  = actuator_cmd_data_r;
    assign irq_status         = irq_status_r;

    assign clamped_fallback_cmd = (fallback_cmd_reg < cmd_min_reg) ? cmd_min_reg :
                                  (fallback_cmd_reg > cmd_max_reg) ? cmd_max_reg :
                                  fallback_cmd_reg;

    assign clamped_accepted_cmd = (accepted_cmd_reg < cmd_min_reg) ? cmd_min_reg :
                                  (accepted_cmd_reg > cmd_max_reg) ? cmd_max_reg :
                                  accepted_cmd_reg;

    assign current_safe_cmd = safe_cmd_reg;

    assign any_fault = sticky_stale_reject | sticky_timeout_error | sticky_service_error | sticky_clamp_active | fallback_active_reg;

    assign status_reg_read = {24'b0,
                              sticky_service_error,
                              fallback_active_reg,
                              sticky_clamp_active,
                              sticky_timeout_error,
                              sticky_stale_reject,
                              response_valid_reg,
                              ctrl_enable,
                              busy_reg};

    assign req_status_read = {timeout_count_reg, req_issued_reg, outstanding_reg, outstanding_seq_id_reg};

    always @(*) begin
        state_next = state;
        mmio_req_ready_r = 1'b1;
        mmio_req_rvalid_r = 1'b0;
        mmio_req_rdata_r = 32'b0;
        model_req_valid_r = 1'b0;
        model_req_data_r = 64'b0;
        model_rsp_ready_r = 1'b0;
        actuator_cmd_valid_r = 1'b0;
        actuator_cmd_data_r = current_safe_cmd;
        irq_status_r = any_fault | (state != ST_IDLE);

        response_cmd_candidate = 32'b0;
        response_seq_candidate = 16'b0;
        response_age_candidate = 16'b0;
        response_seq_match = 1'b0;
        response_fresh = 1'b0;
        response_accept = 1'b0;
        read_mux = 32'b0;

        case (mmio_req_addr)
            8'h00: read_mux = {28'b0, 1'b0, 1'b0, 1'b0, ctrl_enable};
            8'h04: read_mux = {16'b0, seq_id_reg};
            8'h08: read_mux = {timeout_threshold_reg, stale_threshold_reg};
            8'h0C: read_mux = cmd_min_reg;
            8'h10: read_mux = cmd_max_reg;
            8'h14: read_mux = fallback_cmd_reg;
            8'h18: read_mux = status_reg_read;
            8'h1C: read_mux = clamped_accepted_cmd;
            8'h20: read_mux = req_status_read;
            default: read_mux = 32'b0;
        endcase

        if (mmio_req_valid) begin
            if (mmio_req_write) begin
                case (mmio_req_addr)
                    8'h00: begin
                        if (mmio_req_wdata[2]) begin
                        end
                    end
                    default: begin
                    end
                endcase
            end
        end

        case (state)
            ST_IDLE: begin
                model_rsp_ready_r = 1'b0;
                if (ctrl_enable && mmio_req_valid && mmio_req_write && mmio_req_addr == 8'h00 && mmio_req_wdata[1]) begin
                    state_next = ST_ISSUE_REQ;
                end else if (!ctrl_enable) begin
                    state_next = ST_SAFE_FB;
                end
            end
            ST_ISSUE_REQ: begin
                model_req_valid_r = 1'b1;
                model_req_data_r = {40'b0, seq_id_reg, 8'hA5};
                if (model_req_ready) begin
                    state_next = ST_WAIT_RSP;
                end
            end
            ST_WAIT_RSP: begin
                model_rsp_ready_r = 1'b1;
                if (model_rsp_valid) begin
                    state_next = ST_VALIDATE;
                end else if (timeout_count_reg >= timeout_threshold_reg[13:0]) begin
                    state_next = ST_SAFE_FB;
                end
            end
            ST_VALIDATE: begin
                response_seq_candidate = model_rsp_data[63:48];
                response_age_candidate = model_rsp_data[47:32];
                response_cmd_candidate = model_rsp_data[31:0];
                response_seq_match = (response_seq_candidate == seq_id_reg);
                response_fresh = (response_age_candidate <= stale_threshold_reg);
                response_accept = response_seq_match & response_fresh;
                if (response_accept) begin
                    state_next = ST_APPLY_CMD;
                end else begin
                    state_next = ST_SAFE_FB;
                end
            end
            ST_APPLY_CMD: begin
                actuator_cmd_valid_r = 1'b1;
                actuator_cmd_data_r = clamped_accepted_cmd;
                if (actuator_cmd_ready) begin
                    state_next = ST_IDLE;
                end
            end
            ST_SAFE_FB: begin
                actuator_cmd_valid_r = 1'b1;
                actuator_cmd_data_r = clamped_fallback_cmd;
                if (actuator_cmd_ready) begin
                    state_next = ST_IDLE;
                end
            end
            default: begin
                state_next = ST_SAFE_FB;
            end
        endcase
    end

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            state <= ST_SAFE_FB;
            ctrl_enable <= 1'b0;
            seq_id_reg <= 16'b0;
            stale_threshold_reg <= 16'b0;
            timeout_threshold_reg <= 16'b0;
            cmd_min_reg <= 32'b0;
            cmd_max_reg <= 32'hFFFFFFFF;
            fallback_cmd_reg <= 32'b0;
            sticky_stale_reject <= 1'b0;
            sticky_timeout_error <= 1'b0;
            sticky_service_error <= 1'b0;
            sticky_clamp_active <= 1'b0;
            response_valid_reg <= 1'b0;
            fallback_active_reg <= 1'b1;
            busy_reg <= 1'b0;
            outstanding_reg <= 1'b0;
            req_issued_reg <= 1'b0;
            outstanding_seq_id_reg <= 16'b0;
            timeout_count_reg <= 14'b0;
            accepted_cmd_reg <= 32'b0;
            safe_cmd_reg <= 32'b0;
        end else begin
            state <= state_next;

            if (mmio_req_valid && mmio_req_write) begin
                case (mmio_req_addr)
                    8'h00: begin
                        ctrl_enable <= mmio_req_wdata[0];
                        if (mmio_req_wdata[2]) begin
                            sticky_stale_reject <= 1'b0;
                            sticky_timeout_error <= 1'b0;
                            sticky_service_error <= 1'b0;
                            sticky_clamp_active <= 1'b0;
                        end
                    end
                    8'h04: seq_id_reg <= mmio_req_wdata[15:0];
                    8'h08: begin
                        stale_threshold_reg <= mmio_req_wdata[15:0];
                        timeout_threshold_reg <= mmio_req_wdata[31:16];
                    end
                    8'h0C: cmd_min_reg <= mmio_req_wdata;
                    8'h10: cmd_max_reg <= mmio_req_wdata;
                    8'h14: fallback_cmd_reg <= mmio_req_wdata;
                    default: begin
                    end
                endcase
            end

            if (!ctrl_enable) begin
                sticky_service_error <= sticky_service_error;
            end

            case (state)
                ST_IDLE: begin
                    busy_reg <= 1'b0;
                    outstanding_reg <= 1'b0;
                    req_issued_reg <= 1'b0;
                    timeout_count_reg <= 14'b0;
                    fallback_active_reg <= 1'b1;
                    response_valid_reg <= 1'b0;
                    safe_cmd_reg <= clamped_fallback_cmd;
                    if (ctrl_enable) begin
                        if (mmio_req_valid && mmio_req_write && mmio_req_addr == 8'h00 && mmio_req_wdata[1]) begin
                            outstanding_seq_id_reg <= seq_id_reg;
                            req_issued_reg <= 1'b1;
                            busy_reg <= 1'b1;
                            outstanding_reg <= 1'b1;
                            timeout_count_reg <= 14'b0;
                        end
                    end
                end
                ST_ISSUE_REQ: begin
                    busy_reg <= 1'b1;
                    outstanding_reg <= 1'b1;
                    req_issued_reg <= 1'b1;
                    outstanding_seq_id_reg <= seq_id_reg;
                    timeout_count_reg <= 14'b0;
                    fallback_active_reg <= 1'b0;
                end
                ST_WAIT_RSP: begin
                    busy_reg <= 1'b1;
                    outstanding_reg <= 1'b1;
                    req_issued_reg <= 1'b1;
                    timeout_count_reg <= timeout_count_reg + 14'd1;
                    fallback_active_reg <= 1'b0;
                    if (timeout_count_reg >= timeout_threshold_reg[13:0]) begin
                        sticky_timeout_error <= 1'b1;
                        fallback_active_reg <= 1'b1;
                    end
                end
                ST_VALIDATE: begin
                    response_valid_reg <= 1'b0;
                    if (model_rsp_data[63:48] == seq_id_reg && model_rsp_data[47:32] <= stale_threshold_reg) begin
                        accepted_cmd_reg <= model_rsp_data[31:0];
                        response_valid_reg <= 1'b1;
                        sticky_clamp_active <= sticky_clamp_active | ((model_rsp_data[31:0] < cmd_min_reg) | (model_rsp_data[31:0] > cmd_max_reg));
                    end else begin
                        sticky_stale_reject <= 1'b1;
                        fallback_active_reg <= 1'b1;
                    end
                end
                ST_APPLY_CMD: begin
                    accepted_cmd_reg <= clamped_accepted_cmd;
                    safe_cmd_reg <= clamped_accepted_cmd;
                    response_valid_reg <= 1'b1;
                    busy_reg <= 1'b0;
                    outstanding_reg <= 1'b0;
                    req_issued_reg <= 1'b0;
                    fallback_active_reg <= 1'b0;
                end
                ST_SAFE_FB: begin
                    safe_cmd_reg <= clamped_fallback_cmd;
                    fallback_active_reg <= 1'b1;
                    busy_reg <= 1'b0;
                    outstanding_reg <= 1'b0;
                    req_issued_reg <= 1'b0;
                    if (!ctrl_enable) begin
                        sticky_service_error <= 1'b1;
                    end
                end
                default: begin
                    safe_cmd_reg <= clamped_fallback_cmd;
                    fallback_active_reg <= 1'b1;
                    busy_reg <= 1'b0;
                    outstanding_reg <= 1'b0;
                    req_issued_reg <= 1'b0;
                end
            endcase
        end
    end

endmodule
