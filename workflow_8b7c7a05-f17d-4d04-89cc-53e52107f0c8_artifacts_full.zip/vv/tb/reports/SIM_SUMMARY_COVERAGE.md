# Simulation Summary + Coverage

- Total simulation runs: 12
- Simulation pass count: 12
- Simulation fail count: 0
- Coverage status: ok
- Functional coverage %: 67.86
- Coverage bins hit: 19
- Coverage total bins: 28
- Functional bin gaps: 9
- Code line coverage: 45.55%
- Code branch coverage: 4.55%
- Code condition coverage: 4.55%
- Code toggle coverage: 12.03%
- SVA/assertion status: ok
- SVA/assertion pass %: 100.0%
- Formal status: fail
- Golden model status: generated
- Simulator tool: verilator
- Code coverage tool: verilator_coverage
- Formal tool: symbiyosys
- Golden model tool: chiploop_python_scoreboard

## Functional Coverage Not Met
- outputs.irq: bins 1/2, missing nonzero, seen values [0]
- outputs.packet_count: bins 1/2, missing nonzero, seen values [0]
- outputs.rx_fifo_level: bins 1/2, missing nonzero, seen values [0]
- outputs.uart_tx: bins 1/2, missing zero, seen values [1]
- inputs.clk: bins 1/2, missing zero, seen values [1]
- inputs.rd_en: bins 1/2, missing nonzero, seen values [0]
- inputs.reset_n: bins 1/2, missing zero, seen values [1]
- inputs.uart_rx: bins 1/2, missing nonzero, seen values [0]
- inputs.wr_en: bins 1/2, missing nonzero, seen values [0]
