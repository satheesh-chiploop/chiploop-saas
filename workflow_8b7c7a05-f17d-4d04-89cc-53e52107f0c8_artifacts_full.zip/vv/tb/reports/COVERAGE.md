# Functional Coverage Summary

- Top module: uart_packet_engine
- Functional coverage: 64.29%
- Bins hit: 18
- Total bins: 28

## Outputs
- rd_data: samples=78, bins=2/2
- uart_tx: samples=78, bins=1/2
- irq: samples=78, bins=1/2
- rx_fifo_level: samples=78, bins=1/2
- tx_fifo_level: samples=78, bins=2/2
- packet_count: samples=78, bins=1/2

## Inputs
- clk: samples=78, bins=1/2
- reset_n: samples=78, bins=1/2
- wr_en: samples=78, bins=1/2
- wr_addr: samples=78, bins=2/2
- wr_data: samples=78, bins=1/2
- rd_en: samples=78, bins=1/2
- rd_addr: samples=78, bins=2/2
- uart_rx: samples=78, bins=1/2
