/*
 * Auto-generated SVA scaffold.
 * Derived from spec_json / digital_spec_json.
 * No hardcoded design-specific signal assumptions.
 */

module uart_packet_engine_assertions (
  input logic clk,
  input logic irq,
  input logic [15:0] packet_count,
  input logic [7:0] rd_addr,
  input logic [7:0] rd_data,
  input logic rd_en,
  input logic reset_n,
  input logic [5:0] rx_fifo_level,
  input logic [5:0] tx_fifo_level,
  input logic uart_rx,
  input logic uart_tx,
  input logic [7:0] wr_addr,
  input logic [7:0] wr_data,
  input logic wr_en
);

  property p_reset_known;
    @(posedge clk)
      !$isunknown(reset_n);
  endproperty

  a_reset_known: assert property(p_reset_known)
    else $error("Reset signal has X/Z state.");
  property p_rd_data_known_after_reset;
    @(posedge clk) disable iff (!reset_n)
      !$isunknown(rd_data);
  endproperty

  a_rd_data_known_after_reset: assert property(p_rd_data_known_after_reset)
    else $error("Signal rd_data has X/Z after reset release.");
  property p_uart_tx_known_after_reset;
    @(posedge clk) disable iff (!reset_n)
      !$isunknown(uart_tx);
  endproperty

  a_uart_tx_known_after_reset: assert property(p_uart_tx_known_after_reset)
    else $error("Signal uart_tx has X/Z after reset release.");
  property p_irq_known_after_reset;
    @(posedge clk) disable iff (!reset_n)
      !$isunknown(irq);
  endproperty

  a_irq_known_after_reset: assert property(p_irq_known_after_reset)
    else $error("Signal irq has X/Z after reset release.");
  property p_rx_fifo_level_known_after_reset;
    @(posedge clk) disable iff (!reset_n)
      !$isunknown(rx_fifo_level);
  endproperty

  a_rx_fifo_level_known_after_reset: assert property(p_rx_fifo_level_known_after_reset)
    else $error("Signal rx_fifo_level has X/Z after reset release.");
  property p_tx_fifo_level_known_after_reset;
    @(posedge clk) disable iff (!reset_n)
      !$isunknown(tx_fifo_level);
  endproperty

  a_tx_fifo_level_known_after_reset: assert property(p_tx_fifo_level_known_after_reset)
    else $error("Signal tx_fifo_level has X/Z after reset release.");
  property p_packet_count_known_after_reset;
    @(posedge clk) disable iff (!reset_n)
      !$isunknown(packet_count);
  endproperty

  a_packet_count_known_after_reset: assert property(p_packet_count_known_after_reset)
    else $error("Signal packet_count has X/Z after reset release.");

endmodule
