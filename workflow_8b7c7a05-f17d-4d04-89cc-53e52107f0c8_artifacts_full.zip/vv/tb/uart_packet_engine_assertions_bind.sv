/*
 * Auto-generated SVA bind file.
 * Uses only spec-declared signals.
 */
bind uart_packet_engine uart_packet_engine_assertions u_uart_packet_engine_assertions (
  .clk(clk),
  .reset_n(reset_n),
  .wr_en(wr_en),
  .wr_addr(wr_addr),
  .wr_data(wr_data),
  .rd_en(rd_en),
  .rd_addr(rd_addr),
  .uart_rx(uart_rx),
  .rd_data(rd_data),
  .uart_tx(uart_tx),
  .irq(irq),
  .rx_fifo_level(rx_fifo_level),
  .tx_fifo_level(tx_fifo_level),
  .packet_count(packet_count)
);
