<!-- ASSUMPTION: The RTL top module name is provided by the environment via RTL_TOP and is not hardcoded here. -->
<!-- ASSUMPTION: The RTL source directory is provided by the environment via RTL_DIR and is not hardcoded here. -->
<!-- ASSUMPTION: The Verilator filelist is provided by the environment via FILELIST and is not hardcoded here. -->
<!-- ASSUMPTION: A cocotb-compatible testbench exists or will be added under the validation tree. -->
<!-- ASSUMPTION: The platform contract gate is not yet ready; this document covers simulation-only validation, not deployable hardware bring-up. -->

# Co-simulation runner steps

This workflow validates the host-side SPI device layer and portable driver service against the RTL interface contract in simulation.

## Prerequisites

Install the following tools in the host environment:

- Verilator
- Python 3
- pip
- cocotb
- pytest

Recommended Python packages:

- cocotb
- pytest
- pytest-junitxml optional, if JUnit output is desired
- coverage optional, if Python coverage is desired

## Environment variables

Provide the RTL and build inputs through environment variables:

- `RTL_TOP`
- `RTL_DIR`
- `FILELIST`

Optional overrides:

- `TOPLEVEL_LANG=verilog`
- `PYTHONPATH`
- `MODULE` for the cocotb test module
- `COCOTB_TEST_MODULES` if your test harness uses it
- `SIM_BUILD` to select the simulator build directory

## Build and run flow

1. Prepare the environment.
2. Build the RTL simulation with Verilator.
3. Build the firmware/host-side portable source if applicable.
4. Run cocotb through pytest.
5. Inspect logs and artifacts under `firmware/validate/`.

## Exact commands

### 1) Set environment

```bash
export RTL_TOP="${RTL_TOP:-<RTL_TOP>}"
export RTL_DIR="${RTL_DIR:-<RTL_DIR>}"
export FILELIST="${FILELIST:-<FILELIST>}"
export TOPLEVEL_LANG="${TOPLEVEL_LANG:-verilog}"
```

### 2) Build RTL sim

If `firmware/validate/verilator_build.md` exists, follow the command sequence defined there. Otherwise, use the standard Verilator flow:

```bash
mkdir -p firmware/validate/build
verilator --cc \
  --top-module "${RTL_TOP}" \
  --Mdir firmware/validate/build/verilator \
  -f "${FILELIST}"
```

If your RTL requires a cocotb makefile-based build, use the simulator integration command from your project harness. The exact compile options are expected to be supplied by the filelist and environment.

### 3) Build firmware if applicable

The target refinement is `portable_only`, so there is no deployable binary requirement at this stage. If the host-side driver service includes buildable Rust components, compile them with the project’s standard host build flow, for example:

```bash
cargo build --manifest-path <PATH_TO_CARGO_TOML>
```

If no Rust manifest is available yet, skip firmware compilation and validate only the simulator interface and testbench glue.

### 4) Run cocotb via pytest

Recommended invocation:

```bash
pytest -q firmware/validate
```

If the test module requires explicit selection, provide it via environment:

```bash
MODULE=<cocotb_test_module> pytest -q firmware/validate
```

If you want JUnit output:

```bash
pytest -q firmware/validate --junitxml=firmware/validate/junit.xml
```

### 5) Collect outputs

Expected artifacts under `firmware/validate/` include:

- simulator build directory
- Verilator compile logs
- pytest/cocotb runtime logs
- optional JUnit XML
- optional coverage files if enabled by the simulator or Python test harness

## Expected outputs

A successful run should produce:

- Verilator build artifacts in `firmware/validate/build/verilator/`
- cocotb test logs showing RTL elaboration and test execution
- pytest summary with passing tests
- optional `junit.xml` if requested
- optional coverage reports if enabled

## Notes

- This validation flow checks the contract between the host-side SPI device layer and the RTL collateral.
- No deployable binary is claimed until the missing `host_transport_and_board_wrapper` gate is satisfied.
- The script in `firmware/validate/run_cosim.sh` is the canonical entry point for local execution.
