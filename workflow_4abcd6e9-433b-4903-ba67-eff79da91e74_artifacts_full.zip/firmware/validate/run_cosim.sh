#!/usr/bin/env bash
set -euo pipefail

RTL_TOP=${RTL_TOP:-<RTL_TOP>}
RTL_DIR=${RTL_DIR:-<RTL_DIR>}
FILELIST=${FILELIST:-<FILELIST>}
TOPLEVEL_LANG=${TOPLEVEL_LANG:-verilog}
OUT_DIR=${OUT_DIR:-firmware/validate}
BUILD_DIR="${OUT_DIR}/build"
VERILATOR_BUILD_DIR="${BUILD_DIR}/verilator"
LOG_DIR="${OUT_DIR}/logs"

mkdir -p "${VERILATOR_BUILD_DIR}" "${LOG_DIR}"

if [ -f "${OUT_DIR}/verilator_build.md" ]; then
  python3 - <<'PY'
from pathlib import Path
p = Path("firmware/validate/verilator_build.md")
print(p.read_text())
PY
fi

if [ ! -f "${OUT_DIR}/verilator_build.md" ]; then
  verilator --cc \
    --top-module "${RTL_TOP}" \
    --Mdir "${VERILATOR_BUILD_DIR}" \
    -f "${FILELIST}" \
    2>&1 | tee "${LOG_DIR}/verilator_build.log"
fi

if [ -f "${OUT_DIR}/Cargo.toml" ]; then
  cargo build --manifest-path "${OUT_DIR}/Cargo.toml" \
    2>&1 | tee "${LOG_DIR}/cargo_build.log"
fi

export TOPLEVEL_LANG
export RTL_TOP
export RTL_DIR
export FILELIST
export PYTHONPATH="${PYTHONPATH:-}:${PWD}"
export PYTEST_ADDOPTS="${PYTEST_ADDOPTS:-} --junitxml=${OUT_DIR}/junit.xml"

pytest -q "${OUT_DIR}" 2>&1 | tee "${LOG_DIR}/pytest_cocotb.log"
