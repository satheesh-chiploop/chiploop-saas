# firmware/integration_contract.md

## Contract overview
- Host-side SPI device layer for `intelligent_active_aerodynamics_controller` is **portable-source only** at this stage; no deployable binary is claimed until the platform contract gate is complete.
- The firmware scope covers the **device-management service**: configuration, policy/LUT loading, diagnostics, and update control.
- The integration boundary is the approved partition plus existing RTL register collateral; firmware does **not** define new device semantics beyond the provided register contract.
- Primary external contract is between **cpu_software** and **fpga_or_asic** for versioned policy/LUT and control registers.
- Return path contract is **fpga_or_asic** to **firmware** for status, faults, telemetry, and interrupt delivery.
- Target refinement is **portable_only** for `ulx3s_ecp5_45f`; `host_transport` remains **not selected**, so board wrapper and transport binding are intentionally incomplete.
- The firmware gate is **not deployable** because `host_transport_and_board_wrapper` is missing.
- Full chain integration must preserve compatibility with system/host software via versioned interfaces, explicit error reporting, and stable logging schema.

## Contract version + compatibility policy
- **Contract version:** `chiploop.integration_contract.v1`
- **Compatibility policy:**
  - Backward compatible changes are allowed only when they do not change register meaning, message ordering, or error code semantics.
  - Any change to register map, policy blob format, telemetry format, or fault encoding requires a **minor version bump** and an updated compatibility note.
  - Breaking changes to transport binding, board wrapper, or ownership boundaries require a **major version bump** and re-validation.
  - Portable source may remain versioned as compatible even when no deployable artifact exists.
  - The platform contract gate must be satisfied before any claim of binary readiness or field deployment.

## Interfaces

### External interface summary

| Interface | Direction | Contract | Notes |
|---|---|---|---|
| Policy/LUT load | cpu_software → fpga_or_asic | Versioned policy/LUT and control registers | Firmware must validate schema/version before apply |
| Control register access | cpu_software → fpga_or_asic | Versioned policy/LUT and control registers | Read/write behavior follows RTL collateral |
| Status readback | fpga_or_asic → firmware | Status, faults, telemetry, and interrupt | Firmware polls or services events as supported by transport |
| Fault reporting | fpga_or_asic → firmware | Status, faults, telemetry, and interrupt | Faults are preserved with code, context, and timestamp/order if available |
| Telemetry capture | fpga_or_asic → firmware | Status, faults, telemetry, and interrupt | Telemetry is treated as read-only device output |
| Interrupt notification | fpga_or_asic → firmware | Status, faults, telemetry, and interrupt | Interrupt handling remains transport-dependent until host binding is selected |

### Device-management service API contract

| API | Ownership | Expected behavior | Error conditions |
|---|---|---|---|
| `dm_configure()` | Firmware | Apply validated configuration to device registers | Invalid schema, version mismatch, transport unavailable |
| `dm_load_policy()` | Firmware | Load versioned policy/LUT atomically where supported | Blob rejected, checksum/version failure, partial write failure |
| `dm_get_status()` | Firmware | Return current device status snapshot | Transport read failure, stale/invalid snapshot |
| `dm_get_faults()` | Firmware | Return fault list or fault snapshot | None/transport error; must not fabricate faults |
| `dm_clear_faults()` | Firmware | Request fault clear only when allowed by device policy | Clear denied, device busy, unsafe state |
| `dm_update_control()` | Firmware | Update control registers using validated writes | Range violation, policy lockout, transport error |
| `dm_begin_update()` | Firmware | Start a controlled update transaction | Update disabled, incompatible version, transport busy |
| `dm_commit_update()` | Firmware | Finalize update and verify completion | Verification failure, incomplete transfer |
| `dm_abort_update()` | Firmware | Abort in-progress update and restore safe state | Abort unsupported, transport error |

### Register and payload contract

| Class | Required properties | Firmware responsibility | Host/System responsibility |
|---|---|---|---|
| Control registers | Versioned, deterministic, documented by RTL collateral | Enforce write ordering and bounds | Provide valid values and sequencing |
| Policy/LUT blob | Version-tagged, integrity-checked | Validate before apply; reject incompatible schema | Produce blob matching target version |
| Status registers | Read-only from firmware perspective | Sample and expose without mutation | Consume snapshots and react |
| Fault registers | Sticky until cleared per policy | Preserve, report, and gate unsafe actions | Remediate root cause and request clear if permitted |
| Telemetry registers | Read-only, time-ordered if device supports it | Forward without reinterpretation | Use for diagnostics and health monitoring |

## Ownership boundaries

| Area | FW ownership | System/Host ownership | Validation ownership |
|---|---|---|---|
| Register map interpretation | Enforce contract and reject invalid access | Provide correct values and versioned blobs | Verify against RTL collateral |
| Policy/LUT loading | Execute device-side transaction logic | Supply compatible artifact | Confirm load/rollback behavior |
| Diagnostics reporting | Normalize and expose device status/faults | Consume and act on reports | Inject faults and check observability |
| Update control | Implement safe sequencing | Request updates and handle results | Exercise success/failure paths |
| Transport binding | Not owned in portable-only state | Owns platform transport selection and wrapper | Verify transport-specific integration |

## Assumptions
- RTL register collateral is authoritative for field names, access type, and reset behavior.
- Transport is not selected yet; firmware APIs are written to remain portable across the eventual host binding.
- No DMA semantics are defined in the provided scope.
- No boot-only contract is requested; this document covers the device-management integration contract.
- `ulx3s_ecp5_45f` is the selected board for target refinement, but board wrapper work remains incomplete.
- Firmware must not claim deployable readiness until `host_transport_and_board_wrapper` is implemented and validated.
- Error codes must be stable and documented before host integration begins.

## Validation hooks
- **Register conformance test:** compare firmware register access behavior against RTL collateral for every documented control/status/fault field.
- **Version gate test:** feed mismatched policy/LUT versions and confirm deterministic rejection with documented error code.
- **Atomic load test:** simulate interrupted policy/LUT transfer and verify no partial application is exposed as committed state.
- **Fault propagation test:** inject RTL faults and confirm firmware reports them without loss or reinterpretation.
- **Update control test:** exercise begin/commit/abort paths and confirm safe-state behavior on failure.
- **Compatibility test:** run older-compatible policy blobs against current firmware and confirm acceptance only within declared compatibility range.
- **Logging schema test:** verify diagnostics emitted by firmware match the agreed schema and include version, state, and fault context.
- **Transport readiness gate test:** ensure no deployable artifact is produced until host transport and board wrapper are present and validated.