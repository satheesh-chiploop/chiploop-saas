use core::ptr::{read_volatile, write_volatile};

pub const BASE_ADDRESS: usize = 0x00000000;

pub const CSR_CFG0_OFFSET: usize = 0x00000000;
pub const CSR_CFG0_MAX_VELOCITY_MPS_Q_SHIFT: u32 = 0;
pub const CSR_CFG0_MAX_VELOCITY_MPS_Q_WIDTH: u32 = 16;
pub const CSR_CFG0_MAX_VELOCITY_MPS_Q_MASK: u32 = 0x0000FFFF;
pub const CSR_CFG0_MIN_VELOCITY_MPS_Q_SHIFT: u32 = 16;
pub const CSR_CFG0_MIN_VELOCITY_MPS_Q_WIDTH: u32 = 16;
pub const CSR_CFG0_MIN_VELOCITY_MPS_Q_MASK: u32 = 0xFFFF0000;
pub const CSR_CFG0_ENABLE_HOST_INFERENCE_SHIFT: u32 = 32;
pub const CSR_CFG0_ENABLE_HOST_INFERENCE_WIDTH: u32 = 1;
pub const CSR_CFG0_ENABLE_HOST_INFERENCE_MASK: u32 = 0x100000000;
pub const CSR_CFG0_MODE_BITS_SHIFT: u32 = 33;
pub const CSR_CFG0_MODE_BITS_WIDTH: u32 = 4;
pub const CSR_CFG0_MODE_BITS_MASK: u32 = 0x1E00000000;
pub const CSR_CFG0_TRIGGER_REQ_SHIFT: u32 = 37;
pub const CSR_CFG0_TRIGGER_REQ_WIDTH: u32 = 1;
pub const CSR_CFG0_TRIGGER_REQ_MASK: u32 = 0x2000000000;
pub const CSR_CFG0_CLEAR_FAULTS_SHIFT: u32 = 38;
pub const CSR_CFG0_CLEAR_FAULTS_WIDTH: u32 = 1;
pub const CSR_CFG0_CLEAR_FAULTS_MASK: u32 = 0x4000000000;
pub const CSR_CFG0_CLEAR_PENDING_SHIFT: u32 = 39;
pub const CSR_CFG0_CLEAR_PENDING_WIDTH: u32 = 1;
pub const CSR_CFG0_CLEAR_PENDING_MASK: u32 = 0x8000000000;
pub const CSR_CFG0_RESERVED_SHIFT: u32 = 40;
pub const CSR_CFG0_RESERVED_WIDTH: u32 = 24;
pub const CSR_CFG0_RESERVED_MASK: u32 = 0xFFFFFF0000000000;
pub const CSR_CFG1_OFFSET: usize = 0x00000008;
pub const CSR_CFG1_RESPONSE_TIMEOUT_CYCLES_SHIFT: u32 = 0;
pub const CSR_CFG1_RESPONSE_TIMEOUT_CYCLES_WIDTH: u32 = 16;
pub const CSR_CFG1_RESPONSE_TIMEOUT_CYCLES_MASK: u32 = 0x0000FFFF;
pub const CSR_CFG1_FRESHNESS_TIMEOUT_CYCLES_SHIFT: u32 = 16;
pub const CSR_CFG1_FRESHNESS_TIMEOUT_CYCLES_WIDTH: u32 = 16;
pub const CSR_CFG1_FRESHNESS_TIMEOUT_CYCLES_MASK: u32 = 0xFFFF0000;
pub const CSR_CFG1_TIMEOUT_POLICY_STICKY_SHIFT: u32 = 32;
pub const CSR_CFG1_TIMEOUT_POLICY_STICKY_WIDTH: u32 = 1;
pub const CSR_CFG1_TIMEOUT_POLICY_STICKY_MASK: u32 = 0x100000000;
pub const CSR_CFG1_RESP_READY_ALWAYS_SHIFT: u32 = 33;
pub const CSR_CFG1_RESP_READY_ALWAYS_WIDTH: u32 = 1;
pub const CSR_CFG1_RESP_READY_ALWAYS_MASK: u32 = 0x200000000;
pub const CSR_CFG1_RESERVED_SHIFT: u32 = 34;
pub const CSR_CFG1_RESERVED_WIDTH: u32 = 30;
pub const CSR_CFG1_RESERVED_MASK: u32 = 0xFFFFFFFC00000000;
pub const CSR_CFG2_OFFSET: usize = 0x00000010;
pub const CSR_CFG2_ACTUATOR_MIN_CODE_SHIFT: u32 = 0;
pub const CSR_CFG2_ACTUATOR_MIN_CODE_WIDTH: u32 = 16;
pub const CSR_CFG2_ACTUATOR_MIN_CODE_MASK: u32 = 0x0000FFFF;
pub const CSR_CFG2_ACTUATOR_MAX_CODE_SHIFT: u32 = 16;
pub const CSR_CFG2_ACTUATOR_MAX_CODE_WIDTH: u32 = 16;
pub const CSR_CFG2_ACTUATOR_MAX_CODE_MASK: u32 = 0xFFFF0000;
pub const CSR_CFG2_SAFE_FALLBACK_CODE_SHIFT: u32 = 32;
pub const CSR_CFG2_SAFE_FALLBACK_CODE_WIDTH: u32 = 16;
pub const CSR_CFG2_SAFE_FALLBACK_CODE_MASK: u32 = 0xFFFF00000000;
pub const CSR_CFG2_BOUNDS_SIGNED_MODE_SHIFT: u32 = 48;
pub const CSR_CFG2_BOUNDS_SIGNED_MODE_WIDTH: u32 = 1;
pub const CSR_CFG2_BOUNDS_SIGNED_MODE_MASK: u32 = 0x1000000000000;
pub const CSR_CFG2_RESERVED_SHIFT: u32 = 49;
pub const CSR_CFG2_RESERVED_WIDTH: u32 = 15;
pub const CSR_CFG2_RESERVED_MASK: u32 = 0xFFFE000000000000;
pub const CSR_STATUS0_OFFSET: usize = 0x00000018;
pub const CSR_STATUS0_STATUS_BUSY_SHIFT: u32 = 0;
pub const CSR_STATUS0_STATUS_BUSY_WIDTH: u32 = 1;
pub const CSR_STATUS0_STATUS_BUSY_MASK: u32 = 0x00000001;
pub const CSR_STATUS0_STATUS_REQUEST_PENDING_SHIFT: u32 = 1;
pub const CSR_STATUS0_STATUS_REQUEST_PENDING_WIDTH: u32 = 1;
pub const CSR_STATUS0_STATUS_REQUEST_PENDING_MASK: u32 = 0x00000002;
pub const CSR_STATUS0_STATUS_RESPONSE_VALID_SHIFT: u32 = 2;
pub const CSR_STATUS0_STATUS_RESPONSE_VALID_WIDTH: u32 = 1;
pub const CSR_STATUS0_STATUS_RESPONSE_VALID_MASK: u32 = 0x00000004;
pub const CSR_STATUS0_STATUS_TIMEOUT_FAULT_SHIFT: u32 = 3;
pub const CSR_STATUS0_STATUS_TIMEOUT_FAULT_WIDTH: u32 = 1;
pub const CSR_STATUS0_STATUS_TIMEOUT_FAULT_MASK: u32 = 0x00000008;
pub const CSR_STATUS0_STATUS_STALE_FAULT_SHIFT: u32 = 4;
pub const CSR_STATUS0_STATUS_STALE_FAULT_WIDTH: u32 = 1;
pub const CSR_STATUS0_STATUS_STALE_FAULT_MASK: u32 = 0x00000010;
pub const CSR_STATUS0_STATUS_INTEGRITY_FAULT_SHIFT: u32 = 5;
pub const CSR_STATUS0_STATUS_INTEGRITY_FAULT_WIDTH: u32 = 1;
pub const CSR_STATUS0_STATUS_INTEGRITY_FAULT_MASK: u32 = 0x00000020;
pub const CSR_STATUS0_STATUS_FALLBACK_ACTIVE_SHIFT: u32 = 6;
pub const CSR_STATUS0_STATUS_FALLBACK_ACTIVE_WIDTH: u32 = 1;
pub const CSR_STATUS0_STATUS_FALLBACK_ACTIVE_MASK: u32 = 0x00000040;
pub const CSR_STATUS0_STATUS_APPLIED_CLAMPED_INDICATOR_SHIFT: u32 = 7;
pub const CSR_STATUS0_STATUS_APPLIED_CLAMPED_INDICATOR_WIDTH: u32 = 1;
pub const CSR_STATUS0_STATUS_APPLIED_CLAMPED_INDICATOR_MASK: u32 = 0x00000080;
pub const CSR_STATUS0_STATUS_LAST_SEQ_SHIFT: u32 = 8;
pub const CSR_STATUS0_STATUS_LAST_SEQ_WIDTH: u32 = 16;
pub const CSR_STATUS0_STATUS_LAST_SEQ_MASK: u32 = 0x00FFFF00;
pub const CSR_STATUS0_CURRENT_ACTUATOR_CMD_SHIFT: u32 = 24;
pub const CSR_STATUS0_CURRENT_ACTUATOR_CMD_WIDTH: u32 = 16;
pub const CSR_STATUS0_CURRENT_ACTUATOR_CMD_MASK: u32 = 0xFFFF000000;
pub const CSR_STATUS0_RESERVED_SHIFT: u32 = 40;
pub const CSR_STATUS0_RESERVED_WIDTH: u32 = 24;
pub const CSR_STATUS0_RESERVED_MASK: u32 = 0xFFFFFF0000000000;
pub const CSR_REQCAP0_OFFSET: usize = 0x00000020;
pub const CSR_REQCAP0_REQUEST_STREAM_VEL_Q_SHIFT: u32 = 0;
pub const CSR_REQCAP0_REQUEST_STREAM_VEL_Q_WIDTH: u32 = 16;
pub const CSR_REQCAP0_REQUEST_STREAM_VEL_Q_MASK: u32 = 0x0000FFFF;
pub const CSR_REQCAP0_REQUEST_GEOM_TOKEN_SHIFT: u32 = 16;
pub const CSR_REQCAP0_REQUEST_GEOM_TOKEN_WIDTH: u32 = 16;
pub const CSR_REQCAP0_REQUEST_GEOM_TOKEN_MASK: u32 = 0xFFFF0000;
pub const CSR_REQCAP0_REQUEST_AUX_BITS_SHIFT: u32 = 32;
pub const CSR_REQCAP0_REQUEST_AUX_BITS_WIDTH: u32 = 16;
pub const CSR_REQCAP0_REQUEST_AUX_BITS_MASK: u32 = 0xFFFF00000000;
pub const CSR_REQCAP0_REQUEST_INTEGRITY_SEED_SHIFT: u32 = 48;
pub const CSR_REQCAP0_REQUEST_INTEGRITY_SEED_WIDTH: u32 = 16;
pub const CSR_REQCAP0_REQUEST_INTEGRITY_SEED_MASK: u32 = 0xFFFF000000000000;
pub const CSR_REQSEQ_OFFSET: usize = 0x00000028;
pub const CSR_REQSEQ_REQUEST_SEQ_CURRENT_SHIFT: u32 = 0;
pub const CSR_REQSEQ_REQUEST_SEQ_CURRENT_WIDTH: u32 = 16;
pub const CSR_REQSEQ_REQUEST_SEQ_CURRENT_MASK: u32 = 0x0000FFFF;
pub const CSR_REQSEQ_LATEST_ACCEPTED_SEQ_SHIFT: u32 = 16;
pub const CSR_REQSEQ_LATEST_ACCEPTED_SEQ_WIDTH: u32 = 16;
pub const CSR_REQSEQ_LATEST_ACCEPTED_SEQ_MASK: u32 = 0xFFFF0000;
pub const CSR_REQSEQ_OUTSTANDING_SEQ_SHIFT: u32 = 32;
pub const CSR_REQSEQ_OUTSTANDING_SEQ_WIDTH: u32 = 16;
pub const CSR_REQSEQ_OUTSTANDING_SEQ_MASK: u32 = 0xFFFF00000000;
pub const CSR_REQSEQ_RESERVED_SHIFT: u32 = 48;
pub const CSR_REQSEQ_RESERVED_WIDTH: u32 = 16;
pub const CSR_REQSEQ_RESERVED_MASK: u32 = 0xFFFF000000000000;
pub const CSR_HOST_TX_OFFSET: usize = 0x00000030;
pub const CSR_HOST_TX_TX_PACKET_SHIFT: u32 = 0;
pub const CSR_HOST_TX_TX_PACKET_WIDTH: u32 = 64;
pub const CSR_HOST_TX_TX_PACKET_MASK: u32 = 0xFFFF_FFFF;
pub const CSR_HOST_RX_OFFSET: usize = 0x00000038;
pub const CSR_HOST_RX_RX_PACKET_SHIFT: u32 = 0;
pub const CSR_HOST_RX_RX_PACKET_WIDTH: u32 = 64;
pub const CSR_HOST_RX_RX_PACKET_MASK: u32 = 0xFFFF_FFFF;
pub const CSR_W1C_STATUS_OFFSET: usize = 0x00000040;
pub const CSR_W1C_STATUS_CLEAR_TIMEOUT_FAULT_SHIFT: u32 = 0;
pub const CSR_W1C_STATUS_CLEAR_TIMEOUT_FAULT_WIDTH: u32 = 1;
pub const CSR_W1C_STATUS_CLEAR_TIMEOUT_FAULT_MASK: u32 = 0x00000001;
pub const CSR_W1C_STATUS_CLEAR_STALE_FAULT_SHIFT: u32 = 1;
pub const CSR_W1C_STATUS_CLEAR_STALE_FAULT_WIDTH: u32 = 1;
pub const CSR_W1C_STATUS_CLEAR_STALE_FAULT_MASK: u32 = 0x00000002;
pub const CSR_W1C_STATUS_CLEAR_INTEGRITY_FAULT_SHIFT: u32 = 2;
pub const CSR_W1C_STATUS_CLEAR_INTEGRITY_FAULT_WIDTH: u32 = 1;
pub const CSR_W1C_STATUS_CLEAR_INTEGRITY_FAULT_MASK: u32 = 0x00000004;
pub const CSR_W1C_STATUS_CLEAR_FALLBACK_ACTIVE_SHIFT: u32 = 3;
pub const CSR_W1C_STATUS_CLEAR_FALLBACK_ACTIVE_WIDTH: u32 = 1;
pub const CSR_W1C_STATUS_CLEAR_FALLBACK_ACTIVE_MASK: u32 = 0x00000008;
pub const CSR_W1C_STATUS_CLEAR_REQUEST_PENDING_SHIFT: u32 = 4;
pub const CSR_W1C_STATUS_CLEAR_REQUEST_PENDING_WIDTH: u32 = 1;
pub const CSR_W1C_STATUS_CLEAR_REQUEST_PENDING_MASK: u32 = 0x00000010;
pub const CSR_W1C_STATUS_RESERVED_SHIFT: u32 = 5;
pub const CSR_W1C_STATUS_RESERVED_WIDTH: u32 = 59;
pub const CSR_W1C_STATUS_RESERVED_MASK: u32 = 0xFFFF_FFFF;

#[inline]
fn reg_ptr(offset: usize) -> *mut u32 {
    (BASE_ADDRESS + offset) as *mut u32
}

#[inline]
fn read_reg(offset: usize) -> u32 {
    unsafe { read_volatile(reg_ptr(offset) as *const u32) }
}

#[inline]
fn write_reg(offset: usize, value: u32) {
    unsafe { write_volatile(reg_ptr(offset), value) }
}

#[inline]
pub fn read_csr_cfg0() -> u32 {
    read_reg(CSR_CFG0_OFFSET)
}

#[inline]
pub fn write_csr_cfg0(value: u32) {
    write_reg(CSR_CFG0_OFFSET, value)
}

#[inline]
pub fn get_csr_cfg0_max_velocity_mps_q() -> u32 {
    (read_csr_cfg0() & CSR_CFG0_MAX_VELOCITY_MPS_Q_MASK) >> CSR_CFG0_MAX_VELOCITY_MPS_Q_SHIFT
}

#[inline]
pub fn set_csr_cfg0_max_velocity_mps_q(value: u32) {
    let current = read_csr_cfg0();
    let next = (current & !CSR_CFG0_MAX_VELOCITY_MPS_Q_MASK) | ((value << CSR_CFG0_MAX_VELOCITY_MPS_Q_SHIFT) & CSR_CFG0_MAX_VELOCITY_MPS_Q_MASK);
    write_csr_cfg0(next);
}

#[inline]
pub fn get_csr_cfg0_min_velocity_mps_q() -> u32 {
    (read_csr_cfg0() & CSR_CFG0_MIN_VELOCITY_MPS_Q_MASK) >> CSR_CFG0_MIN_VELOCITY_MPS_Q_SHIFT
}

#[inline]
pub fn set_csr_cfg0_min_velocity_mps_q(value: u32) {
    let current = read_csr_cfg0();
    let next = (current & !CSR_CFG0_MIN_VELOCITY_MPS_Q_MASK) | ((value << CSR_CFG0_MIN_VELOCITY_MPS_Q_SHIFT) & CSR_CFG0_MIN_VELOCITY_MPS_Q_MASK);
    write_csr_cfg0(next);
}

#[inline]
pub fn get_csr_cfg0_enable_host_inference() -> u32 {
    (read_csr_cfg0() & CSR_CFG0_ENABLE_HOST_INFERENCE_MASK) >> CSR_CFG0_ENABLE_HOST_INFERENCE_SHIFT
}

#[inline]
pub fn set_csr_cfg0_enable_host_inference(value: u32) {
    let current = read_csr_cfg0();
    let next = (current & !CSR_CFG0_ENABLE_HOST_INFERENCE_MASK) | ((value << CSR_CFG0_ENABLE_HOST_INFERENCE_SHIFT) & CSR_CFG0_ENABLE_HOST_INFERENCE_MASK);
    write_csr_cfg0(next);
}

#[inline]
pub fn get_csr_cfg0_mode_bits() -> u32 {
    (read_csr_cfg0() & CSR_CFG0_MODE_BITS_MASK) >> CSR_CFG0_MODE_BITS_SHIFT
}

#[inline]
pub fn set_csr_cfg0_mode_bits(value: u32) {
    let current = read_csr_cfg0();
    let next = (current & !CSR_CFG0_MODE_BITS_MASK) | ((value << CSR_CFG0_MODE_BITS_SHIFT) & CSR_CFG0_MODE_BITS_MASK);
    write_csr_cfg0(next);
}

#[inline]
pub fn get_csr_cfg0_trigger_req() -> u32 {
    (read_csr_cfg0() & CSR_CFG0_TRIGGER_REQ_MASK) >> CSR_CFG0_TRIGGER_REQ_SHIFT
}

#[inline]
pub fn set_csr_cfg0_trigger_req(value: u32) {
    let current = read_csr_cfg0();
    let next = (current & !CSR_CFG0_TRIGGER_REQ_MASK) | ((value << CSR_CFG0_TRIGGER_REQ_SHIFT) & CSR_CFG0_TRIGGER_REQ_MASK);
    write_csr_cfg0(next);
}

#[inline]
pub fn get_csr_cfg0_clear_faults() -> u32 {
    (read_csr_cfg0() & CSR_CFG0_CLEAR_FAULTS_MASK) >> CSR_CFG0_CLEAR_FAULTS_SHIFT
}

#[inline]
pub fn set_csr_cfg0_clear_faults(value: u32) {
    let current = read_csr_cfg0();
    let next = (current & !CSR_CFG0_CLEAR_FAULTS_MASK) | ((value << CSR_CFG0_CLEAR_FAULTS_SHIFT) & CSR_CFG0_CLEAR_FAULTS_MASK);
    write_csr_cfg0(next);
}

#[inline]
pub fn get_csr_cfg0_clear_pending() -> u32 {
    (read_csr_cfg0() & CSR_CFG0_CLEAR_PENDING_MASK) >> CSR_CFG0_CLEAR_PENDING_SHIFT
}

#[inline]
pub fn set_csr_cfg0_clear_pending(value: u32) {
    let current = read_csr_cfg0();
    let next = (current & !CSR_CFG0_CLEAR_PENDING_MASK) | ((value << CSR_CFG0_CLEAR_PENDING_SHIFT) & CSR_CFG0_CLEAR_PENDING_MASK);
    write_csr_cfg0(next);
}

#[inline]
pub fn get_csr_cfg0_reserved() -> u32 {
    (read_csr_cfg0() & CSR_CFG0_RESERVED_MASK) >> CSR_CFG0_RESERVED_SHIFT
}

#[inline]
pub fn read_csr_cfg1() -> u32 {
    read_reg(CSR_CFG1_OFFSET)
}

#[inline]
pub fn write_csr_cfg1(value: u32) {
    write_reg(CSR_CFG1_OFFSET, value)
}

#[inline]
pub fn get_csr_cfg1_response_timeout_cycles() -> u32 {
    (read_csr_cfg1() & CSR_CFG1_RESPONSE_TIMEOUT_CYCLES_MASK) >> CSR_CFG1_RESPONSE_TIMEOUT_CYCLES_SHIFT
}

#[inline]
pub fn set_csr_cfg1_response_timeout_cycles(value: u32) {
    let current = read_csr_cfg1();
    let next = (current & !CSR_CFG1_RESPONSE_TIMEOUT_CYCLES_MASK) | ((value << CSR_CFG1_RESPONSE_TIMEOUT_CYCLES_SHIFT) & CSR_CFG1_RESPONSE_TIMEOUT_CYCLES_MASK);
    write_csr_cfg1(next);
}

#[inline]
pub fn get_csr_cfg1_freshness_timeout_cycles() -> u32 {
    (read_csr_cfg1() & CSR_CFG1_FRESHNESS_TIMEOUT_CYCLES_MASK) >> CSR_CFG1_FRESHNESS_TIMEOUT_CYCLES_SHIFT
}

#[inline]
pub fn set_csr_cfg1_freshness_timeout_cycles(value: u32) {
    let current = read_csr_cfg1();
    let next = (current & !CSR_CFG1_FRESHNESS_TIMEOUT_CYCLES_MASK) | ((value << CSR_CFG1_FRESHNESS_TIMEOUT_CYCLES_SHIFT) & CSR_CFG1_FRESHNESS_TIMEOUT_CYCLES_MASK);
    write_csr_cfg1(next);
}

#[inline]
pub fn get_csr_cfg1_timeout_policy_sticky() -> u32 {
    (read_csr_cfg1() & CSR_CFG1_TIMEOUT_POLICY_STICKY_MASK) >> CSR_CFG1_TIMEOUT_POLICY_STICKY_SHIFT
}

#[inline]
pub fn set_csr_cfg1_timeout_policy_sticky(value: u32) {
    let current = read_csr_cfg1();
    let next = (current & !CSR_CFG1_TIMEOUT_POLICY_STICKY_MASK) | ((value << CSR_CFG1_TIMEOUT_POLICY_STICKY_SHIFT) & CSR_CFG1_TIMEOUT_POLICY_STICKY_MASK);
    write_csr_cfg1(next);
}

#[inline]
pub fn get_csr_cfg1_resp_ready_always() -> u32 {
    (read_csr_cfg1() & CSR_CFG1_RESP_READY_ALWAYS_MASK) >> CSR_CFG1_RESP_READY_ALWAYS_SHIFT
}

#[inline]
pub fn set_csr_cfg1_resp_ready_always(value: u32) {
    let current = read_csr_cfg1();
    let next = (current & !CSR_CFG1_RESP_READY_ALWAYS_MASK) | ((value << CSR_CFG1_RESP_READY_ALWAYS_SHIFT) & CSR_CFG1_RESP_READY_ALWAYS_MASK);
    write_csr_cfg1(next);
}

#[inline]
pub fn get_csr_cfg1_reserved() -> u32 {
    (read_csr_cfg1() & CSR_CFG1_RESERVED_MASK) >> CSR_CFG1_RESERVED_SHIFT
}

#[inline]
pub fn read_csr_cfg2() -> u32 {
    read_reg(CSR_CFG2_OFFSET)
}

#[inline]
pub fn write_csr_cfg2(value: u32) {
    write_reg(CSR_CFG2_OFFSET, value)
}

#[inline]
pub fn get_csr_cfg2_actuator_min_code() -> u32 {
    (read_csr_cfg2() & CSR_CFG2_ACTUATOR_MIN_CODE_MASK) >> CSR_CFG2_ACTUATOR_MIN_CODE_SHIFT
}

#[inline]
pub fn set_csr_cfg2_actuator_min_code(value: u32) {
    let current = read_csr_cfg2();
    let next = (current & !CSR_CFG2_ACTUATOR_MIN_CODE_MASK) | ((value << CSR_CFG2_ACTUATOR_MIN_CODE_SHIFT) & CSR_CFG2_ACTUATOR_MIN_CODE_MASK);
    write_csr_cfg2(next);
}

#[inline]
pub fn get_csr_cfg2_actuator_max_code() -> u32 {
    (read_csr_cfg2() & CSR_CFG2_ACTUATOR_MAX_CODE_MASK) >> CSR_CFG2_ACTUATOR_MAX_CODE_SHIFT
}

#[inline]
pub fn set_csr_cfg2_actuator_max_code(value: u32) {
    let current = read_csr_cfg2();
    let next = (current & !CSR_CFG2_ACTUATOR_MAX_CODE_MASK) | ((value << CSR_CFG2_ACTUATOR_MAX_CODE_SHIFT) & CSR_CFG2_ACTUATOR_MAX_CODE_MASK);
    write_csr_cfg2(next);
}

#[inline]
pub fn get_csr_cfg2_safe_fallback_code() -> u32 {
    (read_csr_cfg2() & CSR_CFG2_SAFE_FALLBACK_CODE_MASK) >> CSR_CFG2_SAFE_FALLBACK_CODE_SHIFT
}

#[inline]
pub fn set_csr_cfg2_safe_fallback_code(value: u32) {
    let current = read_csr_cfg2();
    let next = (current & !CSR_CFG2_SAFE_FALLBACK_CODE_MASK) | ((value << CSR_CFG2_SAFE_FALLBACK_CODE_SHIFT) & CSR_CFG2_SAFE_FALLBACK_CODE_MASK);
    write_csr_cfg2(next);
}

#[inline]
pub fn get_csr_cfg2_bounds_signed_mode() -> u32 {
    (read_csr_cfg2() & CSR_CFG2_BOUNDS_SIGNED_MODE_MASK) >> CSR_CFG2_BOUNDS_SIGNED_MODE_SHIFT
}

#[inline]
pub fn set_csr_cfg2_bounds_signed_mode(value: u32) {
    let current = read_csr_cfg2();
    let next = (current & !CSR_CFG2_BOUNDS_SIGNED_MODE_MASK) | ((value << CSR_CFG2_BOUNDS_SIGNED_MODE_SHIFT) & CSR_CFG2_BOUNDS_SIGNED_MODE_MASK);
    write_csr_cfg2(next);
}

#[inline]
pub fn get_csr_cfg2_reserved() -> u32 {
    (read_csr_cfg2() & CSR_CFG2_RESERVED_MASK) >> CSR_CFG2_RESERVED_SHIFT
}

#[inline]
pub fn read_csr_status0() -> u32 {
    read_reg(CSR_STATUS0_OFFSET)
}

#[inline]
pub fn get_csr_status0_status_busy() -> u32 {
    (read_csr_status0() & CSR_STATUS0_STATUS_BUSY_MASK) >> CSR_STATUS0_STATUS_BUSY_SHIFT
}

#[inline]
pub fn get_csr_status0_status_request_pending() -> u32 {
    (read_csr_status0() & CSR_STATUS0_STATUS_REQUEST_PENDING_MASK) >> CSR_STATUS0_STATUS_REQUEST_PENDING_SHIFT
}

#[inline]
pub fn get_csr_status0_status_response_valid() -> u32 {
    (read_csr_status0() & CSR_STATUS0_STATUS_RESPONSE_VALID_MASK) >> CSR_STATUS0_STATUS_RESPONSE_VALID_SHIFT
}

#[inline]
pub fn get_csr_status0_status_timeout_fault() -> u32 {
    (read_csr_status0() & CSR_STATUS0_STATUS_TIMEOUT_FAULT_MASK) >> CSR_STATUS0_STATUS_TIMEOUT_FAULT_SHIFT
}

#[inline]
pub fn get_csr_status0_status_stale_fault() -> u32 {
    (read_csr_status0() & CSR_STATUS0_STATUS_STALE_FAULT_MASK) >> CSR_STATUS0_STATUS_STALE_FAULT_SHIFT
}

#[inline]
pub fn get_csr_status0_status_integrity_fault() -> u32 {
    (read_csr_status0() & CSR_STATUS0_STATUS_INTEGRITY_FAULT_MASK) >> CSR_STATUS0_STATUS_INTEGRITY_FAULT_SHIFT
}

#[inline]
pub fn get_csr_status0_status_fallback_active() -> u32 {
    (read_csr_status0() & CSR_STATUS0_STATUS_FALLBACK_ACTIVE_MASK) >> CSR_STATUS0_STATUS_FALLBACK_ACTIVE_SHIFT
}

#[inline]
pub fn get_csr_status0_status_applied_clamped_indicator() -> u32 {
    (read_csr_status0() & CSR_STATUS0_STATUS_APPLIED_CLAMPED_INDICATOR_MASK) >> CSR_STATUS0_STATUS_APPLIED_CLAMPED_INDICATOR_SHIFT
}

#[inline]
pub fn get_csr_status0_status_last_seq() -> u32 {
    (read_csr_status0() & CSR_STATUS0_STATUS_LAST_SEQ_MASK) >> CSR_STATUS0_STATUS_LAST_SEQ_SHIFT
}

#[inline]
pub fn get_csr_status0_current_actuator_cmd() -> u32 {
    (read_csr_status0() & CSR_STATUS0_CURRENT_ACTUATOR_CMD_MASK) >> CSR_STATUS0_CURRENT_ACTUATOR_CMD_SHIFT
}

#[inline]
pub fn get_csr_status0_reserved() -> u32 {
    (read_csr_status0() & CSR_STATUS0_RESERVED_MASK) >> CSR_STATUS0_RESERVED_SHIFT
}

#[inline]
pub fn read_csr_reqcap0() -> u32 {
    read_reg(CSR_REQCAP0_OFFSET)
}

#[inline]
pub fn write_csr_reqcap0(value: u32) {
    write_reg(CSR_REQCAP0_OFFSET, value)
}

#[inline]
pub fn get_csr_reqcap0_request_stream_vel_q() -> u32 {
    (read_csr_reqcap0() & CSR_REQCAP0_REQUEST_STREAM_VEL_Q_MASK) >> CSR_REQCAP0_REQUEST_STREAM_VEL_Q_SHIFT
}

#[inline]
pub fn set_csr_reqcap0_request_stream_vel_q(value: u32) {
    let current = read_csr_reqcap0();
    let next = (current & !CSR_REQCAP0_REQUEST_STREAM_VEL_Q_MASK) | ((value << CSR_REQCAP0_REQUEST_STREAM_VEL_Q_SHIFT) & CSR_REQCAP0_REQUEST_STREAM_VEL_Q_MASK);
    write_csr_reqcap0(next);
}

#[inline]
pub fn get_csr_reqcap0_request_geom_token() -> u32 {
    (read_csr_reqcap0() & CSR_REQCAP0_REQUEST_GEOM_TOKEN_MASK) >> CSR_REQCAP0_REQUEST_GEOM_TOKEN_SHIFT
}

#[inline]
pub fn set_csr_reqcap0_request_geom_token(value: u32) {
    let current = read_csr_reqcap0();
    let next = (current & !CSR_REQCAP0_REQUEST_GEOM_TOKEN_MASK) | ((value << CSR_REQCAP0_REQUEST_GEOM_TOKEN_SHIFT) & CSR_REQCAP0_REQUEST_GEOM_TOKEN_MASK);
    write_csr_reqcap0(next);
}

#[inline]
pub fn get_csr_reqcap0_request_aux_bits() -> u32 {
    (read_csr_reqcap0() & CSR_REQCAP0_REQUEST_AUX_BITS_MASK) >> CSR_REQCAP0_REQUEST_AUX_BITS_SHIFT
}

#[inline]
pub fn set_csr_reqcap0_request_aux_bits(value: u32) {
    let current = read_csr_reqcap0();
    let next = (current & !CSR_REQCAP0_REQUEST_AUX_BITS_MASK) | ((value << CSR_REQCAP0_REQUEST_AUX_BITS_SHIFT) & CSR_REQCAP0_REQUEST_AUX_BITS_MASK);
    write_csr_reqcap0(next);
}

#[inline]
pub fn get_csr_reqcap0_request_integrity_seed() -> u32 {
    (read_csr_reqcap0() & CSR_REQCAP0_REQUEST_INTEGRITY_SEED_MASK) >> CSR_REQCAP0_REQUEST_INTEGRITY_SEED_SHIFT
}

#[inline]
pub fn set_csr_reqcap0_request_integrity_seed(value: u32) {
    let current = read_csr_reqcap0();
    let next = (current & !CSR_REQCAP0_REQUEST_INTEGRITY_SEED_MASK) | ((value << CSR_REQCAP0_REQUEST_INTEGRITY_SEED_SHIFT) & CSR_REQCAP0_REQUEST_INTEGRITY_SEED_MASK);
    write_csr_reqcap0(next);
}

#[inline]
pub fn read_csr_reqseq() -> u32 {
    read_reg(CSR_REQSEQ_OFFSET)
}

#[inline]
pub fn get_csr_reqseq_request_seq_current() -> u32 {
    (read_csr_reqseq() & CSR_REQSEQ_REQUEST_SEQ_CURRENT_MASK) >> CSR_REQSEQ_REQUEST_SEQ_CURRENT_SHIFT
}

#[inline]
pub fn get_csr_reqseq_latest_accepted_seq() -> u32 {
    (read_csr_reqseq() & CSR_REQSEQ_LATEST_ACCEPTED_SEQ_MASK) >> CSR_REQSEQ_LATEST_ACCEPTED_SEQ_SHIFT
}

#[inline]
pub fn get_csr_reqseq_outstanding_seq() -> u32 {
    (read_csr_reqseq() & CSR_REQSEQ_OUTSTANDING_SEQ_MASK) >> CSR_REQSEQ_OUTSTANDING_SEQ_SHIFT
}

#[inline]
pub fn get_csr_reqseq_reserved() -> u32 {
    (read_csr_reqseq() & CSR_REQSEQ_RESERVED_MASK) >> CSR_REQSEQ_RESERVED_SHIFT
}

#[inline]
pub fn read_csr_host_tx() -> u32 {
    read_reg(CSR_HOST_TX_OFFSET)
}

#[inline]
pub fn get_csr_host_tx_tx_packet() -> u32 {
    (read_csr_host_tx() & CSR_HOST_TX_TX_PACKET_MASK) >> CSR_HOST_TX_TX_PACKET_SHIFT
}

#[inline]
pub fn read_csr_host_rx() -> u32 {
    read_reg(CSR_HOST_RX_OFFSET)
}

#[inline]
pub fn get_csr_host_rx_rx_packet() -> u32 {
    (read_csr_host_rx() & CSR_HOST_RX_RX_PACKET_MASK) >> CSR_HOST_RX_RX_PACKET_SHIFT
}

#[inline]
pub fn read_csr_w1c_status() -> u32 {
    read_reg(CSR_W1C_STATUS_OFFSET)
}

#[inline]
pub fn write_csr_w1c_status(value: u32) {
    write_reg(CSR_W1C_STATUS_OFFSET, value)
}

#[inline]
pub fn get_csr_w1c_status_clear_timeout_fault() -> u32 {
    (read_csr_w1c_status() & CSR_W1C_STATUS_CLEAR_TIMEOUT_FAULT_MASK) >> CSR_W1C_STATUS_CLEAR_TIMEOUT_FAULT_SHIFT
}

#[inline]
pub fn set_csr_w1c_status_clear_timeout_fault(value: u32) {
    let current = read_csr_w1c_status();
    let next = (current & !CSR_W1C_STATUS_CLEAR_TIMEOUT_FAULT_MASK) | ((value << CSR_W1C_STATUS_CLEAR_TIMEOUT_FAULT_SHIFT) & CSR_W1C_STATUS_CLEAR_TIMEOUT_FAULT_MASK);
    write_csr_w1c_status(next);
}

#[inline]
pub fn get_csr_w1c_status_clear_stale_fault() -> u32 {
    (read_csr_w1c_status() & CSR_W1C_STATUS_CLEAR_STALE_FAULT_MASK) >> CSR_W1C_STATUS_CLEAR_STALE_FAULT_SHIFT
}

#[inline]
pub fn set_csr_w1c_status_clear_stale_fault(value: u32) {
    let current = read_csr_w1c_status();
    let next = (current & !CSR_W1C_STATUS_CLEAR_STALE_FAULT_MASK) | ((value << CSR_W1C_STATUS_CLEAR_STALE_FAULT_SHIFT) & CSR_W1C_STATUS_CLEAR_STALE_FAULT_MASK);
    write_csr_w1c_status(next);
}

#[inline]
pub fn get_csr_w1c_status_clear_integrity_fault() -> u32 {
    (read_csr_w1c_status() & CSR_W1C_STATUS_CLEAR_INTEGRITY_FAULT_MASK) >> CSR_W1C_STATUS_CLEAR_INTEGRITY_FAULT_SHIFT
}

#[inline]
pub fn set_csr_w1c_status_clear_integrity_fault(value: u32) {
    let current = read_csr_w1c_status();
    let next = (current & !CSR_W1C_STATUS_CLEAR_INTEGRITY_FAULT_MASK) | ((value << CSR_W1C_STATUS_CLEAR_INTEGRITY_FAULT_SHIFT) & CSR_W1C_STATUS_CLEAR_INTEGRITY_FAULT_MASK);
    write_csr_w1c_status(next);
}

#[inline]
pub fn get_csr_w1c_status_clear_fallback_active() -> u32 {
    (read_csr_w1c_status() & CSR_W1C_STATUS_CLEAR_FALLBACK_ACTIVE_MASK) >> CSR_W1C_STATUS_CLEAR_FALLBACK_ACTIVE_SHIFT
}

#[inline]
pub fn set_csr_w1c_status_clear_fallback_active(value: u32) {
    let current = read_csr_w1c_status();
    let next = (current & !CSR_W1C_STATUS_CLEAR_FALLBACK_ACTIVE_MASK) | ((value << CSR_W1C_STATUS_CLEAR_FALLBACK_ACTIVE_SHIFT) & CSR_W1C_STATUS_CLEAR_FALLBACK_ACTIVE_MASK);
    write_csr_w1c_status(next);
}

#[inline]
pub fn get_csr_w1c_status_clear_request_pending() -> u32 {
    (read_csr_w1c_status() & CSR_W1C_STATUS_CLEAR_REQUEST_PENDING_MASK) >> CSR_W1C_STATUS_CLEAR_REQUEST_PENDING_SHIFT
}

#[inline]
pub fn set_csr_w1c_status_clear_request_pending(value: u32) {
    let current = read_csr_w1c_status();
    let next = (current & !CSR_W1C_STATUS_CLEAR_REQUEST_PENDING_MASK) | ((value << CSR_W1C_STATUS_CLEAR_REQUEST_PENDING_SHIFT) & CSR_W1C_STATUS_CLEAR_REQUEST_PENDING_MASK);
    write_csr_w1c_status(next);
}

#[inline]
pub fn get_csr_w1c_status_reserved() -> u32 {
    (read_csr_w1c_status() & CSR_W1C_STATUS_RESERVED_MASK) >> CSR_W1C_STATUS_RESERVED_SHIFT
}

