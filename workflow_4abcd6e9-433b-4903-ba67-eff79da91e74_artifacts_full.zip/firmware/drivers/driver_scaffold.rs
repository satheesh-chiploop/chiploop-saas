use crate::hal::registers::*;

pub struct DigitalSubsystemDriver;

impl DigitalSubsystemDriver {
    #[inline]
    pub const fn new() -> Self {
        Self
    }

    #[inline]
    pub fn read_csr_cfg0(&self) -> u32 {
        read_csr_cfg0()
    }

    #[inline]
    pub fn write_csr_cfg0(&self, value: u32) {
        write_csr_cfg0(value)
    }

    #[inline]
    pub fn get_csr_cfg0_max_velocity_mps_q(&self) -> u16 {
        get_csr_cfg0_max_velocity_mps_q() as u16
    }

    #[inline]
    pub fn set_csr_cfg0_max_velocity_mps_q(&self, value: u16) {
        set_csr_cfg0_max_velocity_mps_q(value as u32)
    }

    #[inline]
    pub fn get_csr_cfg0_min_velocity_mps_q(&self) -> u16 {
        get_csr_cfg0_min_velocity_mps_q() as u16
    }

    #[inline]
    pub fn set_csr_cfg0_min_velocity_mps_q(&self, value: u16) {
        set_csr_cfg0_min_velocity_mps_q(value as u32)
    }

    #[inline]
    pub fn get_csr_cfg0_enable_host_inference(&self) -> bool {
        get_csr_cfg0_enable_host_inference() != 0
    }

    #[inline]
    pub fn set_csr_cfg0_enable_host_inference(&self, value: bool) {
        set_csr_cfg0_enable_host_inference(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_csr_cfg0_mode_bits(&self) -> u8 {
        get_csr_cfg0_mode_bits() as u8
    }

    #[inline]
    pub fn set_csr_cfg0_mode_bits(&self, value: u8) {
        set_csr_cfg0_mode_bits(value as u32)
    }

    #[inline]
    pub fn get_csr_cfg0_trigger_req(&self) -> bool {
        get_csr_cfg0_trigger_req() != 0
    }

    #[inline]
    pub fn set_csr_cfg0_trigger_req(&self, value: bool) {
        set_csr_cfg0_trigger_req(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_csr_cfg0_clear_faults(&self) -> bool {
        get_csr_cfg0_clear_faults() != 0
    }

    #[inline]
    pub fn set_csr_cfg0_clear_faults(&self, value: bool) {
        set_csr_cfg0_clear_faults(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_csr_cfg0_clear_pending(&self) -> bool {
        get_csr_cfg0_clear_pending() != 0
    }

    #[inline]
    pub fn set_csr_cfg0_clear_pending(&self, value: bool) {
        set_csr_cfg0_clear_pending(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_csr_cfg0_reserved(&self) -> u32 {
        get_csr_cfg0_reserved() as u32
    }

    #[inline]
    pub fn read_csr_cfg1(&self) -> u32 {
        read_csr_cfg1()
    }

    #[inline]
    pub fn write_csr_cfg1(&self, value: u32) {
        write_csr_cfg1(value)
    }

    #[inline]
    pub fn get_csr_cfg1_response_timeout_cycles(&self) -> u16 {
        get_csr_cfg1_response_timeout_cycles() as u16
    }

    #[inline]
    pub fn set_csr_cfg1_response_timeout_cycles(&self, value: u16) {
        set_csr_cfg1_response_timeout_cycles(value as u32)
    }

    #[inline]
    pub fn get_csr_cfg1_freshness_timeout_cycles(&self) -> u16 {
        get_csr_cfg1_freshness_timeout_cycles() as u16
    }

    #[inline]
    pub fn set_csr_cfg1_freshness_timeout_cycles(&self, value: u16) {
        set_csr_cfg1_freshness_timeout_cycles(value as u32)
    }

    #[inline]
    pub fn get_csr_cfg1_timeout_policy_sticky(&self) -> bool {
        get_csr_cfg1_timeout_policy_sticky() != 0
    }

    #[inline]
    pub fn set_csr_cfg1_timeout_policy_sticky(&self, value: bool) {
        set_csr_cfg1_timeout_policy_sticky(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_csr_cfg1_resp_ready_always(&self) -> bool {
        get_csr_cfg1_resp_ready_always() != 0
    }

    #[inline]
    pub fn set_csr_cfg1_resp_ready_always(&self, value: bool) {
        set_csr_cfg1_resp_ready_always(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_csr_cfg1_reserved(&self) -> u32 {
        get_csr_cfg1_reserved() as u32
    }

    #[inline]
    pub fn read_csr_cfg2(&self) -> u32 {
        read_csr_cfg2()
    }

    #[inline]
    pub fn write_csr_cfg2(&self, value: u32) {
        write_csr_cfg2(value)
    }

    #[inline]
    pub fn get_csr_cfg2_actuator_min_code(&self) -> u16 {
        get_csr_cfg2_actuator_min_code() as u16
    }

    #[inline]
    pub fn set_csr_cfg2_actuator_min_code(&self, value: u16) {
        set_csr_cfg2_actuator_min_code(value as u32)
    }

    #[inline]
    pub fn get_csr_cfg2_actuator_max_code(&self) -> u16 {
        get_csr_cfg2_actuator_max_code() as u16
    }

    #[inline]
    pub fn set_csr_cfg2_actuator_max_code(&self, value: u16) {
        set_csr_cfg2_actuator_max_code(value as u32)
    }

    #[inline]
    pub fn get_csr_cfg2_safe_fallback_code(&self) -> u16 {
        get_csr_cfg2_safe_fallback_code() as u16
    }

    #[inline]
    pub fn set_csr_cfg2_safe_fallback_code(&self, value: u16) {
        set_csr_cfg2_safe_fallback_code(value as u32)
    }

    #[inline]
    pub fn get_csr_cfg2_bounds_signed_mode(&self) -> bool {
        get_csr_cfg2_bounds_signed_mode() != 0
    }

    #[inline]
    pub fn set_csr_cfg2_bounds_signed_mode(&self, value: bool) {
        set_csr_cfg2_bounds_signed_mode(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_csr_cfg2_reserved(&self) -> u16 {
        get_csr_cfg2_reserved() as u16
    }

    #[inline]
    pub fn read_csr_status0(&self) -> u32 {
        read_csr_status0()
    }

    #[inline]
    pub fn get_csr_status0_status_busy(&self) -> bool {
        get_csr_status0_status_busy() != 0
    }

    #[inline]
    pub fn get_csr_status0_status_request_pending(&self) -> bool {
        get_csr_status0_status_request_pending() != 0
    }

    #[inline]
    pub fn get_csr_status0_status_response_valid(&self) -> bool {
        get_csr_status0_status_response_valid() != 0
    }

    #[inline]
    pub fn get_csr_status0_status_timeout_fault(&self) -> bool {
        get_csr_status0_status_timeout_fault() != 0
    }

    #[inline]
    pub fn get_csr_status0_status_stale_fault(&self) -> bool {
        get_csr_status0_status_stale_fault() != 0
    }

    #[inline]
    pub fn get_csr_status0_status_integrity_fault(&self) -> bool {
        get_csr_status0_status_integrity_fault() != 0
    }

    #[inline]
    pub fn get_csr_status0_status_fallback_active(&self) -> bool {
        get_csr_status0_status_fallback_active() != 0
    }

    #[inline]
    pub fn get_csr_status0_status_applied_clamped_indicator(&self) -> bool {
        get_csr_status0_status_applied_clamped_indicator() != 0
    }

    #[inline]
    pub fn get_csr_status0_status_last_seq(&self) -> u16 {
        get_csr_status0_status_last_seq() as u16
    }

    #[inline]
    pub fn get_csr_status0_current_actuator_cmd(&self) -> u16 {
        get_csr_status0_current_actuator_cmd() as u16
    }

    #[inline]
    pub fn get_csr_status0_reserved(&self) -> u32 {
        get_csr_status0_reserved() as u32
    }

    #[inline]
    pub fn read_csr_reqcap0(&self) -> u32 {
        read_csr_reqcap0()
    }

    #[inline]
    pub fn write_csr_reqcap0(&self, value: u32) {
        write_csr_reqcap0(value)
    }

    #[inline]
    pub fn get_csr_reqcap0_request_stream_vel_q(&self) -> u16 {
        get_csr_reqcap0_request_stream_vel_q() as u16
    }

    #[inline]
    pub fn set_csr_reqcap0_request_stream_vel_q(&self, value: u16) {
        set_csr_reqcap0_request_stream_vel_q(value as u32)
    }

    #[inline]
    pub fn get_csr_reqcap0_request_geom_token(&self) -> u16 {
        get_csr_reqcap0_request_geom_token() as u16
    }

    #[inline]
    pub fn set_csr_reqcap0_request_geom_token(&self, value: u16) {
        set_csr_reqcap0_request_geom_token(value as u32)
    }

    #[inline]
    pub fn get_csr_reqcap0_request_aux_bits(&self) -> u16 {
        get_csr_reqcap0_request_aux_bits() as u16
    }

    #[inline]
    pub fn set_csr_reqcap0_request_aux_bits(&self, value: u16) {
        set_csr_reqcap0_request_aux_bits(value as u32)
    }

    #[inline]
    pub fn get_csr_reqcap0_request_integrity_seed(&self) -> u16 {
        get_csr_reqcap0_request_integrity_seed() as u16
    }

    #[inline]
    pub fn set_csr_reqcap0_request_integrity_seed(&self, value: u16) {
        set_csr_reqcap0_request_integrity_seed(value as u32)
    }

    #[inline]
    pub fn read_csr_reqseq(&self) -> u32 {
        read_csr_reqseq()
    }

    #[inline]
    pub fn get_csr_reqseq_request_seq_current(&self) -> u16 {
        get_csr_reqseq_request_seq_current() as u16
    }

    #[inline]
    pub fn get_csr_reqseq_latest_accepted_seq(&self) -> u16 {
        get_csr_reqseq_latest_accepted_seq() as u16
    }

    #[inline]
    pub fn get_csr_reqseq_outstanding_seq(&self) -> u16 {
        get_csr_reqseq_outstanding_seq() as u16
    }

    #[inline]
    pub fn get_csr_reqseq_reserved(&self) -> u16 {
        get_csr_reqseq_reserved() as u16
    }

    #[inline]
    pub fn read_csr_host_tx(&self) -> u32 {
        read_csr_host_tx()
    }

    #[inline]
    pub fn get_csr_host_tx_tx_packet(&self) -> u32 {
        get_csr_host_tx_tx_packet() as u32
    }

    #[inline]
    pub fn read_csr_host_rx(&self) -> u32 {
        read_csr_host_rx()
    }

    #[inline]
    pub fn get_csr_host_rx_rx_packet(&self) -> u32 {
        get_csr_host_rx_rx_packet() as u32
    }

    #[inline]
    pub fn read_csr_w1c_status(&self) -> u32 {
        read_csr_w1c_status()
    }

    #[inline]
    pub fn write_csr_w1c_status(&self, value: u32) {
        write_csr_w1c_status(value)
    }

    #[inline]
    pub fn get_csr_w1c_status_clear_timeout_fault(&self) -> bool {
        get_csr_w1c_status_clear_timeout_fault() != 0
    }

    #[inline]
    pub fn set_csr_w1c_status_clear_timeout_fault(&self, value: bool) {
        set_csr_w1c_status_clear_timeout_fault(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_csr_w1c_status_clear_stale_fault(&self) -> bool {
        get_csr_w1c_status_clear_stale_fault() != 0
    }

    #[inline]
    pub fn set_csr_w1c_status_clear_stale_fault(&self, value: bool) {
        set_csr_w1c_status_clear_stale_fault(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_csr_w1c_status_clear_integrity_fault(&self) -> bool {
        get_csr_w1c_status_clear_integrity_fault() != 0
    }

    #[inline]
    pub fn set_csr_w1c_status_clear_integrity_fault(&self, value: bool) {
        set_csr_w1c_status_clear_integrity_fault(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_csr_w1c_status_clear_fallback_active(&self) -> bool {
        get_csr_w1c_status_clear_fallback_active() != 0
    }

    #[inline]
    pub fn set_csr_w1c_status_clear_fallback_active(&self, value: bool) {
        set_csr_w1c_status_clear_fallback_active(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_csr_w1c_status_clear_request_pending(&self) -> bool {
        get_csr_w1c_status_clear_request_pending() != 0
    }

    #[inline]
    pub fn set_csr_w1c_status_clear_request_pending(&self, value: bool) {
        set_csr_w1c_status_clear_request_pending(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_csr_w1c_status_reserved(&self) -> u32 {
        get_csr_w1c_status_reserved() as u32
    }

}
