# System Firmware CoSim Execution Summary

- Generated at: 2026-08-11T20:05:21.655925
- Execution mode: artifact_readiness_only
- Overall status: blocked_missing_inputs
- Readiness: blocked

## Key Inputs

- SoC top: `digital/rtl/adaptive_aero_control_top.v`
- Firmware ELF: `firmware/build/target/x86_64-unknown-linux-gnu/release/firmware_app.elf`
- Cocotb Makefile: `firmware/validate/Makefile`
- Test files: `1`
- Verilog/SystemVerilog files: `2`

## Missing Required Inputs

- firmware_elf_path

## Planned Test Matrix

- test_firmware_smoke.py | seed=1 | status=planned
- test_firmware_smoke.py | seed=2 | status=planned

## Notes

- Execution was not attempted because one or more required inputs were missing.
- No coverage model detected; downstream summary should avoid reporting functional coverage percentages.
- No digital assertions collateral detected; assertion coverage should remain unavailable, not fabricated.
- Firmware ELF was not detected; this run should be treated as not executable, not as a passing simulation.

## Conclusion

The co-simulation bundle is incomplete. Downstream agents should treat coverage as unavailable rather than infer passing results.
