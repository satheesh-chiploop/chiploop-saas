module sram_mbist_demo_controller (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    bist_start,
    rd_data,
    ready,
    bist_done,
    bist_fail,
    irq,
    mem_csb,
    mem_web,
    mem_addr,
    mem_din,
    mem_dout,
    mem_model_dout
);
input clk;
input reset_n;
input wr_en;
input [7:0] wr_addr;
input [31:0] wr_data;
input rd_en;
input [7:0] rd_addr;
input bist_start;
output [31:0] rd_data;
output ready;
output bist_done;
output bist_fail;
output irq;
output mem_csb;
output mem_web;
output [7:0] mem_addr;
output [31:0] mem_din;
input [31:0] mem_dout;
input [31:0] mem_model_dout;

reg [31:0] control_reg;
reg [31:0] mem_addr_reg;
reg [31:0] mem_wdata_reg;
reg [31:0] mem_rdata_reg;
reg [31:0] mem_control_reg;
reg [31:0] bist_control_reg;
reg [31:0] bist_status_reg;
reg [31:0] irq_status_reg;
reg [31:0] rd_data_reg;
reg [31:0] read_mux;
reg [31:0] status_value;
reg [31:0] bist_status_value;
reg [31:0] next_control_reg;
reg [31:0] next_mem_addr_reg;
reg [31:0] next_mem_wdata_reg;
reg [31:0] next_mem_rdata_reg;
reg [31:0] next_mem_control_reg;
reg [31:0] next_bist_control_reg;
reg [31:0] next_bist_status_reg;
reg [31:0] next_irq_status_reg;
reg [31:0] next_rd_data_reg;
reg [31:0] next_read_mux;
reg [31:0] next_status_value;
reg [31:0] next_bist_status_value;
reg busy_reg;
reg next_busy_reg;
reg ready_reg;
reg bist_done_reg;
reg bist_fail_reg;
reg irq_reg;
reg bist_start_pulse;
reg mem_write_req;
reg mem_read_req;
reg bist_start_req;
reg clear_result_req;
reg irq_clear_done_req;
reg [7:0] last_fail_addr_reg;
reg [7:0] next_last_fail_addr_reg;
wire [31:0] mem_selected_dout;
wire [31:0] u_sram_dout;

assign mem_selected_dout = mem_dout;
assign rd_data = rd_data_reg;
assign ready = ready_reg;
assign bist_done = bist_done_reg;
assign bist_fail = bist_fail_reg;
assign irq = irq_reg;
assign mem_csb = mem_control_reg[0];
assign mem_web = mem_control_reg[1];
assign mem_addr = mem_addr_reg[7:0];
assign mem_din = mem_wdata_reg;

demo_sram_32x256_wrapper u_sram (
    .clk(clk),
    .csb(mem_csb),
    .web(mem_web),
    .addr(mem_addr),
    .din(mem_din),
    .dout(u_sram_dout)
);

always @(*) begin
    next_control_reg = control_reg;
    next_mem_addr_reg = mem_addr_reg;
    next_mem_wdata_reg = mem_wdata_reg;
    next_mem_rdata_reg = mem_rdata_reg;
    next_mem_control_reg = mem_control_reg;
    next_bist_control_reg = bist_control_reg;
    next_bist_status_reg = bist_status_reg;
    next_irq_status_reg = irq_status_reg;
    next_rd_data_reg = rd_data_reg;
    next_read_mux = 32'h00000000;
    next_status_value = 32'h00000000;
    next_bist_status_value = 32'h00000000;
    next_busy_reg = busy_reg;
    next_last_fail_addr_reg = last_fail_addr_reg;
    bist_start_pulse = 1'b0;
    mem_write_req = 1'b0;
    mem_read_req = 1'b0;
    bist_start_req = 1'b0;
    clear_result_req = 1'b0;
    irq_clear_done_req = 1'b0;

    next_status_value[0] = ready_reg;
    next_status_value[1] = bist_done_reg;
    next_status_value[2] = bist_fail_reg;
    next_status_value[3] = busy_reg;

    next_bist_status_value[0] = bist_status_reg[0];
    next_bist_status_value[1] = bist_status_reg[1];
    next_bist_status_value[2] = bist_status_reg[2];
    next_bist_status_value[15:8] = last_fail_addr_reg;

    case (rd_addr)
        8'h00: next_read_mux = control_reg;
        8'h04: next_read_mux = next_status_value;
        8'h08: next_read_mux = mem_addr_reg;
        8'h0C: next_read_mux = mem_wdata_reg;
        8'h10: next_read_mux = mem_rdata_reg;
        8'h14: next_read_mux = mem_control_reg;
        8'h18: next_read_mux = bist_control_reg;
        8'h1C: next_read_mux = next_bist_status_value;
        8'h20: next_read_mux = irq_status_reg;
        8'h24: next_read_mux = 32'h00000000;
        default: next_read_mux = 32'h00000000;
    endcase

    if (wr_en) begin
        case (wr_addr)
            8'h00: next_control_reg = wr_data;
            8'h08: next_mem_addr_reg = {24'h000000, wr_data[7:0]};
            8'h0C: next_mem_wdata_reg = wr_data;
            8'h14: next_mem_control_reg = wr_data;
            8'h18: next_bist_control_reg = wr_data;
            8'h20: next_irq_status_reg = irq_status_reg & ~wr_data;
            8'h24: begin
                next_irq_status_reg[0] = irq_status_reg[0] & ~wr_data[0];
                next_irq_status_reg[1] = irq_status_reg[1] & ~wr_data[1];
            end
            default: next_control_reg = next_control_reg;
        endcase
    end

    if (rd_en) begin
        case (rd_addr)
            8'h10: next_mem_rdata_reg = mem_selected_dout;
            default: next_mem_rdata_reg = next_mem_rdata_reg;
        endcase
    end

    if (bist_start_req) begin
        next_bist_status_reg[2] = 1'b1;
        next_bist_status_reg[0] = 1'b0;
        next_bist_status_reg[1] = 1'b0;
        next_last_fail_addr_reg = 8'h00;
    end

    if (clear_result_req) begin
        next_bist_status_reg[0] = 1'b0;
        next_bist_status_reg[1] = 1'b0;
        next_bist_status_reg[2] = 1'b0;
        next_last_fail_addr_reg = 8'h00;
        next_irq_status_reg = 32'h00000000;
    end

    if (mem_write_req) begin
        next_busy_reg = 1'b1;
        next_mem_control_reg[0] = 1'b0;
    end else if (mem_read_req) begin
        next_busy_reg = 1'b1;
        next_mem_control_reg[1] = 1'b0;
        next_mem_rdata_reg = mem_selected_dout;
    end else if (bist_status_reg[2]) begin
        next_busy_reg = 1'b1;
    end else begin
        next_busy_reg = 1'b0;
    end

    if (bist_start) begin
        next_bist_status_reg[2] = 1'b1;
    end

    if (bist_status_reg[2]) begin
        next_bist_status_reg[2] = 1'b0;
        next_bist_status_reg[0] = 1'b1;
        next_irq_status_reg[0] = 1'b1;
    end

    if (bist_status_reg[0]) begin
    end

    if (bist_status_reg[1]) begin
    end


    next_rd_data_reg = next_read_mux;
    next_status_value[0] = ready_reg;
    next_status_value[1] = bist_done_reg;
    next_status_value[2] = bist_fail_reg;
    next_status_value[3] = next_busy_reg;
    next_bist_status_value[0] = next_bist_status_reg[0];
    next_bist_status_value[1] = next_bist_status_reg[1];
    next_bist_status_value[2] = next_bist_status_reg[2];
    next_bist_status_value[15:8] = next_last_fail_addr_reg;
end

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        control_reg <= 32'h00000000;
        mem_addr_reg <= 32'h00000000;
        mem_wdata_reg <= 32'h00000000;
        mem_rdata_reg <= 32'h00000000;
        mem_control_reg <= 32'h00000000;
        bist_control_reg <= 32'h00000000;
        bist_status_reg <= 32'h00000000;
        irq_status_reg <= 32'h00000000;
        rd_data_reg <= 32'h00000000;
        busy_reg <= 1'b0;
        ready_reg <= 1'b1;
        bist_done_reg <= 1'b0;
        bist_fail_reg <= 1'b0;
        irq_reg <= 1'b0;
        last_fail_addr_reg <= 8'h00;
    end else begin
        control_reg <= next_control_reg;
        mem_addr_reg <= next_mem_addr_reg;
        mem_wdata_reg <= next_mem_wdata_reg;
        mem_rdata_reg <= next_mem_rdata_reg;
        mem_control_reg <= next_mem_control_reg;
        bist_control_reg <= next_bist_control_reg;
        bist_status_reg <= next_bist_status_reg;
        irq_status_reg <= next_irq_status_reg;
        rd_data_reg <= next_rd_data_reg;
        busy_reg <= next_busy_reg;
        ready_reg <= ready_reg;
        bist_done_reg <= bist_done_reg;
        bist_fail_reg <= bist_fail_reg;
        irq_reg <= irq_reg;
        last_fail_addr_reg <= next_last_fail_addr_reg;
    end
end

endmodule
