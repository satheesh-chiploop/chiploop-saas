module demo_sram_32x256_model (
    clk,
    csb,
    web,
    addr,
    din,
    dout
);
input clk;
input csb;
input web;
input [7:0] addr;
input [31:0] din;
output [31:0] dout;

reg [31:0] mem [0:255];
reg [31:0] dout_reg;
integer i;

assign dout = dout_reg;

always @(posedge clk) begin
    if (csb == 1'b0) begin
        if (web == 1'b0) begin
            mem[addr] <= din;
        end else begin
            dout_reg <= mem[addr];
        end
    end
end

initial begin
    dout_reg = 32'h00000000;
    for (i = 0; i < 256; i = i + 1) begin
        mem[i] = 32'h00000000;
    end
end

endmodule
