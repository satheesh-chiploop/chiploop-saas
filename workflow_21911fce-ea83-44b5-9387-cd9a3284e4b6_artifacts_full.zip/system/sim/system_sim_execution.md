# System Simulation Execution Report

- Top: `temp_monitor_soc_sim`
- Tests run: 6
- Passed: 0
- Failed: 6
- Total runtime (s): 12.011
- Coverage JSON present: False
- Coverage MD present: False

## Run Matrix
- `system_smoke_test` / seed `1` → FAIL (rc=2, 4.74s)
- `system_smoke_test` / seed `2` → FAIL (rc=2, 1.445s)
- `system_smoke_test` / seed `7` → FAIL (rc=2, 1.508s)
- `integrated_input_sanity` / seed `1` → FAIL (rc=2, 1.391s)
- `integrated_input_sanity` / seed `2` → FAIL (rc=2, 1.49s)
- `integrated_input_sanity` / seed `7` → FAIL (rc=2, 1.437s)
