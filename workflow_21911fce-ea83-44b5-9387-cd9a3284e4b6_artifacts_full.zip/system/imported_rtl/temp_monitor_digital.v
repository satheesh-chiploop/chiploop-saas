module temp_monitor_digital (
    input        clk,
    input        reset_n,
    input        wr_en,
    input  [7:0] wr_addr,
    input  [15:0] wr_data,
    input        rd_en,
    input  [7:0] rd_addr,
    input  [11:0] adc_code,
    input        adc_valid,
    output [15:0] rd_data,
    output       sample_req,
    output       alert_irq,
    output [11:0] temp_code,
    output [11:0] threshold_code,
    output       alert_status
);

wire        sample_req_event;
wire        enable;
wire        irq_enable;
wire        alert_clear_pulse;
wire        irq_clear_alert_pulse;
wire        irq_clear_sample_done_pulse;
wire        busy;
wire        adc_valid_seen;
wire        status_sample_done;
wire        status_alert_pending;
wire        irq_status_alert;
wire        irq_status_sample_done;
wire [11:0] latest_temp;
wire [15:0] sample_count;

temp_monitor_registers u_temp_monitor_registers (
    .clk(clk),
    .reset_n(reset_n),
    .wr_en(wr_en),
    .wr_addr(wr_addr),
    .wr_data(wr_data),
    .rd_en(rd_en),
    .rd_addr(rd_addr),
    .adc_valid_seen(adc_valid_seen),
    .status_sample_done(status_sample_done),
    .status_alert_pending(status_alert_pending),
    .busy(busy),
    .latest_temp(latest_temp),
    .sample_count(sample_count),
    .irq_status_alert(irq_status_alert),
    .irq_status_sample_done(irq_status_sample_done),
    .alert_status(alert_status),
    .temp_code(temp_code),
    .sample_req_event(sample_req_event),
    .enable(enable),
    .irq_enable(irq_enable),
    .alert_clear_pulse(alert_clear_pulse),
    .irq_clear_alert_pulse(irq_clear_alert_pulse),
    .irq_clear_sample_done_pulse(irq_clear_sample_done_pulse),
    .threshold_code(threshold_code),
    .rd_data(rd_data),
    .sample_req(sample_req),
    .alert_irq(alert_irq)
);

temp_monitor_filter_alert u_temp_monitor_filter_alert (
    .clk(clk),
    .reset_n(reset_n),
    .sample_req_event(sample_req_event),
    .enable(enable),
    .irq_enable(irq_enable),
    .alert_clear_pulse(alert_clear_pulse),
    .irq_clear_alert_pulse(irq_clear_alert_pulse),
    .irq_clear_sample_done_pulse(irq_clear_sample_done_pulse),
    .threshold_code(threshold_code),
    .adc_code(adc_code),
    .adc_valid(adc_valid),
    .busy(busy),
    .adc_valid_seen(adc_valid_seen),
    .status_sample_done(status_sample_done),
    .status_alert_pending(status_alert_pending),
    .irq_status_alert(irq_status_alert),
    .irq_status_sample_done(irq_status_sample_done),
    .alert_status(alert_status),
    .temp_code(temp_code),
    .latest_temp(latest_temp),
    .sample_count(sample_count),
    .sample_req(sample_req),
    .alert_irq(alert_irq)
);

endmodule
