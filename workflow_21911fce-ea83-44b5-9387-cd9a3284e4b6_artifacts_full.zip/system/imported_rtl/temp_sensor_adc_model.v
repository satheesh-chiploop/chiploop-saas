module temp_sensor_adc_model (
    input  sample_req,
    input  [15:0] sensor_temp_celsius,
    input  avdd,
    input  avss,
    output reg [11:0] adc_code,
    output reg adc_valid
);

    parameter integer SAMPLE_LATENCY_CYCLES = 1;
    parameter integer TEMP_SCALE_LSB_PER_C = 10;
    parameter integer TEMP_OFFSET_CODE = 2048;
    parameter integer GAIN_ERROR_PPM = 0;
    parameter integer OFFSET_ERROR_CODE = 0;

    reg [31:0] latency_cnt;
    reg        conversion_pending;

    reg [31:0] ideal_code_ext;
    reg [31:0] gain_scaled_code_ext;
    reg [31:0] computed_code_ext;
    reg [31:0] clamped_code_ext;
    reg [31:0] temp_unsigned_ext;
    reg        sample_req_prev;
    reg        supply_ok;

    always @(*) begin
        supply_ok = (avdd === 1'b1) && (avss === 1'b0);
    end

    always @(*) begin
        temp_unsigned_ext = {16'b0, sensor_temp_celsius};
        ideal_code_ext = temp_unsigned_ext;
        ideal_code_ext = ideal_code_ext * TEMP_SCALE_LSB_PER_C;
        ideal_code_ext = ideal_code_ext + TEMP_OFFSET_CODE;

        gain_scaled_code_ext = ideal_code_ext;
        gain_scaled_code_ext = (gain_scaled_code_ext * (1000000 + GAIN_ERROR_PPM)) / 1000000;

        computed_code_ext = gain_scaled_code_ext + OFFSET_ERROR_CODE;

        if (!supply_ok) begin
            clamped_code_ext = 32'd0;
        end else if ($signed(computed_code_ext) < 0) begin
            clamped_code_ext = 32'd0;
        end else if (computed_code_ext > 32'd4095) begin
            clamped_code_ext = 32'd4095;
        end else begin
            clamped_code_ext = computed_code_ext;
        end
    end

    always @(posedge sample_req) begin
        if (!conversion_pending) begin
            conversion_pending <= 1'b1;
            if (SAMPLE_LATENCY_CYCLES <= 0) begin
                latency_cnt <= 32'd0;
            end else begin
                latency_cnt <= SAMPLE_LATENCY_CYCLES[31:0];
            end
        end
        sample_req_prev <= 1'b1;
    end

    always @(posedge conversion_pending) begin
        if (latency_cnt == 32'd0) begin
            adc_code <= clamped_code_ext[11:0];
            adc_valid <= 1'b1;
            conversion_pending <= 1'b0;
        end
    end

    always @(posedge sample_req or posedge conversion_pending) begin
        if (sample_req) begin
            adc_valid <= 1'b0;
        end
    end

    initial begin
        adc_code <= 12'd0;
        adc_valid <= 1'b0;
        latency_cnt <= 32'd0;
        conversion_pending <= 1'b0;
        sample_req_prev <= 1'b0;
        supply_ok = 1'b0;
        ideal_code_ext = 32'd0;
        gain_scaled_code_ext = 32'd0;
        computed_code_ext = 32'd0;
        clamped_code_ext = 32'd0;
        temp_unsigned_ext = 32'd0;
    end

endmodule
