module temp_monitor_registers (
    input        clk,
    input        reset_n,
    input        wr_en,
    input  [7:0] wr_addr,
    input  [15:0] wr_data,
    input        rd_en,
    input  [7:0] rd_addr,
    input        adc_valid_seen,
    input        status_sample_done,
    input        status_alert_pending,
    input        busy,
    input  [11:0] latest_temp,
    input  [15:0] sample_count,
    input        irq_status_alert,
    input        irq_status_sample_done,
    input        alert_status,
    input  [11:0] temp_code,
    output reg   sample_req_event,
    output reg   enable,
    output reg   irq_enable,
    output reg   alert_clear_pulse,
    output reg   irq_clear_alert_pulse,
    output reg   irq_clear_sample_done_pulse,
    output reg [11:0] threshold_code,
    output reg [15:0] rd_data,
    input        sample_req,
    input        alert_irq
);

reg [15:0] control_reg;
reg [15:0] threshold_reg;
reg [15:0] irq_clear_reg;
reg [15:0] rd_data_next;
reg        sample_req_event_next;
reg        enable_next;
reg        irq_enable_next;
reg        alert_clear_pulse_next;
reg        irq_clear_alert_pulse_next;
reg        irq_clear_sample_done_pulse_next;
reg [11:0] threshold_code_next;

always @(*) begin
    control_reg = 16'h0000;
    threshold_reg = 16'h0000;
    irq_clear_reg = 16'h0000;
    rd_data_next = 16'h0000;
    sample_req_event_next = 1'b0;
    enable_next = 1'b0;
    irq_enable_next = 1'b0;
    alert_clear_pulse_next = 1'b0;
    irq_clear_alert_pulse_next = 1'b0;
    irq_clear_sample_done_pulse_next = 1'b0;
    threshold_code_next = 12'h000;

    control_reg[0] = enable;
    control_reg[1] = 1'b0;
    control_reg[2] = irq_enable;
    control_reg[3] = 1'b0;
    threshold_reg[11:0] = threshold_code;
    irq_clear_reg[15:0] = 16'h0000;

    if (wr_en) begin
        case (wr_addr)
            8'h00: begin
                enable_next = wr_data[0];
                irq_enable_next = wr_data[2];
                if (wr_data[1]) sample_req_event_next = 1'b1;
                if (wr_data[3]) alert_clear_pulse_next = 1'b1;
            end
            8'h08: begin
                threshold_code_next = wr_data[11:0];
            end
            8'h18: begin
                if (wr_data[0]) irq_clear_alert_pulse_next = 1'b1;
                if (wr_data[1]) irq_clear_sample_done_pulse_next = 1'b1;
            end
            default: begin
            end
        endcase
    end

    if (rd_en) begin
        case (rd_addr)
            8'h00: rd_data_next = {12'h000, 1'b0, 1'b0, irq_enable, enable};
            8'h04: rd_data_next = {12'h000, busy, status_alert_pending, adc_valid_seen, status_sample_done};
            8'h08: rd_data_next = {4'h0, threshold_code};
            8'h0C: rd_data_next = {4'h0, latest_temp};
            8'h10: rd_data_next = sample_count;
            8'h14: rd_data_next = {14'h0000, irq_status_sample_done, irq_status_alert};
            8'h18: rd_data_next = 16'h0000;
            default: rd_data_next = 16'h0000;
        endcase
    end else begin
        rd_data_next = 16'h0000;
    end
end

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        enable <= 1'b0;
        irq_enable <= 1'b0;
        alert_clear_pulse <= 1'b0;
        irq_clear_alert_pulse <= 1'b0;
        irq_clear_sample_done_pulse <= 1'b0;
        threshold_code <= 12'h000;
        rd_data <= 16'h0000;
        sample_req_event <= 1'b0;
    end else begin
        enable <= enable_next;
        irq_enable <= irq_enable_next;
        alert_clear_pulse <= alert_clear_pulse_next;
        irq_clear_alert_pulse <= irq_clear_alert_pulse_next;
        irq_clear_sample_done_pulse <= irq_clear_sample_done_pulse_next;
        threshold_code <= threshold_code_next;
        rd_data <= rd_data_next;
        sample_req_event <= sample_req_event_next;
    end
end

endmodule
