module temp_monitor_filter_alert (
    input        clk,
    input        reset_n,
    input        sample_req_event,
    input        enable,
    input        irq_enable,
    input        alert_clear_pulse,
    input        irq_clear_alert_pulse,
    input        irq_clear_sample_done_pulse,
    input  [11:0] threshold_code,
    input  [11:0] adc_code,
    input        adc_valid,
    output reg   busy,
    output reg   adc_valid_seen,
    output reg   status_sample_done,
    output reg   status_alert_pending,
    output reg   irq_status_alert,
    output reg   irq_status_sample_done,
    output reg   alert_status,
    output reg [11:0] temp_code,
    output reg [11:0] latest_temp,
    output reg [15:0] sample_count,
    output reg   sample_req,
    output reg   alert_irq
);

reg [11:0] prev_sample_code;
reg        pending_req;
reg        periodic_req;
reg [11:0] filtered_next;
reg [11:0] next_latest_temp;
reg [15:0] next_sample_count;
reg        next_adc_valid_seen;
reg        next_status_sample_done;
reg        next_status_alert_pending;
reg        next_irq_status_alert;
reg        next_irq_status_sample_done;
reg        next_alert_status;
reg        next_busy;
reg        next_sample_req;
reg        next_alert_irq;
reg [11:0] next_prev_sample_code;
reg        next_pending_req;

always @(*) begin
    filtered_next = temp_code;
    next_latest_temp = latest_temp;
    next_sample_count = sample_count;
    next_adc_valid_seen = adc_valid_seen;
    next_status_sample_done = status_sample_done;
    next_status_alert_pending = status_alert_pending;
    next_irq_status_alert = irq_status_alert;
    next_irq_status_sample_done = irq_status_sample_done;
    next_alert_status = alert_status;
    next_busy = busy;
    next_sample_req = 1'b0;
    next_alert_irq = alert_irq;
    next_prev_sample_code = prev_sample_code;
    next_pending_req = pending_req;
    periodic_req = 1'b0;

    if (enable && !pending_req && !adc_valid) periodic_req = 1'b1;
    if (sample_req_event || periodic_req) begin
        next_sample_req = 1'b1;
        next_pending_req = 1'b1;
    end
    if (adc_valid) begin
        if (pending_req) next_pending_req = 1'b0;
        filtered_next = {1'b0, adc_code} + {1'b0, prev_sample_code};
        filtered_next = filtered_next[11:1];
        next_prev_sample_code = adc_code;
        next_latest_temp = filtered_next;
        next_sample_count = sample_count + 16'd1;
        next_adc_valid_seen = 1'b1;
        next_status_sample_done = 1'b1;
        next_irq_status_sample_done = 1'b1;
        if (filtered_next > threshold_code) begin
            next_alert_status = 1'b1;
            next_status_alert_pending = 1'b1;
            next_irq_status_alert = 1'b1;
        end
    end
    if (alert_clear_pulse || irq_clear_alert_pulse) begin
        next_alert_status = 1'b0;
        next_status_alert_pending = 1'b0;
    end
    if (irq_clear_alert_pulse) begin
        next_irq_status_alert = 1'b0;
    end
    if (irq_clear_sample_done_pulse) begin
        next_status_sample_done = 1'b0;
        next_irq_status_sample_done = 1'b0;
    end
    next_busy = next_pending_req;
    next_alert_irq = irq_enable && (next_irq_status_alert | next_irq_status_sample_done);
end

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        busy <= 1'b0;
        adc_valid_seen <= 1'b0;
        status_sample_done <= 1'b0;
        status_alert_pending <= 1'b0;
        irq_status_alert <= 1'b0;
        irq_status_sample_done <= 1'b0;
        alert_status <= 1'b0;
        temp_code <= 12'h000;
        latest_temp <= 12'h000;
        sample_count <= 16'h0000;
        sample_req <= 1'b0;
        alert_irq <= 1'b0;
        prev_sample_code <= 12'h000;
        pending_req <= 1'b0;
    end else begin
        busy <= next_busy;
        adc_valid_seen <= next_adc_valid_seen;
        status_sample_done <= next_status_sample_done;
        status_alert_pending <= next_status_alert_pending;
        irq_status_alert <= next_irq_status_alert;
        irq_status_sample_done <= next_irq_status_sample_done;
        alert_status <= next_alert_status;
        temp_code <= filtered_next;
        latest_temp <= next_latest_temp;
        sample_count <= next_sample_count;
        sample_req <= next_sample_req;
        alert_irq <= next_alert_irq;
        prev_sample_code <= next_prev_sample_code;
        pending_req <= next_pending_req;
    end
end

endmodule
