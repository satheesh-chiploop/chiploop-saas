# ChipLoop V&V: System Cocotb + Verilator

Generated:
- `test_temp_monitor_soc_sim.py`     : integrated cocotb tests
- `Makefile`          : cocotb/verilator make entry
- `rtl_sources.mk`    : explicit RTL file list
- `cocotb_vpi_bootstrap.cpp`: cocotb Verilator VPI bootstrap hook
- `testcases.json`    : testcase manifest
- `tb_contract.json`  : resolved contract used for testbench generation

Run (from this folder):
```bash
make
RANDOM_SEED=123 make
NUM_ITERS=200 RANDOM_SEED=7 make TESTCASE=integrated_input_sanity
```
