# System Simulation Control

Generated files:
- `run_regression.py`: orchestrates multi-seed runs via `make TESTCASE=...`
- `simulation_manifest.json`: consolidated simulation-control manifest for the integrated system DUT

Key resolved inputs:
- Top module: `temp_monitor_soc_sim`
- System integration intent: `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/21911fce-ea83-44b5-9387-cd9a3284e4b6/8f70a404-3dae-44af-80dd-fc1f6d78d4e3/digital/system/integration/system_integration_intent.json`
- SoC top (sim): `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/21911fce-ea83-44b5-9387-cd9a3284e4b6/8f70a404-3dae-44af-80dd-fc1f6d78d4e3/digital/system/imported_rtl/temp_monitor_soc_sim.sv`
- RTL file count: `6`

Seed management:
- override with `RANDOM_SEED=<int>`

Usage:
```bash
python run_regression.py --tests system_smoke_test integrated_input_sanity --seeds 1 2 3 4 5
```
