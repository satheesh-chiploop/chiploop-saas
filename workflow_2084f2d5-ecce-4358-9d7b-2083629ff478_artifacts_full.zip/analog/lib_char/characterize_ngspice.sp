.include "/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/2084f2d5-ecce-4358-9d7b-2083629ff478/a2ae2c36-0653-4893-bf3b-a857863a62ee/digital/analog/lib_char/temp_sensor_adc_model.spice"
* Placeholder characterization deck. Real Liberty requires block-specific stimuli and measurements.
.control
op
write op.raw
quit
.endc
.end
