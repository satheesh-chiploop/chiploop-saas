#!/usr/bin/env bash
set -euo pipefail

echo "== ChipLoop: Digital Tapeout Agent =="
echo "PDK_VARIANT=sky130A"
echo "OPENLANE_IMAGE=ghcr.io/efabless/openlane2:2.4.0.dev1"
echo "WORKDIR=/work"

export OPENLANE_NUM_CORES=2

docker run --rm \
  -v "/root/chiploop-backend/backend/pdk":/pdk \
  -v "/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/2084f2d5-ecce-4358-9d7b-2083629ff478/a2ae2c36-0653-4893-bf3b-a857863a62ee/digital/digital/run_work":/work \
  -e PDK=sky130A \
  -e PDK_ROOT=/pdk \
  ghcr.io/efabless/openlane2:2.4.0.dev1 \
  bash -lc 'set -e; cd /work && openlane --flow Classic --run-tag System_PD_2084f2d5-ecce-4358-9d7b-2083629ff478 --override-config RUN_LINTER=False --to KLayout.StreamOut tapeout/config.json'

docker run --rm \
  -v "/root/chiploop-backend/backend/pdk":/pdk \
  -v "/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/2084f2d5-ecce-4358-9d7b-2083629ff478/a2ae2c36-0653-4893-bf3b-a857863a62ee/digital/digital/run_work":/work \
  -e PDK=sky130A \
  -e PDK_ROOT=/pdk \
  ghcr.io/efabless/openlane2:2.4.0.dev1 \
  bash -lc 'set -e; cd /work && openlane --flow Classic --run-tag System_PD_2084f2d5-ecce-4358-9d7b-2083629ff478 --override-config RUN_LINTER=False --to Magic.StreamOut tapeout/config.json || true'

docker run --rm \
  -v "/root/chiploop-backend/backend/pdk":/pdk \
  -v "/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/2084f2d5-ecce-4358-9d7b-2083629ff478/a2ae2c36-0653-4893-bf3b-a857863a62ee/digital/digital/run_work":/work \
  -e PDK=sky130A \
  -e PDK_ROOT=/pdk \
  ghcr.io/efabless/openlane2:2.4.0.dev1 \
  bash -lc 'set -e; cd /work && openlane --flow Classic --run-tag System_PD_2084f2d5-ecce-4358-9d7b-2083629ff478 --override-config RUN_LINTER=False --to KLayout.XOR tapeout/config.json || true'
