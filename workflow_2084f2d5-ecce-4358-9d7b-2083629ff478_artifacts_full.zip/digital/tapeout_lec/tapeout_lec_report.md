# Tapeout Logic Equivalence Check

- Status: `inconclusive_unresolved_cells`
- Comparison: `RTL vs final tapeout implementation netlist`
- Top module: `temp_monitor_soc_phys`
- RTL files: `4`
- Tapeout netlist: `temp_monitor_soc_phys.pnl.v`
- Ignored physical-only gate ports: `VGND, VPWR`
- Standard-cell models loaded: `1`
- Missing standard-cell models: `0`
- Unproven points: `0`
- Return code: `1`
- Failure reason: `yosys_inconclusive_see_lec_log`

This is distinct from synthesis LEC. Synthesis LEC compares RTL against `digital/synth/netlist/*_synth.v`; tapeout LEC compares RTL against the final implementation netlist collected after physical implementation.
