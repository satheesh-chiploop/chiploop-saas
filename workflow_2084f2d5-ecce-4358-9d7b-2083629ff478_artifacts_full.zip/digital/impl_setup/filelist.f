/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/2084f2d5-ecce-4358-9d7b-2083629ff478/a2ae2c36-0653-4893-bf3b-a857863a62ee/digital/system/imported_rtl/temp_sensor_adc_model.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/2084f2d5-ecce-4358-9d7b-2083629ff478/a2ae2c36-0653-4893-bf3b-a857863a62ee/digital/system/imported_rtl/temp_monitor_digital.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/2084f2d5-ecce-4358-9d7b-2083629ff478/a2ae2c36-0653-4893-bf3b-a857863a62ee/digital/system/imported_rtl/temp_monitor_soc_phys.sv
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/2084f2d5-ecce-4358-9d7b-2083629ff478/a2ae2c36-0653-4893-bf3b-a857863a62ee/digital/system/imported_rtl/temp_monitor_soc_sim.sv
