// Auto-generated blackbox stub for preserved macro LEC.
(* blackbox *)
module temp_sensor_adc_model(sample_req, sensor_temp_celsius, avdd, avss);
  input sample_req;
  input sensor_temp_celsius;
  input avdd;
  input avss;
endmodule
