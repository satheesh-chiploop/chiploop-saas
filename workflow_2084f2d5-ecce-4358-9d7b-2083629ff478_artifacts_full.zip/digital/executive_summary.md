# Digital Executive Summary
- workflow_id: `2084f2d5-ecce-4358-9d7b-2083629ff478`
- run_tag: `System_PD_2084f2d5-ecce-4358-9d7b-2083629ff478`
- run_work_dir: `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/2084f2d5-ecce-4358-9d7b-2083629ff478/a2ae2c36-0653-4893-bf3b-a857863a62ee/digital/digital/run_work`

## Key Metrics (best-effort parsed)
- Cell count: `376`
- Area: `4659.4688`
- STA stage used: `sta_postplace`
- Worst slack: `15.8224`
- TNS: `0`
- DRC violations: `None`
- DRC status: `failed`
- LVS status: `failed`
- Tapeout status: `failed`
- Tapeout LEC status: `inconclusive_unresolved_cells`
- ATPG status: `patterns_generated`
- Summary status: `failed`

## STA Stage Breakdown
- sta_preplace: worst_slack=`11.247683991438404`, tns=`0`
- sta_postplace: worst_slack=`15.8224`, tns=`0`
- sta_postcts: worst_slack=`None`, tns=`None`
- sta_postroute: worst_slack=`None`, tns=`None`
- sta_postfill: worst_slack=`None`, tns=`None`

## GDS Paths (local, only if produced)
- KLayout GDS: `None`
- Magic GDS: `None`

## Artifact Map
- synth_metrics: `digital/synth/metrics.json`
- sta_preplace_metrics: `digital/sta_preplace/metrics.json`
- sta_postplace_metrics: `digital/sta_postplace/metrics.json`
- sta_postcts_metrics: `None`
- sta_postroute_metrics: `None`
- sta_postfill_metrics: `None`
- drc_metrics: `None`
- lvs_metrics: `None`
- tapeout_metrics: `None`

## Next Iteration Suggestions
- If worst_slack < 0: relax constraints or improve synthesis/placement/CTS/route parameters.
- If DRC violations > 0: inspect DRC logs and rerun with adjusted floorplan/route settings.
- If LVS not clean: check extraction/streamout mismatch and netlist naming.