# Digital Synthesis Summary

- **Workflow**: 2084f2d5-ecce-4358-9d7b-2083629ff478
- **Status**: `ok` (rc=0)
- **Top module**: `temp_monitor_soc_phys`
- **Clock**: `clk` @ **10.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/2084f2d5-ecce-4358-9d7b-2083629ff478/a2ae2c36-0653-4893-bf3b-a857863a62ee/digital/digital/synth/runs/System_PD_2084f2d5-ecce-4358-9d7b-2083629ff478/final/metrics.json`
- netlist candidates: 1 found
