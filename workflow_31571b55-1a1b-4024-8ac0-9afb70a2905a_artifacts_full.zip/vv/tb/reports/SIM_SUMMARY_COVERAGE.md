# Simulation Summary + Coverage

- Total simulation runs: 3
- Simulation pass count: 3
- Simulation fail count: 0
- Coverage status: ok
- Functional coverage %: 71.43
- Coverage bins hit: 10
- Coverage total bins: 14
- Functional bin gaps: 4
- Code line coverage: 35.47%
- Code branch coverage: 4.03%
- Code condition coverage: 4.03%
- Code toggle coverage: 9.59%
- SVA/assertion status: missing
- SVA/assertion pass %: missing
- Formal status: pass
- Golden model status: not_enabled
- Simulator tool: verilator
- Code coverage tool: verilator_coverage
- Formal tool: symbiyosys
- Golden model tool: none

## Functional Coverage Not Met
- outputs.fault_indicator: bins 1/2, missing nonzero, seen values [0]
- outputs.spi_miso: bins 1/2, missing nonzero, seen values [0]
- inputs.clk: bins 1/2, missing zero, seen values [1]
- inputs.reset_n: bins 1/2, missing zero, seen values [1]
