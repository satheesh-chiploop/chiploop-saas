# Simulation Execution Summary

- Total runs: 3
- Pass count: 3
- Fail count: 0

## Results
- smoke_test / seed 1: PASS (rc=0)
- constrained_random_sanity / seed 1: PASS (rc=0)
- spi_transport_frame_directed / seed 1: PASS (rc=0)
