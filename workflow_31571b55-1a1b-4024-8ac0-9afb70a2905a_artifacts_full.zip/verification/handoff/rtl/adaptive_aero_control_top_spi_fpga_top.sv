// Auto-generated FPGA-only serialized transport shell.
// The verified core RTL remains unchanged; ASIC flows continue to use the core top.
module adaptive_aero_control_top_spi_fpga_top (
  input  logic clk,
  input  logic reset_n,
  input  logic spi_sclk,
  input  logic spi_cs_n,
  input  logic spi_mosi,
  output logic spi_miso,
  output logic fault_indicator
);
  localparam integer INPUT_BITS = 204;
  localparam integer OUTPUT_BITS = 213;
  localparam integer FRAME_BITS = 216;
  logic [FRAME_BITS-1:0] rx_shift;
  logic [INPUT_BITS-1:0] rx_active;
  logic [FRAME_BITS-1:0] tx_shift, tx_snapshot;
  logic spi_active;
  logic spi_cs_meta, spi_cs_sync, spi_cs_prev;
  logic reset_meta, reset_sync;
  logic [7:0] core_reg_addr;
  logic [63:0] core_reg_wdata;
  logic core_reg_valid;
  logic core_reg_write_en;
  logic core_req_stream_ready;
  logic core_resp_stream_valid;
  logic [127:0] core_resp_stream_data;
  wire [63:0] core_reg_rdata;
  wire core_reg_ready;
  wire core_req_stream_valid;
  wire [127:0] core_req_stream_data;
  wire core_resp_stream_ready;
  wire [15:0] core_actuator_cmd;
  wire core_status_irq;
  wire core_safe_mode;
  assign core_reg_addr = rx_active[0 +: 8];
  assign core_reg_wdata = rx_active[8 +: 64];
  assign core_reg_valid = rx_active[72 +: 1];
  assign core_reg_write_en = rx_active[73 +: 1];
  assign core_req_stream_ready = rx_active[74 +: 1];
  assign core_resp_stream_valid = rx_active[75 +: 1];
  assign core_resp_stream_data = rx_active[76 +: 128];
  wire [OUTPUT_BITS-1:0] core_response = {core_reg_rdata, core_reg_ready, core_req_stream_valid, core_req_stream_data, core_resp_stream_ready, core_actuator_cmd, core_status_irq, core_safe_mode};
  wire [FRAME_BITS-1:0] framed_response = {core_response, {(FRAME_BITS-OUTPUT_BITS){1'b0}}};
  assign fault_indicator = 1'b0;
  // Asynchronous assertion, synchronous release into the core domain.
  always_ff @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin reset_meta <= 1'b0; reset_sync <= 1'b0; end
    else begin reset_meta <= 1'b1; reset_sync <= reset_meta; end
  end
  // Chip select asynchronously clears only the frame-state bit. Data
  // registers use SPI clock alone, which is legal in ECP5 fabric.
  always_ff @(posedge spi_sclk or posedge spi_cs_n) begin
    if (spi_cs_n) spi_active <= 1'b0;
    else spi_active <= 1'b1;
  end
  always_ff @(posedge spi_sclk) begin
    if (!spi_cs_n) begin
      rx_shift <= {rx_shift[214:0], spi_mosi};
      if (!spi_active) tx_shift <= {tx_snapshot[214:0], 1'b0};
      else tx_shift <= {tx_shift[214:0], 1'b0};
    end
  end
  // Synchronize frame completion into the core clock domain. The host
  // keeps MOSI stable around CS rising as required by the protocol.
  always_ff @(posedge clk) begin
    if (!reset_sync) begin
      spi_cs_meta <= 1'b1; spi_cs_sync <= 1'b1; spi_cs_prev <= 1'b1;
      rx_active <= '0; tx_snapshot <= '0;
    end else begin
      spi_cs_meta <= spi_cs_n; spi_cs_sync <= spi_cs_meta; spi_cs_prev <= spi_cs_sync;
      if (spi_cs_sync && !spi_cs_prev) begin
        rx_active <= rx_shift[INPUT_BITS-1:0];
        // Bundled-data CDC: capture once, then hold this mailbox stable
        // until the next completed frame. The host observes response N in frame N+2.
        tx_snapshot <= framed_response;
      end
    end
  end
  // MISO is a dedicated top-level output. Drive a defined idle value
  // instead of inferring an internal tri-state cell, which is not a
  // portable fabric primitive and breaks mapped equivalence on targets
  // such as ECP5. Board-specific shared-data buses require an explicit
  // vendor I/O-buffer wrapper outside this transport shell.
  always_comb spi_miso = !spi_cs_n ? (spi_active ? tx_shift[FRAME_BITS-1] : tx_snapshot[FRAME_BITS-1]) : 1'b0;
  adaptive_aero_control_top u_core (
    .clk(clk),
    .clk_rst_n(reset_sync),
    .reg_addr(core_reg_addr),
    .reg_wdata(core_reg_wdata),
    .reg_rdata(core_reg_rdata),
    .reg_valid(core_reg_valid),
    .reg_write_en(core_reg_write_en),
    .reg_ready(core_reg_ready),
    .req_stream_valid(core_req_stream_valid),
    .req_stream_ready(core_req_stream_ready),
    .req_stream_data(core_req_stream_data),
    .resp_stream_valid(core_resp_stream_valid),
    .resp_stream_ready(core_resp_stream_ready),
    .resp_stream_data(core_resp_stream_data),
    .actuator_cmd(core_actuator_cmd),
    .status_irq(core_status_irq),
    .safe_mode(core_safe_mode)
  );
endmodule
