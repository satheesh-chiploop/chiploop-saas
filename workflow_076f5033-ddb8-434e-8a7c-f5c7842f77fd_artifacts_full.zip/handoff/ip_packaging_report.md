# IP Packaging & Handoff Report

- Top: `pwm_fpga_demo`
- Package: `backend/workflows/076f5033-ddb8-434e-8a7c-f5c7842f77fd/handoff/pwm_fpga_demo_ip_package`
- Zip: `backend/workflows/076f5033-ddb8-434e-8a7c-f5c7842f77fd/handoff/pwm_fpga_demo_ip_package.zip`

## Bucket counts
- **rtl**: 1
- **spec**: 3
- **arch**: 1
- **microarch**: 1
- **regmap**: 2
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 7
