module pwm_fpga_demo (
    input clk,
    output led
);

reg [7:0] pwm_counter;
reg [7:0] slow_counter;
reg [7:0] duty_cycle;
reg direction;

assign led = (pwm_counter < duty_cycle);

always @(posedge clk) begin
    pwm_counter <= pwm_counter + 8'd1;

    slow_counter <= slow_counter + 8'd1;

    if (slow_counter == 8'hFF) begin
        if (direction) begin
            if (duty_cycle == 8'hFF) begin
                duty_cycle <= 8'hFE;
                direction <= 1'b0;
            end else begin
                duty_cycle <= duty_cycle + 8'd1;
            end
        end else begin
            if (duty_cycle == 8'h00) begin
                duty_cycle <= 8'h01;
                direction <= 1'b1;
            end else begin
                duty_cycle <= duty_cycle - 8'd1;
            end
        end
    end
end

initial begin
    pwm_counter = 8'h00;
    slow_counter = 8'h00;
    duty_cycle = 8'h00;
    direction = 1'b1;
end

endmodule
