# Digital DQA Summary
- workflow_id: `076f5033-ddb8-434e-8a7c-f5c7842f77fd`
- status: `failed`
- rtl files: `1`
- warning count: `0`

## Stage Status
- rtl_lint: `warn`
- cdc: `unavailable`
- reset_integrity: `unavailable`
- synthesis_readiness: `failed`

## Blocking Issues
- yosys_synthesis_errors
