# firmware/integration_contract.md

## 1) Contract overview

- Target: host-side SPI device layer and portable driver service for `intelligent_active_aerodynamics_controller` using approved partition and existing RTL register collateral.
- Deployment status: **portable source ready**, **deployable binary not ready** because the platform contract gate is missing `host_transport_and_board_wrapper`.
- Architecture boundary: **external host ↔ FPGA control gateway**; no claim of an in-platform soft CPU or board-specific wrapper in this contract.
- Primary contract purpose: define the integration surface for commanding active-aero actuators, reading FPGA safety/status, and exchanging metadata-only liveness/state.
- Software-owned prevalidation is required before any actuator command is emitted to the FPGA interface.
- FPGA-owned safety enforcement remains authoritative for clamp, timeout, freshness, sequence, and fault status.
- Host transport is **not selected**; this contract therefore defines the logical API and ownership model, not a concrete bus binding.
- Logging, error reporting, and versioning are part of the contract and must remain stable across portable source revisions.

## 2) Contract version + compatibility policy

**Contract version:** `1.0.0-portable`

**Compatibility policy:**
- **Backward compatible within major version**: additions to optional fields, new status bits, or new non-breaking metadata are allowed.
- **Breaking changes require major version bump**: changes to field meaning, command semantics, sequence rules, or safety state encoding.
- **Host-side driver must reject unknown incompatible major versions** and fall back to a safe no-command state.
- **FPGA register/layout compatibility is strict** for any field used in command, safety, or configuration paths derived from RTL collateral.
- **Transport binding is external to this contract** and must be finalized before any deployable binary is claimed.

## 3) Interfaces

### 3.1 Logical interface summary

| Interface | Producer | Consumer | Purpose | Contract class |
|---|---|---:|---|---|
| `geometry_input` | software | software | STL geometry ingestion from the designated reference source and preprocessing for downstream evaluation | Host-side preprocessing |
| `operating_conditions_input` | software | software | Validated stream velocity and related control-context inputs within the specified envelope | Host-side validated input |
| `surrogate_output` | gpu_service | software | Physics-based surrogate prediction used for control reasoning and comparison | Imported analytic input |
| `reference_output` | software | software | Transparent analytical reference used for traceability and acceptance-gate comparison | Host-side reference computation |
| `actuator_command_output` | software | fpga | Prevalidated bounded command request and metadata sent to the FPGA control gateway | Host-to-FPGA command |
| `safety_status` | fpga | software | Fault, freshness, timeout, clamp, fallback, and sequence state for monitoring and logging | FPGA-to-host status |
| `configuration_interface` | software | fpga | Programmable bounds, timeout thresholds, safe fallback definition, enable bits, and status control | Host-to-FPGA configuration |
| `host_req_rsp_if` | software | fpga | Metadata-only request/response path for command liveness, sequence tracking, and completion/fault reporting | Host-to-FPGA metadata |
| `sensor_bus_if` | external_sensor_or_host | fpga | Vehicle speed and health inputs for operating-envelope monitoring | External sensor ingress |
| `actuator_if` | fpga | actuator_subsystem | Validated and bounded active-aero command output | FPGA-to-actuator drive |
| `irq` | fpga | software | Interrupt/event indication for stale-data, timeout, invalid-command, and saturation conditions | FPGA-to-host event indication |

### 3.2 Interface details

#### `geometry_input`
- **Producer:** software
- **Consumer:** software
- **Behavior:** ingest STL geometry from the designated reference source, validate file integrity, normalize units as required by the host application, and generate preprocessing artifacts for downstream evaluation.
- **Required validation:** file presence, parseability, deterministic geometry hash, and traceable source ID.
- **Failure handling:** reject invalid geometry, log reason, do not forward to command path.

#### `operating_conditions_input`
- **Producer:** software
- **Consumer:** software
- **Behavior:** accept validated stream velocity and context inputs within the specified envelope.
- **Required validation:** range checks, timestamp freshness, and envelope conformance before use.
- **Failure handling:** mark input invalid and prevent command issuance using stale or out-of-envelope data.

#### `surrogate_output`
- **Producer:** gpu_service
- **Consumer:** software
- **Behavior:** consume physics-based surrogate prediction for comparison and control reasoning.
- **Contract expectation:** treated as advisory input; never bypass FPGA safety enforcement.
- **Failure handling:** if unavailable or stale, host must continue only if reference path and safety policy allow; otherwise safe no-command.

#### `reference_output`
- **Producer:** software
- **Consumer:** software
- **Behavior:** compute transparent analytical reference used for traceability and acceptance-gate comparison.
- **Required properties:** deterministic for the same inputs and versioned algorithm identity.
- **Failure handling:** if reference computation fails, log error and suppress actuator command generation.

#### `actuator_command_output`
- **Producer:** software
- **Consumer:** fpga
- **Behavior:** send prevalidated bounded command request plus metadata to the FPGA control gateway.
- **Required semantics:**
  - command value is already bounded by host policy;
  - metadata includes sequence/transaction identity;
  - command issuance only after input validation and config gate pass.
- **Failure handling:** on validation failure, do not transmit a command; emit local error and retain safe state.

#### `safety_status`
- **Producer:** fpga
- **Consumer:** software
- **Behavior:** report fault, freshness, timeout, clamp, fallback, and sequence state.
- **Consumer action:** host must treat any active fault/timeout/clamp/fallback mismatch as authoritative and stop issuing new commands until cleared per policy.
- **Logging:** every status transition affecting command eligibility must be logged with sequence ID and version context.

#### `configuration_interface`
- **Producer:** software
- **Consumer:** fpga
- **Behavior:** program bounds, timeout thresholds, safe fallback definition, enable bits, and status control.
- **Required constraint:** configuration changes must be applied before command issuance for the corresponding operating mode.
- **Failure handling:** rejected config writes must be surfaced in host logs and block command enablement.

#### `host_req_rsp_if`
- **Producer:** software
- **Consumer:** fpga
- **Behavior:** metadata-only request/response for liveness, sequence tracking, completion/fault reporting.
- **Allowed payload:** identifiers, state tokens, completion flags, error/fault codes.
- **Disallowed payload:** actuator setpoint semantics beyond metadata.
- **Failure handling:** sequence mismatch or missing completion response must be reported as a host-visible error and treated as non-acknowledged command state.

#### `sensor_bus_if`
- **Producer:** external_sensor_or_host
- **Consumer:** fpga
- **Behavior:** provide vehicle speed and health inputs for envelope monitoring.
- **Contract note:** transport and sensor interface binding are outside current portable source readiness; logical expectations only are defined here.
- **Failure handling:** missing or invalid sensor data must force the FPGA into its defined safety policy and reflect that in `safety_status`.

#### `actuator_if`
- **Producer:** fpga
- **Consumer:** actuator_subsystem
- **Behavior:** drive validated and bounded active-aero command output.
- **Contract boundary:** host does not directly drive this interface.
- **Safety rule:** only FPGA-authorized bounded outputs may appear here.

#### `irq`
- **Producer:** fpga
- **Consumer:** software
- **Behavior:** event indication for stale-data, timeout, invalid-command, and saturation conditions.
- **Host requirement:** interrupt/event reception must be translated into status logging and command gating decisions.
- **Failure handling:** missed or masked events must not be treated as absence of fault; host must still poll/verify safety status where supported by the selected transport.

## 4) Ownership boundaries

| Area | FW / FPGA responsibility | System/Host responsibility | Validation responsibility |
|---|---|---|---|
| Command bounds enforcement | Authoritative clamp and safety enforcement at gateway | Prevalidate before send; never exceed configured bounds | Verify clamp behavior and no out-of-bounds emission |
| Configuration programming | Accept and apply validated config writes | Generate config payloads and manage mode sequencing | Confirm applied settings match requested settings |
| Safety/status reporting | Generate fault/freshness/timeout/sequence status | Consume, log, and gate command flow | Inject fault cases and confirm host reaction |
| Sequence tracking | Track and report gateway-visible sequence state | Maintain request IDs and map responses | Confirm monotonicity and mismatch handling |
| Reference/surrogate comparison | Not responsible | Compute/consume comparison for control reasoning | Check traceability and determinism of host reference path |

## 5) Assumptions

- `host_transport` remains unspecified until the platform contract gate is ready.
- Existing RTL register collateral is sufficient to define the logical configuration and status semantics used here.
- The host-side driver service is portable and board-agnostic until `host_transport_and_board_wrapper` is added.
- `gpu_service` is external to the FPGA safety boundary and may be absent without invalidating the safety contract.
- The FPGA control gateway is the final authority for safety-related command acceptance.
- No deployable binary should be represented as ready until the missing board wrapper and transport binding are resolved.
- Logging infrastructure exists on the host side to capture command, config, and status transitions.

## 6) Validation hooks

- **Register compatibility check:** verify host-side register encoding/decoding matches RTL collateral for all config/status fields used by the contract.
- **Version gate test:** confirm host rejects incompatible major versions and accepts compatible minor/patch revisions.
- **Geometry ingestion test:** feed valid and invalid STL inputs and confirm deterministic acceptance/rejection behavior.
- **Operating envelope test:** supply in-range and out-of-range operating conditions and confirm command suppression on violations.
- **Reference path test:** verify `reference_output` is deterministic for identical inputs and version-stamped.
- **Surrogate dependency test:** simulate missing/stale `surrogate_output` and confirm safe fallback behavior.
- **Safety status reaction test:** inject fault, timeout, clamp, fallback, and sequence mismatch states via FPGA status model and confirm host halts or gates commands correctly.
- **Configuration write test:** validate successful and rejected config updates, including enable-bit behavior and threshold propagation.
- **Request/response liveness test:** confirm metadata-only request/response sequencing, completion reporting, and fault propagation.
- **Log schema test:** ensure every command/config/status transition emits the required identifiers: contract version, sequence ID, source input version, and outcome code.
- **Transport-agnostic compliance test:** confirm the portable source builds logically without claiming a board-specific binary until the missing wrapper is implemented.