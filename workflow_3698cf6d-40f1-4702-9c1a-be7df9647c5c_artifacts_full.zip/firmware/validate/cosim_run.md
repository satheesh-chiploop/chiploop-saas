<!-- ASSUMPTION: RTL top/module name is supplied externally through RTL_TOP and may differ by integration branch.
ASSUMPTION: RTL source directory and filelist are supplied externally through RTL_DIR and FILELIST and are not hardcoded.
ASSUMPTION: The host-side SPI device layer and driver service are exercised through cocotb/pytest against a Verilator-built simulation.
ASSUMPTION: If a Rust firmware/host component exists for the co-sim flow, its build is optional and gated by the presence of a Cargo manifest or equivalent project metadata.
ASSUMPTION: The platform contract gate is not ready for a deployable binary; this flow is for portable co-simulation validation only. -->

# Co-simulation runner steps

This flow validates the portable host-side SPI device layer and driver service against RTL using Verilator and cocotb.

## Prerequisites

- Verilator installed and available on PATH
- Python 3 installed
- pip packages:
  - cocotb
  - pytest
  - verilator-compatible cocotb integration packages used by your environment
- Optional, if the host-side driver is built from source:
  - Rust toolchain (cargo) for the x86_64-unknown-linux-gnu target

Recommended environment variables:

- `RTL_TOP` — top-level RTL module/entity name
- `RTL_DIR` — RTL source root
- `FILELIST` — RTL filelist for the simulation build
- `COCOTB_TEST_MODULES` — pytest module list for cocotb tests, if not using defaults

## Build RTL simulation with Verilator

If this repository provides a `firmware/validate/verilator_build.md`, follow it as the primary build contract.

Otherwise, use the following canonical command pattern:

```sh
verilator --cc --exe --build \
  -Wall \
  -Wno-fatal \
  -top-module "${RTL_TOP}" \
  -Mdir firmware/validate/verilator_out \
  -f "${FILELIST}"
```

Notes:
- If your environment uses a generated wrapper or additional include paths, pass them through the filelist or command-line overrides.
- If the build flow requires a cocotb-specific make invocation, keep the Verilator compilation step equivalent and let pytest/cocotb drive execution.

## Build firmware or host-side driver service

This project is portable-only at this stage, so a deployable binary is not assumed.

If a Rust host-side component exists and a Cargo manifest is present, build it with:

```sh
cargo build --target x86_64-unknown-linux-gnu
```

If there is no Rust build artifact required for the current test, skip this step.

## Run cocotb via pytest

Run the cocotb test suite after the Verilator model is available:

```sh
pytest -q firmware/validate
```

If your test module selection is explicit, use:

```sh
pytest -q firmware/validate -k "${COCOTB_TEST_MODULES}"
```

If your cocotb setup requires a simulation library path or make-style variables, export them before invoking pytest.

## Expected outputs

The validation flow should create outputs under `firmware/validate/`, typically including:

- Verilator build artifacts in a subdirectory such as `firmware/validate/verilator_out/`
- pytest/cocotb logs on stdout/stderr
- optional JUnit XML report if enabled
- optional coverage artifacts if your Verilator/cocotb setup emits them
- any waveform dumps requested by the testbench, such as VCD or FST files

If JUnit output is enabled, a common path is:

- `firmware/validate/junit.xml`

If coverage is enabled, expect files under a coverage output directory created by the build or test harness.

## Pass/fail criteria

- Verilator build completes successfully
- cocotb/pytest completes with zero test failures
- host-side command and status sequencing matches the RTL register collateral
- any timeout, clamp, stale-data, or invalid-command conditions are reported as expected by the RTL
