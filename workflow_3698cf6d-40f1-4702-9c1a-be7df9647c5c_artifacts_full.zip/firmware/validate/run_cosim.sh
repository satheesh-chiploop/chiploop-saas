#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
VALIDATE_DIR="${ROOT_DIR}/firmware/validate"

RTL_TOP="${RTL_TOP:-<RTL_TOP>}"
RTL_DIR="${RTL_DIR:-<RTL_DIR>}"
FILELIST="${FILELIST:-<FILELIST>}"

mkdir -p "${VALIDATE_DIR}/verilator_out"

if [[ -f "${VALIDATE_DIR}/verilator_build.md" ]]; then
  cat "${VALIDATE_DIR}/verilator_build.md"
fi

if [[ -f "${VALIDATE_DIR}/verilator_build.md" ]]; then
  :
fi

echo "[cosim] RTL_TOP=${RTL_TOP}"
echo "[cosim] RTL_DIR=${RTL_DIR}"
echo "[cosim] FILELIST=${FILELIST}"

if command -v verilator >/dev/null 2>&1; then
  VERILATOR_BIN="$(command -v verilator)"
else
  echo "[cosim] ERROR: verilator not found on PATH" >&2
  exit 1
fi

if [[ ! -f "${FILELIST}" && "${FILELIST}" == "<FILELIST>" ]]; then
  echo "[cosim] ERROR: FILELIST must be provided via FILELIST environment variable" >&2
  exit 1
fi

if [[ ! -d "${RTL_DIR}" && "${RTL_DIR}" == "<RTL_DIR>" ]]; then
  echo "[cosim] ERROR: RTL_DIR must be provided via RTL_DIR environment variable" >&2
  exit 1
fi

if [[ "${RTL_TOP}" == "<RTL_TOP>" ]]; then
  echo "[cosim] ERROR: RTL_TOP must be provided via RTL_TOP environment variable" >&2
  exit 1
fi

BUILD_LOG="${VALIDATE_DIR}/verilator_out/build.log"

set +e
"${VERILATOR_BIN}" --cc --exe --build \
  -Wall \
  -Wno-fatal \
  -top-module "${RTL_TOP}" \
  -Mdir "${VALIDATE_DIR}/verilator_out" \
  -f "${FILELIST}" \
  >"${BUILD_LOG}" 2>&1
VERILATOR_RC=$?
set -e

if [[ ${VERILATOR_RC} -ne 0 ]]; then
  echo "[cosim] ERROR: Verilator build failed; see ${BUILD_LOG}" >&2
  cat "${BUILD_LOG}" >&2
  exit ${VERILATOR_RC}
fi

if command -v cargo >/dev/null 2>&1 && [[ -f "${ROOT_DIR}/Cargo.toml" ]]; then
  echo "[cosim] Building Rust host-side component"
  cargo build --target x86_64-unknown-linux-gnu
else
  echo "[cosim] Skipping Rust build (no Cargo.toml detected or cargo unavailable)"
fi

export COCOTB_RESULTS_FILE="${VALIDATE_DIR}/junit.xml"
export PYTEST_ADDOPTS="${PYTEST_ADDOPTS:-} --junitxml=${COCOTB_RESULTS_FILE}"

echo "[cosim] Running cocotb via pytest"
pytest -q "${VALIDATE_DIR}" "$@" 2>&1 | tee "${VALIDATE_DIR}/pytest.log"
