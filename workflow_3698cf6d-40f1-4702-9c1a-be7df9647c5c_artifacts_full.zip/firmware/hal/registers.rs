use core::ptr::{read_volatile, write_volatile};

pub const BASE_ADDRESS: usize = 0x00000000;

pub const CTRL0_OFFSET: usize = 0x00000000;
pub const CTRL0_MODE_SHIFT: u32 = 0;
pub const CTRL0_MODE_WIDTH: u32 = 3;
pub const CTRL0_MODE_MASK: u64 = 0x0000000000000007;
pub const CTRL0_ENABLE_SHIFT: u32 = 3;
pub const CTRL0_ENABLE_WIDTH: u32 = 1;
pub const CTRL0_ENABLE_MASK: u64 = 0x0000000000000008;
pub const CTRL0_CMD_VALID_SHIFT: u32 = 4;
pub const CTRL0_CMD_VALID_WIDTH: u32 = 1;
pub const CTRL0_CMD_VALID_MASK: u64 = 0x0000000000000010;
pub const CTRL0_CLEAR_STATUS_SHIFT: u32 = 5;
pub const CTRL0_CLEAR_STATUS_WIDTH: u32 = 1;
pub const CTRL0_CLEAR_STATUS_MASK: u64 = 0x0000000000000020;
pub const CTRL0_CLEAR_ON_READ_SHIFT: u32 = 6;
pub const CTRL0_CLEAR_ON_READ_WIDTH: u32 = 1;
pub const CTRL0_CLEAR_ON_READ_MASK: u64 = 0x0000000000000040;
pub const CTRL0_STATUS_CLEAR_W1C_SHIFT: u32 = 7;
pub const CTRL0_STATUS_CLEAR_W1C_WIDTH: u32 = 1;
pub const CTRL0_STATUS_CLEAR_W1C_MASK: u64 = 0x0000000000000080;
pub const CTRL0_SEQ_NUM_SHIFT: u32 = 8;
pub const CTRL0_SEQ_NUM_WIDTH: u32 = 16;
pub const CTRL0_SEQ_NUM_MASK: u64 = 0x0000000000FFFF00;
pub const CTRL0_CMD_AGE_SHIFT: u32 = 24;
pub const CTRL0_CMD_AGE_WIDTH: u32 = 16;
pub const CTRL0_CMD_AGE_MASK: u64 = 0x000000FFFF000000;
pub const CTRL0_STALE_TIMEOUT_SHIFT: u32 = 40;
pub const CTRL0_STALE_TIMEOUT_WIDTH: u32 = 16;
pub const CTRL0_STALE_TIMEOUT_MASK: u64 = 0x00FFFF0000000000;
pub const CTRL0_WATCHDOG_PERIOD_SHIFT: u32 = 56;
pub const CTRL0_WATCHDOG_PERIOD_WIDTH: u32 = 8;
pub const CTRL0_WATCHDOG_PERIOD_MASK: u64 = 0xFF00000000000000;
pub const CTRL1_OFFSET: usize = 0x00000008;
pub const CTRL1_ACT_MIN_SHIFT: u32 = 0;
pub const CTRL1_ACT_MIN_WIDTH: u32 = 32;
pub const CTRL1_ACT_MIN_MASK: u64 = 0x00000000FFFFFFFF;
pub const CTRL1_ACT_MAX_SHIFT: u32 = 32;
pub const CTRL1_ACT_MAX_WIDTH: u32 = 32;
pub const CTRL1_ACT_MAX_MASK: u64 = 0xFFFFFFFF00000000;
pub const CTRL2_OFFSET: usize = 0x00000010;
pub const CTRL2_SAFE_FALLBACK_CMD_SHIFT: u32 = 0;
pub const CTRL2_SAFE_FALLBACK_CMD_WIDTH: u32 = 32;
pub const CTRL2_SAFE_FALLBACK_CMD_MASK: u64 = 0x00000000FFFFFFFF;
pub const CTRL2_RESERVED_SHIFT: u32 = 32;
pub const CTRL2_RESERVED_WIDTH: u32 = 32;
pub const CTRL2_RESERVED_MASK: u64 = 0xFFFFFFFF00000000;
pub const STATUS0_OFFSET: usize = 0x00000018;
pub const STATUS0_BUSY_SHIFT: u32 = 0;
pub const STATUS0_BUSY_WIDTH: u32 = 1;
pub const STATUS0_BUSY_MASK: u64 = 0x0000000000000001;
pub const STATUS0_READY_SHIFT: u32 = 1;
pub const STATUS0_READY_WIDTH: u32 = 1;
pub const STATUS0_READY_MASK: u64 = 0x0000000000000002;
pub const STATUS0_ENABLED_SHIFT: u32 = 2;
pub const STATUS0_ENABLED_WIDTH: u32 = 1;
pub const STATUS0_ENABLED_MASK: u64 = 0x0000000000000004;
pub const STATUS0_MODE_SHIFT: u32 = 3;
pub const STATUS0_MODE_WIDTH: u32 = 3;
pub const STATUS0_MODE_MASK: u64 = 0x0000000000000038;
pub const STATUS0_SPEED_MPS_SHIFT: u32 = 6;
pub const STATUS0_SPEED_MPS_WIDTH: u32 = 16;
pub const STATUS0_SPEED_MPS_MASK: u64 = 0x00000000003FFFC0;
pub const STATUS0_STALE_FAULT_SHIFT: u32 = 22;
pub const STATUS0_STALE_FAULT_WIDTH: u32 = 1;
pub const STATUS0_STALE_FAULT_MASK: u64 = 0x0000000000400000;
pub const STATUS0_TIMEOUT_FAULT_SHIFT: u32 = 23;
pub const STATUS0_TIMEOUT_FAULT_WIDTH: u32 = 1;
pub const STATUS0_TIMEOUT_FAULT_MASK: u64 = 0x0000000000800000;
pub const STATUS0_INVALID_CMD_FAULT_SHIFT: u32 = 24;
pub const STATUS0_INVALID_CMD_FAULT_WIDTH: u32 = 1;
pub const STATUS0_INVALID_CMD_FAULT_MASK: u64 = 0x0000000001000000;
pub const STATUS0_CLAMP_EVENT_SHIFT: u32 = 25;
pub const STATUS0_CLAMP_EVENT_WIDTH: u32 = 1;
pub const STATUS0_CLAMP_EVENT_MASK: u64 = 0x0000000002000000;
pub const STATUS0_FALLBACK_ACTIVE_SHIFT: u32 = 26;
pub const STATUS0_FALLBACK_ACTIVE_WIDTH: u32 = 1;
pub const STATUS0_FALLBACK_ACTIVE_MASK: u64 = 0x0000000004000000;
pub const STATUS0_LAST_SEQ_SHIFT: u32 = 27;
pub const STATUS0_LAST_SEQ_WIDTH: u32 = 16;
pub const STATUS0_LAST_SEQ_MASK: u64 = 0x000007FFF8000000;
pub const STATUS0_RESERVED_SHIFT: u32 = 43;
pub const STATUS0_RESERVED_WIDTH: u32 = 21;
pub const STATUS0_RESERVED_MASK: u64 = 0xFFFFF80000000000;
pub const STATUS1_OFFSET: usize = 0x00000020;
pub const STATUS1_SENSOR_HEALTH_SHIFT: u32 = 0;
pub const STATUS1_SENSOR_HEALTH_WIDTH: u32 = 8;
pub const STATUS1_SENSOR_HEALTH_MASK: u64 = 0x00000000000000FF;
pub const STATUS1_MODEL_LIVENESS_OK_SHIFT: u32 = 8;
pub const STATUS1_MODEL_LIVENESS_OK_WIDTH: u32 = 1;
pub const STATUS1_MODEL_LIVENESS_OK_MASK: u64 = 0x0000000000000100;
pub const STATUS1_MODEL_COMPLETION_CODE_SHIFT: u32 = 9;
pub const STATUS1_MODEL_COMPLETION_CODE_WIDTH: u32 = 8;
pub const STATUS1_MODEL_COMPLETION_CODE_MASK: u64 = 0x000000000001FE00;
pub const STATUS1_MODEL_FAULT_CODE_SHIFT: u32 = 17;
pub const STATUS1_MODEL_FAULT_CODE_WIDTH: u32 = 8;
pub const STATUS1_MODEL_FAULT_CODE_MASK: u64 = 0x0000000001FE0000;
pub const STATUS1_RESERVED_SHIFT: u32 = 25;
pub const STATUS1_RESERVED_WIDTH: u32 = 39;
pub const STATUS1_RESERVED_MASK: u64 = 0xFFFFFFFFFE000000;

#[inline]
fn reg_ptr(offset: usize) -> *mut u64 {
    (BASE_ADDRESS + offset) as *mut u64
}

#[inline]
fn read_reg(offset: usize) -> u64 {
    unsafe { read_volatile(reg_ptr(offset) as *const u64) }
}

#[inline]
fn write_reg(offset: usize, value: u64) {
    unsafe { write_volatile(reg_ptr(offset), value) }
}

#[inline]
pub fn read_ctrl0() -> u64 {
    read_reg(CTRL0_OFFSET)
}

#[inline]
pub fn write_ctrl0(value: u64) {
    write_reg(CTRL0_OFFSET, value)
}

#[inline]
pub fn get_ctrl0_mode() -> u64 {
    (read_ctrl0() & CTRL0_MODE_MASK) >> CTRL0_MODE_SHIFT
}

#[inline]
pub fn set_ctrl0_mode(value: u64) {
    let current = read_ctrl0();
    let next = (current & !CTRL0_MODE_MASK) | ((value << CTRL0_MODE_SHIFT) & CTRL0_MODE_MASK);
    write_ctrl0(next);
}

#[inline]
pub fn get_ctrl0_enable() -> u64 {
    (read_ctrl0() & CTRL0_ENABLE_MASK) >> CTRL0_ENABLE_SHIFT
}

#[inline]
pub fn set_ctrl0_enable(value: u64) {
    let current = read_ctrl0();
    let next = (current & !CTRL0_ENABLE_MASK) | ((value << CTRL0_ENABLE_SHIFT) & CTRL0_ENABLE_MASK);
    write_ctrl0(next);
}

#[inline]
pub fn get_ctrl0_cmd_valid() -> u64 {
    (read_ctrl0() & CTRL0_CMD_VALID_MASK) >> CTRL0_CMD_VALID_SHIFT
}

#[inline]
pub fn set_ctrl0_cmd_valid(value: u64) {
    let current = read_ctrl0();
    let next = (current & !CTRL0_CMD_VALID_MASK) | ((value << CTRL0_CMD_VALID_SHIFT) & CTRL0_CMD_VALID_MASK);
    write_ctrl0(next);
}

#[inline]
pub fn get_ctrl0_clear_status() -> u64 {
    (read_ctrl0() & CTRL0_CLEAR_STATUS_MASK) >> CTRL0_CLEAR_STATUS_SHIFT
}

#[inline]
pub fn set_ctrl0_clear_status(value: u64) {
    let current = read_ctrl0();
    let next = (current & !CTRL0_CLEAR_STATUS_MASK) | ((value << CTRL0_CLEAR_STATUS_SHIFT) & CTRL0_CLEAR_STATUS_MASK);
    write_ctrl0(next);
}

#[inline]
pub fn get_ctrl0_clear_on_read() -> u64 {
    (read_ctrl0() & CTRL0_CLEAR_ON_READ_MASK) >> CTRL0_CLEAR_ON_READ_SHIFT
}

#[inline]
pub fn set_ctrl0_clear_on_read(value: u64) {
    let current = read_ctrl0();
    let next = (current & !CTRL0_CLEAR_ON_READ_MASK) | ((value << CTRL0_CLEAR_ON_READ_SHIFT) & CTRL0_CLEAR_ON_READ_MASK);
    write_ctrl0(next);
}

#[inline]
pub fn get_ctrl0_status_clear_w1c() -> u64 {
    (read_ctrl0() & CTRL0_STATUS_CLEAR_W1C_MASK) >> CTRL0_STATUS_CLEAR_W1C_SHIFT
}

#[inline]
pub fn set_ctrl0_status_clear_w1c(value: u64) {
    let current = read_ctrl0();
    let next = (current & !CTRL0_STATUS_CLEAR_W1C_MASK) | ((value << CTRL0_STATUS_CLEAR_W1C_SHIFT) & CTRL0_STATUS_CLEAR_W1C_MASK);
    write_ctrl0(next);
}

#[inline]
pub fn get_ctrl0_seq_num() -> u64 {
    (read_ctrl0() & CTRL0_SEQ_NUM_MASK) >> CTRL0_SEQ_NUM_SHIFT
}

#[inline]
pub fn set_ctrl0_seq_num(value: u64) {
    let current = read_ctrl0();
    let next = (current & !CTRL0_SEQ_NUM_MASK) | ((value << CTRL0_SEQ_NUM_SHIFT) & CTRL0_SEQ_NUM_MASK);
    write_ctrl0(next);
}

#[inline]
pub fn get_ctrl0_cmd_age() -> u64 {
    (read_ctrl0() & CTRL0_CMD_AGE_MASK) >> CTRL0_CMD_AGE_SHIFT
}

#[inline]
pub fn set_ctrl0_cmd_age(value: u64) {
    let current = read_ctrl0();
    let next = (current & !CTRL0_CMD_AGE_MASK) | ((value << CTRL0_CMD_AGE_SHIFT) & CTRL0_CMD_AGE_MASK);
    write_ctrl0(next);
}

#[inline]
pub fn get_ctrl0_stale_timeout() -> u64 {
    (read_ctrl0() & CTRL0_STALE_TIMEOUT_MASK) >> CTRL0_STALE_TIMEOUT_SHIFT
}

#[inline]
pub fn set_ctrl0_stale_timeout(value: u64) {
    let current = read_ctrl0();
    let next = (current & !CTRL0_STALE_TIMEOUT_MASK) | ((value << CTRL0_STALE_TIMEOUT_SHIFT) & CTRL0_STALE_TIMEOUT_MASK);
    write_ctrl0(next);
}

#[inline]
pub fn get_ctrl0_watchdog_period() -> u64 {
    (read_ctrl0() & CTRL0_WATCHDOG_PERIOD_MASK) >> CTRL0_WATCHDOG_PERIOD_SHIFT
}

#[inline]
pub fn set_ctrl0_watchdog_period(value: u64) {
    let current = read_ctrl0();
    let next = (current & !CTRL0_WATCHDOG_PERIOD_MASK) | ((value << CTRL0_WATCHDOG_PERIOD_SHIFT) & CTRL0_WATCHDOG_PERIOD_MASK);
    write_ctrl0(next);
}

#[inline]
pub fn read_ctrl1() -> u64 {
    read_reg(CTRL1_OFFSET)
}

#[inline]
pub fn write_ctrl1(value: u64) {
    write_reg(CTRL1_OFFSET, value)
}

#[inline]
pub fn get_ctrl1_act_min() -> u64 {
    (read_ctrl1() & CTRL1_ACT_MIN_MASK) >> CTRL1_ACT_MIN_SHIFT
}

#[inline]
pub fn set_ctrl1_act_min(value: u64) {
    let current = read_ctrl1();
    let next = (current & !CTRL1_ACT_MIN_MASK) | ((value << CTRL1_ACT_MIN_SHIFT) & CTRL1_ACT_MIN_MASK);
    write_ctrl1(next);
}

#[inline]
pub fn get_ctrl1_act_max() -> u64 {
    (read_ctrl1() & CTRL1_ACT_MAX_MASK) >> CTRL1_ACT_MAX_SHIFT
}

#[inline]
pub fn set_ctrl1_act_max(value: u64) {
    let current = read_ctrl1();
    let next = (current & !CTRL1_ACT_MAX_MASK) | ((value << CTRL1_ACT_MAX_SHIFT) & CTRL1_ACT_MAX_MASK);
    write_ctrl1(next);
}

#[inline]
pub fn read_ctrl2() -> u64 {
    read_reg(CTRL2_OFFSET)
}

#[inline]
pub fn write_ctrl2(value: u64) {
    write_reg(CTRL2_OFFSET, value)
}

#[inline]
pub fn get_ctrl2_safe_fallback_cmd() -> u64 {
    (read_ctrl2() & CTRL2_SAFE_FALLBACK_CMD_MASK) >> CTRL2_SAFE_FALLBACK_CMD_SHIFT
}

#[inline]
pub fn set_ctrl2_safe_fallback_cmd(value: u64) {
    let current = read_ctrl2();
    let next = (current & !CTRL2_SAFE_FALLBACK_CMD_MASK) | ((value << CTRL2_SAFE_FALLBACK_CMD_SHIFT) & CTRL2_SAFE_FALLBACK_CMD_MASK);
    write_ctrl2(next);
}

#[inline]
pub fn get_ctrl2_reserved() -> u64 {
    (read_ctrl2() & CTRL2_RESERVED_MASK) >> CTRL2_RESERVED_SHIFT
}

#[inline]
pub fn read_status0() -> u64 {
    read_reg(STATUS0_OFFSET)
}

#[inline]
pub fn get_status0_busy() -> u64 {
    (read_status0() & STATUS0_BUSY_MASK) >> STATUS0_BUSY_SHIFT
}

#[inline]
pub fn get_status0_ready() -> u64 {
    (read_status0() & STATUS0_READY_MASK) >> STATUS0_READY_SHIFT
}

#[inline]
pub fn get_status0_enabled() -> u64 {
    (read_status0() & STATUS0_ENABLED_MASK) >> STATUS0_ENABLED_SHIFT
}

#[inline]
pub fn get_status0_mode() -> u64 {
    (read_status0() & STATUS0_MODE_MASK) >> STATUS0_MODE_SHIFT
}

#[inline]
pub fn get_status0_speed_mps() -> u64 {
    (read_status0() & STATUS0_SPEED_MPS_MASK) >> STATUS0_SPEED_MPS_SHIFT
}

#[inline]
pub fn get_status0_stale_fault() -> u64 {
    (read_status0() & STATUS0_STALE_FAULT_MASK) >> STATUS0_STALE_FAULT_SHIFT
}

#[inline]
pub fn get_status0_timeout_fault() -> u64 {
    (read_status0() & STATUS0_TIMEOUT_FAULT_MASK) >> STATUS0_TIMEOUT_FAULT_SHIFT
}

#[inline]
pub fn get_status0_invalid_cmd_fault() -> u64 {
    (read_status0() & STATUS0_INVALID_CMD_FAULT_MASK) >> STATUS0_INVALID_CMD_FAULT_SHIFT
}

#[inline]
pub fn get_status0_clamp_event() -> u64 {
    (read_status0() & STATUS0_CLAMP_EVENT_MASK) >> STATUS0_CLAMP_EVENT_SHIFT
}

#[inline]
pub fn get_status0_fallback_active() -> u64 {
    (read_status0() & STATUS0_FALLBACK_ACTIVE_MASK) >> STATUS0_FALLBACK_ACTIVE_SHIFT
}

#[inline]
pub fn get_status0_last_seq() -> u64 {
    (read_status0() & STATUS0_LAST_SEQ_MASK) >> STATUS0_LAST_SEQ_SHIFT
}

#[inline]
pub fn get_status0_reserved() -> u64 {
    (read_status0() & STATUS0_RESERVED_MASK) >> STATUS0_RESERVED_SHIFT
}

#[inline]
pub fn read_status1() -> u64 {
    read_reg(STATUS1_OFFSET)
}

#[inline]
pub fn get_status1_sensor_health() -> u64 {
    (read_status1() & STATUS1_SENSOR_HEALTH_MASK) >> STATUS1_SENSOR_HEALTH_SHIFT
}

#[inline]
pub fn get_status1_model_liveness_ok() -> u64 {
    (read_status1() & STATUS1_MODEL_LIVENESS_OK_MASK) >> STATUS1_MODEL_LIVENESS_OK_SHIFT
}

#[inline]
pub fn get_status1_model_completion_code() -> u64 {
    (read_status1() & STATUS1_MODEL_COMPLETION_CODE_MASK) >> STATUS1_MODEL_COMPLETION_CODE_SHIFT
}

#[inline]
pub fn get_status1_model_fault_code() -> u64 {
    (read_status1() & STATUS1_MODEL_FAULT_CODE_MASK) >> STATUS1_MODEL_FAULT_CODE_SHIFT
}

#[inline]
pub fn get_status1_reserved() -> u64 {
    (read_status1() & STATUS1_RESERVED_MASK) >> STATUS1_RESERVED_SHIFT
}

