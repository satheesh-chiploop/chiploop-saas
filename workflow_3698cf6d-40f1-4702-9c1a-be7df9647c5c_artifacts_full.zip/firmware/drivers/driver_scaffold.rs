use crate::hal::registers::*;

pub struct DigitalSubsystemDriver;

impl DigitalSubsystemDriver {
    #[inline]
    pub const fn new() -> Self {
        Self
    }

    #[inline]
    pub fn read_ctrl0(&self) -> u32 {
        read_ctrl0()
    }

    #[inline]
    pub fn write_ctrl0(&self, value: u32) {
        write_ctrl0(value)
    }

    #[inline]
    pub fn get_ctrl0_mode(&self) -> u8 {
        get_ctrl0_mode() as u8
    }

    #[inline]
    pub fn set_ctrl0_mode(&self, value: u8) {
        set_ctrl0_mode(value as u32)
    }

    #[inline]
    pub fn get_ctrl0_enable(&self) -> bool {
        get_ctrl0_enable() != 0
    }

    #[inline]
    pub fn set_ctrl0_enable(&self, value: bool) {
        set_ctrl0_enable(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_ctrl0_cmd_valid(&self) -> bool {
        get_ctrl0_cmd_valid() != 0
    }

    #[inline]
    pub fn set_ctrl0_cmd_valid(&self, value: bool) {
        set_ctrl0_cmd_valid(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_ctrl0_clear_status(&self) -> bool {
        get_ctrl0_clear_status() != 0
    }

    #[inline]
    pub fn set_ctrl0_clear_status(&self, value: bool) {
        set_ctrl0_clear_status(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_ctrl0_clear_on_read(&self) -> bool {
        get_ctrl0_clear_on_read() != 0
    }

    #[inline]
    pub fn set_ctrl0_clear_on_read(&self, value: bool) {
        set_ctrl0_clear_on_read(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_ctrl0_status_clear_w1c(&self) -> bool {
        get_ctrl0_status_clear_w1c() != 0
    }

    #[inline]
    pub fn set_ctrl0_status_clear_w1c(&self, value: bool) {
        set_ctrl0_status_clear_w1c(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_ctrl0_seq_num(&self) -> u16 {
        get_ctrl0_seq_num() as u16
    }

    #[inline]
    pub fn set_ctrl0_seq_num(&self, value: u16) {
        set_ctrl0_seq_num(value as u32)
    }

    #[inline]
    pub fn get_ctrl0_cmd_age(&self) -> u16 {
        get_ctrl0_cmd_age() as u16
    }

    #[inline]
    pub fn set_ctrl0_cmd_age(&self, value: u16) {
        set_ctrl0_cmd_age(value as u32)
    }

    #[inline]
    pub fn get_ctrl0_stale_timeout(&self) -> u16 {
        get_ctrl0_stale_timeout() as u16
    }

    #[inline]
    pub fn set_ctrl0_stale_timeout(&self, value: u16) {
        set_ctrl0_stale_timeout(value as u32)
    }

    #[inline]
    pub fn get_ctrl0_watchdog_period(&self) -> u8 {
        get_ctrl0_watchdog_period() as u8
    }

    #[inline]
    pub fn set_ctrl0_watchdog_period(&self, value: u8) {
        set_ctrl0_watchdog_period(value as u32)
    }

    #[inline]
    pub fn read_ctrl1(&self) -> u32 {
        read_ctrl1()
    }

    #[inline]
    pub fn write_ctrl1(&self, value: u32) {
        write_ctrl1(value)
    }

    #[inline]
    pub fn get_ctrl1_act_min(&self) -> u32 {
        get_ctrl1_act_min() as u32
    }

    #[inline]
    pub fn set_ctrl1_act_min(&self, value: u32) {
        set_ctrl1_act_min(value as u32)
    }

    #[inline]
    pub fn get_ctrl1_act_max(&self) -> u32 {
        get_ctrl1_act_max() as u32
    }

    #[inline]
    pub fn set_ctrl1_act_max(&self, value: u32) {
        set_ctrl1_act_max(value as u32)
    }

    #[inline]
    pub fn read_ctrl2(&self) -> u32 {
        read_ctrl2()
    }

    #[inline]
    pub fn write_ctrl2(&self, value: u32) {
        write_ctrl2(value)
    }

    #[inline]
    pub fn get_ctrl2_safe_fallback_cmd(&self) -> u32 {
        get_ctrl2_safe_fallback_cmd() as u32
    }

    #[inline]
    pub fn set_ctrl2_safe_fallback_cmd(&self, value: u32) {
        set_ctrl2_safe_fallback_cmd(value as u32)
    }

    #[inline]
    pub fn get_ctrl2_reserved(&self) -> u32 {
        get_ctrl2_reserved() as u32
    }

    #[inline]
    pub fn read_status0(&self) -> u32 {
        read_status0()
    }

    #[inline]
    pub fn get_status0_busy(&self) -> bool {
        get_status0_busy() != 0
    }

    #[inline]
    pub fn get_status0_ready(&self) -> bool {
        get_status0_ready() != 0
    }

    #[inline]
    pub fn get_status0_enabled(&self) -> bool {
        get_status0_enabled() != 0
    }

    #[inline]
    pub fn get_status0_mode(&self) -> u8 {
        get_status0_mode() as u8
    }

    #[inline]
    pub fn get_status0_speed_mps(&self) -> u16 {
        get_status0_speed_mps() as u16
    }

    #[inline]
    pub fn get_status0_stale_fault(&self) -> bool {
        get_status0_stale_fault() != 0
    }

    #[inline]
    pub fn get_status0_timeout_fault(&self) -> bool {
        get_status0_timeout_fault() != 0
    }

    #[inline]
    pub fn get_status0_invalid_cmd_fault(&self) -> bool {
        get_status0_invalid_cmd_fault() != 0
    }

    #[inline]
    pub fn get_status0_clamp_event(&self) -> bool {
        get_status0_clamp_event() != 0
    }

    #[inline]
    pub fn get_status0_fallback_active(&self) -> bool {
        get_status0_fallback_active() != 0
    }

    #[inline]
    pub fn get_status0_last_seq(&self) -> u16 {
        get_status0_last_seq() as u16
    }

    #[inline]
    pub fn get_status0_reserved(&self) -> u32 {
        get_status0_reserved() as u32
    }

    #[inline]
    pub fn read_status1(&self) -> u32 {
        read_status1()
    }

    #[inline]
    pub fn get_status1_sensor_health(&self) -> u8 {
        get_status1_sensor_health() as u8
    }

    #[inline]
    pub fn get_status1_model_liveness_ok(&self) -> bool {
        get_status1_model_liveness_ok() != 0
    }

    #[inline]
    pub fn get_status1_model_completion_code(&self) -> u8 {
        get_status1_model_completion_code() as u8
    }

    #[inline]
    pub fn get_status1_model_fault_code(&self) -> u8 {
        get_status1_model_fault_code() as u8
    }

    #[inline]
    pub fn get_status1_reserved(&self) -> u32 {
        get_status1_reserved() as u32
    }

}
