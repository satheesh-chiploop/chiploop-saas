// ASSUMPTION: Interrupt decode is software-mediated using firmware-visible status/interrupt bits.
// ASSUMPTION: No MCU-style external vector table is generated unless the hardware contract explicitly requires one.

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum InterruptSource {
    Ready,
    StaleFault,
    TimeoutFault,
    InvalidCmdFault,
    ModelFaultCode,
}

#[inline]
pub fn interrupt_count() -> usize {
    5
}

pub const READY_BIT: u32 = 0;
pub const STALE_FAULT_BIT: u32 = 1;
pub const TIMEOUT_FAULT_BIT: u32 = 2;
pub const INVALID_CMD_FAULT_BIT: u32 = 3;
pub const MODEL_FAULT_CODE_BIT: u32 = 4;

#[inline]
pub fn handle_ready() {
    // Default ISR scaffold: replace with concrete firmware behavior as needed.
}

#[inline]
pub fn handle_stale_fault() {
    // Default ISR scaffold: replace with concrete firmware behavior as needed.
}

#[inline]
pub fn handle_timeout_fault() {
    // Default ISR scaffold: replace with concrete firmware behavior as needed.
}

#[inline]
pub fn handle_invalid_cmd_fault() {
    // Default ISR scaffold: replace with concrete firmware behavior as needed.
}

#[inline]
pub fn handle_model_fault_code() {
    // Default ISR scaffold: replace with concrete firmware behavior as needed.
}

#[inline]
pub fn dispatch_interrupt(bit_index: u32) -> bool {
    match bit_index {
        READY_BIT => { handle_ready(); true }
        STALE_FAULT_BIT => { handle_stale_fault(); true }
        TIMEOUT_FAULT_BIT => { handle_timeout_fault(); true }
        INVALID_CMD_FAULT_BIT => { handle_invalid_cmd_fault(); true }
        MODEL_FAULT_CODE_BIT => { handle_model_fault_code(); true }
        _ => false,
    }
}
