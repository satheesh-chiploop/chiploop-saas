# Functional Coverage Summary

- Top module: pwm_controller
- Functional coverage: 0.0%
- Bins hit: 0
- Total bins: 0

## Outputs

## Inputs
