# Simulation Summary + Coverage

- Total simulation runs: 2
- Simulation pass count: 2
- Simulation fail count: 0
- Coverage status: ok
- Functional coverage %: 0.0
- Coverage bins hit: 0
- Coverage total bins: 0
- Functional bin gaps: 0
- Code line coverage: 0.0%
- Code branch coverage: 0.0%
- Code condition coverage: 0.0%
- Code toggle coverage: 0.0%
- SVA/assertion status: missing
- SVA/assertion pass %: missing
- Formal status: not_enabled
- Golden model status: not_enabled
- Simulator tool: verilator
- Code coverage tool: verilator_coverage
- Formal tool: none
- Golden model tool: none

## Functional Coverage Not Met
