# Coverage Gap Analysis

- Functional coverage: 50.0 / target 100.0%
- Code line coverage: 32.89 / target 90.0%
- Code branch coverage: 0.0 / target 80.0%
- Code condition coverage: 0.0 / target 80.0%
- Code toggle coverage: 2.23 / target 80.0%
- Gap count: 15
- Functional bin gaps: 10

## Functional Coverage Gaps
- outputs.counter_value: bins 1/2, missing nonzero, seen values [0]
- outputs.pwm_out: bins 1/2, missing nonzero, seen values [0]
- outputs.rd_data: bins 1/2, missing nonzero, seen values [0]
- inputs.clk: bins 1/2, missing zero, seen values [1]
- inputs.rd_addr: bins 1/2, missing nonzero, seen values [0]
- inputs.rd_en: bins 1/2, missing nonzero, seen values [0]
- inputs.reset_n: bins 1/2, missing zero, seen values [1]
- inputs.wr_addr: bins 1/2, missing nonzero, seen values [0]
- inputs.wr_data: bins 1/2, missing nonzero, seen values [0]
- inputs.wr_en: bins 1/2, missing nonzero, seen values [0]

## Recommended Actions
- high: add_directed_tests - Coverage holes should first be mapped to explicit scenarios so closure is explainable.
- medium: increase_random_seeds - More seeds may close random-observable bins after directed gaps are handled.
- medium: review_coverage_model - Unreachable or incorrectly specified bins should be waived or corrected, not chased indefinitely.
