# Failure Triage

- Failing testcase/seed pairs: 6
- unknown seed 1: simulation_failure - Replay the failing seed with waveform and full logs.
- unknown seed 2: simulation_failure - Replay the failing seed with waveform and full logs.
- unknown seed 7: simulation_failure - Replay the failing seed with waveform and full logs.
- unknown seed 1: simulation_failure - Replay the failing seed with waveform and full logs.
- unknown seed 2: simulation_failure - Replay the failing seed with waveform and full logs.
- unknown seed 7: simulation_failure - Replay the failing seed with waveform and full logs.
