# System Simulation Summary + Coverage

- Top module: None
- Status: None
- Total simulation runs: None
- Simulation pass count: None
- Simulation fail count: None
- Total runtime (s): None
- Coverage status: ok
- Functional coverage %: None
- Coverage bins hit: None
- Coverage total bins: None
- Code line coverage %: None
- Code branch coverage %: None
- Code condition coverage %: None
- Code toggle coverage %: None
- Assertions total: None
- Assertion failures: None
- Formal status: tool_unavailable
- Golden model status: generated
