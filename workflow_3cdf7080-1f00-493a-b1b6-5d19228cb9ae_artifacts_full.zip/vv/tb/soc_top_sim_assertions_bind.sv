/*
 * Auto-generated system SVA bind file.
 * Uses only top-level signals declared in the resolved system contract.
 */
bind soc_top_sim soc_top_sim_assertions u_soc_top_sim_assertions (

);
