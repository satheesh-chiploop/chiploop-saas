/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/b2becb3f-e33e-4448-ad20-a3d4bbff9f97/bc35b903-47fd-46c4-81a4-0bca16b058f4/digital/arch2synthesis/handoff/rtl/uart_baud_tick_gen.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/b2becb3f-e33e-4448-ad20-a3d4bbff9f97/bc35b903-47fd-46c4-81a4-0bca16b058f4/digital/arch2synthesis/handoff/rtl/uart_fifo_16x8.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/b2becb3f-e33e-4448-ad20-a3d4bbff9f97/bc35b903-47fd-46c4-81a4-0bca16b058f4/digital/arch2synthesis/handoff/rtl/uart_packet_engine.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/b2becb3f-e33e-4448-ad20-a3d4bbff9f97/bc35b903-47fd-46c4-81a4-0bca16b058f4/digital/arch2synthesis/handoff/rtl/uart_packet_monitor.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/b2becb3f-e33e-4448-ad20-a3d4bbff9f97/bc35b903-47fd-46c4-81a4-0bca16b058f4/digital/arch2synthesis/handoff/rtl/uart_register_file.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/b2becb3f-e33e-4448-ad20-a3d4bbff9f97/bc35b903-47fd-46c4-81a4-0bca16b058f4/digital/arch2synthesis/handoff/rtl/uart_rx_engine.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/b2becb3f-e33e-4448-ad20-a3d4bbff9f97/bc35b903-47fd-46c4-81a4-0bca16b058f4/digital/arch2synthesis/handoff/rtl/uart_tx_engine.v
