# Digital Synthesis Summary

- **Workflow**: b2becb3f-e33e-4448-ad20-a3d4bbff9f97
- **Status**: `ok` (rc=0)
- **Top module**: `uart_packet_engine`
- **Clock**: `clk` @ **10.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/b2becb3f-e33e-4448-ad20-a3d4bbff9f97/bc35b903-47fd-46c4-81a4-0bca16b058f4/digital/arch2synthesis/digital/synth/runs/Digital_Arch2Synthesis_b2becb3f-e33e-4448-ad20-a3d4bbff9f97/final/metrics.json`
- netlist candidates: 1 found
