module uart_packet_engine (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    uart_rx,
    rd_data,
    uart_tx,
    irq,
    rx_fifo_level,
    tx_fifo_level,
    packet_count
);
    input clk;
    input reset_n;
    input wr_en;
    input [7:0] wr_addr;
    input [7:0] wr_data;
    input rd_en;
    input [7:0] rd_addr;
    input uart_rx;
    output [7:0] rd_data;
    output uart_tx;
    output irq;
    output [5:0] rx_fifo_level;
    output [5:0] tx_fifo_level;
    output [15:0] packet_count;
    wire control_enable;
    wire control_rx_enable;
    wire control_tx_enable;
    wire control_loopback;
    wire control_irq_enable;
    wire [15:0] baud_div;
    wire [7:0] packet_len;
    wire tx_fifo_push_req;
    wire [7:0] tx_fifo_push_data;
    wire rx_fifo_pop_req;
    wire irq_clear_rx_done;
    wire irq_clear_tx_done;
    wire irq_clear_rx_overflow;
    wire irq_clear_tx_underflow;
    wire irq_clear_framing_error;
    wire irq_clear_packet_done;
    wire [7:0] reg_rd_data;
    wire baud_tick;
    wire tx_fifo_rd_req;
    wire tx_busy;
    wire tx_underflow_error;
    wire tx_done_pulse;
    wire [7:0] tx_byte_out;
    wire tx_byte_valid;
    wire rx_fifo_wr_req;
    wire [7:0] rx_fifo_wr_data;
    wire rx_busy;
    wire rx_overflow_error;
    wire framing_error;
    wire rx_done_pulse;
    wire packet_active;
    wire packet_done;
    wire error;
    wire irq_rx_done;
    wire irq_tx_done;
    wire irq_rx_overflow;
    wire irq_tx_underflow;
    wire irq_framing_error;
    wire irq_packet_done;
    wire tx_fifo_empty;
    wire tx_fifo_full;
    wire [5:0] tx_fifo_level_i;
    wire tx_fifo_push_error;
    wire tx_fifo_pop_error;
    wire rx_fifo_empty;
    wire rx_fifo_full;
    wire [5:0] rx_fifo_level_i;
    wire rx_fifo_push_error;
    wire rx_fifo_pop_error;
    wire [7:0] tx_fifo_rd_data;
    wire [7:0] rx_fifo_rd_data;

    assign rd_data = reg_rd_data;
    assign uart_tx = uart_tx_i;
    assign irq = control_irq_enable & (irq_rx_done | irq_tx_done | irq_rx_overflow | irq_tx_underflow | irq_framing_error | irq_packet_done);
    assign rx_fifo_level = rx_fifo_level_i;
    assign tx_fifo_level = tx_fifo_level_i;

    uart_register_file u_uart_register_file (
        .clk(clk),
        .reset_n(reset_n),
        .wr_en(wr_en),
        .wr_addr(wr_addr),
        .wr_data(wr_data),
        .rd_en(rd_en),
        .rd_addr(rd_addr),
        .status_tx_empty(tx_fifo_empty),
        .status_tx_full(tx_fifo_full),
        .status_rx_empty(rx_fifo_empty),
        .status_rx_full(rx_fifo_full),
        .status_tx_busy(tx_busy),
        .status_rx_busy(rx_busy),
        .status_packet_active(packet_active),
        .status_error(error),
        .irq_rx_done(irq_rx_done),
        .irq_tx_done(irq_tx_done),
        .irq_rx_overflow(irq_rx_overflow),
        .irq_tx_underflow(irq_tx_underflow),
        .irq_framing_error(irq_framing_error),
        .irq_packet_done(irq_packet_done),
        .rx_fifo_push_data(rx_fifo_rd_data),
        .rx_fifo_pop_data(rx_fifo_rd_data),
        .packet_count(packet_count),
        .control_enable(control_enable),
        .control_rx_enable(control_rx_enable),
        .control_tx_enable(control_tx_enable),
        .control_loopback(control_loopback),
        .control_irq_enable(control_irq_enable),
        .baud_div(baud_div),
        .packet_len(packet_len),
        .tx_fifo_push_req(tx_fifo_push_req),
        .tx_fifo_push_data(tx_fifo_push_data),
        .rx_fifo_pop_req(rx_fifo_pop_req),
        .irq_clear_rx_done(irq_clear_rx_done),
        .irq_clear_tx_done(irq_clear_tx_done),
        .irq_clear_rx_overflow(irq_clear_rx_overflow),
        .irq_clear_tx_underflow(irq_clear_tx_underflow),
        .irq_clear_framing_error(irq_clear_framing_error),
        .irq_clear_packet_done(irq_clear_packet_done),
        .rd_data(reg_rd_data)
    );

    uart_baud_tick_gen u_uart_baud_tick_gen (
        .clk(clk),
        .reset_n(reset_n),
        .baud_div(baud_div),
        .enable(control_enable),
        .baud_tick(baud_tick)
    );

    uart_tx_engine u_uart_tx_engine (
        .clk(clk),
        .reset_n(reset_n),
        .baud_tick(baud_tick),
        .enable(control_enable & control_tx_enable),
        .tx_fifo_empty(tx_fifo_empty),
        .tx_fifo_rd_data(tx_fifo_rd_data),
        .tx_fifo_rd_req(tx_fifo_rd_req),
        .tx_busy(tx_busy),
        .tx_underflow_error(tx_underflow_error),
        .tx_done_pulse(tx_done_pulse),
        .uart_tx(uart_tx_i),
        .tx_byte_out(tx_byte_out),
        .tx_byte_valid(tx_byte_valid)
    );

    uart_rx_engine u_uart_rx_engine (
        .clk(clk),
        .reset_n(reset_n),
        .baud_tick(baud_tick),
        .enable(control_enable & control_rx_enable),
        .uart_rx(uart_rx),
        .rx_fifo_full(rx_fifo_full),
        .rx_fifo_wr_req(rx_fifo_wr_req),
        .rx_fifo_wr_data(rx_fifo_wr_data),
        .rx_busy(rx_busy),
        .rx_overflow_error(rx_overflow_error),
        .framing_error(framing_error),
        .rx_done_pulse(rx_done_pulse)
    );

    uart_fifo_16x8 u_uart_tx_fifo (
        .clk(clk),
        .reset_n(reset_n),
        .wr_req(tx_fifo_push_req),
        .wr_data(tx_fifo_push_data),
        .rd_req(tx_fifo_rd_req),
        .rd_data(tx_fifo_rd_data),
        .empty(tx_fifo_empty),
        .full(tx_fifo_full),
        .level(tx_fifo_level_i),
        .push_error(tx_fifo_push_error),
        .pop_error(tx_fifo_pop_error)
    );

    uart_fifo_16x8 u_uart_rx_fifo (
        .clk(clk),
        .reset_n(reset_n),
        .wr_req(rx_fifo_wr_req),
        .wr_data(rx_fifo_wr_data),
        .rd_req(rx_fifo_pop_req),
        .rd_data(rx_fifo_rd_data),
        .empty(rx_fifo_empty),
        .full(rx_fifo_full),
        .level(rx_fifo_level_i),
        .push_error(rx_fifo_push_error),
        .pop_error(rx_fifo_pop_error)
    );

    uart_packet_monitor u_uart_packet_monitor (
        .clk(clk),
        .reset_n(reset_n),
        .enable(control_enable & (control_loopback | control_irq_enable)),
        .packet_len(packet_len),
        .tx_byte_valid(tx_byte_valid),
        .rx_byte_valid(rx_done_pulse),
        .tx_done_pulse(tx_done_pulse),
        .rx_done_pulse(rx_done_pulse),
        .rx_overflow_error(rx_overflow_error | rx_fifo_push_error),
        .tx_underflow_error(tx_underflow_error | tx_fifo_pop_error),
        .framing_error(framing_error),
        .packet_active(packet_active),
        .packet_done(packet_done),
        .packet_count(packet_count),
        .error(error),
        .irq_rx_done(irq_rx_done),
        .irq_tx_done(irq_tx_done),
        .irq_rx_overflow(irq_rx_overflow),
        .irq_tx_underflow(irq_tx_underflow),
        .irq_framing_error(irq_framing_error),
        .irq_packet_done(irq_packet_done)
    );

    wire uart_tx_i;
endmodule
