module uart_rx_engine (
    clk,
    reset_n,
    baud_tick,
    enable,
    uart_rx,
    rx_fifo_full,
    rx_fifo_wr_req,
    rx_fifo_wr_data,
    rx_busy,
    rx_overflow_error,
    framing_error,
    rx_done_pulse
);
    input clk;
    input reset_n;
    input baud_tick;
    input enable;
    input uart_rx;
    input rx_fifo_full;
    output rx_fifo_wr_req;
    output [7:0] rx_fifo_wr_data;
    output rx_busy;
    output rx_overflow_error;
    output framing_error;
    output rx_done_pulse;

    localparam RX_IDLE = 3'd0;
    localparam RX_START = 3'd1;
    localparam RX_DATA = 3'd2;
    localparam RX_STOP = 3'd3;

    reg [2:0] state;
    reg [2:0] bit_idx;
    reg [7:0] shreg;
    reg rx_fifo_wr_req_r;
    reg [7:0] rx_fifo_wr_data_r;
    reg rx_busy_r;
    reg rx_overflow_error_r;
    reg framing_error_r;
    reg rx_done_pulse_r;

    assign rx_fifo_wr_req = rx_fifo_wr_req_r;
    assign rx_fifo_wr_data = rx_fifo_wr_data_r;
    assign rx_busy = rx_busy_r;
    assign rx_overflow_error = rx_overflow_error_r;
    assign framing_error = framing_error_r;
    assign rx_done_pulse = rx_done_pulse_r;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            state <= RX_IDLE;
            bit_idx <= 3'd0;
            shreg <= 8'd0;
            rx_fifo_wr_req_r <= 1'b0;
            rx_fifo_wr_data_r <= 8'd0;
            rx_busy_r <= 1'b0;
            rx_overflow_error_r <= 1'b0;
            framing_error_r <= 1'b0;
            rx_done_pulse_r <= 1'b0;
        end else begin
            rx_fifo_wr_req_r <= 1'b0;
            rx_done_pulse_r <= 1'b0;
            if (!enable) begin
                state <= RX_IDLE;
                rx_busy_r <= 1'b0;
            end else if (baud_tick) begin
                case (state)
                    RX_IDLE: begin
                        rx_busy_r <= 1'b0;
                        if (uart_rx == 1'b0) begin
                            state <= RX_START;
                            rx_busy_r <= 1'b1;
                        end
                    end
                    RX_START: begin
                        if (uart_rx != 1'b0) begin
                            framing_error_r <= 1'b1;
                            state <= RX_IDLE;
                            rx_busy_r <= 1'b0;
                        end else begin
                            bit_idx <= 3'd0;
                            state <= RX_DATA;
                        end
                    end
                    RX_DATA: begin
                        shreg[bit_idx] <= uart_rx;
                        if (bit_idx == 3'd7) begin
                            state <= RX_STOP;
                        end else begin
                            bit_idx <= bit_idx + 3'd1;
                        end
                    end
                    default: begin
                        if (uart_rx != 1'b1) begin
                            framing_error_r <= 1'b1;
                        end else if (!rx_fifo_full) begin
                            rx_fifo_wr_req_r <= 1'b1;
                            rx_fifo_wr_data_r <= shreg;
                            rx_done_pulse_r <= 1'b1;
                        end else begin
                            rx_overflow_error_r <= 1'b1;
                        end
                        rx_busy_r <= 1'b0;
                        state <= RX_IDLE;
                    end
                endcase
            end
        end
    end
endmodule
