module uart_register_file (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    status_tx_empty,
    status_tx_full,
    status_rx_empty,
    status_rx_full,
    status_tx_busy,
    status_rx_busy,
    status_packet_active,
    status_error,
    irq_rx_done,
    irq_tx_done,
    irq_rx_overflow,
    irq_tx_underflow,
    irq_framing_error,
    irq_packet_done,
    rx_fifo_push_data,
    rx_fifo_pop_data,
    packet_count,
    control_enable,
    control_rx_enable,
    control_tx_enable,
    control_loopback,
    control_irq_enable,
    baud_div,
    packet_len,
    tx_fifo_push_req,
    tx_fifo_push_data,
    rx_fifo_pop_req,
    irq_clear_rx_done,
    irq_clear_tx_done,
    irq_clear_rx_overflow,
    irq_clear_tx_underflow,
    irq_clear_framing_error,
    irq_clear_packet_done,
    rd_data
);
    input clk;
    input reset_n;
    input wr_en;
    input [7:0] wr_addr;
    input [7:0] wr_data;
    input rd_en;
    input [7:0] rd_addr;
    input status_tx_empty;
    input status_tx_full;
    input status_rx_empty;
    input status_rx_full;
    input status_tx_busy;
    input status_rx_busy;
    input status_packet_active;
    input status_error;
    input irq_rx_done;
    input irq_tx_done;
    input irq_rx_overflow;
    input irq_tx_underflow;
    input irq_framing_error;
    input irq_packet_done;
    input [7:0] rx_fifo_push_data;
    input [7:0] rx_fifo_pop_data;
    input [15:0] packet_count;
    output control_enable;
    output control_rx_enable;
    output control_tx_enable;
    output control_loopback;
    output control_irq_enable;
    output [15:0] baud_div;
    output [7:0] packet_len;
    output tx_fifo_push_req;
    output [7:0] tx_fifo_push_data;
    output rx_fifo_pop_req;
    output irq_clear_rx_done;
    output irq_clear_tx_done;
    output irq_clear_rx_overflow;
    output irq_clear_tx_underflow;
    output irq_clear_framing_error;
    output irq_clear_packet_done;
    output [7:0] rd_data;
    reg [7:0] control_reg;
    reg [15:0] baud_div_reg;
    reg [7:0] packet_len_reg;
    reg [7:0] irq_clear_r;
    reg [7:0] rd_data_r;
    reg tx_fifo_push_req_r;
    reg rx_fifo_pop_req_r;

    assign control_enable = control_reg[0];
    assign control_rx_enable = control_reg[1];
    assign control_tx_enable = control_reg[2];
    assign control_loopback = control_reg[3];
    assign control_irq_enable = control_reg[4];
    assign baud_div = baud_div_reg;
    assign packet_len = packet_len_reg;
    assign tx_fifo_push_req = tx_fifo_push_req_r;
    assign tx_fifo_push_data = wr_data;
    assign rx_fifo_pop_req = rx_fifo_pop_req_r;
    assign irq_clear_rx_done = irq_clear_r[0];
    assign irq_clear_tx_done = irq_clear_r[1];
    assign irq_clear_rx_overflow = irq_clear_r[2];
    assign irq_clear_tx_underflow = irq_clear_r[3];
    assign irq_clear_framing_error = irq_clear_r[4];
    assign irq_clear_packet_done = irq_clear_r[5];
    assign rd_data = rd_data_r;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            control_reg <= 8'd0;
            baud_div_reg <= 16'd0;
            packet_len_reg <= 8'd0;
            irq_clear_r <= 8'd0;
            rd_data_r <= 8'd0;
            tx_fifo_push_req_r <= 1'b0;
            rx_fifo_pop_req_r <= 1'b0;
        end else begin
            tx_fifo_push_req_r <= 1'b0;
            rx_fifo_pop_req_r <= 1'b0;
            irq_clear_r <= 8'd0;
            if (wr_en) begin
                case (wr_addr)
                    8'h00: control_reg <= wr_data;
                    8'h04: baud_div_reg[7:0] <= wr_data;
                    8'h05: baud_div_reg[15:8] <= wr_data;
                    8'h08: packet_len_reg <= wr_data;
                    8'h0C: begin
                        tx_fifo_push_req_r <= 1'b1;
                    end
                    8'h1C: irq_clear_r <= wr_data;
                    default: begin
                    end
                endcase
            end
            if (rd_en) begin
                case (rd_addr)
                    8'h00: rd_data_r <= control_reg;
                    8'h04: rd_data_r <= baud_div_reg[7:0];
                    8'h05: rd_data_r <= baud_div_reg[15:8];
                    8'h08: rd_data_r <= packet_len_reg;
                    8'h10: begin
                        rx_fifo_pop_req_r <= 1'b1;
                        rd_data_r <= rx_fifo_pop_data;
                    end
                    8'h14: rd_data_r <= {status_error, status_packet_active, status_rx_busy, status_tx_busy, status_rx_full, status_rx_empty, status_tx_full, status_tx_empty};
                    8'h18: rd_data_r <= {2'b00, irq_packet_done, irq_framing_error, irq_tx_underflow, irq_rx_overflow, irq_tx_done, irq_rx_done};
                    8'h20: rd_data_r <= packet_count[7:0];
                    8'h21: rd_data_r <= packet_count[15:8];
                    default: rd_data_r <= 8'd0;
                endcase
            end
        end
    end
endmodule
