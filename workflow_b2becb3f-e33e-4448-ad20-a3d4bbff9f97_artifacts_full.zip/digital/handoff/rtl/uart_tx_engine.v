module uart_tx_engine (
    clk,
    reset_n,
    baud_tick,
    enable,
    tx_fifo_empty,
    tx_fifo_rd_data,
    tx_fifo_rd_req,
    tx_busy,
    tx_underflow_error,
    tx_done_pulse,
    uart_tx,
    tx_byte_out,
    tx_byte_valid
);
    input clk;
    input reset_n;
    input baud_tick;
    input enable;
    input tx_fifo_empty;
    input [7:0] tx_fifo_rd_data;
    output tx_fifo_rd_req;
    output tx_busy;
    output tx_underflow_error;
    output tx_done_pulse;
    output uart_tx;
    output [7:0] tx_byte_out;
    output tx_byte_valid;

    localparam S_IDLE = 3'd0;
    localparam S_START = 3'd1;
    localparam S_DATA = 3'd2;
    localparam S_STOP = 3'd3;

    reg [2:0] state;
    reg [2:0] bit_idx;
    reg [7:0] shreg;
    reg tx_fifo_rd_req_r;
    reg tx_busy_r;
    reg tx_underflow_error_r;
    reg tx_done_pulse_r;
    reg uart_tx_r;
    reg [7:0] tx_byte_out_r;
    reg tx_byte_valid_r;

    assign tx_fifo_rd_req = tx_fifo_rd_req_r;
    assign tx_busy = tx_busy_r;
    assign tx_underflow_error = tx_underflow_error_r;
    assign tx_done_pulse = tx_done_pulse_r;
    assign uart_tx = uart_tx_r;
    assign tx_byte_out = tx_byte_out_r;
    assign tx_byte_valid = tx_byte_valid_r;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            state <= S_IDLE;
            bit_idx <= 3'd0;
            shreg <= 8'd0;
            tx_fifo_rd_req_r <= 1'b0;
            tx_busy_r <= 1'b0;
            tx_underflow_error_r <= 1'b0;
            tx_done_pulse_r <= 1'b0;
            uart_tx_r <= 1'b1;
            tx_byte_out_r <= 8'd0;
            tx_byte_valid_r <= 1'b0;
        end else begin
            tx_fifo_rd_req_r <= 1'b0;
            tx_done_pulse_r <= 1'b0;
            tx_byte_valid_r <= 1'b0;
            if (!enable) begin
                state <= S_IDLE;
                tx_busy_r <= 1'b0;
                uart_tx_r <= 1'b1;
            end else if (baud_tick) begin
                case (state)
                    S_IDLE: begin
                        tx_busy_r <= 1'b0;
                        uart_tx_r <= 1'b1;
                        if (!tx_fifo_empty) begin
                            tx_fifo_rd_req_r <= 1'b1;
                            shreg <= tx_fifo_rd_data;
                            tx_byte_out_r <= tx_fifo_rd_data;
                            tx_busy_r <= 1'b1;
                            uart_tx_r <= 1'b0;
                            state <= S_START;
                        end else begin
                            tx_underflow_error_r <= 1'b1;
                        end
                    end
                    S_START: begin
                        uart_tx_r <= shreg[0];
                        bit_idx <= 3'd1;
                        state <= S_DATA;
                    end
                    S_DATA: begin
                        uart_tx_r <= shreg[bit_idx];
                        if (bit_idx == 3'd7) begin
                            state <= S_STOP;
                        end else begin
                            bit_idx <= bit_idx + 3'd1;
                        end
                    end
                    default: begin
                        uart_tx_r <= 1'b1;
                        tx_done_pulse_r <= 1'b1;
                        tx_byte_valid_r <= 1'b1;
                        tx_busy_r <= 1'b0;
                        state <= S_IDLE;
                    end
                endcase
            end
        end
    end
endmodule
