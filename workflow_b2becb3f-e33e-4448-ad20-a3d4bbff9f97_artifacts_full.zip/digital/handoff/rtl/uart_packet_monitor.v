module uart_packet_monitor (
    clk,
    reset_n,
    enable,
    packet_len,
    tx_byte_valid,
    rx_byte_valid,
    tx_done_pulse,
    rx_done_pulse,
    rx_overflow_error,
    tx_underflow_error,
    framing_error,
    packet_active,
    packet_done,
    packet_count,
    error,
    irq_rx_done,
    irq_tx_done,
    irq_rx_overflow,
    irq_tx_underflow,
    irq_framing_error,
    irq_packet_done
);
    input clk;
    input reset_n;
    input enable;
    input [7:0] packet_len;
    input tx_byte_valid;
    input rx_byte_valid;
    input tx_done_pulse;
    input rx_done_pulse;
    input rx_overflow_error;
    input tx_underflow_error;
    input framing_error;
    output packet_active;
    output packet_done;
    output [15:0] packet_count;
    output error;
    output irq_rx_done;
    output irq_tx_done;
    output irq_rx_overflow;
    output irq_tx_underflow;
    output irq_framing_error;
    output irq_packet_done;

    reg [15:0] packet_count_r;
    reg [7:0] byte_count;
    reg packet_active_r;
    reg packet_done_r;
    reg error_r;
    reg irq_rx_done_r;
    reg irq_tx_done_r;
    reg irq_rx_overflow_r;
    reg irq_tx_underflow_r;
    reg irq_framing_error_r;
    reg irq_packet_done_r;

    assign packet_active = packet_active_r;
    assign packet_done = packet_done_r;
    assign packet_count = packet_count_r;
    assign error = error_r;
    assign irq_rx_done = irq_rx_done_r;
    assign irq_tx_done = irq_tx_done_r;
    assign irq_rx_overflow = irq_rx_overflow_r;
    assign irq_tx_underflow = irq_tx_underflow_r;
    assign irq_framing_error = irq_framing_error_r;
    assign irq_packet_done = irq_packet_done_r;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            packet_count_r <= 16'd0;
            byte_count <= 8'd0;
            packet_active_r <= 1'b0;
            packet_done_r <= 1'b0;
            error_r <= 1'b0;
            irq_rx_done_r <= 1'b0;
            irq_tx_done_r <= 1'b0;
            irq_rx_overflow_r <= 1'b0;
            irq_tx_underflow_r <= 1'b0;
            irq_framing_error_r <= 1'b0;
            irq_packet_done_r <= 1'b0;
        end else begin
            packet_done_r <= 1'b0;
            irq_rx_done_r <= 1'b0;
            irq_tx_done_r <= 1'b0;
            irq_rx_overflow_r <= 1'b0;
            irq_tx_underflow_r <= 1'b0;
            irq_framing_error_r <= 1'b0;
            irq_packet_done_r <= 1'b0;
            error_r <= rx_overflow_error | tx_underflow_error | framing_error;
            if (enable) begin
                if (tx_done_pulse) begin
                    irq_tx_done_r <= 1'b1;
                    packet_active_r <= 1'b1;
                    if (packet_len != 8'd0) begin
                        if (byte_count == packet_len - 8'd1) begin
                            packet_done_r <= 1'b1;
                            irq_packet_done_r <= 1'b1;
                            packet_count_r <= packet_count_r + 16'd1;
                            byte_count <= 8'd0;
                            packet_active_r <= 1'b0;
                        end else begin
                            byte_count <= byte_count + 8'd1;
                        end
                    end
                end
                if (rx_done_pulse || rx_byte_valid) begin
                    irq_rx_done_r <= 1'b1;
                    packet_active_r <= 1'b1;
                    if (packet_len != 8'd0) begin
                        if (byte_count == packet_len - 8'd1) begin
                            packet_done_r <= 1'b1;
                            irq_packet_done_r <= 1'b1;
                            packet_count_r <= packet_count_r + 16'd1;
                            byte_count <= 8'd0;
                            packet_active_r <= 1'b0;
                        end else begin
                            byte_count <= byte_count + 8'd1;
                        end
                    end
                end
                if (rx_overflow_error) irq_rx_overflow_r <= 1'b1;
                if (tx_underflow_error) irq_tx_underflow_r <= 1'b1;
                if (framing_error) irq_framing_error_r <= 1'b1;
            end else begin
                packet_active_r <= 1'b0;
                byte_count <= 8'd0;
            end
        end
    end
endmodule
