module uart_baud_tick_gen (
    clk,
    reset_n,
    baud_div,
    enable,
    baud_tick
);
    input clk;
    input reset_n;
    input [15:0] baud_div;
    input enable;
    output baud_tick;

    reg [15:0] div_cnt;
    reg baud_tick_r;

    assign baud_tick = baud_tick_r;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            div_cnt <= 16'd0;
            baud_tick_r <= 1'b0;
        end else begin
            baud_tick_r <= 1'b0;
            if (enable) begin
                if (baud_div == 16'd0) begin
                    baud_tick_r <= 1'b0;
                    div_cnt <= 16'd0;
                end else if (div_cnt == 16'd0) begin
                    baud_tick_r <= 1'b1;
                    div_cnt <= baud_div - 16'd1;
                end else begin
                    div_cnt <= div_cnt - 16'd1;
                end
            end else begin
                div_cnt <= baud_div;
            end
        end
    end
endmodule
