module uart_fifo_16x8 (
    clk,
    reset_n,
    wr_req,
    wr_data,
    rd_req,
    rd_data,
    empty,
    full,
    level,
    push_error,
    pop_error
);
    input clk;
    input reset_n;
    input wr_req;
    input [7:0] wr_data;
    input rd_req;
    output [7:0] rd_data;
    output empty;
    output full;
    output [5:0] level;
    output push_error;
    output pop_error;

    reg [7:0] mem [0:15];
    reg [3:0] wr_ptr;
    reg [3:0] rd_ptr;
    reg [4:0] count;
    reg [7:0] rd_data_r;
    reg push_error_r;
    reg pop_error_r;

    assign rd_data = rd_data_r;
    assign empty = (count == 5'd0);
    assign full = (count == 5'd16);
    assign level = {1'b0, count};
    assign push_error = push_error_r;
    assign pop_error = pop_error_r;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            wr_ptr <= 4'd0;
            rd_ptr <= 4'd0;
            count <= 5'd0;
            rd_data_r <= 8'd0;
            push_error_r <= 1'b0;
            pop_error_r <= 1'b0;
        end else begin
            push_error_r <= 1'b0;
            pop_error_r <= 1'b0;
            if (wr_req && !full) begin
                mem[wr_ptr] <= wr_data;
                wr_ptr <= wr_ptr + 4'd1;
                if (!(rd_req && !empty)) begin
                    count <= count + 5'd1;
                end
            end else if (wr_req && full) begin
                push_error_r <= 1'b1;
            end

            if (rd_req && !empty) begin
                rd_data_r <= mem[rd_ptr];
                rd_ptr <= rd_ptr + 4'd1;
                if (!(wr_req && !full)) begin
                    count <= count - 5'd1;
                end
            end else if (rd_req && empty) begin
                pop_error_r <= 1'b1;
            end
            if (wr_req && !full && rd_req && !empty) begin
                count <= count;
            end
        end
    end
endmodule
