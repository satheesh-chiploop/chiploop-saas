# IP Packaging & Handoff Report

- Top: `imported_from_arch2rtl`
- Package: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/b2becb3f-e33e-4448-ad20-a3d4bbff9f97/bc35b903-47fd-46c4-81a4-0bca16b058f4/digital/arch2synthesis/handoff/imported_from_arch2rtl_ip_package`
- Zip: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/b2becb3f-e33e-4448-ad20-a3d4bbff9f97/bc35b903-47fd-46c4-81a4-0bca16b058f4/digital/arch2synthesis/handoff/imported_from_arch2rtl_ip_package.zip`

## Bucket counts
- **rtl**: 7
- **spec**: 1
- **arch**: 0
- **microarch**: 0
- **regmap**: 1
- **constraints**: 0
- **power_intent**: 0
- **verification**: 0
- **reports**: 0
- **other**: 2
