# IP Packaging & Handoff Report

- Top: `motor_control_top`
- Package: `backend/workflows/3383be5b-5d10-4e41-bd22-bfbe761fc8ba/handoff/motor_control_top_ip_package`
- Zip: `backend/workflows/3383be5b-5d10-4e41-bd22-bfbe761fc8ba/handoff/motor_control_top_ip_package.zip`

## Bucket counts
- **rtl**: 0
- **spec**: 3
- **arch**: 1
- **microarch**: 1
- **regmap**: 2
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 4
