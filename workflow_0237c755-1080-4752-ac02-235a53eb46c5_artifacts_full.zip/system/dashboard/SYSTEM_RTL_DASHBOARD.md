# System RTL Evidence Dashboard

## System
- Top module: temp_monitor_soc_sim
- RTL files: 10
- Modules: 7
- Input bits: 54
- Output bits: 43
- Flip-flops: 140
- Latches: 0
- Full-cycle paths: 3
- Half-cycle paths: 7

## Soc
- Top module: temp_monitor_soc_sim
- RTL files: 0
- Modules: 0
- Input bits: 0
- Output bits: 0
- Flip-flops: 0
- Latches: 0
- Full-cycle paths: 0
- Half-cycle paths: 0

## Digital
- Top module: temp_monitor_soc_phys
- RTL files: 10
- Modules: 7
- Input bits: 54
- Output bits: 43
- Flip-flops: 140
- Latches: 0
- Full-cycle paths: 3
- Half-cycle paths: 7

## Analog
- Top module: analog_macro
- RTL files: 0
- Modules: 0
- Input bits: 0
- Output bits: 0
- Flip-flops: 0
- Latches: 0
- Full-cycle paths: 0
- Half-cycle paths: 0
