.include "/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0237c755-1080-4752-ac02-235a53eb46c5/869ce829-4b7b-4a70-a506-3d8f967b3e44/digital/analog/lib_char/temp_sensor_adc_model.spice"
* Placeholder characterization deck. Real Liberty requires block-specific stimuli and measurements.
.control
op
write op.raw
quit
.endc
.end
