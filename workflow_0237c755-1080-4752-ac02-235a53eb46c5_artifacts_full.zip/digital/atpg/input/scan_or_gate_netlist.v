module temp_monitor_soc_phys (alert_irq,
    alert_status,
    avdd,
    avss,
    clk,
    rd_en,
    rst_n,
    sample_req,
    scan_en,
    wr_en,
    rd_addr,
    rd_data,
    scan_in,
    scan_out,
    sensor_temp_celsius,
    temp_code,
    threshold_code,
    wr_addr,
    wr_data);
 output alert_irq;
 output alert_status;
 input avdd;
 input avss;
 input clk;
 input rd_en;
 input rst_n;
 output sample_req;
 input scan_en;
 input wr_en;
 input [7:0] rd_addr;
 output [15:0] rd_data;
 input [3:0] scan_in;
 output [3:0] scan_out;
 input [15:0] sensor_temp_celsius;
 output [11:0] temp_code;
 output [11:0] threshold_code;
 input [7:0] wr_addr;
 input [15:0] wr_data;

 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire _086_;
 wire _087_;
 wire _088_;
 wire _089_;
 wire _090_;
 wire _091_;
 wire _092_;
 wire _093_;
 wire _094_;
 wire _095_;
 wire _096_;
 wire _097_;
 wire _098_;
 wire _099_;
 wire _100_;
 wire _101_;
 wire _102_;
 wire _103_;
 wire _104_;
 wire _105_;
 wire _106_;
 wire _107_;
 wire _108_;
 wire _109_;
 wire _110_;
 wire _111_;
 wire _112_;
 wire _113_;
 wire _114_;
 wire _115_;
 wire _116_;
 wire _117_;
 wire _118_;
 wire _119_;
 wire _120_;
 wire _121_;
 wire _122_;
 wire _123_;
 wire _124_;
 wire _125_;
 wire _126_;
 wire _127_;
 wire _128_;
 wire _129_;
 wire _130_;
 wire _131_;
 wire _132_;
 wire _133_;
 wire _134_;
 wire _135_;
 wire _136_;
 wire _137_;
 wire _138_;
 wire _139_;
 wire _140_;
 wire _141_;
 wire _142_;
 wire _143_;
 wire _144_;
 wire _145_;
 wire _146_;
 wire _147_;
 wire _148_;
 wire _149_;
 wire _150_;
 wire _151_;
 wire _152_;
 wire _153_;
 wire _154_;
 wire _155_;
 wire _156_;
 wire _157_;
 wire _158_;
 wire _159_;
 wire _160_;
 wire _161_;
 wire _162_;
 wire _163_;
 wire _164_;
 wire _165_;
 wire _166_;
 wire _167_;
 wire _168_;
 wire _169_;
 wire _170_;
 wire _171_;
 wire _172_;
 wire _173_;
 wire _174_;
 wire _175_;
 wire _176_;
 wire _177_;
 wire _178_;
 wire _179_;
 wire _180_;
 wire _181_;
 wire _182_;
 wire _183_;
 wire _184_;
 wire _185_;
 wire _186_;
 wire _187_;
 wire _188_;
 wire _189_;
 wire _190_;
 wire _191_;
 wire _192_;
 wire _193_;
 wire _194_;
 wire _195_;
 wire _196_;
 wire _197_;
 wire _198_;
 wire _199_;
 wire _200_;
 wire _201_;
 wire _202_;
 wire _203_;
 wire _204_;
 wire _205_;
 wire _206_;
 wire _207_;
 wire _208_;
 wire _209_;
 wire _210_;
 wire _211_;
 wire _212_;
 wire _213_;
 wire _214_;
 wire _215_;
 wire _216_;
 wire _217_;
 wire _218_;
 wire _219_;
 wire _220_;
 wire _221_;
 wire _222_;
 wire _223_;
 wire _224_;
 wire _225_;
 wire _226_;
 wire _227_;
 wire _228_;
 wire _229_;
 wire _230_;
 wire \u_digital.adc_code[0] ;
 wire \u_digital.adc_code[10] ;
 wire \u_digital.adc_code[11] ;
 wire \u_digital.adc_code[1] ;
 wire \u_digital.adc_code[2] ;
 wire \u_digital.adc_code[3] ;
 wire \u_digital.adc_code[4] ;
 wire \u_digital.adc_code[5] ;
 wire \u_digital.adc_code[6] ;
 wire \u_digital.adc_code[7] ;
 wire \u_digital.adc_code[8] ;
 wire \u_digital.adc_code[9] ;
 wire \u_digital.adc_valid ;
 wire \u_digital.irq_manager_control_irq_enable ;
 wire \u_digital.irq_manager_irq_clear_alert_pulse ;
 wire \u_digital.irq_manager_irq_clear_sample_done_pulse ;
 wire \u_digital.irq_manager_irq_status_alert ;
 wire \u_digital.irq_manager_irq_status_sample_done ;
 wire \u_digital.irq_manager_status_sample_done ;
 wire \u_digital.register_map_control_enable ;
 wire \u_digital.register_map_irq_status_alert ;
 wire \u_digital.register_map_irq_status_sample_done ;
 wire \u_digital.register_map_latest_temp[0] ;
 wire \u_digital.register_map_latest_temp[10] ;
 wire \u_digital.register_map_latest_temp[11] ;
 wire \u_digital.register_map_latest_temp[1] ;
 wire \u_digital.register_map_latest_temp[2] ;
 wire \u_digital.register_map_latest_temp[3] ;
 wire \u_digital.register_map_latest_temp[4] ;
 wire \u_digital.register_map_latest_temp[5] ;
 wire \u_digital.register_map_latest_temp[6] ;
 wire \u_digital.register_map_latest_temp[7] ;
 wire \u_digital.register_map_latest_temp[8] ;
 wire \u_digital.register_map_latest_temp[9] ;
 wire \u_digital.register_map_sample_count[0] ;
 wire \u_digital.register_map_sample_count[10] ;
 wire \u_digital.register_map_sample_count[11] ;
 wire \u_digital.register_map_sample_count[12] ;
 wire \u_digital.register_map_sample_count[13] ;
 wire \u_digital.register_map_sample_count[14] ;
 wire \u_digital.register_map_sample_count[15] ;
 wire \u_digital.register_map_sample_count[1] ;
 wire \u_digital.register_map_sample_count[2] ;
 wire \u_digital.register_map_sample_count[3] ;
 wire \u_digital.register_map_sample_count[4] ;
 wire \u_digital.register_map_sample_count[5] ;
 wire \u_digital.register_map_sample_count[6] ;
 wire \u_digital.register_map_sample_count[7] ;
 wire \u_digital.register_map_sample_count[8] ;
 wire \u_digital.register_map_sample_count[9] ;
 wire \u_digital.register_map_status_adc_valid_seen ;
 wire \u_digital.register_map_status_alert_pending ;
 wire \u_digital.register_map_status_busy ;
 wire \u_digital.register_map_status_sample_done ;
 wire \u_digital.u_register_map.adc_code_r[0] ;
 wire \u_digital.u_register_map.adc_code_r[10] ;
 wire \u_digital.u_register_map.adc_code_r[11] ;
 wire \u_digital.u_register_map.adc_code_r[1] ;
 wire \u_digital.u_register_map.adc_code_r[2] ;
 wire \u_digital.u_register_map.adc_code_r[3] ;
 wire \u_digital.u_register_map.adc_code_r[4] ;
 wire \u_digital.u_register_map.adc_code_r[5] ;
 wire \u_digital.u_register_map.adc_code_r[6] ;
 wire \u_digital.u_register_map.adc_code_r[7] ;
 wire \u_digital.u_register_map.adc_code_r[8] ;
 wire \u_digital.u_register_map.adc_code_r[9] ;
 wire \u_digital.u_register_map.adc_valid_r ;
 wire \u_digital.u_register_map.control_enable_next ;
 wire \u_digital.u_register_map.control_irq_enable_next ;
 wire \u_digital.u_register_map.irq_clear_alert_pulse_next ;
 wire \u_digital.u_register_map.irq_clear_sample_done_pulse_next ;
 wire \u_digital.u_register_map.irq_status_alert_next ;
 wire \u_digital.u_register_map.irq_status_sample_done_next ;
 wire \u_digital.u_register_map.latest_temp_next[0] ;
 wire \u_digital.u_register_map.latest_temp_next[10] ;
 wire \u_digital.u_register_map.latest_temp_next[11] ;
 wire \u_digital.u_register_map.latest_temp_next[1] ;
 wire \u_digital.u_register_map.latest_temp_next[2] ;
 wire \u_digital.u_register_map.latest_temp_next[3] ;
 wire \u_digital.u_register_map.latest_temp_next[4] ;
 wire \u_digital.u_register_map.latest_temp_next[5] ;
 wire \u_digital.u_register_map.latest_temp_next[6] ;
 wire \u_digital.u_register_map.latest_temp_next[7] ;
 wire \u_digital.u_register_map.latest_temp_next[8] ;
 wire \u_digital.u_register_map.latest_temp_next[9] ;
 wire \u_digital.u_register_map.rd_data_next[0] ;
 wire \u_digital.u_register_map.rd_data_next[10] ;
 wire \u_digital.u_register_map.rd_data_next[11] ;
 wire \u_digital.u_register_map.rd_data_next[12] ;
 wire \u_digital.u_register_map.rd_data_next[13] ;
 wire \u_digital.u_register_map.rd_data_next[14] ;
 wire \u_digital.u_register_map.rd_data_next[15] ;
 wire \u_digital.u_register_map.rd_data_next[1] ;
 wire \u_digital.u_register_map.rd_data_next[2] ;
 wire \u_digital.u_register_map.rd_data_next[3] ;
 wire \u_digital.u_register_map.rd_data_next[4] ;
 wire \u_digital.u_register_map.rd_data_next[5] ;
 wire \u_digital.u_register_map.rd_data_next[6] ;
 wire \u_digital.u_register_map.rd_data_next[7] ;
 wire \u_digital.u_register_map.rd_data_next[8] ;
 wire \u_digital.u_register_map.rd_data_next[9] ;
 wire \u_digital.u_register_map.sample_count_next[0] ;
 wire \u_digital.u_register_map.sample_count_next[10] ;
 wire \u_digital.u_register_map.sample_count_next[11] ;
 wire \u_digital.u_register_map.sample_count_next[12] ;
 wire \u_digital.u_register_map.sample_count_next[13] ;
 wire \u_digital.u_register_map.sample_count_next[14] ;
 wire \u_digital.u_register_map.sample_count_next[15] ;
 wire \u_digital.u_register_map.sample_count_next[1] ;
 wire \u_digital.u_register_map.sample_count_next[2] ;
 wire \u_digital.u_register_map.sample_count_next[3] ;
 wire \u_digital.u_register_map.sample_count_next[4] ;
 wire \u_digital.u_register_map.sample_count_next[5] ;
 wire \u_digital.u_register_map.sample_count_next[6] ;
 wire \u_digital.u_register_map.sample_count_next[7] ;
 wire \u_digital.u_register_map.sample_count_next[8] ;
 wire \u_digital.u_register_map.sample_count_next[9] ;
 wire \u_digital.u_register_map.sample_req_next ;
 wire \u_digital.u_register_map.status_adc_valid_seen_next ;
 wire \u_digital.u_register_map.status_alert_pending_next ;
 wire \u_digital.u_register_map.status_busy_next ;
 wire \u_digital.u_register_map.status_sample_done_next ;
 wire \u_digital.u_register_map.threshold_next[0] ;
 wire \u_digital.u_register_map.threshold_next[10] ;
 wire \u_digital.u_register_map.threshold_next[11] ;
 wire \u_digital.u_register_map.threshold_next[1] ;
 wire \u_digital.u_register_map.threshold_next[2] ;
 wire \u_digital.u_register_map.threshold_next[3] ;
 wire \u_digital.u_register_map.threshold_next[4] ;
 wire \u_digital.u_register_map.threshold_next[5] ;
 wire \u_digital.u_register_map.threshold_next[6] ;
 wire \u_digital.u_register_map.threshold_next[7] ;
 wire \u_digital.u_register_map.threshold_next[8] ;
 wire \u_digital.u_register_map.threshold_next[9] ;
 wire \u_digital.u_temp_filter_compare.filtered_next[0] ;
 wire \u_digital.u_temp_filter_compare.filtered_next[10] ;
 wire \u_digital.u_temp_filter_compare.filtered_next[11] ;
 wire \u_digital.u_temp_filter_compare.filtered_next[1] ;
 wire \u_digital.u_temp_filter_compare.filtered_next[2] ;
 wire \u_digital.u_temp_filter_compare.filtered_next[3] ;
 wire \u_digital.u_temp_filter_compare.filtered_next[4] ;
 wire \u_digital.u_temp_filter_compare.filtered_next[5] ;
 wire \u_digital.u_temp_filter_compare.filtered_next[6] ;
 wire \u_digital.u_temp_filter_compare.filtered_next[7] ;
 wire \u_digital.u_temp_filter_compare.filtered_next[8] ;
 wire \u_digital.u_temp_filter_compare.filtered_next[9] ;
 wire \u_digital.u_temp_filter_compare.prev_sample[0] ;
 wire \u_digital.u_temp_filter_compare.prev_sample[10] ;
 wire \u_digital.u_temp_filter_compare.prev_sample[11] ;
 wire \u_digital.u_temp_filter_compare.prev_sample[1] ;
 wire \u_digital.u_temp_filter_compare.prev_sample[2] ;
 wire \u_digital.u_temp_filter_compare.prev_sample[3] ;
 wire \u_digital.u_temp_filter_compare.prev_sample[4] ;
 wire \u_digital.u_temp_filter_compare.prev_sample[5] ;
 wire \u_digital.u_temp_filter_compare.prev_sample[6] ;
 wire \u_digital.u_temp_filter_compare.prev_sample[7] ;
 wire \u_digital.u_temp_filter_compare.prev_sample[8] ;
 wire \u_digital.u_temp_filter_compare.prev_sample[9] ;

 sky130_fd_sc_hd__inv_2 _231_ (.A(threshold_code[11]),
    .Y(_017_));
 sky130_fd_sc_hd__inv_2 _232_ (.A(\u_digital.irq_manager_status_sample_done ),
    .Y(_018_));
 sky130_fd_sc_hd__inv_2 _233_ (.A(threshold_code[10]),
    .Y(_019_));
 sky130_fd_sc_hd__inv_2 _234_ (.A(threshold_code[9]),
    .Y(_020_));
 sky130_fd_sc_hd__inv_2 _235_ (.A(threshold_code[8]),
    .Y(_021_));
 sky130_fd_sc_hd__inv_2 _236_ (.A(threshold_code[7]),
    .Y(_022_));
 sky130_fd_sc_hd__inv_2 _237_ (.A(threshold_code[6]),
    .Y(_023_));
 sky130_fd_sc_hd__inv_2 _238_ (.A(threshold_code[5]),
    .Y(_024_));
 sky130_fd_sc_hd__inv_2 _239_ (.A(threshold_code[4]),
    .Y(_025_));
 sky130_fd_sc_hd__inv_2 _240_ (.A(threshold_code[3]),
    .Y(_026_));
 sky130_fd_sc_hd__inv_2 _241_ (.A(threshold_code[1]),
    .Y(_027_));
 sky130_fd_sc_hd__inv_2 _242_ (.A(threshold_code[0]),
    .Y(_028_));
 sky130_fd_sc_hd__inv_2 _243_ (.A(\u_digital.adc_valid ),
    .Y(_029_));
 sky130_fd_sc_hd__inv_2 _244_ (.A(wr_addr[4]),
    .Y(_030_));
 sky130_fd_sc_hd__inv_2 _245_ (.A(rd_addr[3]),
    .Y(_031_));
 sky130_fd_sc_hd__or4_2 _246_ (.A(wr_addr[1]),
    .B(wr_addr[0]),
    .C(wr_addr[2]),
    .D(wr_addr[3]),
    .X(_032_));
 sky130_fd_sc_hd__or4b_2 _247_ (.A(wr_addr[5]),
    .B(wr_addr[7]),
    .C(wr_addr[6]),
    .D_N(wr_en),
    .X(_033_));
 sky130_fd_sc_hd__nor3_2 _248_ (.A(wr_addr[4]),
    .B(_032_),
    .C(_033_),
    .Y(_034_));
 sky130_fd_sc_hd__mux2_1 _249_ (.A0(\u_digital.irq_manager_control_irq_enable ),
    .A1(wr_data[2]),
    .S(_034_),
    .X(\u_digital.u_register_map.control_irq_enable_next ));
 sky130_fd_sc_hd__mux2_1 _250_ (.A0(\u_digital.register_map_control_enable ),
    .A1(wr_data[0]),
    .S(_034_),
    .X(\u_digital.u_register_map.control_enable_next ));
 sky130_fd_sc_hd__or4b_2 _251_ (.A(wr_addr[1]),
    .B(wr_addr[0]),
    .C(wr_addr[2]),
    .D_N(wr_addr[3]),
    .X(_035_));
 sky130_fd_sc_hd__or3_2 _252_ (.A(wr_addr[4]),
    .B(_033_),
    .C(_035_),
    .X(_036_));
 sky130_fd_sc_hd__mux2_1 _253_ (.A0(wr_data[0]),
    .A1(threshold_code[0]),
    .S(_036_),
    .X(\u_digital.u_register_map.threshold_next[0] ));
 sky130_fd_sc_hd__mux2_1 _254_ (.A0(wr_data[1]),
    .A1(threshold_code[1]),
    .S(_036_),
    .X(\u_digital.u_register_map.threshold_next[1] ));
 sky130_fd_sc_hd__mux2_1 _255_ (.A0(wr_data[2]),
    .A1(threshold_code[2]),
    .S(_036_),
    .X(\u_digital.u_register_map.threshold_next[2] ));
 sky130_fd_sc_hd__mux2_1 _256_ (.A0(wr_data[3]),
    .A1(threshold_code[3]),
    .S(_036_),
    .X(\u_digital.u_register_map.threshold_next[3] ));
 sky130_fd_sc_hd__mux2_1 _257_ (.A0(wr_data[4]),
    .A1(threshold_code[4]),
    .S(_036_),
    .X(\u_digital.u_register_map.threshold_next[4] ));
 sky130_fd_sc_hd__mux2_1 _258_ (.A0(wr_data[5]),
    .A1(threshold_code[5]),
    .S(_036_),
    .X(\u_digital.u_register_map.threshold_next[5] ));
 sky130_fd_sc_hd__mux2_1 _259_ (.A0(wr_data[6]),
    .A1(threshold_code[6]),
    .S(_036_),
    .X(\u_digital.u_register_map.threshold_next[6] ));
 sky130_fd_sc_hd__mux2_1 _260_ (.A0(wr_data[7]),
    .A1(threshold_code[7]),
    .S(_036_),
    .X(\u_digital.u_register_map.threshold_next[7] ));
 sky130_fd_sc_hd__mux2_1 _261_ (.A0(wr_data[8]),
    .A1(threshold_code[8]),
    .S(_036_),
    .X(\u_digital.u_register_map.threshold_next[8] ));
 sky130_fd_sc_hd__mux2_1 _262_ (.A0(wr_data[9]),
    .A1(threshold_code[9]),
    .S(_036_),
    .X(\u_digital.u_register_map.threshold_next[9] ));
 sky130_fd_sc_hd__mux2_1 _263_ (.A0(wr_data[10]),
    .A1(threshold_code[10]),
    .S(_036_),
    .X(\u_digital.u_register_map.threshold_next[10] ));
 sky130_fd_sc_hd__mux2_1 _264_ (.A0(wr_data[11]),
    .A1(threshold_code[11]),
    .S(_036_),
    .X(\u_digital.u_register_map.threshold_next[11] ));
 sky130_fd_sc_hd__and2_2 _265_ (.A(\u_digital.u_temp_filter_compare.prev_sample[1] ),
    .B(\u_digital.adc_code[1] ),
    .X(_037_));
 sky130_fd_sc_hd__xor2_2 _266_ (.A(\u_digital.u_temp_filter_compare.prev_sample[1] ),
    .B(\u_digital.adc_code[1] ),
    .X(_038_));
 sky130_fd_sc_hd__nand2_2 _267_ (.A(\u_digital.u_temp_filter_compare.prev_sample[0] ),
    .B(\u_digital.adc_code[0] ),
    .Y(_039_));
 sky130_fd_sc_hd__xnor2_2 _268_ (.A(_038_),
    .B(_039_),
    .Y(_040_));
 sky130_fd_sc_hd__mux2_1 _269_ (.A0(\u_digital.adc_code[0] ),
    .A1(_040_),
    .S(\u_digital.irq_manager_status_sample_done ),
    .X(_041_));
 sky130_fd_sc_hd__mux2_1 _270_ (.A0(\u_digital.register_map_latest_temp[0] ),
    .A1(_041_),
    .S(\u_digital.adc_valid ),
    .X(\u_digital.u_temp_filter_compare.filtered_next[0] ));
 sky130_fd_sc_hd__a31o_2 _271_ (.A1(\u_digital.u_temp_filter_compare.prev_sample[0] ),
    .A2(\u_digital.adc_code[0] ),
    .A3(_038_),
    .B1(_037_),
    .X(_042_));
 sky130_fd_sc_hd__nor2_2 _272_ (.A(\u_digital.u_temp_filter_compare.prev_sample[2] ),
    .B(\u_digital.adc_code[2] ),
    .Y(_043_));
 sky130_fd_sc_hd__and2_2 _273_ (.A(\u_digital.u_temp_filter_compare.prev_sample[2] ),
    .B(\u_digital.adc_code[2] ),
    .X(_044_));
 sky130_fd_sc_hd__nor2_2 _274_ (.A(_043_),
    .B(_044_),
    .Y(_045_));
 sky130_fd_sc_hd__nand2_2 _275_ (.A(_042_),
    .B(_045_),
    .Y(_046_));
 sky130_fd_sc_hd__o21a_2 _276_ (.A1(_042_),
    .A2(_045_),
    .B1(\u_digital.irq_manager_status_sample_done ),
    .X(_047_));
 sky130_fd_sc_hd__a22o_2 _277_ (.A1(\u_digital.adc_code[1] ),
    .A2(_018_),
    .B1(_046_),
    .B2(_047_),
    .X(_048_));
 sky130_fd_sc_hd__mux2_1 _278_ (.A0(\u_digital.register_map_latest_temp[1] ),
    .A1(_048_),
    .S(\u_digital.adc_valid ),
    .X(\u_digital.u_temp_filter_compare.filtered_next[1] ));
 sky130_fd_sc_hd__or2_2 _279_ (.A(\u_digital.adc_code[2] ),
    .B(\u_digital.irq_manager_status_sample_done ),
    .X(_049_));
 sky130_fd_sc_hd__and2_2 _280_ (.A(\u_digital.u_temp_filter_compare.prev_sample[3] ),
    .B(\u_digital.adc_code[3] ),
    .X(_050_));
 sky130_fd_sc_hd__or2_2 _281_ (.A(\u_digital.u_temp_filter_compare.prev_sample[3] ),
    .B(\u_digital.adc_code[3] ),
    .X(_051_));
 sky130_fd_sc_hd__and2b_2 _282_ (.A_N(_050_),
    .B(_051_),
    .X(_052_));
 sky130_fd_sc_hd__a21oi_2 _283_ (.A1(_042_),
    .A2(_045_),
    .B1(_044_),
    .Y(_053_));
 sky130_fd_sc_hd__xnor2_2 _284_ (.A(_052_),
    .B(_053_),
    .Y(_054_));
 sky130_fd_sc_hd__o21ai_2 _285_ (.A1(_018_),
    .A2(_054_),
    .B1(_049_),
    .Y(_055_));
 sky130_fd_sc_hd__inv_2 _286_ (.A(_055_),
    .Y(_056_));
 sky130_fd_sc_hd__mux2_1 _287_ (.A0(\u_digital.register_map_latest_temp[2] ),
    .A1(_056_),
    .S(\u_digital.adc_valid ),
    .X(\u_digital.u_temp_filter_compare.filtered_next[2] ));
 sky130_fd_sc_hd__nor2_2 _288_ (.A(\u_digital.u_temp_filter_compare.prev_sample[4] ),
    .B(\u_digital.adc_code[4] ),
    .Y(_057_));
 sky130_fd_sc_hd__and2_2 _289_ (.A(\u_digital.u_temp_filter_compare.prev_sample[4] ),
    .B(\u_digital.adc_code[4] ),
    .X(_058_));
 sky130_fd_sc_hd__nor2_2 _290_ (.A(_057_),
    .B(_058_),
    .Y(_059_));
 sky130_fd_sc_hd__a31o_2 _291_ (.A1(\u_digital.u_temp_filter_compare.prev_sample[2] ),
    .A2(\u_digital.adc_code[2] ),
    .A3(_051_),
    .B1(_050_),
    .X(_060_));
 sky130_fd_sc_hd__a31o_2 _292_ (.A1(_042_),
    .A2(_045_),
    .A3(_052_),
    .B1(_060_),
    .X(_061_));
 sky130_fd_sc_hd__nor2_2 _293_ (.A(_059_),
    .B(_061_),
    .Y(_062_));
 sky130_fd_sc_hd__a21o_2 _294_ (.A1(_059_),
    .A2(_061_),
    .B1(_018_),
    .X(_063_));
 sky130_fd_sc_hd__o2bb2a_2 _295_ (.A1_N(\u_digital.adc_code[3] ),
    .A2_N(_018_),
    .B1(_062_),
    .B2(_063_),
    .X(_064_));
 sky130_fd_sc_hd__inv_2 _296_ (.A(_064_),
    .Y(_065_));
 sky130_fd_sc_hd__mux2_1 _297_ (.A0(\u_digital.register_map_latest_temp[3] ),
    .A1(_065_),
    .S(\u_digital.adc_valid ),
    .X(\u_digital.u_temp_filter_compare.filtered_next[3] ));
 sky130_fd_sc_hd__or2_2 _298_ (.A(\u_digital.u_temp_filter_compare.prev_sample[5] ),
    .B(\u_digital.adc_code[5] ),
    .X(_066_));
 sky130_fd_sc_hd__and2_2 _299_ (.A(\u_digital.u_temp_filter_compare.prev_sample[5] ),
    .B(\u_digital.adc_code[5] ),
    .X(_067_));
 sky130_fd_sc_hd__nand2_2 _300_ (.A(\u_digital.u_temp_filter_compare.prev_sample[5] ),
    .B(\u_digital.adc_code[5] ),
    .Y(_068_));
 sky130_fd_sc_hd__nand2_2 _301_ (.A(_066_),
    .B(_068_),
    .Y(_069_));
 sky130_fd_sc_hd__a21o_2 _302_ (.A1(_059_),
    .A2(_061_),
    .B1(_058_),
    .X(_070_));
 sky130_fd_sc_hd__or2_2 _303_ (.A(\u_digital.adc_code[4] ),
    .B(\u_digital.irq_manager_status_sample_done ),
    .X(_071_));
 sky130_fd_sc_hd__xnor2_2 _304_ (.A(_069_),
    .B(_070_),
    .Y(_072_));
 sky130_fd_sc_hd__o21a_2 _305_ (.A1(_018_),
    .A2(_072_),
    .B1(_071_),
    .X(_073_));
 sky130_fd_sc_hd__mux2_1 _306_ (.A0(\u_digital.register_map_latest_temp[4] ),
    .A1(_073_),
    .S(\u_digital.adc_valid ),
    .X(\u_digital.u_temp_filter_compare.filtered_next[4] ));
 sky130_fd_sc_hd__and2_2 _307_ (.A(\u_digital.u_temp_filter_compare.prev_sample[6] ),
    .B(\u_digital.adc_code[6] ),
    .X(_074_));
 sky130_fd_sc_hd__nand2_2 _308_ (.A(\u_digital.u_temp_filter_compare.prev_sample[6] ),
    .B(\u_digital.adc_code[6] ),
    .Y(_075_));
 sky130_fd_sc_hd__or2_2 _309_ (.A(\u_digital.u_temp_filter_compare.prev_sample[6] ),
    .B(\u_digital.adc_code[6] ),
    .X(_076_));
 sky130_fd_sc_hd__and3_2 _310_ (.A(_059_),
    .B(_066_),
    .C(_068_),
    .X(_077_));
 sky130_fd_sc_hd__o21a_2 _311_ (.A1(_058_),
    .A2(_067_),
    .B1(_066_),
    .X(_078_));
 sky130_fd_sc_hd__a21o_2 _312_ (.A1(_061_),
    .A2(_077_),
    .B1(_078_),
    .X(_079_));
 sky130_fd_sc_hd__and3_2 _313_ (.A(_075_),
    .B(_076_),
    .C(_079_),
    .X(_080_));
 sky130_fd_sc_hd__a21oi_2 _314_ (.A1(_075_),
    .A2(_076_),
    .B1(_079_),
    .Y(_081_));
 sky130_fd_sc_hd__o21ai_2 _315_ (.A1(_080_),
    .A2(_081_),
    .B1(\u_digital.irq_manager_status_sample_done ),
    .Y(_082_));
 sky130_fd_sc_hd__o21ai_2 _316_ (.A1(\u_digital.adc_code[5] ),
    .A2(\u_digital.irq_manager_status_sample_done ),
    .B1(_082_),
    .Y(_083_));
 sky130_fd_sc_hd__inv_2 _317_ (.A(_083_),
    .Y(_084_));
 sky130_fd_sc_hd__mux2_1 _318_ (.A0(\u_digital.register_map_latest_temp[5] ),
    .A1(_084_),
    .S(\u_digital.adc_valid ),
    .X(\u_digital.u_temp_filter_compare.filtered_next[5] ));
 sky130_fd_sc_hd__nand2_2 _319_ (.A(\u_digital.adc_code[6] ),
    .B(_018_),
    .Y(_085_));
 sky130_fd_sc_hd__or2_2 _320_ (.A(\u_digital.u_temp_filter_compare.prev_sample[7] ),
    .B(\u_digital.adc_code[7] ),
    .X(_086_));
 sky130_fd_sc_hd__nand2_2 _321_ (.A(\u_digital.u_temp_filter_compare.prev_sample[7] ),
    .B(\u_digital.adc_code[7] ),
    .Y(_087_));
 sky130_fd_sc_hd__inv_2 _322_ (.A(_087_),
    .Y(_088_));
 sky130_fd_sc_hd__nand2_2 _323_ (.A(_086_),
    .B(_087_),
    .Y(_089_));
 sky130_fd_sc_hd__a21oi_2 _324_ (.A1(_076_),
    .A2(_079_),
    .B1(_074_),
    .Y(_090_));
 sky130_fd_sc_hd__nor2_2 _325_ (.A(_089_),
    .B(_090_),
    .Y(_091_));
 sky130_fd_sc_hd__and2_2 _326_ (.A(_089_),
    .B(_090_),
    .X(_092_));
 sky130_fd_sc_hd__nor2_2 _327_ (.A(\u_digital.adc_code[6] ),
    .B(\u_digital.irq_manager_status_sample_done ),
    .Y(_093_));
 sky130_fd_sc_hd__xnor2_2 _328_ (.A(_089_),
    .B(_090_),
    .Y(_094_));
 sky130_fd_sc_hd__a211o_2 _329_ (.A1(\u_digital.irq_manager_status_sample_done ),
    .A2(_094_),
    .B1(_093_),
    .C1(_029_),
    .X(_095_));
 sky130_fd_sc_hd__a21bo_2 _330_ (.A1(_029_),
    .A2(\u_digital.register_map_latest_temp[6] ),
    .B1_N(_095_),
    .X(\u_digital.u_temp_filter_compare.filtered_next[6] ));
 sky130_fd_sc_hd__xor2_2 _331_ (.A(\u_digital.u_temp_filter_compare.prev_sample[8] ),
    .B(\u_digital.adc_code[8] ),
    .X(_096_));
 sky130_fd_sc_hd__and4_2 _332_ (.A(_075_),
    .B(_076_),
    .C(_086_),
    .D(_087_),
    .X(_097_));
 sky130_fd_sc_hd__a221o_2 _333_ (.A1(_074_),
    .A2(_086_),
    .B1(_097_),
    .B2(_078_),
    .C1(_088_),
    .X(_098_));
 sky130_fd_sc_hd__a31o_2 _334_ (.A1(_061_),
    .A2(_077_),
    .A3(_097_),
    .B1(_098_),
    .X(_099_));
 sky130_fd_sc_hd__nand2_2 _335_ (.A(_096_),
    .B(_099_),
    .Y(_100_));
 sky130_fd_sc_hd__o21a_2 _336_ (.A1(_096_),
    .A2(_099_),
    .B1(\u_digital.irq_manager_status_sample_done ),
    .X(_101_));
 sky130_fd_sc_hd__a22o_2 _337_ (.A1(\u_digital.adc_code[7] ),
    .A2(_018_),
    .B1(_100_),
    .B2(_101_),
    .X(_102_));
 sky130_fd_sc_hd__mux2_1 _338_ (.A0(\u_digital.register_map_latest_temp[7] ),
    .A1(_102_),
    .S(\u_digital.adc_valid ),
    .X(\u_digital.u_temp_filter_compare.filtered_next[7] ));
 sky130_fd_sc_hd__nor2_2 _339_ (.A(\u_digital.u_temp_filter_compare.prev_sample[9] ),
    .B(\u_digital.adc_code[9] ),
    .Y(_103_));
 sky130_fd_sc_hd__or2_2 _340_ (.A(\u_digital.u_temp_filter_compare.prev_sample[9] ),
    .B(\u_digital.adc_code[9] ),
    .X(_104_));
 sky130_fd_sc_hd__and2_2 _341_ (.A(\u_digital.u_temp_filter_compare.prev_sample[9] ),
    .B(\u_digital.adc_code[9] ),
    .X(_105_));
 sky130_fd_sc_hd__nor2_2 _342_ (.A(_103_),
    .B(_105_),
    .Y(_106_));
 sky130_fd_sc_hd__a22o_2 _343_ (.A1(\u_digital.u_temp_filter_compare.prev_sample[8] ),
    .A2(\u_digital.adc_code[8] ),
    .B1(_096_),
    .B2(_099_),
    .X(_107_));
 sky130_fd_sc_hd__xor2_2 _344_ (.A(_106_),
    .B(_107_),
    .X(_108_));
 sky130_fd_sc_hd__or2_2 _345_ (.A(\u_digital.adc_code[8] ),
    .B(\u_digital.irq_manager_status_sample_done ),
    .X(_109_));
 sky130_fd_sc_hd__and2_2 _346_ (.A(\u_digital.adc_code[8] ),
    .B(_018_),
    .X(_110_));
 sky130_fd_sc_hd__a211o_2 _347_ (.A1(\u_digital.irq_manager_status_sample_done ),
    .A2(_108_),
    .B1(_110_),
    .C1(_029_),
    .X(_111_));
 sky130_fd_sc_hd__o21a_2 _348_ (.A1(\u_digital.adc_valid ),
    .A2(\u_digital.register_map_latest_temp[8] ),
    .B1(_111_),
    .X(\u_digital.u_temp_filter_compare.filtered_next[8] ));
 sky130_fd_sc_hd__and2_2 _349_ (.A(\u_digital.adc_code[9] ),
    .B(_018_),
    .X(_112_));
 sky130_fd_sc_hd__or2_2 _350_ (.A(\u_digital.u_temp_filter_compare.prev_sample[10] ),
    .B(\u_digital.adc_code[10] ),
    .X(_113_));
 sky130_fd_sc_hd__nand2_2 _351_ (.A(\u_digital.u_temp_filter_compare.prev_sample[10] ),
    .B(\u_digital.adc_code[10] ),
    .Y(_114_));
 sky130_fd_sc_hd__nand2_2 _352_ (.A(_113_),
    .B(_114_),
    .Y(_115_));
 sky130_fd_sc_hd__a31o_2 _353_ (.A1(\u_digital.u_temp_filter_compare.prev_sample[8] ),
    .A2(\u_digital.adc_code[8] ),
    .A3(_104_),
    .B1(_105_),
    .X(_116_));
 sky130_fd_sc_hd__a31o_2 _354_ (.A1(_096_),
    .A2(_099_),
    .A3(_106_),
    .B1(_116_),
    .X(_117_));
 sky130_fd_sc_hd__xnor2_2 _355_ (.A(_115_),
    .B(_117_),
    .Y(_118_));
 sky130_fd_sc_hd__a21oi_2 _356_ (.A1(\u_digital.irq_manager_status_sample_done ),
    .A2(_118_),
    .B1(_112_),
    .Y(_119_));
 sky130_fd_sc_hd__inv_2 _357_ (.A(_119_),
    .Y(_120_));
 sky130_fd_sc_hd__mux2_1 _358_ (.A0(\u_digital.register_map_latest_temp[9] ),
    .A1(_120_),
    .S(\u_digital.adc_valid ),
    .X(\u_digital.u_temp_filter_compare.filtered_next[9] ));
 sky130_fd_sc_hd__a21bo_2 _359_ (.A1(_113_),
    .A2(_117_),
    .B1_N(_114_),
    .X(_121_));
 sky130_fd_sc_hd__xnor2_2 _360_ (.A(\u_digital.u_temp_filter_compare.prev_sample[11] ),
    .B(\u_digital.adc_code[11] ),
    .Y(_122_));
 sky130_fd_sc_hd__xnor2_2 _361_ (.A(_121_),
    .B(_122_),
    .Y(_123_));
 sky130_fd_sc_hd__mux2_1 _362_ (.A0(\u_digital.adc_code[10] ),
    .A1(_123_),
    .S(\u_digital.irq_manager_status_sample_done ),
    .X(_124_));
 sky130_fd_sc_hd__mux2_1 _363_ (.A0(\u_digital.register_map_latest_temp[10] ),
    .A1(_124_),
    .S(\u_digital.adc_valid ),
    .X(\u_digital.u_temp_filter_compare.filtered_next[10] ));
 sky130_fd_sc_hd__and2_2 _364_ (.A(\u_digital.adc_code[11] ),
    .B(_018_),
    .X(_125_));
 sky130_fd_sc_hd__mux2_1 _365_ (.A0(\u_digital.register_map_latest_temp[11] ),
    .A1(_125_),
    .S(\u_digital.adc_valid ),
    .X(\u_digital.u_temp_filter_compare.filtered_next[11] ));
 sky130_fd_sc_hd__xor2_2 _366_ (.A(\u_digital.u_register_map.adc_valid_r ),
    .B(\u_digital.register_map_sample_count[0] ),
    .X(\u_digital.u_register_map.sample_count_next[0] ));
 sky130_fd_sc_hd__mux2_1 _367_ (.A0(\u_digital.register_map_latest_temp[0] ),
    .A1(\u_digital.u_register_map.adc_code_r[0] ),
    .S(\u_digital.u_register_map.adc_valid_r ),
    .X(\u_digital.u_register_map.latest_temp_next[0] ));
 sky130_fd_sc_hd__nor3_2 _368_ (.A(_030_),
    .B(_033_),
    .C(_035_),
    .Y(_126_));
 sky130_fd_sc_hd__nand2_2 _369_ (.A(wr_data[1]),
    .B(_126_),
    .Y(_127_));
 sky130_fd_sc_hd__inv_2 _370_ (.A(_127_),
    .Y(\u_digital.u_register_map.irq_clear_sample_done_pulse_next ));
 sky130_fd_sc_hd__o21a_2 _371_ (.A1(\u_digital.u_register_map.adc_valid_r ),
    .A2(\u_digital.register_map_status_sample_done ),
    .B1(_127_),
    .X(\u_digital.u_register_map.status_sample_done_next ));
 sky130_fd_sc_hd__or4b_2 _372_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .C(rd_addr[3]),
    .D_N(rd_addr[2]),
    .X(_128_));
 sky130_fd_sc_hd__or4b_2 _373_ (.A(rd_addr[5]),
    .B(rd_addr[7]),
    .C(rd_addr[6]),
    .D_N(rd_addr[4]),
    .X(_129_));
 sky130_fd_sc_hd__nor2_2 _374_ (.A(_128_),
    .B(_129_),
    .Y(_130_));
 sky130_fd_sc_hd__o22a_2 _375_ (.A1(_021_),
    .A2(\u_digital.u_register_map.adc_code_r[8] ),
    .B1(\u_digital.u_register_map.adc_code_r[7] ),
    .B2(_022_),
    .X(_131_));
 sky130_fd_sc_hd__a22o_2 _376_ (.A1(_024_),
    .A2(\u_digital.u_register_map.adc_code_r[5] ),
    .B1(\u_digital.u_register_map.adc_code_r[4] ),
    .B2(_025_),
    .X(_132_));
 sky130_fd_sc_hd__o22a_2 _377_ (.A1(_025_),
    .A2(\u_digital.u_register_map.adc_code_r[4] ),
    .B1(\u_digital.u_register_map.adc_code_r[3] ),
    .B2(_026_),
    .X(_133_));
 sky130_fd_sc_hd__nand2b_2 _378_ (.A_N(\u_digital.u_register_map.adc_code_r[2] ),
    .B(threshold_code[2]),
    .Y(_134_));
 sky130_fd_sc_hd__and2b_2 _379_ (.A_N(threshold_code[1]),
    .B(\u_digital.u_register_map.adc_code_r[1] ),
    .X(_135_));
 sky130_fd_sc_hd__nand2b_2 _380_ (.A_N(\u_digital.u_register_map.adc_code_r[1] ),
    .B(threshold_code[1]),
    .Y(_136_));
 sky130_fd_sc_hd__and2b_2 _381_ (.A_N(threshold_code[2]),
    .B(\u_digital.u_register_map.adc_code_r[2] ),
    .X(_137_));
 sky130_fd_sc_hd__a311o_2 _382_ (.A1(_028_),
    .A2(\u_digital.u_register_map.adc_code_r[0] ),
    .A3(_136_),
    .B1(_137_),
    .C1(_135_),
    .X(_138_));
 sky130_fd_sc_hd__a22o_2 _383_ (.A1(_026_),
    .A2(\u_digital.u_register_map.adc_code_r[3] ),
    .B1(_134_),
    .B2(_138_),
    .X(_139_));
 sky130_fd_sc_hd__a21o_2 _384_ (.A1(_133_),
    .A2(_139_),
    .B1(_132_),
    .X(_140_));
 sky130_fd_sc_hd__a22o_2 _385_ (.A1(_022_),
    .A2(\u_digital.u_register_map.adc_code_r[7] ),
    .B1(\u_digital.u_register_map.adc_code_r[6] ),
    .B2(_023_),
    .X(_141_));
 sky130_fd_sc_hd__o221a_2 _386_ (.A1(_023_),
    .A2(\u_digital.u_register_map.adc_code_r[6] ),
    .B1(\u_digital.u_register_map.adc_code_r[5] ),
    .B2(_024_),
    .C1(_140_),
    .X(_142_));
 sky130_fd_sc_hd__o21a_2 _387_ (.A1(_141_),
    .A2(_142_),
    .B1(_131_),
    .X(_143_));
 sky130_fd_sc_hd__a22o_2 _388_ (.A1(_020_),
    .A2(\u_digital.u_register_map.adc_code_r[9] ),
    .B1(\u_digital.u_register_map.adc_code_r[8] ),
    .B2(_021_),
    .X(_144_));
 sky130_fd_sc_hd__or2_2 _389_ (.A(_019_),
    .B(\u_digital.u_register_map.adc_code_r[10] ),
    .X(_145_));
 sky130_fd_sc_hd__o221a_2 _390_ (.A1(_017_),
    .A2(\u_digital.u_register_map.adc_code_r[11] ),
    .B1(\u_digital.u_register_map.adc_code_r[9] ),
    .B2(_020_),
    .C1(_145_),
    .X(_146_));
 sky130_fd_sc_hd__o21a_2 _391_ (.A1(_143_),
    .A2(_144_),
    .B1(_146_),
    .X(_147_));
 sky130_fd_sc_hd__a22o_2 _392_ (.A1(_017_),
    .A2(\u_digital.u_register_map.adc_code_r[11] ),
    .B1(\u_digital.u_register_map.adc_code_r[10] ),
    .B2(_019_),
    .X(_148_));
 sky130_fd_sc_hd__or3b_2 _393_ (.A(_017_),
    .B(threshold_code[10]),
    .C_N(\u_digital.u_register_map.adc_code_r[10] ),
    .X(_149_));
 sky130_fd_sc_hd__o221a_2 _394_ (.A1(_147_),
    .A2(_148_),
    .B1(_149_),
    .B2(\u_digital.u_register_map.adc_code_r[11] ),
    .C1(\u_digital.u_register_map.adc_valid_r ),
    .X(_150_));
 sky130_fd_sc_hd__and2_2 _395_ (.A(wr_data[0]),
    .B(_126_),
    .X(\u_digital.u_register_map.irq_clear_alert_pulse_next ));
 sky130_fd_sc_hd__a21oi_2 _396_ (.A1(wr_data[3]),
    .A2(_034_),
    .B1(\u_digital.u_register_map.irq_clear_alert_pulse_next ),
    .Y(_151_));
 sky130_fd_sc_hd__a21o_2 _397_ (.A1(\u_digital.register_map_irq_status_alert ),
    .A2(_151_),
    .B1(_150_),
    .X(\u_digital.u_register_map.irq_status_alert_next ));
 sky130_fd_sc_hd__or4_2 _398_ (.A(rd_addr[5]),
    .B(rd_addr[4]),
    .C(rd_addr[7]),
    .D(rd_addr[6]),
    .X(_152_));
 sky130_fd_sc_hd__nor2_2 _399_ (.A(_128_),
    .B(_152_),
    .Y(_153_));
 sky130_fd_sc_hd__or2_2 _400_ (.A(_031_),
    .B(_152_),
    .X(_154_));
 sky130_fd_sc_hd__nor4b_2 _401_ (.A(rd_addr[1]),
    .B(_154_),
    .C(rd_addr[0]),
    .D_N(rd_addr[2]),
    .Y(_155_));
 sky130_fd_sc_hd__or4_2 _402_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .C(rd_addr[3]),
    .D(rd_addr[2]),
    .X(_156_));
 sky130_fd_sc_hd__nor2_2 _403_ (.A(_129_),
    .B(_156_),
    .Y(_157_));
 sky130_fd_sc_hd__a22o_2 _404_ (.A1(\u_digital.u_register_map.latest_temp_next[0] ),
    .A2(_155_),
    .B1(_157_),
    .B2(\u_digital.u_register_map.sample_count_next[0] ),
    .X(_158_));
 sky130_fd_sc_hd__a21o_2 _405_ (.A1(\u_digital.u_register_map.status_sample_done_next ),
    .A2(_153_),
    .B1(_158_),
    .X(_159_));
 sky130_fd_sc_hd__nor4_2 _406_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .C(rd_addr[2]),
    .D(_154_),
    .Y(_160_));
 sky130_fd_sc_hd__a22o_2 _407_ (.A1(_130_),
    .A2(\u_digital.u_register_map.irq_status_alert_next ),
    .B1(_160_),
    .B2(\u_digital.u_register_map.threshold_next[0] ),
    .X(_161_));
 sky130_fd_sc_hd__o21a_2 _408_ (.A1(_159_),
    .A2(_161_),
    .B1(rd_en),
    .X(\u_digital.u_register_map.rd_data_next[0] ));
 sky130_fd_sc_hd__a21oi_2 _409_ (.A1(\u_digital.u_register_map.adc_valid_r ),
    .A2(\u_digital.register_map_sample_count[0] ),
    .B1(\u_digital.register_map_sample_count[1] ),
    .Y(_162_));
 sky130_fd_sc_hd__and3_2 _410_ (.A(\u_digital.u_register_map.adc_valid_r ),
    .B(\u_digital.register_map_sample_count[0] ),
    .C(\u_digital.register_map_sample_count[1] ),
    .X(_163_));
 sky130_fd_sc_hd__nor2_2 _411_ (.A(_162_),
    .B(_163_),
    .Y(\u_digital.u_register_map.sample_count_next[1] ));
 sky130_fd_sc_hd__mux2_1 _412_ (.A0(\u_digital.register_map_latest_temp[1] ),
    .A1(\u_digital.u_register_map.adc_code_r[1] ),
    .S(\u_digital.u_register_map.adc_valid_r ),
    .X(\u_digital.u_register_map.latest_temp_next[1] ));
 sky130_fd_sc_hd__o21a_2 _413_ (.A1(\u_digital.register_map_status_alert_pending ),
    .A2(_150_),
    .B1(_151_),
    .X(\u_digital.u_register_map.status_alert_pending_next ));
 sky130_fd_sc_hd__and2_2 _414_ (.A(_153_),
    .B(\u_digital.u_register_map.status_alert_pending_next ),
    .X(_164_));
 sky130_fd_sc_hd__a21o_2 _415_ (.A1(\u_digital.register_map_irq_status_sample_done ),
    .A2(_127_),
    .B1(\u_digital.u_register_map.adc_valid_r ),
    .X(\u_digital.u_register_map.irq_status_sample_done_next ));
 sky130_fd_sc_hd__a22o_2 _416_ (.A1(_157_),
    .A2(\u_digital.u_register_map.sample_count_next[1] ),
    .B1(\u_digital.u_register_map.latest_temp_next[1] ),
    .B2(_155_),
    .X(_165_));
 sky130_fd_sc_hd__nor2_2 _417_ (.A(_152_),
    .B(_156_),
    .Y(_166_));
 sky130_fd_sc_hd__a221o_2 _418_ (.A1(\u_digital.u_register_map.threshold_next[1] ),
    .A2(_160_),
    .B1(_166_),
    .B2(\u_digital.u_register_map.control_enable_next ),
    .C1(_165_),
    .X(_167_));
 sky130_fd_sc_hd__a21o_2 _419_ (.A1(_130_),
    .A2(\u_digital.u_register_map.irq_status_sample_done_next ),
    .B1(_167_),
    .X(_168_));
 sky130_fd_sc_hd__o21a_2 _420_ (.A1(_164_),
    .A2(_168_),
    .B1(rd_en),
    .X(\u_digital.u_register_map.rd_data_next[1] ));
 sky130_fd_sc_hd__mux2_1 _421_ (.A0(\u_digital.register_map_latest_temp[2] ),
    .A1(\u_digital.u_register_map.adc_code_r[2] ),
    .S(\u_digital.u_register_map.adc_valid_r ),
    .X(\u_digital.u_register_map.latest_temp_next[2] ));
 sky130_fd_sc_hd__and4_2 _422_ (.A(\u_digital.u_register_map.adc_valid_r ),
    .B(\u_digital.register_map_sample_count[0] ),
    .C(\u_digital.register_map_sample_count[1] ),
    .D(\u_digital.register_map_sample_count[2] ),
    .X(_169_));
 sky130_fd_sc_hd__nor2_2 _423_ (.A(\u_digital.register_map_sample_count[2] ),
    .B(_163_),
    .Y(_170_));
 sky130_fd_sc_hd__nor2_2 _424_ (.A(_169_),
    .B(_170_),
    .Y(\u_digital.u_register_map.sample_count_next[2] ));
 sky130_fd_sc_hd__or2_2 _425_ (.A(\u_digital.u_register_map.adc_valid_r ),
    .B(\u_digital.register_map_status_adc_valid_seen ),
    .X(\u_digital.u_register_map.status_adc_valid_seen_next ));
 sky130_fd_sc_hd__a22o_2 _426_ (.A1(_157_),
    .A2(\u_digital.u_register_map.sample_count_next[2] ),
    .B1(\u_digital.u_register_map.status_adc_valid_seen_next ),
    .B2(_153_),
    .X(_171_));
 sky130_fd_sc_hd__a22o_2 _427_ (.A1(\u_digital.u_register_map.threshold_next[2] ),
    .A2(_160_),
    .B1(\u_digital.u_register_map.latest_temp_next[2] ),
    .B2(_155_),
    .X(_172_));
 sky130_fd_sc_hd__o21a_2 _428_ (.A1(_171_),
    .A2(_172_),
    .B1(rd_en),
    .X(\u_digital.u_register_map.rd_data_next[2] ));
 sky130_fd_sc_hd__mux2_1 _429_ (.A0(\u_digital.register_map_latest_temp[3] ),
    .A1(\u_digital.u_register_map.adc_code_r[3] ),
    .S(\u_digital.u_register_map.adc_valid_r ),
    .X(\u_digital.u_register_map.latest_temp_next[3] ));
 sky130_fd_sc_hd__nand2_2 _430_ (.A(wr_data[1]),
    .B(_034_),
    .Y(_173_));
 sky130_fd_sc_hd__inv_2 _431_ (.A(_173_),
    .Y(\u_digital.u_register_map.sample_req_next ));
 sky130_fd_sc_hd__o21ba_2 _432_ (.A1(\u_digital.register_map_status_busy ),
    .A2(\u_digital.u_register_map.sample_req_next ),
    .B1_N(\u_digital.u_register_map.adc_valid_r ),
    .X(\u_digital.u_register_map.status_busy_next ));
 sky130_fd_sc_hd__xor2_2 _433_ (.A(\u_digital.register_map_sample_count[3] ),
    .B(_169_),
    .X(\u_digital.u_register_map.sample_count_next[3] ));
 sky130_fd_sc_hd__and2_2 _434_ (.A(_157_),
    .B(\u_digital.u_register_map.sample_count_next[3] ),
    .X(_174_));
 sky130_fd_sc_hd__a221o_2 _435_ (.A1(\u_digital.u_register_map.threshold_next[3] ),
    .A2(_160_),
    .B1(\u_digital.u_register_map.latest_temp_next[3] ),
    .B2(_155_),
    .C1(_174_),
    .X(_175_));
 sky130_fd_sc_hd__a22o_2 _436_ (.A1(\u_digital.u_register_map.control_irq_enable_next ),
    .A2(_166_),
    .B1(\u_digital.u_register_map.status_busy_next ),
    .B2(_153_),
    .X(_176_));
 sky130_fd_sc_hd__o21a_2 _437_ (.A1(_175_),
    .A2(_176_),
    .B1(rd_en),
    .X(\u_digital.u_register_map.rd_data_next[3] ));
 sky130_fd_sc_hd__mux2_1 _438_ (.A0(\u_digital.register_map_latest_temp[4] ),
    .A1(\u_digital.u_register_map.adc_code_r[4] ),
    .S(\u_digital.u_register_map.adc_valid_r ),
    .X(\u_digital.u_register_map.latest_temp_next[4] ));
 sky130_fd_sc_hd__and2_2 _439_ (.A(\u_digital.u_register_map.threshold_next[4] ),
    .B(_160_),
    .X(_177_));
 sky130_fd_sc_hd__and3_2 _440_ (.A(\u_digital.register_map_sample_count[3] ),
    .B(\u_digital.register_map_sample_count[4] ),
    .C(_169_),
    .X(_178_));
 sky130_fd_sc_hd__a21oi_2 _441_ (.A1(\u_digital.register_map_sample_count[3] ),
    .A2(_169_),
    .B1(\u_digital.register_map_sample_count[4] ),
    .Y(_179_));
 sky130_fd_sc_hd__nor2_2 _442_ (.A(_178_),
    .B(_179_),
    .Y(\u_digital.u_register_map.sample_count_next[4] ));
 sky130_fd_sc_hd__a22o_2 _443_ (.A1(_155_),
    .A2(\u_digital.u_register_map.latest_temp_next[4] ),
    .B1(\u_digital.u_register_map.sample_count_next[4] ),
    .B2(_157_),
    .X(_180_));
 sky130_fd_sc_hd__o21a_2 _444_ (.A1(_177_),
    .A2(_180_),
    .B1(rd_en),
    .X(\u_digital.u_register_map.rd_data_next[4] ));
 sky130_fd_sc_hd__mux2_1 _445_ (.A0(\u_digital.register_map_latest_temp[5] ),
    .A1(\u_digital.u_register_map.adc_code_r[5] ),
    .S(\u_digital.u_register_map.adc_valid_r ),
    .X(\u_digital.u_register_map.latest_temp_next[5] ));
 sky130_fd_sc_hd__and2_2 _446_ (.A(\u_digital.register_map_sample_count[5] ),
    .B(_178_),
    .X(_181_));
 sky130_fd_sc_hd__nor2_2 _447_ (.A(\u_digital.register_map_sample_count[5] ),
    .B(_178_),
    .Y(_182_));
 sky130_fd_sc_hd__nor2_2 _448_ (.A(_181_),
    .B(_182_),
    .Y(\u_digital.u_register_map.sample_count_next[5] ));
 sky130_fd_sc_hd__a22o_2 _449_ (.A1(\u_digital.u_register_map.threshold_next[5] ),
    .A2(_160_),
    .B1(\u_digital.u_register_map.latest_temp_next[5] ),
    .B2(_155_),
    .X(_183_));
 sky130_fd_sc_hd__a21o_2 _450_ (.A1(_157_),
    .A2(\u_digital.u_register_map.sample_count_next[5] ),
    .B1(_183_),
    .X(_184_));
 sky130_fd_sc_hd__and2_2 _451_ (.A(rd_en),
    .B(_184_),
    .X(\u_digital.u_register_map.rd_data_next[5] ));
 sky130_fd_sc_hd__mux2_1 _452_ (.A0(\u_digital.register_map_latest_temp[6] ),
    .A1(\u_digital.u_register_map.adc_code_r[6] ),
    .S(\u_digital.u_register_map.adc_valid_r ),
    .X(\u_digital.u_register_map.latest_temp_next[6] ));
 sky130_fd_sc_hd__a22o_2 _453_ (.A1(\u_digital.u_register_map.threshold_next[6] ),
    .A2(_160_),
    .B1(\u_digital.u_register_map.latest_temp_next[6] ),
    .B2(_155_),
    .X(_185_));
 sky130_fd_sc_hd__xor2_2 _454_ (.A(\u_digital.register_map_sample_count[6] ),
    .B(_181_),
    .X(\u_digital.u_register_map.sample_count_next[6] ));
 sky130_fd_sc_hd__and2_2 _455_ (.A(rd_en),
    .B(_157_),
    .X(_186_));
 sky130_fd_sc_hd__a22o_2 _456_ (.A1(rd_en),
    .A2(_185_),
    .B1(\u_digital.u_register_map.sample_count_next[6] ),
    .B2(_186_),
    .X(\u_digital.u_register_map.rd_data_next[6] ));
 sky130_fd_sc_hd__mux2_1 _457_ (.A0(\u_digital.register_map_latest_temp[7] ),
    .A1(\u_digital.u_register_map.adc_code_r[7] ),
    .S(\u_digital.u_register_map.adc_valid_r ),
    .X(\u_digital.u_register_map.latest_temp_next[7] ));
 sky130_fd_sc_hd__and3_2 _458_ (.A(\u_digital.register_map_sample_count[6] ),
    .B(\u_digital.register_map_sample_count[7] ),
    .C(_181_),
    .X(_187_));
 sky130_fd_sc_hd__a21oi_2 _459_ (.A1(\u_digital.register_map_sample_count[6] ),
    .A2(_181_),
    .B1(\u_digital.register_map_sample_count[7] ),
    .Y(_188_));
 sky130_fd_sc_hd__nor2_2 _460_ (.A(_187_),
    .B(_188_),
    .Y(\u_digital.u_register_map.sample_count_next[7] ));
 sky130_fd_sc_hd__and2_2 _461_ (.A(_157_),
    .B(\u_digital.u_register_map.sample_count_next[7] ),
    .X(_189_));
 sky130_fd_sc_hd__a22o_2 _462_ (.A1(\u_digital.u_register_map.threshold_next[7] ),
    .A2(_160_),
    .B1(\u_digital.u_register_map.latest_temp_next[7] ),
    .B2(_155_),
    .X(_190_));
 sky130_fd_sc_hd__o21a_2 _463_ (.A1(_189_),
    .A2(_190_),
    .B1(rd_en),
    .X(\u_digital.u_register_map.rd_data_next[7] ));
 sky130_fd_sc_hd__mux2_1 _464_ (.A0(\u_digital.register_map_latest_temp[8] ),
    .A1(\u_digital.u_register_map.adc_code_r[8] ),
    .S(\u_digital.u_register_map.adc_valid_r ),
    .X(\u_digital.u_register_map.latest_temp_next[8] ));
 sky130_fd_sc_hd__a22o_2 _465_ (.A1(\u_digital.u_register_map.threshold_next[8] ),
    .A2(_160_),
    .B1(\u_digital.u_register_map.latest_temp_next[8] ),
    .B2(_155_),
    .X(_191_));
 sky130_fd_sc_hd__and2_2 _466_ (.A(\u_digital.register_map_sample_count[8] ),
    .B(_187_),
    .X(_192_));
 sky130_fd_sc_hd__nor2_2 _467_ (.A(\u_digital.register_map_sample_count[8] ),
    .B(_187_),
    .Y(_193_));
 sky130_fd_sc_hd__nor2_2 _468_ (.A(_192_),
    .B(_193_),
    .Y(\u_digital.u_register_map.sample_count_next[8] ));
 sky130_fd_sc_hd__a22o_2 _469_ (.A1(rd_en),
    .A2(_191_),
    .B1(\u_digital.u_register_map.sample_count_next[8] ),
    .B2(_186_),
    .X(\u_digital.u_register_map.rd_data_next[8] ));
 sky130_fd_sc_hd__mux2_1 _470_ (.A0(\u_digital.register_map_latest_temp[9] ),
    .A1(\u_digital.u_register_map.adc_code_r[9] ),
    .S(\u_digital.u_register_map.adc_valid_r ),
    .X(\u_digital.u_register_map.latest_temp_next[9] ));
 sky130_fd_sc_hd__a22o_2 _471_ (.A1(\u_digital.u_register_map.threshold_next[9] ),
    .A2(_160_),
    .B1(\u_digital.u_register_map.latest_temp_next[9] ),
    .B2(_155_),
    .X(_194_));
 sky130_fd_sc_hd__xor2_2 _472_ (.A(\u_digital.register_map_sample_count[9] ),
    .B(_192_),
    .X(\u_digital.u_register_map.sample_count_next[9] ));
 sky130_fd_sc_hd__a22o_2 _473_ (.A1(rd_en),
    .A2(_194_),
    .B1(\u_digital.u_register_map.sample_count_next[9] ),
    .B2(_186_),
    .X(\u_digital.u_register_map.rd_data_next[9] ));
 sky130_fd_sc_hd__mux2_1 _474_ (.A0(\u_digital.register_map_latest_temp[10] ),
    .A1(\u_digital.u_register_map.adc_code_r[10] ),
    .S(\u_digital.u_register_map.adc_valid_r ),
    .X(\u_digital.u_register_map.latest_temp_next[10] ));
 sky130_fd_sc_hd__a22o_2 _475_ (.A1(\u_digital.u_register_map.threshold_next[10] ),
    .A2(_160_),
    .B1(\u_digital.u_register_map.latest_temp_next[10] ),
    .B2(_155_),
    .X(_195_));
 sky130_fd_sc_hd__and3_2 _476_ (.A(\u_digital.register_map_sample_count[9] ),
    .B(\u_digital.register_map_sample_count[10] ),
    .C(_192_),
    .X(_196_));
 sky130_fd_sc_hd__a31o_2 _477_ (.A1(\u_digital.register_map_sample_count[8] ),
    .A2(\u_digital.register_map_sample_count[9] ),
    .A3(_187_),
    .B1(\u_digital.register_map_sample_count[10] ),
    .X(_197_));
 sky130_fd_sc_hd__and2b_2 _478_ (.A_N(_196_),
    .B(_197_),
    .X(\u_digital.u_register_map.sample_count_next[10] ));
 sky130_fd_sc_hd__a22o_2 _479_ (.A1(rd_en),
    .A2(_195_),
    .B1(\u_digital.u_register_map.sample_count_next[10] ),
    .B2(_186_),
    .X(\u_digital.u_register_map.rd_data_next[10] ));
 sky130_fd_sc_hd__mux2_1 _480_ (.A0(\u_digital.register_map_latest_temp[11] ),
    .A1(\u_digital.u_register_map.adc_code_r[11] ),
    .S(\u_digital.u_register_map.adc_valid_r ),
    .X(\u_digital.u_register_map.latest_temp_next[11] ));
 sky130_fd_sc_hd__a22o_2 _481_ (.A1(\u_digital.u_register_map.threshold_next[11] ),
    .A2(_160_),
    .B1(\u_digital.u_register_map.latest_temp_next[11] ),
    .B2(_155_),
    .X(_198_));
 sky130_fd_sc_hd__and2_2 _482_ (.A(\u_digital.register_map_sample_count[11] ),
    .B(_196_),
    .X(_199_));
 sky130_fd_sc_hd__xor2_2 _483_ (.A(\u_digital.register_map_sample_count[11] ),
    .B(_196_),
    .X(\u_digital.u_register_map.sample_count_next[11] ));
 sky130_fd_sc_hd__a22o_2 _484_ (.A1(rd_en),
    .A2(_198_),
    .B1(\u_digital.u_register_map.sample_count_next[11] ),
    .B2(_186_),
    .X(\u_digital.u_register_map.rd_data_next[11] ));
 sky130_fd_sc_hd__nand2_2 _485_ (.A(\u_digital.register_map_sample_count[12] ),
    .B(_199_),
    .Y(_200_));
 sky130_fd_sc_hd__xor2_2 _486_ (.A(\u_digital.register_map_sample_count[12] ),
    .B(_199_),
    .X(\u_digital.u_register_map.sample_count_next[12] ));
 sky130_fd_sc_hd__and2_2 _487_ (.A(_186_),
    .B(\u_digital.u_register_map.sample_count_next[12] ),
    .X(\u_digital.u_register_map.rd_data_next[12] ));
 sky130_fd_sc_hd__and3_2 _488_ (.A(\u_digital.register_map_sample_count[12] ),
    .B(\u_digital.register_map_sample_count[13] ),
    .C(_199_),
    .X(_201_));
 sky130_fd_sc_hd__xnor2_2 _489_ (.A(\u_digital.register_map_sample_count[13] ),
    .B(_200_),
    .Y(\u_digital.u_register_map.sample_count_next[13] ));
 sky130_fd_sc_hd__and2_2 _490_ (.A(_186_),
    .B(\u_digital.u_register_map.sample_count_next[13] ),
    .X(\u_digital.u_register_map.rd_data_next[13] ));
 sky130_fd_sc_hd__nand2_2 _491_ (.A(\u_digital.register_map_sample_count[14] ),
    .B(_201_),
    .Y(_202_));
 sky130_fd_sc_hd__xor2_2 _492_ (.A(\u_digital.register_map_sample_count[14] ),
    .B(_201_),
    .X(\u_digital.u_register_map.sample_count_next[14] ));
 sky130_fd_sc_hd__and2_2 _493_ (.A(_186_),
    .B(\u_digital.u_register_map.sample_count_next[14] ),
    .X(\u_digital.u_register_map.rd_data_next[14] ));
 sky130_fd_sc_hd__xnor2_2 _494_ (.A(\u_digital.register_map_sample_count[15] ),
    .B(_202_),
    .Y(\u_digital.u_register_map.sample_count_next[15] ));
 sky130_fd_sc_hd__and2_2 _495_ (.A(_186_),
    .B(\u_digital.u_register_map.sample_count_next[15] ),
    .X(\u_digital.u_register_map.rd_data_next[15] ));
 sky130_fd_sc_hd__o41a_2 _496_ (.A1(\u_digital.irq_manager_status_sample_done ),
    .A2(alert_status),
    .A3(\u_digital.irq_manager_irq_status_alert ),
    .A4(\u_digital.irq_manager_irq_status_sample_done ),
    .B1(\u_digital.irq_manager_control_irq_enable ),
    .X(_000_));
 sky130_fd_sc_hd__or2_2 _497_ (.A(\u_digital.irq_manager_status_sample_done ),
    .B(\u_digital.adc_valid ),
    .X(_001_));
 sky130_fd_sc_hd__o21ba_2 _498_ (.A1(alert_status),
    .A2(\u_digital.irq_manager_irq_status_alert ),
    .B1_N(\u_digital.irq_manager_irq_clear_alert_pulse ),
    .X(_002_));
 sky130_fd_sc_hd__mux2_1 _499_ (.A0(\u_digital.u_temp_filter_compare.prev_sample[0] ),
    .A1(\u_digital.adc_code[0] ),
    .S(\u_digital.adc_valid ),
    .X(_003_));
 sky130_fd_sc_hd__mux2_1 _500_ (.A0(\u_digital.u_temp_filter_compare.prev_sample[1] ),
    .A1(\u_digital.adc_code[1] ),
    .S(\u_digital.adc_valid ),
    .X(_004_));
 sky130_fd_sc_hd__mux2_1 _501_ (.A0(\u_digital.u_temp_filter_compare.prev_sample[2] ),
    .A1(\u_digital.adc_code[2] ),
    .S(\u_digital.adc_valid ),
    .X(_005_));
 sky130_fd_sc_hd__mux2_1 _502_ (.A0(\u_digital.u_temp_filter_compare.prev_sample[3] ),
    .A1(\u_digital.adc_code[3] ),
    .S(\u_digital.adc_valid ),
    .X(_006_));
 sky130_fd_sc_hd__mux2_1 _503_ (.A0(\u_digital.u_temp_filter_compare.prev_sample[4] ),
    .A1(\u_digital.adc_code[4] ),
    .S(\u_digital.adc_valid ),
    .X(_007_));
 sky130_fd_sc_hd__mux2_1 _504_ (.A0(\u_digital.u_temp_filter_compare.prev_sample[5] ),
    .A1(\u_digital.adc_code[5] ),
    .S(\u_digital.adc_valid ),
    .X(_008_));
 sky130_fd_sc_hd__mux2_1 _505_ (.A0(\u_digital.u_temp_filter_compare.prev_sample[6] ),
    .A1(\u_digital.adc_code[6] ),
    .S(\u_digital.adc_valid ),
    .X(_009_));
 sky130_fd_sc_hd__mux2_1 _506_ (.A0(\u_digital.u_temp_filter_compare.prev_sample[7] ),
    .A1(\u_digital.adc_code[7] ),
    .S(\u_digital.adc_valid ),
    .X(_010_));
 sky130_fd_sc_hd__mux2_1 _507_ (.A0(\u_digital.u_temp_filter_compare.prev_sample[8] ),
    .A1(\u_digital.adc_code[8] ),
    .S(\u_digital.adc_valid ),
    .X(_011_));
 sky130_fd_sc_hd__mux2_1 _508_ (.A0(\u_digital.u_temp_filter_compare.prev_sample[9] ),
    .A1(\u_digital.adc_code[9] ),
    .S(\u_digital.adc_valid ),
    .X(_012_));
 sky130_fd_sc_hd__mux2_1 _509_ (.A0(\u_digital.u_temp_filter_compare.prev_sample[10] ),
    .A1(\u_digital.adc_code[10] ),
    .S(\u_digital.adc_valid ),
    .X(_013_));
 sky130_fd_sc_hd__mux2_1 _510_ (.A0(\u_digital.u_temp_filter_compare.prev_sample[11] ),
    .A1(\u_digital.adc_code[11] ),
    .S(\u_digital.adc_valid ),
    .X(_014_));
 sky130_fd_sc_hd__o21ba_2 _511_ (.A1(\u_digital.irq_manager_status_sample_done ),
    .A2(\u_digital.irq_manager_irq_status_sample_done ),
    .B1_N(\u_digital.irq_manager_irq_clear_sample_done_pulse ),
    .X(_015_));
 sky130_fd_sc_hd__or2_2 _512_ (.A(_017_),
    .B(_125_),
    .X(_203_));
 sky130_fd_sc_hd__nand2_2 _513_ (.A(_017_),
    .B(_125_),
    .Y(_204_));
 sky130_fd_sc_hd__nand2_2 _514_ (.A(_203_),
    .B(_204_),
    .Y(_205_));
 sky130_fd_sc_hd__nor2_2 _515_ (.A(_019_),
    .B(_124_),
    .Y(_206_));
 sky130_fd_sc_hd__o31a_2 _516_ (.A1(_019_),
    .A2(_124_),
    .A3(_205_),
    .B1(_203_),
    .X(_207_));
 sky130_fd_sc_hd__a21o_2 _517_ (.A1(_019_),
    .A2(_124_),
    .B1(_205_),
    .X(_208_));
 sky130_fd_sc_hd__a211o_2 _518_ (.A1(\u_digital.irq_manager_status_sample_done ),
    .A2(_118_),
    .B1(_112_),
    .C1(_020_),
    .X(_209_));
 sky130_fd_sc_hd__or2_2 _519_ (.A(threshold_code[9]),
    .B(_119_),
    .X(_210_));
 sky130_fd_sc_hd__a211o_2 _520_ (.A1(\u_digital.irq_manager_status_sample_done ),
    .A2(_108_),
    .B1(_110_),
    .C1(_021_),
    .X(_211_));
 sky130_fd_sc_hd__nand2b_2 _521_ (.A_N(_211_),
    .B(_210_),
    .Y(_212_));
 sky130_fd_sc_hd__o211ai_2 _522_ (.A1(_018_),
    .A2(_108_),
    .B1(_109_),
    .C1(_021_),
    .Y(_213_));
 sky130_fd_sc_hd__nand2_2 _523_ (.A(_022_),
    .B(_102_),
    .Y(_214_));
 sky130_fd_sc_hd__and4_2 _524_ (.A(_209_),
    .B(_211_),
    .C(_213_),
    .D(_214_),
    .X(_215_));
 sky130_fd_sc_hd__nor2_2 _525_ (.A(_025_),
    .B(_073_),
    .Y(_216_));
 sky130_fd_sc_hd__a22o_2 _526_ (.A1(_028_),
    .A2(_041_),
    .B1(_048_),
    .B2(_027_),
    .X(_217_));
 sky130_fd_sc_hd__or2_2 _527_ (.A(_027_),
    .B(_048_),
    .X(_218_));
 sky130_fd_sc_hd__o2bb2a_2 _528_ (.A1_N(_217_),
    .A2_N(_218_),
    .B1(threshold_code[2]),
    .B2(_055_),
    .X(_219_));
 sky130_fd_sc_hd__a22o_2 _529_ (.A1(threshold_code[2]),
    .A2(_055_),
    .B1(_064_),
    .B2(threshold_code[3]),
    .X(_220_));
 sky130_fd_sc_hd__o211ai_2 _530_ (.A1(_018_),
    .A2(_072_),
    .B1(_071_),
    .C1(_025_),
    .Y(_221_));
 sky130_fd_sc_hd__or2_2 _531_ (.A(threshold_code[3]),
    .B(_064_),
    .X(_222_));
 sky130_fd_sc_hd__o211a_2 _532_ (.A1(_219_),
    .A2(_220_),
    .B1(_221_),
    .C1(_222_),
    .X(_223_));
 sky130_fd_sc_hd__a211o_2 _533_ (.A1(\u_digital.irq_manager_status_sample_done ),
    .A2(_094_),
    .B1(_093_),
    .C1(threshold_code[6]),
    .X(_224_));
 sky130_fd_sc_hd__o221a_2 _534_ (.A1(threshold_code[5]),
    .A2(_083_),
    .B1(_216_),
    .B2(_223_),
    .C1(_224_),
    .X(_225_));
 sky130_fd_sc_hd__nor2_2 _535_ (.A(_022_),
    .B(_102_),
    .Y(_226_));
 sky130_fd_sc_hd__o311a_2 _536_ (.A1(_018_),
    .A2(_091_),
    .A3(_092_),
    .B1(threshold_code[6]),
    .C1(_085_),
    .X(_227_));
 sky130_fd_sc_hd__a311o_2 _537_ (.A1(threshold_code[5]),
    .A2(_083_),
    .A3(_224_),
    .B1(_226_),
    .C1(_227_),
    .X(_228_));
 sky130_fd_sc_hd__o211ai_2 _538_ (.A1(_225_),
    .A2(_228_),
    .B1(_210_),
    .C1(_215_),
    .Y(_229_));
 sky130_fd_sc_hd__a311o_2 _539_ (.A1(_209_),
    .A2(_212_),
    .A3(_229_),
    .B1(_208_),
    .C1(_206_),
    .X(_230_));
 sky130_fd_sc_hd__a31o_2 _540_ (.A1(\u_digital.adc_valid ),
    .A2(_207_),
    .A3(_230_),
    .B1(alert_status),
    .X(_016_));
 sky130_fd_sc_hd__sdfrtp_2 _541_ (.CLK(clk),
    .D(\u_digital.adc_valid ),
    .RESET_B(rst_n),
    .SCD(scan_in[0]),
    .SCE(scan_en),
    .Q(\u_digital.u_register_map.adc_valid_r ));
 sky130_fd_sc_hd__sdfrtp_2 _542_ (.CLK(clk),
    .D(\u_digital.u_register_map.sample_req_next ),
    .RESET_B(rst_n),
    .SCD(scan_in[1]),
    .SCE(scan_en),
    .Q(sample_req));
 sky130_fd_sc_hd__sdfrtp_2 _543_ (.CLK(clk),
    .D(\u_digital.u_register_map.sample_count_next[0] ),
    .RESET_B(rst_n),
    .SCD(scan_in[2]),
    .SCE(scan_en),
    .Q(\u_digital.register_map_sample_count[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _544_ (.CLK(clk),
    .D(\u_digital.u_register_map.sample_count_next[1] ),
    .RESET_B(rst_n),
    .SCD(scan_in[3]),
    .SCE(scan_en),
    .Q(\u_digital.register_map_sample_count[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _545_ (.CLK(clk),
    .D(\u_digital.u_register_map.sample_count_next[2] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.u_register_map.adc_valid_r ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_sample_count[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _546_ (.CLK(clk),
    .D(\u_digital.u_register_map.sample_count_next[3] ),
    .RESET_B(rst_n),
    .SCD(sample_req),
    .SCE(scan_en),
    .Q(\u_digital.register_map_sample_count[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _547_ (.CLK(clk),
    .D(\u_digital.u_register_map.sample_count_next[4] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_sample_count[0] ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_sample_count[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _548_ (.CLK(clk),
    .D(\u_digital.u_register_map.sample_count_next[5] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_sample_count[1] ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_sample_count[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _549_ (.CLK(clk),
    .D(\u_digital.u_register_map.sample_count_next[6] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_sample_count[2] ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_sample_count[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _550_ (.CLK(clk),
    .D(\u_digital.u_register_map.sample_count_next[7] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_sample_count[3] ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_sample_count[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _551_ (.CLK(clk),
    .D(\u_digital.u_register_map.sample_count_next[8] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_sample_count[4] ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_sample_count[8] ));
 sky130_fd_sc_hd__sdfrtp_2 _552_ (.CLK(clk),
    .D(\u_digital.u_register_map.sample_count_next[9] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_sample_count[5] ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_sample_count[9] ));
 sky130_fd_sc_hd__sdfrtp_2 _553_ (.CLK(clk),
    .D(\u_digital.u_register_map.sample_count_next[10] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_sample_count[6] ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_sample_count[10] ));
 sky130_fd_sc_hd__sdfrtp_2 _554_ (.CLK(clk),
    .D(\u_digital.u_register_map.sample_count_next[11] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_sample_count[7] ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_sample_count[11] ));
 sky130_fd_sc_hd__sdfrtp_2 _555_ (.CLK(clk),
    .D(\u_digital.u_register_map.sample_count_next[12] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_sample_count[8] ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_sample_count[12] ));
 sky130_fd_sc_hd__sdfrtp_2 _556_ (.CLK(clk),
    .D(\u_digital.u_register_map.sample_count_next[13] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_sample_count[9] ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_sample_count[13] ));
 sky130_fd_sc_hd__sdfrtp_2 _557_ (.CLK(clk),
    .D(\u_digital.u_register_map.sample_count_next[14] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_sample_count[10] ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_sample_count[14] ));
 sky130_fd_sc_hd__sdfrtp_2 _558_ (.CLK(clk),
    .D(\u_digital.u_register_map.sample_count_next[15] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_sample_count[11] ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_sample_count[15] ));
 sky130_fd_sc_hd__sdfrtp_2 _559_ (.CLK(clk),
    .D(\u_digital.u_register_map.rd_data_next[0] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_sample_count[12] ),
    .SCE(scan_en),
    .Q(rd_data[0]));
 sky130_fd_sc_hd__sdfrtp_2 _560_ (.CLK(clk),
    .D(\u_digital.u_register_map.rd_data_next[1] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_sample_count[13] ),
    .SCE(scan_en),
    .Q(rd_data[1]));
 sky130_fd_sc_hd__sdfrtp_2 _561_ (.CLK(clk),
    .D(\u_digital.u_register_map.rd_data_next[2] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_sample_count[14] ),
    .SCE(scan_en),
    .Q(rd_data[2]));
 sky130_fd_sc_hd__sdfrtp_2 _562_ (.CLK(clk),
    .D(\u_digital.u_register_map.rd_data_next[3] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_sample_count[15] ),
    .SCE(scan_en),
    .Q(rd_data[3]));
 sky130_fd_sc_hd__sdfrtp_2 _563_ (.CLK(clk),
    .D(\u_digital.u_register_map.rd_data_next[4] ),
    .RESET_B(rst_n),
    .SCD(rd_data[0]),
    .SCE(scan_en),
    .Q(rd_data[4]));
 sky130_fd_sc_hd__sdfrtp_2 _564_ (.CLK(clk),
    .D(\u_digital.u_register_map.rd_data_next[5] ),
    .RESET_B(rst_n),
    .SCD(rd_data[1]),
    .SCE(scan_en),
    .Q(rd_data[5]));
 sky130_fd_sc_hd__sdfrtp_2 _565_ (.CLK(clk),
    .D(\u_digital.u_register_map.rd_data_next[6] ),
    .RESET_B(rst_n),
    .SCD(rd_data[2]),
    .SCE(scan_en),
    .Q(rd_data[6]));
 sky130_fd_sc_hd__sdfrtp_2 _566_ (.CLK(clk),
    .D(\u_digital.u_register_map.rd_data_next[7] ),
    .RESET_B(rst_n),
    .SCD(rd_data[3]),
    .SCE(scan_en),
    .Q(rd_data[7]));
 sky130_fd_sc_hd__sdfrtp_2 _567_ (.CLK(clk),
    .D(\u_digital.u_register_map.rd_data_next[8] ),
    .RESET_B(rst_n),
    .SCD(rd_data[4]),
    .SCE(scan_en),
    .Q(rd_data[8]));
 sky130_fd_sc_hd__sdfrtp_2 _568_ (.CLK(clk),
    .D(\u_digital.u_register_map.rd_data_next[9] ),
    .RESET_B(rst_n),
    .SCD(rd_data[5]),
    .SCE(scan_en),
    .Q(rd_data[9]));
 sky130_fd_sc_hd__sdfrtp_2 _569_ (.CLK(clk),
    .D(\u_digital.u_register_map.rd_data_next[10] ),
    .RESET_B(rst_n),
    .SCD(rd_data[6]),
    .SCE(scan_en),
    .Q(rd_data[10]));
 sky130_fd_sc_hd__sdfrtp_2 _570_ (.CLK(clk),
    .D(\u_digital.u_register_map.rd_data_next[11] ),
    .RESET_B(rst_n),
    .SCD(rd_data[7]),
    .SCE(scan_en),
    .Q(rd_data[11]));
 sky130_fd_sc_hd__sdfrtp_2 _571_ (.CLK(clk),
    .D(\u_digital.u_register_map.rd_data_next[12] ),
    .RESET_B(rst_n),
    .SCD(rd_data[8]),
    .SCE(scan_en),
    .Q(rd_data[12]));
 sky130_fd_sc_hd__sdfrtp_2 _572_ (.CLK(clk),
    .D(\u_digital.u_register_map.rd_data_next[13] ),
    .RESET_B(rst_n),
    .SCD(rd_data[9]),
    .SCE(scan_en),
    .Q(rd_data[13]));
 sky130_fd_sc_hd__sdfrtp_2 _573_ (.CLK(clk),
    .D(\u_digital.u_register_map.rd_data_next[14] ),
    .RESET_B(rst_n),
    .SCD(rd_data[10]),
    .SCE(scan_en),
    .Q(rd_data[14]));
 sky130_fd_sc_hd__sdfrtp_2 _574_ (.CLK(clk),
    .D(\u_digital.u_register_map.rd_data_next[15] ),
    .RESET_B(rst_n),
    .SCD(rd_data[11]),
    .SCE(scan_en),
    .Q(rd_data[15]));
 sky130_fd_sc_hd__sdfrtp_2 _575_ (.CLK(clk),
    .D(\u_digital.u_register_map.threshold_next[0] ),
    .RESET_B(rst_n),
    .SCD(rd_data[12]),
    .SCE(scan_en),
    .Q(threshold_code[0]));
 sky130_fd_sc_hd__sdfrtp_2 _576_ (.CLK(clk),
    .D(\u_digital.u_register_map.threshold_next[1] ),
    .RESET_B(rst_n),
    .SCD(rd_data[13]),
    .SCE(scan_en),
    .Q(threshold_code[1]));
 sky130_fd_sc_hd__sdfrtp_2 _577_ (.CLK(clk),
    .D(\u_digital.u_register_map.threshold_next[2] ),
    .RESET_B(rst_n),
    .SCD(rd_data[14]),
    .SCE(scan_en),
    .Q(threshold_code[2]));
 sky130_fd_sc_hd__sdfrtp_2 _578_ (.CLK(clk),
    .D(\u_digital.u_register_map.threshold_next[3] ),
    .RESET_B(rst_n),
    .SCD(rd_data[15]),
    .SCE(scan_en),
    .Q(threshold_code[3]));
 sky130_fd_sc_hd__sdfrtp_2 _579_ (.CLK(clk),
    .D(\u_digital.u_register_map.threshold_next[4] ),
    .RESET_B(rst_n),
    .SCD(threshold_code[0]),
    .SCE(scan_en),
    .Q(threshold_code[4]));
 sky130_fd_sc_hd__sdfrtp_2 _580_ (.CLK(clk),
    .D(\u_digital.u_register_map.threshold_next[5] ),
    .RESET_B(rst_n),
    .SCD(threshold_code[1]),
    .SCE(scan_en),
    .Q(threshold_code[5]));
 sky130_fd_sc_hd__sdfrtp_2 _581_ (.CLK(clk),
    .D(\u_digital.u_register_map.threshold_next[6] ),
    .RESET_B(rst_n),
    .SCD(threshold_code[2]),
    .SCE(scan_en),
    .Q(threshold_code[6]));
 sky130_fd_sc_hd__sdfrtp_2 _582_ (.CLK(clk),
    .D(\u_digital.u_register_map.threshold_next[7] ),
    .RESET_B(rst_n),
    .SCD(threshold_code[3]),
    .SCE(scan_en),
    .Q(threshold_code[7]));
 sky130_fd_sc_hd__sdfrtp_2 _583_ (.CLK(clk),
    .D(\u_digital.u_register_map.threshold_next[8] ),
    .RESET_B(rst_n),
    .SCD(threshold_code[4]),
    .SCE(scan_en),
    .Q(threshold_code[8]));
 sky130_fd_sc_hd__sdfrtp_2 _584_ (.CLK(clk),
    .D(\u_digital.u_register_map.threshold_next[9] ),
    .RESET_B(rst_n),
    .SCD(threshold_code[5]),
    .SCE(scan_en),
    .Q(threshold_code[9]));
 sky130_fd_sc_hd__sdfrtp_2 _585_ (.CLK(clk),
    .D(\u_digital.u_register_map.threshold_next[10] ),
    .RESET_B(rst_n),
    .SCD(threshold_code[6]),
    .SCE(scan_en),
    .Q(threshold_code[10]));
 sky130_fd_sc_hd__sdfrtp_2 _586_ (.CLK(clk),
    .D(\u_digital.u_register_map.threshold_next[11] ),
    .RESET_B(rst_n),
    .SCD(threshold_code[7]),
    .SCE(scan_en),
    .Q(threshold_code[11]));
 sky130_fd_sc_hd__sdfrtp_2 _587_ (.CLK(clk),
    .D(\u_digital.adc_code[0] ),
    .RESET_B(rst_n),
    .SCD(threshold_code[8]),
    .SCE(scan_en),
    .Q(\u_digital.u_register_map.adc_code_r[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _588_ (.CLK(clk),
    .D(\u_digital.adc_code[1] ),
    .RESET_B(rst_n),
    .SCD(threshold_code[9]),
    .SCE(scan_en),
    .Q(\u_digital.u_register_map.adc_code_r[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _589_ (.CLK(clk),
    .D(\u_digital.adc_code[2] ),
    .RESET_B(rst_n),
    .SCD(threshold_code[10]),
    .SCE(scan_en),
    .Q(\u_digital.u_register_map.adc_code_r[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _590_ (.CLK(clk),
    .D(\u_digital.adc_code[3] ),
    .RESET_B(rst_n),
    .SCD(threshold_code[11]),
    .SCE(scan_en),
    .Q(\u_digital.u_register_map.adc_code_r[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _591_ (.CLK(clk),
    .D(\u_digital.adc_code[4] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.u_register_map.adc_code_r[0] ),
    .SCE(scan_en),
    .Q(\u_digital.u_register_map.adc_code_r[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _592_ (.CLK(clk),
    .D(\u_digital.adc_code[5] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.u_register_map.adc_code_r[1] ),
    .SCE(scan_en),
    .Q(\u_digital.u_register_map.adc_code_r[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _593_ (.CLK(clk),
    .D(\u_digital.adc_code[6] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.u_register_map.adc_code_r[2] ),
    .SCE(scan_en),
    .Q(\u_digital.u_register_map.adc_code_r[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _594_ (.CLK(clk),
    .D(\u_digital.adc_code[7] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.u_register_map.adc_code_r[3] ),
    .SCE(scan_en),
    .Q(\u_digital.u_register_map.adc_code_r[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _595_ (.CLK(clk),
    .D(\u_digital.adc_code[8] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.u_register_map.adc_code_r[4] ),
    .SCE(scan_en),
    .Q(\u_digital.u_register_map.adc_code_r[8] ));
 sky130_fd_sc_hd__sdfrtp_2 _596_ (.CLK(clk),
    .D(\u_digital.adc_code[9] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.u_register_map.adc_code_r[5] ),
    .SCE(scan_en),
    .Q(\u_digital.u_register_map.adc_code_r[9] ));
 sky130_fd_sc_hd__sdfrtp_2 _597_ (.CLK(clk),
    .D(\u_digital.adc_code[10] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.u_register_map.adc_code_r[6] ),
    .SCE(scan_en),
    .Q(\u_digital.u_register_map.adc_code_r[10] ));
 sky130_fd_sc_hd__sdfrtp_2 _598_ (.CLK(clk),
    .D(\u_digital.adc_code[11] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.u_register_map.adc_code_r[7] ),
    .SCE(scan_en),
    .Q(\u_digital.u_register_map.adc_code_r[11] ));
 sky130_fd_sc_hd__sdfrtp_2 _599_ (.CLK(clk),
    .D(\u_digital.u_register_map.control_enable_next ),
    .RESET_B(rst_n),
    .SCD(\u_digital.u_register_map.adc_code_r[8] ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_control_enable ));
 sky130_fd_sc_hd__sdfrtp_2 _600_ (.CLK(clk),
    .D(\u_digital.u_register_map.control_irq_enable_next ),
    .RESET_B(rst_n),
    .SCD(\u_digital.u_register_map.adc_code_r[9] ),
    .SCE(scan_en),
    .Q(\u_digital.irq_manager_control_irq_enable ));
 sky130_fd_sc_hd__sdfrtp_2 _601_ (.CLK(clk),
    .D(\u_digital.u_register_map.irq_clear_sample_done_pulse_next ),
    .RESET_B(rst_n),
    .SCD(\u_digital.u_register_map.adc_code_r[10] ),
    .SCE(scan_en),
    .Q(\u_digital.irq_manager_irq_clear_sample_done_pulse ));
 sky130_fd_sc_hd__sdfrtp_2 _602_ (.CLK(clk),
    .D(\u_digital.u_register_map.status_sample_done_next ),
    .RESET_B(rst_n),
    .SCD(\u_digital.u_register_map.adc_code_r[11] ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_status_sample_done ));
 sky130_fd_sc_hd__sdfrtp_2 _603_ (.CLK(clk),
    .D(\u_digital.u_register_map.status_alert_pending_next ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_control_enable ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_status_alert_pending ));
 sky130_fd_sc_hd__sdfrtp_2 _604_ (.CLK(clk),
    .D(\u_digital.u_register_map.irq_clear_alert_pulse_next ),
    .RESET_B(rst_n),
    .SCD(\u_digital.irq_manager_control_irq_enable ),
    .SCE(scan_en),
    .Q(\u_digital.irq_manager_irq_clear_alert_pulse ));
 sky130_fd_sc_hd__sdfrtp_2 _605_ (.CLK(clk),
    .D(\u_digital.u_register_map.status_adc_valid_seen_next ),
    .RESET_B(rst_n),
    .SCD(\u_digital.irq_manager_irq_clear_sample_done_pulse ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_status_adc_valid_seen ));
 sky130_fd_sc_hd__sdfrtp_2 _606_ (.CLK(clk),
    .D(\u_digital.u_register_map.irq_status_alert_next ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_status_sample_done ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_irq_status_alert ));
 sky130_fd_sc_hd__sdfrtp_2 _607_ (.CLK(clk),
    .D(\u_digital.u_register_map.status_busy_next ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_status_alert_pending ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_status_busy ));
 sky130_fd_sc_hd__sdfrtp_2 _608_ (.CLK(clk),
    .D(\u_digital.u_register_map.latest_temp_next[0] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.irq_manager_irq_clear_alert_pulse ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_latest_temp[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _609_ (.CLK(clk),
    .D(\u_digital.u_register_map.latest_temp_next[1] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_status_adc_valid_seen ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_latest_temp[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _610_ (.CLK(clk),
    .D(\u_digital.u_register_map.latest_temp_next[2] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_irq_status_alert ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_latest_temp[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _611_ (.CLK(clk),
    .D(\u_digital.u_register_map.latest_temp_next[3] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_status_busy ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_latest_temp[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _612_ (.CLK(clk),
    .D(\u_digital.u_register_map.latest_temp_next[4] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_latest_temp[0] ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_latest_temp[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _613_ (.CLK(clk),
    .D(\u_digital.u_register_map.latest_temp_next[5] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_latest_temp[1] ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_latest_temp[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _614_ (.CLK(clk),
    .D(\u_digital.u_register_map.latest_temp_next[6] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_latest_temp[2] ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_latest_temp[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _615_ (.CLK(clk),
    .D(\u_digital.u_register_map.latest_temp_next[7] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_latest_temp[3] ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_latest_temp[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _616_ (.CLK(clk),
    .D(\u_digital.u_register_map.latest_temp_next[8] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_latest_temp[4] ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_latest_temp[8] ));
 sky130_fd_sc_hd__sdfrtp_2 _617_ (.CLK(clk),
    .D(\u_digital.u_register_map.latest_temp_next[9] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_latest_temp[5] ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_latest_temp[9] ));
 sky130_fd_sc_hd__sdfrtp_2 _618_ (.CLK(clk),
    .D(\u_digital.u_register_map.latest_temp_next[10] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_latest_temp[6] ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_latest_temp[10] ));
 sky130_fd_sc_hd__sdfrtp_2 _619_ (.CLK(clk),
    .D(\u_digital.u_register_map.latest_temp_next[11] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_latest_temp[7] ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_latest_temp[11] ));
 sky130_fd_sc_hd__sdfrtp_2 _620_ (.CLK(clk),
    .D(\u_digital.u_register_map.irq_status_sample_done_next ),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_latest_temp[8] ),
    .SCE(scan_en),
    .Q(\u_digital.register_map_irq_status_sample_done ));
 sky130_fd_sc_hd__sdfrtp_2 _621_ (.CLK(clk),
    .D(_001_),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_latest_temp[9] ),
    .SCE(scan_en),
    .Q(\u_digital.irq_manager_status_sample_done ));
 sky130_fd_sc_hd__sdfrtp_2 _622_ (.CLK(clk),
    .D(_002_),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_latest_temp[10] ),
    .SCE(scan_en),
    .Q(\u_digital.irq_manager_irq_status_alert ));
 sky130_fd_sc_hd__sdfrtp_2 _623_ (.CLK(clk),
    .D(_000_),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_latest_temp[11] ),
    .SCE(scan_en),
    .Q(alert_irq));
 sky130_fd_sc_hd__sdfrtp_2 _624_ (.CLK(clk),
    .D(_003_),
    .RESET_B(rst_n),
    .SCD(\u_digital.register_map_irq_status_sample_done ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_filter_compare.prev_sample[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _625_ (.CLK(clk),
    .D(_004_),
    .RESET_B(rst_n),
    .SCD(\u_digital.irq_manager_status_sample_done ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_filter_compare.prev_sample[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _626_ (.CLK(clk),
    .D(_005_),
    .RESET_B(rst_n),
    .SCD(\u_digital.irq_manager_irq_status_alert ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_filter_compare.prev_sample[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _627_ (.CLK(clk),
    .D(_006_),
    .RESET_B(rst_n),
    .SCD(alert_irq),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_filter_compare.prev_sample[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _628_ (.CLK(clk),
    .D(_007_),
    .RESET_B(rst_n),
    .SCD(\u_digital.u_temp_filter_compare.prev_sample[0] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_filter_compare.prev_sample[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _629_ (.CLK(clk),
    .D(_008_),
    .RESET_B(rst_n),
    .SCD(\u_digital.u_temp_filter_compare.prev_sample[1] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_filter_compare.prev_sample[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _630_ (.CLK(clk),
    .D(_009_),
    .RESET_B(rst_n),
    .SCD(\u_digital.u_temp_filter_compare.prev_sample[2] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_filter_compare.prev_sample[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _631_ (.CLK(clk),
    .D(_010_),
    .RESET_B(rst_n),
    .SCD(\u_digital.u_temp_filter_compare.prev_sample[3] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_filter_compare.prev_sample[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _632_ (.CLK(clk),
    .D(_011_),
    .RESET_B(rst_n),
    .SCD(\u_digital.u_temp_filter_compare.prev_sample[4] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_filter_compare.prev_sample[8] ));
 sky130_fd_sc_hd__sdfrtp_2 _633_ (.CLK(clk),
    .D(_012_),
    .RESET_B(rst_n),
    .SCD(\u_digital.u_temp_filter_compare.prev_sample[5] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_filter_compare.prev_sample[9] ));
 sky130_fd_sc_hd__sdfrtp_2 _634_ (.CLK(clk),
    .D(_013_),
    .RESET_B(rst_n),
    .SCD(\u_digital.u_temp_filter_compare.prev_sample[6] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_filter_compare.prev_sample[10] ));
 sky130_fd_sc_hd__sdfrtp_2 _635_ (.CLK(clk),
    .D(_014_),
    .RESET_B(rst_n),
    .SCD(\u_digital.u_temp_filter_compare.prev_sample[7] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_filter_compare.prev_sample[11] ));
 sky130_fd_sc_hd__sdfrtp_2 _636_ (.CLK(clk),
    .D(_015_),
    .RESET_B(rst_n),
    .SCD(\u_digital.u_temp_filter_compare.prev_sample[8] ),
    .SCE(scan_en),
    .Q(\u_digital.irq_manager_irq_status_sample_done ));
 sky130_fd_sc_hd__sdfrtp_2 _637_ (.CLK(clk),
    .D(_016_),
    .RESET_B(rst_n),
    .SCD(\u_digital.u_temp_filter_compare.prev_sample[9] ),
    .SCE(scan_en),
    .Q(alert_status));
 sky130_fd_sc_hd__sdfrtp_2 _638_ (.CLK(clk),
    .D(\u_digital.u_temp_filter_compare.filtered_next[0] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.u_temp_filter_compare.prev_sample[10] ),
    .SCE(scan_en),
    .Q(temp_code[0]));
 sky130_fd_sc_hd__sdfrtp_2 _639_ (.CLK(clk),
    .D(\u_digital.u_temp_filter_compare.filtered_next[1] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.u_temp_filter_compare.prev_sample[11] ),
    .SCE(scan_en),
    .Q(temp_code[1]));
 sky130_fd_sc_hd__sdfrtp_2 _640_ (.CLK(clk),
    .D(\u_digital.u_temp_filter_compare.filtered_next[2] ),
    .RESET_B(rst_n),
    .SCD(\u_digital.irq_manager_irq_status_sample_done ),
    .SCE(scan_en),
    .Q(temp_code[2]));
 sky130_fd_sc_hd__sdfrtp_2 _641_ (.CLK(clk),
    .D(\u_digital.u_temp_filter_compare.filtered_next[3] ),
    .RESET_B(rst_n),
    .SCD(alert_status),
    .SCE(scan_en),
    .Q(temp_code[3]));
 sky130_fd_sc_hd__sdfrtp_2 _642_ (.CLK(clk),
    .D(\u_digital.u_temp_filter_compare.filtered_next[4] ),
    .RESET_B(rst_n),
    .SCD(temp_code[0]),
    .SCE(scan_en),
    .Q(temp_code[4]));
 sky130_fd_sc_hd__sdfrtp_2 _643_ (.CLK(clk),
    .D(\u_digital.u_temp_filter_compare.filtered_next[5] ),
    .RESET_B(rst_n),
    .SCD(temp_code[1]),
    .SCE(scan_en),
    .Q(temp_code[5]));
 sky130_fd_sc_hd__sdfrtp_2 _644_ (.CLK(clk),
    .D(\u_digital.u_temp_filter_compare.filtered_next[6] ),
    .RESET_B(rst_n),
    .SCD(temp_code[2]),
    .SCE(scan_en),
    .Q(temp_code[6]));
 sky130_fd_sc_hd__sdfrtp_2 _645_ (.CLK(clk),
    .D(\u_digital.u_temp_filter_compare.filtered_next[7] ),
    .RESET_B(rst_n),
    .SCD(temp_code[3]),
    .SCE(scan_en),
    .Q(temp_code[7]));
 sky130_fd_sc_hd__sdfrtp_2 _646_ (.CLK(clk),
    .D(\u_digital.u_temp_filter_compare.filtered_next[8] ),
    .RESET_B(rst_n),
    .SCD(temp_code[4]),
    .SCE(scan_en),
    .Q(temp_code[8]));
 sky130_fd_sc_hd__sdfrtp_2 _647_ (.CLK(clk),
    .D(\u_digital.u_temp_filter_compare.filtered_next[9] ),
    .RESET_B(rst_n),
    .SCD(temp_code[5]),
    .SCE(scan_en),
    .Q(temp_code[9]));
 sky130_fd_sc_hd__sdfrtp_2 _648_ (.CLK(clk),
    .D(\u_digital.u_temp_filter_compare.filtered_next[10] ),
    .RESET_B(rst_n),
    .SCD(temp_code[6]),
    .SCE(scan_en),
    .Q(temp_code[10]));
 sky130_fd_sc_hd__sdfrtp_2 _649_ (.CLK(clk),
    .D(\u_digital.u_temp_filter_compare.filtered_next[11] ),
    .RESET_B(rst_n),
    .SCD(temp_code[7]),
    .SCE(scan_en),
    .Q(temp_code[11]));
 assign scan_out[3] = temp_code[10];
 assign scan_out[0] = temp_code[11];
 assign scan_out[1] = temp_code[8];
 assign scan_out[2] = temp_code[9];
  // Preserved non-stdcell macro instances omitted by DFT write_verilog.
  temp_sensor_adc_model u_analog (
    .adc_code({ \u_digital.adc_code[11] , \u_digital.adc_code[10] , \u_digital.adc_code[9] , \u_digital.adc_code[8] , \u_digital.adc_code[7] , \u_digital.adc_code[6] , \u_digital.adc_code[5] , \u_digital.adc_code[4] , \u_digital.adc_code[3] , \u_digital.adc_code[2] , \u_digital.adc_code[1] , \u_digital.adc_code[0]  }),
    .adc_valid(\u_digital.adc_valid ),
    .avdd(avdd),
    .avss(avss),
    .sample_req(sample_req),
    .sensor_temp_celsius(sensor_temp_celsius)
  );
endmodule
