/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0237c755-1080-4752-ac02-235a53eb46c5/869ce829-4b7b-4a70-a506-3d8f967b3e44/digital/system/imported_rtl/temp_sensor_adc_model.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0237c755-1080-4752-ac02-235a53eb46c5/869ce829-4b7b-4a70-a506-3d8f967b3e44/digital/system/imported_rtl/irq_manager.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0237c755-1080-4752-ac02-235a53eb46c5/869ce829-4b7b-4a70-a506-3d8f967b3e44/digital/system/imported_rtl/register_map.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0237c755-1080-4752-ac02-235a53eb46c5/869ce829-4b7b-4a70-a506-3d8f967b3e44/digital/system/imported_rtl/temp_filter_compare.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0237c755-1080-4752-ac02-235a53eb46c5/869ce829-4b7b-4a70-a506-3d8f967b3e44/digital/system/imported_rtl/temp_monitor_digital.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0237c755-1080-4752-ac02-235a53eb46c5/869ce829-4b7b-4a70-a506-3d8f967b3e44/digital/system/imported_rtl/temp_monitor_soc_phys.sv
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0237c755-1080-4752-ac02-235a53eb46c5/869ce829-4b7b-4a70-a506-3d8f967b3e44/digital/system/imported_rtl/temp_monitor_soc_sim.sv
