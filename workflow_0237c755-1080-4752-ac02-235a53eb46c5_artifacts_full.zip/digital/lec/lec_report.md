# Logic Equivalence Check

- Status: `fail_reset_sequence_counterexample`
- Tool: `yosys`
- Top module: `temp_monitor_soc_phys`
- RTL files: `7`
- Synth netlist: `temp_monitor_soc_phys_synth.v`
- Liberty files discovered: `1`
- Standard-cell Verilog models loaded: `1`
- Standard-cell model strategy: `generated_functional_wrappers_from_gate_netlist`
- Missing standard-cell models: `0`
- Unproven points: `25`
- Unproven signal names: `alert_status, alert_irq, sample_req, threshold_code[0], threshold_code[1], temp_code[11], threshold_code[2], threshold_code[3], temp_code[10], threshold_code[4], threshold_code[5], threshold_code[6], temp_code[9], threshold_code[7], threshold_code[8], threshold_code[9], threshold_code[10], temp_code[8], threshold_code[11], temp_code[7], temp_code[3], temp_code[6], rd_data[0], rd_data[1], rd_data[2], temp_code[5], rd_data[3], rd_data[4], rd_data[5], temp_code[4], rd_data[6], rd_data[7], rd_data[8], rd_data[9], rd_data[10], rd_data[11], rd_data[12], rd_data[13], rd_data[14], rd_data[15], temp_code[2], temp_code[1], temp_code[0]`
- Primary LEC status: `inconclusive_missing_sat_models`
- Primary unproven signal names: `alert_status, alert_irq, sample_req, threshold_code[0], threshold_code[1], temp_code[11], threshold_code[2], threshold_code[3], temp_code[10], threshold_code[4], threshold_code[5], threshold_code[6], temp_code[9], threshold_code[7], threshold_code[8], threshold_code[9], threshold_code[10], temp_code[8], threshold_code[11], temp_code[7], temp_code[3], temp_code[6], rd_data[0], rd_data[1], rd_data[2], temp_code[5], rd_data[3], rd_data[4], rd_data[5], temp_code[4], rd_data[6], rd_data[7], rd_data[8], rd_data[9], rd_data[10], rd_data[11], rd_data[12], rd_data[13], rd_data[14], rd_data[15], temp_code[2], temp_code[1], temp_code[0]`
- Reset-sequence repair: `fail_reset_sequence_counterexample`
- Return code: `1`
- Failure reason: `rtl_gate_mismatch_after_reset_sequence`

If this is inconclusive, inspect `digital/lec/logs/yosys_lec.log` and `digital/lec/lec_summary.json` for unsupported cells, black boxes, reset/initial-state assumptions, or bounded sequential proof limits.
