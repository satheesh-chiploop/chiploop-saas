# Digital Synthesis Summary

- **Workflow**: 0237c755-1080-4752-ac02-235a53eb46c5
- **Status**: `ok` (rc=0)
- **Top module**: `temp_monitor_soc_phys`
- **Clock**: `clk` @ **9.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0237c755-1080-4752-ac02-235a53eb46c5/869ce829-4b7b-4a70-a506-3d8f967b3e44/digital/digital/synth/runs/System_PD_0237c755-1080-4752-ac02-235a53eb46c5/final/metrics.json`
- netlist candidates: 2 found
