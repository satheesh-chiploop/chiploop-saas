# System Software Handoff Package

- Generated at: 2026-09-16T17:43:34.457883+00:00
- Source workflow id: 0511e849-df80-4dfc-bb15-c5bf235318a2
- Package version: 2.0

## Overview

- Top module: `adaptive_aero_control_top`
- SoC sim top path: `digital/rtl/adaptive_aero_control_top.v`
- RTL file count: `14`
- Firmware ELF path: `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0511e849-df80-4dfc-bb15-c5bf235318a2/c6b04ba6-b344-408b-a3af-6f1adca450aa/system/firmware/esp_idf/build/chiploop_fpga_host.elf`
- Firmware ELF exists: `True`
- Firmware ELF placeholder: `False`
- System firmware execution readiness: `ready`
- Coverage available: `False`

## Artifacts

- `digital/rtl/adaptive_aero_control_top.v`
- `firmware/firmware_manifest.json`
- `firmware/register_map.json`
- `firmware/hal/registers.rs`
- `firmware/drivers/driver_scaffold.rs`
- `firmware/isr/interrupt_map.json`
- `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0511e849-df80-4dfc-bb15-c5bf235318a2/c6b04ba6-b344-408b-a3af-6f1adca450aa/system/firmware/esp_idf/build/chiploop_fpga_host.elf`
- `firmware/validate/Makefile`
- `firmware/validate/test_firmware_smoke.py`
- `firmware/validate/cocotb_harness.py`
- `firmware/validate/validation_report.md`
- `firmware/register_map_debug.json`
- `firmware/register_map_summary.json`
- `firmware/isr/interrupts.rs`
- `firmware/isr/interrupts_debug.json`
- `firmware/isr/interrupts_summary.json`
- `firmware/esp_idf/build/bootloader/compile_commands.json`
- `firmware/esp_idf/build/bootloader/project_description.json`
- `firmware/esp_idf/build/bootloader/project_elf_src_esp32.c`
- `firmware/esp_idf/build/bootloader/config/kconfig_menus.json`
- `firmware/esp_idf/build/bootloader/config/sdkconfig.h`
- `firmware/esp_idf/build/bootloader/config/sdkconfig.json`
- `firmware/esp_idf/build/bootloader/CMakeFiles/CMakeConfigureLog.yaml`
- `firmware/esp_idf/build/bootloader/CMakeFiles/3.31.6/CompilerIdC/CMakeCCompilerId.c`
- `firmware/esp_idf/build/bootloader/CMakeFiles/3.31.6/CompilerIdCXX/CMakeCXXCompilerId.cpp`
- `firmware/esp_idf/build/CMakeFiles/bootloader.dir/Labels.json`
- `firmware/handoff/digital_handoff_ingest.json`
- `firmware/hal/register_validation.json`
- `firmware/hal/register_validation.md`
- `firmware/hal/register_validation_debug.json`
- `firmware/hal/registers_debug.json`
- `firmware/hal/registers_summary.json`
- `firmware/drivers/driver_scaffold_debug.json`
- `firmware/drivers/driver_scaffold_summary.json`

## Required inputs for System_Software

- `register_map_path` → `firmware/register_map.json`
- `hal_path` → `firmware/hal/registers.rs`
- `driver_path` → `firmware/drivers/driver_scaffold.rs`
- `firmware_manifest_path` → `firmware/firmware_manifest.json`
- `system_integration_intent_path` → `missing`

## Recommended inputs for System_Software

- `register_dump_path` → `unavailable`
- `interrupt_mapping_path` → `firmware/isr/interrupt_map.json`
- `dma_integration_path` → `unavailable`
- `boot_dependency_plan_path` → `unavailable`
- `clock_config_path` → `unavailable`
- `reset_sequence_path` → `unavailable`
- `power_mode_path` → `unavailable`
- `soc_top_sim_path` → `digital/rtl/adaptive_aero_control_top.v`
- `rtl_file_entries` → `['digital/rtl/adaptive_aero_control_top.v', 'digital/rtl/aero_cfg_mmio.v', 'digital/rtl/aero_req_packer.v', 'digital/rtl/aero_rsp_unpacker.v', 'digital/rtl/aero_seq_timeout_monitor.v', 'digital/rtl/aero_safety_supervisor.v', 'digital/rtl/aero_req_rsp_fifo_bram.v', '/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0511e849-df80-4dfc-bb15-c5bf235318a2/c6b04ba6-b344-408b-a3af-6f1adca450aa/system/digital/rtl/aero_cfg_mmio.v', '/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0511e849-df80-4dfc-bb15-c5bf235318a2/c6b04ba6-b344-408b-a3af-6f1adca450aa/system/digital/rtl/aero_req_packer.v', '/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0511e849-df80-4dfc-bb15-c5bf235318a2/c6b04ba6-b344-408b-a3af-6f1adca450aa/system/digital/rtl/aero_rsp_unpacker.v', '/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0511e849-df80-4dfc-bb15-c5bf235318a2/c6b04ba6-b344-408b-a3af-6f1adca450aa/system/digital/rtl/aero_req_rsp_fifo_bram.v', '/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0511e849-df80-4dfc-bb15-c5bf235318a2/c6b04ba6-b344-408b-a3af-6f1adca450aa/system/digital/rtl/aero_safety_supervisor.v', '/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0511e849-df80-4dfc-bb15-c5bf235318a2/c6b04ba6-b344-408b-a3af-6f1adca450aa/system/digital/rtl/aero_seq_timeout_monitor.v', '/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0511e849-df80-4dfc-bb15-c5bf235318a2/c6b04ba6-b344-408b-a3af-6f1adca450aa/system/digital/rtl/adaptive_aero_control_top.v']`
- `cocotb_makefile_path` → `firmware/validate/Makefile`
- `cocotb_test_paths` → `['firmware/validate/test_firmware_smoke.py']`
- `validation_report_path` → `firmware/validate/validation_report.md`

## Key assumptions

- system_integration_intent_missing

## Risks / Gaps

- (none recorded)

## Next system software steps

- Consume `system_software_handoff.json` as the primary machine-readable input.
- Build the public system software package against the register map, HAL, and driver contract rather than scraping raw artifacts.
- Treat placeholder ELF as non-executable for runtime validation even if the file path exists.
- Use the runtime/simulation contract only for validation stages, not as part of the software build itself.
