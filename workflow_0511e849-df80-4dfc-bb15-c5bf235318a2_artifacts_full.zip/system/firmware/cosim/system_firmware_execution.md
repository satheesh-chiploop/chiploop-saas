# System Firmware CoSim Execution Summary

- Generated at: 2026-09-16T17:43:28.533376
- Execution mode: runtime_execution
- Overall status: simulation_passed
- Readiness: ready

## Key Inputs

- SoC top: `digital/rtl/adaptive_aero_control_top.v`
- Firmware ELF: `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0511e849-df80-4dfc-bb15-c5bf235318a2/c6b04ba6-b344-408b-a3af-6f1adca450aa/system/firmware/esp_idf/build/chiploop_fpga_host.elf`
- Cocotb Makefile: `firmware/validate/Makefile`
- Test files: `1`
- Verilog/SystemVerilog files: `14`

## Planned Test Matrix

- test_firmware_smoke.py | seed=1 | status=passed
- test_firmware_smoke.py | seed=2 | status=planned

## Notes

- Runtime execution was requested and attempted with the discovered cocotb collateral.
- No coverage model detected; downstream summary should avoid reporting functional coverage percentages.
- No digital assertions collateral detected; assertion coverage should remain unavailable, not fabricated.
- Firmware ELF was detected for firmware-aware co-simulation.

## Conclusion

Runtime execution completed successfully with the discovered co-simulation collateral.
