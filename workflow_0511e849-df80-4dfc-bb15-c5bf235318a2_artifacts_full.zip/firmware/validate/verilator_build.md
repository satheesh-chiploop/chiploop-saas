<!-- ASSUMPTION: Replace placeholders with concrete file paths before execution. -->
<!-- ASSUMPTION: Cocotb integration is driven externally through pytest/cocotb makefile flow. -->

# Verilator Build Plan

## Inputs
- RTL top module: adaptive_aero_control_top
- RTL filelist: artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0511e849-df80-4dfc-bb15-c5bf235318a2/c6b04ba6-b344-408b-a3af-6f1adca450aa/system/system/integration/system_rtl_filelist_sim.txt
- Optional include flags: <OPTIONAL_INCLUDE_FLAGS>
- Optional define flags: <OPTIONAL_DEFINE_FLAGS>
- Cocotb Python test/harness: firmware/validate/cocotb_harness.py

## Deterministic command template

verilator -cc --build --trace --top-module adaptive_aero_control_top \
  -f artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0511e849-df80-4dfc-bb15-c5bf235318a2/c6b04ba6-b344-408b-a3af-6f1adca450aa/system/system/integration/system_rtl_filelist_sim.txt \
  <OPTIONAL_INCLUDE_FLAGS> \
  <OPTIONAL_DEFINE_FLAGS> \
  

## Expected outputs
- Build directory: obj_dir/
- Generated make/build products under: obj_dir/
- Runnable binary name: obj_dir/Vadaptive_aero_control_top

## Notes
- Python cocotb tests are executed via pytest or cocotb makefile flow.
- Do not pass Python files to --exe.
- If firmware/ELF integration is needed, handle it via simulator memory preload or cocotb hooks.
