#!/usr/bin/env bash
set -euo pipefail

RTL_TOP="${RTL_TOP:-<RTL_TOP>}"
RTL_DIR="${RTL_DIR:-<RTL_DIR>}"
FILELIST="${FILELIST:-<FILELIST>}"
FW_DIR="${FW_DIR:-.}"
SIM_BUILD_DIR="${SIM_BUILD_DIR:-firmware/validate/build}"
COSIM_OUT_DIR="${COSIM_OUT_DIR:-firmware/validate}"
VERILATOR_BUILD_GUIDE="${VERILATOR_BUILD_GUIDE:-firmware/validate/verilator_build.md}"

mkdir -p "$SIM_BUILD_DIR" "$COSIM_OUT_DIR"

if [[ -f "$VERILATOR_BUILD_GUIDE" ]]; then
  echo "Using repository Verilator build guide: $VERILATOR_BUILD_GUIDE"
  echo "Please follow the repository-specific commands in that guide."
else
  echo "No repository Verilator build guide found at $VERILATOR_BUILD_GUIDE"
fi

if [[ "$FW_DIR" != "." && -d "$FW_DIR" ]]; then
  echo "Building firmware in $FW_DIR"
  (cd "$FW_DIR" && idf.py build)
else
  echo "FW_DIR not set to a valid directory; skipping firmware build"
fi

export PYTHONPATH="${PYTHONPATH:-}:$(pwd)"
export COCOTB_RESULTS_FILE="$COSIM_OUT_DIR/results.xml"
export JUNITXML="$COSIM_OUT_DIR/junit.xml"

if [[ -n "$FILELIST" && "$FILELIST" != "<FILELIST>" ]]; then
  echo "RTL_TOP=$RTL_TOP"
  echo "RTL_DIR=$RTL_DIR"
  echo "FILELIST=$FILELIST"
else
  echo "RTL_TOP=$RTL_TOP"
  echo "RTL_DIR=$RTL_DIR"
  echo "No FILELIST provided"
fi

pytest -q firmware/validate -k cosim --junitxml="$COSIM_OUT_DIR/junit.xml" "$@"
