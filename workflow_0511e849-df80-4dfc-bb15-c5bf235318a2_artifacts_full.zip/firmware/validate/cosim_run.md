<!-- ASSUMPTION: RTL_TOP, RTL_DIR, and FILELIST are supplied by the build environment or CI job configuration.
<!-- ASSUMPTION: The cocotb test module and any Python helpers are discoverable via PYTHONPATH/pytest defaults.
<!-- ASSUMPTION: If firmware artifacts are required, the ESP-IDF project root is available via FW_DIR or the repository root.
<!-- ASSUMPTION: Verilator-based RTL simulation is the intended co-simulation backend. -->

# Co-simulation runner

## Prerequisites

- Verilator
- Python 3
- pytest
- cocotb
- ESP-IDF toolchain, if building firmware artifacts is required for the test flow

Recommended Python packages:
- cocotb
- pytest
- pytest-xdist optional

## Environment variables

- `RTL_TOP` : top-level RTL module name
- `RTL_DIR` : RTL source directory
- `FILELIST` : optional filelist for RTL compilation
- `FW_DIR` : firmware project directory, if different from repository root
- `SIM_BUILD_DIR` : build output directory for simulation artifacts
- `COSIM_OUT_DIR` : output directory for logs and reports

## Build and run commands

### 1) Build RTL simulation with Verilator

If a repository-provided build guide exists, follow it first:
- `firmware/validate/verilator_build.md` if present

Otherwise, use a generic Verilator flow:

- `mkdir -p firmware/validate/build`
- `verilator --cc --exe --build -Mdir firmware/validate/build -top-module "$RTL_TOP" ...`

If a filelist is provided:
- `verilator --cc --exe --build -Mdir firmware/validate/build -top-module "$RTL_TOP" -f "$FILELIST" ...`

If the cocotb integration uses a Makefile or simulator wrapper, invoke that instead of a direct Verilator command.

### 2) Build firmware, if applicable

If the firmware under test must be rebuilt:
- `idf.py -C "$FW_DIR" build`

If no firmware rebuild is needed, this step may be skipped and existing firmware artifacts may be used.

### 3) Run cocotb via pytest

Run the Python test entrypoint with pytest:

- `pytest -q firmware/validate -k cosim --junitxml=firmware/validate/junit.xml`

If the cocotb test is located elsewhere, keep the invocation equivalent and ensure it is pointed at the correct test module.

## Expected outputs

After a successful run, expect:

- Simulation logs under `firmware/validate/`
- A pytest summary on stdout
- Optional JUnit report:
  - `firmware/validate/junit.xml`
- Optional Verilator build artifacts:
  - `firmware/validate/build/`
- Optional coverage artifacts if enabled:
  - `firmware/validate/*.gcda`
  - `firmware/validate/*.gcno`
  - `firmware/validate/coverage/`

Expected indicators of success:
- pytest exits with code 0
- cocotb reports pass for the selected test(s)
- any generated logs show the DUT elaborated and the test completed without assertion failures
