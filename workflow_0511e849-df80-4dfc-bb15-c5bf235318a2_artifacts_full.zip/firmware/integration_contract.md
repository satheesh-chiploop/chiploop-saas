# Firmware Integration Contract

## 1) Contract overview
- Target platform: `ulx3s_ecp5_45f_esp32`, architecture `fpga_onboard_cpu`, host MCU `esp32_xtensa_lx6`, firmware platform `esp-idf`.
- Transport: SPI register interface, mode 0, MSB-first, max 10 MHz, 28-byte full-duplex frames.
- Scope: embedded firmware integration for `physical_ai_product` using the approved partition and existing RTL register collateral.
- Device-layer jobs: none specified. Interfaces: none beyond the SPI transport contract.
- Platform contract gate status: ready for portable source and deployable binary, but no deployable artifact is claimed here.
- Command/response timing model: command frame `N` is committed on CS rising edge; response for command `N` is read in frame `N+2`.
- Firmware must treat the transport as a fixed-width framed protocol with leading padding and trailing padding bits; byte order and bit packing are part of the contract.
- Logging, error handling, and version reporting are part of the integration boundary and must remain stable across compatible revisions.

## 2) Contract version + compatibility policy
**Contract version:** `chiploop.application_intelligence.firmware_integration_contract.v1`

**Compatibility policy:**
- Minor changes may add fields, status codes, or non-breaking validation hooks.
- Bit placement, frame size, SPI mode, clock limit, and response latency are **breaking-contract** properties and require a major version bump.
- Firmware and host software must reject mismatched major versions.
- If `transport_contract` metadata and RTL collateral disagree, RTL collateral takes precedence for implemented register behavior; metadata is the binding contract for firmware framing.
- Source-level compatibility is required across `esp-idf` updates within the same major contract version, subject to board support.

## 3) Interfaces

### 3.1 Transport interface
| Field | Value | Notes |
|---|---:|---|
| Transport | SPI | `spi_mode_0_shift_transport` |
| Controller | ESP32 | `esp32` |
| Peripheral | FPGA | `fpga` |
| SPI mode | 0 | CPOL=0, CPHA=0 |
| Frame size | 224 bits | 28 bytes |
| Byte order | MSB-first | Full-duplex |
| Max clock | 10 MHz | Do not exceed |
| Min interframe delay | 1 us | Between CS deassert and next transaction |
| Response latency | 2 frames | Response for command `N` appears in frame `N+2` |
| Leading padding | 12 bits | Command-leading padding |
| Trailing padding | 4 bits | Response-trailing padding |

### 3.2 Input bit map
| LSB | Width | Port |
|---:|---:|---|
| 0 | 8 | `cfg_bus_addr` |
| 8 | 64 | `cfg_bus_wdata` |
| 72 | 1 | `cfg_bus_valid` |
| 73 | 1 | `cfg_bus_write` |
| 74 | 1 | `req_ready` |
| 75 | 128 | `rsp_data` |
| 203 | 1 | `rsp_valid` |
| 204 | 8 | `seq_next` |

### 3.3 Output bit map
| LSB | Width | Port |
|---:|---:|---|
| 0 | 8 | `fault_out` |
| 8 | 16 | `act_cmd` |
| 24 | 1 | `rsp_ready` |
| 25 | 1 | `req_valid` |
| 26 | 128 | `req_data` |
| 154 | 1 | `cfg_bus_rvalid` |
| 155 | 1 | `cfg_bus_ready` |
| 156 | 64 | `cfg_bus_rdata` |

### 3.4 Firmware API contract
| API | Direction | Behavior |
|---|---|---|
| `spi_transport_init()` | FW internal | Configure SPI peripheral for mode 0, MSB-first, 10 MHz max, GPIO mapping per target refinement |
| `spi_frame_txrx(frame_out, frame_in)` | FW internal | Execute one 28-byte full-duplex frame with correct CS framing and interframe delay |
| `cfg_write(addr, wdata)` | Host-visible via FW | Emit config write transaction using `cfg_bus_*` fields |
| `cfg_read(addr)` | Host-visible via FW | Emit config read transaction and return `cfg_bus_rdata` when valid |
| `poll_status()` | Host-visible via FW | Read `fault_out`, `act_cmd`, `rsp_ready`, `req_valid`, `cfg_bus_ready`, `cfg_bus_rvalid` |
| `get_version()` | Host-visible via FW | Return contract version and firmware build identifier |

### 3.5 Error model
| Code | Meaning | Handling |
|---|---|---|
| `0x00` | OK | No fault |
| `0x01` | SPI framing error | Retry only if transaction is idempotent |
| `0x02` | Timeout / no response | Report to host; do not assume write completion |
| `0x03` | Unsupported register access | Host bug or RTL mismatch |
| `0x04` | Version mismatch | Refuse operation |
| `0x05` | Busy / not ready | Backoff and retry |
| `0x06` | Internal firmware fault | Halt affected service path |

### 3.6 Logging schema
| Field | Type | Requirement |
|---|---|---|
| `ts_us` | integer | Required |
| `level` | string | Required |
| `subsystem` | string | Required |
| `event` | string | Required |
| `code` | integer | Required for errors |
| `seq` | integer | Required for transport transactions |
| `addr` | integer | Required for config accesses |
| `detail` | string | Optional |

Minimum events:
- `boot.start`
- `boot.spi_init`
- `boot.contract_ok`
- `boot.contract_mismatch`
- `spi.tx`
- `spi.rx`
- `cfg.write`
- `cfg.read`
- `fault.report`
- `version.report`

## 4) Ownership boundaries

| Area | Firmware | System/Host | Validation |
|---|---|---|---|
| SPI pinmux, timing, frame packing | Owns | Consumes contract | Verifies on hardware |
| Register access sequencing | Owns transport execution | Requests operations | Confirms protocol compliance |
| Version reporting | Owns emitted values | Checks compatibility | Gates release |
| Error code interpretation | Emits and documents | Handles recovery policy | Exercises fault paths |
| Logging format | Owns emission | Parses and stores | Validates schema |
| Board bring-up assumptions | Owns only firmware-side setup | Provides target selection | Confirms board-specific behavior |
| Register semantic correctness | Mirrors RTL collateral | Consumes API | Cross-checks against RTL |

## 5) Assumptions
- ESP-IDF is the firmware build system and runtime platform.
- SPI GPIO assignment is fixed as: SCLK `14`, CS_N `13`, MOSI `15`, MISO `2`.
- The frame contract is authoritative for framing, padding, and latency behavior.
- The integration wrapper is ready and soft CPU support is available.
- No device-layer jobs or additional external interfaces are defined in scope.
- The firmware will not claim deployability beyond the platform contract gate and target collateral alignment.
- RTL register collateral is available and is the source of register semantics.

## 6) Validation hooks
- Verify SPI mode 0 on a logic analyzer: CPOL low, CPHA low, MSB-first shifting, CS framing per transaction.
- Confirm frame width is exactly 28 bytes and that leading/trailing padding bits are preserved.
- Run loopback or FPGA-backed transaction tests to ensure command `N` is observed to commit on CS rise and response `N+2` is returned in the specified frame.
- Validate max clock enforcement by testing operation at and below 10 MHz and rejecting higher configuration.
- Confirm interframe delay of at least 1 us between transactions.
- Cross-check `cfg_bus_*`, `req_*`, `rsp_*`, `act_cmd`, and `fault_out` bit positions against RTL-generated waveforms.
- Exercise read/write paths and confirm `cfg_bus_ready`, `cfg_bus_rvalid`, and `cfg_bus_rdata` semantics under expected and error cases.
- Validate version handshake: firmware must reject incompatible major versions and log `boot.contract_mismatch`.
- Confirm logging schema fields are emitted for boot, transaction, and fault events.
- Run negative tests for unsupported address access, timeout, and busy conditions to confirm error code mapping.