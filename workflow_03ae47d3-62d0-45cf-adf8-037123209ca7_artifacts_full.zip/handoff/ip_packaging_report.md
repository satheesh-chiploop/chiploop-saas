# IP Packaging & Handoff Report

- Top: `sram_mbist_demo_controller`
- Package: `backend/workflows/03ae47d3-62d0-45cf-adf8-037123209ca7/handoff/sram_mbist_demo_controller_ip_package`
- Zip: `backend/workflows/03ae47d3-62d0-45cf-adf8-037123209ca7/handoff/sram_mbist_demo_controller_ip_package.zip`

## Bucket counts
- **rtl**: 36
- **spec**: 3
- **arch**: 1
- **microarch**: 1
- **regmap**: 2
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 11
