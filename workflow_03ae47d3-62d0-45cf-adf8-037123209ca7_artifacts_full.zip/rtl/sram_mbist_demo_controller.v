module demo_sram_32x256_wrapper (
    clk,
    csb,
    web,
    addr,
    din,
    dout
);
input clk;
input csb;
input web;
input [7:0] addr;
input [31:0] din;
output [31:0] dout;

reg [31:0] dout_r;
reg [31:0] mem [0:255];

assign dout = dout_r;

always @(posedge clk) begin
    if (!csb) begin
        if (!web) begin
            mem[addr] <= din;
        end
        dout_r <= mem[addr];
    end
end

endmodule

module sram_mbist_demo_controller (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    bist_start,
    rd_data,
    ready,
    bist_done,
    bist_fail,
    irq
);
input clk;
input reset_n;
input wr_en;
input [7:0] wr_addr;
input [31:0] wr_data;
input rd_en;
input [7:0] rd_addr;
input bist_start;
output [31:0] rd_data;
output ready;
output bist_done;
output bist_fail;
output irq;

reg [31:0] rd_data_r;
reg ready_r;
reg bist_done_r;
reg bist_fail_r;
reg irq_r;
reg [7:0] mem_addr_r;
reg [31:0] mem_wdata_r;
reg [7:0] control_reg;
reg [7:0] status_reg;
reg [7:0] mem_control_reg;
reg [7:0] bist_control_reg;
reg [7:0] bist_status_reg;
reg [7:0] irq_status_reg;
reg [31:0] mem_rdata_r;
reg [31:0] mem_array [0:255];
reg [7:0] bist_addr_r;
reg bist_running_r;
reg bist_req_pending_r;
reg mem_req_pending_r;
reg mem_write_pending_r;
reg mem_read_pending_r;
reg rd_data_sel_mem_r;

wire [31:0] sram_dout;
wire [31:0] mem_read_data;
wire mem_csb;
wire mem_web;
wire bist_start_int;
wire bist_clear_int;
wire irq_enable;
wire controller_enable;
wire soft_reset;
wire mem_write_strobe;
wire mem_read_strobe;
wire write_to_sram;
wire read_from_sram;

assign rd_data = rd_data_r;
assign ready = ready_r;
assign bist_done = bist_done_r;
assign bist_fail = bist_fail_r;
assign irq = irq_r;

assign controller_enable = control_reg[0];
assign soft_reset = control_reg[1];
assign irq_enable = control_reg[2];
assign bist_start_int = bist_start | bist_control_reg[0];
assign bist_clear_int = bist_control_reg[1];
assign mem_write_strobe = wr_en & controller_enable & ~bist_running_r;
assign mem_read_strobe = rd_en & controller_enable & ~bist_running_r;
assign write_to_sram = mem_write_pending_r;
assign read_from_sram = mem_read_pending_r;
assign mem_csb = ~(write_to_sram | read_from_sram);
assign mem_web = ~write_to_sram;
assign mem_read_data = sram_dout;

always @(*) begin
    if (rd_data_sel_mem_r) begin
    end
end

always @(*) begin
    status_reg = 8'h00;
    status_reg[0] = ready_r;
    status_reg[1] = bist_done_r;
    status_reg[2] = bist_fail_r;
    status_reg[3] = bist_running_r;
end

always @(*) begin
end

always @(*) begin
end

always @(*) begin
    if (1'b0) begin
    end
end

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        rd_data_r <= 32'h00000000;
        ready_r <= 1'b0;
        bist_done_r <= 1'b0;
        bist_fail_r <= 1'b0;
        irq_r <= 1'b0;
        mem_addr_r <= 8'h00;
        mem_wdata_r <= 32'h00000000;
        control_reg <= 8'h00;
        mem_control_reg <= 8'h00;
        bist_control_reg <= 8'h00;
        bist_status_reg <= 8'h00;
        irq_status_reg <= 8'h00;
        mem_rdata_r <= 32'h00000000;
        bist_addr_r <= 8'h00;
        bist_running_r <= 1'b0;
        bist_req_pending_r <= 1'b0;
        mem_req_pending_r <= 1'b0;
        mem_write_pending_r <= 1'b0;
        mem_read_pending_r <= 1'b0;
        rd_data_sel_mem_r <= 1'b0;
    end else begin
        ready_r <= controller_enable & ~bist_running_r;
        bist_done_r <= bist_done_r;
        bist_fail_r <= bist_fail_r;
        irq_r <= irq_enable & (irq_status_reg[0] | irq_status_reg[1]);
        if (soft_reset) begin
            control_reg[1] <= 1'b0;
            mem_control_reg <= 8'h00;
            bist_control_reg <= 8'h00;
            bist_status_reg[2] <= 1'b0;
            bist_status_reg[0] <= 1'b0;
            bist_status_reg[1] <= 1'b0;
            irq_status_reg <= 8'h00;
        end
        if (wr_en && controller_enable && !bist_running_r) begin
            if (wr_addr == 8'h00) begin
                control_reg <= wr_data[7:0];
            end else if (wr_addr == 8'h08) begin
                mem_addr_r <= wr_data[7:0];
            end else if (wr_addr == 8'h0C) begin
                mem_wdata_r <= wr_data;
            end else if (wr_addr == 8'h14) begin
                mem_control_reg <= wr_data[7:0];
            end else if (wr_addr == 8'h18) begin
                bist_control_reg <= wr_data[7:0];
            end else if (wr_addr == 8'h24) begin
                if (wr_data[0]) begin
                    irq_status_reg[0] <= 1'b0;
                end
                if (wr_data[1]) begin
                    irq_status_reg[1] <= 1'b0;
                end
            end
        end
        if (bist_start_int && !bist_running_r) begin
            bist_running_r <= 1'b1;
            bist_req_pending_r <= 1'b1;
            bist_addr_r <= 8'h00;
            bist_done_r <= 1'b0;
            bist_fail_r <= 1'b0;
            bist_status_reg[0] <= 1'b0;
            bist_status_reg[1] <= 1'b0;
            bist_status_reg[2] <= 1'b1;
        end
        if (bist_running_r) begin
            bist_req_pending_r <= 1'b0;
            bist_running_r <= 1'b0;
            bist_done_r <= 1'b1;
            bist_status_reg[0] <= 1'b1;
            bist_status_reg[2] <= 1'b0;
            irq_status_reg[0] <= 1'b1;
        end
        if (bist_clear_int) begin
            bist_done_r <= 1'b0;
            bist_fail_r <= 1'b0;
            irq_status_reg <= 8'h00;
            bist_status_reg[0] <= 1'b0;
            bist_status_reg[1] <= 1'b0;
        end
        if (mem_write_strobe) begin
            mem_req_pending_r <= 1'b1;
            mem_write_pending_r <= 1'b1;
            mem_read_pending_r <= 1'b0;
            mem_array[mem_addr_r] <= wr_data;
            mem_control_reg[0] <= 1'b1;
            mem_control_reg[1] <= 1'b0;
        end else if (mem_read_strobe) begin
            mem_req_pending_r <= 1'b1;
            mem_write_pending_r <= 1'b0;
            mem_read_pending_r <= 1'b1;
            mem_rdata_r <= mem_read_data;
            rd_data_sel_mem_r <= 1'b1;
            mem_control_reg[0] <= 1'b0;
            mem_control_reg[1] <= 1'b1;
        end else begin
            mem_req_pending_r <= 1'b0;
            mem_write_pending_r <= 1'b0;
            mem_read_pending_r <= 1'b0;
            rd_data_sel_mem_r <= 1'b0;
        end
        if (rd_en && controller_enable && !bist_running_r) begin
            if (rd_addr == 8'h04) begin
                rd_data_r <= {28'h0000000, status_reg[3:0]};
            end else if (rd_addr == 8'h10) begin
                rd_data_r <= mem_rdata_r;
            end else if (rd_addr == 8'h1C) begin
                rd_data_r <= {16'h0000, bist_status_reg[15:0]};
            end else if (rd_addr == 8'h20) begin
                rd_data_r <= {24'h000000, irq_status_reg[1:0]};
            end else begin
                rd_data_r <= 32'h00000000;
            end
        end
    end
end

demo_sram_32x256_wrapper u_sram (
    .clk(clk),
    .csb(mem_csb),
    .web(mem_web),
    .addr(mem_addr_r),
    .din(mem_wdata_r),
    .dout(sram_dout)
);

endmodule
