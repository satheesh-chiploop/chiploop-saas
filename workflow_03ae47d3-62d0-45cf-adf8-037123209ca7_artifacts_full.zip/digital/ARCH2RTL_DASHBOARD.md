# Arch2RTL Evidence Dashboard

- Lint: warnings
- Flip-flops: 16595
- Latches: 0
- Full-cycle paths: 3
- Half-cycle paths: 8
- Input bits: 53
- Output bits: 36
- Input ports: 8
- Output ports: 5
- Clock: clk
- Reset: reset_n
- Modules: 14
- RTL files: 13
