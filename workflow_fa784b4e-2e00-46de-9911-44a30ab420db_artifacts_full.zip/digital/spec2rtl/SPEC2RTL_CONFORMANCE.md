# Spec-to-RTL Conformance Report

Status: **partial**

- Requirements checked: 84
- Matched: 83
- Partial: 0
- Missing: 1
- Inconclusive: 0
- Interface: pass
- Register map: pass
- Clock/reset: pass

## Missing Or Partial Requirements
- REQ-022 [missing]: IRQ_CLEAR bit 1 clears IRQ_STATUS.sample_done and STATUS.sample_done.
