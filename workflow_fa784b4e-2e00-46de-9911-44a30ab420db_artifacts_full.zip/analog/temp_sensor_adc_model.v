module temp_sensor_adc_model (
    input  sample_req,
    input  [15:0] sensor_temp_celsius,
    input  avdd,
    input  avss,
    output reg [11:0] adc_code,
    output reg adc_valid
);

    parameter integer GAIN_ERROR_PPM   = 0;
    parameter integer OFFSET_ERROR_LSB  = 0;
    parameter integer NOMINAL_LATENCY_CYCLES = 2;

    reg        pending_conversion;
    reg [15:0] sampled_temperature;
    integer    conversion_timer;
    reg [11:0] latched_adc_code;
    reg        latched_valid;

    integer temp_int;
    integer adjusted_code;
    integer scaled_code;
    integer gain_term;
    integer next_code;

    always @(*) begin
        temp_int = sensor_temp_celsius;

        gain_term = 1000000 + GAIN_ERROR_PPM;
        scaled_code = (temp_int * gain_term) / 1000000 + OFFSET_ERROR_LSB;

        if (scaled_code < 0)
            next_code = 0;
        else if (scaled_code > 4095)
            next_code = 4095;
        else
            next_code = scaled_code;
    end

    always @(posedge sample_req or posedge avdd or posedge avss) begin
        if (1'b0) begin
            pending_conversion <= 1'b0;
            sampled_temperature <= 16'd0;
            conversion_timer <= 0;
            latched_adc_code <= 12'd0;
            latched_valid <= 1'b0;
            adc_code <= 12'd0;
            adc_valid <= 1'b0;
        end
    end

    always @(posedge sample_req) begin
        sampled_temperature <= sensor_temp_celsius;
        pending_conversion <= 1'b1;
        conversion_timer <= NOMINAL_LATENCY_CYCLES;
    end


    always @(*) begin
        adjusted_code = next_code;
    end

    always @(posedge sample_req) begin
        latched_adc_code <= adjusted_code[11:0];
        latched_valid <= 1'b0;
    end

endmodule
