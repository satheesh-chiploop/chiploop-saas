module temp_monitor_digital_regfile (
    input         clk,
    input         reset_n,
    input         wr_en,
    input  [7:0] wr_addr,
    input  [15:0] wr_data,
    input         rd_en,
    input  [7:0] rd_addr,
    input         adc_valid,
    input  [11:0] adc_code,
    input         sample_req_pulse,
    input  [11:0] filtered_temp_code,
    input         sample_done_pulse,
    input         alert_condition,
    input  [1:0] irq_clear_pulse,
    input         alert_clear_pulse,
    output reg [15:0] rd_data,
    output reg        control_enable,
    output reg        control_irq_enable,
    output reg        control_sample_start_pulse,
    output reg        control_alert_clear_pulse,
    output reg [11:0] threshold_code,
    output reg [11:0] latest_temp,
    input  [15:0] sample_count,
    input         irq_status_alert,
    input         irq_status_sample_done,
    input         status_sample_done,
    input         status_alert_pending,
    input         status_adc_valid_seen,
    input         status_busy,
    input         alert_status
);

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        control_enable <= 1'b0;
        control_irq_enable <= 1'b0;
        control_sample_start_pulse <= 1'b0;
        control_alert_clear_pulse <= 1'b0;
        threshold_code <= 12'b0;
        latest_temp <= 12'b0;
        rd_data <= 16'b0;
    end else begin
        control_sample_start_pulse <= 1'b0;
        control_alert_clear_pulse <= 1'b0;
        if (wr_en) begin
            case (wr_addr)
                8'h00: begin
                    control_enable <= wr_data[0];
                    control_irq_enable <= wr_data[2];
                    control_sample_start_pulse <= wr_data[1];
                    control_alert_clear_pulse <= wr_data[3];
                end
                8'h08: begin
                    threshold_code <= wr_data[11:0];
                end
                default: begin
                end
            endcase
        end
        latest_temp <= filtered_temp_code;
        if (rd_en) begin
            case (rd_addr)
                8'h00: rd_data <= {12'b0, control_alert_clear_pulse, control_irq_enable, control_sample_start_pulse, control_enable};
                8'h04: rd_data <= {12'b0, status_busy, status_adc_valid_seen, status_alert_pending, status_sample_done};
                8'h08: rd_data <= {4'b0, threshold_code};
                8'h0C: rd_data <= {4'b0, latest_temp};
                8'h10: rd_data <= sample_count;
                8'h14: rd_data <= {14'b0, irq_status_sample_done, irq_status_alert};
                8'h18: rd_data <= 16'b0;
                default: rd_data <= 16'b0;
            endcase
        end else begin
            rd_data <= 16'b0;
        end
    end
end

endmodule
