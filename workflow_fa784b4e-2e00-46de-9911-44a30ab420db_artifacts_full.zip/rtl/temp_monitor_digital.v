module temp_monitor_digital (
    input         clk,
    input         reset_n,
    input         wr_en,
    input  [7:0] wr_addr,
    input  [15:0] wr_data,
    input         rd_en,
    input  [7:0] rd_addr,
    input  [11:0] adc_code,
    input         adc_valid,
    output [15:0] rd_data,
    output        sample_req,
    output        alert_irq,
    output [11:0] temp_code,
    output [11:0] threshold_code,
    output        alert_status
);

wire        control_enable;
wire        control_irq_enable;
wire        control_sample_start_pulse;
wire        control_alert_clear_pulse;
wire [11:0] threshold_code_w;
wire [11:0] latest_temp;
wire [15:0] sample_count;
wire        adc_valid_seen;
wire        sample_done_pulse;
wire        alert_condition;
wire        busy;
wire        irq_status_alert;
wire        irq_status_sample_done;
wire        status_sample_done;
wire        status_alert_pending;

wire [11:0] latest_temp_unused_from_u_regfile_latest_temp;
assign threshold_code = threshold_code_w;
assign temp_code      = latest_temp;
assign sample_req     = control_sample_start_pulse;

temp_monitor_digital_regfile u_regfile (
    .clk                      (clk),
    .reset_n                  (reset_n),
    .wr_en                    (wr_en),
    .wr_addr                  (wr_addr),
    .wr_data                  (wr_data),
    .rd_en                    (rd_en),
    .rd_addr                  (rd_addr),
    .adc_valid                (adc_valid),
    .adc_code                 (adc_code),
    .sample_req_pulse         (sample_req),
    .filtered_temp_code       (latest_temp),
    .sample_done_pulse        (sample_done_pulse),
    .alert_condition          (alert_condition),
    .irq_clear_pulse          (2'b00),
    .alert_clear_pulse        (control_alert_clear_pulse),
    .rd_data                  (rd_data),
    .control_enable           (control_enable),
    .control_irq_enable       (control_irq_enable),
    .control_sample_start_pulse(control_sample_start_pulse),
    .control_alert_clear_pulse (control_alert_clear_pulse),
    .threshold_code           (threshold_code_w),
    .latest_temp              (latest_temp_unused_from_u_regfile_latest_temp),
    .sample_count             (sample_count),
    .irq_status_alert         (irq_status_alert),
    .irq_status_sample_done   (irq_status_sample_done),
    .status_sample_done       (status_sample_done),
    .status_alert_pending     (status_alert_pending),
    .status_adc_valid_seen    (adc_valid_seen),
    .status_busy              (busy),
    .alert_status             (alert_status)
);

temp_monitor_digital_sample_filter u_sample_filter (
    .clk              (clk),
    .reset_n          (reset_n),
    .adc_code         (adc_code),
    .adc_valid        (adc_valid),
    .threshold_code   (threshold_code_w),
    .sample_req       (sample_req),
    .latest_temp      (latest_temp),
    .sample_count     (sample_count),
    .adc_valid_seen   (adc_valid_seen),
    .sample_done_pulse (sample_done_pulse),
    .alert_condition  (alert_condition),
    .busy             (busy)
);

temp_monitor_digital_irq_ctrl u_irq_ctrl (
    .clk                    (clk),
    .reset_n                (reset_n),
    .irq_enable             (control_irq_enable),
    .alert_condition        (alert_condition),
    .sample_done_pulse      (sample_done_pulse),
    .alert_clear_pulse      (control_alert_clear_pulse),
    .irq_clear_pulse        (2'b00),
    .alert_status           (alert_status),
    .irq_status_alert       (irq_status_alert),
    .irq_status_sample_done (irq_status_sample_done),
    .status_alert_pending   (status_alert_pending),
    .status_sample_done     (status_sample_done),
    .alert_irq              (alert_irq)
);

endmodule
