module temp_monitor_digital_irq_ctrl (
    input         clk,
    input         reset_n,
    input         irq_enable,
    input         alert_condition,
    input         sample_done_pulse,
    input         alert_clear_pulse,
    input  [1:0] irq_clear_pulse,
    output reg    alert_status,
    output reg    irq_status_alert,
    output reg    irq_status_sample_done,
    output reg    status_alert_pending,
    output reg    status_sample_done,
    output reg    alert_irq
);

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        alert_status <= 1'b0;
        irq_status_alert <= 1'b0;
        irq_status_sample_done <= 1'b0;
        status_alert_pending <= 1'b0;
        status_sample_done <= 1'b0;
        alert_irq <= 1'b0;
    end else begin
        if (alert_condition) begin
            alert_status <= 1'b1;
            irq_status_alert <= 1'b1;
            status_alert_pending <= 1'b1;
        end
        if (sample_done_pulse) begin
            irq_status_sample_done <= 1'b1;
            status_sample_done <= 1'b1;
        end
        if (alert_clear_pulse || irq_clear_pulse[0]) begin
            alert_status <= 1'b0;
            irq_status_alert <= 1'b0;
            status_alert_pending <= 1'b0;
        end
        if (irq_clear_pulse[1]) begin
            irq_status_sample_done <= 1'b0;
            status_sample_done <= 1'b0;
        end
        alert_irq <= irq_enable & (irq_status_alert | irq_status_sample_done);
    end
end

endmodule
