module temp_monitor_digital_sample_filter (
    input         clk,
    input         reset_n,
    input  [11:0] adc_code,
    input         adc_valid,
    input  [11:0] threshold_code,
    input         sample_req,
    output reg [11:0] latest_temp,
    output reg [15:0] sample_count,
    output reg        adc_valid_seen,
    output reg        sample_done_pulse,
    output reg        alert_condition,
    output reg        busy
);

reg [11:0] prev_sample;
reg [11:0] current_sample;
reg        pending_req;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        prev_sample <= 12'b0;
        current_sample <= 12'b0;
        latest_temp <= 12'b0;
        sample_count <= 16'b0;
        adc_valid_seen <= 1'b0;
        sample_done_pulse <= 1'b0;
        alert_condition <= 1'b0;
        busy <= 1'b0;
        pending_req <= 1'b0;
    end else begin
        sample_done_pulse <= 1'b0;
        if (sample_req)
            pending_req <= 1'b1;
        if (adc_valid) begin
            prev_sample <= current_sample;
            current_sample <= adc_code;
            latest_temp <= (adc_code + prev_sample) >> 1;
            sample_count <= sample_count + 16'd1;
            adc_valid_seen <= 1'b1;
            sample_done_pulse <= 1'b1;
            alert_condition <= (((adc_code + prev_sample) >> 1) > threshold_code);
            pending_req <= 1'b0;
        end
        busy <= pending_req;
    end
end

endmodule
