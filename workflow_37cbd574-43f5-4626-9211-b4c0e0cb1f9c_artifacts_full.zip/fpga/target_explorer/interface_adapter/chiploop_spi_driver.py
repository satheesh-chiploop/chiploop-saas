"""Generated ChipLoop SPI Mode-0 host transport.

Command N is committed when chip-select rises. The held response mailbox is
captured at the next frame commit, so response N is visible during frame N+2.
Callers must pipeline two exchanges or issue two explicit polling frames.
"""
from typing import Callable, Mapping

INPUT_BITS = 204
OUTPUT_BITS = 213
FRAME_BITS = 216
FRAME_BYTES = FRAME_BITS // 8
COMMAND_LEADING_PADDING_BITS = FRAME_BITS - INPUT_BITS
RESPONSE_TRAILING_PADDING_BITS = FRAME_BITS - OUTPUT_BITS
INPUT_MAP = [{'port': 'reg_addr', 'width': 8, 'lsb': 0}, {'port': 'reg_wdata', 'width': 64, 'lsb': 8}, {'port': 'reg_valid', 'width': 1, 'lsb': 72}, {'port': 'reg_write_en', 'width': 1, 'lsb': 73}, {'port': 'req_stream_ready', 'width': 1, 'lsb': 74}, {'port': 'resp_stream_valid', 'width': 1, 'lsb': 75}, {'port': 'resp_stream_data', 'width': 128, 'lsb': 76}]
OUTPUT_MAP = [{'port': 'reg_rdata', 'width': 64, 'lsb': 149}, {'port': 'reg_ready', 'width': 1, 'lsb': 148}, {'port': 'req_stream_valid', 'width': 1, 'lsb': 147}, {'port': 'req_stream_data', 'width': 128, 'lsb': 19}, {'port': 'resp_stream_ready', 'width': 1, 'lsb': 18}, {'port': 'actuator_cmd', 'width': 16, 'lsb': 2}, {'port': 'status_irq', 'width': 1, 'lsb': 1}, {'port': 'safe_mode', 'width': 1, 'lsb': 0}]

def _mask(width: int) -> int:
    return (1 << width) - 1

def pack_command(values: Mapping[str, int]) -> bytes:
    frame = 0
    for field in INPUT_MAP:
        value = int(values.get(field["port"], 0))
        if value < 0 or value > _mask(field["width"]):
            raise ValueError(f'{field["port"]} exceeds {field["width"]} bits')
        frame |= value << field["lsb"]
    return frame.to_bytes(FRAME_BYTES, "big")

def unpack_response(raw: bytes) -> dict[str, int]:
    if len(raw) != FRAME_BYTES:
        raise ValueError(f"expected {FRAME_BYTES} response bytes, got {len(raw)}")
    # Response bits leave the FPGA first and are followed by zero padding when
    # the command side determines a longer full-duplex frame.
    value = int.from_bytes(raw, "big") >> (FRAME_BYTES * 8 - OUTPUT_BITS)
    return {field["port"]: (value >> field["lsb"]) & _mask(field["width"]) for field in OUTPUT_MAP}

class ChipLoopSpiDevice:
    def __init__(self, transfer: Callable[[bytes], bytes]):
        self._transfer = transfer

    def exchange(self, values: Mapping[str, int]) -> dict[str, int]:
        response = self._transfer(pack_command(values))
        return unpack_response(response)
