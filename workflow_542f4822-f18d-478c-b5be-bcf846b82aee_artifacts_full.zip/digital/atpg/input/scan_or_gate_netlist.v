module pwm_controller (clk,
    pwm_out,
    rd_en,
    reset_n,
    scan_en,
    wr_en,
    counter_value,
    rd_addr,
    rd_data,
    scan_in,
    scan_out,
    wr_addr,
    wr_data);
 input clk;
 output pwm_out;
 input rd_en;
 input reset_n;
 input scan_en;
 input wr_en;
 output [7:0] counter_value;
 input [7:0] rd_addr;
 output [7:0] rd_data;
 input [3:0] scan_in;
 output [3:0] scan_out;
 input [7:0] wr_addr;
 input [7:0] wr_data;

 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire _086_;
 wire _087_;
 wire _088_;
 wire _089_;
 wire _090_;
 wire _091_;
 wire _092_;
 wire _093_;
 wire _094_;
 wire _095_;
 wire _096_;
 wire _097_;
 wire _098_;
 wire _099_;
 wire _100_;
 wire _101_;
 wire _102_;
 wire _103_;
 wire _104_;
 wire _105_;
 wire _106_;
 wire _107_;
 wire control_reg;
 wire \duty_cycle_reg[0] ;
 wire \duty_cycle_reg[1] ;
 wire \duty_cycle_reg[2] ;
 wire \duty_cycle_reg[3] ;
 wire \duty_cycle_reg[4] ;
 wire \duty_cycle_reg[5] ;
 wire \duty_cycle_reg[6] ;
 wire \duty_cycle_reg[7] ;
 wire \period_reg[0] ;
 wire \period_reg[1] ;
 wire \period_reg[2] ;
 wire \period_reg[3] ;
 wire \period_reg[4] ;
 wire \period_reg[5] ;
 wire \period_reg[6] ;
 wire \period_reg[7] ;

 sky130_fd_sc_hd__nand2_2 _108_ (.A(counter_value[1]),
    .B(counter_value[0]),
    .Y(_076_));
 sky130_fd_sc_hd__and4_2 _109_ (.A(_072_),
    .B(_074_),
    .C(_075_),
    .D(_076_),
    .X(_001_));
 sky130_fd_sc_hd__and3_2 _110_ (.A(counter_value[2]),
    .B(counter_value[1]),
    .C(counter_value[0]),
    .X(_077_));
 sky130_fd_sc_hd__a21o_2 _111_ (.A1(counter_value[1]),
    .A2(counter_value[0]),
    .B1(counter_value[2]),
    .X(_078_));
 sky130_fd_sc_hd__and4bb_2 _112_ (.A_N(_073_),
    .B_N(_077_),
    .C(_078_),
    .D(_074_),
    .X(_002_));
 sky130_fd_sc_hd__and4_2 _113_ (.A(counter_value[3]),
    .B(counter_value[2]),
    .C(counter_value[1]),
    .D(counter_value[0]),
    .X(_079_));
 sky130_fd_sc_hd__nor2_2 _114_ (.A(counter_value[3]),
    .B(_077_),
    .Y(_080_));
 sky130_fd_sc_hd__nor2_2 _115_ (.A(_079_),
    .B(_080_),
    .Y(_081_));
 sky130_fd_sc_hd__and3_2 _116_ (.A(_072_),
    .B(_074_),
    .C(_081_),
    .X(_003_));
 sky130_fd_sc_hd__nand2_2 _117_ (.A(counter_value[4]),
    .B(_079_),
    .Y(_082_));
 sky130_fd_sc_hd__or2_2 _118_ (.A(counter_value[4]),
    .B(_079_),
    .X(_083_));
 sky130_fd_sc_hd__and4_2 _119_ (.A(_072_),
    .B(_074_),
    .C(_082_),
    .D(_083_),
    .X(_004_));
 sky130_fd_sc_hd__xnor2_2 _120_ (.A(counter_value[5]),
    .B(_082_),
    .Y(_084_));
 sky130_fd_sc_hd__and3_2 _121_ (.A(_072_),
    .B(_074_),
    .C(_084_),
    .X(_005_));
 sky130_fd_sc_hd__and4_2 _122_ (.A(counter_value[6]),
    .B(counter_value[5]),
    .C(counter_value[4]),
    .D(_079_),
    .X(_085_));
 sky130_fd_sc_hd__a31o_2 _123_ (.A1(counter_value[5]),
    .A2(counter_value[4]),
    .A3(_079_),
    .B1(counter_value[6]),
    .X(_086_));
 sky130_fd_sc_hd__and4bb_2 _124_ (.A_N(_073_),
    .B_N(_085_),
    .C(_086_),
    .D(_074_),
    .X(_006_));
 sky130_fd_sc_hd__xor2_2 _125_ (.A(counter_value[7]),
    .B(_085_),
    .X(_087_));
 sky130_fd_sc_hd__and3_2 _126_ (.A(_072_),
    .B(_074_),
    .C(_087_),
    .X(_007_));
 sky130_fd_sc_hd__or4_2 _127_ (.A(wr_addr[5]),
    .B(wr_addr[4]),
    .C(wr_addr[7]),
    .D(wr_addr[6]),
    .X(_088_));
 sky130_fd_sc_hd__or3_2 _128_ (.A(wr_addr[1]),
    .B(wr_addr[0]),
    .C(_088_),
    .X(_089_));
 sky130_fd_sc_hd__or4_2 _129_ (.A(wr_addr[1]),
    .B(wr_addr[0]),
    .C(wr_addr[2]),
    .D(_088_),
    .X(_090_));
 sky130_fd_sc_hd__or3_2 _130_ (.A(_094_),
    .B(_095_),
    .C(_090_),
    .X(_091_));
 sky130_fd_sc_hd__mux2_1 _131_ (.A0(wr_data[0]),
    .A1(\period_reg[0] ),
    .S(_091_),
    .X(_009_));
 sky130_fd_sc_hd__mux2_1 _132_ (.A0(wr_data[1]),
    .A1(\period_reg[1] ),
    .S(_091_),
    .X(_010_));
 sky130_fd_sc_hd__mux2_1 _133_ (.A0(wr_data[2]),
    .A1(\period_reg[2] ),
    .S(_091_),
    .X(_011_));
 sky130_fd_sc_hd__mux2_1 _134_ (.A0(wr_data[3]),
    .A1(\period_reg[3] ),
    .S(_091_),
    .X(_012_));
 sky130_fd_sc_hd__mux2_1 _135_ (.A0(wr_data[4]),
    .A1(\period_reg[4] ),
    .S(_091_),
    .X(_013_));
 sky130_fd_sc_hd__mux2_1 _136_ (.A0(wr_data[5]),
    .A1(\period_reg[5] ),
    .S(_091_),
    .X(_014_));
 sky130_fd_sc_hd__mux2_1 _137_ (.A0(wr_data[6]),
    .A1(\period_reg[6] ),
    .S(_091_),
    .X(_015_));
 sky130_fd_sc_hd__mux2_1 _138_ (.A0(wr_data[7]),
    .A1(\period_reg[7] ),
    .S(_091_),
    .X(_016_));
 sky130_fd_sc_hd__or3_2 _139_ (.A(wr_addr[3]),
    .B(_095_),
    .C(_090_),
    .X(_092_));
 sky130_fd_sc_hd__mux2_1 _140_ (.A0(wr_data[0]),
    .A1(control_reg),
    .S(_092_),
    .X(_017_));
 sky130_fd_sc_hd__or4b_2 _141_ (.A(wr_addr[3]),
    .B(_095_),
    .C(_089_),
    .D_N(wr_addr[2]),
    .X(_093_));
 sky130_fd_sc_hd__mux2_1 _142_ (.A0(wr_data[0]),
    .A1(\duty_cycle_reg[0] ),
    .S(_093_),
    .X(_018_));
 sky130_fd_sc_hd__mux2_1 _143_ (.A0(wr_data[1]),
    .A1(\duty_cycle_reg[1] ),
    .S(_093_),
    .X(_019_));
 sky130_fd_sc_hd__mux2_1 _144_ (.A0(wr_data[2]),
    .A1(\duty_cycle_reg[2] ),
    .S(_093_),
    .X(_020_));
 sky130_fd_sc_hd__mux2_1 _145_ (.A0(wr_data[3]),
    .A1(\duty_cycle_reg[3] ),
    .S(_093_),
    .X(_021_));
 sky130_fd_sc_hd__mux2_1 _146_ (.A0(wr_data[4]),
    .A1(\duty_cycle_reg[4] ),
    .S(_093_),
    .X(_022_));
 sky130_fd_sc_hd__mux2_1 _147_ (.A0(wr_data[5]),
    .A1(\duty_cycle_reg[5] ),
    .S(_093_),
    .X(_023_));
 sky130_fd_sc_hd__mux2_1 _148_ (.A0(wr_data[6]),
    .A1(\duty_cycle_reg[6] ),
    .S(_093_),
    .X(_024_));
 sky130_fd_sc_hd__mux2_1 _149_ (.A0(wr_data[7]),
    .A1(\duty_cycle_reg[7] ),
    .S(_093_),
    .X(_025_));
 sky130_fd_sc_hd__inv_2 _150_ (.A(wr_addr[3]),
    .Y(_094_));
 sky130_fd_sc_hd__inv_2 _151_ (.A(wr_en),
    .Y(_095_));
 sky130_fd_sc_hd__inv_2 _152_ (.A(\duty_cycle_reg[5] ),
    .Y(_096_));
 sky130_fd_sc_hd__inv_2 _153_ (.A(\duty_cycle_reg[4] ),
    .Y(_097_));
 sky130_fd_sc_hd__inv_2 _154_ (.A(\duty_cycle_reg[3] ),
    .Y(_098_));
 sky130_fd_sc_hd__inv_2 _155_ (.A(\duty_cycle_reg[2] ),
    .Y(_099_));
 sky130_fd_sc_hd__inv_2 _156_ (.A(\duty_cycle_reg[1] ),
    .Y(_100_));
 sky130_fd_sc_hd__inv_2 _157_ (.A(\duty_cycle_reg[0] ),
    .Y(_101_));
 sky130_fd_sc_hd__inv_2 _158_ (.A(control_reg),
    .Y(_102_));
 sky130_fd_sc_hd__a22o_2 _159_ (.A1(_098_),
    .A2(counter_value[3]),
    .B1(_099_),
    .B2(counter_value[2]),
    .X(_103_));
 sky130_fd_sc_hd__a211o_2 _160_ (.A1(_100_),
    .A2(counter_value[1]),
    .B1(_101_),
    .C1(counter_value[0]),
    .X(_104_));
 sky130_fd_sc_hd__o22a_2 _161_ (.A1(_099_),
    .A2(counter_value[2]),
    .B1(_100_),
    .B2(counter_value[1]),
    .X(_105_));
 sky130_fd_sc_hd__a21o_2 _162_ (.A1(_104_),
    .A2(_105_),
    .B1(_103_),
    .X(_106_));
 sky130_fd_sc_hd__nand2b_2 _163_ (.A_N(\duty_cycle_reg[6] ),
    .B(counter_value[6]),
    .Y(_107_));
 sky130_fd_sc_hd__nand2b_2 _164_ (.A_N(\duty_cycle_reg[7] ),
    .B(counter_value[7]),
    .Y(_026_));
 sky130_fd_sc_hd__nand2b_2 _165_ (.A_N(counter_value[7]),
    .B(\duty_cycle_reg[7] ),
    .Y(_027_));
 sky130_fd_sc_hd__nand2b_2 _166_ (.A_N(counter_value[6]),
    .B(\duty_cycle_reg[6] ),
    .Y(_028_));
 sky130_fd_sc_hd__or2_2 _167_ (.A(_096_),
    .B(counter_value[5]),
    .X(_029_));
 sky130_fd_sc_hd__and4_2 _168_ (.A(_107_),
    .B(_026_),
    .C(_027_),
    .D(_028_),
    .X(_030_));
 sky130_fd_sc_hd__a22o_2 _169_ (.A1(_096_),
    .A2(counter_value[5]),
    .B1(counter_value[4]),
    .B2(_097_),
    .X(_031_));
 sky130_fd_sc_hd__o22a_2 _170_ (.A1(counter_value[4]),
    .A2(_097_),
    .B1(_098_),
    .B2(counter_value[3]),
    .X(_032_));
 sky130_fd_sc_hd__and4b_2 _171_ (.A_N(_031_),
    .B(_029_),
    .C(_030_),
    .D(_032_),
    .X(_033_));
 sky130_fd_sc_hd__a21boi_2 _172_ (.A1(_107_),
    .A2(_026_),
    .B1_N(_027_),
    .Y(_034_));
 sky130_fd_sc_hd__a311o_2 _173_ (.A1(_029_),
    .A2(_030_),
    .A3(_031_),
    .B1(_034_),
    .C1(_102_),
    .X(_035_));
 sky130_fd_sc_hd__a21oi_2 _174_ (.A1(_106_),
    .A2(_033_),
    .B1(_035_),
    .Y(_008_));
 sky130_fd_sc_hd__nor2_2 _175_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .Y(_036_));
 sky130_fd_sc_hd__nor4_2 _176_ (.A(rd_addr[5]),
    .B(rd_addr[4]),
    .C(rd_addr[7]),
    .D(rd_addr[6]),
    .Y(_037_));
 sky130_fd_sc_hd__and4_2 _177_ (.A(rd_addr[2]),
    .B(rd_addr[3]),
    .C(_036_),
    .D(_037_),
    .X(_038_));
 sky130_fd_sc_hd__and4b_2 _178_ (.A_N(rd_addr[3]),
    .B(_036_),
    .C(_037_),
    .D(rd_addr[2]),
    .X(_039_));
 sky130_fd_sc_hd__and4bb_2 _179_ (.A_N(rd_addr[2]),
    .B_N(rd_addr[3]),
    .C(_036_),
    .D(control_reg),
    .X(_040_));
 sky130_fd_sc_hd__a22o_2 _180_ (.A1(\duty_cycle_reg[0] ),
    .A2(_039_),
    .B1(_040_),
    .B2(_037_),
    .X(_041_));
 sky130_fd_sc_hd__and4b_2 _181_ (.A_N(rd_addr[2]),
    .B(rd_addr[3]),
    .C(_036_),
    .D(_037_),
    .X(_042_));
 sky130_fd_sc_hd__a22o_2 _182_ (.A1(counter_value[0]),
    .A2(_038_),
    .B1(_042_),
    .B2(\period_reg[0] ),
    .X(_043_));
 sky130_fd_sc_hd__o21a_2 _183_ (.A1(_041_),
    .A2(_043_),
    .B1(rd_en),
    .X(rd_data[0]));
 sky130_fd_sc_hd__and2_2 _184_ (.A(counter_value[1]),
    .B(_038_),
    .X(_044_));
 sky130_fd_sc_hd__a22o_2 _185_ (.A1(\duty_cycle_reg[1] ),
    .A2(_039_),
    .B1(_042_),
    .B2(\period_reg[1] ),
    .X(_045_));
 sky130_fd_sc_hd__o21a_2 _186_ (.A1(_044_),
    .A2(_045_),
    .B1(rd_en),
    .X(rd_data[1]));
 sky130_fd_sc_hd__and2_2 _187_ (.A(counter_value[2]),
    .B(_038_),
    .X(_046_));
 sky130_fd_sc_hd__a22o_2 _188_ (.A1(\duty_cycle_reg[2] ),
    .A2(_039_),
    .B1(_042_),
    .B2(\period_reg[2] ),
    .X(_047_));
 sky130_fd_sc_hd__o21a_2 _189_ (.A1(_046_),
    .A2(_047_),
    .B1(rd_en),
    .X(rd_data[2]));
 sky130_fd_sc_hd__and2_2 _190_ (.A(\period_reg[3] ),
    .B(_042_),
    .X(_048_));
 sky130_fd_sc_hd__a22o_2 _191_ (.A1(counter_value[3]),
    .A2(_038_),
    .B1(_039_),
    .B2(\duty_cycle_reg[3] ),
    .X(_049_));
 sky130_fd_sc_hd__o21a_2 _192_ (.A1(_048_),
    .A2(_049_),
    .B1(rd_en),
    .X(rd_data[3]));
 sky130_fd_sc_hd__and2_2 _193_ (.A(\duty_cycle_reg[4] ),
    .B(_039_),
    .X(_050_));
 sky130_fd_sc_hd__a22o_2 _194_ (.A1(counter_value[4]),
    .A2(_038_),
    .B1(_042_),
    .B2(\period_reg[4] ),
    .X(_051_));
 sky130_fd_sc_hd__o21a_2 _195_ (.A1(_050_),
    .A2(_051_),
    .B1(rd_en),
    .X(rd_data[4]));
 sky130_fd_sc_hd__and2_2 _196_ (.A(counter_value[5]),
    .B(_038_),
    .X(_052_));
 sky130_fd_sc_hd__a22o_2 _197_ (.A1(\duty_cycle_reg[5] ),
    .A2(_039_),
    .B1(_042_),
    .B2(\period_reg[5] ),
    .X(_053_));
 sky130_fd_sc_hd__o21a_2 _198_ (.A1(_052_),
    .A2(_053_),
    .B1(rd_en),
    .X(rd_data[5]));
 sky130_fd_sc_hd__and2_2 _199_ (.A(counter_value[6]),
    .B(_038_),
    .X(_054_));
 sky130_fd_sc_hd__a22o_2 _200_ (.A1(\duty_cycle_reg[6] ),
    .A2(_039_),
    .B1(_042_),
    .B2(\period_reg[6] ),
    .X(_055_));
 sky130_fd_sc_hd__o21a_2 _201_ (.A1(_054_),
    .A2(_055_),
    .B1(rd_en),
    .X(rd_data[6]));
 sky130_fd_sc_hd__and2_2 _202_ (.A(\duty_cycle_reg[7] ),
    .B(_039_),
    .X(_056_));
 sky130_fd_sc_hd__a22o_2 _203_ (.A1(counter_value[7]),
    .A2(_038_),
    .B1(_042_),
    .B2(\period_reg[7] ),
    .X(_057_));
 sky130_fd_sc_hd__o21a_2 _204_ (.A1(_056_),
    .A2(_057_),
    .B1(rd_en),
    .X(rd_data[7]));
 sky130_fd_sc_hd__xor2_2 _205_ (.A(counter_value[0]),
    .B(\period_reg[0] ),
    .X(_058_));
 sky130_fd_sc_hd__xor2_2 _206_ (.A(counter_value[5]),
    .B(\period_reg[5] ),
    .X(_059_));
 sky130_fd_sc_hd__or2_2 _207_ (.A(counter_value[4]),
    .B(\period_reg[4] ),
    .X(_060_));
 sky130_fd_sc_hd__nand2_2 _208_ (.A(counter_value[4]),
    .B(\period_reg[4] ),
    .Y(_061_));
 sky130_fd_sc_hd__nand2_2 _209_ (.A(counter_value[7]),
    .B(\period_reg[7] ),
    .Y(_062_));
 sky130_fd_sc_hd__or2_2 _210_ (.A(counter_value[7]),
    .B(\period_reg[7] ),
    .X(_063_));
 sky130_fd_sc_hd__a22o_2 _211_ (.A1(_060_),
    .A2(_061_),
    .B1(_062_),
    .B2(_063_),
    .X(_064_));
 sky130_fd_sc_hd__xor2_2 _212_ (.A(counter_value[2]),
    .B(\period_reg[2] ),
    .X(_065_));
 sky130_fd_sc_hd__xor2_2 _213_ (.A(counter_value[6]),
    .B(\period_reg[6] ),
    .X(_066_));
 sky130_fd_sc_hd__xor2_2 _214_ (.A(counter_value[3]),
    .B(\period_reg[3] ),
    .X(_067_));
 sky130_fd_sc_hd__xor2_2 _215_ (.A(counter_value[1]),
    .B(\period_reg[1] ),
    .X(_068_));
 sky130_fd_sc_hd__or4_2 _216_ (.A(_058_),
    .B(_059_),
    .C(_065_),
    .D(_066_),
    .X(_069_));
 sky130_fd_sc_hd__or4_2 _217_ (.A(\period_reg[4] ),
    .B(\period_reg[5] ),
    .C(\period_reg[6] ),
    .D(\period_reg[7] ),
    .X(_070_));
 sky130_fd_sc_hd__or4_2 _218_ (.A(\period_reg[0] ),
    .B(\period_reg[1] ),
    .C(\period_reg[2] ),
    .D(\period_reg[3] ),
    .X(_071_));
 sky130_fd_sc_hd__or2_2 _219_ (.A(_070_),
    .B(_071_),
    .X(_072_));
 sky130_fd_sc_hd__inv_2 _220_ (.A(_072_),
    .Y(_073_));
 sky130_fd_sc_hd__o41a_2 _221_ (.A1(_064_),
    .A2(_067_),
    .A3(_068_),
    .A4(_069_),
    .B1(control_reg),
    .X(_074_));
 sky130_fd_sc_hd__and3b_2 _222_ (.A_N(counter_value[0]),
    .B(_072_),
    .C(_074_),
    .X(_000_));
 sky130_fd_sc_hd__or2_2 _223_ (.A(counter_value[1]),
    .B(counter_value[0]),
    .X(_075_));
 sky130_fd_sc_hd__sdfrtp_2 _224_ (.CLK(clk),
    .D(_009_),
    .RESET_B(reset_n),
    .SCD(scan_in[0]),
    .SCE(scan_en),
    .Q(\period_reg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _225_ (.CLK(clk),
    .D(_010_),
    .RESET_B(reset_n),
    .SCD(scan_in[1]),
    .SCE(scan_en),
    .Q(\period_reg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _226_ (.CLK(clk),
    .D(_011_),
    .RESET_B(reset_n),
    .SCD(scan_in[2]),
    .SCE(scan_en),
    .Q(\period_reg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _227_ (.CLK(clk),
    .D(_012_),
    .RESET_B(reset_n),
    .SCD(scan_in[3]),
    .SCE(scan_en),
    .Q(\period_reg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _228_ (.CLK(clk),
    .D(_013_),
    .RESET_B(reset_n),
    .SCD(\period_reg[0] ),
    .SCE(scan_en),
    .Q(\period_reg[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _229_ (.CLK(clk),
    .D(_014_),
    .RESET_B(reset_n),
    .SCD(\period_reg[1] ),
    .SCE(scan_en),
    .Q(\period_reg[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _230_ (.CLK(clk),
    .D(_015_),
    .RESET_B(reset_n),
    .SCD(\period_reg[2] ),
    .SCE(scan_en),
    .Q(\period_reg[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _231_ (.CLK(clk),
    .D(_016_),
    .RESET_B(reset_n),
    .SCD(\period_reg[3] ),
    .SCE(scan_en),
    .Q(\period_reg[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _232_ (.CLK(clk),
    .D(_008_),
    .RESET_B(reset_n),
    .SCD(\period_reg[4] ),
    .SCE(scan_en),
    .Q(pwm_out));
 sky130_fd_sc_hd__sdfrtp_2 _233_ (.CLK(clk),
    .D(_000_),
    .RESET_B(reset_n),
    .SCD(\period_reg[5] ),
    .SCE(scan_en),
    .Q(counter_value[0]));
 sky130_fd_sc_hd__sdfrtp_2 _234_ (.CLK(clk),
    .D(_001_),
    .RESET_B(reset_n),
    .SCD(\period_reg[6] ),
    .SCE(scan_en),
    .Q(counter_value[1]));
 sky130_fd_sc_hd__sdfrtp_2 _235_ (.CLK(clk),
    .D(_002_),
    .RESET_B(reset_n),
    .SCD(\period_reg[7] ),
    .SCE(scan_en),
    .Q(counter_value[2]));
 sky130_fd_sc_hd__sdfrtp_2 _236_ (.CLK(clk),
    .D(_003_),
    .RESET_B(reset_n),
    .SCD(pwm_out),
    .SCE(scan_en),
    .Q(counter_value[3]));
 sky130_fd_sc_hd__sdfrtp_2 _237_ (.CLK(clk),
    .D(_004_),
    .RESET_B(reset_n),
    .SCD(counter_value[0]),
    .SCE(scan_en),
    .Q(counter_value[4]));
 sky130_fd_sc_hd__sdfrtp_2 _238_ (.CLK(clk),
    .D(_005_),
    .RESET_B(reset_n),
    .SCD(counter_value[1]),
    .SCE(scan_en),
    .Q(counter_value[5]));
 sky130_fd_sc_hd__sdfrtp_2 _239_ (.CLK(clk),
    .D(_006_),
    .RESET_B(reset_n),
    .SCD(counter_value[2]),
    .SCE(scan_en),
    .Q(counter_value[6]));
 sky130_fd_sc_hd__sdfrtp_2 _240_ (.CLK(clk),
    .D(_007_),
    .RESET_B(reset_n),
    .SCD(counter_value[3]),
    .SCE(scan_en),
    .Q(counter_value[7]));
 sky130_fd_sc_hd__sdfrtp_2 _241_ (.CLK(clk),
    .D(_017_),
    .RESET_B(reset_n),
    .SCD(counter_value[4]),
    .SCE(scan_en),
    .Q(control_reg));
 sky130_fd_sc_hd__sdfrtp_2 _242_ (.CLK(clk),
    .D(_018_),
    .RESET_B(reset_n),
    .SCD(counter_value[5]),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _243_ (.CLK(clk),
    .D(_019_),
    .RESET_B(reset_n),
    .SCD(counter_value[6]),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _244_ (.CLK(clk),
    .D(_020_),
    .RESET_B(reset_n),
    .SCD(counter_value[7]),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _245_ (.CLK(clk),
    .D(_021_),
    .RESET_B(reset_n),
    .SCD(control_reg),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _246_ (.CLK(clk),
    .D(_022_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[0] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _247_ (.CLK(clk),
    .D(_023_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[1] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _248_ (.CLK(clk),
    .D(_024_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[2] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _249_ (.CLK(clk),
    .D(_025_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[3] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[7] ));
 assign scan_out[2] = \duty_cycle_reg[4] ;
 assign scan_out[3] = \duty_cycle_reg[5] ;
 assign scan_out[0] = \duty_cycle_reg[6] ;
 assign scan_out[1] = \duty_cycle_reg[7] ;
endmodule
