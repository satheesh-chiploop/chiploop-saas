# Digital Synthesis Summary

- **Workflow**: 542f4822-f18d-478c-b5be-bcf846b82aee
- **Status**: `ok` (rc=0)
- **Top module**: `pwm_controller`
- **Clock**: `clk` @ **9.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/542f4822-f18d-478c-b5be-bcf846b82aee/92ba4441-2998-486b-929e-3b87bf554531/digital/arch2tapeout/digital/synth/runs/Digital_Arch2Tapeout_542f4822-f18d-478c-b5be-bcf846b82aee/final/metrics.json`
- netlist candidates: 2 found
