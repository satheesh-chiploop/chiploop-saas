# System PD Signoff Closure Plan

- closure_complete: `False`
- selected_restart_stage: `None`
- dominant_issue: `synthesis_lec`
- max_iterations: `1`
- stop_reason: `repair_plan_created`

## Post-Fill Timing
- setup WNS: `0`
- setup TNS: `0`
- setup violations: `0`
- hold WNS: `0`
- hold TNS: `0`
- hold violations: `0`

## Repair Actions
- none

## Skipped Repairs
- `synthesis_lec`: Outside PD signoff closure scope; rerun synthesis closure or synthesis LEC repair first.