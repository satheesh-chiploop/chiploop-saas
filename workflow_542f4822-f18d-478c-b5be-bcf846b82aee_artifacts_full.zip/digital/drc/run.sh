#!/usr/bin/env bash
set -euo pipefail

echo "== ChipLoop: Digital DRC Agent =="
echo "PDK_VARIANT=sky130A"
echo "OPENLANE_IMAGE=ghcr.io/efabless/openlane2:2.4.0.dev1"
echo "WORKDIR=/work"

export OPENLANE_NUM_CORES=2

docker run --rm \
  -v "/root/chiploop-backend/backend/pdk":/pdk \
  -v "/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/542f4822-f18d-478c-b5be-bcf846b82aee/92ba4441-2998-486b-929e-3b87bf554531/digital/arch2tapeout/digital/run_work":/work \
  -e PDK=sky130A \
  -e PDK_ROOT=/pdk \
  ghcr.io/efabless/openlane2:2.4.0.dev1 \
  bash -lc 'set -e; cd /work && openlane --flow Classic --run-tag Digital_Arch2Tapeout_542f4822-f18d-478c-b5be-bcf846b82aee --override-config RUN_LINTER=False --to KLayout.DRC drc/config.json'
