// Auto-generated functional SKY130 cell wrappers for Yosys LEC.
// Generated from the synthesized netlist's referenced cell/pin set.
module sky130_fd_sc_hd__a211o_2(A1, A2, B1, C1, X);
  input A1;
  input A2;
  input B1;
  input C1;
  output X;
  assign X = ((A1 & A2) | (B1) | (C1));
endmodule

module sky130_fd_sc_hd__a21boi_2(A1, A2, B1_N, Y);
  input A1;
  input A2;
  input B1_N;
  output Y;
  assign Y = ~((A1 & A2) | (~B1_N));
endmodule

module sky130_fd_sc_hd__a21o_2(A1, A2, B1, X);
  input A1;
  input A2;
  input B1;
  output X;
  assign X = ((A1 & A2) | (B1));
endmodule

module sky130_fd_sc_hd__a21oi_2(A1, A2, B1, Y);
  input A1;
  input A2;
  input B1;
  output Y;
  assign Y = ~((A1 & A2) | (B1));
endmodule

module sky130_fd_sc_hd__a22o_2(A1, A2, B1, B2, X);
  input A1;
  input A2;
  input B1;
  input B2;
  output X;
  assign X = ((A1 & A2) | (B1 & B2));
endmodule

module sky130_fd_sc_hd__a311o_2(A1, A2, A3, B1, C1, X);
  input A1;
  input A2;
  input A3;
  input B1;
  input C1;
  output X;
  assign X = ((A1 & A2 & A3) | (B1) | (C1));
endmodule

module sky130_fd_sc_hd__a31o_2(A1, A2, A3, B1, X);
  input A1;
  input A2;
  input A3;
  input B1;
  output X;
  assign X = ((A1 & A2 & A3) | (B1));
endmodule

module sky130_fd_sc_hd__and2_2(A, B, X);
  input A;
  input B;
  output X;
  assign X = (A & B);
endmodule

module sky130_fd_sc_hd__and3_2(A, B, C, X);
  input A;
  input B;
  input C;
  output X;
  assign X = (A & B & C);
endmodule

module sky130_fd_sc_hd__and3b_2(A_N, B, C, X);
  input A_N;
  input B;
  input C;
  output X;
  assign X = (~A_N & B & C);
endmodule

module sky130_fd_sc_hd__and4_2(A, B, C, D, X);
  input A;
  input B;
  input C;
  input D;
  output X;
  assign X = (A & B & C & D);
endmodule

module sky130_fd_sc_hd__and4b_2(A_N, B, C, D, X);
  input A_N;
  input B;
  input C;
  input D;
  output X;
  assign X = (~A_N & B & C & D);
endmodule

module sky130_fd_sc_hd__and4bb_2(A_N, B_N, C, D, X);
  input A_N;
  input B_N;
  input C;
  input D;
  output X;
  assign X = (~A_N & ~B_N & C & D);
endmodule

module sky130_fd_sc_hd__dfrtp_2(CLK, D, RESET_B, Q);
  input CLK;
  input D;
  input RESET_B;
  output Q;
  reg q_reg;
  always @(posedge CLK or negedge RESET_B) begin
    if (!RESET_B) q_reg <= 1'b0;
    else q_reg <= D;
  end
  assign Q = q_reg;
endmodule

module sky130_fd_sc_hd__inv_2(A, Y);
  input A;
  output Y;
  assign Y = ~A;
endmodule

module sky130_fd_sc_hd__mux2_1(A0, A1, S, X);
  input A0;
  input A1;
  input S;
  output X;
  assign X = (S ? A1 : A0);
endmodule

module sky130_fd_sc_hd__nand2_2(A, B, Y);
  input A;
  input B;
  output Y;
  assign Y = ~(A & B);
endmodule

module sky130_fd_sc_hd__nand2b_2(A_N, B, Y);
  input A_N;
  input B;
  output Y;
  assign Y = ~(~A_N & B);
endmodule

module sky130_fd_sc_hd__nor2_2(A, B, Y);
  input A;
  input B;
  output Y;
  assign Y = ~(A | B);
endmodule

module sky130_fd_sc_hd__nor4_2(A, B, C, D, Y);
  input A;
  input B;
  input C;
  input D;
  output Y;
  assign Y = ~(A | B | C | D);
endmodule

module sky130_fd_sc_hd__o21a_2(A1, A2, B1, X);
  input A1;
  input A2;
  input B1;
  output X;
  assign X = ((A1 | A2) & (B1));
endmodule

module sky130_fd_sc_hd__o22a_2(A1, A2, B1, B2, X);
  input A1;
  input A2;
  input B1;
  input B2;
  output X;
  assign X = ((A1 | A2) & (B1 | B2));
endmodule

module sky130_fd_sc_hd__o41a_2(A1, A2, A3, A4, B1, X);
  input A1;
  input A2;
  input A3;
  input A4;
  input B1;
  output X;
  assign X = ((A1 | A2 | A3 | A4) & (B1));
endmodule

module sky130_fd_sc_hd__or2_2(A, B, X);
  input A;
  input B;
  output X;
  assign X = (A | B);
endmodule

module sky130_fd_sc_hd__or3_2(A, B, C, X);
  input A;
  input B;
  input C;
  output X;
  assign X = (A | B | C);
endmodule

module sky130_fd_sc_hd__or4_2(A, B, C, D, X);
  input A;
  input B;
  input C;
  input D;
  output X;
  assign X = (A | B | C | D);
endmodule

module sky130_fd_sc_hd__or4b_2(A, B, C, D_N, X);
  input A;
  input B;
  input C;
  input D_N;
  output X;
  assign X = (A | B | C | ~D_N);
endmodule

module sky130_fd_sc_hd__xnor2_2(A, B, Y);
  input A;
  input B;
  output Y;
  assign Y = ~(A ^ B);
endmodule

module sky130_fd_sc_hd__xor2_2(A, B, X);
  input A;
  input B;
  output X;
  assign X = (A ^ B);
endmodule

