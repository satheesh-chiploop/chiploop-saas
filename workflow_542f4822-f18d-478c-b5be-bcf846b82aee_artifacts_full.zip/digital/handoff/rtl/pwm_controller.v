module pwm_controller (
    input        clk,
    input        reset_n,
    input        wr_en,
    input  [7:0] wr_addr,
    input  [7:0] wr_data,
    input        rd_en,
    input  [7:0] rd_addr,
    output reg [7:0] rd_data,
    output reg       pwm_out,
    output reg [7:0] counter_value
);

reg [7:0] control_reg;
reg [7:0] duty_cycle_reg;
reg [7:0] period_reg;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        control_reg   <= 8'h00;
        duty_cycle_reg <= 8'h00;
        period_reg    <= 8'h00;
        counter_value <= 8'h00;
        pwm_out       <= 1'b0;
    end else begin
        if (wr_en) begin
            case (wr_addr)
                8'h00: control_reg    <= {7'h00, wr_data[0]};
                8'h04: duty_cycle_reg  <= wr_data;
                8'h08: period_reg     <= wr_data;
                default: begin
                end
            endcase
        end

        if (control_reg[0] && (period_reg != 8'h00)) begin
            if (counter_value == period_reg)
                counter_value <= 8'h00;
            else
                counter_value <= counter_value + 8'h01;
        end else begin
            counter_value <= 8'h00;
        end

        if (control_reg[0] && (counter_value < duty_cycle_reg))
            pwm_out <= 1'b1;
        else
            pwm_out <= 1'b0;
    end
end

always @(*) begin
    rd_data = 8'h00;
    if (rd_en) begin
        case (rd_addr)
            8'h00: rd_data = {7'h00, control_reg[0]};
            8'h04: rd_data = duty_cycle_reg;
            8'h08: rd_data = period_reg;
            8'h0C: rd_data = counter_value;
            default: rd_data = 8'h00;
        endcase
    end
end

endmodule
