# IP Packaging & Handoff Report

- Top: `imported_from_arch2rtl`
- Package: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/542f4822-f18d-478c-b5be-bcf846b82aee/92ba4441-2998-486b-929e-3b87bf554531/digital/arch2tapeout/handoff/imported_from_arch2rtl_ip_package`
- Zip: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/542f4822-f18d-478c-b5be-bcf846b82aee/92ba4441-2998-486b-929e-3b87bf554531/digital/arch2tapeout/handoff/imported_from_arch2rtl_ip_package.zip`

## Bucket counts
- **rtl**: 1
- **spec**: 1
- **arch**: 0
- **microarch**: 0
- **regmap**: 1
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 2
