# Smoke Executive Summary
- Generated: `2026-06-06T03:08:44.319507`
- Top: `pwm_controller`
- Verdict: **PASS ✅**

## What ran
- Preflight: yes
- Compile: pass
- Smoke sim: pass
- Simulator: `verilator`
- Time budget: `fast`
- RTL files: `1`

## Key notes
- Smoke indicates the design is not obviously broken. Proceed to DQA + Verify for deeper checks.

## Recommended next action
- **Run DQA next**
