"""Bug localization helper for Cocotb + Verilator logs."""

import argparse
import json
import os
import re
from datetime import datetime

FAIL_PATTERNS = [
    r"AssertionError:.*",
    r"assert\s+.*failed",
    r"FATAL.*",
    r"ERROR.*",
    r"Mismatch.*",
]

def _now():
    return datetime.now().isoformat()

def parse_log(text: str) -> dict:
    lines = text.splitlines()
    hits = []
    for i, ln in enumerate(lines):
        for pat in FAIL_PATTERNS:
            if re.search(pat, ln):
                hits.append({"line": i, "text": ln})
    tail = lines[-200:] if len(lines) > 200 else lines
    return {"fail_hits": hits[:50], "tail": tail}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--log", required=True)
    ap.add_argument("--out", default="reports/bug_localization.json")
    args = ap.parse_args()

    with open(args.log, "r", encoding="utf-8", errors="ignore") as f:
        txt = f.read()

    info = parse_log(txt)
    out = {
        "type": "bug_localization",
        "top_module": "pwm_controller",
        "generated_at": _now(),
        "log_path": args.log,
        "log_analysis": info,
        "hints": [
            "The first AssertionError/Mismatch line is usually closest to root-cause.",
            "If VCD is enabled, inspect around the failure in GTKWave.",
            "If scoreboarding is used, the first mismatch indicates divergence."
        ],
    }

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)

if __name__ == "__main__":
    main()
