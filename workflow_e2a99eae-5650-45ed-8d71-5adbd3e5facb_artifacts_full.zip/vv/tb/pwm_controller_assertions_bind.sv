/*
 * Auto-generated SVA bind file.
 * Uses only spec-declared signals.
 */
bind pwm_controller pwm_controller_assertions u_pwm_controller_assertions (

);
