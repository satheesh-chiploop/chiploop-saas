# Bug Localization

Generated:
- `bug_localize.py` : scans logs for assertion/mismatch lines

Use:
```bash
python bug_localize.py --log <path-to-make-or-cocotb-log>
```
