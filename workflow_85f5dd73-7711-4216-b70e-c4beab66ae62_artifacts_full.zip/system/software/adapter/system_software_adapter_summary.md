# System Software HAL/Driver Adapter

- Generated at: 2026-09-16T17:43:55.501220+00:00
- Source workflow id: 0511e849-df80-4dfc-bb15-c5bf235318a2
- Adapter crate: `physical_ai_product_adapter`
- Adapter package: `physical_ai_product_adapter`

## Adapter contract

- `hal_path` → `firmware/hal/registers.rs`
- `driver_path` → `firmware/drivers/driver_scaffold.rs`
- `register_map_path` → `firmware/register_map.json`
- `interrupt_mapping_path` → `firmware/isr/interrupt_map.json`
- `dma_integration_path` → `unavailable`

## Generated files

- `system/software/adapter/physical_ai_product_adapter/src/adapter/register_adapter.rs`
- `system/software/adapter/physical_ai_product_adapter/src/adapter/device_adapter.rs`
- `system/software/adapter/physical_ai_product_adapter/src/error.rs`
- `system/software/adapter/physical_ai_product_adapter/Cargo.toml`
- `system/software/adapter/physical_ai_product_adapter/src/lib.rs`
- `system/software/adapter/physical_ai_product_adapter/src/adapter/mod.rs`
