# System Software Config Schema

- Generated at: 2026-09-16T17:43:56.324397+00:00
- Source workflow id: 0511e849-df80-4dfc-bb15-c5bf235318a2

## Feature toggles

- `interrupt_control` → `True`
- `dma_control` → `False`
- `power_mode_control` → `False`
- `clock_control` → `False`
- `reset_control` → `False`

## Generated files

- `system/software/config/default_config.json`
- `system/software/config/default_runtime_config.json`
- `system/software/config/default_runtime_config.toml`
