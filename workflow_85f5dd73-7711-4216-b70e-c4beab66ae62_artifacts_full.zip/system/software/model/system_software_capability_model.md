# System Software Capability Model

- Generated at: 2026-09-16T17:43:51.178227+00:00
- Source workflow id: 0511e849-df80-4dfc-bb15-c5bf235318a2

## Platform identity

- Top module: `adaptive_aero_control_top`
- RTL file count: `14`

## Software services

- `register_access` → `True`
- `driver_layer` → `True`
- `interrupt_control` → `True`
- `dma_control` → `False`
- `boot_orchestration` → `False`
- `clock_control` → `False`
- `reset_control` → `False`
- `power_mode_control` → `False`
- `runtime_validation_support` → `True`

## Register model

- Register count: `9`
- Field count: `36`
- Bus: `MINIMAL`

## Constraints

- system_integration_intent_missing
- system_integration_intent_path_missing
