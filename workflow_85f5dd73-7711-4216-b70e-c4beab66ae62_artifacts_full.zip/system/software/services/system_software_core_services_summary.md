# System Software Core Services

- Generated at: 2026-09-16T17:43:59.687844+00:00
- Source workflow id: 0511e849-df80-4dfc-bb15-c5bf235318a2
- Service count: 4

## Services

- `init_manager`
- `health_monitor`
- `control_service`
- `interrupt_service`

## Files

- `system/software/services/src/init_manager.rs`
- `system/software/services/src/health_monitor.rs`
- `system/software/services/src/control_service.rs`
- `system/software/services/src/interrupt_service.rs`
- `system/software/services/src/error.rs`
- `system/software/services/Cargo.toml`
- `system/software/services/src/lib.rs`
