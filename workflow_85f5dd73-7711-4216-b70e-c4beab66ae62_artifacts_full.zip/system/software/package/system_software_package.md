# System Software Package

- Generated at: 2026-09-16T17:44:08.660253+00:00
- Source workflow id: 0511e849-df80-4dfc-bb15-c5bf235318a2
- Artifact count: 37
- Inferred required files added: 0
- Package status: `complete`
- Entry binary: `ss_app_control_service`

## Artifacts

- `system/software/sdk/physical_ai_product/Cargo.toml`
- `system/software/sdk/physical_ai_product/src/lib.rs`
- `system/software/sdk/physical_ai_product/examples/basic.rs`
- `system/software/sdk/physical_ai_product/src/bin/diag_cli.rs`
- `system/software/sdk/physical_ai_product/config/default.toml`
- `system/software/apps/control_service/src/main.rs`
- `system/software/apps/control_service/Cargo.toml`
- `system/software/apps/diagnostics/src/main.rs`
- `system/software/apps/diagnostics/Cargo.toml`
- `system/software/apps/demo_cli/src/main.rs`
- `system/software/apps/demo_cli/Cargo.toml`
- `system/software/tools/reg_viewer/Cargo.toml`
- `system/software/tools/reg_viewer/src/main.rs`
- `system/software/tools/diag_cli/Cargo.toml`
- `system/software/tools/diag_cli/src/main.rs`
- `system/software/Cargo.toml`
- `system/software/Makefile`
- `system/software/build_plan.json`
- `system/software/tests/sdk/sdk_tests.rs`
- `system/software/tests/services/service_tests.rs`
- `system/software/tests/apps/control_service_smoke.rs`
- `system/software/tests/apps/diagnostics_smoke.rs`
- `system/software/tests/apps/demo_cli_smoke.rs`
- `system/software/mock/src/mock_runtime.rs`
- `system/software/adapter/physical_ai_product_adapter/src/adapter/register_adapter.rs`
- `system/software/adapter/physical_ai_product_adapter/src/adapter/device_adapter.rs`
- `system/software/adapter/physical_ai_product_adapter/src/error.rs`
- `system/software/adapter/physical_ai_product_adapter/Cargo.toml`
- `system/software/adapter/physical_ai_product_adapter/src/lib.rs`
- `system/software/adapter/physical_ai_product_adapter/src/adapter/mod.rs`
- `system/software/services/src/init_manager.rs`
- `system/software/services/src/health_monitor.rs`
- `system/software/services/src/control_service.rs`
- `system/software/services/src/interrupt_service.rs`
- `system/software/services/src/error.rs`
- `system/software/services/Cargo.toml`
- `system/software/services/src/lib.rs`
