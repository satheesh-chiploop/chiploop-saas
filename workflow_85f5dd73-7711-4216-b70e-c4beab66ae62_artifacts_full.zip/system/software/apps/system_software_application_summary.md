# System Software Applications

- Generated at: 2026-09-16T17:44:01.981934+00:00
- Source workflow id: 0511e849-df80-4dfc-bb15-c5bf235318a2
- Crate name: `physical_ai_product`

## Applications

- `control_service` → package `ss_app_control_service`
- `diagnostics` → package `ss_app_diagnostics`
- `demo_cli` → package `ss_app_demo_cli`

## Files

- `system/software/apps/control_service/src/main.rs`
- `system/software/apps/control_service/Cargo.toml`
- `system/software/apps/diagnostics/src/main.rs`
- `system/software/apps/diagnostics/Cargo.toml`
- `system/software/apps/demo_cli/src/main.rs`
- `system/software/apps/demo_cli/Cargo.toml`
