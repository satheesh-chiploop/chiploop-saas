# System Software Tooling

- Generated at: 2026-09-16T17:44:03.601155+00:00
- Source workflow id: 0511e849-df80-4dfc-bb15-c5bf235318a2
- SDK crate name: `physical_ai_product`

## Tools

- `reg_viewer` → package `ss_tool_reg_viewer`
- `diag_cli` → package `ss_tool_diag_cli`

## Files

- `system/software/tools/reg_viewer/Cargo.toml`
- `system/software/tools/reg_viewer/src/main.rs`
- `system/software/tools/diag_cli/Cargo.toml`
- `system/software/tools/diag_cli/src/main.rs`
