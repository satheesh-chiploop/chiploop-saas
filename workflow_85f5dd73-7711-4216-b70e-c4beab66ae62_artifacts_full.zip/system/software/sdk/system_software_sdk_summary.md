# System Software SDK Scaffold Summary

- Generated at: 2026-09-16T17:43:53.712033+00:00
- Source workflow id: 0511e849-df80-4dfc-bb15-c5bf235318a2
- Target language: `rust`
- Build system: `cargo`
- Crate name: `physical_ai_product`

## Generated files

- `system/software/sdk/physical_ai_product/Cargo.toml`
- `system/software/sdk/physical_ai_product/src/lib.rs`
- `system/software/sdk/physical_ai_product/examples/basic.rs`
- `system/software/sdk/physical_ai_product/src/bin/diag_cli.rs`
- `system/software/sdk/physical_ai_product/config/default.toml`
