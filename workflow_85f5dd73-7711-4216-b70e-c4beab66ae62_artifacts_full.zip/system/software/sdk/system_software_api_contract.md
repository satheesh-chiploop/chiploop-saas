# System Software API Contract

- Generated at: 2026-09-16T17:43:52.052073+00:00
- Source workflow id: 0511e849-df80-4dfc-bb15-c5bf235318a2
- Public API language: rust

## Public API groups

### register_access
Public register access wrapper over the firmware HAL/driver layer.
- `read_register`(register_name: &str) -> `u64`
- `write_register`(register_name: &str, value: u64) -> `Result<(), SoftwareError>`

### device_driver
Primary software-facing driver contract for device lifecycle and status.
- `device_init`(config: DeviceConfig) -> `Result<(), SoftwareError>`
- `device_shutdown`() -> `Result<(), SoftwareError>`
- `get_status`() -> `DeviceStatus`

### interrupts
Optional interrupt control/service layer.
- `register_interrupt_handler`(irq_name: &str, callback: InterruptHandler) -> `Result<(), SoftwareError>`
- `enable_interrupt`(irq_name: &str) -> `Result<(), SoftwareError>`

### handoff_candidates
Candidate APIs derived directly from the upstream handoff.
- `firmware_firmware_manifest`() -> `candidate`
- `firmware_register_map`() -> `candidate`
- `firmware_register_map_debug`() -> `candidate`
- `firmware_register_map_summary`() -> `candidate`
- `firmware_isr_interrupt_map`() -> `candidate`
- `firmware_isr_interrupts`() -> `candidate`
- `firmware_isr_interrupts_debug`() -> `candidate`
- `firmware_isr_interrupts_summary`() -> `candidate`
- `firmware_esp_idf_build_bootloader_compile_commands`() -> `candidate`
- `firmware_esp_idf_build_bootloader_project_description`() -> `candidate`
- `firmware_esp_idf_build_bootloader_project_elf_src_esp32`() -> `candidate`
- `firmware_esp_idf_build_bootloader_config_kconfig_menus`() -> `candidate`
- `firmware_esp_idf_build_bootloader_config_sdkconfig`() -> `candidate`
- `firmware_esp_idf_build_bootloader_config_sdkconfig_2`() -> `candidate`
- `firmware_esp_idf_build_bootloader_cmakefiles_cmakeconfigurelog`() -> `candidate`
- `firmware_esp_idf_build_bootloader_cmakefiles_3_31_6_compileridc_cmakeccompilerid`() -> `candidate`
- `firmware_esp_idf_build_bootloader_cmakefiles_3_31_6_compileridcxx_cmakecxxcompilerid`() -> `candidate`
- `firmware_esp_idf_build_cmakefiles_bootloader_dir_labels`() -> `candidate`
- `firmware_handoff_digital_handoff_ingest`() -> `candidate`
- `firmware_hal_register_validation`() -> `candidate`
- `firmware_hal_register_validation_2`() -> `candidate`
- `firmware_hal_register_validation_debug`() -> `candidate`
- `firmware_hal_registers`() -> `candidate`
- `firmware_hal_registers_debug`() -> `candidate`
- `firmware_hal_registers_summary`() -> `candidate`
- `firmware_drivers_driver_scaffold`() -> `candidate`
- `firmware_drivers_driver_scaffold_debug`() -> `candidate`
- `firmware_drivers_driver_scaffold_summary`() -> `candidate`
