# System Software Unit Tests

- Generated at: 2026-09-16T17:44:06.623195+00:00
- Source workflow id: 0511e849-df80-4dfc-bb15-c5bf235318a2

## Files

- `system/software/tests/sdk/sdk_tests.rs`
- `system/software/tests/services/service_tests.rs`
- `system/software/tests/apps/control_service_smoke.rs`
- `system/software/tests/apps/diagnostics_smoke.rs`
- `system/software/tests/apps/demo_cli_smoke.rs`
