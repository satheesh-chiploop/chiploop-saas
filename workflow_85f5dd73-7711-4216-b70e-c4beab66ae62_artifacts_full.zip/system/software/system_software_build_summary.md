# System Software Build System

- Generated at: 2026-09-16T17:44:04.919256+00:00
- Source workflow id: 0511e849-df80-4dfc-bb15-c5bf235318a2

## Workspace members

- `sdk/physical_ai_product`
- `services`
- `adapter/physical_ai_product_adapter`
- `apps/control_service`
- `apps/diagnostics`
- `apps/demo_cli`
- `tools/reg_viewer`
- `tools/diag_cli`

## Files

- `system/software/Cargo.toml`
- `system/software/Makefile`
- `system/software/build_plan.json`
