# Digital DQA Summary
- workflow_id: `2cf2f2f0-e33c-4c82-ad93-2a09cd848cc4`
- status: `failed`
- rtl files: `4`
- warning count: `1`

## Stage Status
- rtl_lint: `pass`
- cdc: `warning`
- reset_integrity: `pass`
- synthesis_readiness: `failed`

## Blocking Issues
- yosys_synthesis_errors
