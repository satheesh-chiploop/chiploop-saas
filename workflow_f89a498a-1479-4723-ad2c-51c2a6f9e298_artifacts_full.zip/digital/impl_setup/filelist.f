/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/f89a498a-1479-4723-ad2c-51c2a6f9e298/32e6ab3f-c7a7-461a-a085-321e4fe60637/digital/system/imported_rtl/temp_sensor_adc_model.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/f89a498a-1479-4723-ad2c-51c2a6f9e298/32e6ab3f-c7a7-461a-a085-321e4fe60637/digital/system/imported_rtl/temp_monitor_digital.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/f89a498a-1479-4723-ad2c-51c2a6f9e298/32e6ab3f-c7a7-461a-a085-321e4fe60637/digital/system/imported_rtl/temp_monitor_soc_phys.sv
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/f89a498a-1479-4723-ad2c-51c2a6f9e298/32e6ab3f-c7a7-461a-a085-321e4fe60637/digital/system/imported_rtl/temp_monitor_soc_sim.sv
