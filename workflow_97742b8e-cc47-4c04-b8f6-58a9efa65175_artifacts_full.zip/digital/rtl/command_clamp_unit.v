module command_clamp_unit (
    clk,
    rst_n,
    command_raw,
    response_mode_code,
    actuator_min,
    actuator_max,
    actuator_rate_limit,
    rate_limit_enable,
    safe_fallback_command,
    safe_fallback_active,
    response_accept_pulse,
    act_cmd,
    act_mode,
    act_cmd_valid,
    clamp_applied,
    rate_limit_applied
);
    input clk;
    input rst_n;
    input [15:0] command_raw;
    input [1:0] response_mode_code;
    input [15:0] actuator_min;
    input [15:0] actuator_max;
    input [15:0] actuator_rate_limit;
    input rate_limit_enable;
    input [15:0] safe_fallback_command;
    input safe_fallback_active;
    input response_accept_pulse;
    output reg [15:0] act_cmd;
    output reg [1:0] act_mode;
    output reg act_cmd_valid;
    output reg clamp_applied;
    output reg rate_limit_applied;

    reg [15:0] prev_cmd;
    reg [15:0] clamp_value;
    reg [15:0] delta_value;
    reg [15:0] next_cmd;
    reg clamp_flag;
    reg rate_flag;

    always @(*) begin
        clamp_value = command_raw;
        clamp_flag = 1'b0;
        rate_flag = 1'b0;
        if (command_raw < actuator_min) begin
            clamp_value = actuator_min;
            clamp_flag = 1'b1;
        end else if (command_raw > actuator_max) begin
            clamp_value = actuator_max;
            clamp_flag = 1'b1;
        end
        delta_value = (clamp_value >= prev_cmd) ? (clamp_value - prev_cmd) : (prev_cmd - clamp_value);
        next_cmd = clamp_value;
        if (rate_limit_enable && delta_value > actuator_rate_limit) begin
            rate_flag = 1'b1;
            if (clamp_value >= prev_cmd)
                next_cmd = prev_cmd + actuator_rate_limit;
            else
                next_cmd = prev_cmd - actuator_rate_limit;
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            act_cmd <= 16'h0000;
            act_mode <= 2'b00;
            act_cmd_valid <= 1'b0;
            clamp_applied <= 1'b0;
            rate_limit_applied <= 1'b0;
            prev_cmd <= 16'h0000;
        end else begin
            clamp_applied <= 1'b0;
            rate_limit_applied <= 1'b0;
            if (safe_fallback_active) begin
                act_cmd <= safe_fallback_command;
                act_mode <= 2'b00;
                act_cmd_valid <= 1'b1;
                prev_cmd <= safe_fallback_command;
            end else if (response_accept_pulse) begin
                act_cmd <= next_cmd;
                act_mode <= response_mode_code;
                act_cmd_valid <= 1'b1;
                clamp_applied <= clamp_flag;
                rate_limit_applied <= rate_flag;
                prev_cmd <= next_cmd;
            end else begin
                act_cmd_valid <= 1'b0;
            end
        end
    end
endmodule
