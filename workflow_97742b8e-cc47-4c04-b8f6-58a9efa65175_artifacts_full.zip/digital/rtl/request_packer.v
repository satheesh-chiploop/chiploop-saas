module request_packer (
    clk,
    rst_n,
    enable,
    clear_faults,
    stream_velocity_setpoint,
    request_sequence,
    geometry_descriptor_token,
    mode_tag,
    control_flags,
    req_ready,
    req_valid,
    req_data,
    outstanding_sequence,
    request_issued_pulse
);
    input clk;
    input rst_n;
    input enable;
    input clear_faults;
    input [15:0] stream_velocity_setpoint;
    input [15:0] request_sequence;
    input [7:0] geometry_descriptor_token;
    input [1:0] mode_tag;
    input [7:0] control_flags;
    input req_ready;
    output reg req_valid;
    output reg [63:0] req_data;
    output reg [15:0] outstanding_sequence;
    output reg request_issued_pulse;

    reg [63:0] packet_next;

    always @(*) begin
        packet_next = 64'h0000000000000000;
        packet_next[15:0] = request_sequence;
        packet_next[31:16] = stream_velocity_setpoint;
        packet_next[39:32] = geometry_descriptor_token;
        packet_next[41:40] = mode_tag;
        packet_next[49:42] = control_flags;
        packet_next[63:50] = {14{1'b0}};
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            req_valid <= 1'b0;
            req_data <= 64'h0000000000000000;
            outstanding_sequence <= 16'h0000;
            request_issued_pulse <= 1'b0;
        end else begin
            request_issued_pulse <= 1'b0;
            if (clear_faults) begin
                req_valid <= 1'b0;
            end
            if (enable && req_ready && !req_valid) begin
                req_valid <= 1'b1;
                req_data <= packet_next;
                outstanding_sequence <= request_sequence;
                request_issued_pulse <= 1'b1;
            end else if (req_valid && req_ready) begin
                req_valid <= 1'b0;
                req_data <= packet_next;
            end
            if (!enable) begin
                req_valid <= 1'b0;
            end
        end
    end
endmodule
