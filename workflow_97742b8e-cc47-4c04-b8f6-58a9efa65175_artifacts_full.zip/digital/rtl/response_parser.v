module response_parser (
    clk,
    rst_n,
    rsp_valid,
    rsp_ready,
    rsp_data,
    outstanding_sequence,
    response_timeout_limit,
    response_accept_pulse,
    response_sequence_match,
    response_sequence_observed,
    command_raw,
    response_mode_code,
    response_valid_compact,
    response_invalid_frame
);
    input clk;
    input rst_n;
    input rsp_valid;
    output rsp_ready;
    input [63:0] rsp_data;
    input [15:0] outstanding_sequence;
    input [15:0] response_timeout_limit;
    output reg response_accept_pulse;
    output reg response_sequence_match;
    output reg [15:0] response_sequence_observed;
    output reg [15:0] command_raw;
    output reg [1:0] response_mode_code;
    output reg response_valid_compact;
    output reg response_invalid_frame;

    assign rsp_ready = 1'b1;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            response_accept_pulse <= 1'b0;
            response_sequence_match <= 1'b0;
            response_sequence_observed <= 16'h0000;
            command_raw <= 16'h0000;
            response_mode_code <= 2'b00;
            response_valid_compact <= 1'b0;
            response_invalid_frame <= 1'b0;
        end else begin
            response_accept_pulse <= 1'b0;
            response_sequence_match <= 1'b0;
            response_valid_compact <= 1'b0;
            response_invalid_frame <= 1'b0;
            if (rsp_valid) begin
                response_sequence_observed <= rsp_data[15:0];
                command_raw <= rsp_data[31:16];
                response_mode_code <= rsp_data[33:32];
                if (rsp_data[63:56] == 8'hA5 && rsp_data[15:0] == outstanding_sequence) begin
                    response_sequence_match <= 1'b1;
                    response_valid_compact <= 1'b1;
                    response_accept_pulse <= 1'b1;
                end else begin
                    response_invalid_frame <= 1'b1;
                end
            end
        end
    end
endmodule
