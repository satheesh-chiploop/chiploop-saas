module safety_watchdog (
    clk,
    rst_n,
    enable,
    clear_faults,
    request_issued_pulse,
    response_accept_pulse,
    response_sequence_match,
    response_invalid_frame,
    response_timeout_limit,
    fault_stale,
    fault_timeout,
    fault_invalid,
    safe_fallback_active,
    status_valid,
    diag_status_word
);
    input clk;
    input rst_n;
    input enable;
    input clear_faults;
    input request_issued_pulse;
    input response_accept_pulse;
    input response_sequence_match;
    input response_invalid_frame;
    input [15:0] response_timeout_limit;
    output reg fault_stale;
    output reg fault_timeout;
    output reg fault_invalid;
    output reg safe_fallback_active;
    output reg status_valid;
    output reg [31:0] diag_status_word;
    reg [15:0] timeout_count;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            fault_stale <= 1'b0;
            fault_timeout <= 1'b0;
            fault_invalid <= 1'b0;
            safe_fallback_active <= 1'b1;
            status_valid <= 1'b0;
            diag_status_word <= 32'h00000000;
            timeout_count <= 16'h0000;
        end else begin
            status_valid <= 1'b1;
            if (clear_faults && enable) begin
                fault_stale <= 1'b0;
                fault_timeout <= 1'b0;
                fault_invalid <= 1'b0;
            end
            if (request_issued_pulse) begin
                timeout_count <= 16'h0000;
            end else if (enable && !response_accept_pulse && timeout_count != 16'hFFFF) begin
                timeout_count <= timeout_count + 16'h0001;
            end
            if (response_invalid_frame) begin
                fault_invalid <= 1'b1;
            end
            if (response_accept_pulse) begin
                timeout_count <= 16'h0000;
            end
            if (enable && response_invalid_frame) begin
                safe_fallback_active <= 1'b1;
            end else if (enable && response_sequence_match && response_accept_pulse) begin
                safe_fallback_active <= 1'b0;
            end
            if (enable && response_sequence_match && response_accept_pulse) begin
                fault_stale <= 1'b0;
            end
            if (enable && !response_sequence_match && response_accept_pulse) begin
                fault_stale <= 1'b1;
                safe_fallback_active <= 1'b1;
            end
            if (enable && response_timeout_limit != 16'h0000 && timeout_count >= response_timeout_limit) begin
                fault_timeout <= 1'b1;
                safe_fallback_active <= 1'b1;
            end
            diag_status_word <= {12'h000, safe_fallback_active, fault_invalid, fault_timeout, fault_stale, enable, status_valid, 1'b0, 1'b0, 12'b0};
        end
    end
endmodule
