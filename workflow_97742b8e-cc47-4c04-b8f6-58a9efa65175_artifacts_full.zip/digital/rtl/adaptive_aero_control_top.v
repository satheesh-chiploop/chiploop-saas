module adaptive_aero_control_top (
    clk,
    rst_n,
    cfg_valid,
    cfg_ready,
    cfg_we,
    cfg_addr,
    cfg_wdata,
    cfg_rdata,
    cfg_rvalid,
    req_valid,
    req_ready,
    req_data,
    rsp_valid,
    rsp_ready,
    rsp_data,
    act_cmd_valid,
    act_cmd,
    act_mode,
    status_valid,
    fault_stale,
    fault_timeout,
    fault_invalid,
    safe_fallback_active
);
    input clk;
    input rst_n;
    input cfg_valid;
    output cfg_ready;
    input cfg_we;
    input [7:0] cfg_addr;
    input [31:0] cfg_wdata;
    output [31:0] cfg_rdata;
    output cfg_rvalid;
    output req_valid;
    input req_ready;
    output [63:0] req_data;
    input rsp_valid;
    output rsp_ready;
    input [63:0] rsp_data;
    output act_cmd_valid;
    output [15:0] act_cmd;
    output [1:0] act_mode;
    output status_valid;
    output fault_stale;
    output fault_timeout;
    output fault_invalid;
    output safe_fallback_active;
wire enable;
wire clear_faults;
wire [15:0] stream_velocity_setpoint;
wire [15:0] request_sequence;
wire [15:0] response_timeout_limit;
wire [15:0] actuator_min;
wire [15:0] actuator_max;
wire [15:0] actuator_rate_limit;
wire rate_limit_enable;
wire [15:0] safe_fallback_command;
wire [7:0] geometry_descriptor_token;
wire [1:0] mode_tag;
wire [7:0] control_flags;
wire [15:0] outstanding_sequence;
wire request_issued_pulse;
wire response_accept_pulse;
wire response_sequence_match;
    wire [15:0] response_sequence_observed;
wire [15:0] command_raw;
wire [1:0] response_mode_code;
    wire response_valid_compact;
wire response_invalid_frame;
wire [31:0] diag_status_word;
wire status_valid_i;
wire fault_stale_i;
wire fault_timeout_i;
wire fault_invalid_i;
wire safe_fallback_active_i;
    wire [15:0] act_cmd_int;
    wire [1:0] act_mode_int;
    wire act_cmd_valid_int;
    wire clamp_applied;
    wire rate_limit_applied;

    assign status_valid = status_valid_i;
    assign fault_stale = fault_stale_i;
    assign fault_timeout = fault_timeout_i;
    assign fault_invalid = fault_invalid_i;
    assign safe_fallback_active = safe_fallback_active_i;
    assign act_cmd = act_cmd_int;
    assign act_mode = act_mode_int;
    assign act_cmd_valid = act_cmd_valid_int;

    host_transport_adapter u_host_transport_adapter (
        .clk(clk),
        .rst_n(rst_n),
        .cfg_valid(cfg_valid),
        .cfg_ready(cfg_ready),
        .cfg_we(cfg_we),
        .cfg_addr(cfg_addr),
        .cfg_wdata(cfg_wdata),
        .cfg_rdata(cfg_rdata),
        .cfg_rvalid(cfg_rvalid),
        .enable(enable),
        .clear_faults(clear_faults),
        .stream_velocity_setpoint(stream_velocity_setpoint),
        .request_sequence(request_sequence),
        .response_timeout_limit(response_timeout_limit),
        .actuator_min(actuator_min),
        .actuator_max(actuator_max),
        .actuator_rate_limit(actuator_rate_limit),
        .rate_limit_enable(rate_limit_enable),
        .safe_fallback_command(safe_fallback_command),
        .geometry_descriptor_token(geometry_descriptor_token),
        .mode_tag(mode_tag),
        .control_flags(control_flags),
        .diag_status_word(diag_status_word),
        .fault_stale_i(fault_stale_i),
        .fault_timeout_i(fault_timeout_i),
        .fault_invalid_i(fault_invalid_i),
        .safe_fallback_active_i(safe_fallback_active_i)
    );

    request_packer u_request_packer (
        .clk(clk),
        .rst_n(rst_n),
        .enable(enable),
        .clear_faults(clear_faults),
        .stream_velocity_setpoint(stream_velocity_setpoint),
        .request_sequence(request_sequence),
        .geometry_descriptor_token(geometry_descriptor_token),
        .mode_tag(mode_tag),
        .control_flags(control_flags),
        .req_ready(req_ready),
        .req_valid(req_valid),
        .req_data(req_data),
        .outstanding_sequence(outstanding_sequence),
        .request_issued_pulse(request_issued_pulse)
    );

    response_parser u_response_parser (
        .clk(clk),
        .rst_n(rst_n),
        .rsp_valid(rsp_valid),
        .rsp_ready(rsp_ready),
        .rsp_data(rsp_data),
        .outstanding_sequence(outstanding_sequence),
        .response_timeout_limit(response_timeout_limit),
        .response_accept_pulse(response_accept_pulse),
        .response_sequence_match(response_sequence_match),
        .response_sequence_observed(response_sequence_observed),
        .command_raw(command_raw),
        .response_mode_code(response_mode_code),
        .response_valid_compact(response_valid_compact),
        .response_invalid_frame(response_invalid_frame)
    );

    safety_watchdog u_safety_watchdog (
        .clk(clk),
        .rst_n(rst_n),
        .enable(enable),
        .clear_faults(clear_faults),
        .request_issued_pulse(request_issued_pulse),
        .response_accept_pulse(response_accept_pulse),
        .response_sequence_match(response_sequence_match),
        .response_invalid_frame(response_invalid_frame),
        .response_timeout_limit(response_timeout_limit),
        .fault_stale(fault_stale_i),
        .fault_timeout(fault_timeout_i),
        .fault_invalid(fault_invalid_i),
        .safe_fallback_active(safe_fallback_active_i),
        .status_valid(status_valid_i),
        .diag_status_word(diag_status_word)
    );

    command_clamp_unit u_command_clamp_unit (
        .clk(clk),
        .rst_n(rst_n),
        .command_raw(command_raw),
        .response_mode_code(response_mode_code),
        .actuator_min(actuator_min),
        .actuator_max(actuator_max),
        .actuator_rate_limit(actuator_rate_limit),
        .rate_limit_enable(rate_limit_enable),
        .safe_fallback_command(safe_fallback_command),
        .safe_fallback_active(safe_fallback_active_i),
        .response_accept_pulse(response_accept_pulse),
        .act_cmd(act_cmd_int),
        .act_mode(act_mode_int),
        .act_cmd_valid(act_cmd_valid_int),
        .clamp_applied(clamp_applied),
        .rate_limit_applied(rate_limit_applied)
    );

assign cfg_rvalid = status_valid_i;

endmodule
