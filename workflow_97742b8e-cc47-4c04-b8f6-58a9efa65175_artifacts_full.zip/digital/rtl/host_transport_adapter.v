module host_transport_adapter (
    clk,
    rst_n,
    cfg_valid,
    cfg_ready,
    cfg_we,
    cfg_addr,
    cfg_wdata,
    cfg_rdata,
    cfg_rvalid,
    enable,
    clear_faults,
    stream_velocity_setpoint,
    request_sequence,
    response_timeout_limit,
    actuator_min,
    actuator_max,
    actuator_rate_limit,
    rate_limit_enable,
    safe_fallback_command,
    geometry_descriptor_token,
    mode_tag,
    control_flags,
    diag_status_word,
    fault_stale_i,
    fault_timeout_i,
    fault_invalid_i,
    safe_fallback_active_i
);
    input clk;
    input rst_n;
    input cfg_valid;
    output cfg_ready;
    input cfg_we;
    input [7:0] cfg_addr;
    input [31:0] cfg_wdata;
    output reg [31:0] cfg_rdata;
    input cfg_rvalid;
    output reg enable;
    output reg clear_faults;
    output reg [15:0] stream_velocity_setpoint;
    output reg [15:0] request_sequence;
    output reg [15:0] response_timeout_limit;
    output reg [15:0] actuator_min;
    output reg [15:0] actuator_max;
    output reg [15:0] actuator_rate_limit;
    output reg rate_limit_enable;
    output reg [15:0] safe_fallback_command;
    output reg [7:0] geometry_descriptor_token;
    output reg [1:0] mode_tag;
    output reg [7:0] control_flags;
    input [31:0] diag_status_word;
    input fault_stale_i;
    input fault_timeout_i;
    input fault_invalid_i;
    input safe_fallback_active_i;

    reg [31:0] read_data;
    reg [31:0] read_data_next;
    reg [31:0] active_config_summary;
    reg [31:0] status_word_shadow;

    assign cfg_ready = cfg_valid;

    always @(*) begin
        read_data_next = 32'h00000000;
        active_config_summary = 32'h00000000;
        active_config_summary[0] = enable;
        active_config_summary[1] = rate_limit_enable;
        active_config_summary[2] = clear_faults;
        active_config_summary[4:3] = mode_tag;
        active_config_summary[12:5] = geometry_descriptor_token;
        active_config_summary[20:13] = control_flags;
        status_word_shadow = diag_status_word;
        case (cfg_addr)
            8'h00: read_data_next = {31'h00000000, enable};
            8'h04: read_data_next = {31'h00000000, clear_faults};
            8'h08: read_data_next = {16'h0000, stream_velocity_setpoint};
            8'h0C: read_data_next = {16'h0000, request_sequence};
            8'h10: read_data_next = {16'h0000, response_timeout_limit};
            8'h14: read_data_next = {16'h0000, actuator_min};
            8'h18: read_data_next = {16'h0000, actuator_max};
            8'h1C: read_data_next = {16'h0000, actuator_rate_limit};
            8'h20: read_data_next = {31'h00000000, rate_limit_enable};
            8'h24: read_data_next = {16'h0000, safe_fallback_command};
            8'h28: read_data_next = {24'h000000, geometry_descriptor_token};
            8'h2C: read_data_next = {30'h00000000, mode_tag};
            8'h30: read_data_next = {24'h000000, control_flags};
            8'h34: read_data_next = diag_status_word;
            8'h38: read_data_next = {31'h00000000, fault_stale_i};
            8'h3C: read_data_next = {31'h00000000, fault_timeout_i};
            8'h40: read_data_next = {31'h00000000, fault_invalid_i};
            8'h44: read_data_next = {31'h00000000, safe_fallback_active_i};
            8'h48: read_data_next = {31'h00000000, cfg_rvalid};
            8'h4C: read_data_next = 32'h00000000;
            8'h50: read_data_next = 32'h00000000;
            8'h54: read_data_next = 32'h00000000;
            8'h58: read_data_next = 32'h00000000;
            8'h5C: read_data_next = 32'h00000000;
            8'h60: read_data_next = active_config_summary;
            default: read_data_next = 32'h00000000;
        endcase
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            enable <= 1'b0;
            clear_faults <= 1'b0;
            stream_velocity_setpoint <= 16'h0000;
            request_sequence <= 16'h0000;
            response_timeout_limit <= 16'h0010;
            actuator_min <= 16'h0000;
            actuator_max <= 16'h03FF;
            actuator_rate_limit <= 16'h0010;
            rate_limit_enable <= 1'b0;
            safe_fallback_command <= 16'h0000;
            geometry_descriptor_token <= 8'h00;
            mode_tag <= 2'b00;
            control_flags <= 8'h00;
            cfg_rdata <= 32'h00000000;
            read_data <= 32'h00000000;
        end else begin
            cfg_rdata <= read_data_next;
            read_data <= read_data_next;
            if (cfg_valid && cfg_we) begin
                case (cfg_addr)
                    8'h00: enable <= cfg_wdata[0];
                    8'h04: clear_faults <= cfg_wdata[0];
                    8'h08: stream_velocity_setpoint <= cfg_wdata[15:0];
                    8'h0C: request_sequence <= cfg_wdata[15:0];
                    8'h10: response_timeout_limit <= cfg_wdata[15:0];
                    8'h14: actuator_min <= cfg_wdata[15:0];
                    8'h18: actuator_max <= cfg_wdata[15:0];
                    8'h1C: actuator_rate_limit <= cfg_wdata[15:0];
                    8'h20: rate_limit_enable <= cfg_wdata[0];
                    8'h24: safe_fallback_command <= cfg_wdata[15:0];
                    8'h28: geometry_descriptor_token <= cfg_wdata[7:0];
                    8'h2C: mode_tag <= cfg_wdata[1:0];
                    8'h30: control_flags <= cfg_wdata[7:0];
                    default: begin
                    end
                endcase
            end
        end
    end
endmodule
