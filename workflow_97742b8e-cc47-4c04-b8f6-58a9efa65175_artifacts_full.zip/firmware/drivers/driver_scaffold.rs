use crate::hal::registers::*;

pub struct DigitalSubsystemDriver;

impl DigitalSubsystemDriver {
    #[inline]
    pub const fn new() -> Self {
        Self
    }

    #[inline]
    pub fn read_cfg_enable(&self) -> u32 {
        read_cfg_enable()
    }

    #[inline]
    pub fn write_cfg_enable(&self, value: u32) {
        write_cfg_enable(value)
    }

    #[inline]
    pub fn get_cfg_enable_enable(&self) -> bool {
        get_cfg_enable_enable() != 0
    }

    #[inline]
    pub fn set_cfg_enable_enable(&self, value: bool) {
        set_cfg_enable_enable(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_cfg_enable_reserved(&self) -> bool {
        get_cfg_enable_reserved() != 0
    }

    #[inline]
    pub fn read_cfg_clear_faults(&self) -> u32 {
        read_cfg_clear_faults()
    }

    #[inline]
    pub fn write_cfg_clear_faults(&self, value: u32) {
        write_cfg_clear_faults(value)
    }

    #[inline]
    pub fn get_cfg_clear_faults_clear_faults(&self) -> bool {
        get_cfg_clear_faults_clear_faults() != 0
    }

    #[inline]
    pub fn set_cfg_clear_faults_clear_faults(&self, value: bool) {
        set_cfg_clear_faults_clear_faults(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_cfg_clear_faults_reserved(&self) -> bool {
        get_cfg_clear_faults_reserved() != 0
    }

    #[inline]
    pub fn read_cfg_stream_velocity_setpoint(&self) -> u32 {
        read_cfg_stream_velocity_setpoint()
    }

    #[inline]
    pub fn write_cfg_stream_velocity_setpoint(&self, value: u32) {
        write_cfg_stream_velocity_setpoint(value)
    }

    #[inline]
    pub fn get_cfg_stream_velocity_setpoint_setpoint(&self) -> bool {
        get_cfg_stream_velocity_setpoint_setpoint() != 0
    }

    #[inline]
    pub fn set_cfg_stream_velocity_setpoint_setpoint(&self, value: bool) {
        set_cfg_stream_velocity_setpoint_setpoint(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_cfg_stream_velocity_setpoint_reserved(&self) -> bool {
        get_cfg_stream_velocity_setpoint_reserved() != 0
    }

    #[inline]
    pub fn read_cfg_request_sequence(&self) -> u32 {
        read_cfg_request_sequence()
    }

    #[inline]
    pub fn write_cfg_request_sequence(&self, value: u32) {
        write_cfg_request_sequence(value)
    }

    #[inline]
    pub fn get_cfg_request_sequence_sequence(&self) -> bool {
        get_cfg_request_sequence_sequence() != 0
    }

    #[inline]
    pub fn set_cfg_request_sequence_sequence(&self, value: bool) {
        set_cfg_request_sequence_sequence(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_cfg_request_sequence_reserved(&self) -> bool {
        get_cfg_request_sequence_reserved() != 0
    }

    #[inline]
    pub fn read_cfg_response_timeout_limit(&self) -> u32 {
        read_cfg_response_timeout_limit()
    }

    #[inline]
    pub fn write_cfg_response_timeout_limit(&self, value: u32) {
        write_cfg_response_timeout_limit(value)
    }

    #[inline]
    pub fn get_cfg_response_timeout_limit_timeout_limit(&self) -> bool {
        get_cfg_response_timeout_limit_timeout_limit() != 0
    }

    #[inline]
    pub fn set_cfg_response_timeout_limit_timeout_limit(&self, value: bool) {
        set_cfg_response_timeout_limit_timeout_limit(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_cfg_response_timeout_limit_reserved(&self) -> bool {
        get_cfg_response_timeout_limit_reserved() != 0
    }

    #[inline]
    pub fn read_cfg_actuator_min(&self) -> u32 {
        read_cfg_actuator_min()
    }

    #[inline]
    pub fn write_cfg_actuator_min(&self, value: u32) {
        write_cfg_actuator_min(value)
    }

    #[inline]
    pub fn get_cfg_actuator_min_actuator_min(&self) -> bool {
        get_cfg_actuator_min_actuator_min() != 0
    }

    #[inline]
    pub fn set_cfg_actuator_min_actuator_min(&self, value: bool) {
        set_cfg_actuator_min_actuator_min(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_cfg_actuator_min_reserved(&self) -> bool {
        get_cfg_actuator_min_reserved() != 0
    }

    #[inline]
    pub fn read_cfg_actuator_max(&self) -> u32 {
        read_cfg_actuator_max()
    }

    #[inline]
    pub fn write_cfg_actuator_max(&self, value: u32) {
        write_cfg_actuator_max(value)
    }

    #[inline]
    pub fn get_cfg_actuator_max_actuator_max(&self) -> bool {
        get_cfg_actuator_max_actuator_max() != 0
    }

    #[inline]
    pub fn set_cfg_actuator_max_actuator_max(&self, value: bool) {
        set_cfg_actuator_max_actuator_max(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_cfg_actuator_max_reserved(&self) -> bool {
        get_cfg_actuator_max_reserved() != 0
    }

    #[inline]
    pub fn read_cfg_actuator_rate_limit(&self) -> u32 {
        read_cfg_actuator_rate_limit()
    }

    #[inline]
    pub fn write_cfg_actuator_rate_limit(&self, value: u32) {
        write_cfg_actuator_rate_limit(value)
    }

    #[inline]
    pub fn get_cfg_actuator_rate_limit_rate_limit(&self) -> bool {
        get_cfg_actuator_rate_limit_rate_limit() != 0
    }

    #[inline]
    pub fn set_cfg_actuator_rate_limit_rate_limit(&self, value: bool) {
        set_cfg_actuator_rate_limit_rate_limit(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_cfg_actuator_rate_limit_reserved(&self) -> bool {
        get_cfg_actuator_rate_limit_reserved() != 0
    }

    #[inline]
    pub fn read_cfg_rate_limit_enable(&self) -> u32 {
        read_cfg_rate_limit_enable()
    }

    #[inline]
    pub fn write_cfg_rate_limit_enable(&self, value: u32) {
        write_cfg_rate_limit_enable(value)
    }

    #[inline]
    pub fn get_cfg_rate_limit_enable_rate_limit_enable(&self) -> bool {
        get_cfg_rate_limit_enable_rate_limit_enable() != 0
    }

    #[inline]
    pub fn set_cfg_rate_limit_enable_rate_limit_enable(&self, value: bool) {
        set_cfg_rate_limit_enable_rate_limit_enable(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_cfg_rate_limit_enable_reserved(&self) -> bool {
        get_cfg_rate_limit_enable_reserved() != 0
    }

    #[inline]
    pub fn read_cfg_safe_fallback_command(&self) -> u32 {
        read_cfg_safe_fallback_command()
    }

    #[inline]
    pub fn write_cfg_safe_fallback_command(&self, value: u32) {
        write_cfg_safe_fallback_command(value)
    }

    #[inline]
    pub fn get_cfg_safe_fallback_command_fallback_command(&self) -> bool {
        get_cfg_safe_fallback_command_fallback_command() != 0
    }

    #[inline]
    pub fn set_cfg_safe_fallback_command_fallback_command(&self, value: bool) {
        set_cfg_safe_fallback_command_fallback_command(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_cfg_safe_fallback_command_reserved(&self) -> bool {
        get_cfg_safe_fallback_command_reserved() != 0
    }

    #[inline]
    pub fn read_cfg_geometry_descriptor_token(&self) -> u32 {
        read_cfg_geometry_descriptor_token()
    }

    #[inline]
    pub fn write_cfg_geometry_descriptor_token(&self, value: u32) {
        write_cfg_geometry_descriptor_token(value)
    }

    #[inline]
    pub fn get_cfg_geometry_descriptor_token_geometry_token(&self) -> bool {
        get_cfg_geometry_descriptor_token_geometry_token() != 0
    }

    #[inline]
    pub fn set_cfg_geometry_descriptor_token_geometry_token(&self, value: bool) {
        set_cfg_geometry_descriptor_token_geometry_token(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_cfg_geometry_descriptor_token_reserved(&self) -> bool {
        get_cfg_geometry_descriptor_token_reserved() != 0
    }

    #[inline]
    pub fn read_cfg_mode_tag(&self) -> u32 {
        read_cfg_mode_tag()
    }

    #[inline]
    pub fn write_cfg_mode_tag(&self, value: u32) {
        write_cfg_mode_tag(value)
    }

    #[inline]
    pub fn get_cfg_mode_tag_mode_tag(&self) -> bool {
        get_cfg_mode_tag_mode_tag() != 0
    }

    #[inline]
    pub fn set_cfg_mode_tag_mode_tag(&self, value: bool) {
        set_cfg_mode_tag_mode_tag(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_cfg_mode_tag_reserved(&self) -> bool {
        get_cfg_mode_tag_reserved() != 0
    }

    #[inline]
    pub fn read_cfg_control_flags(&self) -> u32 {
        read_cfg_control_flags()
    }

    #[inline]
    pub fn write_cfg_control_flags(&self, value: u32) {
        write_cfg_control_flags(value)
    }

    #[inline]
    pub fn get_cfg_control_flags_control_flags(&self) -> bool {
        get_cfg_control_flags_control_flags() != 0
    }

    #[inline]
    pub fn set_cfg_control_flags_control_flags(&self, value: bool) {
        set_cfg_control_flags_control_flags(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_cfg_control_flags_reserved(&self) -> bool {
        get_cfg_control_flags_reserved() != 0
    }

    #[inline]
    pub fn read_stat_diag_status_word(&self) -> u32 {
        read_stat_diag_status_word()
    }

    #[inline]
    pub fn get_stat_diag_status_word_diag_status_word(&self) -> bool {
        get_stat_diag_status_word_diag_status_word() != 0
    }

    #[inline]
    pub fn read_stat_fault_stale(&self) -> u32 {
        read_stat_fault_stale()
    }

    #[inline]
    pub fn get_stat_fault_stale_fault_stale(&self) -> bool {
        get_stat_fault_stale_fault_stale() != 0
    }

    #[inline]
    pub fn get_stat_fault_stale_reserved(&self) -> bool {
        get_stat_fault_stale_reserved() != 0
    }

    #[inline]
    pub fn read_stat_fault_timeout(&self) -> u32 {
        read_stat_fault_timeout()
    }

    #[inline]
    pub fn get_stat_fault_timeout_fault_timeout(&self) -> bool {
        get_stat_fault_timeout_fault_timeout() != 0
    }

    #[inline]
    pub fn get_stat_fault_timeout_reserved(&self) -> bool {
        get_stat_fault_timeout_reserved() != 0
    }

    #[inline]
    pub fn read_stat_fault_invalid(&self) -> u32 {
        read_stat_fault_invalid()
    }

    #[inline]
    pub fn get_stat_fault_invalid_fault_invalid(&self) -> bool {
        get_stat_fault_invalid_fault_invalid() != 0
    }

    #[inline]
    pub fn get_stat_fault_invalid_reserved(&self) -> bool {
        get_stat_fault_invalid_reserved() != 0
    }

    #[inline]
    pub fn read_stat_safe_fallback_active(&self) -> u32 {
        read_stat_safe_fallback_active()
    }

    #[inline]
    pub fn get_stat_safe_fallback_active_safe_fallback_active(&self) -> bool {
        get_stat_safe_fallback_active_safe_fallback_active() != 0
    }

    #[inline]
    pub fn get_stat_safe_fallback_active_reserved(&self) -> bool {
        get_stat_safe_fallback_active_reserved() != 0
    }

    #[inline]
    pub fn read_stat_status_valid(&self) -> u32 {
        read_stat_status_valid()
    }

    #[inline]
    pub fn get_stat_status_valid_status_valid(&self) -> bool {
        get_stat_status_valid_status_valid() != 0
    }

    #[inline]
    pub fn get_stat_status_valid_reserved(&self) -> bool {
        get_stat_status_valid_reserved() != 0
    }

    #[inline]
    pub fn read_stat_request_observed_sequence(&self) -> u32 {
        read_stat_request_observed_sequence()
    }

    #[inline]
    pub fn get_stat_request_observed_sequence_observed_sequence(&self) -> bool {
        get_stat_request_observed_sequence_observed_sequence() != 0
    }

    #[inline]
    pub fn get_stat_request_observed_sequence_reserved(&self) -> bool {
        get_stat_request_observed_sequence_reserved() != 0
    }

    #[inline]
    pub fn read_stat_response_command_raw(&self) -> u32 {
        read_stat_response_command_raw()
    }

    #[inline]
    pub fn get_stat_response_command_raw_command_raw(&self) -> bool {
        get_stat_response_command_raw_command_raw() != 0
    }

    #[inline]
    pub fn get_stat_response_command_raw_reserved(&self) -> bool {
        get_stat_response_command_raw_reserved() != 0
    }

    #[inline]
    pub fn read_stat_response_mode_code(&self) -> u32 {
        read_stat_response_mode_code()
    }

    #[inline]
    pub fn get_stat_response_mode_code_response_mode_code(&self) -> bool {
        get_stat_response_mode_code_response_mode_code() != 0
    }

    #[inline]
    pub fn get_stat_response_mode_code_reserved(&self) -> bool {
        get_stat_response_mode_code_reserved() != 0
    }

    #[inline]
    pub fn read_stat_act_cmd(&self) -> u32 {
        read_stat_act_cmd()
    }

    #[inline]
    pub fn get_stat_act_cmd_act_cmd(&self) -> bool {
        get_stat_act_cmd_act_cmd() != 0
    }

    #[inline]
    pub fn get_stat_act_cmd_reserved(&self) -> bool {
        get_stat_act_cmd_reserved() != 0
    }

    #[inline]
    pub fn read_stat_act_mode(&self) -> u32 {
        read_stat_act_mode()
    }

    #[inline]
    pub fn get_stat_act_mode_act_mode(&self) -> bool {
        get_stat_act_mode_act_mode() != 0
    }

    #[inline]
    pub fn get_stat_act_mode_reserved(&self) -> bool {
        get_stat_act_mode_reserved() != 0
    }

    #[inline]
    pub fn read_stat_active_config_summary(&self) -> u32 {
        read_stat_active_config_summary()
    }

    #[inline]
    pub fn get_stat_active_config_summary_enable(&self) -> bool {
        get_stat_active_config_summary_enable() != 0
    }

    #[inline]
    pub fn get_stat_active_config_summary_rate_limit_enable(&self) -> bool {
        get_stat_active_config_summary_rate_limit_enable() != 0
    }

    #[inline]
    pub fn get_stat_active_config_summary_clear_faults_live(&self) -> bool {
        get_stat_active_config_summary_clear_faults_live() != 0
    }

    #[inline]
    pub fn get_stat_active_config_summary_mode_tag(&self) -> bool {
        get_stat_active_config_summary_mode_tag() != 0
    }

    #[inline]
    pub fn get_stat_active_config_summary_geometry_token(&self) -> bool {
        get_stat_active_config_summary_geometry_token() != 0
    }

    #[inline]
    pub fn get_stat_active_config_summary_control_flags(&self) -> bool {
        get_stat_active_config_summary_control_flags() != 0
    }

    #[inline]
    pub fn get_stat_active_config_summary_reserved(&self) -> bool {
        get_stat_active_config_summary_reserved() != 0
    }

}
