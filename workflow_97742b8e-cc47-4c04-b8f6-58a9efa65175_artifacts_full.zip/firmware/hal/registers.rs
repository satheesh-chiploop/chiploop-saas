use core::ptr::{read_volatile, write_volatile};

pub const BASE_ADDRESS: usize = 0x00000000;

pub const CFG_ENABLE_OFFSET: usize = 0x00000000;
pub const CFG_ENABLE_ENABLE_SHIFT: u32 = 0;
pub const CFG_ENABLE_ENABLE_WIDTH: u32 = 1;
pub const CFG_ENABLE_ENABLE_MASK: u32 = 0x00000001;
pub const CFG_ENABLE_RESERVED_SHIFT: u32 = 31;
pub const CFG_ENABLE_RESERVED_WIDTH: u32 = 1;
pub const CFG_ENABLE_RESERVED_MASK: u32 = 0x80000000;
pub const CFG_CLEAR_FAULTS_OFFSET: usize = 0x00000004;
pub const CFG_CLEAR_FAULTS_CLEAR_FAULTS_SHIFT: u32 = 0;
pub const CFG_CLEAR_FAULTS_CLEAR_FAULTS_WIDTH: u32 = 1;
pub const CFG_CLEAR_FAULTS_CLEAR_FAULTS_MASK: u32 = 0x00000001;
pub const CFG_CLEAR_FAULTS_RESERVED_SHIFT: u32 = 31;
pub const CFG_CLEAR_FAULTS_RESERVED_WIDTH: u32 = 1;
pub const CFG_CLEAR_FAULTS_RESERVED_MASK: u32 = 0x80000000;
pub const CFG_STREAM_VELOCITY_SETPOINT_OFFSET: usize = 0x00000008;
pub const CFG_STREAM_VELOCITY_SETPOINT_SETPOINT_SHIFT: u32 = 15;
pub const CFG_STREAM_VELOCITY_SETPOINT_SETPOINT_WIDTH: u32 = 1;
pub const CFG_STREAM_VELOCITY_SETPOINT_SETPOINT_MASK: u32 = 0x00008000;
pub const CFG_STREAM_VELOCITY_SETPOINT_RESERVED_SHIFT: u32 = 31;
pub const CFG_STREAM_VELOCITY_SETPOINT_RESERVED_WIDTH: u32 = 1;
pub const CFG_STREAM_VELOCITY_SETPOINT_RESERVED_MASK: u32 = 0x80000000;
pub const CFG_REQUEST_SEQUENCE_OFFSET: usize = 0x0000000C;
pub const CFG_REQUEST_SEQUENCE_SEQUENCE_SHIFT: u32 = 15;
pub const CFG_REQUEST_SEQUENCE_SEQUENCE_WIDTH: u32 = 1;
pub const CFG_REQUEST_SEQUENCE_SEQUENCE_MASK: u32 = 0x00008000;
pub const CFG_REQUEST_SEQUENCE_RESERVED_SHIFT: u32 = 31;
pub const CFG_REQUEST_SEQUENCE_RESERVED_WIDTH: u32 = 1;
pub const CFG_REQUEST_SEQUENCE_RESERVED_MASK: u32 = 0x80000000;
pub const CFG_RESPONSE_TIMEOUT_LIMIT_OFFSET: usize = 0x00000010;
pub const CFG_RESPONSE_TIMEOUT_LIMIT_TIMEOUT_LIMIT_SHIFT: u32 = 15;
pub const CFG_RESPONSE_TIMEOUT_LIMIT_TIMEOUT_LIMIT_WIDTH: u32 = 1;
pub const CFG_RESPONSE_TIMEOUT_LIMIT_TIMEOUT_LIMIT_MASK: u32 = 0x00008000;
pub const CFG_RESPONSE_TIMEOUT_LIMIT_RESERVED_SHIFT: u32 = 31;
pub const CFG_RESPONSE_TIMEOUT_LIMIT_RESERVED_WIDTH: u32 = 1;
pub const CFG_RESPONSE_TIMEOUT_LIMIT_RESERVED_MASK: u32 = 0x80000000;
pub const CFG_ACTUATOR_MIN_OFFSET: usize = 0x00000014;
pub const CFG_ACTUATOR_MIN_ACTUATOR_MIN_SHIFT: u32 = 15;
pub const CFG_ACTUATOR_MIN_ACTUATOR_MIN_WIDTH: u32 = 1;
pub const CFG_ACTUATOR_MIN_ACTUATOR_MIN_MASK: u32 = 0x00008000;
pub const CFG_ACTUATOR_MIN_RESERVED_SHIFT: u32 = 31;
pub const CFG_ACTUATOR_MIN_RESERVED_WIDTH: u32 = 1;
pub const CFG_ACTUATOR_MIN_RESERVED_MASK: u32 = 0x80000000;
pub const CFG_ACTUATOR_MAX_OFFSET: usize = 0x00000018;
pub const CFG_ACTUATOR_MAX_ACTUATOR_MAX_SHIFT: u32 = 15;
pub const CFG_ACTUATOR_MAX_ACTUATOR_MAX_WIDTH: u32 = 1;
pub const CFG_ACTUATOR_MAX_ACTUATOR_MAX_MASK: u32 = 0x00008000;
pub const CFG_ACTUATOR_MAX_RESERVED_SHIFT: u32 = 31;
pub const CFG_ACTUATOR_MAX_RESERVED_WIDTH: u32 = 1;
pub const CFG_ACTUATOR_MAX_RESERVED_MASK: u32 = 0x80000000;
pub const CFG_ACTUATOR_RATE_LIMIT_OFFSET: usize = 0x0000001C;
pub const CFG_ACTUATOR_RATE_LIMIT_RATE_LIMIT_SHIFT: u32 = 15;
pub const CFG_ACTUATOR_RATE_LIMIT_RATE_LIMIT_WIDTH: u32 = 1;
pub const CFG_ACTUATOR_RATE_LIMIT_RATE_LIMIT_MASK: u32 = 0x00008000;
pub const CFG_ACTUATOR_RATE_LIMIT_RESERVED_SHIFT: u32 = 31;
pub const CFG_ACTUATOR_RATE_LIMIT_RESERVED_WIDTH: u32 = 1;
pub const CFG_ACTUATOR_RATE_LIMIT_RESERVED_MASK: u32 = 0x80000000;
pub const CFG_RATE_LIMIT_ENABLE_OFFSET: usize = 0x00000020;
pub const CFG_RATE_LIMIT_ENABLE_RATE_LIMIT_ENABLE_SHIFT: u32 = 0;
pub const CFG_RATE_LIMIT_ENABLE_RATE_LIMIT_ENABLE_WIDTH: u32 = 1;
pub const CFG_RATE_LIMIT_ENABLE_RATE_LIMIT_ENABLE_MASK: u32 = 0x00000001;
pub const CFG_RATE_LIMIT_ENABLE_RESERVED_SHIFT: u32 = 31;
pub const CFG_RATE_LIMIT_ENABLE_RESERVED_WIDTH: u32 = 1;
pub const CFG_RATE_LIMIT_ENABLE_RESERVED_MASK: u32 = 0x80000000;
pub const CFG_SAFE_FALLBACK_COMMAND_OFFSET: usize = 0x00000024;
pub const CFG_SAFE_FALLBACK_COMMAND_FALLBACK_COMMAND_SHIFT: u32 = 15;
pub const CFG_SAFE_FALLBACK_COMMAND_FALLBACK_COMMAND_WIDTH: u32 = 1;
pub const CFG_SAFE_FALLBACK_COMMAND_FALLBACK_COMMAND_MASK: u32 = 0x00008000;
pub const CFG_SAFE_FALLBACK_COMMAND_RESERVED_SHIFT: u32 = 31;
pub const CFG_SAFE_FALLBACK_COMMAND_RESERVED_WIDTH: u32 = 1;
pub const CFG_SAFE_FALLBACK_COMMAND_RESERVED_MASK: u32 = 0x80000000;
pub const CFG_GEOMETRY_DESCRIPTOR_TOKEN_OFFSET: usize = 0x00000028;
pub const CFG_GEOMETRY_DESCRIPTOR_TOKEN_GEOMETRY_TOKEN_SHIFT: u32 = 7;
pub const CFG_GEOMETRY_DESCRIPTOR_TOKEN_GEOMETRY_TOKEN_WIDTH: u32 = 1;
pub const CFG_GEOMETRY_DESCRIPTOR_TOKEN_GEOMETRY_TOKEN_MASK: u32 = 0x00000080;
pub const CFG_GEOMETRY_DESCRIPTOR_TOKEN_RESERVED_SHIFT: u32 = 31;
pub const CFG_GEOMETRY_DESCRIPTOR_TOKEN_RESERVED_WIDTH: u32 = 1;
pub const CFG_GEOMETRY_DESCRIPTOR_TOKEN_RESERVED_MASK: u32 = 0x80000000;
pub const CFG_MODE_TAG_OFFSET: usize = 0x0000002C;
pub const CFG_MODE_TAG_MODE_TAG_SHIFT: u32 = 1;
pub const CFG_MODE_TAG_MODE_TAG_WIDTH: u32 = 1;
pub const CFG_MODE_TAG_MODE_TAG_MASK: u32 = 0x00000002;
pub const CFG_MODE_TAG_RESERVED_SHIFT: u32 = 31;
pub const CFG_MODE_TAG_RESERVED_WIDTH: u32 = 1;
pub const CFG_MODE_TAG_RESERVED_MASK: u32 = 0x80000000;
pub const CFG_CONTROL_FLAGS_OFFSET: usize = 0x00000030;
pub const CFG_CONTROL_FLAGS_CONTROL_FLAGS_SHIFT: u32 = 7;
pub const CFG_CONTROL_FLAGS_CONTROL_FLAGS_WIDTH: u32 = 1;
pub const CFG_CONTROL_FLAGS_CONTROL_FLAGS_MASK: u32 = 0x00000080;
pub const CFG_CONTROL_FLAGS_RESERVED_SHIFT: u32 = 31;
pub const CFG_CONTROL_FLAGS_RESERVED_WIDTH: u32 = 1;
pub const CFG_CONTROL_FLAGS_RESERVED_MASK: u32 = 0x80000000;
pub const STAT_DIAG_STATUS_WORD_OFFSET: usize = 0x00000034;
pub const STAT_DIAG_STATUS_WORD_DIAG_STATUS_WORD_SHIFT: u32 = 31;
pub const STAT_DIAG_STATUS_WORD_DIAG_STATUS_WORD_WIDTH: u32 = 1;
pub const STAT_DIAG_STATUS_WORD_DIAG_STATUS_WORD_MASK: u32 = 0x80000000;
pub const STAT_FAULT_STALE_OFFSET: usize = 0x00000038;
pub const STAT_FAULT_STALE_FAULT_STALE_SHIFT: u32 = 0;
pub const STAT_FAULT_STALE_FAULT_STALE_WIDTH: u32 = 1;
pub const STAT_FAULT_STALE_FAULT_STALE_MASK: u32 = 0x00000001;
pub const STAT_FAULT_STALE_RESERVED_SHIFT: u32 = 31;
pub const STAT_FAULT_STALE_RESERVED_WIDTH: u32 = 1;
pub const STAT_FAULT_STALE_RESERVED_MASK: u32 = 0x80000000;
pub const STAT_FAULT_TIMEOUT_OFFSET: usize = 0x0000003C;
pub const STAT_FAULT_TIMEOUT_FAULT_TIMEOUT_SHIFT: u32 = 0;
pub const STAT_FAULT_TIMEOUT_FAULT_TIMEOUT_WIDTH: u32 = 1;
pub const STAT_FAULT_TIMEOUT_FAULT_TIMEOUT_MASK: u32 = 0x00000001;
pub const STAT_FAULT_TIMEOUT_RESERVED_SHIFT: u32 = 31;
pub const STAT_FAULT_TIMEOUT_RESERVED_WIDTH: u32 = 1;
pub const STAT_FAULT_TIMEOUT_RESERVED_MASK: u32 = 0x80000000;
pub const STAT_FAULT_INVALID_OFFSET: usize = 0x00000040;
pub const STAT_FAULT_INVALID_FAULT_INVALID_SHIFT: u32 = 0;
pub const STAT_FAULT_INVALID_FAULT_INVALID_WIDTH: u32 = 1;
pub const STAT_FAULT_INVALID_FAULT_INVALID_MASK: u32 = 0x00000001;
pub const STAT_FAULT_INVALID_RESERVED_SHIFT: u32 = 31;
pub const STAT_FAULT_INVALID_RESERVED_WIDTH: u32 = 1;
pub const STAT_FAULT_INVALID_RESERVED_MASK: u32 = 0x80000000;
pub const STAT_SAFE_FALLBACK_ACTIVE_OFFSET: usize = 0x00000044;
pub const STAT_SAFE_FALLBACK_ACTIVE_SAFE_FALLBACK_ACTIVE_SHIFT: u32 = 0;
pub const STAT_SAFE_FALLBACK_ACTIVE_SAFE_FALLBACK_ACTIVE_WIDTH: u32 = 1;
pub const STAT_SAFE_FALLBACK_ACTIVE_SAFE_FALLBACK_ACTIVE_MASK: u32 = 0x00000001;
pub const STAT_SAFE_FALLBACK_ACTIVE_RESERVED_SHIFT: u32 = 31;
pub const STAT_SAFE_FALLBACK_ACTIVE_RESERVED_WIDTH: u32 = 1;
pub const STAT_SAFE_FALLBACK_ACTIVE_RESERVED_MASK: u32 = 0x80000000;
pub const STAT_STATUS_VALID_OFFSET: usize = 0x00000048;
pub const STAT_STATUS_VALID_STATUS_VALID_SHIFT: u32 = 0;
pub const STAT_STATUS_VALID_STATUS_VALID_WIDTH: u32 = 1;
pub const STAT_STATUS_VALID_STATUS_VALID_MASK: u32 = 0x00000001;
pub const STAT_STATUS_VALID_RESERVED_SHIFT: u32 = 31;
pub const STAT_STATUS_VALID_RESERVED_WIDTH: u32 = 1;
pub const STAT_STATUS_VALID_RESERVED_MASK: u32 = 0x80000000;
pub const STAT_REQUEST_OBSERVED_SEQUENCE_OFFSET: usize = 0x0000004C;
pub const STAT_REQUEST_OBSERVED_SEQUENCE_OBSERVED_SEQUENCE_SHIFT: u32 = 15;
pub const STAT_REQUEST_OBSERVED_SEQUENCE_OBSERVED_SEQUENCE_WIDTH: u32 = 1;
pub const STAT_REQUEST_OBSERVED_SEQUENCE_OBSERVED_SEQUENCE_MASK: u32 = 0x00008000;
pub const STAT_REQUEST_OBSERVED_SEQUENCE_RESERVED_SHIFT: u32 = 31;
pub const STAT_REQUEST_OBSERVED_SEQUENCE_RESERVED_WIDTH: u32 = 1;
pub const STAT_REQUEST_OBSERVED_SEQUENCE_RESERVED_MASK: u32 = 0x80000000;
pub const STAT_RESPONSE_COMMAND_RAW_OFFSET: usize = 0x00000050;
pub const STAT_RESPONSE_COMMAND_RAW_COMMAND_RAW_SHIFT: u32 = 15;
pub const STAT_RESPONSE_COMMAND_RAW_COMMAND_RAW_WIDTH: u32 = 1;
pub const STAT_RESPONSE_COMMAND_RAW_COMMAND_RAW_MASK: u32 = 0x00008000;
pub const STAT_RESPONSE_COMMAND_RAW_RESERVED_SHIFT: u32 = 31;
pub const STAT_RESPONSE_COMMAND_RAW_RESERVED_WIDTH: u32 = 1;
pub const STAT_RESPONSE_COMMAND_RAW_RESERVED_MASK: u32 = 0x80000000;
pub const STAT_RESPONSE_MODE_CODE_OFFSET: usize = 0x00000054;
pub const STAT_RESPONSE_MODE_CODE_RESPONSE_MODE_CODE_SHIFT: u32 = 1;
pub const STAT_RESPONSE_MODE_CODE_RESPONSE_MODE_CODE_WIDTH: u32 = 1;
pub const STAT_RESPONSE_MODE_CODE_RESPONSE_MODE_CODE_MASK: u32 = 0x00000002;
pub const STAT_RESPONSE_MODE_CODE_RESERVED_SHIFT: u32 = 31;
pub const STAT_RESPONSE_MODE_CODE_RESERVED_WIDTH: u32 = 1;
pub const STAT_RESPONSE_MODE_CODE_RESERVED_MASK: u32 = 0x80000000;
pub const STAT_ACT_CMD_OFFSET: usize = 0x00000058;
pub const STAT_ACT_CMD_ACT_CMD_SHIFT: u32 = 15;
pub const STAT_ACT_CMD_ACT_CMD_WIDTH: u32 = 1;
pub const STAT_ACT_CMD_ACT_CMD_MASK: u32 = 0x00008000;
pub const STAT_ACT_CMD_RESERVED_SHIFT: u32 = 31;
pub const STAT_ACT_CMD_RESERVED_WIDTH: u32 = 1;
pub const STAT_ACT_CMD_RESERVED_MASK: u32 = 0x80000000;
pub const STAT_ACT_MODE_OFFSET: usize = 0x0000005C;
pub const STAT_ACT_MODE_ACT_MODE_SHIFT: u32 = 1;
pub const STAT_ACT_MODE_ACT_MODE_WIDTH: u32 = 1;
pub const STAT_ACT_MODE_ACT_MODE_MASK: u32 = 0x00000002;
pub const STAT_ACT_MODE_RESERVED_SHIFT: u32 = 31;
pub const STAT_ACT_MODE_RESERVED_WIDTH: u32 = 1;
pub const STAT_ACT_MODE_RESERVED_MASK: u32 = 0x80000000;
pub const STAT_ACTIVE_CONFIG_SUMMARY_OFFSET: usize = 0x00000060;
pub const STAT_ACTIVE_CONFIG_SUMMARY_ENABLE_SHIFT: u32 = 0;
pub const STAT_ACTIVE_CONFIG_SUMMARY_ENABLE_WIDTH: u32 = 1;
pub const STAT_ACTIVE_CONFIG_SUMMARY_ENABLE_MASK: u32 = 0x00000001;
pub const STAT_ACTIVE_CONFIG_SUMMARY_RATE_LIMIT_ENABLE_SHIFT: u32 = 1;
pub const STAT_ACTIVE_CONFIG_SUMMARY_RATE_LIMIT_ENABLE_WIDTH: u32 = 1;
pub const STAT_ACTIVE_CONFIG_SUMMARY_RATE_LIMIT_ENABLE_MASK: u32 = 0x00000002;
pub const STAT_ACTIVE_CONFIG_SUMMARY_CLEAR_FAULTS_LIVE_SHIFT: u32 = 2;
pub const STAT_ACTIVE_CONFIG_SUMMARY_CLEAR_FAULTS_LIVE_WIDTH: u32 = 1;
pub const STAT_ACTIVE_CONFIG_SUMMARY_CLEAR_FAULTS_LIVE_MASK: u32 = 0x00000004;
pub const STAT_ACTIVE_CONFIG_SUMMARY_MODE_TAG_SHIFT: u32 = 4;
pub const STAT_ACTIVE_CONFIG_SUMMARY_MODE_TAG_WIDTH: u32 = 1;
pub const STAT_ACTIVE_CONFIG_SUMMARY_MODE_TAG_MASK: u32 = 0x00000010;
pub const STAT_ACTIVE_CONFIG_SUMMARY_GEOMETRY_TOKEN_SHIFT: u32 = 12;
pub const STAT_ACTIVE_CONFIG_SUMMARY_GEOMETRY_TOKEN_WIDTH: u32 = 1;
pub const STAT_ACTIVE_CONFIG_SUMMARY_GEOMETRY_TOKEN_MASK: u32 = 0x00001000;
pub const STAT_ACTIVE_CONFIG_SUMMARY_CONTROL_FLAGS_SHIFT: u32 = 20;
pub const STAT_ACTIVE_CONFIG_SUMMARY_CONTROL_FLAGS_WIDTH: u32 = 1;
pub const STAT_ACTIVE_CONFIG_SUMMARY_CONTROL_FLAGS_MASK: u32 = 0x00100000;
pub const STAT_ACTIVE_CONFIG_SUMMARY_RESERVED_SHIFT: u32 = 31;
pub const STAT_ACTIVE_CONFIG_SUMMARY_RESERVED_WIDTH: u32 = 1;
pub const STAT_ACTIVE_CONFIG_SUMMARY_RESERVED_MASK: u32 = 0x80000000;

#[inline]
fn reg_ptr(offset: usize) -> *mut u32 {
    (BASE_ADDRESS + offset) as *mut u32
}

#[inline]
fn read_reg(offset: usize) -> u32 {
    unsafe { read_volatile(reg_ptr(offset) as *const u32) }
}

#[inline]
fn write_reg(offset: usize, value: u32) {
    unsafe { write_volatile(reg_ptr(offset), value) }
}

#[inline]
pub fn read_cfg_enable() -> u32 {
    read_reg(CFG_ENABLE_OFFSET)
}

#[inline]
pub fn write_cfg_enable(value: u32) {
    write_reg(CFG_ENABLE_OFFSET, value)
}

#[inline]
pub fn get_cfg_enable_enable() -> u32 {
    (read_cfg_enable() & CFG_ENABLE_ENABLE_MASK) >> CFG_ENABLE_ENABLE_SHIFT
}

#[inline]
pub fn set_cfg_enable_enable(value: u32) {
    let current = read_cfg_enable();
    let next = (current & !CFG_ENABLE_ENABLE_MASK) | ((value << CFG_ENABLE_ENABLE_SHIFT) & CFG_ENABLE_ENABLE_MASK);
    write_cfg_enable(next);
}

#[inline]
pub fn get_cfg_enable_reserved() -> u32 {
    (read_cfg_enable() & CFG_ENABLE_RESERVED_MASK) >> CFG_ENABLE_RESERVED_SHIFT
}

#[inline]
pub fn read_cfg_clear_faults() -> u32 {
    read_reg(CFG_CLEAR_FAULTS_OFFSET)
}

#[inline]
pub fn write_cfg_clear_faults(value: u32) {
    write_reg(CFG_CLEAR_FAULTS_OFFSET, value)
}

#[inline]
pub fn get_cfg_clear_faults_clear_faults() -> u32 {
    (read_cfg_clear_faults() & CFG_CLEAR_FAULTS_CLEAR_FAULTS_MASK) >> CFG_CLEAR_FAULTS_CLEAR_FAULTS_SHIFT
}

#[inline]
pub fn set_cfg_clear_faults_clear_faults(value: u32) {
    let current = read_cfg_clear_faults();
    let next = (current & !CFG_CLEAR_FAULTS_CLEAR_FAULTS_MASK) | ((value << CFG_CLEAR_FAULTS_CLEAR_FAULTS_SHIFT) & CFG_CLEAR_FAULTS_CLEAR_FAULTS_MASK);
    write_cfg_clear_faults(next);
}

#[inline]
pub fn get_cfg_clear_faults_reserved() -> u32 {
    (read_cfg_clear_faults() & CFG_CLEAR_FAULTS_RESERVED_MASK) >> CFG_CLEAR_FAULTS_RESERVED_SHIFT
}

#[inline]
pub fn read_cfg_stream_velocity_setpoint() -> u32 {
    read_reg(CFG_STREAM_VELOCITY_SETPOINT_OFFSET)
}

#[inline]
pub fn write_cfg_stream_velocity_setpoint(value: u32) {
    write_reg(CFG_STREAM_VELOCITY_SETPOINT_OFFSET, value)
}

#[inline]
pub fn get_cfg_stream_velocity_setpoint_setpoint() -> u32 {
    (read_cfg_stream_velocity_setpoint() & CFG_STREAM_VELOCITY_SETPOINT_SETPOINT_MASK) >> CFG_STREAM_VELOCITY_SETPOINT_SETPOINT_SHIFT
}

#[inline]
pub fn set_cfg_stream_velocity_setpoint_setpoint(value: u32) {
    let current = read_cfg_stream_velocity_setpoint();
    let next = (current & !CFG_STREAM_VELOCITY_SETPOINT_SETPOINT_MASK) | ((value << CFG_STREAM_VELOCITY_SETPOINT_SETPOINT_SHIFT) & CFG_STREAM_VELOCITY_SETPOINT_SETPOINT_MASK);
    write_cfg_stream_velocity_setpoint(next);
}

#[inline]
pub fn get_cfg_stream_velocity_setpoint_reserved() -> u32 {
    (read_cfg_stream_velocity_setpoint() & CFG_STREAM_VELOCITY_SETPOINT_RESERVED_MASK) >> CFG_STREAM_VELOCITY_SETPOINT_RESERVED_SHIFT
}

#[inline]
pub fn read_cfg_request_sequence() -> u32 {
    read_reg(CFG_REQUEST_SEQUENCE_OFFSET)
}

#[inline]
pub fn write_cfg_request_sequence(value: u32) {
    write_reg(CFG_REQUEST_SEQUENCE_OFFSET, value)
}

#[inline]
pub fn get_cfg_request_sequence_sequence() -> u32 {
    (read_cfg_request_sequence() & CFG_REQUEST_SEQUENCE_SEQUENCE_MASK) >> CFG_REQUEST_SEQUENCE_SEQUENCE_SHIFT
}

#[inline]
pub fn set_cfg_request_sequence_sequence(value: u32) {
    let current = read_cfg_request_sequence();
    let next = (current & !CFG_REQUEST_SEQUENCE_SEQUENCE_MASK) | ((value << CFG_REQUEST_SEQUENCE_SEQUENCE_SHIFT) & CFG_REQUEST_SEQUENCE_SEQUENCE_MASK);
    write_cfg_request_sequence(next);
}

#[inline]
pub fn get_cfg_request_sequence_reserved() -> u32 {
    (read_cfg_request_sequence() & CFG_REQUEST_SEQUENCE_RESERVED_MASK) >> CFG_REQUEST_SEQUENCE_RESERVED_SHIFT
}

#[inline]
pub fn read_cfg_response_timeout_limit() -> u32 {
    read_reg(CFG_RESPONSE_TIMEOUT_LIMIT_OFFSET)
}

#[inline]
pub fn write_cfg_response_timeout_limit(value: u32) {
    write_reg(CFG_RESPONSE_TIMEOUT_LIMIT_OFFSET, value)
}

#[inline]
pub fn get_cfg_response_timeout_limit_timeout_limit() -> u32 {
    (read_cfg_response_timeout_limit() & CFG_RESPONSE_TIMEOUT_LIMIT_TIMEOUT_LIMIT_MASK) >> CFG_RESPONSE_TIMEOUT_LIMIT_TIMEOUT_LIMIT_SHIFT
}

#[inline]
pub fn set_cfg_response_timeout_limit_timeout_limit(value: u32) {
    let current = read_cfg_response_timeout_limit();
    let next = (current & !CFG_RESPONSE_TIMEOUT_LIMIT_TIMEOUT_LIMIT_MASK) | ((value << CFG_RESPONSE_TIMEOUT_LIMIT_TIMEOUT_LIMIT_SHIFT) & CFG_RESPONSE_TIMEOUT_LIMIT_TIMEOUT_LIMIT_MASK);
    write_cfg_response_timeout_limit(next);
}

#[inline]
pub fn get_cfg_response_timeout_limit_reserved() -> u32 {
    (read_cfg_response_timeout_limit() & CFG_RESPONSE_TIMEOUT_LIMIT_RESERVED_MASK) >> CFG_RESPONSE_TIMEOUT_LIMIT_RESERVED_SHIFT
}

#[inline]
pub fn read_cfg_actuator_min() -> u32 {
    read_reg(CFG_ACTUATOR_MIN_OFFSET)
}

#[inline]
pub fn write_cfg_actuator_min(value: u32) {
    write_reg(CFG_ACTUATOR_MIN_OFFSET, value)
}

#[inline]
pub fn get_cfg_actuator_min_actuator_min() -> u32 {
    (read_cfg_actuator_min() & CFG_ACTUATOR_MIN_ACTUATOR_MIN_MASK) >> CFG_ACTUATOR_MIN_ACTUATOR_MIN_SHIFT
}

#[inline]
pub fn set_cfg_actuator_min_actuator_min(value: u32) {
    let current = read_cfg_actuator_min();
    let next = (current & !CFG_ACTUATOR_MIN_ACTUATOR_MIN_MASK) | ((value << CFG_ACTUATOR_MIN_ACTUATOR_MIN_SHIFT) & CFG_ACTUATOR_MIN_ACTUATOR_MIN_MASK);
    write_cfg_actuator_min(next);
}

#[inline]
pub fn get_cfg_actuator_min_reserved() -> u32 {
    (read_cfg_actuator_min() & CFG_ACTUATOR_MIN_RESERVED_MASK) >> CFG_ACTUATOR_MIN_RESERVED_SHIFT
}

#[inline]
pub fn read_cfg_actuator_max() -> u32 {
    read_reg(CFG_ACTUATOR_MAX_OFFSET)
}

#[inline]
pub fn write_cfg_actuator_max(value: u32) {
    write_reg(CFG_ACTUATOR_MAX_OFFSET, value)
}

#[inline]
pub fn get_cfg_actuator_max_actuator_max() -> u32 {
    (read_cfg_actuator_max() & CFG_ACTUATOR_MAX_ACTUATOR_MAX_MASK) >> CFG_ACTUATOR_MAX_ACTUATOR_MAX_SHIFT
}

#[inline]
pub fn set_cfg_actuator_max_actuator_max(value: u32) {
    let current = read_cfg_actuator_max();
    let next = (current & !CFG_ACTUATOR_MAX_ACTUATOR_MAX_MASK) | ((value << CFG_ACTUATOR_MAX_ACTUATOR_MAX_SHIFT) & CFG_ACTUATOR_MAX_ACTUATOR_MAX_MASK);
    write_cfg_actuator_max(next);
}

#[inline]
pub fn get_cfg_actuator_max_reserved() -> u32 {
    (read_cfg_actuator_max() & CFG_ACTUATOR_MAX_RESERVED_MASK) >> CFG_ACTUATOR_MAX_RESERVED_SHIFT
}

#[inline]
pub fn read_cfg_actuator_rate_limit() -> u32 {
    read_reg(CFG_ACTUATOR_RATE_LIMIT_OFFSET)
}

#[inline]
pub fn write_cfg_actuator_rate_limit(value: u32) {
    write_reg(CFG_ACTUATOR_RATE_LIMIT_OFFSET, value)
}

#[inline]
pub fn get_cfg_actuator_rate_limit_rate_limit() -> u32 {
    (read_cfg_actuator_rate_limit() & CFG_ACTUATOR_RATE_LIMIT_RATE_LIMIT_MASK) >> CFG_ACTUATOR_RATE_LIMIT_RATE_LIMIT_SHIFT
}

#[inline]
pub fn set_cfg_actuator_rate_limit_rate_limit(value: u32) {
    let current = read_cfg_actuator_rate_limit();
    let next = (current & !CFG_ACTUATOR_RATE_LIMIT_RATE_LIMIT_MASK) | ((value << CFG_ACTUATOR_RATE_LIMIT_RATE_LIMIT_SHIFT) & CFG_ACTUATOR_RATE_LIMIT_RATE_LIMIT_MASK);
    write_cfg_actuator_rate_limit(next);
}

#[inline]
pub fn get_cfg_actuator_rate_limit_reserved() -> u32 {
    (read_cfg_actuator_rate_limit() & CFG_ACTUATOR_RATE_LIMIT_RESERVED_MASK) >> CFG_ACTUATOR_RATE_LIMIT_RESERVED_SHIFT
}

#[inline]
pub fn read_cfg_rate_limit_enable() -> u32 {
    read_reg(CFG_RATE_LIMIT_ENABLE_OFFSET)
}

#[inline]
pub fn write_cfg_rate_limit_enable(value: u32) {
    write_reg(CFG_RATE_LIMIT_ENABLE_OFFSET, value)
}

#[inline]
pub fn get_cfg_rate_limit_enable_rate_limit_enable() -> u32 {
    (read_cfg_rate_limit_enable() & CFG_RATE_LIMIT_ENABLE_RATE_LIMIT_ENABLE_MASK) >> CFG_RATE_LIMIT_ENABLE_RATE_LIMIT_ENABLE_SHIFT
}

#[inline]
pub fn set_cfg_rate_limit_enable_rate_limit_enable(value: u32) {
    let current = read_cfg_rate_limit_enable();
    let next = (current & !CFG_RATE_LIMIT_ENABLE_RATE_LIMIT_ENABLE_MASK) | ((value << CFG_RATE_LIMIT_ENABLE_RATE_LIMIT_ENABLE_SHIFT) & CFG_RATE_LIMIT_ENABLE_RATE_LIMIT_ENABLE_MASK);
    write_cfg_rate_limit_enable(next);
}

#[inline]
pub fn get_cfg_rate_limit_enable_reserved() -> u32 {
    (read_cfg_rate_limit_enable() & CFG_RATE_LIMIT_ENABLE_RESERVED_MASK) >> CFG_RATE_LIMIT_ENABLE_RESERVED_SHIFT
}

#[inline]
pub fn read_cfg_safe_fallback_command() -> u32 {
    read_reg(CFG_SAFE_FALLBACK_COMMAND_OFFSET)
}

#[inline]
pub fn write_cfg_safe_fallback_command(value: u32) {
    write_reg(CFG_SAFE_FALLBACK_COMMAND_OFFSET, value)
}

#[inline]
pub fn get_cfg_safe_fallback_command_fallback_command() -> u32 {
    (read_cfg_safe_fallback_command() & CFG_SAFE_FALLBACK_COMMAND_FALLBACK_COMMAND_MASK) >> CFG_SAFE_FALLBACK_COMMAND_FALLBACK_COMMAND_SHIFT
}

#[inline]
pub fn set_cfg_safe_fallback_command_fallback_command(value: u32) {
    let current = read_cfg_safe_fallback_command();
    let next = (current & !CFG_SAFE_FALLBACK_COMMAND_FALLBACK_COMMAND_MASK) | ((value << CFG_SAFE_FALLBACK_COMMAND_FALLBACK_COMMAND_SHIFT) & CFG_SAFE_FALLBACK_COMMAND_FALLBACK_COMMAND_MASK);
    write_cfg_safe_fallback_command(next);
}

#[inline]
pub fn get_cfg_safe_fallback_command_reserved() -> u32 {
    (read_cfg_safe_fallback_command() & CFG_SAFE_FALLBACK_COMMAND_RESERVED_MASK) >> CFG_SAFE_FALLBACK_COMMAND_RESERVED_SHIFT
}

#[inline]
pub fn read_cfg_geometry_descriptor_token() -> u32 {
    read_reg(CFG_GEOMETRY_DESCRIPTOR_TOKEN_OFFSET)
}

#[inline]
pub fn write_cfg_geometry_descriptor_token(value: u32) {
    write_reg(CFG_GEOMETRY_DESCRIPTOR_TOKEN_OFFSET, value)
}

#[inline]
pub fn get_cfg_geometry_descriptor_token_geometry_token() -> u32 {
    (read_cfg_geometry_descriptor_token() & CFG_GEOMETRY_DESCRIPTOR_TOKEN_GEOMETRY_TOKEN_MASK) >> CFG_GEOMETRY_DESCRIPTOR_TOKEN_GEOMETRY_TOKEN_SHIFT
}

#[inline]
pub fn set_cfg_geometry_descriptor_token_geometry_token(value: u32) {
    let current = read_cfg_geometry_descriptor_token();
    let next = (current & !CFG_GEOMETRY_DESCRIPTOR_TOKEN_GEOMETRY_TOKEN_MASK) | ((value << CFG_GEOMETRY_DESCRIPTOR_TOKEN_GEOMETRY_TOKEN_SHIFT) & CFG_GEOMETRY_DESCRIPTOR_TOKEN_GEOMETRY_TOKEN_MASK);
    write_cfg_geometry_descriptor_token(next);
}

#[inline]
pub fn get_cfg_geometry_descriptor_token_reserved() -> u32 {
    (read_cfg_geometry_descriptor_token() & CFG_GEOMETRY_DESCRIPTOR_TOKEN_RESERVED_MASK) >> CFG_GEOMETRY_DESCRIPTOR_TOKEN_RESERVED_SHIFT
}

#[inline]
pub fn read_cfg_mode_tag() -> u32 {
    read_reg(CFG_MODE_TAG_OFFSET)
}

#[inline]
pub fn write_cfg_mode_tag(value: u32) {
    write_reg(CFG_MODE_TAG_OFFSET, value)
}

#[inline]
pub fn get_cfg_mode_tag_mode_tag() -> u32 {
    (read_cfg_mode_tag() & CFG_MODE_TAG_MODE_TAG_MASK) >> CFG_MODE_TAG_MODE_TAG_SHIFT
}

#[inline]
pub fn set_cfg_mode_tag_mode_tag(value: u32) {
    let current = read_cfg_mode_tag();
    let next = (current & !CFG_MODE_TAG_MODE_TAG_MASK) | ((value << CFG_MODE_TAG_MODE_TAG_SHIFT) & CFG_MODE_TAG_MODE_TAG_MASK);
    write_cfg_mode_tag(next);
}

#[inline]
pub fn get_cfg_mode_tag_reserved() -> u32 {
    (read_cfg_mode_tag() & CFG_MODE_TAG_RESERVED_MASK) >> CFG_MODE_TAG_RESERVED_SHIFT
}

#[inline]
pub fn read_cfg_control_flags() -> u32 {
    read_reg(CFG_CONTROL_FLAGS_OFFSET)
}

#[inline]
pub fn write_cfg_control_flags(value: u32) {
    write_reg(CFG_CONTROL_FLAGS_OFFSET, value)
}

#[inline]
pub fn get_cfg_control_flags_control_flags() -> u32 {
    (read_cfg_control_flags() & CFG_CONTROL_FLAGS_CONTROL_FLAGS_MASK) >> CFG_CONTROL_FLAGS_CONTROL_FLAGS_SHIFT
}

#[inline]
pub fn set_cfg_control_flags_control_flags(value: u32) {
    let current = read_cfg_control_flags();
    let next = (current & !CFG_CONTROL_FLAGS_CONTROL_FLAGS_MASK) | ((value << CFG_CONTROL_FLAGS_CONTROL_FLAGS_SHIFT) & CFG_CONTROL_FLAGS_CONTROL_FLAGS_MASK);
    write_cfg_control_flags(next);
}

#[inline]
pub fn get_cfg_control_flags_reserved() -> u32 {
    (read_cfg_control_flags() & CFG_CONTROL_FLAGS_RESERVED_MASK) >> CFG_CONTROL_FLAGS_RESERVED_SHIFT
}

#[inline]
pub fn read_stat_diag_status_word() -> u32 {
    read_reg(STAT_DIAG_STATUS_WORD_OFFSET)
}

#[inline]
pub fn get_stat_diag_status_word_diag_status_word() -> u32 {
    (read_stat_diag_status_word() & STAT_DIAG_STATUS_WORD_DIAG_STATUS_WORD_MASK) >> STAT_DIAG_STATUS_WORD_DIAG_STATUS_WORD_SHIFT
}

#[inline]
pub fn read_stat_fault_stale() -> u32 {
    read_reg(STAT_FAULT_STALE_OFFSET)
}

#[inline]
pub fn get_stat_fault_stale_fault_stale() -> u32 {
    (read_stat_fault_stale() & STAT_FAULT_STALE_FAULT_STALE_MASK) >> STAT_FAULT_STALE_FAULT_STALE_SHIFT
}

#[inline]
pub fn get_stat_fault_stale_reserved() -> u32 {
    (read_stat_fault_stale() & STAT_FAULT_STALE_RESERVED_MASK) >> STAT_FAULT_STALE_RESERVED_SHIFT
}

#[inline]
pub fn read_stat_fault_timeout() -> u32 {
    read_reg(STAT_FAULT_TIMEOUT_OFFSET)
}

#[inline]
pub fn get_stat_fault_timeout_fault_timeout() -> u32 {
    (read_stat_fault_timeout() & STAT_FAULT_TIMEOUT_FAULT_TIMEOUT_MASK) >> STAT_FAULT_TIMEOUT_FAULT_TIMEOUT_SHIFT
}

#[inline]
pub fn get_stat_fault_timeout_reserved() -> u32 {
    (read_stat_fault_timeout() & STAT_FAULT_TIMEOUT_RESERVED_MASK) >> STAT_FAULT_TIMEOUT_RESERVED_SHIFT
}

#[inline]
pub fn read_stat_fault_invalid() -> u32 {
    read_reg(STAT_FAULT_INVALID_OFFSET)
}

#[inline]
pub fn get_stat_fault_invalid_fault_invalid() -> u32 {
    (read_stat_fault_invalid() & STAT_FAULT_INVALID_FAULT_INVALID_MASK) >> STAT_FAULT_INVALID_FAULT_INVALID_SHIFT
}

#[inline]
pub fn get_stat_fault_invalid_reserved() -> u32 {
    (read_stat_fault_invalid() & STAT_FAULT_INVALID_RESERVED_MASK) >> STAT_FAULT_INVALID_RESERVED_SHIFT
}

#[inline]
pub fn read_stat_safe_fallback_active() -> u32 {
    read_reg(STAT_SAFE_FALLBACK_ACTIVE_OFFSET)
}

#[inline]
pub fn get_stat_safe_fallback_active_safe_fallback_active() -> u32 {
    (read_stat_safe_fallback_active() & STAT_SAFE_FALLBACK_ACTIVE_SAFE_FALLBACK_ACTIVE_MASK) >> STAT_SAFE_FALLBACK_ACTIVE_SAFE_FALLBACK_ACTIVE_SHIFT
}

#[inline]
pub fn get_stat_safe_fallback_active_reserved() -> u32 {
    (read_stat_safe_fallback_active() & STAT_SAFE_FALLBACK_ACTIVE_RESERVED_MASK) >> STAT_SAFE_FALLBACK_ACTIVE_RESERVED_SHIFT
}

#[inline]
pub fn read_stat_status_valid() -> u32 {
    read_reg(STAT_STATUS_VALID_OFFSET)
}

#[inline]
pub fn get_stat_status_valid_status_valid() -> u32 {
    (read_stat_status_valid() & STAT_STATUS_VALID_STATUS_VALID_MASK) >> STAT_STATUS_VALID_STATUS_VALID_SHIFT
}

#[inline]
pub fn get_stat_status_valid_reserved() -> u32 {
    (read_stat_status_valid() & STAT_STATUS_VALID_RESERVED_MASK) >> STAT_STATUS_VALID_RESERVED_SHIFT
}

#[inline]
pub fn read_stat_request_observed_sequence() -> u32 {
    read_reg(STAT_REQUEST_OBSERVED_SEQUENCE_OFFSET)
}

#[inline]
pub fn get_stat_request_observed_sequence_observed_sequence() -> u32 {
    (read_stat_request_observed_sequence() & STAT_REQUEST_OBSERVED_SEQUENCE_OBSERVED_SEQUENCE_MASK) >> STAT_REQUEST_OBSERVED_SEQUENCE_OBSERVED_SEQUENCE_SHIFT
}

#[inline]
pub fn get_stat_request_observed_sequence_reserved() -> u32 {
    (read_stat_request_observed_sequence() & STAT_REQUEST_OBSERVED_SEQUENCE_RESERVED_MASK) >> STAT_REQUEST_OBSERVED_SEQUENCE_RESERVED_SHIFT
}

#[inline]
pub fn read_stat_response_command_raw() -> u32 {
    read_reg(STAT_RESPONSE_COMMAND_RAW_OFFSET)
}

#[inline]
pub fn get_stat_response_command_raw_command_raw() -> u32 {
    (read_stat_response_command_raw() & STAT_RESPONSE_COMMAND_RAW_COMMAND_RAW_MASK) >> STAT_RESPONSE_COMMAND_RAW_COMMAND_RAW_SHIFT
}

#[inline]
pub fn get_stat_response_command_raw_reserved() -> u32 {
    (read_stat_response_command_raw() & STAT_RESPONSE_COMMAND_RAW_RESERVED_MASK) >> STAT_RESPONSE_COMMAND_RAW_RESERVED_SHIFT
}

#[inline]
pub fn read_stat_response_mode_code() -> u32 {
    read_reg(STAT_RESPONSE_MODE_CODE_OFFSET)
}

#[inline]
pub fn get_stat_response_mode_code_response_mode_code() -> u32 {
    (read_stat_response_mode_code() & STAT_RESPONSE_MODE_CODE_RESPONSE_MODE_CODE_MASK) >> STAT_RESPONSE_MODE_CODE_RESPONSE_MODE_CODE_SHIFT
}

#[inline]
pub fn get_stat_response_mode_code_reserved() -> u32 {
    (read_stat_response_mode_code() & STAT_RESPONSE_MODE_CODE_RESERVED_MASK) >> STAT_RESPONSE_MODE_CODE_RESERVED_SHIFT
}

#[inline]
pub fn read_stat_act_cmd() -> u32 {
    read_reg(STAT_ACT_CMD_OFFSET)
}

#[inline]
pub fn get_stat_act_cmd_act_cmd() -> u32 {
    (read_stat_act_cmd() & STAT_ACT_CMD_ACT_CMD_MASK) >> STAT_ACT_CMD_ACT_CMD_SHIFT
}

#[inline]
pub fn get_stat_act_cmd_reserved() -> u32 {
    (read_stat_act_cmd() & STAT_ACT_CMD_RESERVED_MASK) >> STAT_ACT_CMD_RESERVED_SHIFT
}

#[inline]
pub fn read_stat_act_mode() -> u32 {
    read_reg(STAT_ACT_MODE_OFFSET)
}

#[inline]
pub fn get_stat_act_mode_act_mode() -> u32 {
    (read_stat_act_mode() & STAT_ACT_MODE_ACT_MODE_MASK) >> STAT_ACT_MODE_ACT_MODE_SHIFT
}

#[inline]
pub fn get_stat_act_mode_reserved() -> u32 {
    (read_stat_act_mode() & STAT_ACT_MODE_RESERVED_MASK) >> STAT_ACT_MODE_RESERVED_SHIFT
}

#[inline]
pub fn read_stat_active_config_summary() -> u32 {
    read_reg(STAT_ACTIVE_CONFIG_SUMMARY_OFFSET)
}

#[inline]
pub fn get_stat_active_config_summary_enable() -> u32 {
    (read_stat_active_config_summary() & STAT_ACTIVE_CONFIG_SUMMARY_ENABLE_MASK) >> STAT_ACTIVE_CONFIG_SUMMARY_ENABLE_SHIFT
}

#[inline]
pub fn get_stat_active_config_summary_rate_limit_enable() -> u32 {
    (read_stat_active_config_summary() & STAT_ACTIVE_CONFIG_SUMMARY_RATE_LIMIT_ENABLE_MASK) >> STAT_ACTIVE_CONFIG_SUMMARY_RATE_LIMIT_ENABLE_SHIFT
}

#[inline]
pub fn get_stat_active_config_summary_clear_faults_live() -> u32 {
    (read_stat_active_config_summary() & STAT_ACTIVE_CONFIG_SUMMARY_CLEAR_FAULTS_LIVE_MASK) >> STAT_ACTIVE_CONFIG_SUMMARY_CLEAR_FAULTS_LIVE_SHIFT
}

#[inline]
pub fn get_stat_active_config_summary_mode_tag() -> u32 {
    (read_stat_active_config_summary() & STAT_ACTIVE_CONFIG_SUMMARY_MODE_TAG_MASK) >> STAT_ACTIVE_CONFIG_SUMMARY_MODE_TAG_SHIFT
}

#[inline]
pub fn get_stat_active_config_summary_geometry_token() -> u32 {
    (read_stat_active_config_summary() & STAT_ACTIVE_CONFIG_SUMMARY_GEOMETRY_TOKEN_MASK) >> STAT_ACTIVE_CONFIG_SUMMARY_GEOMETRY_TOKEN_SHIFT
}

#[inline]
pub fn get_stat_active_config_summary_control_flags() -> u32 {
    (read_stat_active_config_summary() & STAT_ACTIVE_CONFIG_SUMMARY_CONTROL_FLAGS_MASK) >> STAT_ACTIVE_CONFIG_SUMMARY_CONTROL_FLAGS_SHIFT
}

#[inline]
pub fn get_stat_active_config_summary_reserved() -> u32 {
    (read_stat_active_config_summary() & STAT_ACTIVE_CONFIG_SUMMARY_RESERVED_MASK) >> STAT_ACTIVE_CONFIG_SUMMARY_RESERVED_SHIFT
}

