# firmware/integration_contract.md

## Contract overview
- This contract defines the host-side SPI device layer and portable driver service for `intelligent_active_aerodynamics_controller` using the approved partition and existing RTL register collateral.
- The target refinement is **portable_only** for `ulx3s_ecp5_45f` with **external host** deployment architecture; no deployable binary is claimed because the platform contract gate is not ready.
- Hardware-facing scope is limited to the FPGA register/sideband contract and SPI transport abstraction; geometry is parsed and validated in software, and the FPGA receives only a bounded descriptor/token.
- The interface set covers software-to-software geometry ingestion, software-to-GPU operating condition streaming, FPGA-to-GPU request/response metadata, FPGA-to-CPU control/status, FPGA-to-actuator command output, and FPGA-to-supervisor safety status.
- The contract preserves safety behavior for stale-data rejection, timeout fallback, command clamping, and safe fallback activation.
- The portable driver service must expose versioned APIs, deterministic error codes, logging, and validation traceability for acceptance gating.
- Ownership is split so that firmware owns FPGA-side behavior and status generation, while system/host software owns parsing, transport selection, orchestration, and validation.

## Contract version + compatibility policy
- **Contract schema:** `chiploop.application_intelligence.target_refinement.v1`
- **Contract version:** `1.0.0`
- **Compatibility policy:**
  - **Backward compatible** for additive interface fields, status bits, and non-breaking log extensions.
  - **Breaking changes** require a major version bump and a new compatibility declaration.
  - FPGA register field meanings from existing RTL collateral are treated as stable unless explicitly revved.
  - The host transport is **not selected** yet; a transport selection must not change payload semantics or status meanings.

## Interfaces

### Interface summary

| Interface | Direction | Payload | Ownership | Notes |
|---|---|---|---|---|
| `geometry_input` | software -> software | STL file from DrivAerML reference geometry | System/Host software | Parsed and validated in software; FPGA receives only bounded descriptor/token, not raw geometry tensors. |
| `operating_condition_input` | software -> gpu_service | `stream_velocity_mps` and control flags | System/Host software | Must support 20 to 55 m/s across the full operating envelope. |
| `request_response_link` | fpga -> gpu_service | compact 64-bit request/response metadata | Firmware / FPGA-side contract | Contains sequence, descriptor token, mode flags, and compact command/quality metadata only. |
| `control_status_bus` | fpga -> cpu_software | freshness, timeout, clamp, and fallback status bits | Firmware / FPGA-side contract | Used for logging, supervision, and verification traceability. |
| `actuator_command_output` | fpga -> actuator_subsystem | clamped safe control command plus validity/fallback status | Firmware / FPGA-side contract | Final output must honor command limits and safe fallback state. |
| `safety_status_interface` | fpga -> system_supervisor | `stale_data_detected`, `timeout_detected`, `safe_fallback_active`, `command_clamped` | Firmware / FPGA-side contract | Directly supports acceptance gates for stale rejection, timeout fallback, and clamping. |

### Portable driver service interface
The portable driver service shall expose the following host-side APIs:

| API | Purpose | Inputs | Outputs | Error handling |
|---|---|---|---|---|
| `init()` | Initialize host-side SPI device layer and register map binding | Board profile, transport config, RTL revision ID | Service handle, negotiated capability set | Returns `E_UNSUPPORTED_PLATFORM`, `E_TRANSPORT_UNAVAILABLE`, `E_VERSION_MISMATCH` |
| `submit_geometry_descriptor()` | Send validated geometry token/descriptor to FPGA-facing pipeline | Bounded geometry descriptor/token, sequence ID, mode flags | Accepted/rejected status | Returns `E_INVALID_DESCRIPTOR`, `E_RANGE`, `E_STALE_SEQUENCE` |
| `set_operating_condition()` | Update operating condition stream | `stream_velocity_mps`, control flags | Applied status | Returns `E_RANGE`, `E_BUSY`, `E_TIMEOUT` |
| `poll_control_status()` | Read FPGA control/status bus | None | Freshness, timeout, clamp, fallback bits | Returns `E_IO`, `E_TIMEOUT` |
| `read_request_response()` | Read compact request/response metadata | None | 64-bit metadata word, decode status | Returns `E_IO`, `E_CRC` if transport layer exposes it |
| `read_safety_status()` | Read safety interface status | None | `stale_data_detected`, `timeout_detected`, `safe_fallback_active`, `command_clamped` | Returns `E_IO` |
| `shutdown()` | Quiesce host-side service | None | Closed state | Best-effort; returns `E_STATE` if not initialized |

### 64-bit request/response metadata contract
The FPGA-to-GPU `request_response_link` shall be a compact 64-bit word with the following logical fields:

| Field | Width | Meaning |
|---|---:|---|
| `sequence` | 16 bits | Monotonic transaction sequence number |
| `descriptor_token` | 16 bits | Bounded geometry descriptor/token identifier |
| `mode_flags` | 8 bits | Control mode and operating flags |
| `command_meta` | 8 bits | Compact command classification or disposition |
| `quality_meta` | 8 bits | Compact quality/freshness indicator |
| `reserved` | 8 bits | Reserved, must be zero on transmit and ignored on receive unless revved |

### Control/status bit contract
The FPGA-to-CPU `control_status_bus` shall include at minimum:

| Bit/Field | Meaning |
|---|---|
| `freshness` | Indicates whether the current command/data is within freshness window |
| `timeout` | Indicates transport or response timeout condition |
| `clamp` | Indicates command was clamped to safe limits |
| `fallback` | Indicates safe fallback mode is active |

### Safety status contract
The FPGA-to-supervisor `safety_status_interface` shall include at minimum:

| Status bit | Meaning | Required action |
|---|---|---|
| `stale_data_detected` | Input data is stale | Reject stale command path and log event |
| `timeout_detected` | Response or transport timeout occurred | Enter or maintain fallback policy |
| `safe_fallback_active` | Safe fallback is currently active | Supervisor shall treat actuator output as degraded-safe |
| `command_clamped` | Command was clamped to allowed bounds | Log clamp event and preserve clamped value |

### Error code contract
The portable driver service shall use stable error codes:

| Error code | Meaning |
|---|---|
| `E_OK` | Success |
| `E_UNSUPPORTED_PLATFORM` | Board or host configuration not supported |
| `E_TRANSPORT_UNAVAILABLE` | SPI transport or host transport not present |
| `E_VERSION_MISMATCH` | RTL/register version incompatible |
| `E_INVALID_DESCRIPTOR` | Geometry token/descriptor rejected in software |
| `E_RANGE` | Operating condition out of allowed range |
| `E_STALE_SEQUENCE` | Sequence or freshness violation |
| `E_BUSY` | Target service busy or not ready |
| `E_TIMEOUT` | Transport or response timeout |
| `E_IO` | Generic I/O failure |
| `E_CRC` | Transport integrity failure if checksum/CRC is present |
| `E_STATE` | Invalid service state |

## Ownership boundaries

| Area | Firmware / FPGA | System / Host software | Validation |
|---|---|---|---|
| Geometry parsing | No ownership | Owns STL parsing, bounding, tokenization | Verifies descriptor/token formation |
| Operating condition generation | No ownership | Owns velocity stream and control flags | Verifies 20–55 m/s envelope handling |
| Transport selection | Consumes selected host transport | Selects and configures transport | Confirms transport compatibility |
| Register map / status bits | Owns semantics and stable meaning | Reads, logs, and reacts | Confirms bit accuracy and latching behavior |
| Safety fallback | Owns safe fallback activation and clamping | Observes and escalates | Confirms stale rejection and timeout fallback |
| Logging schema | Emits status-relevant events only | Aggregates host logs and traces | Confirms traceability and timestamps |
| Deployable binary claim | No claim unless gate is ready | No claim | Confirms platform contract gate status |

## Assumptions
- Existing RTL register collateral defines the stable FPGA-side status and command semantics used here.
- The host transport remains unspecified until a later selection; this contract intentionally stays transport-agnostic.
- Geometry is bounded and reduced in software before any FPGA interaction; the FPGA never receives raw STL geometry tensors.
- The actuator subsystem expects a clamped safe command and validity/fallback status, not raw optimization internals.
- The GPU service integration may be asynchronous, but the compact FPGA request/response metadata must remain deterministic and versioned.
- `ulx3s_ecp5_45f` is the selected board for refinement, but no binary is deployable until the missing `host_transport_and_board_wrapper` is completed.

## Validation hooks
- **Interface conformance tests:** Verify each API accepts only the documented inputs and returns the documented error codes.
- **Sequence/freshness tests:** Inject stale and out-of-order sequence numbers and confirm `stale_data_detected` and rejection behavior.
- **Timeout tests:** Force transport timeout and confirm `timeout_detected`, `safe_fallback_active`, and logged fallback event.
- **Clamp tests:** Drive commands beyond safe bounds and verify `command_clamped` plus bounded actuator output.
- **Range tests:** Sweep `stream_velocity_mps` from 20 to 55 m/s and confirm accepted behavior across the full envelope.
- **Version compatibility tests:** Pair the host service with mismatched RTL/register versions and confirm `E_VERSION_MISMATCH`.
- **Bitfield decode tests:** Validate the 64-bit metadata packing/unpacking against the register collateral.
- **Traceability tests:** Confirm logs contain sequence ID, descriptor token, mode flags, status bits, and terminal disposition for every transaction.
- **Gate validation:** Confirm no deployable binary is claimed unless `host_transport_and_board_wrapper` is present and the platform contract gate is green.