// ASSUMPTION: Interrupt decode is software-mediated using firmware-visible status/interrupt bits.
// ASSUMPTION: No MCU-style external vector table is generated unless the hardware contract explicitly requires one.

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum InterruptSource {
    CfgClearFaults,
    ClearFaults,
    CfgStreamVelocitySetpoint,
    Setpoint,
    StatFaultStale,
    FaultStale,
    StatFaultTimeout,
    FaultTimeout,
    StatFaultInvalid,
    FaultInvalid,
    ClearFaultsLive,
}

#[inline]
pub fn interrupt_count() -> usize {
    11
}

pub const CFG_CLEAR_FAULTS_BIT: u32 = 0;
pub const CLEAR_FAULTS_BIT: u32 = 1;
pub const CFG_STREAM_VELOCITY_SETPOINT_BIT: u32 = 2;
pub const SETPOINT_BIT: u32 = 3;
pub const STAT_FAULT_STALE_BIT: u32 = 4;
pub const FAULT_STALE_BIT: u32 = 5;
pub const STAT_FAULT_TIMEOUT_BIT: u32 = 6;
pub const FAULT_TIMEOUT_BIT: u32 = 7;
pub const STAT_FAULT_INVALID_BIT: u32 = 8;
pub const FAULT_INVALID_BIT: u32 = 9;
pub const CLEAR_FAULTS_LIVE_BIT: u32 = 10;

#[inline]
pub fn handle_cfg_clear_faults() {
    // Default ISR scaffold: replace with concrete firmware behavior as needed.
}

#[inline]
pub fn handle_clear_faults() {
    // Default ISR scaffold: replace with concrete firmware behavior as needed.
}

#[inline]
pub fn handle_cfg_stream_velocity_setpoint() {
    // Default ISR scaffold: replace with concrete firmware behavior as needed.
}

#[inline]
pub fn handle_setpoint() {
    // Default ISR scaffold: replace with concrete firmware behavior as needed.
}

#[inline]
pub fn handle_stat_fault_stale() {
    // Default ISR scaffold: replace with concrete firmware behavior as needed.
}

#[inline]
pub fn handle_fault_stale() {
    // Default ISR scaffold: replace with concrete firmware behavior as needed.
}

#[inline]
pub fn handle_stat_fault_timeout() {
    // Default ISR scaffold: replace with concrete firmware behavior as needed.
}

#[inline]
pub fn handle_fault_timeout() {
    // Default ISR scaffold: replace with concrete firmware behavior as needed.
}

#[inline]
pub fn handle_stat_fault_invalid() {
    // Default ISR scaffold: replace with concrete firmware behavior as needed.
}

#[inline]
pub fn handle_fault_invalid() {
    // Default ISR scaffold: replace with concrete firmware behavior as needed.
}

#[inline]
pub fn handle_clear_faults_live() {
    // Default ISR scaffold: replace with concrete firmware behavior as needed.
}

#[inline]
pub fn dispatch_interrupt(bit_index: u32) -> bool {
    match bit_index {
        CFG_CLEAR_FAULTS_BIT => { handle_cfg_clear_faults(); true }
        CLEAR_FAULTS_BIT => { handle_clear_faults(); true }
        CFG_STREAM_VELOCITY_SETPOINT_BIT => { handle_cfg_stream_velocity_setpoint(); true }
        SETPOINT_BIT => { handle_setpoint(); true }
        STAT_FAULT_STALE_BIT => { handle_stat_fault_stale(); true }
        FAULT_STALE_BIT => { handle_fault_stale(); true }
        STAT_FAULT_TIMEOUT_BIT => { handle_stat_fault_timeout(); true }
        FAULT_TIMEOUT_BIT => { handle_fault_timeout(); true }
        STAT_FAULT_INVALID_BIT => { handle_stat_fault_invalid(); true }
        FAULT_INVALID_BIT => { handle_fault_invalid(); true }
        CLEAR_FAULTS_LIVE_BIT => { handle_clear_faults_live(); true }
        _ => false,
    }
}
