# Coverage Point Plan

- Source: generated_from_spec
- Top module: `pwm_controller`

## Output Coverpoints
- Cover `rd_data` zero and non-zero/value-transition bins.
- Cover `pwm_out` zero and non-zero/value-transition bins.
- Cover `counter_value` zero and non-zero/value-transition bins.

## Input Coverpoints
- Cover `clk` zero and non-zero/input-stimulus bins.
- Cover `reset_n` zero and non-zero/input-stimulus bins.
- Cover `wr_en` zero and non-zero/input-stimulus bins.
- Cover `wr_addr` zero and non-zero/input-stimulus bins.
- Cover `wr_data` zero and non-zero/input-stimulus bins.
- Cover `rd_en` zero and non-zero/input-stimulus bins.
- Cover `rd_addr` zero and non-zero/input-stimulus bins.

## Cross Coverage Candidates
- Cross reset release with first observed output activity.
- Cross primary control inputs with output response bins when both are present.

## Closure Guidance
- Review uncovered bins before accepting closure.
- Add directed tests for missed bins, or mark exclusions with reviewer rationale.

## Closure Iteration 1 Coverage Points

- COV_ITER001_001: `outputs.counter_value` target bins nonzero
- COV_ITER001_002: `outputs.pwm_out` target bins nonzero
- COV_ITER001_003: `outputs.rd_data` target bins nonzero
- COV_ITER001_004: `inputs.clk` target bins zero
- COV_ITER001_005: `inputs.reset_n` target bins zero
- COV_ITER001_006: `functional_coverage_below_target` target bins unhit
- COV_ITER001_007: `code_line_coverage_below_target` target bins unhit
- COV_ITER001_008: `code_branch_coverage_below_target` target bins unhit
- COV_ITER001_009: `code_condition_coverage_below_target` target bins unhit
- COV_ITER001_010: `code_toggle_coverage_below_target` target bins unhit
