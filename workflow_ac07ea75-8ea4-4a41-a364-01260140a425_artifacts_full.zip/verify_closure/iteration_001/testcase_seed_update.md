# Testcase And Seed Update

- Iteration: 1
- Testcase intents added: 10
- Executable tests for rerun: smoke_test, constrained_random_sanity
- Seeds: 1, 2, 3, 4, 5

## Testcase Intents
- `closure_cov_001_001` -> `smoke_test` (coverage_directed_intent)
- `closure_cov_001_002` -> `smoke_test` (coverage_directed_intent)
- `closure_cov_001_003` -> `smoke_test` (coverage_directed_intent)
- `closure_cov_001_004` -> `smoke_test` (coverage_directed_intent)
- `closure_cov_001_005` -> `smoke_test` (coverage_directed_intent)
- `closure_cov_001_006` -> `smoke_test` (coverage_directed_intent)
- `closure_cov_001_007` -> `constrained_random_sanity` (code_coverage_intent)
- `closure_cov_001_008` -> `constrained_random_sanity` (code_coverage_intent)
- `closure_cov_001_009` -> `constrained_random_sanity` (code_coverage_intent)
- `closure_cov_001_010` -> `constrained_random_sanity` (code_coverage_intent)
