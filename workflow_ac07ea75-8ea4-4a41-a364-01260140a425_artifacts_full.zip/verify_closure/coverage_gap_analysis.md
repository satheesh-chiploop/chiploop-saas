# Coverage Gap Analysis

- Functional coverage: 75.0 / target 100.0%
- Code line coverage: 54.88 / target 90.0%
- Code branch coverage: 4.38 / target 80.0%
- Code condition coverage: 4.38 / target 80.0%
- Code toggle coverage: 28.97 / target 80.0%
- Gap count: 10
- Functional bin gaps: 5

## Functional Coverage Gaps
- outputs.counter_value: bins 1/2, missing nonzero, seen values [0]
- outputs.pwm_out: bins 1/2, missing nonzero, seen values [0]
- outputs.rd_data: bins 1/2, missing nonzero, seen values [0]
- inputs.clk: bins 1/2, missing zero, seen values [1]
- inputs.reset_n: bins 1/2, missing zero, seen values [1]

## Recommended Actions
- high: add_directed_tests - Coverage holes should first be mapped to explicit scenarios so closure is explainable.
- medium: increase_random_seeds - More seeds may close random-observable bins after directed gaps are handled.
- medium: review_coverage_model - Unreachable or incorrectly specified bins should be waived or corrected, not chased indefinitely.
