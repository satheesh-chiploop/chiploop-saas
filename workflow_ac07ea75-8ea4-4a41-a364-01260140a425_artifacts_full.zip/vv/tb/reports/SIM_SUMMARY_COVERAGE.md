# Simulation Summary + Coverage

- Total simulation runs: None
- Simulation pass count: None
- Simulation fail count: None
- Coverage status: missing
- Functional coverage %: None
- Coverage bins hit: None
- Coverage total bins: None
- Functional bin gaps: 0
- Code line coverage: missing
- Code branch coverage: missing
- Code condition coverage: unavailable
- Code toggle coverage: not_reported_by_verilator_lcov
- SVA/assertion status: missing
- SVA/assertion pass %: missing
- Formal status: not_enabled
- Golden model status: not_enabled
- Simulator tool: verilator
- Code coverage tool: verilator_coverage
- Formal tool: none
- Golden model tool: none

## Functional Coverage Not Met
