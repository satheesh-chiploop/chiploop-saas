# Firmware Integration Contract

## 1) Contract overview
- Defines the firmware-to-system integration contract for the full Embedded_Run chain.
- Covers API surfaces, expected behavior, logging, error reporting, versioning, and ownership boundaries.
- Establishes what firmware guarantees, what system/host software must provide, and what validation must verify.
- Defines compatibility rules for forward/backward releases and fielded deployments.
- Uses explicit, machine-checkable interfaces wherever practical.
- Requires deterministic startup, status reporting, and failure signaling.
- Treats any unspecified behavior as implementation-defined and not contractually guaranteed.

## 2) Contract version + compatibility policy
- **Contract version:** `1.0.0`
- **Versioning scheme:** `MAJOR.MINOR.PATCH`
  - **MAJOR:** incompatible contract changes
  - **MINOR:** backward-compatible additions
  - **PATCH:** clarifications, fixes, non-functional corrections
- **Compatibility policy:**
  - Firmware **must** remain backward-compatible with host software for all interfaces within the same MAJOR version.
  - Host software **may** ignore unknown optional fields or log keys added in newer MINOR versions.
  - Any removal, semantic change, or repurposing of an existing field requires a MAJOR version bump.
  - Firmware **must** expose its contract version at runtime.
  - Validation **must** reject pairings that violate MAJOR compatibility.

## 3) Interfaces

### 3.1 Runtime control and status

| Interface | Direction | Type | Contract |
|---|---:|---|---|
| `GetFirmwareInfo()` | FW -> Host | Query | Returns firmware identity, contract version, build identifier, and runtime mode. |
| `GetStatus()` | FW -> Host | Query | Returns current state, health, and active fault summary. |
| `Start()` | Host -> FW | Command | Transitions firmware from initialized/ready state into active operation. |
| `Stop()` | Host -> FW | Command | Requests orderly stop and transition to safe idle state. |
| `Reset()` | Host -> FW | Command | Requests a controlled restart; behavior depends on platform reset policy. |

### 3.2 Expected behavior

| Item | Requirement |
|---|---|
| Initialization | Firmware must complete initialization deterministically and publish readiness or failure. |
| State transitions | Firmware must reject commands that are invalid for the current state and return a defined error code. |
| Safe idle | On stop or unrecoverable fault, firmware must enter a safe idle state that does not continue normal actuation/control. |
| Idempotency | Reissuing a command that is already satisfied should either be a no-op with success or return a defined “already in requested state” code. |
| Timeout handling | If a host-visible operation cannot complete within contract timing, firmware must return a timeout error and retain a consistent state. |
| Fault handling | Fatal faults must be reported once, latched until acknowledged or reset per policy, and visible in status/logs. |

### 3.3 Error codes

| Code | Symbol | Meaning | Expected use |
|---:|---|---|---|
| 0 | `FW_OK` | Success | Operation completed successfully. |
| 1 | `FW_E_BUSY` | Busy | Requested operation cannot proceed in current state. |
| 2 | `FW_E_INVALID_STATE` | Invalid state | Command is not valid for the current state. |
| 3 | `FW_E_TIMEOUT` | Timeout | Operation exceeded allowed completion time. |
| 4 | `FW_E_UNSUPPORTED` | Unsupported | Feature, version, or request is not supported. |
| 5 | `FW_E_BAD_PARAM` | Bad parameter | Parameter validation failed. |
| 6 | `FW_E_HW_FAILURE` | Hardware failure | Underlying platform or peripheral failure detected. |
| 7 | `FW_E_INTERNAL` | Internal error | Unclassified firmware fault. |

### 3.4 Logging schema

| Field | Type | Required | Description |
|---|---|---:|---|
| `ts_us` | uint64 | yes | Monotonic timestamp in microseconds if available. |
| `level` | enum | yes | `DEBUG`, `INFO`, `WARN`, `ERROR`, `FATAL`. |
| `module` | string | yes | Firmware module or subsystem name. |
| `event` | string | yes | Stable event identifier. |
| `code` | uint32 | no | Error or status code when applicable. |
| `msg` | string | no | Human-readable summary. |
| `context` | object/map | no | Key-value details for diagnostics. |

**Logging rules**
- Event identifiers must be stable across patch releases.
- Error logs must include a code when one exists.
- Fatal conditions must generate an `ERROR` or `FATAL` log before transition to safe idle or reset, when feasible.
- Logs must not require host-side parsing of free-form text to determine essential state.

### 3.5 Versioning and identity

| Field | Requirement |
|---|---|
| Firmware semantic version | Must be reported at runtime. |
| Contract version | Must be reported at runtime. |
| Build ID | Must be unique per build or release artifact. |
| Git or source reference | Optional unless required by release process. |
| Mode | Must indicate operational mode, including boot/init/active/fault if applicable. |

### 3.6 Power modes

| Power mode | FW behavior | Host expectation |
|---|---|---|
| Active | Full firmware operation permitted. | May issue normal commands. |
| Idle | Firmware remains responsive with reduced activity. | May request resume/start if supported. |
| Sleep/Low-power | Firmware preserves required state and limits responsiveness per platform policy. | Must not assume immediate service unless contract says so. |
| Fault-safe | Firmware has detected unrecoverable condition and entered protective behavior. | Must treat as non-operational until reset or recovery policy completes. |

## 4) Ownership boundaries

| Area | Firmware owns | System/Host owns | Validation owns |
|---|---|---|---|
| Command execution | Implements command handling and state transitions. | Issues valid commands and handles returned status. | Verifies command/state matrix. |
| Status reporting | Publishes status, health, and fault indicators. | Consumes status and reacts appropriately. | Verifies completeness and correctness. |
| Error handling | Maps internal faults to contract error codes. | Interprets codes and applies recovery logic. | Verifies code stability and coverage. |
| Logging | Emits contract-defined event schema. | Collects, stores, and forwards logs. | Verifies required fields and event stability. |
| Versioning | Reports firmware and contract versions. | Enforces compatibility gating. | Verifies version policy compliance. |
| Recovery/reset behavior | Performs controlled transitions and preserves safety. | Requests reset/recovery as allowed. | Verifies safe-state and restart behavior. |

## 5) Assumptions
- Host/system software can observe and act on firmware-reported readiness and fault status.
- A safe idle or fault-safe state is defined by the platform integration, even if the exact actuation behavior is system-specific.
- Monotonic timestamps are available, or the implementation may substitute a documented alternative if unavailable.
- The release process can provide a unique build identifier.
- Validation has access to command, status, and log channels required to exercise the contract.
- Any subsystem-specific timing, electrical, or protocol details not defined here are out of scope unless added by a future contract revision.

## 6) Validation hooks
- **Version check:** Confirm runtime-reported firmware version and contract version match the release manifest.
- **Compatibility gate:** Verify host software rejects incompatible MAJOR versions and accepts compatible MINOR/PATCH updates.
- **Command/state matrix:** Exercise each command from each supported state and verify expected success or defined error code.
- **Startup readiness:** Confirm firmware publishes readiness or failure within the required boot window.
- **Fault injection:** Induce representative hardware/internal faults and verify correct error code, log event, and safe-state transition.
- **Log schema validation:** Parse emitted logs and verify required fields, stable event IDs, and error code presence when applicable.
- **Recovery/reset behavior:** Verify controlled reset returns firmware to the documented startup state and does not retain invalid operational state.
- **Power-mode behavior:** Validate behavior in each supported power mode against the published responsiveness and state-retention rules.
- **Negative testing:** Send invalid parameters, unsupported requests, and repeated commands to confirm deterministic handling.