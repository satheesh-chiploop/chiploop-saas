# Validation Report

- Co-simulation overall status: blocked_missing_inputs
- Readiness status: blocked
- Execution attempted: False
- Executed tests: 0
- Passed tests: 0
- Failed tests: 0

## Coverage
- Functional coverage: None
- RTL coverage: None
- Assertion coverage: None
- Coverage available: False

## Notes
- This report is generated directly from downstream execution and coverage artifacts.
- Missing values are reported as unavailable rather than inferred.
