#!/usr/bin/env bash
set -euo pipefail

mkdir -p firmware/validate
mkdir -p firmware/validate/verilator_obj

RTL_TOP=${RTL_TOP:-<RTL_TOP>}
RTL_DIR=${RTL_DIR:-<RTL_DIR>}
FILELIST=${FILELIST:-<FILELIST>}
FW_BUILD_CMD=${FW_BUILD_CMD:-}
VERILATOR_BUILD_CMD=${VERILATOR_BUILD_CMD:-}

if [[ -f firmware/validate/verilator_build.md ]]; then
  echo "Found firmware/validate/verilator_build.md; using project-specific guidance if available."
fi

if [[ -n "${VERILATOR_BUILD_CMD}" ]]; then
  echo "Running VERILATOR_BUILD_CMD..."
  bash -lc "${VERILATOR_BUILD_CMD}"
else
  echo "Running default Verilator build..."
  verilator --binary \
    -Wall \
    -Mdir firmware/validate/verilator_obj \
    -o firmware/validate/simv \
    -cc "${RTL_DIR}" \
    --top-module "${RTL_TOP}" \
    -f "${FILELIST}"
fi

if [[ -n "${FW_BUILD_CMD}" ]]; then
  echo "Running FW_BUILD_CMD..."
  bash -lc "${FW_BUILD_CMD}"
fi

echo "Running cocotb tests via pytest..."
pytest -q \
  --junitxml=firmware/validate/junit.xml \
  --cov-report=xml:firmware/validate/coverage.xml \
  --cov-report=term \
  --log-file=firmware/validate/cosim.log

echo "Co-simulation completed successfully."
