<!-- ASSUMPTION: The RTL build flow is driven by Verilator and cocotb/pytest, with paths and top-level names supplied by environment overrides when not known ahead of time. -->
<!-- ASSUMPTION: If firmware compilation is required for the co-simulation testbench, the build step is provided via an environment override or existing project build system. -->
<!-- ASSUMPTION: Any project-specific Verilator instructions may be present in firmware/validate/verilator_build.md and should be preferred when available. -->

# Co-simulation Runner Steps

## Prerequisites

Install or make available the following tools in `PATH`:

- Verilator
- Python 3
- `pytest`
- `cocotb`
- A C/C++ toolchain required by Verilator-generated simulation builds
- Any firmware build toolchain required by the DUT test flow, if applicable

Recommended Python packages:

```bash
python3 -m pip install --user pytest cocotb
```

If your project uses a Python virtual environment, activate it before running the steps below.

## Environment Variables

The runner supports environment overrides:

- `RTL_TOP=${RTL_TOP:-<RTL_TOP>}`
- `RTL_DIR=${RTL_DIR:-<RTL_DIR>}`
- `FILELIST=${FILELIST:-<FILELIST>}`

Optional build overrides if needed by your project:

- `FW_BUILD_CMD=${FW_BUILD_CMD:-<FW_BUILD_CMD>}`
- `VERILATOR_BUILD_CMD=${VERILATOR_BUILD_CMD:-<VERILATOR_BUILD_CMD>}`

## Run Sequence

### 1) Prepare output directory

```bash
mkdir -p firmware/validate
```

### 2) Build RTL simulation

If `firmware/validate/verilator_build.md` exists, follow it first.

Otherwise, use the project-provided Verilator build command. A generic example is:

```bash
verilator --binary \
  -Wall \
  -Mdir firmware/validate/verilator_obj \
  -o firmware/validate/simv \
  -cc "${RTL_DIR}" \
  --top-module "${RTL_TOP}" \
  --Mdir firmware/validate/verilator_obj \
  -f "${FILELIST}"
```

If your flow uses a different invocation, set `VERILATOR_BUILD_CMD` and execute it from the runner.

### 3) Build firmware, if applicable

If the co-simulation requires firmware images or artifacts, run the project build command before executing tests. Example:

```bash
${FW_BUILD_CMD}
```

If firmware is not required, this step can be skipped.

### 4) Run cocotb via pytest

Run the cocotb test suite with pytest, writing outputs under `firmware/validate/`:

```bash
pytest -q \
  --junitxml=firmware/validate/junit.xml \
  --cov-report=xml:firmware/validate/coverage.xml \
  --cov-report=term \
  --log-file=firmware/validate/cosim.log
```

If your test selection requires a specific test module or directory, add it to the pytest command via environment overrides or project conventions.

## Expected Outputs

At completion, the flow should produce one or more of the following under `firmware/validate/`:

- `cosim.log` — simulation and test log
- `junit.xml` — pytest JUnit results, if enabled
- `coverage.xml` — coverage report, if enabled
- Verilator build artifacts under `firmware/validate/verilator_obj/`
- Built simulation executable or equivalent Verilator output
- Any firmware build artifacts required by the testbench

## Notes

- Prefer the project-specific `firmware/validate/verilator_build.md` instructions whenever present.
- Keep all generated outputs under `firmware/validate/`.
- Use the same environment variables in both manual execution and automation to avoid hardcoded RTL paths or filenames.
