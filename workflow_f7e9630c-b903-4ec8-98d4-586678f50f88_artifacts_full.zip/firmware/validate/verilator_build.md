<!-- ASSUMPTION: Replace placeholders with concrete file paths before execution. -->
<!-- ASSUMPTION: Cocotb integration is driven externally through pytest/cocotb makefile flow. -->

# Verilator Build Plan

## Inputs
- RTL top module: temp_monitor_soc_sim
- RTL filelist: artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/f7e9630c-b903-4ec8-98d4-586678f50f88/8148798f-593c-41c7-adf3-0fb21f438555/digital/system/integration/system_rtl_filelist_sim.txt
- Optional include flags: <OPTIONAL_INCLUDE_FLAGS>
- Optional define flags: <OPTIONAL_DEFINE_FLAGS>
- Cocotb Python test/harness: firmware/validate/cocotb_harness.py

## Deterministic command template

verilator -cc --build --trace --top-module temp_monitor_soc_sim \
  -f artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/f7e9630c-b903-4ec8-98d4-586678f50f88/8148798f-593c-41c7-adf3-0fb21f438555/digital/system/integration/system_rtl_filelist_sim.txt \
  <OPTIONAL_INCLUDE_FLAGS> \
  <OPTIONAL_DEFINE_FLAGS> \
  

## Expected outputs
- Build directory: obj_dir/
- Generated make/build products under: obj_dir/
- Runnable binary name: obj_dir/Vtemp_monitor_soc_sim

## Notes
- Python cocotb tests are executed via pytest or cocotb makefile flow.
- Do not pass Python files to --exe.
- If firmware/ELF integration is needed, handle it via simulator memory preload or cocotb hooks.
