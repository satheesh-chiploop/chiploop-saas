module temp_monitor_digital (
    input         clk,
    input         reset_n,
    input         wr_en,
    input  [7:0]  wr_addr,
    input  [15:0] wr_data,
    input         rd_en,
    input  [7:0]  rd_addr,
    input  [11:0] adc_code,
    input         adc_valid,
    output [15:0] rd_data,
    output        sample_req,
    output        alert_irq,
    output [11:0] temp_code,
    output [11:0] threshold_code,
    output        alert_status
);

    reg  [15:0] rd_data_r;
    reg         sample_req_r;
    reg         alert_irq_r;
    reg  [11:0] temp_code_r;
    reg  [11:0] threshold_code_r;
    reg         alert_status_r;

    reg         control_enable;
    reg         control_irq_enable;

    reg         status_sample_done;
    reg         status_alert_pending;
    reg         status_adc_valid_seen;
    reg         status_busy;

    reg  [11:0] latest_temp;
    reg  [15:0] sample_count;

    reg         irq_status_alert;
    reg         irq_status_sample_done;

    reg  [11:0] prev_adc_code;
    reg         prev_adc_valid;
    reg         busy_pending;
    reg         periodic_toggle;

    wire [12:0] sum_adc;
    wire [11:0] avg_adc;
    wire        threshold_exceeded;
    wire        any_irq_status;

    assign sum_adc = {1'b0, adc_code} + {1'b0, prev_adc_code};
    assign avg_adc = sum_adc[12:1];
    assign threshold_exceeded = (temp_code_r > threshold_code_r);
    assign any_irq_status = irq_status_alert | irq_status_sample_done;

    assign rd_data = rd_data_r;
    assign sample_req = sample_req_r;
    assign alert_irq = alert_irq_r;
    assign temp_code = temp_code_r;
    assign threshold_code = threshold_code_r;
    assign alert_status = alert_status_r;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            rd_data_r <= 16'h0000;
            sample_req_r <= 1'b0;
            alert_irq_r <= 1'b0;
            temp_code_r <= 12'h000;
            threshold_code_r <= 12'h000;
            alert_status_r <= 1'b0;

            control_enable <= 1'b0;
            control_irq_enable <= 1'b0;

            status_sample_done <= 1'b0;
            status_alert_pending <= 1'b0;
            status_adc_valid_seen <= 1'b0;
            status_busy <= 1'b0;

            latest_temp <= 12'h000;
            sample_count <= 16'h0000;

            irq_status_alert <= 1'b0;
            irq_status_sample_done <= 1'b0;

            prev_adc_code <= 12'h000;
            prev_adc_valid <= 1'b0;
            busy_pending <= 1'b0;
            periodic_toggle <= 1'b0;
        end else begin
            sample_req_r <= 1'b0;

            if (wr_en) begin
                case (wr_addr)
                    8'h00: begin
                        control_enable <= wr_data[0];
                        control_irq_enable <= wr_data[2];
                        if (wr_data[1]) begin
                            sample_req_r <= 1'b1;
                            busy_pending <= 1'b1;
                            status_busy <= 1'b1;
                        end
                        if (wr_data[3]) begin
                            alert_status_r <= 1'b0;
                            status_alert_pending <= 1'b0;
                        end
                    end
                    8'h08: begin
                        threshold_code_r <= wr_data[11:0];
                    end
                    8'h18: begin
                        if (wr_data[0]) begin
                            irq_status_alert <= 1'b0;
                            alert_status_r <= 1'b0;
                            status_alert_pending <= 1'b0;
                        end
                        if (wr_data[1]) begin
                            irq_status_sample_done <= 1'b0;
                            status_sample_done <= 1'b0;
                        end
                    end
                    default: begin
                    end
                endcase
            end

            if (control_enable && !busy_pending && !status_busy) begin
                periodic_toggle <= ~periodic_toggle;
                if (periodic_toggle) begin
                    sample_req_r <= 1'b1;
                    busy_pending <= 1'b1;
                    status_busy <= 1'b1;
                end
            end

            if (adc_valid) begin
                prev_adc_code <= adc_code;
                prev_adc_valid <= 1'b1;
                status_adc_valid_seen <= 1'b1;
                status_sample_done <= 1'b1;
                irq_status_sample_done <= 1'b1;
                sample_count <= sample_count + 16'h0001;
                latest_temp <= avg_adc;
                temp_code_r <= avg_adc;
                status_busy <= 1'b0;
                busy_pending <= 1'b0;

                if (avg_adc > threshold_code_r) begin
                    alert_status_r <= 1'b1;
                    status_alert_pending <= 1'b1;
                    irq_status_alert <= 1'b1;
                end
            end

            if (status_sample_done | status_alert_pending | status_adc_valid_seen | busy_pending | status_busy) begin
                if (status_alert_pending) begin
                    alert_status_r <= 1'b1;
                end
            end

            alert_irq_r <= control_irq_enable & any_irq_status;

            if (rd_en) begin
                case (rd_addr)
                    8'h00: rd_data_r <= {12'h000, control_irq_enable, 1'b0, control_enable, 1'b0};
                    8'h04: rd_data_r <= {12'h000, status_busy, status_adc_valid_seen, status_alert_pending, status_sample_done};
                    8'h08: rd_data_r <= {4'h0, threshold_code_r};
                    8'h0C: rd_data_r <= {4'h0, latest_temp};
                    8'h10: rd_data_r <= sample_count;
                    8'h14: rd_data_r <= {14'h0000, irq_status_sample_done, irq_status_alert};
                    8'h18: rd_data_r <= 16'h0000;
                    default: rd_data_r <= 16'h0000;
                endcase
            end
        end
    end

endmodule
