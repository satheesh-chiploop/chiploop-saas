module temp_sensor_adc_model (
    input  sample_req,
    input  [15:0] sensor_temp_celsius,
    input  avdd,
    input  avss,
    output reg [11:0] adc_code,
    output reg adc_valid
);

    parameter integer GAIN_ERROR_PPM   = 0;
    parameter integer OFFSET_ERROR_LSB  = 0;
    parameter integer SAMPLE_LATENCY    = 2;

    localparam integer ADC_MIN_CODE = 0;
    localparam integer ADC_MAX_CODE = 4095;
    localparam integer TEMP_MIN_C    = -128;
    localparam integer TEMP_MAX_C    = 127;
    localparam integer TEMP_SPAN_C   = TEMP_MAX_C - TEMP_MIN_C;

    reg [15:0] temp_sampled_r;
    reg [31:0] latency_cnt_r;
    reg        conversion_pending_r;
    reg        valid_pulse_r;
    reg [31:0] temp_offset_r;
    reg [31:0] temp_span_r;
    reg [31:0] gain_num_r;
    reg signed [31:0] temp_signed_r;
    reg signed [31:0] temp_clamped_r;
    reg signed [63:0] scaled_r;
    reg signed [63:0] code_calc_r;
    reg signed [63:0] gain_scaled_r;
    reg signed [63:0] offset_scaled_r;
    reg signed [63:0] numerator_r;
    reg signed [63:0] temp_rel_r;
    reg signed [63:0] temp_rel_scaled_r;
    reg [11:0] next_code_r;

    always @(*) begin
        temp_offset_r      = 32'd128;
        temp_span_r        = 32'd255;
        gain_num_r         = 32'sd1000000 + GAIN_ERROR_PPM;
        temp_signed_r      = $signed(sensor_temp_celsius);
        temp_clamped_r     = temp_signed_r;
        scaled_r           = 64'sd0;
        code_calc_r        = 64'sd0;
        gain_scaled_r      = 64'sd0;
        offset_scaled_r    = 64'sd0;
        numerator_r        = 64'sd0;
        temp_rel_r         = 64'sd0;
        temp_rel_scaled_r  = 64'sd0;
        next_code_r        = 12'd0;

        if (temp_clamped_r < TEMP_MIN_C)
            temp_clamped_r = TEMP_MIN_C;
        else if (temp_clamped_r > TEMP_MAX_C)
            temp_clamped_r = TEMP_MAX_C;

        temp_rel_r = $signed({{32{1'b0}}, temp_clamped_r}) - $signed(64'sd0 + TEMP_MIN_C);
        temp_rel_scaled_r = temp_rel_r * 64'sd4095;
        numerator_r = temp_rel_scaled_r * $signed({1'b0, gain_num_r});
        gain_scaled_r = numerator_r / 64'sd1000000;
        offset_scaled_r = $signed({1'b0, OFFSET_ERROR_LSB}) * 64'sd1;

        code_calc_r = (gain_scaled_r / $signed({1'b0, temp_span_r})) + offset_scaled_r;

        if (code_calc_r < 0)
            next_code_r = 12'd0;
        else if (code_calc_r > 4095)
            next_code_r = 12'd4095;
        else
            next_code_r = code_calc_r[11:0];
    end

    always @(posedge sample_req or negedge avdd or negedge avss) begin
        if (!avdd || !avss) begin
            adc_code <= 12'd0;
            adc_valid <= 1'b0;
            temp_sampled_r <= 16'd0;
            latency_cnt_r <= 32'd0;
            conversion_pending_r <= 1'b0;
            valid_pulse_r <= 1'b0;
        end else begin
            temp_sampled_r <= sensor_temp_celsius;
            latency_cnt_r <= (SAMPLE_LATENCY <= 0) ? 32'd0 : SAMPLE_LATENCY[31:0];
            conversion_pending_r <= 1'b1;
            valid_pulse_r <= 1'b0;
            adc_valid <= 1'b0;
            if (SAMPLE_LATENCY <= 0) begin
                adc_code <= next_code_r;
                adc_valid <= 1'b1;
                valid_pulse_r <= 1'b1;
                conversion_pending_r <= 1'b0;
            end
        end
    end

    always @(posedge avdd or negedge avss) begin
        if (!avss) begin
            adc_code <= 12'd0;
            adc_valid <= 1'b0;
            temp_sampled_r <= 16'd0;
            latency_cnt_r <= 32'd0;
            conversion_pending_r <= 1'b0;
            valid_pulse_r <= 1'b0;
        end else begin
            if (conversion_pending_r) begin
                if (latency_cnt_r == 32'd0) begin
                    adc_code <= next_code_r;
                    adc_valid <= 1'b1;
                    valid_pulse_r <= 1'b1;
                    conversion_pending_r <= 1'b0;
                end else begin
                    latency_cnt_r <= latency_cnt_r - 32'd1;
                    adc_valid <= 1'b0;
                    valid_pulse_r <= 1'b0;
                end
            end else begin
                adc_valid <= 1'b0;
                valid_pulse_r <= 1'b0;
            end
        end
    end

endmodule
