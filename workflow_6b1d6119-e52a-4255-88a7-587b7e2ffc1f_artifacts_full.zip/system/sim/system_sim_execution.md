# System Simulation Execution Report

- Top: `temp_monitor_soc_sim`
- Tests run: 6
- Passed: 0
- Failed: 6
- Total runtime (s): 8.402
- Coverage JSON present: False
- Coverage MD present: False

## Run Matrix
- `system_smoke_test` / seed `1` → FAIL (rc=2, 1.366s)
- `system_smoke_test` / seed `2` → FAIL (rc=2, 1.381s)
- `system_smoke_test` / seed `7` → FAIL (rc=2, 1.425s)
- `integrated_input_sanity` / seed `1` → FAIL (rc=2, 1.497s)
- `integrated_input_sanity` / seed `2` → FAIL (rc=2, 1.35s)
- `integrated_input_sanity` / seed `7` → FAIL (rc=2, 1.383s)
