# Digital Executive Summary
- workflow_id: `89a2017e-48e8-46f0-8792-c2b0d88fbf8a`
- run_tag: `digital_89a2017e-48e8-46f0-8792-c2b0d88fbf8a`
- run_work_dir: `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/89a2017e-48e8-46f0-8792-c2b0d88fbf8a/72318fbc-69a4-40db-b97c-305205d34a7a/digital/arch2tapeout/digital/run_work`

## Key Metrics (best-effort parsed)
- Cell count: `171`
- Area: `2383.536`
- STA stage used: `None`
- Worst slack: `None`
- TNS: `None`
- DRC violations: `None`
- LVS status: `None`

## STA Stage Breakdown
- sta_preplace: worst_slack=`None`, tns=`None`
- sta_postplace: worst_slack=`None`, tns=`None`
- sta_postcts: worst_slack=`None`, tns=`None`
- sta_postroute: worst_slack=`None`, tns=`None`

## GDS Paths (local, only if produced)
- KLayout GDS: `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/89a2017e-48e8-46f0-8792-c2b0d88fbf8a/72318fbc-69a4-40db-b97c-305205d34a7a/digital/arch2tapeout/digital/tapeout/gds/klayout.gds`
- Magic GDS: `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/89a2017e-48e8-46f0-8792-c2b0d88fbf8a/72318fbc-69a4-40db-b97c-305205d34a7a/digital/arch2tapeout/digital/tapeout/gds/magic.gds`

## Artifact Map
- synth_metrics: `digital/synth/metrics.json`
- sta_preplace_metrics: `None`
- sta_postplace_metrics: `None`
- sta_postcts_metrics: `None`
- sta_postroute_metrics: `None`
- drc_metrics: `None`
- lvs_metrics: `None`
- tapeout_metrics: `digital/tapeout/metrics.json`

## Next Iteration Suggestions
- If worst_slack < 0: relax constraints or improve synthesis/placement/CTS/route parameters.
- If DRC violations > 0: inspect DRC logs and rerun with adjusted floorplan/route settings.
- If LVS not clean: check extraction/streamout mismatch and netlist naming.