#!/usr/bin/env bash
set -euo pipefail

echo "== ChipLoop: Digital Route Agent =="
echo "PDK_VARIANT=sky130A"
echo "OPENLANE_IMAGE=ghcr.io/efabless/openlane2:2.4.0.dev1"
echo "WORKDIR=/work"

export OPENLANE_NUM_CORES=2

docker run --rm   -v "/root/chiploop-backend/backend/pdk":/pdk   -v "/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/89a2017e-48e8-46f0-8792-c2b0d88fbf8a/72318fbc-69a4-40db-b97c-305205d34a7a/digital/arch2tapeout/digital/run_work":/work   -e PDK=sky130A   -e PDK_ROOT=/pdk   ghcr.io/efabless/openlane2:2.4.0.dev1   bash -lc 'set -e; cd /work && openlane --flow Classic --run-tag digital_89a2017e-48e8-46f0-8792-c2b0d88fbf8a --override-config RUN_LINTER=False --to OpenROAD.STAPostPNR route/config.json'
