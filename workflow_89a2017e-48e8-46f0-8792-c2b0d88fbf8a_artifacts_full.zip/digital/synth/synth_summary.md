# Digital Synthesis Summary

- **Workflow**: 89a2017e-48e8-46f0-8792-c2b0d88fbf8a
- **Status**: `ok` (rc=0)
- **Top module**: `pwm_controller`
- **Clock**: `clk` @ **10.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/89a2017e-48e8-46f0-8792-c2b0d88fbf8a/72318fbc-69a4-40db-b97c-305205d34a7a/digital/arch2tapeout/digital/synth/runs/digital_89a2017e-48e8-46f0-8792-c2b0d88fbf8a/final/metrics.json`
- netlist candidates: 1 found
