# IP Packaging & Handoff Report

- Top: `imported_from_arch2rtl`
- Package: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/89a2017e-48e8-46f0-8792-c2b0d88fbf8a/72318fbc-69a4-40db-b97c-305205d34a7a/digital/arch2tapeout/handoff/imported_from_arch2rtl_ip_package`
- Zip: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/89a2017e-48e8-46f0-8792-c2b0d88fbf8a/72318fbc-69a4-40db-b97c-305205d34a7a/digital/arch2tapeout/handoff/imported_from_arch2rtl_ip_package.zip`

## Bucket counts
- **rtl**: 1
- **spec**: 1
- **arch**: 0
- **microarch**: 0
- **regmap**: 1
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 2
