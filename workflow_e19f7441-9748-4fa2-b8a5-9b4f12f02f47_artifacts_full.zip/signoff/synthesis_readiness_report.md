# Synthesis Readiness Report

- Top: `temp_monitor_soc_sim`
- RTL files: `4`
- Score (heuristic): **45/100**

## Timing/Area Intent Checks
- (info) No clocks found in spec. If synchronous, include clock intent (name + freq/period).
- (info) No performance/timing intent section found (latency/throughput/constraints).
- (info) No area/gatecount intent found. Provide rough bounds if needed.

## Synthesizable Subset Red Flags
No obvious red flags found by regex scan.

## Yosys Synthesis Check
- Return code: `1`
### Errors (first 20)
- ERROR: Multiple edge sensitive events found for this signal!
