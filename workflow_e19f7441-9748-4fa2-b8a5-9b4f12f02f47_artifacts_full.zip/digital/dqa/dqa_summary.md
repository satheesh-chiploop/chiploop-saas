# Digital DQA Summary
- workflow_id: `e19f7441-9748-4fa2-b8a5-9b4f12f02f47`
- status: `failed`
- rtl files: `4`
- warning count: `1`

## Stage Status
- rtl_lint: `pass`
- cdc: `warning`
- reset_integrity: `pass`
- synthesis_readiness: `failed`

## Blocking Issues
- yosys_synthesis_errors
