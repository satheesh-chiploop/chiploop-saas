{
  "type": "reset_integrity_report",
  "version": "1.0",
  "rtl_file_count": 4,
  "detected_reset_signals": [
    "reset_n"
  ],
  "async_reset_blocks": [
    {
      "file": "/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/e19f7441-9748-4fa2-b8a5-9b4f12f02f47/6b88f84b-41e4-4678-8c41-2c6a95fcbd06/digital/system/imported_rtl/temp_monitor_digital.v",
      "reset": "reset_n",
      "edge": "negedge"
    }
  ],
  "reset_usage_locations": [
    {
      "file": "/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/e19f7441-9748-4fa2-b8a5-9b4f12f02f47/6b88f84b-41e4-4678-8c41-2c6a95fcbd06/digital/system/imported_rtl/temp_monitor_digital.v",
      "reset": "reset_n",
      "context": "if_condition"
    }
  ],
  "findings": [],
  "recommendations": [
    "Prefer async-assert / sync-deassert reset strategy in multi-clock designs.",
    "Ensure reset deassertion is synchronized per clock domain.",
    "Avoid mixing async and sync reset styles without clear intent.",
    "Add reset-specific assertions: no X after reset release; stable reset sequencing."
  ],
  "note": "Heuristic scan only; use signoff reset/CDC checks in enterprise flows when available."
}