{
  "type": "cdc_analysis_report",
  "version": "1.0",
  "inputs": {
    "clock_reset_intent_present": false,
    "rtl_file_count": 4
  },
  "observations": {
    "inferred_clocks": [
      "clk",
      "sample_req"
    ],
    "inferred_domains": [],
    "per_file": [
      {
        "file": "/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/e19f7441-9748-4fa2-b8a5-9b4f12f02f47/6b88f84b-41e4-4678-8c41-2c6a95fcbd06/digital/system/imported_rtl/temp_monitor_digital.v",
        "clock": "clk",
        "domain": null
      },
      {
        "file": "/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/e19f7441-9748-4fa2-b8a5-9b4f12f02f47/6b88f84b-41e4-4678-8c41-2c6a95fcbd06/digital/system/imported_rtl/temp_monitor_soc_phys.sv",
        "clock": null,
        "domain": null
      },
      {
        "file": "/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/e19f7441-9748-4fa2-b8a5-9b4f12f02f47/6b88f84b-41e4-4678-8c41-2c6a95fcbd06/digital/system/imported_rtl/temp_monitor_soc_sim.sv",
        "clock": null,
        "domain": null
      },
      {
        "file": "/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/e19f7441-9748-4fa2-b8a5-9b4f12f02f47/6b88f84b-41e4-4678-8c41-2c6a95fcbd06/digital/system/imported_rtl/temp_sensor_adc_model.v",
        "clock": "sample_req",
        "domain": null
      }
    ]
  },
  "findings": [
    {
      "type": "potential_multi_clock_design",
      "severity": "warning",
      "msg": "Multiple clocks inferred in RTL: ['clk', 'sample_req']. Consider providing clock intent JSON."
    }
  ],
  "recommendations": [
    "Provide clock_reset_arch_intent.json for higher-fidelity CDC intent (domains, allowed crossings).",
    "For single-bit control crossings: use 2-flop synchronizers.",
    "For multi-bit data: use async FIFOs or validated handshake schemes.",
    "Run a real CDC tool in enterprise flow (Questa CDC / SpyGlass CDC / VC CDC) when available."
  ],
  "note": "This agent provides intent-level CDC screening. It is not a replacement for signoff CDC tools."
}