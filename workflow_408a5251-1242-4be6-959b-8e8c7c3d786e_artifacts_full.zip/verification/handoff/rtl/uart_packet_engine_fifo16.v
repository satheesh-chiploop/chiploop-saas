module uart_packet_engine_fifo16 (
    input clk,
    input reset_n,
    input push_en,
    input [7:0] push_data,
    input pop_en,
    output [7:0] pop_data,
    output empty,
    output full,
    output [5:0] level
);

reg [7:0] mem0;
reg [7:0] mem1;
reg [7:0] mem2;
reg [7:0] mem3;
reg [7:0] mem4;
reg [7:0] mem5;
reg [7:0] mem6;
reg [7:0] mem7;
reg [7:0] mem8;
reg [7:0] mem9;
reg [7:0] mem10;
reg [7:0] mem11;
reg [7:0] mem12;
reg [7:0] mem13;
reg [7:0] mem14;
reg [7:0] mem15;
reg [3:0] rd_ptr;
reg [3:0] wr_ptr;
reg [4:0] count_r;
reg [7:0] pop_data_r;
assign pop_data = pop_data_r;
assign empty = (count_r == 5'd0);
assign full = (count_r == 5'd16);
assign level = {1'b0, count_r};

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        mem0 <= 8'h00;
        mem1 <= 8'h00;
        mem2 <= 8'h00;
        mem3 <= 8'h00;
        mem4 <= 8'h00;
        mem5 <= 8'h00;
        mem6 <= 8'h00;
        mem7 <= 8'h00;
        mem8 <= 8'h00;
        mem9 <= 8'h00;
        mem10 <= 8'h00;
        mem11 <= 8'h00;
        mem12 <= 8'h00;
        mem13 <= 8'h00;
        mem14 <= 8'h00;
        mem15 <= 8'h00;
        rd_ptr <= 4'h0;
        wr_ptr <= 4'h0;
        count_r <= 5'd0;
        pop_data_r <= 8'h00;
    end else begin
        if (push_en && !full) begin
            case (wr_ptr)
                4'h0: mem0 <= push_data;
                4'h1: mem1 <= push_data;
                4'h2: mem2 <= push_data;
                4'h3: mem3 <= push_data;
                4'h4: mem4 <= push_data;
                4'h5: mem5 <= push_data;
                4'h6: mem6 <= push_data;
                4'h7: mem7 <= push_data;
                4'h8: mem8 <= push_data;
                4'h9: mem9 <= push_data;
                4'hA: mem10 <= push_data;
                4'hB: mem11 <= push_data;
                4'hC: mem12 <= push_data;
                4'hD: mem13 <= push_data;
                4'hE: mem14 <= push_data;
                default: mem15 <= push_data;
            endcase
            wr_ptr <= wr_ptr + 4'h1;
            count_r <= count_r + 5'd1;
        end
        if (pop_en && !empty) begin
            case (rd_ptr)
                4'h0: pop_data_r <= mem0;
                4'h1: pop_data_r <= mem1;
                4'h2: pop_data_r <= mem2;
                4'h3: pop_data_r <= mem3;
                4'h4: pop_data_r <= mem4;
                4'h5: pop_data_r <= mem5;
                4'h6: pop_data_r <= mem6;
                4'h7: pop_data_r <= mem7;
                4'h8: pop_data_r <= mem8;
                4'h9: pop_data_r <= mem9;
                4'hA: pop_data_r <= mem10;
                4'hB: pop_data_r <= mem11;
                4'hC: pop_data_r <= mem12;
                4'hD: pop_data_r <= mem13;
                4'hE: pop_data_r <= mem14;
                default: pop_data_r <= mem15;
            endcase
            rd_ptr <= rd_ptr + 4'h1;
            count_r <= count_r - 5'd1;
        end
    end
end

endmodule
