module uart_packet_engine_loopback (
    input clk,
    input reset_n,
    input loopback_enable,
    input tx_byte_pulse,
    input [7:0] tx_byte_data,
    input rx_byte_pulse,
    input [7:0] rx_byte_data,
    output loopback_byte_pulse,
    output [7:0] loopback_byte_data,
    output packet_done_pulse,
    output packet_count_inc,
    input packet_active,
    output error_flag
);

reg loopback_byte_pulse_r;
reg [7:0] loopback_byte_data_r;
reg packet_done_pulse_r;
reg packet_count_inc_r;
reg error_flag_r;
reg [7:0] activity_count_r;

assign loopback_byte_pulse = loopback_byte_pulse_r;
assign loopback_byte_data = loopback_byte_data_r;
assign packet_done_pulse = packet_done_pulse_r;
assign packet_count_inc = packet_count_inc_r;
assign error_flag = error_flag_r;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        loopback_byte_pulse_r <= 1'b0;
        loopback_byte_data_r <= 8'h00;
        packet_done_pulse_r <= 1'b0;
        packet_count_inc_r <= 1'b0;
        error_flag_r <= 1'b0;
        activity_count_r <= 8'h00;
    end else begin
        loopback_byte_pulse_r <= 1'b0;
        packet_done_pulse_r <= 1'b0;
        packet_count_inc_r <= 1'b0;
        if (loopback_enable && tx_byte_pulse) begin
            loopback_byte_pulse_r <= 1'b1;
            loopback_byte_data_r <= tx_byte_data;
            activity_count_r <= activity_count_r + 8'h01;
        end
        if (rx_byte_pulse && loopback_enable) begin
            activity_count_r <= activity_count_r + 8'h01;
        end
        if (loopback_enable && packet_active && (activity_count_r == 8'h10)) begin
            packet_done_pulse_r <= 1'b1;
            packet_count_inc_r <= 1'b1;
            activity_count_r <= 8'h00;
        end
        error_flag_r <= (loopback_enable && (activity_count_r == 8'hFF)) || (!loopback_enable && rx_byte_pulse);
    end
end

endmodule
