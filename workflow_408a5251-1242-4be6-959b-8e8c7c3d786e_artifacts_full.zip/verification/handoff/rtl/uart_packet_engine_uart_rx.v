module uart_packet_engine_uart_rx (
    input clk,
    input reset_n,
    input enable,
    input baud_tick,
    input uart_rx,
    output rx_byte_pulse,
    output [7:0] rx_byte_data,
    output framing_error_pulse,
    output busy,
    output packet_active,
    output rx_sample_tick
);

localparam RX_IDLE = 3'd0;
localparam RX_START = 3'd1;
localparam RX_DATA = 3'd2;
localparam RX_STOP = 3'd3;

reg [2:0] state_r;
reg [2:0] bit_cnt_r;
reg [7:0] shift_r;
reg rx_byte_pulse_r;
reg [7:0] rx_byte_data_r;
reg framing_error_pulse_r;
reg busy_r;
reg packet_active_r;
reg rx_sample_tick_r;

assign rx_byte_pulse = rx_byte_pulse_r;
assign rx_byte_data = rx_byte_data_r;
assign framing_error_pulse = framing_error_pulse_r;
assign busy = busy_r;
assign packet_active = packet_active_r;
assign rx_sample_tick = rx_sample_tick_r;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        state_r <= RX_IDLE;
        bit_cnt_r <= 3'd0;
        shift_r <= 8'h00;
        rx_byte_pulse_r <= 1'b0;
        rx_byte_data_r <= 8'h00;
        framing_error_pulse_r <= 1'b0;
        busy_r <= 1'b0;
        packet_active_r <= 1'b0;
        rx_sample_tick_r <= 1'b0;
    end else begin
        rx_byte_pulse_r <= 1'b0;
        framing_error_pulse_r <= 1'b0;
        rx_sample_tick_r <= 1'b0;
        if (!enable) begin
            state_r <= RX_IDLE;
            busy_r <= 1'b0;
            packet_active_r <= 1'b0;
        end else if (baud_tick) begin
            rx_sample_tick_r <= 1'b1;
            case (state_r)
                RX_IDLE: begin
                    busy_r <= 1'b0;
                    packet_active_r <= 1'b0;
                    if (uart_rx == 1'b0) begin
                        state_r <= RX_START;
                        busy_r <= 1'b1;
                        packet_active_r <= 1'b1;
                    end
                end
                RX_START: begin
                    if (uart_rx == 1'b0) begin
                        state_r <= RX_DATA;
                        bit_cnt_r <= 3'd0;
                    end else begin
                        state_r <= RX_IDLE;
                        busy_r <= 1'b0;
                        packet_active_r <= 1'b0;
                        framing_error_pulse_r <= 1'b1;
                    end
                end
                RX_DATA: begin
                    shift_r <= {uart_rx, shift_r[7:1]};
                    if (bit_cnt_r == 3'd7) begin
                        state_r <= RX_STOP;
                    end else begin
                        bit_cnt_r <= bit_cnt_r + 3'd1;
                    end
                end
                default: begin
                    if (uart_rx == 1'b1) begin
                        rx_byte_data_r <= {uart_rx, shift_r[7:1]};
                        rx_byte_pulse_r <= 1'b1;
                    end else begin
                        framing_error_pulse_r <= 1'b1;
                    end
                    state_r <= RX_IDLE;
                    busy_r <= 1'b0;
                    packet_active_r <= 1'b0;
                end
            endcase
        end
    end
end

endmodule
