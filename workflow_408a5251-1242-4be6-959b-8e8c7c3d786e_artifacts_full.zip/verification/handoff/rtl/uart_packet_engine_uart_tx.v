module uart_packet_engine_uart_tx (
    input clk,
    input reset_n,
    input enable,
    input baud_tick,
    input fifo_empty,
    input [7:0] fifo_rd_data,
    output fifo_pop_req,
    output uart_tx,
    output busy,
    output tx_done_pulse,
    output packet_active,
    output tx_byte_pulse,
    output [7:0] tx_byte_data
);

localparam ST_IDLE = 3'd0;
localparam ST_START = 3'd1;
localparam ST_DATA = 3'd2;
localparam ST_STOP = 3'd3;

reg [2:0] state_r;
reg [2:0] bit_cnt_r;
reg [7:0] shift_r;
reg uart_tx_r;
reg busy_r;
reg tx_done_pulse_r;
reg packet_active_r;
reg fifo_pop_req_r;
reg tx_byte_pulse_r;
reg [7:0] tx_byte_data_r;
assign uart_tx = uart_tx_r;
assign busy = busy_r;
assign tx_done_pulse = tx_done_pulse_r;
assign packet_active = packet_active_r;
assign fifo_pop_req = fifo_pop_req_r;
assign tx_byte_pulse = tx_byte_pulse_r;
assign tx_byte_data = tx_byte_data_r;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        state_r <= ST_IDLE;
        bit_cnt_r <= 3'd0;
        shift_r <= 8'h00;
        uart_tx_r <= 1'b1;
        busy_r <= 1'b0;
        tx_done_pulse_r <= 1'b0;
        packet_active_r <= 1'b0;
        fifo_pop_req_r <= 1'b0;
        tx_byte_pulse_r <= 1'b0;
        tx_byte_data_r <= 8'h00;
    end else begin
        tx_done_pulse_r <= 1'b0;
        fifo_pop_req_r <= 1'b0;
        tx_byte_pulse_r <= 1'b0;
        if (!enable) begin
            state_r <= ST_IDLE;
            uart_tx_r <= 1'b1;
            busy_r <= 1'b0;
            packet_active_r <= 1'b0;
        end else if (baud_tick) begin
            case (state_r)
                ST_IDLE: begin
                    uart_tx_r <= 1'b1;
                    busy_r <= 1'b0;
                    packet_active_r <= 1'b0;
                    if (!fifo_empty) begin
                        fifo_pop_req_r <= 1'b1;
                        shift_r <= fifo_rd_data;
                        tx_byte_data_r <= fifo_rd_data;
                        tx_byte_pulse_r <= 1'b1;
                        state_r <= ST_START;
                        uart_tx_r <= 1'b0;
                        busy_r <= 1'b1;
                        packet_active_r <= 1'b1;
                        bit_cnt_r <= 3'd0;
                    end
                end
                ST_START: begin
                    uart_tx_r <= 1'b0;
                    busy_r <= 1'b1;
                    packet_active_r <= 1'b1;
                    state_r <= ST_DATA;
                    bit_cnt_r <= 3'd0;
                end
                ST_DATA: begin
                    uart_tx_r <= shift_r[0];
                    busy_r <= 1'b1;
                    packet_active_r <= 1'b1;
                    shift_r <= {1'b0, shift_r[7:1]};
                    if (bit_cnt_r == 3'd7) begin
                        state_r <= ST_STOP;
                    end else begin
                        bit_cnt_r <= bit_cnt_r + 3'd1;
                    end
                end
                default: begin
                    uart_tx_r <= 1'b1;
                    busy_r <= 1'b0;
                    packet_active_r <= 1'b0;
                    state_r <= ST_IDLE;
                    tx_done_pulse_r <= 1'b1;
                end
            endcase
        end
    end
end

endmodule
