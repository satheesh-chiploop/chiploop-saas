module uart_packet_engine (
    input clk,
    input reset_n,
    input wr_en,
    input [7:0] wr_addr,
    input [7:0] wr_data,
    input rd_en,
    input [7:0] rd_addr,
    input uart_rx,
    output [7:0] rd_data,
    output uart_tx,
    output irq,
    output [5:0] rx_fifo_level,
    output [5:0] tx_fifo_level,
    output [15:0] packet_count
);

wire tx_fifo_push_en;
wire [7:0] tx_fifo_push_data;
wire rx_fifo_pop_en;
wire [5:0] irq_clear_mask;
wire ctrl_enable;
wire ctrl_rx_enable;
wire ctrl_tx_enable;
wire ctrl_loopback;
wire ctrl_irq_enable;
wire [15:0] baud_div_cfg;
wire [7:0] packet_len_cfg;
wire [7:0] reg_rd_data;
wire [5:0] irq_status_out;
wire [7:0] status_out;
wire [15:0] packet_count_out;
wire tx_fifo_full;
wire rx_fifo_empty;
wire [5:0] tx_fifo_level_in;
wire [5:0] rx_fifo_level_in;
wire tx_busy_in;
wire rx_busy_in;
wire packet_active_in;
wire error_in;
wire rx_done_pulse;
wire tx_done_pulse;
wire rx_overflow_pulse;
wire tx_underflow_pulse;
wire framing_error_pulse;
wire packet_done_pulse;
wire [7:0] rx_fifo_rd_data;
wire tx_data_popped_ack;
wire rx_data_pushed_ack;
wire baud_tick;
wire tx_fifo_pop_req;
wire [7:0] tx_fifo_pop_data;
wire tx_fifo_empty;
wire rx_fifo_full;
wire tx_busy;
wire rx_busy;
wire tx_packet_active;
wire rx_packet_active;
wire [7:0] tx_byte_observe;
wire tx_byte_pulse;
wire [7:0] rx_byte_observe;
wire rx_byte_pulse_observe;
wire loopback_byte_pulse;
wire [7:0] loopback_byte_data;
wire packet_count_inc;
wire loopback_error_flag;

assign rd_data = reg_rd_data;
assign irq = ctrl_irq_enable & (irq_status_out != 6'b000000);
assign packet_count = packet_count_out;
assign rx_fifo_level = rx_fifo_level_in;
assign tx_fifo_level = tx_fifo_level_in;

uart_packet_engine_regfile u_regfile (
    .clk(clk),
    .reset_n(reset_n),
    .wr_en(wr_en),
    .wr_addr(wr_addr),
    .wr_data(wr_data),
    .rd_en(rd_en),
    .rd_addr(rd_addr),
    .tx_fifo_full(tx_fifo_full),
    .rx_fifo_empty(rx_fifo_empty),
    .tx_fifo_level_in(tx_fifo_level_in),
    .rx_fifo_level_in(rx_fifo_level_in),
    .tx_busy_in(tx_busy_in),
    .rx_busy_in(rx_busy_in),
    .packet_active_in(packet_active_in),
    .error_in(error_in),
    .rx_done_pulse(rx_done_pulse),
    .tx_done_pulse(tx_done_pulse),
    .rx_overflow_pulse(rx_overflow_pulse),
    .tx_underflow_pulse(tx_underflow_pulse),
    .framing_error_pulse(framing_error_pulse),
    .packet_done_pulse(packet_done_pulse),
    .rx_fifo_rd_data(rx_fifo_rd_data),
    .tx_data_push(tx_fifo_push_en),
    .tx_data_push_data(tx_fifo_push_data),
    .rx_data_pop(rx_fifo_pop_en),
    .irq_clear_mask(irq_clear_mask),
    .ctrl_enable(ctrl_enable),
    .ctrl_rx_enable(ctrl_rx_enable),
    .ctrl_tx_enable(ctrl_tx_enable),
    .ctrl_loopback(ctrl_loopback),
    .ctrl_irq_enable(ctrl_irq_enable),
    .baud_div_cfg(baud_div_cfg),
    .packet_len_cfg(packet_len_cfg),
    .rd_data(reg_rd_data),
    .irq_status_out(irq_status_out),
    .status_out(status_out),
    .packet_count_out(packet_count_out),
    .tx_data_popped_ack(tx_data_popped_ack),
    .rx_data_pushed_ack(rx_data_pushed_ack)
);

uart_packet_engine_baudgen u_baudgen (
    .clk(clk),
    .reset_n(reset_n),
    .enable(ctrl_enable),
    .baud_div_cfg(baud_div_cfg),
    .baud_tick(baud_tick)
);

uart_packet_engine_fifo16 u_tx_fifo (
    .clk(clk),
    .reset_n(reset_n),
    .push_en(tx_fifo_push_en),
    .push_data(tx_fifo_push_data),
    .pop_en(tx_fifo_pop_req),
    .pop_data(tx_fifo_pop_data),
    .empty(tx_fifo_empty),
    .full(tx_fifo_full),
    .level(tx_fifo_level_in)
);

uart_packet_engine_fifo16 u_rx_fifo (
    .clk(clk),
    .reset_n(reset_n),
    .push_en(loopback_byte_pulse),
    .push_data(loopback_byte_data),
    .pop_en(rx_fifo_pop_en),
    .pop_data(rx_fifo_rd_data),
    .empty(rx_fifo_empty),
    .full(rx_fifo_full),
    .level(rx_fifo_level_in)
);

uart_packet_engine_uart_tx u_uart_tx (
    .clk(clk),
    .reset_n(reset_n),
    .enable(ctrl_enable & ctrl_tx_enable),
    .baud_tick(baud_tick),
    .fifo_empty(tx_fifo_empty),
    .fifo_rd_data(tx_fifo_pop_data),
    .fifo_pop_req(tx_fifo_pop_req),
    .uart_tx(uart_tx),
    .busy(tx_busy),
    .tx_done_pulse(tx_done_pulse),
    .packet_active(tx_packet_active),
    .tx_byte_pulse(tx_byte_pulse),
    .tx_byte_data(tx_byte_observe)
);

uart_packet_engine_uart_rx u_uart_rx (
    .clk(clk),
    .reset_n(reset_n),
    .enable(ctrl_enable & ctrl_rx_enable),
    .baud_tick(baud_tick),
    .uart_rx(uart_rx),
    .rx_byte_pulse(rx_byte_pulse_observe),
    .rx_byte_data(rx_byte_observe),
    .framing_error_pulse(framing_error_pulse),
    .busy(rx_busy),
    .packet_active(rx_packet_active),
    .rx_sample_tick()
);

uart_packet_engine_loopback u_loopback (
    .clk(clk),
    .reset_n(reset_n),
    .loopback_enable(ctrl_loopback),
    .tx_byte_pulse(tx_byte_pulse),
    .tx_byte_data(tx_byte_observe),
    .rx_byte_pulse(rx_byte_pulse_observe),
    .rx_byte_data(rx_byte_observe),
    .loopback_byte_pulse(loopback_byte_pulse),
    .loopback_byte_data(loopback_byte_data),
    .packet_done_pulse(packet_done_pulse),
    .packet_count_inc(packet_count_inc),
    .packet_active(tx_packet_active | rx_packet_active),
    .error_flag(loopback_error_flag)
);

assign rx_done_pulse = packet_done_pulse;
assign error_in = loopback_error_flag | rx_fifo_full | tx_fifo_empty;
assign tx_data_popped_ack = tx_fifo_pop_req & ~tx_fifo_empty;
assign rx_data_pushed_ack = loopback_byte_pulse;

endmodule
