module uart_packet_engine_baudgen (
    input clk,
    input reset_n,
    input enable,
    input [15:0] baud_div_cfg,
    output baud_tick
);

reg [15:0] counter_r;
reg baud_tick_r;

assign baud_tick = baud_tick_r;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        counter_r <= 16'h0000;
        baud_tick_r <= 1'b0;
    end else begin
        baud_tick_r <= 1'b0;
        if (!enable) begin
            counter_r <= 16'h0000;
        end else begin
            if (baud_div_cfg == 16'h0000) begin
                baud_tick_r <= 1'b1;
                counter_r <= 16'h0000;
            end else if (counter_r == (baud_div_cfg - 16'h0001)) begin
                baud_tick_r <= 1'b1;
                counter_r <= 16'h0000;
            end else begin
                counter_r <= counter_r + 16'h0001;
            end
        end
    end
end

endmodule
