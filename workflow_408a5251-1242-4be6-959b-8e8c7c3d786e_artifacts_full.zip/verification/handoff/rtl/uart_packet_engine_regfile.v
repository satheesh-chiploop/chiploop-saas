module uart_packet_engine_regfile (
    input clk,
    input reset_n,
    input wr_en,
    input [7:0] wr_addr,
    input [7:0] wr_data,
    input rd_en,
    input [7:0] rd_addr,
    input tx_fifo_full,
    input rx_fifo_empty,
    input [5:0] tx_fifo_level_in,
    input [5:0] rx_fifo_level_in,
    input tx_busy_in,
    input rx_busy_in,
    input packet_active_in,
    input error_in,
    output rx_done_pulse,
    input tx_done_pulse,
    input rx_overflow_pulse,
    input tx_underflow_pulse,
    input framing_error_pulse,
    input packet_done_pulse,
    input [7:0] rx_fifo_rd_data,
    output tx_data_push,
    output [7:0] tx_data_push_data,
    output rx_data_pop,
    output [5:0] irq_clear_mask,
    output ctrl_enable,
    output ctrl_rx_enable,
    output ctrl_tx_enable,
    output ctrl_loopback,
    output ctrl_irq_enable,
    output [15:0] baud_div_cfg,
    output [7:0] packet_len_cfg,
    output [7:0] rd_data,
    output [5:0] irq_status_out,
    output [7:0] status_out,
    output [15:0] packet_count_out,
    input tx_data_popped_ack,
    input rx_data_pushed_ack
);

reg [7:0] control_reg;
reg [15:0] baud_div_reg;
reg [7:0] packet_len_reg;
reg [5:0] irq_status_reg;
reg [15:0] packet_count_reg;
reg [7:0] rd_data_r;
reg tx_data_push_r;
reg [7:0] tx_data_push_data_r;
reg rx_data_pop_r;
reg [5:0] irq_clear_mask_r;
reg rx_done_pulse_r;

assign rd_data = rd_data_r;
assign tx_data_push = tx_data_push_r;
assign tx_data_push_data = tx_data_push_data_r;
assign rx_data_pop = rx_data_pop_r;
assign irq_clear_mask = irq_clear_mask_r;
assign ctrl_enable = control_reg[0];
assign ctrl_rx_enable = control_reg[1];
assign ctrl_tx_enable = control_reg[2];
assign ctrl_loopback = control_reg[3];
assign ctrl_irq_enable = control_reg[4];
assign baud_div_cfg = baud_div_reg;
assign packet_len_cfg = packet_len_reg;
assign irq_status_out = irq_status_reg;
assign packet_count_out = packet_count_reg;
assign rx_done_pulse = rx_done_pulse_r;
assign status_out = {error_in, packet_active_in, rx_busy_in, tx_busy_in, rx_fifo_full, rx_fifo_empty, tx_fifo_full, tx_fifo_empty};

wire tx_fifo_empty;
wire rx_fifo_full;

assign tx_fifo_empty = tx_fifo_level_in == 6'b000000;
assign rx_fifo_full = rx_fifo_level_in == 6'b010000;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        control_reg <= 8'h00;
        baud_div_reg <= 16'h0000;
        packet_len_reg <= 8'h00;
        irq_status_reg <= 6'b000000;
        packet_count_reg <= 16'h0000;
        rd_data_r <= 8'h00;
        tx_data_push_r <= 1'b0;
        tx_data_push_data_r <= 8'h00;
        rx_data_pop_r <= 1'b0;
        irq_clear_mask_r <= 6'b000000;
        rx_done_pulse_r <= 1'b0;
    end else begin
        tx_data_push_r <= 1'b0;
        rx_data_pop_r <= 1'b0;
        irq_clear_mask_r <= 6'b000000;
        rx_done_pulse_r <= 1'b0;
        if (wr_en) begin
            case (wr_addr)
                8'h00: control_reg <= {3'b000, wr_data[4:0]};
                8'h04: baud_div_reg[7:0] <= wr_data;
                8'h05: baud_div_reg[15:8] <= wr_data;
                8'h08: packet_len_reg <= wr_data;
                8'h0C: begin
                    if (!tx_fifo_full) begin
                        tx_data_push_r <= 1'b1;
                        tx_data_push_data_r <= wr_data;
                    end else begin
                        irq_status_reg[2] <= 1'b1;
                    end
                end
                8'h1C: begin
                    irq_clear_mask_r <= wr_data[5:0];
                    irq_status_reg <= irq_status_reg & ~wr_data[5:0];
                end
                default: begin
                end
            endcase
        end
        if (rd_en) begin
            case (rd_addr)
                8'h00: rd_data_r <= {3'b000, control_reg[4:0]};
                8'h04: rd_data_r <= baud_div_reg[7:0];
                8'h05: rd_data_r <= baud_div_reg[15:8];
                8'h08: rd_data_r <= packet_len_reg;
                8'h10: begin
                    if (!rx_fifo_empty) begin
                        rx_data_pop_r <= 1'b1;
                        rd_data_r <= rx_fifo_rd_data;
                    end else begin
                        rd_data_r <= 8'h00;
                    end
                end
                8'h14: rd_data_r <= status_out;
                8'h18: rd_data_r <= {2'b00, irq_status_reg};
                8'h20: rd_data_r <= packet_count_reg[7:0];
                8'h21: rd_data_r <= packet_count_reg[15:8];
                default: rd_data_r <= 8'h00;
            endcase
        end else begin
            rd_data_r <= rd_data_r;
        end
        if (tx_done_pulse) begin
            irq_status_reg[1] <= 1'b1;
            packet_count_reg <= packet_count_reg + 16'h0001;
        end
        if (rx_overflow_pulse) irq_status_reg[2] <= 1'b1;
        if (tx_underflow_pulse) irq_status_reg[3] <= 1'b1;
        if (framing_error_pulse) irq_status_reg[4] <= 1'b1;
        if (packet_done_pulse) begin
            irq_status_reg[5] <= 1'b1;
            packet_count_reg <= packet_count_reg + 16'h0001;
        end
        if (rx_done_pulse_r) irq_status_reg[0] <= 1'b1;
        if (tx_data_popped_ack) begin
            tx_data_push_data_r <= tx_data_push_data_r;
        end
        if (rx_data_pushed_ack) begin
            rx_done_pulse_r <= 1'b1;
        end
    end
end

endmodule
