# Verification Closure Plan

- Verdict: coverage_closure_needed
- Coverage gaps: 14
- Functional bin gaps: 9
- Failing testcase/seed pairs: 0

## Verify Evidence Snapshot
- Runs: 12
- Simulation pass/fail: 12 / 0
- Functional coverage: 67.86
- Code line/branch/condition/toggle coverage: 45.55 / 4.55 / 4.55 / 12.03
- Formal: fail
- Golden model: generated
- Tools: verilator / verilator_coverage / symbiyosys
- Plans: verification=True, monitor/checker=True, coverage=True

## Functional Coverage Not Met
- outputs.irq: bins 1/2, missing nonzero; Add directed stimulus and checker sampling for outputs.irq; target missing bins: nonzero.
- outputs.packet_count: bins 1/2, missing nonzero; Add directed stimulus and checker sampling for outputs.packet_count; target missing bins: nonzero.
- outputs.rx_fifo_level: bins 1/2, missing nonzero; Add directed stimulus and checker sampling for outputs.rx_fifo_level; target missing bins: nonzero.
- outputs.uart_tx: bins 1/2, missing zero; Add directed stimulus and checker sampling for outputs.uart_tx; target missing bins: zero.
- inputs.clk: bins 1/2, missing zero; Add directed stimulus and checker sampling for inputs.clk; target missing bins: zero.
- inputs.rd_en: bins 1/2, missing nonzero; Add directed stimulus and checker sampling for inputs.rd_en; target missing bins: nonzero.
- inputs.reset_n: bins 1/2, missing zero; Add directed stimulus and checker sampling for inputs.reset_n; target missing bins: zero.
- inputs.uart_rx: bins 1/2, missing nonzero; Add directed stimulus and checker sampling for inputs.uart_rx; target missing bins: nonzero.
- inputs.wr_en: bins 1/2, missing nonzero; Add directed stimulus and checker sampling for inputs.wr_en; target missing bins: nonzero.

## Recommended Actions
- high: Generate directed tests targeting unhit functional bins and uncovered code paths.
- medium: Review whether any coverage holes are unreachable or incorrectly modeled.
