# Coverage Point Plan

- Source: generated_from_spec
- Top module: `uart_packet_engine`

## Output Coverpoints
- Cover `rd_data` zero and non-zero/value-transition bins.
- Cover `uart_tx` zero and non-zero/value-transition bins.
- Cover `irq` zero and non-zero/value-transition bins.
- Cover `rx_fifo_level` zero and non-zero/value-transition bins.
- Cover `tx_fifo_level` zero and non-zero/value-transition bins.
- Cover `packet_count` zero and non-zero/value-transition bins.

## Input Coverpoints
- Cover `clk` zero and non-zero/input-stimulus bins.
- Cover `reset_n` zero and non-zero/input-stimulus bins.
- Cover `wr_en` zero and non-zero/input-stimulus bins.
- Cover `wr_addr` zero and non-zero/input-stimulus bins.
- Cover `wr_data` zero and non-zero/input-stimulus bins.
- Cover `rd_en` zero and non-zero/input-stimulus bins.
- Cover `rd_addr` zero and non-zero/input-stimulus bins.
- Cover `uart_rx` zero and non-zero/input-stimulus bins.

## Cross Coverage Candidates
- Cross reset release with first observed output activity.
- Cross primary control inputs with output response bins when both are present.

## Closure Guidance
- Review uncovered bins before accepting closure.
- Add directed tests for missed bins, or mark exclusions with reviewer rationale.

## Closure Iteration 1 Coverage Points

- COV_ITER001_001: `outputs.irq` target bins nonzero
- COV_ITER001_002: `outputs.packet_count` target bins nonzero
- COV_ITER001_003: `outputs.rx_fifo_level` target bins nonzero
- COV_ITER001_004: `outputs.uart_tx` target bins zero
- COV_ITER001_005: `inputs.clk` target bins zero
- COV_ITER001_006: `inputs.rd_en` target bins nonzero
- COV_ITER001_007: `inputs.reset_n` target bins zero
- COV_ITER001_008: `inputs.uart_rx` target bins nonzero
- COV_ITER001_009: `inputs.wr_en` target bins nonzero
- COV_ITER001_010: `functional_coverage_below_target` target bins unhit
- COV_ITER001_011: `code_line_coverage_below_target` target bins unhit
- COV_ITER001_012: `code_branch_coverage_below_target` target bins unhit
- COV_ITER001_013: `code_condition_coverage_below_target` target bins unhit
- COV_ITER001_014: `code_toggle_coverage_below_target` target bins unhit
