# Coverage Gap Analysis

- Functional coverage: 67.86 / target 100.0%
- Code line coverage: 45.55 / target 90.0%
- Code branch coverage: 4.55 / target 80.0%
- Code condition coverage: 4.55 / target 80.0%
- Code toggle coverage: 12.03 / target 80.0%
- Gap count: 14
- Functional bin gaps: 9

## Functional Coverage Gaps
- outputs.irq: bins 1/2, missing nonzero, seen values [0]
- outputs.packet_count: bins 1/2, missing nonzero, seen values [0]
- outputs.rx_fifo_level: bins 1/2, missing nonzero, seen values [0]
- outputs.uart_tx: bins 1/2, missing zero, seen values [1]
- inputs.clk: bins 1/2, missing zero, seen values [1]
- inputs.rd_en: bins 1/2, missing nonzero, seen values [0]
- inputs.reset_n: bins 1/2, missing zero, seen values [1]
- inputs.uart_rx: bins 1/2, missing nonzero, seen values [0]
- inputs.wr_en: bins 1/2, missing nonzero, seen values [0]

## Recommended Actions
- high: add_directed_tests - Coverage holes should first be mapped to explicit scenarios so closure is explainable.
- medium: increase_random_seeds - More seeds may close random-observable bins after directed gaps are handled.
- medium: review_coverage_model - Unreachable or incorrectly specified bins should be waived or corrected, not chased indefinitely.
