/*
 * Auto-generated SVA bind file.
 * Uses only spec-declared signals.
 */
bind uart_packet_engine uart_packet_engine_assertions u_uart_packet_engine_assertions (

);
