# Simulation Execution Summary

- Total runs: 10
- Pass count: 10
- Fail count: 0

## Results
- smoke_test / seed 1: PASS (rc=0)
- smoke_test / seed 2: PASS (rc=0)
- smoke_test / seed 3: PASS (rc=0)
- smoke_test / seed 4: PASS (rc=0)
- smoke_test / seed 5: PASS (rc=0)
- register_mapped_control_directed / seed 1: PASS (rc=0)
- register_mapped_control_directed / seed 2: PASS (rc=0)
- register_mapped_control_directed / seed 3: PASS (rc=0)
- register_mapped_control_directed / seed 4: PASS (rc=0)
- register_mapped_control_directed / seed 5: PASS (rc=0)
