# Functional Coverage Summary

- Top module: uart_packet_engine
- Functional coverage: 0.0%
- Bins hit: 0
- Total bins: 0

## Outputs

## Inputs
