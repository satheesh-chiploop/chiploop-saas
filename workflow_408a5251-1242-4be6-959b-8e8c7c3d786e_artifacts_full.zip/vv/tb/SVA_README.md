# SVA Usage

Generated:
- `uart_packet_engine_assertions.sv`        : assertion module derived from spec
- `uart_packet_engine_assertions_bind.sv`   : bind file for DUT integration
- `sva_spec.json`           : resolved assertion contract
- `sva_generation_report.json`

The bind file uses only spec-declared signals and is intended to be compiled with simulation sources.
