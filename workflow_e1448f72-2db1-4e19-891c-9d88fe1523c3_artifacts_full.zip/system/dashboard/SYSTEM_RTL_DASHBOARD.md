# System RTL Evidence Dashboard

## System
- Top module: soc_top_sim
- RTL files: 4
- Modules: 4
- Input bits: 38
- Output bits: 43
- Flip-flops: 202
- Latches: 1
- Full-cycle paths: 3
- Half-cycle paths: 1

## Soc
- Top module: soc_top_sim
- RTL files: 2
- Modules: 2
- Input bits: 38
- Output bits: 43
- Flip-flops: 0
- Latches: 0
- Full-cycle paths: 2
- Half-cycle paths: 0

## Digital
- Top module: digital_block
- RTL files: 0
- Modules: 0
- Input bits: 0
- Output bits: 0
- Flip-flops: 0
- Latches: 0
- Full-cycle paths: 2
- Half-cycle paths: 0

## Analog
- Top module: temp_sensor_adc_model
- RTL files: 2
- Modules: 2
- Input bits: 19
- Output bits: 13
- Flip-flops: 202
- Latches: 1
- Full-cycle paths: 3
- Half-cycle paths: 1
