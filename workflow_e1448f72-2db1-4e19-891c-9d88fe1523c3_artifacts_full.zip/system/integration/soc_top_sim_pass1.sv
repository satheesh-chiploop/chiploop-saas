module soc_top_sim (
  output logic alert_irq,
  output logic alert_status,
  input logic avdd,
  input logic avss,
  input logic clk,
  input logic rd_addr,
  output logic rd_data,
  input logic rd_en,
  input logic rst_n,
  output logic sample_req,
  output logic temp_code,
  output logic threshold_code,
  input logic wr_addr,
  input logic wr_data,
  input logic wr_en
);

  // Auto-generated interconnect wires
  logic w_4_u_digital_sample_req_u_analog_sample_req;
  logic [11:0] w_5_u_analog_adc_code_u_digital_adc_code;
  logic w_6_u_analog_adc_valid_u_digital_adc_valid;

  temp_sensor_adc_model u_analog (
    .adc_code(w_5_u_analog_adc_code_u_digital_adc_code),
    .adc_valid(w_6_u_analog_adc_valid_u_digital_adc_valid),
    .avdd(avdd),
    .avss(avss),
    .sample_req(w_4_u_digital_sample_req_u_analog_sample_req)
  );

  temp_monitor_digital u_digital (
    .adc_code(w_5_u_analog_adc_code_u_digital_adc_code),
    .adc_valid(w_6_u_analog_adc_valid_u_digital_adc_valid),
    .alert_irq(alert_irq),
    .alert_status(alert_status),
    .clk(clk),
    .rd_addr(rd_addr),
    .rd_data(rd_data),
    .rd_en(rd_en),
    .reset_n(rst_n),
    .sample_req(sample_req),
    .temp_code(temp_code),
    .threshold_code(threshold_code),
    .wr_addr(wr_addr),
    .wr_data(wr_data),
    .wr_en(wr_en)
  );

endmodule