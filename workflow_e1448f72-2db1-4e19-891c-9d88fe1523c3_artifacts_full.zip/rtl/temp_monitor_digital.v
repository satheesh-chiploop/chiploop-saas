module temp_monitor_digital (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    adc_code,
    adc_valid,
    rd_data,
    sample_req,
    alert_irq,
    temp_code,
    threshold_code,
    alert_status
);

input clk;
input reset_n;
input wr_en;
input [7:0] wr_addr;
input [15:0] wr_data;
input rd_en;
input [7:0] rd_addr;
input [11:0] adc_code;
input adc_valid;
output reg [15:0] rd_data;
output reg sample_req;
output reg alert_irq;
output reg [11:0] temp_code;
output reg [11:0] threshold_code;
output reg alert_status;

reg [15:0] control_reg;
reg [15:0] status_reg;
reg [15:0] irq_status_reg;
reg [15:0] sample_count;
reg [11:0] latest_temp;
reg [11:0] prev_sample;
reg prev_sample_valid;
reg busy;
reg status_sample_done;
reg status_alert_pending;
reg irq_status_alert;
reg irq_status_sample_done;
reg adc_valid_seen;
reg sample_req_pulse;

wire [11:0] filtered_temp;
wire [12:0] avg_sum;
wire temp_above_threshold;
wire sample_start_write;
wire alert_clear_write;
wire irq_clear_alert_write;
wire irq_clear_sample_write;

assign sample_start_write = wr_en && (wr_addr == 8'h00) && wr_data[1];
assign alert_clear_write = wr_en && (wr_addr == 8'h00) && wr_data[3];
assign irq_clear_alert_write = wr_en && (wr_addr == 8'h18) && wr_data[0];
assign irq_clear_sample_write = wr_en && (wr_addr == 8'h18) && wr_data[1];

assign avg_sum = {1'b0, adc_code} + {1'b0, prev_sample};
assign filtered_temp = avg_sum[12:1];
assign temp_above_threshold = (latest_temp > threshold_code);

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        control_reg <= 16'h0000;
        status_reg <= 16'h0000;
        irq_status_reg <= 16'h0000;
        sample_count <= 16'h0000;
        latest_temp <= 12'h000;
        prev_sample <= 12'h000;
        prev_sample_valid <= 1'b0;
        busy <= 1'b0;
        status_sample_done <= 1'b0;
        status_alert_pending <= 1'b0;
        irq_status_alert <= 1'b0;
        irq_status_sample_done <= 1'b0;
        adc_valid_seen <= 1'b0;
        threshold_code <= 12'h000;
        temp_code <= 12'h000;
        alert_status <= 1'b0;
        sample_req <= 1'b0;
        alert_irq <= 1'b0;
        rd_data <= 16'h0000;
        sample_req_pulse <= 1'b0;
    end else begin
        sample_req_pulse <= 1'b0;

        if (wr_en) begin
            case (wr_addr)
                8'h00: begin
                    control_reg[0] <= wr_data[0];
                    control_reg[2] <= wr_data[2];
                    if (wr_data[1]) begin
                        sample_req_pulse <= 1'b1;
                        busy <= 1'b1;
                    end
                    if (wr_data[3]) begin
                        alert_status <= 1'b0;
                        status_alert_pending <= 1'b0;
                    end
                    control_reg[1] <= 1'b0;
                    control_reg[3] <= 1'b0;
                end
                8'h08: begin
                    threshold_code <= wr_data[11:0];
                end
                8'h18: begin
                    if (wr_data[0]) begin
                        irq_status_alert <= 1'b0;
                        alert_status <= 1'b0;
                        status_alert_pending <= 1'b0;
                    end
                    if (wr_data[1]) begin
                        irq_status_sample_done <= 1'b0;
                        status_sample_done <= 1'b0;
                    end
                end
                default: begin
                end
            endcase
        end

        if (adc_valid) begin
            latest_temp <= filtered_temp;
            temp_code <= filtered_temp;
            prev_sample <= adc_code;
            prev_sample_valid <= 1'b1;
            adc_valid_seen <= 1'b1;
            sample_count <= sample_count + 16'd1;
            status_sample_done <= 1'b1;
            irq_status_sample_done <= 1'b1;
            busy <= 1'b0;
            if (filtered_temp > threshold_code) begin
                alert_status <= 1'b1;
                status_alert_pending <= 1'b1;
                irq_status_alert <= 1'b1;
            end
        end

        if (control_reg[0] && !busy) begin
            sample_req_pulse <= 1'b1;
            busy <= 1'b1;
        end

        if (alert_clear_write) begin
            alert_status <= 1'b0;
            status_alert_pending <= 1'b0;
            irq_status_alert <= 1'b0;
        end

        if (irq_clear_alert_write) begin
            irq_status_alert <= 1'b0;
            alert_status <= 1'b0;
            status_alert_pending <= 1'b0;
        end

        if (irq_clear_sample_write) begin
            irq_status_sample_done <= 1'b0;
            status_sample_done <= 1'b0;
        end

        status_reg[0] <= status_sample_done;
        status_reg[1] <= status_alert_pending;
        status_reg[2] <= adc_valid_seen;
        status_reg[3] <= busy;
        status_reg[15:4] <= 12'h000;

        irq_status_reg[0] <= irq_status_alert;
        irq_status_reg[1] <= irq_status_sample_done;
        irq_status_reg[15:2] <= 14'h0000;

        control_reg[15:4] <= 12'h000;

        if (wr_en || rd_en) begin
            case (rd_addr)
                8'h00: rd_data <= {12'h000, control_reg[3:0]};
                8'h04: rd_data <= status_reg;
                8'h08: rd_data <= {4'h0, threshold_code};
                8'h0C: rd_data <= {4'h0, latest_temp};
                8'h10: rd_data <= sample_count;
                8'h14: rd_data <= irq_status_reg;
                8'h18: rd_data <= 16'h0000;
                default: rd_data <= 16'h0000;
            endcase
        end else begin
            rd_data <= rd_data;
        end

        sample_req <= sample_req_pulse;
        alert_irq <= control_reg[2] && (irq_status_alert || irq_status_sample_done);
    end
end

endmodule
