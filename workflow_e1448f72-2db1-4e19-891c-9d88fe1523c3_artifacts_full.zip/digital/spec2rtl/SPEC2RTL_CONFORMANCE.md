# Spec-to-RTL Conformance Report

Status: **partial**

- Requirements checked: 38
- Matched: 32
- Partial: 0
- Missing: 5
- Inconclusive: 1
- Interface: pass
- Register map: pass
- Clock/reset: pass

## Missing Or Partial Requirements
- REQ-002 [missing]: Store CONTROL.ENABLE and CONTROL.IRQ_ENABLE bits.
- REQ-008 [missing]: CONTROL bit 0 ENABLE is a stored configuration bit.
- REQ-010 [missing]: CONTROL bit 2 IRQ_ENABLE is a stored configuration bit.
- REQ-020 [missing]: IRQ_STATUS bit 1 latches sample_done events.
- REQ-022 [missing]: IRQ_CLEAR bit 1 clears IRQ_STATUS.sample_done and STATUS.sample_done.
