module temp_sensor_adc_model (
    input  sample_req,
    input  [15:0] sensor_temp_celsius,
    input  avdd,
    input  avss,
    output reg [11:0] adc_code,
    output reg adc_valid
);

    parameter integer NOMINAL_SAMPLE_LATENCY = 2;
    parameter integer GAIN_ERROR_PPM = 0;
    parameter integer OFFSET_ERROR_LSB = 0;
    parameter integer TEMP_ZERO_C = 0;
    parameter integer TEMP_SCALE_C_PER_CODE = 1;
    parameter integer DEFAULT_ADC_CODE = 0;

    reg [31:0] latency_cnt;
    reg pending_sample;
    reg [15:0] latched_temp;
    reg [11:0] next_code;
    reg [31:0] temp_u32;
    reg [63:0] nominal_term_signed;
    reg [63:0] gain_term_signed;
    reg [63:0] offset_term_signed;
    reg [63:0] corrected_code_signed;
    reg [63:0] clamp_value_signed;
    reg [63:0] temp_term_signed;
    reg [63:0] temp_zero_ext;
    reg [63:0] temp_scale_ext;
    reg [63:0] gain_factor_ext;
    reg [63:0] temp_ext;
    reg [63:0] default_code_ext;

    always @(*) begin
        temp_u32 = {16'd0, latched_temp};
        temp_ext = {32'd0, temp_u32};
        temp_zero_ext = {{32{TEMP_ZERO_C[31]}}, TEMP_ZERO_C[31:0]};
        temp_scale_ext = {{32{TEMP_SCALE_C_PER_CODE[31]}}, TEMP_SCALE_C_PER_CODE[31:0]};
        gain_factor_ext = {{32{(1000000 + GAIN_ERROR_PPM)[31]}}, (1000000 + GAIN_ERROR_PPM)[31:0]};
        default_code_ext = {{52{DEFAULT_ADC_CODE[11]}}, DEFAULT_ADC_CODE[11:0]};

        if (TEMP_SCALE_C_PER_CODE <= 0) begin
            nominal_term_signed = 64'sd0;
        end else begin
            temp_term_signed = temp_ext;
            nominal_term_signed = (temp_term_signed - temp_zero_ext) / temp_scale_ext;
        end

        gain_term_signed = (nominal_term_signed * gain_factor_ext) / 64'sd1000000;
        offset_term_signed = {{32{OFFSET_ERROR_LSB[31]}}, OFFSET_ERROR_LSB[31:0]};
        corrected_code_signed = gain_term_signed + offset_term_signed;

        if (corrected_code_signed < 0)
            clamp_value_signed = 64'sd0;
        else if (corrected_code_signed > 64'sd4095)
            clamp_value_signed = 64'sd4095;
        else
            clamp_value_signed = corrected_code_signed;

        next_code = clamp_value_signed[11:0];
    end

    always @(posedge sample_req or posedge avdd or posedge avss) begin
        if (avdd || avss) begin
            adc_code <= DEFAULT_ADC_CODE[11:0];
            adc_valid <= 1'b0;
            pending_sample <= 1'b0;
            latency_cnt <= 32'd0;
            latched_temp <= 16'd0;
        end else begin
            latched_temp <= sensor_temp_celsius;
            pending_sample <= 1'b1;
            latency_cnt <= (NOMINAL_SAMPLE_LATENCY < 0) ? 32'd0 : NOMINAL_SAMPLE_LATENCY[31:0];

            if (NOMINAL_SAMPLE_LATENCY <= 0) begin
                adc_code <= next_code;
                adc_valid <= 1'b1;
                pending_sample <= 1'b0;
                latency_cnt <= 32'd0;
            end
        end
    end

endmodule