# Testcase And Seed Update

- Iteration: 1
- Testcase intents added: 10
- Executable tests for rerun: constrained_random_sanity, smoke_test
- Seeds: 1, 2, 7, 3, 4, 5

## Testcase Intents
- `closure_cov_001_001` -> `constrained_random_sanity` (coverage_directed_intent)
- `closure_cov_001_002` -> `constrained_random_sanity` (code_coverage_intent)
- `closure_cov_001_003` -> `constrained_random_sanity` (code_coverage_intent)
- `closure_cov_001_004` -> `constrained_random_sanity` (code_coverage_intent)
- `replay_unknown_seed_1` -> `smoke_test` (failure_replay)
- `replay_unknown_seed_2` -> `smoke_test` (failure_replay)
- `replay_unknown_seed_7` -> `smoke_test` (failure_replay)
- `replay_unknown_seed_1` -> `smoke_test` (failure_replay)
- `replay_unknown_seed_2` -> `smoke_test` (failure_replay)
- `replay_unknown_seed_7` -> `smoke_test` (failure_replay)
