# Verification Plan

- Source: generated_by_closure_loop

## Closure Iteration 1 Additions

### Coverage-Driven Objectives
- VCOV-01: `functional_coverage_missing` (functional_coverage_missing) - Confirm the coverage model was imported and sampled during simulation.
- VCOV-02: `code_line_coverage_unavailable` (code_line_coverage_unavailable) - Enable Verilator code coverage and confirm verilator_coverage is in PATH.
- VCOV-03: `code_condition_coverage_unavailable` (code_condition_coverage_unavailable) - Use a coverage backend that exports condition coverage, or review Verilator branch coverage as a condition proxy.
- VCOV-04: `code_toggle_coverage_unavailable` (code_toggle_coverage_unavailable) - Enable a simulator coverage flow that exports toggle coverage, or add toggle extraction from the native coverage database.

### Failure Replay Objectives
- VFAIL-01: replay `unknown` seed `1` with waveform and preserve logs.
- VFAIL-02: replay `unknown` seed `2` with waveform and preserve logs.
- VFAIL-03: replay `unknown` seed `7` with waveform and preserve logs.
- VFAIL-04: replay `unknown` seed `1` with waveform and preserve logs.
- VFAIL-05: replay `unknown` seed `2` with waveform and preserve logs.
- VFAIL-06: replay `unknown` seed `7` with waveform and preserve logs.

### Guardrails
- Do not edit RTL in closure iterations unless failure triage classifies a true design bug and user approval is captured.
- Every added testcase or seed must map to a coverage gap, failed seed, or missing checker objective.
