# Coverage Point Plan

- Source: generated_by_closure_loop

## Closure Iteration 1 Coverage Points

- COV_ITER001_001: `functional_coverage_missing` target bins unhit
- COV_ITER001_002: `code_line_coverage_unavailable` target bins unhit
- COV_ITER001_003: `code_condition_coverage_unavailable` target bins unhit
- COV_ITER001_004: `code_toggle_coverage_unavailable` target bins unhit
