#!/usr/bin/env bash
set -euo pipefail

echo "== ChipLoop: Digital STA PrePlace Agent =="
echo "PDK_VARIANT=sky130A"
echo "OPENLANE_IMAGE=ghcr.io/efabless/openlane2:2.4.0.dev1"
echo "WORKDIR=/work"

export OPENLANE_NUM_CORES=2

docker run --rm \
  -v "/root/chiploop-backend/backend/pdk":/pdk \
  -v "/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/d9cc207d-feb9-454c-b0f9-0c3b3c26fa81/54bd81a0-2046-4add-ba11-ab2407bc240b/digital/digital/run_work":/work \
  -e PDK=sky130A \
  -e PDK_ROOT=/pdk \
  ghcr.io/efabless/openlane2:2.4.0.dev1 \
  bash -lc 'set -e; cd /work && openlane --flow Classic --run-tag System_PD_d9cc207d-feb9-454c-b0f9-0c3b3c26fa81 --override-config RUN_LINTER=False --to OpenROAD.STAPrePNR sta_preplace/config.json'
