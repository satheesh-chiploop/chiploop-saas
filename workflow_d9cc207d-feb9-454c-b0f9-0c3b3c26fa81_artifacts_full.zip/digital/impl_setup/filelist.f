/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/d9cc207d-feb9-454c-b0f9-0c3b3c26fa81/54bd81a0-2046-4add-ba11-ab2407bc240b/digital/system/imported_rtl/temp_sensor_adc_model.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/d9cc207d-feb9-454c-b0f9-0c3b3c26fa81/54bd81a0-2046-4add-ba11-ab2407bc240b/digital/system/imported_rtl/temp_monitor_digital.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/d9cc207d-feb9-454c-b0f9-0c3b3c26fa81/54bd81a0-2046-4add-ba11-ab2407bc240b/digital/system/imported_rtl/temp_monitor_soc_phys.sv
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/d9cc207d-feb9-454c-b0f9-0c3b3c26fa81/54bd81a0-2046-4add-ba11-ab2407bc240b/digital/system/imported_rtl/temp_monitor_soc_sim.sv
