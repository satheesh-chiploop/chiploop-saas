# Digital Synthesis Summary

- **Workflow**: d9cc207d-feb9-454c-b0f9-0c3b3c26fa81
- **Status**: `ok` (rc=0)
- **Top module**: `temp_monitor_soc_phys`
- **Clock**: `clk` @ **10.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/d9cc207d-feb9-454c-b0f9-0c3b3c26fa81/54bd81a0-2046-4add-ba11-ab2407bc240b/digital/digital/synth/runs/System_PD_d9cc207d-feb9-454c-b0f9-0c3b3c26fa81/final/metrics.json`
- netlist candidates: 1 found
