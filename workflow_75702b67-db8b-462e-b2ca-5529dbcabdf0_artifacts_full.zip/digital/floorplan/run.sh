#!/usr/bin/env bash
set -euo pipefail

echo "== ChipLoop: Digital Floorplan Agent =="
echo "PDK_VARIANT=sky130A"
echo "OPENLANE_IMAGE=ghcr.io/efabless/openlane2:2.4.0.dev1"
echo "WORKDIR=/work"

export OPENLANE_NUM_CORES=2

docker run --rm   -v "/root/chiploop-backend/backend/pdk":/pdk   -v "/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/75702b67-db8b-462e-b2ca-5529dbcabdf0/8267128e-631f-4885-a6c3-d53abdeeeefd/digital/arch2tapeout/digital/run_work":/work   -e PDK=sky130A   -e PDK_ROOT=/pdk   ghcr.io/efabless/openlane2:2.4.0.dev1   bash -lc 'set -e; cd /work && openlane --flow Classic --run-tag digital_75702b67-db8b-462e-b2ca-5529dbcabdf0 --override-config RUN_LINTER=False --to OpenROAD.Floorplan floorplan/config.json'


