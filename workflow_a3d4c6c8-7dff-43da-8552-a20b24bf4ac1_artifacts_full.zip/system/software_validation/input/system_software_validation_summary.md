# System Software Validation Ingest Summary

- Generated at: 2026-08-12T02:55:40.564470+00:00
- Source workflow id: `4ea1b152-5347-443c-9b57-2e90fc76fabf`
- Validation scope: `software_only`
- Co-sim enabled: `False`
- Overall ingest status: `ready`

## Discovered assets

- `software_package_manifest` → exists=`True` | source=`supabase` | resolved=`backend/workflows/4ea1b152-5347-443c-9b57-2e90fc76fabf/system/software/package/system_software_package.json`
- `build_manifest` → exists=`True` | source=`supabase` | resolved=`backend/workflows/4ea1b152-5347-443c-9b57-2e90fc76fabf/system/software/system_software_build_manifest.json`
- `test_manifest` → exists=`False` | source=`missing` | resolved=``
- `mock_manifest` → exists=`False` | source=`missing` | resolved=``
- `sdk_manifest` → exists=`True` | source=`supabase` | resolved=`backend/workflows/4ea1b152-5347-443c-9b57-2e90fc76fabf/system/software/sdk/system_software_sdk_manifest.json`
- `application_manifest` → exists=`True` | source=`supabase` | resolved=`backend/workflows/4ea1b152-5347-443c-9b57-2e90fc76fabf/system/software/apps/system_software_application_manifest.json`
- `tools_manifest` → exists=`False` | source=`missing` | resolved=``
- `adapter_manifest` → exists=`True` | source=`supabase` | resolved=`backend/workflows/4ea1b152-5347-443c-9b57-2e90fc76fabf/system/software/adapter/system_software_adapter_manifest.json`
- `services_manifest` → exists=`True` | source=`supabase` | resolved=`backend/workflows/4ea1b152-5347-443c-9b57-2e90fc76fabf/system/software/services/system_software_core_services_manifest.json`
- `input_contract` → exists=`True` | source=`supabase` | resolved=`backend/workflows/4ea1b152-5347-443c-9b57-2e90fc76fabf/system/software/input/system_software_input_contract.json`
- `api_contract` → exists=`True` | source=`supabase` | resolved=`backend/workflows/4ea1b152-5347-443c-9b57-2e90fc76fabf/system/software/sdk/system_software_api_contract.json`
- `executive_summary` → exists=`False` | source=`missing` | resolved=``

## Workspace members

- `sdk/adaptive_aero_control`
- `services`
- `adapter/adaptive_aero_control_adapter`
- `apps/control_service`
- `apps/diagnostics`
- `apps/demo_cli`

## Missing required assets

- none
