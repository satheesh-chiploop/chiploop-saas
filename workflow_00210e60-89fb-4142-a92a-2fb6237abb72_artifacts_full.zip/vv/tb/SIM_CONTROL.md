# System Simulation Control

Generated files:
- `run_regression.py`: orchestrates multi-seed runs via `make TESTCASE=...`
- `simulation_manifest.json`: consolidated simulation-control manifest for the integrated system DUT

Key resolved inputs:
- Top module: `temp_monitor_soc_sim`
- System integration intent: `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/00210e60-89fb-4142-a92a-2fb6237abb72/9600d8a1-7620-49a8-9890-0c9e76ec61ad/digital/system/integration/system_integration_intent.json`
- SoC top (sim): `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/00210e60-89fb-4142-a92a-2fb6237abb72/9600d8a1-7620-49a8-9890-0c9e76ec61ad/digital/system/imported_rtl/temp_monitor_soc_sim.sv`
- RTL file count: `8`

Seed management:
- override with `RANDOM_SEED=<int>`

Usage:
```bash
python run_regression.py --tests system_smoke_test integrated_input_sanity --seeds 1 2 3 4 5
```
