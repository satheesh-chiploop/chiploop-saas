# System Simulation Summary + Coverage

- Top module: temp_monitor_soc_sim
- Status: partial
- Total simulation runs: 6
- Simulation pass count: 5
- Simulation fail count: 1
- Total runtime (s): 17.667
- Coverage status: ok
- Functional coverage %: 76.67
- Coverage bins hit: 23
- Coverage total bins: 30
- Code line coverage %: 44.49
- Code branch coverage %: 0.25
- Code condition coverage %: 0.25
- Code toggle coverage %: 4.55
- Assertions total: 0
- Assertion failures: 0
- Formal status: fail

## Waveforms
- `vv/tb/dump.vcd`
