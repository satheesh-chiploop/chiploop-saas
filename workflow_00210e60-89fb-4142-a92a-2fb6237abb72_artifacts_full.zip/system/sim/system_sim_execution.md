# System Simulation Execution Report

- Top: `temp_monitor_soc_sim`
- Tests run: 6
- Passed: 5
- Failed: 1
- Total runtime (s): 17.667
- Coverage JSON present: True
- Coverage MD present: True

## Run Matrix
- `system_smoke_test` / seed `1` → FAIL (rc=2, 1.358s)
- `system_smoke_test` / seed `2` → PASS (rc=0, 6.937s)
- `system_smoke_test` / seed `7` → PASS (rc=0, 2.297s)
- `integrated_input_sanity` / seed `1` → PASS (rc=0, 2.346s)
- `integrated_input_sanity` / seed `2` → PASS (rc=0, 2.377s)
- `integrated_input_sanity` / seed `7` → PASS (rc=0, 2.352s)

## Waveforms
- `vv/tb/dump.vcd`
