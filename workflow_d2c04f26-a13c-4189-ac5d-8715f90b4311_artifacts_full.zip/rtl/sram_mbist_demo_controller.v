module sram_mbist_demo_controller (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    bist_start,
    rd_data,
    ready,
    bist_done,
    bist_fail,
    irq,
    mem_csb,
    mem_web,
    mem_addr,
    mem_din,
    mem_dout,
    bist_req,
    irq_enable,
    bist_done_latched,
    bist_fail_latched,
    last_fail_addr
);

input clk;
input reset_n;
input wr_en;
input [7:0] wr_addr;
input [31:0] wr_data;
input rd_en;
input [7:0] rd_addr;
input bist_start;

output [31:0] rd_data;
output ready;
output bist_done;
output bist_fail;
output irq;
output mem_csb;
output mem_web;
output [5:0] mem_addr;
output [31:0] mem_din;
input [31:0] mem_dout;
output bist_req;
output irq_enable;
output bist_done_latched;
output bist_fail_latched;
output [5:0] last_fail_addr;

reg [31:0] rd_data_r;
reg ready_r;
reg bist_done_r;
reg bist_fail_r;
reg irq_r;
reg mem_csb_r;
reg mem_web_r;
reg [5:0] mem_addr_r;
reg [31:0] mem_din_r;
reg bist_req_r;
reg irq_enable_r;
reg bist_done_latched_r;
reg bist_fail_latched_r;
reg [5:0] last_fail_addr_r;

reg [31:0] control_reg;
reg [31:0] mem_addr_reg;
reg [31:0] mem_wdata_reg;
reg [31:0] mem_rdata_reg;
reg [31:0] mem_control_reg;
reg [31:0] bist_control_reg;
reg [31:0] bist_status_reg;
reg [31:0] irq_status_reg;

wire [5:0] mem_addr_eff;
wire write_fire;
wire read_fire;
wire bist_start_fire;
wire bist_clear_fire;
wire irq_done_set;
wire irq_fail_set;
wire soft_reset_fire;
wire control_enable;

assign mem_addr_eff = mem_addr_reg[5:0];
assign write_fire = wr_en & (wr_addr == 8'h14) & wr_data[0];
assign read_fire = rd_en & (rd_addr == 8'h14) & mem_control_reg[1];
assign bist_start_fire = bist_start | bist_control_reg[0];
assign bist_clear_fire = wr_en & (wr_addr == 8'h18) & bist_control_reg[1];
assign irq_done_set = bist_done_latched_r;
assign irq_fail_set = bist_fail_latched_r;
assign soft_reset_fire = control_reg[1];
assign control_enable = control_reg[0];

assign rd_data = rd_data_r;
assign ready = ready_r;
assign bist_done = bist_done_r;
assign bist_fail = bist_fail_r;
assign irq = irq_r;
assign mem_csb = mem_csb_r;
assign mem_web = mem_web_r;
assign mem_addr = mem_addr_r;
assign mem_din = mem_din_r;
assign bist_req = bist_req_r;
assign irq_enable = irq_enable_r;
assign bist_done_latched = bist_done_latched_r;
assign bist_fail_latched = bist_fail_latched_r;
assign last_fail_addr = last_fail_addr_r;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        rd_data_r <= 32'h00000000;
        ready_r <= 1'b0;
        bist_done_r <= 1'b0;
        bist_fail_r <= 1'b0;
        irq_r <= 1'b0;
        mem_csb_r <= 1'b1;
        mem_web_r <= 1'b1;
        mem_addr_r <= 6'h00;
        mem_din_r <= 32'h00000000;
        bist_req_r <= 1'b0;
        irq_enable_r <= 1'b0;
        bist_done_latched_r <= 1'b0;
        bist_fail_latched_r <= 1'b0;
        last_fail_addr_r <= 6'h00;
        control_reg <= 32'h00000000;
        mem_addr_reg <= 32'h00000000;
        mem_wdata_reg <= 32'h00000000;
        mem_rdata_reg <= 32'h00000000;
        mem_control_reg <= 32'h00000000;
        bist_control_reg <= 32'h00000000;
        bist_status_reg <= 32'h00000000;
        irq_status_reg <= 32'h00000000;
    end else begin
        if (soft_reset_fire) begin
            rd_data_r <= 32'h00000000;
            ready_r <= 1'b0;
            bist_done_r <= 1'b0;
            bist_fail_r <= 1'b0;
            irq_r <= 1'b0;
            mem_csb_r <= 1'b1;
            mem_web_r <= 1'b1;
            mem_addr_r <= 6'h00;
            mem_din_r <= 32'h00000000;
            bist_req_r <= 1'b0;
            bist_done_latched_r <= 1'b0;
            bist_fail_latched_r <= 1'b0;
            last_fail_addr_r <= 6'h00;
            control_reg <= 32'h00000000;
            mem_addr_reg <= 32'h00000000;
            mem_wdata_reg <= 32'h00000000;
            mem_rdata_reg <= 32'h00000000;
            mem_control_reg <= 32'h00000000;
            bist_control_reg <= 32'h00000000;
            bist_status_reg <= 32'h00000000;
            irq_status_reg <= 32'h00000000;
            irq_enable_r <= 1'b0;
        end else begin
            if (wr_en && (wr_addr == 8'h00)) begin
                control_reg <= wr_data;
                irq_enable_r <= wr_data[2];
            end
            if (wr_en && (wr_addr == 8'h08)) begin
                mem_addr_reg <= wr_data;
            end
            if (wr_en && (wr_addr == 8'h0C)) begin
                mem_wdata_reg <= wr_data;
            end
            if (wr_en && (wr_addr == 8'h14)) begin
                mem_control_reg <= wr_data;
            end
            if (wr_en && (wr_addr == 8'h18)) begin
                bist_control_reg <= wr_data;
            end
            if (wr_en && (wr_addr == 8'h20)) begin
                irq_status_reg[0] <= wr_data[0];
                irq_status_reg[1] <= wr_data[1];
            end
            if (wr_en && (wr_addr == 8'h24)) begin
                if (wr_data[0]) begin
                    irq_status_reg[0] <= 1'b0;
                end
                if (wr_data[1]) begin
                    irq_status_reg[1] <= 1'b0;
                end
            end

            if (write_fire && control_enable) begin
                mem_csb_r <= 1'b0;
                mem_web_r <= 1'b0;
                mem_addr_r <= mem_addr_eff;
                mem_din_r <= mem_wdata_reg;
            end else if (read_fire && control_enable) begin
                mem_csb_r <= 1'b0;
                mem_web_r <= 1'b1;
                mem_addr_r <= mem_addr_eff;
                mem_din_r <= mem_din_r;
            end else begin
                mem_csb_r <= 1'b1;
                mem_web_r <= 1'b1;
                mem_addr_r <= mem_addr_eff;
                mem_din_r <= mem_din_r;
            end

            if (read_fire && control_enable) begin
                mem_rdata_reg <= mem_dout;
                rd_data_r <= mem_dout;
            end else if (wr_en && (wr_addr == 8'h10)) begin
                mem_rdata_reg <= wr_data;
                rd_data_r <= wr_data;
            end

            if (bist_start_fire && control_enable) begin
                bist_req_r <= 1'b1;
                bist_done_latched_r <= 1'b0;
                bist_fail_latched_r <= 1'b0;
                last_fail_addr_r <= 6'h00;
                bist_done_r <= 1'b0;
                bist_fail_r <= 1'b0;
                bist_status_reg[0] <= 1'b0;
                bist_status_reg[1] <= 1'b0;
                bist_status_reg[2] <= 1'b1;
            end else begin
                bist_req_r <= 1'b0;
                bist_status_reg[2] <= 1'b0;
            end

            if (bist_req_r) begin
                bist_done_r <= 1'b1;
                bist_done_latched_r <= 1'b1;
                bist_status_reg[0] <= 1'b1;
                irq_status_reg[0] <= 1'b1;
            end

            if (bist_req_r & mem_dout[0]) begin
                bist_fail_r <= 1'b1;
                bist_fail_latched_r <= 1'b1;
                last_fail_addr_r <= mem_addr_eff;
                bist_status_reg[1] <= 1'b1;
                bist_status_reg[8:3] <= mem_addr_eff;
                irq_status_reg[1] <= 1'b1;
            end

            if (bist_clear_fire) begin
                bist_done_r <= 1'b0;
                bist_fail_r <= 1'b0;
                bist_done_latched_r <= 1'b0;
                bist_fail_latched_r <= 1'b0;
                irq_status_reg[0] <= 1'b0;
                irq_status_reg[1] <= 1'b0;
                bist_status_reg <= 32'h00000000;
                last_fail_addr_r <= 6'h00;
            end

            ready_r <= control_enable & ~bist_req_r;
            irq_r <= irq_enable_r & (irq_done_set | irq_fail_set);
            bist_control_reg[0] <= 1'b0;
            bist_control_reg[1] <= 1'b0;
        end
    end
end

endmodule
