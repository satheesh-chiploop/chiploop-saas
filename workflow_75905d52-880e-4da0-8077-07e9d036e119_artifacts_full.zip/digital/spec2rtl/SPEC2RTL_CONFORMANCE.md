# Spec-to-RTL Conformance Report

Status: **issues**

- Requirements checked: 27
- Matched: 0
- Partial: 3
- Missing: 17
- Inconclusive: 0
- Interface: issues
- Register map: not_applicable
- Clock/reset: pass

## Missing Or Partial Requirements
- REQ-001 [missing]: This version is controlled by firmware through a memory-mapped register interface.
- REQ-002 [missing]: Register map:
- REQ-003 [missing]: 0x00 CONTROL: bit 0 ENABLE, read/write
- REQ-004 [missing]: 0x04 DUTY_CYCLE: duty_cycle[7:0], read/write
- REQ-005 [missing]: 0x08 PERIOD: period[7:0], read/write
- REQ-006 [partial]: 0x0C COUNTER_VALUE: counter_value[7:0], read-only status
- REQ-007 [partial]: All registers and outputs reset to zero when reset_n is low.
- REQ-008 [missing]: Counter increments every clock while CONTROL.ENABLE is high and PERIOD is nonzero.
- REQ-009 [missing]: Counter wraps to zero when it reaches PERIOD.
- REQ-010 [partial]: Reads return the addressed register value, including live COUNTER_VALUE status.
- REQ-011 [missing]: Generate synthesizable SystemVerilog, a register map, assertions, a simulation testbench, UPF-lite collateral, and a packaging manifest.
