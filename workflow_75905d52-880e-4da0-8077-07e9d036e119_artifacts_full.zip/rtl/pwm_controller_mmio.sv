module pwm_controller_mmio (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    rd_data,
    pwm_out,
    counter_value
);

input clk;
input reset_n;
input wr_en;
input [7:0] wr_addr;
input [7:0] wr_data;
input rd_en;
input [7:0] rd_addr;
output [7:0] rd_data;
output pwm_out;
output [7:0] counter_value;

reg [7:0] control_reg;
reg [7:0] duty_cycle_reg;
reg [7:0] period_reg;
reg [7:0] counter_reg;
reg [7:0] rd_data_reg;
reg pwm_out_reg;

assign rd_data = rd_data_reg;
assign pwm_out = pwm_out_reg;
assign counter_value = counter_reg;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        control_reg <= 8'h00;
        duty_cycle_reg <= 8'h00;
        period_reg <= 8'h00;
        counter_reg <= 8'h00;
    end else begin
        if (wr_en) begin
            case (wr_addr)
                8'h00: control_reg <= {7'h00, wr_data[0]};
                8'h04: duty_cycle_reg <= wr_data;
                8'h08: period_reg <= wr_data;
                default: begin
                end
            endcase
        end

        if (control_reg[0] && (period_reg != 8'h00)) begin
            if (counter_reg >= period_reg)
                counter_reg <= 8'h00;
            else
                counter_reg <= counter_reg + 8'h01;
        end
    end
end

always @(*) begin
    rd_data_reg = 8'h00;
    pwm_out_reg = 1'b0;

    case (rd_addr)
        8'h00: rd_data_reg = control_reg;
        8'h04: rd_data_reg = duty_cycle_reg;
        8'h08: rd_data_reg = period_reg;
        8'h0C: rd_data_reg = counter_reg;
        default: rd_data_reg = 8'h00;
    endcase

    if (control_reg[0] && (counter_reg < duty_cycle_reg))
        pwm_out_reg = 1'b1;
    else
        pwm_out_reg = 1'b0;
end

endmodule
