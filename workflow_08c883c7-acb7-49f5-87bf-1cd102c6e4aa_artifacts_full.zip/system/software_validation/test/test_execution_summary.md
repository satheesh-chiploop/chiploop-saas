# Test Execution Summary

- Status: **pass**
- Test root: `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/08c883c7-acb7-49f5-87bf-1cd102c6e4aa/5b0a9c69-26f2-441d-96eb-d832ce0b273f/system/restored_system_software/system/software`
- Test manifest present: `True`
- Cargo: `/root/.cargo/bin/cargo`
- Command: `/root/.cargo/bin/cargo test --workspace --all-targets`
- Return code: `0`
