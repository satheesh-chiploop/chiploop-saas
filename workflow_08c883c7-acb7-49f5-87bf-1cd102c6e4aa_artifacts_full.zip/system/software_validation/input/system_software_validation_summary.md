# System Software Validation Ingest Summary

- Generated at: 2026-09-16T17:44:26.775069+00:00
- Source workflow id: `85f5dd73-7711-4216-b70e-c4beab66ae62`
- Validation scope: `software_only`
- Co-sim enabled: `False`
- Overall ingest status: `ready`

## Discovered assets

- `software_package_manifest` → exists=`True` | source=`supabase` | resolved=`backend/workflows/85f5dd73-7711-4216-b70e-c4beab66ae62/system/software/package/system_software_package.json`
- `build_manifest` → exists=`True` | source=`supabase` | resolved=`backend/workflows/85f5dd73-7711-4216-b70e-c4beab66ae62/system/software/system_software_build_manifest.json`
- `test_manifest` → exists=`True` | source=`supabase` | resolved=`backend/workflows/85f5dd73-7711-4216-b70e-c4beab66ae62/system/software/tests/system_software_test_manifest.json`
- `mock_manifest` → exists=`True` | source=`supabase` | resolved=`backend/workflows/85f5dd73-7711-4216-b70e-c4beab66ae62/system/software/mock/system_software_mock_manifest.json`
- `sdk_manifest` → exists=`True` | source=`supabase` | resolved=`backend/workflows/85f5dd73-7711-4216-b70e-c4beab66ae62/system/software/sdk/system_software_sdk_manifest.json`
- `application_manifest` → exists=`True` | source=`supabase` | resolved=`backend/workflows/85f5dd73-7711-4216-b70e-c4beab66ae62/system/software/apps/system_software_application_manifest.json`
- `tools_manifest` → exists=`True` | source=`supabase` | resolved=`backend/workflows/85f5dd73-7711-4216-b70e-c4beab66ae62/system/software/tools/system_software_tools_manifest.json`
- `adapter_manifest` → exists=`True` | source=`supabase` | resolved=`backend/workflows/85f5dd73-7711-4216-b70e-c4beab66ae62/system/software/adapter/system_software_adapter_manifest.json`
- `services_manifest` → exists=`True` | source=`supabase` | resolved=`backend/workflows/85f5dd73-7711-4216-b70e-c4beab66ae62/system/software/services/system_software_core_services_manifest.json`
- `input_contract` → exists=`True` | source=`supabase` | resolved=`backend/workflows/85f5dd73-7711-4216-b70e-c4beab66ae62/system/software/input/system_software_input_contract.json`
- `api_contract` → exists=`True` | source=`supabase` | resolved=`backend/workflows/85f5dd73-7711-4216-b70e-c4beab66ae62/system/software/sdk/system_software_api_contract.json`
- `executive_summary` → exists=`True` | source=`supabase` | resolved=`backend/workflows/85f5dd73-7711-4216-b70e-c4beab66ae62/system/software/executive/system_software_executive_summary.json`

## Workspace members

- `sdk/physical_ai_product`
- `services`
- `adapter/physical_ai_product_adapter`
- `apps/control_service`
- `apps/diagnostics`
- `apps/demo_cli`
- `tools/reg_viewer`
- `tools/diag_cli`

## Missing required assets

- none
