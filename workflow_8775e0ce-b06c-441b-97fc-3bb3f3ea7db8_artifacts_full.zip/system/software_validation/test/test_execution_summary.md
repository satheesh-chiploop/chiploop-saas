# Test Execution Summary

- Status: **pass**
- Test root: `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/8775e0ce-b06c-441b-97fc-3bb3f3ea7db8/c7818520-af33-4cba-867d-959a2e5fa0d2/system/restored_system_software/system/software`
- Test manifest present: `True`
- Cargo: `/root/.cargo/bin/cargo`
- Command: `/root/.cargo/bin/cargo test --workspace --all-targets`
- Return code: `0`
