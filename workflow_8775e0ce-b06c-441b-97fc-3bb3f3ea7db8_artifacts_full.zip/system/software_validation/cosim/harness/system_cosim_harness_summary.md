# System Software CoSim Harness Summary

- Generated at: `2026-09-16T21:59:56.517277+00:00`
- L1 ready: `True`
- Harness status: `ready`
- Scenario count: `9`

## Blocked dependencies
- none

## Resolved commands
- `control_service_boot_smoke` → `make -C /root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/8775e0ce-b06c-441b-97fc-3bb3f3ea7db8/c7818520-af33-4cba-867d-959a2e5fa0d2/system/system/restored_rtl_sim/31571b55-1a1b-4024-8ac0-9afb70a2905a/vv/tb`
- `control_service_boot_smoke` → `cargo run -p ss_app_control_service -- --scenario control_service_boot_smoke`
- `control_service_register_rw_basic` → `cargo run -p ss_app_control_service -- --scenario control_service_register_rw_basic`
- `diagnostics_boot_smoke` → `cargo run -p ss_app_diagnostics -- --scenario diagnostics_boot_smoke`
- `diagnostics_register_rw_basic` → `cargo run -p ss_app_diagnostics -- --scenario diagnostics_register_rw_basic`
- `demo_cli_boot_smoke` → `cargo run -p ss_app_demo_cli -- --scenario demo_cli_boot_smoke`
- `demo_cli_register_rw_basic` → `cargo run -p ss_app_demo_cli -- --scenario demo_cli_register_rw_basic`
