# Simulation Summary + Coverage

- Total simulation runs: 20
- Simulation pass count: 20
- Simulation fail count: 0
- Coverage status: ok
- Functional coverage %: 50.0
- Coverage bins hit: 2
- Coverage total bins: 4
- Functional bin gaps: 2
- Code line coverage: 51.52%
- Code branch coverage: 12.12%
- Code condition coverage: 12.12%
- Code toggle coverage: 37.5%
- SVA/assertion status: missing
- SVA/assertion pass %: missing
- Formal status: not_enabled
- Golden model status: not_enabled
- Simulator tool: verilator
- Code coverage tool: verilator_coverage
- Formal tool: none
- Golden model tool: none

## Functional Coverage Not Met
- outputs.led: bins 1/2, missing nonzero, seen values [0]
- inputs.clk: bins 1/2, missing zero, seen values [1]
