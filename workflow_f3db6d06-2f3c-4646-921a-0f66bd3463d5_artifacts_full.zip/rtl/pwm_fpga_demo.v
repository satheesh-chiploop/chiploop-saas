module pwm_fpga_demo (
    clk,
    led
);

input clk;
output led;

reg [7:0] pwm_counter;
reg [7:0] slow_counter;
reg [7:0] duty_cycle;
reg direction_up;
reg led_r;

assign led = led_r;

always @(posedge clk) begin
    pwm_counter <= pwm_counter + 8'h01;
    slow_counter <= slow_counter + 8'h01;

    if (slow_counter == 8'hFF) begin
        if (direction_up) begin
            if (duty_cycle == 8'hFF) begin
                duty_cycle <= 8'hFE;
                direction_up <= 1'b0;
            end else begin
                duty_cycle <= duty_cycle + 8'h01;
            end
        end else begin
            if (duty_cycle == 8'h00) begin
                duty_cycle <= 8'h01;
                direction_up <= 1'b1;
            end else begin
                duty_cycle <= duty_cycle - 8'h01;
            end
        end
    end

    if (pwm_counter < duty_cycle) begin
        led_r <= 1'b1;
    end else begin
        led_r <= 1'b0;
    end
end

initial begin
    pwm_counter = 8'h00;
    slow_counter = 8'h00;
    duty_cycle = 8'h00;
    direction_up = 1'b1;
    led_r = 1'b0;
end

endmodule
