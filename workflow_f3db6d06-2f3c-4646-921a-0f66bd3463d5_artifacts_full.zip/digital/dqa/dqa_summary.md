# Digital DQA Summary
- workflow_id: `f3db6d06-2f3c-4646-921a-0f66bd3463d5`
- status: `failed`
- rtl files: `1`
- warning count: `0`

## Stage Status
- rtl_lint: `warn`
- cdc: `unavailable`
- reset_integrity: `unavailable`
- synthesis_readiness: `failed`

## Blocking Issues
- yosys_synthesis_errors
