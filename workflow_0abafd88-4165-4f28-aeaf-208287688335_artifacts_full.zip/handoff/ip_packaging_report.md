# IP Packaging & Handoff Report

- Top: `motor_control_top`
- Package: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0abafd88-4165-4f28-aeaf-208287688335/0fdbbf3d-b33e-4ed8-9589-2e1762541eec/digital/arch2tapeout/handoff/motor_control_top_ip_package`
- Zip: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0abafd88-4165-4f28-aeaf-208287688335/0fdbbf3d-b33e-4ed8-9589-2e1762541eec/digital/arch2tapeout/handoff/motor_control_top_ip_package.zip`

## Bucket counts
- **rtl**: 6
- **spec**: 1
- **arch**: 0
- **microarch**: 0
- **regmap**: 1
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 2
