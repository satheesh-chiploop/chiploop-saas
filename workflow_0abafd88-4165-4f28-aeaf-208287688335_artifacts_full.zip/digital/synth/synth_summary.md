# Digital Synthesis Summary

- **Workflow**: 0abafd88-4165-4f28-aeaf-208287688335
- **Status**: `ok` (rc=0)
- **Top module**: `motor_control_top`
- **Clock**: `clk` @ **10.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0abafd88-4165-4f28-aeaf-208287688335/0fdbbf3d-b33e-4ed8-9589-2e1762541eec/digital/arch2tapeout/digital/synth/runs/Digital_Arch2Tapeout_0abafd88-4165-4f28-aeaf-208287688335/final/metrics.json`
- netlist candidates: 1 found
