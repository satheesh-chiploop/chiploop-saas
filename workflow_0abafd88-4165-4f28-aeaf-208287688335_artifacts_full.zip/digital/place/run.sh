#!/usr/bin/env bash
set -euo pipefail

echo "== ChipLoop: Digital Placement Agent =="
echo "PDK_VARIANT=sky130A"
echo "OPENLANE_IMAGE=ghcr.io/efabless/openlane2:2.4.0.dev1"
echo "WORKDIR=/work"

export OPENLANE_NUM_CORES=2

docker run --rm   -v "/root/chiploop-backend/backend/pdk":/pdk   -v "/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0abafd88-4165-4f28-aeaf-208287688335/0fdbbf3d-b33e-4ed8-9589-2e1762541eec/digital/arch2tapeout/digital/run_work":/work   -e PDK=sky130A   -e PDK_ROOT=/pdk   ghcr.io/efabless/openlane2:2.4.0.dev1   bash -lc 'set -e; cd /work && openlane --flow Classic --run-tag Digital_Arch2Tapeout_0abafd88-4165-4f28-aeaf-208287688335 --override-config RUN_LINTER=False --to OpenROAD.DetailedPlacement place/config.json'


