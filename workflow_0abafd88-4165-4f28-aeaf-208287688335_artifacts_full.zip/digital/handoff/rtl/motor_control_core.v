module motor_control_core (
    clk,
    reset_n,
    cfg_launch_req,
    cfg_seq_id,
    cfg_flow_velocity,
    cfg_geom_token,
    cfg_geom_format,
    cfg_queue_enable,
    cfg_queue_depth,
    cfg_timeout_thresh,
    cfg_velocity_min,
    cfg_velocity_max,
    cfg_ref_velocity,
    cfg_safe_cmd,
    cfg_cmd_min,
    cfg_cmd_max,
    cfg_rate_limit_en,
    cfg_rate_limit_step,
    cfg_envelope_policy_en,
    req_ready,
    req_valid,
    req_desc,
    rsp_valid,
    rsp_desc,
    rsp_ready,
    model_cmd_candidate,
    model_cmd_valid,
    approved_cmd,
    fallback_cmd,
    request_active,
    response_accepted,
    stale_reject,
    timeout_flag,
    clamp_applied,
    fallback_active,
    generic_error,
    seq_id_out,
    watchdog_age
);
    input clk;
    input reset_n;
    input cfg_launch_req;
    input [15:0] cfg_seq_id;
    input [15:0] cfg_flow_velocity;
    input [31:0] cfg_geom_token;
    input [3:0] cfg_geom_format;
    input cfg_queue_enable;
    input [1:0] cfg_queue_depth;
    input [15:0] cfg_timeout_thresh;
    input [15:0] cfg_velocity_min;
    input [15:0] cfg_velocity_max;
    input [15:0] cfg_ref_velocity;
    input [15:0] cfg_safe_cmd;
    input [15:0] cfg_cmd_min;
    input [15:0] cfg_cmd_max;
    input cfg_rate_limit_en;
    input [15:0] cfg_rate_limit_step;
    input cfg_envelope_policy_en;
    input req_ready;
    output reg req_valid;
    output reg [127:0] req_desc;
    output reg rsp_valid;
    output reg [127:0] rsp_desc;
    output reg rsp_ready;
    output reg [15:0] model_cmd_candidate;
    output reg model_cmd_valid;
    output reg [15:0] approved_cmd;
    output reg [15:0] fallback_cmd;
    output reg request_active;
    output reg response_accepted;
    output reg stale_reject;
    output reg timeout_flag;
    output reg clamp_applied;
    output reg fallback_active;
    output reg generic_error;
    output reg [15:0] seq_id_out;
    output reg [15:0] watchdog_age;
    localparam S_IDLE = 3'd0;
    localparam S_ISSUE = 3'd1;
    localparam S_WAIT = 3'd2;
    localparam S_VALIDATE = 3'd3;
    localparam S_APPLY = 3'd4;
    localparam S_FALLBACK = 3'd5;
    localparam S_ERROR = 3'd6;

    reg [2:0] state;
    reg [2:0] state_n;
    reg [15:0] cmd_raw;
    reg [15:0] cmd_clamped;
    reg [15:0] cmd_limited;
    reg [15:0] age_next;
    reg [15:0] seq_latched;
    reg launch_ok;

    always @(*) begin
        state_n = state;
        cmd_raw = 16'h0000;
        cmd_clamped = 16'h0000;
        cmd_limited = 16'h0000;
        age_next = watchdog_age;
        launch_ok = cfg_launch_req & ((cfg_flow_velocity >= cfg_velocity_min) & (cfg_flow_velocity <= cfg_velocity_max));
        if (cfg_envelope_policy_en) begin
            launch_ok = launch_ok & (cfg_ref_velocity == 16'd38);
        end
        case (state)
            S_IDLE: begin
                if (launch_ok) begin
                    state_n = S_ISSUE;
                end
            end
            S_ISSUE: begin
                if (req_ready) begin
                    state_n = S_WAIT;
                end
            end
            S_WAIT: begin
                age_next = watchdog_age + 16'd1;
                if (watchdog_age >= cfg_timeout_thresh) begin
                    state_n = S_FALLBACK;
                end else if (rsp_valid) begin
                    state_n = S_VALIDATE;
                end
            end
            S_VALIDATE: begin
                if (rsp_desc[15:0] == cfg_seq_id) begin
                    cmd_raw = rsp_desc[31:16];
                    cmd_clamped = cmd_raw;
                    if (cmd_raw < cfg_cmd_min) begin
                        cmd_clamped = cfg_cmd_min;
                    end else if (cmd_raw > cfg_cmd_max) begin
                        cmd_clamped = cfg_cmd_max;
                    end
                    if (cfg_rate_limit_en) begin
                        if (cmd_clamped > (cfg_safe_cmd + cfg_rate_limit_step)) begin
                            cmd_limited = cfg_safe_cmd + cfg_rate_limit_step;
                        end else if (cmd_clamped + cfg_rate_limit_step < cfg_safe_cmd) begin
                            cmd_limited = cfg_safe_cmd - cfg_rate_limit_step;
                        end else begin
                            cmd_limited = cmd_clamped;
                        end
                    end else begin
                        cmd_limited = cmd_clamped;
                    end
                    state_n = S_APPLY;
                end else begin
                    state_n = S_FALLBACK;
                end
            end
            S_APPLY: begin
                state_n = S_IDLE;
            end
            S_FALLBACK: begin
                state_n = S_ERROR;
            end
            S_ERROR: begin
                state_n = S_IDLE;
            end
            default: begin
                state_n = S_IDLE;
            end
        endcase
    end

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            state <= S_IDLE;
            req_valid <= 1'b0;
            req_desc <= 128'h00000000000000000000000000000000;
            rsp_valid <= 1'b0;
            rsp_desc <= 128'h00000000000000000000000000000000;
            rsp_ready <= 1'b1;
            model_cmd_candidate <= 16'h0000;
            model_cmd_valid <= 1'b0;
            approved_cmd <= 16'h0000;
            fallback_cmd <= 16'h0000;
            request_active <= 1'b0;
            response_accepted <= 1'b0;
            stale_reject <= 1'b0;
            timeout_flag <= 1'b0;
            clamp_applied <= 1'b0;
            fallback_active <= 1'b1;
            generic_error <= 1'b0;
            seq_id_out <= 16'h0000;
            watchdog_age <= 16'h0000;
            seq_latched <= 16'h0000;
        end else begin
            state <= state_n;
            req_valid <= req_valid;
            req_desc <= req_desc;
            rsp_valid <= rsp_valid;
            rsp_desc <= rsp_desc;
            rsp_ready <= rsp_ready;
            model_cmd_candidate <= model_cmd_candidate;
            model_cmd_valid <= model_cmd_valid;
            approved_cmd <= approved_cmd;
            fallback_cmd <= fallback_cmd;
            request_active <= request_active;
            response_accepted <= response_accepted;
            stale_reject <= stale_reject;
            timeout_flag <= timeout_flag;
            clamp_applied <= clamp_applied;
            fallback_active <= fallback_active;
            generic_error <= generic_error | 1'b0;
            seq_id_out <= seq_id_out;
            watchdog_age <= age_next;
            seq_latched <= cfg_seq_id;
        end
    end
endmodule
