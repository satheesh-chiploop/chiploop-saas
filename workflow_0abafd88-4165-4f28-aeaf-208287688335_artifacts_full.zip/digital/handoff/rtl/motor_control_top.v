module motor_control_top (
    clk,
    reset_n,
    reg_valid,
    reg_write,
    reg_addr,
    reg_wdata,
    reg_rdata,
    reg_ready,
    req_valid,
    req_ready,
    req_desc,
    rsp_valid,
    rsp_ready,
    rsp_desc,
    actuator_cmd,
    status_irq,
    status_flags
);
    input clk;
    input reset_n;
    input reg_valid;
    input reg_write;
    input [3:0] reg_addr;
    input [63:0] reg_wdata;
    output [63:0] reg_rdata;
    output reg_ready;
    output req_valid;
    input req_ready;
    output [127:0] req_desc;
    input rsp_valid;
    output rsp_ready;
    input [127:0] rsp_desc;
    output [15:0] actuator_cmd;
    output status_irq;
    output [7:0] status_flags;
    wire cfg_launch_req;
    wire [15:0] cfg_seq_id;
    wire [15:0] cfg_flow_velocity;
    wire [31:0] cfg_geom_token;
    wire [3:0] cfg_geom_format;
    wire cfg_queue_enable;
    wire [1:0] cfg_queue_depth;
    wire [15:0] cfg_timeout_thresh;
    wire [15:0] cfg_velocity_min;
    wire [15:0] cfg_velocity_max;
    wire [15:0] cfg_ref_velocity;
    wire [15:0] cfg_safe_cmd;
    wire [15:0] cfg_cmd_min;
    wire [15:0] cfg_cmd_max;
    wire cfg_rate_limit_en;
    wire [15:0] cfg_rate_limit_step;
    wire cfg_envelope_policy_en;

    wire request_active;
    wire response_accepted;
    wire stale_reject;
    wire timeout_flag;
    wire clamp_applied;
    wire fallback_active;
    wire generic_error;
    wire [15:0] seq_id_out;
    wire [15:0] watchdog_age;

    wire [15:0] approved_cmd;
    wire [15:0] fallback_cmd;
    wire model_cmd_valid;
    wire [15:0] model_cmd_candidate;
    wire launch_allow;
    wire policy_error;
    wire env_match;

    wire desc_generic_error;

wire req_ready_from_u_motor_control_descriptor_if;
wire [127:0] rsp_desc_from_u_motor_control_core;
wire [127:0] rsp_desc_from_u_motor_control_descriptor_if;
wire rsp_valid_from_u_motor_control_core;
wire rsp_valid_from_u_motor_control_descriptor_if;
    motor_control_regfile u_motor_control_regfile (
        .clk(clk),
        .reset_n(reset_n),
        .reg_valid(reg_valid),
        .reg_write(reg_write),
        .reg_addr(reg_addr),
        .reg_wdata(reg_wdata),
        .reg_rdata(reg_rdata),
        .reg_ready(reg_ready),
        .cfg_launch_req(cfg_launch_req),
        .cfg_seq_id(cfg_seq_id),
        .cfg_flow_velocity(cfg_flow_velocity),
        .cfg_geom_token(cfg_geom_token),
        .cfg_geom_format(cfg_geom_format),
        .cfg_queue_enable(cfg_queue_enable),
        .cfg_queue_depth(cfg_queue_depth),
        .cfg_timeout_thresh(cfg_timeout_thresh),
        .cfg_velocity_min(cfg_velocity_min),
        .cfg_velocity_max(cfg_velocity_max),
        .cfg_ref_velocity(cfg_ref_velocity),
        .cfg_safe_cmd(cfg_safe_cmd),
        .cfg_cmd_min(cfg_cmd_min),
        .cfg_cmd_max(cfg_cmd_max),
        .cfg_rate_limit_en(cfg_rate_limit_en),
        .cfg_rate_limit_step(cfg_rate_limit_step),
        .cfg_envelope_policy_en(cfg_envelope_policy_en),
        .request_active(request_active),
        .response_accepted(response_accepted),
        .stale_reject(stale_reject),
        .timeout_flag(timeout_flag),
        .clamp_applied(clamp_applied),
        .fallback_active(fallback_active),
        .generic_error(generic_error),
        .seq_id_out(seq_id_out),
        .watchdog_age(watchdog_age),
        .status_flags(status_flags),
        .status_irq(status_irq)
    );

    motor_control_core u_motor_control_core (
        .clk(clk),
        .reset_n(reset_n),
        .cfg_launch_req(cfg_launch_req),
        .cfg_seq_id(cfg_seq_id),
        .cfg_flow_velocity(cfg_flow_velocity),
        .cfg_geom_token(cfg_geom_token),
        .cfg_geom_format(cfg_geom_format),
        .cfg_queue_enable(cfg_queue_enable),
        .cfg_queue_depth(cfg_queue_depth),
        .cfg_timeout_thresh(cfg_timeout_thresh),
        .cfg_velocity_min(cfg_velocity_min),
        .cfg_velocity_max(cfg_velocity_max),
        .cfg_ref_velocity(cfg_ref_velocity),
        .cfg_safe_cmd(cfg_safe_cmd),
        .cfg_cmd_min(cfg_cmd_min),
        .cfg_cmd_max(cfg_cmd_max),
        .cfg_rate_limit_en(cfg_rate_limit_en),
        .cfg_rate_limit_step(cfg_rate_limit_step),
        .cfg_envelope_policy_en(cfg_envelope_policy_en),
        .req_ready(req_ready),
        .req_valid(req_valid),
        .req_desc(req_desc),
        .rsp_valid(rsp_valid_from_u_motor_control_core),
        .rsp_desc(rsp_desc_from_u_motor_control_core),
        .rsp_ready(rsp_ready),
        .model_cmd_candidate(model_cmd_candidate),
        .model_cmd_valid(model_cmd_valid),
        .approved_cmd(approved_cmd),
        .fallback_cmd(fallback_cmd),
        .request_active(request_active),
        .response_accepted(response_accepted),
        .stale_reject(stale_reject),
        .timeout_flag(timeout_flag),
        .clamp_applied(clamp_applied),
        .fallback_active(fallback_active),
        .generic_error(generic_error),
        .seq_id_out(seq_id_out),
        .watchdog_age(watchdog_age)
    );

    motor_control_descriptor_if u_motor_control_descriptor_if (
        .clk(clk),
        .reset_n(reset_n),
        .req_valid(req_valid),
        .req_ready(req_ready_from_u_motor_control_descriptor_if),
        .req_desc(req_desc),
        .rsp_valid(rsp_valid_from_u_motor_control_descriptor_if),
        .rsp_ready(rsp_ready),
        .rsp_desc(rsp_desc_from_u_motor_control_descriptor_if),
        .queue_enable(cfg_queue_enable),
        .queue_depth(cfg_queue_depth),
        .seq_id_out(seq_id_out),
        .request_active(request_active),
        .watchdog_age(watchdog_age),
        .generic_error(desc_generic_error)
    );

    motor_control_safety_arb u_motor_control_safety_arb (
        .clk(clk),
        .reset_n(reset_n),
        .approved_cmd(approved_cmd),
        .fallback_cmd(fallback_cmd),
        .model_cmd_valid(model_cmd_valid),
        .cfg_cmd_min(cfg_cmd_min),
        .cfg_cmd_max(cfg_cmd_max),
        .cfg_rate_limit_en(cfg_rate_limit_en),
        .cfg_rate_limit_step(cfg_rate_limit_step),
        .cfg_safe_cmd(cfg_safe_cmd),
        .clamp_applied(clamp_applied),
        .fallback_active(fallback_active),
        .actuator_cmd(actuator_cmd),
        .generic_error(generic_error)
    );

    motor_control_env_guard u_motor_control_env_guard (
        .clk(clk),
        .reset_n(reset_n),
        .cfg_envelope_policy_en(cfg_envelope_policy_en),
        .cfg_velocity_min(cfg_velocity_min),
        .cfg_velocity_max(cfg_velocity_max),
        .cfg_ref_velocity(cfg_ref_velocity),
        .cfg_flow_velocity(cfg_flow_velocity),
        .cfg_launch_req(cfg_launch_req),
        .launch_allow(launch_allow),
        .policy_error(policy_error),
        .env_match(env_match)
    );

endmodule
