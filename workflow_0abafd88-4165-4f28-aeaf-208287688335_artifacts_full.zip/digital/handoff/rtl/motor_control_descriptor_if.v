module motor_control_descriptor_if (
    clk,
    reset_n,
    req_valid,
    req_ready,
    req_desc,
    rsp_valid,
    rsp_ready,
    rsp_desc,
    queue_enable,
    queue_depth,
    seq_id_out,
    request_active,
    watchdog_age,
    generic_error
);
    input clk;
    input reset_n;
    input req_valid;
    output reg req_ready;
    input [127:0] req_desc;
    output reg rsp_valid;
    input rsp_ready;
    output reg [127:0] rsp_desc;
    input queue_enable;
    input [1:0] queue_depth;
    input [15:0] seq_id_out;
    input request_active;
    input [15:0] watchdog_age;
    output reg generic_error;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            req_ready <= 1'b1;
            rsp_valid <= 1'b0;
            rsp_desc <= 128'h00000000000000000000000000000000;
            generic_error <= 1'b0;
        end else begin
            req_ready <= 1'b1;
            rsp_valid <= 1'b0;
            rsp_desc <= {seq_id_out, watchdog_age, req_desc[95:0]};
            generic_error <= queue_enable & queue_depth[1] & request_active & req_valid & ~rsp_ready;
        end
    end
endmodule
