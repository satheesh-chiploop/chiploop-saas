module motor_control_regfile (
    clk,
    reset_n,
    reg_valid,
    reg_write,
    reg_addr,
    reg_wdata,
    reg_rdata,
    reg_ready,
    cfg_launch_req,
    cfg_seq_id,
    cfg_flow_velocity,
    cfg_geom_token,
    cfg_geom_format,
    cfg_queue_enable,
    cfg_queue_depth,
    cfg_timeout_thresh,
    cfg_velocity_min,
    cfg_velocity_max,
    cfg_ref_velocity,
    cfg_safe_cmd,
    cfg_cmd_min,
    cfg_cmd_max,
    cfg_rate_limit_en,
    cfg_rate_limit_step,
    cfg_envelope_policy_en,
    request_active,
    response_accepted,
    stale_reject,
    timeout_flag,
    clamp_applied,
    fallback_active,
    generic_error,
    seq_id_out,
    watchdog_age,
    status_flags,
    status_irq
);
    input clk;
    input reset_n;
    input reg_valid;
    input reg_write;
    input [3:0] reg_addr;
    input [63:0] reg_wdata;
    output [63:0] reg_rdata;
    output reg_ready;
    output reg cfg_launch_req;
    output reg [15:0] cfg_seq_id;
    output reg [15:0] cfg_flow_velocity;
    output reg [31:0] cfg_geom_token;
    output reg [3:0] cfg_geom_format;
    output reg cfg_queue_enable;
    output reg [1:0] cfg_queue_depth;
    output reg [15:0] cfg_timeout_thresh;
    output reg [15:0] cfg_velocity_min;
    output reg [15:0] cfg_velocity_max;
    output reg [15:0] cfg_ref_velocity;
    output reg [15:0] cfg_safe_cmd;
    output reg [15:0] cfg_cmd_min;
    output reg [15:0] cfg_cmd_max;
    output reg cfg_rate_limit_en;
    output reg [15:0] cfg_rate_limit_step;
    output reg cfg_envelope_policy_en;
    input request_active;
    input response_accepted;
    input stale_reject;
    input timeout_flag;
    input clamp_applied;
    input fallback_active;
    input generic_error;
    input [15:0] seq_id_out;
    input [15:0] watchdog_age;
    output reg [7:0] status_flags;
    output reg status_irq;

    reg [7:0] irq_mask;
    reg [7:0] irq_status;
    reg [7:0] sticky_status0;
    reg [15:0] sticky_seq_id;
    reg [15:0] sticky_watchdog;
    reg [63:0] reg_rdata_r;
    assign reg_rdata = reg_rdata_r;
    assign reg_ready = reg_valid;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            cfg_launch_req <= 1'b0;
            cfg_seq_id <= 16'h0000;
            cfg_flow_velocity <= 16'h0000;
            cfg_geom_token <= 32'h00000000;
            cfg_geom_format <= 4'h0;
            cfg_queue_enable <= 1'b0;
            cfg_queue_depth <= 2'b00;
            cfg_timeout_thresh <= 16'd32;
            cfg_velocity_min <= 16'd20;
            cfg_velocity_max <= 16'd55;
            cfg_ref_velocity <= 16'd38;
            cfg_safe_cmd <= 16'h0000;
            cfg_cmd_min <= 16'h0000;
            cfg_cmd_max <= 16'h00FF;
            cfg_rate_limit_en <= 1'b0;
            cfg_rate_limit_step <= 16'h0001;
            cfg_envelope_policy_en <= 1'b0;
            irq_mask <= 8'h0A;
            irq_status <= 8'h04;
            sticky_status0 <= 8'h20;
            sticky_seq_id <= 16'h0000;
            sticky_watchdog <= 16'h0000;
            reg_rdata_r <= 64'h0000000000000000;
            status_flags <= 8'h20;
            status_irq <= 1'b0;
        end else begin
            cfg_launch_req <= 1'b0;
            if (reg_valid && reg_write) begin
                case (reg_addr)
                    4'h0: begin
                        cfg_launch_req <= reg_wdata[0];
                        cfg_queue_enable <= reg_wdata[1];
                        cfg_rate_limit_en <= reg_wdata[2];
                        cfg_envelope_policy_en <= reg_wdata[3];
                    end
                    4'h1: begin
                        cfg_seq_id[7:0] <= reg_wdata[7:0];
                    end
                    4'h2: begin
                        cfg_seq_id[15:8] <= reg_wdata[7:0];
                    end
                    4'h3: begin
                        cfg_queue_depth <= reg_wdata[1:0];
                        cfg_geom_format <= reg_wdata[5:2];
                    end
                    4'h4: begin
                        cfg_velocity_min[7:0] <= reg_wdata[7:0];
                    end
                    4'h5: begin
                        cfg_velocity_min[15:8] <= reg_wdata[7:0];
                    end
                    4'h6: begin
                        cfg_velocity_max[7:0] <= reg_wdata[7:0];
                    end
                    4'h7: begin
                        cfg_velocity_max[15:8] <= reg_wdata[7:0];
                    end
                    4'h8: begin
                        cfg_ref_velocity[7:0] <= reg_wdata[7:0];
                    end
                    4'h9: begin
                        cfg_ref_velocity[15:8] <= reg_wdata[7:0];
                    end
                    4'hA: begin
                        cfg_flow_velocity[7:0] <= reg_wdata[7:0];
                    end
                    4'hB: begin
                        cfg_flow_velocity[15:8] <= reg_wdata[7:0];
                    end
                    4'hC: begin
                        cfg_timeout_thresh[7:0] <= reg_wdata[7:0];
                    end
                    4'hD: begin
                        cfg_timeout_thresh[15:8] <= reg_wdata[7:0];
                    end
                    4'hE: begin
                        cfg_safe_cmd[7:0] <= reg_wdata[7:0];
                    end
                    4'hF: begin
                        cfg_safe_cmd[15:8] <= reg_wdata[7:0];
                    end
                    default: begin
                    end
                endcase
            end
            if (reg_valid && reg_write) begin
                case (reg_addr)
                    4'h0: begin end
                    4'h1: begin end
                    4'h2: begin end
                    4'h3: begin end
                    4'h4: begin end
                    4'h5: begin end
                    4'h6: begin end
                    4'h7: begin end
                    4'h8: begin end
                    4'h9: begin end
                    4'hA: begin end
                    4'hB: begin end
                    4'hC: begin end
                    4'hD: begin end
                    4'hE: begin end
                    4'hF: begin end
                    default: begin end
                endcase
            end
            sticky_seq_id <= seq_id_out;
            sticky_watchdog <= watchdog_age;
            sticky_status0[0] <= request_active;
            sticky_status0[1] <= response_accepted;
            sticky_status0[2] <= stale_reject;
            sticky_status0[3] <= timeout_flag;
            sticky_status0[4] <= clamp_applied;
            sticky_status0[5] <= fallback_active;
            sticky_status0[6] <= generic_error;
            sticky_status0[7] <= 1'b0;
            irq_status[0] <= generic_error;
            irq_status[1] <= response_accepted;
            irq_status[2] <= fallback_active;
            irq_status[7:3] <= 5'b00000;
            status_flags <= sticky_status0;
            status_irq <= irq_mask[0] & (generic_error | response_accepted | fallback_active);
            case (reg_addr)
                4'h0: reg_rdata_r <= {56'h00000000000000, sticky_status0};
                4'h1: reg_rdata_r <= {56'h00000000000000, sticky_seq_id[7:0]};
                4'h2: reg_rdata_r <= {56'h00000000000000, sticky_seq_id[15:8]};
                4'h3: reg_rdata_r <= {48'h000000000000, {2'b00, cfg_geom_format, cfg_queue_depth}};
                4'h4: reg_rdata_r <= {56'h00000000000000, cfg_velocity_min[7:0]};
                4'h5: reg_rdata_r <= {56'h00000000000000, cfg_velocity_min[15:8]};
                4'h6: reg_rdata_r <= {56'h00000000000000, cfg_velocity_max[7:0]};
                4'h7: reg_rdata_r <= {56'h00000000000000, cfg_velocity_max[15:8]};
                4'h8: reg_rdata_r <= {56'h00000000000000, cfg_ref_velocity[7:0]};
                4'h9: reg_rdata_r <= {56'h00000000000000, cfg_ref_velocity[15:8]};
                4'hA: reg_rdata_r <= {56'h00000000000000, cfg_flow_velocity[7:0]};
                4'hB: reg_rdata_r <= {56'h00000000000000, cfg_flow_velocity[15:8]};
                4'hC: reg_rdata_r <= {56'h00000000000000, cfg_timeout_thresh[7:0]};
                4'hD: reg_rdata_r <= {56'h00000000000000, cfg_timeout_thresh[15:8]};
                4'hE: reg_rdata_r <= {56'h00000000000000, cfg_safe_cmd[7:0]};
                4'hF: reg_rdata_r <= {56'h00000000000000, cfg_safe_cmd[15:8]};
                default: reg_rdata_r <= 64'h0000000000000000;
            endcase
        end
    end
endmodule
