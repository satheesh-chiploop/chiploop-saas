module motor_control_env_guard (
    clk,
    reset_n,
    cfg_envelope_policy_en,
    cfg_velocity_min,
    cfg_velocity_max,
    cfg_ref_velocity,
    cfg_flow_velocity,
    cfg_launch_req,
    launch_allow,
    policy_error,
    env_match
);
    input clk;
    input reset_n;
    input cfg_envelope_policy_en;
    input [15:0] cfg_velocity_min;
    input [15:0] cfg_velocity_max;
    input [15:0] cfg_ref_velocity;
    input [15:0] cfg_flow_velocity;
    input cfg_launch_req;
    output reg launch_allow;
    output reg policy_error;
    output reg env_match;

    always @(*) begin
        env_match = (cfg_velocity_min == 16'd20) & (cfg_velocity_max == 16'd55) & (cfg_ref_velocity == 16'd38) & (cfg_flow_velocity >= cfg_velocity_min) & (cfg_flow_velocity <= cfg_velocity_max);
        policy_error = cfg_envelope_policy_en & (~env_match | ~cfg_launch_req);
        launch_allow = cfg_launch_req & (~cfg_envelope_policy_en | env_match);
    end

endmodule
