module motor_control_safety_arb (
    clk,
    reset_n,
    approved_cmd,
    fallback_cmd,
    model_cmd_valid,
    cfg_cmd_min,
    cfg_cmd_max,
    cfg_rate_limit_en,
    cfg_rate_limit_step,
    cfg_safe_cmd,
    clamp_applied,
    fallback_active,
    actuator_cmd,
    generic_error
);
    input clk;
    input reset_n;
    input [15:0] approved_cmd;
    input [15:0] fallback_cmd;
    input model_cmd_valid;
    input [15:0] cfg_cmd_min;
    input [15:0] cfg_cmd_max;
    input cfg_rate_limit_en;
    input [15:0] cfg_rate_limit_step;
    input [15:0] cfg_safe_cmd;
    input clamp_applied;
    input fallback_active;
    output reg [15:0] actuator_cmd;
    input generic_error;

    reg [15:0] limited_cmd;
    reg [15:0] clamped_cmd;

    always @(*) begin
        clamped_cmd = approved_cmd;
        if (clamped_cmd < cfg_cmd_min)
            clamped_cmd = cfg_cmd_min;
        else if (clamped_cmd > cfg_cmd_max)
            clamped_cmd = cfg_cmd_max;
        limited_cmd = clamped_cmd;
        if (cfg_rate_limit_en) begin
            if (limited_cmd > (cfg_safe_cmd + cfg_rate_limit_step))
                limited_cmd = cfg_safe_cmd + cfg_rate_limit_step;
            else if (limited_cmd < (cfg_safe_cmd - cfg_rate_limit_step))
                limited_cmd = cfg_safe_cmd - cfg_rate_limit_step;
        end
        if (fallback_active || generic_error || !model_cmd_valid) begin
            actuator_cmd = cfg_safe_cmd;
        end else begin
            actuator_cmd = limited_cmd;
        end
    end

endmodule
