module sram_mbist_demo_controller (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    bist_start,
    rd_data,
    ready,
    bist_done,
    bist_fail,
    irq,
    sram_clk,
    sram_csb,
    sram_web,
    sram_addr,
    sram_din,
    sram_dout
);
input clk;
input reset_n;
input wr_en;
input [7:0] wr_addr;
input [31:0] wr_data;
input rd_en;
input [7:0] rd_addr;
input bist_start;
output [31:0] rd_data;
output ready;
output bist_done;
output bist_fail;
output irq;
output sram_clk;
output sram_csb;
output sram_web;
output [5:0] sram_addr;
output [31:0] sram_din;
input [31:0] sram_dout;

reg [2:0] control_reg;
reg [5:0] mem_addr_reg;
reg [31:0] mem_wdata_reg;
reg [1:0] mem_control_reg;
reg [1:0] bist_control_reg;
reg [1:0] irq_status_reg;
reg [31:0] mem_rdata_reg;
reg bist_done_reg;
reg bist_fail_reg;
reg bist_running_reg;
reg [5:0] last_fail_addr_reg;
reg bist_req_pending_reg;
reg bist_req_seen_reg;

wire bist_req_int;
wire clear_result_pulse;
wire soft_reset_pulse;
wire mem_write_req;
wire mem_read_req;
wire irq_clear_done;
wire irq_clear_fail;
wire bist_done_event;
wire bist_fail_event;

wire sram_clk_intent;
wire sram_csb_intent;
wire sram_web_intent;
wire [5:0] sram_addr_intent;
wire [31:0] sram_din_intent;
wire [31:0] sram_dout_observation;
wire [31:0] sram_model_dout_observation;

assign sram_clk_intent = clk;
assign sram_csb_intent = ~(mem_write_req | mem_read_req);
assign sram_web_intent = ~mem_write_req;
assign sram_addr_intent = mem_addr_reg;
assign sram_din_intent = mem_wdata_reg;
assign sram_clk = sram_clk_intent;
assign sram_csb = sram_csb_intent;
assign sram_web = sram_web_intent;
assign sram_addr = sram_addr_intent;
assign sram_din = sram_din_intent;
assign sram_dout_observation = sram_dout;
assign sram_model_dout_observation = sram_dout_observation;

assign rd_data = mem_rdata_reg;
assign ready = reset_n & ~bist_running_reg;
assign bist_done = bist_done_reg;
assign bist_fail = bist_fail_reg;
assign irq = control_reg[2] & (irq_status_reg[0] | irq_status_reg[1]);
assign bist_req_int = bist_start | bist_control_reg[0];
assign clear_result_pulse = wr_en & (wr_addr == 8'h18) & wr_data[1];
assign soft_reset_pulse = wr_en & (wr_addr == 8'h00) & wr_data[1];
assign mem_write_req = wr_en & (wr_addr == 8'h14) & wr_data[0];
assign mem_read_req = wr_en & (wr_addr == 8'h14) & wr_data[1];
assign irq_clear_done = wr_en & (wr_addr == 8'h24) & wr_data[0];
assign irq_clear_fail = wr_en & (wr_addr == 8'h24) & wr_data[1];
assign bist_done_event = bist_req_seen_reg & ~bist_running_reg;
assign bist_fail_event = 1'b0;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        control_reg <= 3'b000;
        mem_addr_reg <= 6'b000000;
        mem_wdata_reg <= 32'b00000000000000000000000000000000;
        mem_control_reg <= 2'b00;
        bist_control_reg <= 2'b00;
        irq_status_reg <= 2'b00;
        mem_rdata_reg <= 32'b00000000000000000000000000000000;
        bist_done_reg <= 1'b0;
        bist_fail_reg <= 1'b0;
        bist_running_reg <= 1'b0;
        last_fail_addr_reg <= 6'b000000;
        bist_req_pending_reg <= 1'b0;
        bist_req_seen_reg <= 1'b0;
    end else begin
        mem_control_reg <= 2'b00;
        bist_control_reg <= 2'b00;

        if (soft_reset_pulse) begin
            control_reg <= 3'b000;
            mem_addr_reg <= 6'b000000;
            mem_wdata_reg <= 32'b00000000000000000000000000000000;
            irq_status_reg <= 2'b00;
            mem_rdata_reg <= 32'b00000000000000000000000000000000;
            bist_done_reg <= 1'b0;
            bist_fail_reg <= 1'b0;
            bist_running_reg <= 1'b0;
            last_fail_addr_reg <= 6'b000000;
            bist_req_pending_reg <= 1'b0;
            bist_req_seen_reg <= 1'b0;
        end else begin
            if (wr_en) begin
                case (wr_addr)
                    8'h00: begin
                        control_reg[0] <= wr_data[0];
                        control_reg[1] <= 1'b0;
                        control_reg[2] <= wr_data[2];
                    end
                    8'h08: begin
                        mem_addr_reg <= wr_data[5:0];
                    end
                    8'h0C: begin
                        mem_wdata_reg <= wr_data;
                    end
                    8'h14: begin
                        mem_control_reg <= wr_data[1:0];
                    end
                    8'h18: begin
                        bist_control_reg <= wr_data[1:0];
                    end
                    8'h24: begin
                        if (wr_data[0]) begin
                            irq_status_reg[0] <= 1'b0;
                        end
                        if (wr_data[1]) begin
                            irq_status_reg[1] <= 1'b0;
                        end
                    end
                    default: begin
                    end
                endcase
            end

            if (clear_result_pulse) begin
                bist_done_reg <= 1'b0;
                bist_fail_reg <= 1'b0;
                irq_status_reg <= 2'b00;
                last_fail_addr_reg <= 6'b000000;
            end

            if (irq_clear_done) begin
                irq_status_reg[0] <= 1'b0;
            end
            if (irq_clear_fail) begin
                irq_status_reg[1] <= 1'b0;
            end

            if (bist_req_int) begin
                bist_running_reg <= 1'b1;
                bist_req_pending_reg <= 1'b1;
                bist_req_seen_reg <= 1'b1;
            end else begin
                bist_req_pending_reg <= 1'b0;
                if (bist_running_reg) begin
                    bist_running_reg <= 1'b0;
                    bist_done_reg <= 1'b1;
                    irq_status_reg[0] <= 1'b1;
                end
            end

            if (bist_done_event) begin
                bist_running_reg <= 1'b0;
            end

            if (mem_write_req) begin
                mem_rdata_reg <= mem_rdata_reg;
            end else if (mem_read_req) begin
                mem_rdata_reg <= sram_dout;
            end

            if (mem_write_req) begin
                mem_control_reg <= 2'b01;
            end else if (mem_read_req) begin
                mem_control_reg <= 2'b10;
            end

            if (bist_running_reg) begin
                last_fail_addr_reg <= mem_addr_reg;
            end
        end
    end
end

assign sram_csb = ~(mem_write_req | mem_read_req);
assign sram_web = ~mem_write_req;

endmodule
