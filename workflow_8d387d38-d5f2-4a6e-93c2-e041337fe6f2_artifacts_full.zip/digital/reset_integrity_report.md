{
  "type": "reset_integrity_report",
  "version": "1.0",
  "rtl_file_count": 8,
  "detected_reset_signals": [
    "reset_n",
    "rst_n"
  ],
  "async_reset_blocks": [
    {
      "file": "backend/workflows/8d387d38-d5f2-4a6e-93c2-e041337fe6f2/fpga/src/handoff/rtl/aero_cfg_mmio.v",
      "reset": "rst_n",
      "edge": "negedge"
    },
    {
      "file": "backend/workflows/8d387d38-d5f2-4a6e-93c2-e041337fe6f2/fpga/src/handoff/rtl/aero_req_packer.v",
      "reset": "rst_n",
      "edge": "negedge"
    },
    {
      "file": "backend/workflows/8d387d38-d5f2-4a6e-93c2-e041337fe6f2/fpga/src/handoff/rtl/aero_rsp_unpacker.v",
      "reset": "rst_n",
      "edge": "negedge"
    },
    {
      "file": "backend/workflows/8d387d38-d5f2-4a6e-93c2-e041337fe6f2/fpga/src/handoff/rtl/aero_safety_supervisor.v",
      "reset": "rst_n",
      "edge": "negedge"
    },
    {
      "file": "backend/workflows/8d387d38-d5f2-4a6e-93c2-e041337fe6f2/fpga/src/handoff/rtl/aero_seq_timeout_monitor.v",
      "reset": "rst_n",
      "edge": "negedge"
    }
  ],
  "reset_usage_locations": [
    {
      "file": "backend/workflows/8d387d38-d5f2-4a6e-93c2-e041337fe6f2/fpga/src/handoff/rtl/adaptive_aero_control_top_spi_fpga_top.sv",
      "reset": "reset_n",
      "context": "if_condition"
    },
    {
      "file": "backend/workflows/8d387d38-d5f2-4a6e-93c2-e041337fe6f2/fpga/src/handoff/rtl/aero_cfg_mmio.v",
      "reset": "rst_n",
      "context": "if_condition"
    },
    {
      "file": "backend/workflows/8d387d38-d5f2-4a6e-93c2-e041337fe6f2/fpga/src/handoff/rtl/aero_req_packer.v",
      "reset": "rst_n",
      "context": "if_condition"
    },
    {
      "file": "backend/workflows/8d387d38-d5f2-4a6e-93c2-e041337fe6f2/fpga/src/handoff/rtl/aero_rsp_unpacker.v",
      "reset": "rst_n",
      "context": "if_condition"
    },
    {
      "file": "backend/workflows/8d387d38-d5f2-4a6e-93c2-e041337fe6f2/fpga/src/handoff/rtl/aero_safety_supervisor.v",
      "reset": "rst_n",
      "context": "if_condition"
    },
    {
      "file": "backend/workflows/8d387d38-d5f2-4a6e-93c2-e041337fe6f2/fpga/src/handoff/rtl/aero_seq_timeout_monitor.v",
      "reset": "rst_n",
      "context": "if_condition"
    }
  ],
  "findings": [],
  "recommendations": [
    "Prefer async-assert / sync-deassert reset strategy in multi-clock designs.",
    "Ensure reset deassertion is synchronized per clock domain.",
    "Avoid mixing async and sync reset styles without clear intent.",
    "Add reset-specific assertions: no X after reset release; stable reset sequencing."
  ],
  "note": "Heuristic scan only; use signoff reset/CDC checks in enterprise flows when available."
}