{
  "type": "cdc_analysis_report",
  "version": "1.0",
  "inputs": {
    "clock_reset_intent_present": false,
    "rtl_file_count": 8
  },
  "observations": {
    "inferred_clocks": [
      "clk"
    ],
    "inferred_domains": [],
    "per_file": [
      {
        "file": "backend/workflows/8d387d38-d5f2-4a6e-93c2-e041337fe6f2/fpga/src/handoff/rtl/adaptive_aero_control_top.v",
        "clock": null,
        "domain": null
      },
      {
        "file": "backend/workflows/8d387d38-d5f2-4a6e-93c2-e041337fe6f2/fpga/src/handoff/rtl/adaptive_aero_control_top_spi_fpga_top.sv",
        "clock": null,
        "domain": null
      },
      {
        "file": "backend/workflows/8d387d38-d5f2-4a6e-93c2-e041337fe6f2/fpga/src/handoff/rtl/aero_cfg_mmio.v",
        "clock": "clk",
        "domain": null
      },
      {
        "file": "backend/workflows/8d387d38-d5f2-4a6e-93c2-e041337fe6f2/fpga/src/handoff/rtl/aero_req_packer.v",
        "clock": "clk",
        "domain": null
      },
      {
        "file": "backend/workflows/8d387d38-d5f2-4a6e-93c2-e041337fe6f2/fpga/src/handoff/rtl/aero_req_rsp_fifo_bram.v",
        "clock": "clk",
        "domain": null
      },
      {
        "file": "backend/workflows/8d387d38-d5f2-4a6e-93c2-e041337fe6f2/fpga/src/handoff/rtl/aero_rsp_unpacker.v",
        "clock": "clk",
        "domain": null
      },
      {
        "file": "backend/workflows/8d387d38-d5f2-4a6e-93c2-e041337fe6f2/fpga/src/handoff/rtl/aero_safety_supervisor.v",
        "clock": "clk",
        "domain": null
      },
      {
        "file": "backend/workflows/8d387d38-d5f2-4a6e-93c2-e041337fe6f2/fpga/src/handoff/rtl/aero_seq_timeout_monitor.v",
        "clock": "clk",
        "domain": null
      }
    ]
  },
  "findings": [],
  "recommendations": [
    "Provide clock_reset_arch_intent.json for higher-fidelity CDC intent (domains, allowed crossings).",
    "For single-bit control crossings: use 2-flop synchronizers.",
    "For multi-bit data: use async FIFOs or validated handshake schemes.",
    "Run a real CDC tool in enterprise flow (Questa CDC / SpyGlass CDC / VC CDC) when available."
  ],
  "note": "This agent provides intent-level CDC screening. It is not a replacement for signoff CDC tools."
}