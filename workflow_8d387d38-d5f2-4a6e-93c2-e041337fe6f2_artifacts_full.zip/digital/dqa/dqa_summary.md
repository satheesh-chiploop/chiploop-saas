# Digital DQA Summary
- workflow_id: `8d387d38-d5f2-4a6e-93c2-e041337fe6f2`
- status: `pass`
- rtl files: `8`
- warning count: `0`

## Stage Status
- rtl_lint: `warn`
- cdc: `pass`
- reset_integrity: `pass`
- synthesis_readiness: `pass`
