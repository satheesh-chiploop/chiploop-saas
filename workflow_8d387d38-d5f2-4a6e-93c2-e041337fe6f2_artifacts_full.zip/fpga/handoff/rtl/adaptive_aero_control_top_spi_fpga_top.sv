// Auto-generated FPGA-only serialized transport shell.
// The verified core RTL remains unchanged; ASIC flows continue to use the core top.
module adaptive_aero_control_top_spi_fpga_top (
  input  logic clk,
  input  logic reset_n,
  input  logic spi_sclk,
  input  logic spi_cs_n,
  input  logic spi_mosi,
  output logic spi_miso,
  output logic fault_indicator
);
  localparam integer INPUT_BITS = 212;
  localparam integer OUTPUT_BITS = 220;
  localparam integer FRAME_BITS = 224;
  logic [FRAME_BITS-1:0] rx_shift;
  logic [INPUT_BITS-1:0] rx_active;
  logic [FRAME_BITS-1:0] tx_shift, tx_snapshot;
  logic spi_active;
  logic spi_cs_meta, spi_cs_sync, spi_cs_prev;
  logic [7:0] core_cfg_bus_addr;
  logic [63:0] core_cfg_bus_wdata;
  logic core_cfg_bus_valid;
  logic core_cfg_bus_write;
  logic core_req_ready;
  logic [127:0] core_rsp_data;
  logic core_rsp_valid;
  logic [7:0] core_seq_next;
  wire [63:0] core_cfg_bus_rdata;
  wire core_cfg_bus_ready;
  wire core_cfg_bus_rvalid;
  wire [127:0] core_req_data;
  wire core_req_valid;
  wire core_rsp_ready;
  wire [15:0] core_act_cmd;
  wire [7:0] core_fault_out;
  assign core_cfg_bus_addr = rx_active[0 +: 8];
  assign core_cfg_bus_wdata = rx_active[8 +: 64];
  assign core_cfg_bus_valid = rx_active[72 +: 1];
  assign core_cfg_bus_write = rx_active[73 +: 1];
  assign core_req_ready = rx_active[74 +: 1];
  assign core_rsp_data = rx_active[75 +: 128];
  assign core_rsp_valid = rx_active[203 +: 1];
  assign core_seq_next = rx_active[204 +: 8];
  wire [OUTPUT_BITS-1:0] core_response = {core_cfg_bus_rdata, core_cfg_bus_ready, core_cfg_bus_rvalid, core_req_data, core_req_valid, core_rsp_ready, core_act_cmd, core_fault_out};
  wire [FRAME_BITS-1:0] framed_response = {core_response, {(FRAME_BITS-OUTPUT_BITS){1'b0}}};
  assign fault_indicator = 1'b0;
  // Chip select asynchronously clears only the frame-state bit. Data
  // registers use SPI clock alone, which is legal in ECP5 fabric.
  always_ff @(posedge spi_sclk or posedge spi_cs_n) begin
    if (spi_cs_n) spi_active <= 1'b0;
    else spi_active <= 1'b1;
  end
  always_ff @(posedge spi_sclk) begin
    if (!spi_cs_n) begin
      rx_shift <= {rx_shift[222:0], spi_mosi};
      if (!spi_active) tx_shift <= {tx_snapshot[222:0], 1'b0};
      else tx_shift <= {tx_shift[222:0], 1'b0};
    end
  end
  // Synchronize frame completion into the core clock domain. The host
  // keeps MOSI stable around CS rising as required by the protocol.
  always_ff @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
      spi_cs_meta <= 1'b1; spi_cs_sync <= 1'b1; spi_cs_prev <= 1'b1;
      rx_active <= '0; tx_snapshot <= '0;
    end else begin
      spi_cs_meta <= spi_cs_n; spi_cs_sync <= spi_cs_meta; spi_cs_prev <= spi_cs_sync;
      if (spi_cs_sync && !spi_cs_prev) begin
        rx_active <= rx_shift[INPUT_BITS-1:0];
        // Bundled-data CDC: capture once, then hold this mailbox stable
        // until the next completed frame. The host observes response N in frame N+2.
        tx_snapshot <= framed_response;
      end
    end
  end
  // MISO is a dedicated top-level output. Drive a defined idle value
  // instead of inferring an internal tri-state cell, which is not a
  // portable fabric primitive and breaks mapped equivalence on targets
  // such as ECP5. Board-specific shared-data buses require an explicit
  // vendor I/O-buffer wrapper outside this transport shell.
  always_comb spi_miso = !spi_cs_n ? (spi_active ? tx_shift[FRAME_BITS-1] : tx_snapshot[FRAME_BITS-1]) : 1'b0;
  adaptive_aero_control_top u_core (
    .clk(clk),
    .clk_rst_n(reset_n),
    .cfg_bus_addr(core_cfg_bus_addr),
    .cfg_bus_wdata(core_cfg_bus_wdata),
    .cfg_bus_valid(core_cfg_bus_valid),
    .cfg_bus_write(core_cfg_bus_write),
    .cfg_bus_rdata(core_cfg_bus_rdata),
    .cfg_bus_ready(core_cfg_bus_ready),
    .cfg_bus_rvalid(core_cfg_bus_rvalid),
    .req_data(core_req_data),
    .req_valid(core_req_valid),
    .req_ready(core_req_ready),
    .rsp_data(core_rsp_data),
    .rsp_valid(core_rsp_valid),
    .rsp_ready(core_rsp_ready),
    .act_cmd(core_act_cmd),
    .fault_out(core_fault_out),
    .seq_next(core_seq_next)
  );
endmodule
