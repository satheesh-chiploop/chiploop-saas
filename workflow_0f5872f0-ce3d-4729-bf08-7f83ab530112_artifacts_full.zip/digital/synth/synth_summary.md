# Digital Synthesis Summary

- **Workflow**: 0f5872f0-ce3d-4729-bf08-7f83ab530112
- **Status**: `failed` (rc=2)
- **Top module**: `smart_sensor_hub_mcu`
- **Clock**: `clk` @ **10.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `not found`
- netlist candidates: 1 found
