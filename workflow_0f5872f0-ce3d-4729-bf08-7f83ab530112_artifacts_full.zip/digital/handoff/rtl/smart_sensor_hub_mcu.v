module smart_sensor_hub_mcu (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    sensor_temp_raw,
    sensor_humidity_raw,
    sensor_air_raw,
    sensor_valid,
    rd_data,
    sensor_sample_req,
    alert_irq,
    fifo_level,
    low_power_active,
    sample_count,
    alert_status
);
input clk;
input reset_n;
input wr_en;
input [11:0] wr_addr;
input [31:0] wr_data;
input rd_en;
input [11:0] rd_addr;
input [15:0] sensor_temp_raw;
input [15:0] sensor_humidity_raw;
input [15:0] sensor_air_raw;
input sensor_valid;
output [31:0] rd_data;
output sensor_sample_req;
output alert_irq;
output [5:0] fifo_level;
output low_power_active;
output [31:0] sample_count;
output [7:0] alert_status;
wire sensor_hub_register_file_control_enable_out;
wire sensor_hub_register_file_control_sample_start_out;
wire sensor_hub_register_file_control_low_power_en_out;
wire sensor_hub_register_file_control_irq_enable_out;
wire sensor_hub_register_file_control_fifo_clear_pulse_out;
wire [31:0] sensor_hub_register_file_sample_period_out;
wire [2:0] sensor_hub_register_file_sensor_select_out;
wire [15:0] sensor_hub_register_file_temp_threshold_out;
wire [15:0] sensor_hub_register_file_humidity_threshold_out;
wire [15:0] sensor_hub_register_file_air_threshold_out;
wire [7:0] sensor_hub_register_file_alert_clear_pulse_out;
wire [15:0] sensor_hub_register_file_latest_temp_in;
wire [15:0] sensor_hub_register_file_latest_humidity_in;
wire [15:0] sensor_hub_register_file_latest_air_in;
wire [31:0] sensor_hub_register_file_fifo_data_in;
wire [5:0] sensor_hub_register_file_fifo_level_in;
wire sensor_hub_register_file_low_power_active_in;
wire [31:0] sensor_hub_register_file_sample_count_in;
wire sensor_hub_register_file_busy_in;
wire sensor_hub_register_file_sample_done_in;
wire sensor_hub_register_file_fifo_empty_in;
wire sensor_hub_register_file_fifo_full_in;
wire sensor_hub_register_file_alert_pending_in;
wire [7:0] sensor_hub_register_file_alert_status_in;
wire [31:0] sensor_hub_sampler_fifo_data_out;
wire [5:0] sensor_hub_sampler_fifo_level_out;
wire [15:0] sensor_hub_sampler_latest_temp_out;
wire [15:0] sensor_hub_sampler_latest_humidity_out;
wire [15:0] sensor_hub_sampler_latest_air_out;
wire [31:0] sensor_hub_sampler_sample_count_out;
wire sensor_hub_sampler_busy_out;
wire sensor_hub_sampler_sample_done_out;
wire sensor_hub_sampler_fifo_empty_out;
wire sensor_hub_sampler_fifo_full_out;
wire sensor_hub_sampler_alert_pending_out;
wire [7:0] sensor_hub_sampler_alert_status_out;
wire sensor_hub_sampler_low_power_active_out;
wire sensor_hub_sampler_control_enable_in;
wire sensor_hub_sampler_control_sample_start_in;
wire sensor_hub_sampler_control_low_power_en_in;
wire [31:0] sensor_hub_sampler_sample_period_in;
wire [2:0] sensor_hub_sampler_sensor_select_in;
wire sensor_hub_sampler_fifo_clear_in;
wire [15:0] sensor_hub_sampler_temp_threshold_in;
wire [15:0] sensor_hub_sampler_humidity_threshold_in;
wire [15:0] sensor_hub_sampler_air_threshold_in;
wire [7:0] sensor_hub_sampler_alert_clear_in;

assign sensor_hub_register_file_latest_temp_in = sensor_hub_sampler_latest_temp_out;
assign sensor_hub_register_file_latest_humidity_in = sensor_hub_sampler_latest_humidity_out;
assign sensor_hub_register_file_latest_air_in = sensor_hub_sampler_latest_air_out;
assign sensor_hub_register_file_fifo_data_in = sensor_hub_sampler_fifo_data_out;
assign sensor_hub_register_file_fifo_level_in = sensor_hub_sampler_fifo_level_out;
assign sensor_hub_register_file_low_power_active_in = sensor_hub_sampler_low_power_active_out;
assign sensor_hub_register_file_sample_count_in = sensor_hub_sampler_sample_count_out;
assign sensor_hub_register_file_busy_in = sensor_hub_sampler_busy_out;
assign sensor_hub_register_file_sample_done_in = sensor_hub_sampler_sample_done_out;
assign sensor_hub_register_file_fifo_empty_in = sensor_hub_sampler_fifo_empty_out;
assign sensor_hub_register_file_fifo_full_in = sensor_hub_sampler_fifo_full_out;
assign sensor_hub_register_file_alert_pending_in = sensor_hub_sampler_alert_pending_out;
assign sensor_hub_register_file_alert_status_in = sensor_hub_sampler_alert_status_out;

assign sensor_hub_sampler_control_enable_in = sensor_hub_register_file_control_enable_out;
assign sensor_hub_sampler_control_sample_start_in = sensor_hub_register_file_control_sample_start_out;
assign sensor_hub_sampler_control_low_power_en_in = sensor_hub_register_file_control_low_power_en_out;
assign sensor_hub_sampler_sample_period_in = sensor_hub_register_file_sample_period_out;
assign sensor_hub_sampler_sensor_select_in = sensor_hub_register_file_sensor_select_out;
assign sensor_hub_sampler_fifo_clear_in = sensor_hub_register_file_control_fifo_clear_pulse_out;
assign sensor_hub_sampler_temp_threshold_in = sensor_hub_register_file_temp_threshold_out;
assign sensor_hub_sampler_humidity_threshold_in = sensor_hub_register_file_humidity_threshold_out;
assign sensor_hub_sampler_air_threshold_in = sensor_hub_register_file_air_threshold_out;
assign sensor_hub_sampler_alert_clear_in = sensor_hub_register_file_alert_clear_pulse_out;

sensor_hub_register_file u_sensor_hub_register_file (
    .clk(clk),
    .reset_n(reset_n),
    .wr_en(wr_en),
    .wr_addr(wr_addr),
    .wr_data(wr_data),
    .rd_en(rd_en),
    .rd_addr(rd_addr),
    .latest_temp_in(sensor_hub_register_file_latest_temp_in),
    .latest_humidity_in(sensor_hub_register_file_latest_humidity_in),
    .latest_air_in(sensor_hub_register_file_latest_air_in),
    .fifo_data_in(sensor_hub_register_file_fifo_data_in),
    .fifo_level_in(sensor_hub_register_file_fifo_level_in),
    .low_power_active_in(sensor_hub_register_file_low_power_active_in),
    .sample_count_in(sensor_hub_register_file_sample_count_in),
    .busy_in(sensor_hub_register_file_busy_in),
    .sample_done_in(sensor_hub_register_file_sample_done_in),
    .fifo_empty_in(sensor_hub_register_file_fifo_empty_in),
    .fifo_full_in(sensor_hub_register_file_fifo_full_in),
    .alert_pending_in(sensor_hub_register_file_alert_pending_in),
    .alert_status_in(sensor_hub_register_file_alert_status_in),
    .control_enable_out(sensor_hub_register_file_control_enable_out),
    .control_sample_start_out(sensor_hub_register_file_control_sample_start_out),
    .control_low_power_en_out(sensor_hub_register_file_control_low_power_en_out),
    .control_irq_enable_out(sensor_hub_register_file_control_irq_enable_out),
    .control_fifo_clear_pulse_out(sensor_hub_register_file_control_fifo_clear_pulse_out),
    .sample_period_out(sensor_hub_register_file_sample_period_out),
    .sensor_select_out(sensor_hub_register_file_sensor_select_out),
    .temp_threshold_out(sensor_hub_register_file_temp_threshold_out),
    .humidity_threshold_out(sensor_hub_register_file_humidity_threshold_out),
    .air_threshold_out(sensor_hub_register_file_air_threshold_out),
    .alert_clear_pulse_out(sensor_hub_register_file_alert_clear_pulse_out),
    .rd_data(rd_data)
);

sensor_hub_sampler u_sensor_hub_sampler (
    .clk(clk),
    .reset_n(reset_n),
    .control_enable_in(sensor_hub_sampler_control_enable_in),
    .control_sample_start_in(sensor_hub_sampler_control_sample_start_in),
    .control_low_power_en_in(sensor_hub_sampler_control_low_power_en_in),
    .sample_period_in(sensor_hub_sampler_sample_period_in),
    .sensor_select_in(sensor_hub_sampler_sensor_select_in),
    .sensor_temp_raw(sensor_temp_raw),
    .sensor_humidity_raw(sensor_humidity_raw),
    .sensor_air_raw(sensor_air_raw),
    .sensor_valid(sensor_valid),
    .fifo_clear_in(sensor_hub_sampler_fifo_clear_in),
    .temp_threshold_in(sensor_hub_sampler_temp_threshold_in),
    .humidity_threshold_in(sensor_hub_sampler_humidity_threshold_in),
    .air_threshold_in(sensor_hub_sampler_air_threshold_in),
    .alert_clear_in(sensor_hub_sampler_alert_clear_in),
    .sensor_sample_req(sensor_sample_req),
    .low_power_active(sensor_hub_sampler_low_power_active_out),
    .fifo_data_out(sensor_hub_sampler_fifo_data_out),
    .fifo_level_out(fifo_level),
    .latest_temp_out(sensor_hub_sampler_latest_temp_out),
    .latest_humidity_out(sensor_hub_sampler_latest_humidity_out),
    .latest_air_out(sensor_hub_sampler_latest_air_out),
    .sample_count_out(sample_count),
    .busy_out(sensor_hub_sampler_busy_out),
    .sample_done_out(sensor_hub_sampler_sample_done_out),
    .fifo_empty_out(sensor_hub_sampler_fifo_empty_out),
    .fifo_full_out(sensor_hub_sampler_fifo_full_out),
    .alert_pending_out(sensor_hub_sampler_alert_pending_out),
    .alert_status_out(alert_status)
);

assign alert_irq = sensor_hub_register_file_control_irq_enable_out & sensor_hub_sampler_alert_pending_out;

endmodule
