module sensor_hub_register_file (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    latest_temp_in,
    latest_humidity_in,
    latest_air_in,
    fifo_data_in,
    fifo_level_in,
    low_power_active_in,
    sample_count_in,
    busy_in,
    sample_done_in,
    fifo_empty_in,
    fifo_full_in,
    alert_pending_in,
    alert_status_in,
    control_enable_out,
    control_sample_start_out,
    control_low_power_en_out,
    control_irq_enable_out,
    control_fifo_clear_pulse_out,
    sample_period_out,
    sensor_select_out,
    temp_threshold_out,
    humidity_threshold_out,
    air_threshold_out,
    alert_clear_pulse_out,
    rd_data
);
input clk;
input reset_n;
input wr_en;
input [11:0] wr_addr;
input [31:0] wr_data;
input rd_en;
input [11:0] rd_addr;
input [15:0] latest_temp_in;
input [15:0] latest_humidity_in;
input [15:0] latest_air_in;
input [31:0] fifo_data_in;
input [5:0] fifo_level_in;
input low_power_active_in;
input [31:0] sample_count_in;
input busy_in;
input sample_done_in;
input fifo_empty_in;
input fifo_full_in;
input alert_pending_in;
input [7:0] alert_status_in;
output control_enable_out;
output control_sample_start_out;
output control_low_power_en_out;
output control_irq_enable_out;
output control_fifo_clear_pulse_out;
output [31:0] sample_period_out;
output [2:0] sensor_select_out;
output [15:0] temp_threshold_out;
output [15:0] humidity_threshold_out;
output [15:0] air_threshold_out;
output [7:0] alert_clear_pulse_out;
output [31:0] rd_data;
reg control_enable_out;
reg control_sample_start_out;
reg control_low_power_en_out;
reg control_irq_enable_out;
reg control_fifo_clear_pulse_out;
reg [31:0] sample_period_out;
reg [2:0] sensor_select_out;
reg [15:0] temp_threshold_out;
reg [15:0] humidity_threshold_out;
reg [15:0] air_threshold_out;
reg [7:0] alert_clear_pulse_out;
reg [31:0] rd_data;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        control_enable_out <= 1'b0;
        control_sample_start_out <= 1'b0;
        control_low_power_en_out <= 1'b0;
        control_irq_enable_out <= 1'b0;
        control_fifo_clear_pulse_out <= 1'b0;
        sample_period_out <= 32'h00000000;
        sensor_select_out <= 3'b000;
        temp_threshold_out <= 16'h0000;
        humidity_threshold_out <= 16'h0000;
        air_threshold_out <= 16'h0000;
        alert_clear_pulse_out <= 8'h00;
        rd_data <= 32'h00000000;
    end else begin
        control_sample_start_out <= 1'b0;
        control_fifo_clear_pulse_out <= 1'b0;
        alert_clear_pulse_out <= 8'h00;
        if (wr_en) begin
            case (wr_addr)
                12'h000: begin
                    control_enable_out <= wr_data[0];
                    control_sample_start_out <= wr_data[1];
                    control_low_power_en_out <= wr_data[2];
                    control_irq_enable_out <= wr_data[3];
                    control_fifo_clear_pulse_out <= wr_data[4];
                end
                12'h008: sample_period_out <= wr_data;
                12'h00C: sensor_select_out <= wr_data[2:0];
                12'h010: temp_threshold_out <= wr_data[15:0];
                12'h014: humidity_threshold_out <= wr_data[15:0];
                12'h018: air_threshold_out <= wr_data[15:0];
                12'h034: alert_clear_pulse_out <= wr_data[7:0];
                default: begin
                end
            endcase
        end
        if (rd_en) begin
            case (rd_addr)
                12'h000: rd_data <= {27'h0000000, control_fifo_clear_pulse_out, control_irq_enable_out, control_low_power_en_out, control_sample_start_out, control_enable_out};
                12'h004: rd_data <= {26'h0000000, low_power_active_in, alert_pending_in, fifo_full_in, fifo_empty_in, sample_done_in, busy_in};
                12'h008: rd_data <= sample_period_out;
                12'h00C: rd_data <= {29'h00000000, sensor_select_out};
                12'h010: rd_data <= {16'h0000, temp_threshold_out};
                12'h014: rd_data <= {16'h0000, humidity_threshold_out};
                12'h018: rd_data <= {16'h0000, air_threshold_out};
                12'h01C: rd_data <= {16'h0000, latest_temp_in};
                12'h020: rd_data <= {16'h0000, latest_humidity_in};
                12'h024: rd_data <= {16'h0000, latest_air_in};
                12'h028: rd_data <= fifo_data_in;
                12'h02C: rd_data <= {26'h0000000, fifo_level_in};
                12'h030: rd_data <= {24'h000000, alert_status_in};
                12'h038: rd_data <= sample_count_in;
                default: rd_data <= 32'h00000000;
            endcase
        end else begin
            rd_data <= 32'h00000000;
        end
    end
end

endmodule
