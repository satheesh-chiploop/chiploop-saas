module sensor_hub_sampler (
    clk,
    reset_n,
    control_enable_in,
    control_sample_start_in,
    control_low_power_en_in,
    sample_period_in,
    sensor_select_in,
    sensor_temp_raw,
    sensor_humidity_raw,
    sensor_air_raw,
    sensor_valid,
    fifo_clear_in,
    temp_threshold_in,
    humidity_threshold_in,
    air_threshold_in,
    alert_clear_in,
    sensor_sample_req,
    low_power_active,
    fifo_data_out,
    fifo_level_out,
    latest_temp_out,
    latest_humidity_out,
    latest_air_out,
    sample_count_out,
    busy_out,
    sample_done_out,
    fifo_empty_out,
    fifo_full_out,
    alert_pending_out,
    alert_status_out
);
input clk;
input reset_n;
input control_enable_in;
input control_sample_start_in;
input control_low_power_en_in;
input [31:0] sample_period_in;
input [2:0] sensor_select_in;
input [15:0] sensor_temp_raw;
input [15:0] sensor_humidity_raw;
input [15:0] sensor_air_raw;
input sensor_valid;
input fifo_clear_in;
input [15:0] temp_threshold_in;
input [15:0] humidity_threshold_in;
input [15:0] air_threshold_in;
input [7:0] alert_clear_in;
output sensor_sample_req;
output low_power_active;
output [31:0] fifo_data_out;
output [5:0] fifo_level_out;
output [15:0] latest_temp_out;
output [15:0] latest_humidity_out;
output [15:0] latest_air_out;
output [31:0] sample_count_out;
output busy_out;
output sample_done_out;
output fifo_empty_out;
output fifo_full_out;
output alert_pending_out;
output [7:0] alert_status_out;
reg sensor_sample_req;
reg low_power_active;
reg [31:0] fifo_data_out;
reg [5:0] fifo_level_out;
reg [15:0] latest_temp_out;
reg [15:0] latest_humidity_out;
reg [15:0] latest_air_out;
reg [31:0] sample_count_out;
reg busy_out;
reg sample_done_out;
reg fifo_empty_out;
reg fifo_full_out;
reg alert_pending_out;
reg [7:0] alert_status_out;

reg [31:0] sample_timer;
reg [31:0] fifo_mem0;
reg [31:0] fifo_mem1;
reg [31:0] fifo_mem2;
reg [31:0] fifo_mem3;
reg [31:0] fifo_mem4;
reg [31:0] fifo_mem5;
reg [31:0] fifo_mem6;
reg [31:0] fifo_mem7;
reg [31:0] fifo_mem8;
reg [31:0] fifo_mem9;
reg [31:0] fifo_mem10;
reg [31:0] fifo_mem11;
reg [31:0] fifo_mem12;
reg [31:0] fifo_mem13;
reg [31:0] fifo_mem14;
reg [31:0] fifo_mem15;
reg [3:0] fifo_wr_ptr;
reg [3:0] fifo_rd_ptr;
reg [31:0] fifo_head_mux;
reg [7:0] next_alert_status;
reg [31:0] next_fifo_data;
reg [5:0] next_fifo_level;
reg [3:0] next_fifo_wr_ptr;
reg [3:0] next_fifo_rd_ptr;
reg [31:0] fifo_mem0_n;
reg [31:0] fifo_mem1_n;
reg [31:0] fifo_mem2_n;
reg [31:0] fifo_mem3_n;
reg [31:0] fifo_mem4_n;
reg [31:0] fifo_mem5_n;
reg [31:0] fifo_mem6_n;
reg [31:0] fifo_mem7_n;
reg [31:0] fifo_mem8_n;
reg [31:0] fifo_mem9_n;
reg [31:0] fifo_mem10_n;
reg [31:0] fifo_mem11_n;
reg [31:0] fifo_mem12_n;
reg [31:0] fifo_mem13_n;
reg [31:0] fifo_mem14_n;
reg [31:0] fifo_mem15_n;

always @(*) begin
    fifo_head_mux = 32'h00000000;
    case (fifo_rd_ptr)
        4'h0: fifo_head_mux = fifo_mem0;
        4'h1: fifo_head_mux = fifo_mem1;
        4'h2: fifo_head_mux = fifo_mem2;
        4'h3: fifo_head_mux = fifo_mem3;
        4'h4: fifo_head_mux = fifo_mem4;
        4'h5: fifo_head_mux = fifo_mem5;
        4'h6: fifo_head_mux = fifo_mem6;
        4'h7: fifo_head_mux = fifo_mem7;
        4'h8: fifo_head_mux = fifo_mem8;
        4'h9: fifo_head_mux = fifo_mem9;
        4'hA: fifo_head_mux = fifo_mem10;
        4'hB: fifo_head_mux = fifo_mem11;
        4'hC: fifo_head_mux = fifo_mem12;
        4'hD: fifo_head_mux = fifo_mem13;
        4'hE: fifo_head_mux = fifo_mem14;
        4'hF: fifo_head_mux = fifo_mem15;
        default: fifo_head_mux = 32'h00000000;
    endcase
end

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        sensor_sample_req <= 1'b0;
        low_power_active <= 1'b0;
        fifo_data_out <= 32'h00000000;
        fifo_level_out <= 6'd0;
        latest_temp_out <= 16'h0000;
        latest_humidity_out <= 16'h0000;
        latest_air_out <= 16'h0000;
        sample_count_out <= 32'h00000000;
        busy_out <= 1'b0;
        sample_done_out <= 1'b0;
        fifo_empty_out <= 1'b1;
        fifo_full_out <= 1'b0;
        alert_pending_out <= 1'b0;
        alert_status_out <= 8'h00;
        sample_timer <= 32'h00000000;
        fifo_wr_ptr <= 4'h0;
        fifo_rd_ptr <= 4'h0;
        fifo_mem0 <= 32'h00000000;
        fifo_mem1 <= 32'h00000000;
        fifo_mem2 <= 32'h00000000;
        fifo_mem3 <= 32'h00000000;
        fifo_mem4 <= 32'h00000000;
        fifo_mem5 <= 32'h00000000;
        fifo_mem6 <= 32'h00000000;
        fifo_mem7 <= 32'h00000000;
        fifo_mem8 <= 32'h00000000;
        fifo_mem9 <= 32'h00000000;
        fifo_mem10 <= 32'h00000000;
        fifo_mem11 <= 32'h00000000;
        fifo_mem12 <= 32'h00000000;
        fifo_mem13 <= 32'h00000000;
        fifo_mem14 <= 32'h00000000;
        fifo_mem15 <= 32'h00000000;
    end else begin
        sensor_sample_req <= 1'b0;
        sample_done_out <= 1'b0;
        busy_out <= control_enable_in;
        low_power_active <= control_low_power_en_in && ((sensor_select_in == 3'b000) || (sample_period_in == 32'h00000000));
        if (fifo_clear_in) begin
            fifo_level_out <= 6'd0;
            fifo_wr_ptr <= 4'h0;
            fifo_rd_ptr <= 4'h0;
            fifo_empty_out <= 1'b1;
            fifo_full_out <= 1'b0;
        end
        if (alert_clear_in[0]) alert_status_out[0] <= 1'b0;
        if (alert_clear_in[1]) alert_status_out[1] <= 1'b0;
        if (alert_clear_in[2]) alert_status_out[2] <= 1'b0;
        if (alert_clear_in[3]) alert_status_out[3] <= 1'b0;
        if (alert_clear_in[4]) alert_status_out[4] <= 1'b0;
        if (control_enable_in && !low_power_active && (sample_period_in != 32'h00000000)) begin
            if (sample_timer == 32'h00000000) begin
                sensor_sample_req <= 1'b1;
                sample_timer <= sample_period_in;
            end else begin
                sample_timer <= sample_timer - 32'h00000001;
            end
        end else begin
            sample_timer <= sample_period_in;
        end
        if (control_sample_start_in) begin
            sensor_sample_req <= 1'b1;
        end
        if (sensor_valid) begin
            if (sensor_select_in[0]) latest_temp_out <= sensor_temp_raw;
            if (sensor_select_in[1]) latest_humidity_out <= sensor_humidity_raw;
            if (sensor_select_in[2]) latest_air_out <= sensor_air_raw;
            if (sensor_select_in[0] || sensor_select_in[1] || sensor_select_in[2]) begin
                sample_count_out <= sample_count_out + 32'h00000001;
                sample_done_out <= 1'b1;
                fifo_data_out <= {sensor_select_in, sensor_temp_raw[12:0], sensor_humidity_raw[12:0]};
                if (!fifo_full_out) begin
                    case (fifo_wr_ptr)
                        4'h0: fifo_mem0 <= {sensor_select_in, sensor_temp_raw[12:0], sensor_humidity_raw[12:0]};
                        4'h1: fifo_mem1 <= {sensor_select_in, sensor_temp_raw[12:0], sensor_humidity_raw[12:0]};
                        4'h2: fifo_mem2 <= {sensor_select_in, sensor_temp_raw[12:0], sensor_humidity_raw[12:0]};
                        4'h3: fifo_mem3 <= {sensor_select_in, sensor_temp_raw[12:0], sensor_humidity_raw[12:0]};
                        4'h4: fifo_mem4 <= {sensor_select_in, sensor_temp_raw[12:0], sensor_humidity_raw[12:0]};
                        4'h5: fifo_mem5 <= {sensor_select_in, sensor_temp_raw[12:0], sensor_humidity_raw[12:0]};
                        4'h6: fifo_mem6 <= {sensor_select_in, sensor_temp_raw[12:0], sensor_humidity_raw[12:0]};
                        4'h7: fifo_mem7 <= {sensor_select_in, sensor_temp_raw[12:0], sensor_humidity_raw[12:0]};
                        4'h8: fifo_mem8 <= {sensor_select_in, sensor_temp_raw[12:0], sensor_humidity_raw[12:0]};
                        4'h9: fifo_mem9 <= {sensor_select_in, sensor_temp_raw[12:0], sensor_humidity_raw[12:0]};
                        4'hA: fifo_mem10 <= {sensor_select_in, sensor_temp_raw[12:0], sensor_humidity_raw[12:0]};
                        4'hB: fifo_mem11 <= {sensor_select_in, sensor_temp_raw[12:0], sensor_humidity_raw[12:0]};
                        4'hC: fifo_mem12 <= {sensor_select_in, sensor_temp_raw[12:0], sensor_humidity_raw[12:0]};
                        4'hD: fifo_mem13 <= {sensor_select_in, sensor_temp_raw[12:0], sensor_humidity_raw[12:0]};
                        4'hE: fifo_mem14 <= {sensor_select_in, sensor_temp_raw[12:0], sensor_humidity_raw[12:0]};
                        4'hF: fifo_mem15 <= {sensor_select_in, sensor_temp_raw[12:0], sensor_humidity_raw[12:0]};
                        default: begin
                        end
                    endcase
                    fifo_wr_ptr <= fifo_wr_ptr + 4'h1;
                    fifo_level_out <= fifo_level_out + 6'd1;
                    fifo_empty_out <= 1'b0;
                    fifo_full_out <= (fifo_level_out == 6'd15);
                end else begin
                    alert_status_out[3] <= 1'b1;
                    fifo_full_out <= 1'b1;
                end
                if (sensor_select_in[0] && (sensor_temp_raw > temp_threshold_in)) alert_status_out[0] <= 1'b1;
                if (sensor_select_in[1] && (sensor_humidity_raw > humidity_threshold_in)) alert_status_out[1] <= 1'b1;
                if (sensor_select_in[2] && (sensor_air_raw > air_threshold_in)) alert_status_out[2] <= 1'b1;
            end
        end
        if (fifo_level_out != 6'd0) begin
            fifo_data_out <= fifo_head_mux;
        end
        if (alert_status_out != 8'h00) begin
            alert_pending_out <= 1'b1;
        end else begin
            alert_pending_out <= 1'b0;
        end
        if (fifo_level_out == 6'd0) begin
            fifo_empty_out <= 1'b1;
        end
        if (fifo_level_out >= 6'd16) begin
            fifo_full_out <= 1'b1;
        end
    end
end

endmodule
