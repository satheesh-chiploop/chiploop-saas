# IP Packaging & Handoff Report

- Top: `imported_from_arch2rtl`
- Package: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0f5872f0-ce3d-4729-bf08-7f83ab530112/f9b679ef-9a41-48d7-936a-d46eec277935/digital/arch2synthesis/handoff/imported_from_arch2rtl_ip_package`
- Zip: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0f5872f0-ce3d-4729-bf08-7f83ab530112/f9b679ef-9a41-48d7-936a-d46eec277935/digital/arch2synthesis/handoff/imported_from_arch2rtl_ip_package.zip`

## Bucket counts
- **rtl**: 3
- **spec**: 1
- **arch**: 0
- **microarch**: 0
- **regmap**: 1
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 0
