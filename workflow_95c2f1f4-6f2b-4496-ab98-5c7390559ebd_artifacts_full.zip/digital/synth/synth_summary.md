# Digital Synthesis Summary

- **Workflow**: 95c2f1f4-6f2b-4496-ab98-5c7390559ebd
- **Status**: `ok` (rc=0)
- **Top module**: `temp_monitor_soc_phys`
- **Clock**: `clk` @ **10.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/95c2f1f4-6f2b-4496-ab98-5c7390559ebd/c15220be-a615-4e29-b637-fc5ef79a89a8/digital/digital/synth/runs/System_Synthesis_95c2f1f4-6f2b-4496-ab98-5c7390559ebd/final/metrics.json`
- netlist candidates: 1 found
