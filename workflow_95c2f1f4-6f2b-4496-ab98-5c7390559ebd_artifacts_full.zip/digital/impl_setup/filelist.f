/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/95c2f1f4-6f2b-4496-ab98-5c7390559ebd/c15220be-a615-4e29-b637-fc5ef79a89a8/digital/system/imported_rtl/temp_sensor_adc_model.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/95c2f1f4-6f2b-4496-ab98-5c7390559ebd/c15220be-a615-4e29-b637-fc5ef79a89a8/digital/system/imported_rtl/irq_manager.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/95c2f1f4-6f2b-4496-ab98-5c7390559ebd/c15220be-a615-4e29-b637-fc5ef79a89a8/digital/system/imported_rtl/register_map.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/95c2f1f4-6f2b-4496-ab98-5c7390559ebd/c15220be-a615-4e29-b637-fc5ef79a89a8/digital/system/imported_rtl/temp_filter_compare.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/95c2f1f4-6f2b-4496-ab98-5c7390559ebd/c15220be-a615-4e29-b637-fc5ef79a89a8/digital/system/imported_rtl/temp_monitor_digital.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/95c2f1f4-6f2b-4496-ab98-5c7390559ebd/c15220be-a615-4e29-b637-fc5ef79a89a8/digital/system/imported_rtl/temp_monitor_soc_phys.sv
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/95c2f1f4-6f2b-4496-ab98-5c7390559ebd/c15220be-a615-4e29-b637-fc5ef79a89a8/digital/system/imported_rtl/temp_monitor_soc_sim.sv
