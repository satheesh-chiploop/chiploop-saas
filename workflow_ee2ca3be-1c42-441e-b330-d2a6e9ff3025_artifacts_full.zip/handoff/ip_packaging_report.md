# IP Packaging & Handoff Report

- Top: `pwm_controller`
- Package: `backend/workflows/ee2ca3be-1c42-441e-b330-d2a6e9ff3025/handoff/pwm_controller_ip_package`
- Zip: `backend/workflows/ee2ca3be-1c42-441e-b330-d2a6e9ff3025/handoff/pwm_controller_ip_package.zip`

## Bucket counts
- **rtl**: 1
- **spec**: 3
- **arch**: 1
- **microarch**: 1
- **regmap**: 2
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 7
