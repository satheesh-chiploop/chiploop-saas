# IP Packaging & Handoff Report

- Top: `PWM_Controller`
- Package: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/262c5f63-7735-4c4e-a392-f5cc65cf5141/handoff/PWM_Controller_ip_package`
- Zip: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/262c5f63-7735-4c4e-a392-f5cc65cf5141/handoff/PWM_Controller_ip_package.zip`

## Bucket counts
- **rtl**: 0
- **spec**: 1
- **arch**: 0
- **microarch**: 0
- **regmap**: 0
- **constraints**: 0
- **power_intent**: 0
- **verification**: 0
- **reports**: 0
- **other**: 3
