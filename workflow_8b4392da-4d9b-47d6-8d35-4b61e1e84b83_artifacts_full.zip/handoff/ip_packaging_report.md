# IP Packaging & Handoff Report

- Top: `imported_from_arch2rtl`
- Package: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/8b4392da-4d9b-47d6-8d35-4b61e1e84b83/4dd8af3e-7647-4c70-976d-ae5f173c44fb/digital/arch2tapeout/handoff/imported_from_arch2rtl_ip_package`
- Zip: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/8b4392da-4d9b-47d6-8d35-4b61e1e84b83/4dd8af3e-7647-4c70-976d-ae5f173c44fb/digital/arch2tapeout/handoff/imported_from_arch2rtl_ip_package.zip`

## Bucket counts
- **rtl**: 1
- **spec**: 1
- **arch**: 0
- **microarch**: 0
- **regmap**: 1
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 2
