module pwm_controller_mmio (clk,
    pwm_out,
    rd_en,
    reset_n,
    scan_en,
    wr_en,
    counter_value,
    rd_addr,
    rd_data,
    scan_in,
    scan_out,
    wr_addr,
    wr_data);
 input clk;
 output pwm_out;
 input rd_en;
 input reset_n;
 input scan_en;
 input wr_en;
 output [7:0] counter_value;
 input [7:0] rd_addr;
 output [7:0] rd_data;
 input [3:0] scan_in;
 output [3:0] scan_out;
 input [7:0] wr_addr;
 input [7:0] wr_data;

 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire _086_;
 wire _087_;
 wire _088_;
 wire _089_;
 wire _090_;
 wire _091_;
 wire _092_;
 wire _093_;
 wire _094_;
 wire _095_;
 wire _096_;
 wire control_reg;
 wire \duty_cycle_reg[0] ;
 wire \duty_cycle_reg[1] ;
 wire \duty_cycle_reg[2] ;
 wire \duty_cycle_reg[3] ;
 wire \duty_cycle_reg[4] ;
 wire \duty_cycle_reg[5] ;
 wire \duty_cycle_reg[6] ;
 wire \duty_cycle_reg[7] ;
 wire \period_reg[0] ;
 wire \period_reg[1] ;
 wire \period_reg[2] ;
 wire \period_reg[3] ;
 wire \period_reg[4] ;
 wire \period_reg[5] ;
 wire \period_reg[6] ;
 wire \period_reg[7] ;

 sky130_fd_sc_hd__mux2_1 _097_ (.A0(wr_data[5]),
    .A1(\period_reg[5] ),
    .S(_081_),
    .X(_022_));
 sky130_fd_sc_hd__mux2_1 _098_ (.A0(wr_data[6]),
    .A1(\period_reg[6] ),
    .S(_081_),
    .X(_023_));
 sky130_fd_sc_hd__mux2_1 _099_ (.A0(wr_data[7]),
    .A1(\period_reg[7] ),
    .S(_081_),
    .X(_024_));
 sky130_fd_sc_hd__inv_2 _100_ (.A(counter_value[7]),
    .Y(_082_));
 sky130_fd_sc_hd__inv_2 _101_ (.A(counter_value[6]),
    .Y(_083_));
 sky130_fd_sc_hd__inv_2 _102_ (.A(counter_value[4]),
    .Y(_084_));
 sky130_fd_sc_hd__inv_2 _103_ (.A(counter_value[3]),
    .Y(_085_));
 sky130_fd_sc_hd__inv_2 _104_ (.A(counter_value[2]),
    .Y(_086_));
 sky130_fd_sc_hd__inv_2 _105_ (.A(counter_value[1]),
    .Y(_087_));
 sky130_fd_sc_hd__inv_2 _106_ (.A(counter_value[0]),
    .Y(_088_));
 sky130_fd_sc_hd__o211a_2 _107_ (.A1(\duty_cycle_reg[1] ),
    .A2(_087_),
    .B1(\duty_cycle_reg[0] ),
    .C1(_088_),
    .X(_089_));
 sky130_fd_sc_hd__a22o_2 _108_ (.A1(\duty_cycle_reg[2] ),
    .A2(_086_),
    .B1(\duty_cycle_reg[1] ),
    .B2(_087_),
    .X(_090_));
 sky130_fd_sc_hd__or2_2 _109_ (.A(\duty_cycle_reg[2] ),
    .B(_086_),
    .X(_091_));
 sky130_fd_sc_hd__o221a_2 _110_ (.A1(\duty_cycle_reg[3] ),
    .A2(_085_),
    .B1(_089_),
    .B2(_090_),
    .C1(_091_),
    .X(_092_));
 sky130_fd_sc_hd__and2b_2 _111_ (.A_N(counter_value[5]),
    .B(\duty_cycle_reg[5] ),
    .X(_093_));
 sky130_fd_sc_hd__o22a_2 _112_ (.A1(_082_),
    .A2(\duty_cycle_reg[7] ),
    .B1(\duty_cycle_reg[6] ),
    .B2(_083_),
    .X(_094_));
 sky130_fd_sc_hd__and2_2 _113_ (.A(_082_),
    .B(\duty_cycle_reg[7] ),
    .X(_095_));
 sky130_fd_sc_hd__and2b_2 _114_ (.A_N(counter_value[6]),
    .B(\duty_cycle_reg[6] ),
    .X(_096_));
 sky130_fd_sc_hd__nand2b_2 _115_ (.A_N(\duty_cycle_reg[4] ),
    .B(counter_value[4]),
    .Y(_025_));
 sky130_fd_sc_hd__nand2b_2 _116_ (.A_N(\duty_cycle_reg[5] ),
    .B(counter_value[5]),
    .Y(_026_));
 sky130_fd_sc_hd__nand2_2 _117_ (.A(_025_),
    .B(_026_),
    .Y(_027_));
 sky130_fd_sc_hd__a221o_2 _118_ (.A1(_084_),
    .A2(\duty_cycle_reg[4] ),
    .B1(\duty_cycle_reg[3] ),
    .B2(_085_),
    .C1(_096_),
    .X(_028_));
 sky130_fd_sc_hd__or4b_2 _119_ (.A(_093_),
    .B(_095_),
    .C(_028_),
    .D_N(_094_),
    .X(_029_));
 sky130_fd_sc_hd__a211o_2 _120_ (.A1(_025_),
    .A2(_026_),
    .B1(_093_),
    .C1(_096_),
    .X(_030_));
 sky130_fd_sc_hd__a21o_2 _121_ (.A1(_094_),
    .A2(_030_),
    .B1(_095_),
    .X(_031_));
 sky130_fd_sc_hd__o311a_2 _122_ (.A1(_092_),
    .A2(_027_),
    .A3(_029_),
    .B1(_031_),
    .C1(control_reg),
    .X(pwm_out));
 sky130_fd_sc_hd__nor4_2 _123_ (.A(rd_addr[5]),
    .B(rd_addr[4]),
    .C(rd_addr[7]),
    .D(rd_addr[6]),
    .Y(_032_));
 sky130_fd_sc_hd__nor2_2 _124_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .Y(_033_));
 sky130_fd_sc_hd__and4_2 _125_ (.A(rd_addr[3]),
    .B(rd_addr[2]),
    .C(_032_),
    .D(_033_),
    .X(_034_));
 sky130_fd_sc_hd__mux2_1 _126_ (.A0(control_reg),
    .A1(\duty_cycle_reg[0] ),
    .S(rd_addr[2]),
    .X(_035_));
 sky130_fd_sc_hd__and4b_2 _127_ (.A_N(rd_addr[3]),
    .B(_032_),
    .C(_033_),
    .D(_035_),
    .X(_036_));
 sky130_fd_sc_hd__and4b_2 _128_ (.A_N(rd_addr[2]),
    .B(_032_),
    .C(_033_),
    .D(rd_addr[3]),
    .X(_037_));
 sky130_fd_sc_hd__a221o_2 _129_ (.A1(counter_value[0]),
    .A2(_034_),
    .B1(_037_),
    .B2(\period_reg[0] ),
    .C1(_036_),
    .X(rd_data[0]));
 sky130_fd_sc_hd__and4b_2 _130_ (.A_N(rd_addr[3]),
    .B(rd_addr[2]),
    .C(_032_),
    .D(_033_),
    .X(_038_));
 sky130_fd_sc_hd__a22o_2 _131_ (.A1(\period_reg[1] ),
    .A2(_037_),
    .B1(_038_),
    .B2(\duty_cycle_reg[1] ),
    .X(_039_));
 sky130_fd_sc_hd__a21o_2 _132_ (.A1(counter_value[1]),
    .A2(_034_),
    .B1(_039_),
    .X(rd_data[1]));
 sky130_fd_sc_hd__a22o_2 _133_ (.A1(counter_value[2]),
    .A2(_034_),
    .B1(_038_),
    .B2(\duty_cycle_reg[2] ),
    .X(_040_));
 sky130_fd_sc_hd__a21o_2 _134_ (.A1(\period_reg[2] ),
    .A2(_037_),
    .B1(_040_),
    .X(rd_data[2]));
 sky130_fd_sc_hd__a22o_2 _135_ (.A1(counter_value[3]),
    .A2(_034_),
    .B1(_038_),
    .B2(\duty_cycle_reg[3] ),
    .X(_041_));
 sky130_fd_sc_hd__a21o_2 _136_ (.A1(\period_reg[3] ),
    .A2(_037_),
    .B1(_041_),
    .X(rd_data[3]));
 sky130_fd_sc_hd__a22o_2 _137_ (.A1(\period_reg[4] ),
    .A2(_037_),
    .B1(_038_),
    .B2(\duty_cycle_reg[4] ),
    .X(_042_));
 sky130_fd_sc_hd__a21o_2 _138_ (.A1(counter_value[4]),
    .A2(_034_),
    .B1(_042_),
    .X(rd_data[4]));
 sky130_fd_sc_hd__a22o_2 _139_ (.A1(counter_value[5]),
    .A2(_034_),
    .B1(_038_),
    .B2(\duty_cycle_reg[5] ),
    .X(_043_));
 sky130_fd_sc_hd__a21o_2 _140_ (.A1(\period_reg[5] ),
    .A2(_037_),
    .B1(_043_),
    .X(rd_data[5]));
 sky130_fd_sc_hd__a22o_2 _141_ (.A1(counter_value[6]),
    .A2(_034_),
    .B1(_037_),
    .B2(\period_reg[6] ),
    .X(_044_));
 sky130_fd_sc_hd__a21o_2 _142_ (.A1(\duty_cycle_reg[6] ),
    .A2(_038_),
    .B1(_044_),
    .X(rd_data[6]));
 sky130_fd_sc_hd__a22o_2 _143_ (.A1(counter_value[7]),
    .A2(_034_),
    .B1(_038_),
    .B2(\duty_cycle_reg[7] ),
    .X(_045_));
 sky130_fd_sc_hd__a21o_2 _144_ (.A1(\period_reg[7] ),
    .A2(_037_),
    .B1(_045_),
    .X(rd_data[7]));
 sky130_fd_sc_hd__or3b_2 _145_ (.A(wr_addr[7]),
    .B(wr_addr[6]),
    .C_N(wr_en),
    .X(_046_));
 sky130_fd_sc_hd__nor3_2 _146_ (.A(wr_addr[5]),
    .B(wr_addr[4]),
    .C(_046_),
    .Y(_047_));
 sky130_fd_sc_hd__nor2_2 _147_ (.A(wr_addr[1]),
    .B(wr_addr[0]),
    .Y(_048_));
 sky130_fd_sc_hd__and4bb_2 _148_ (.A_N(wr_addr[2]),
    .B_N(wr_addr[3]),
    .C(_047_),
    .D(_048_),
    .X(_049_));
 sky130_fd_sc_hd__mux2_1 _149_ (.A0(control_reg),
    .A1(wr_data[0]),
    .S(_049_),
    .X(_000_));
 sky130_fd_sc_hd__and4b_2 _150_ (.A_N(wr_addr[3]),
    .B(_047_),
    .C(_048_),
    .D(wr_addr[2]),
    .X(_050_));
 sky130_fd_sc_hd__mux2_1 _151_ (.A0(\duty_cycle_reg[0] ),
    .A1(wr_data[0]),
    .S(_050_),
    .X(_001_));
 sky130_fd_sc_hd__mux2_1 _152_ (.A0(\duty_cycle_reg[1] ),
    .A1(wr_data[1]),
    .S(_050_),
    .X(_002_));
 sky130_fd_sc_hd__mux2_1 _153_ (.A0(\duty_cycle_reg[2] ),
    .A1(wr_data[2]),
    .S(_050_),
    .X(_003_));
 sky130_fd_sc_hd__mux2_1 _154_ (.A0(\duty_cycle_reg[3] ),
    .A1(wr_data[3]),
    .S(_050_),
    .X(_004_));
 sky130_fd_sc_hd__mux2_1 _155_ (.A0(\duty_cycle_reg[4] ),
    .A1(wr_data[4]),
    .S(_050_),
    .X(_005_));
 sky130_fd_sc_hd__mux2_1 _156_ (.A0(\duty_cycle_reg[5] ),
    .A1(wr_data[5]),
    .S(_050_),
    .X(_006_));
 sky130_fd_sc_hd__mux2_1 _157_ (.A0(\duty_cycle_reg[6] ),
    .A1(wr_data[6]),
    .S(_050_),
    .X(_007_));
 sky130_fd_sc_hd__mux2_1 _158_ (.A0(\duty_cycle_reg[7] ),
    .A1(wr_data[7]),
    .S(_050_),
    .X(_008_));
 sky130_fd_sc_hd__or4_2 _159_ (.A(\period_reg[5] ),
    .B(\period_reg[4] ),
    .C(\period_reg[7] ),
    .D(\period_reg[6] ),
    .X(_051_));
 sky130_fd_sc_hd__or4_2 _160_ (.A(\period_reg[1] ),
    .B(\period_reg[0] ),
    .C(\period_reg[3] ),
    .D(\period_reg[2] ),
    .X(_052_));
 sky130_fd_sc_hd__o21a_2 _161_ (.A1(_051_),
    .A2(_052_),
    .B1(control_reg),
    .X(_053_));
 sky130_fd_sc_hd__o21ai_2 _162_ (.A1(_051_),
    .A2(_052_),
    .B1(control_reg),
    .Y(_054_));
 sky130_fd_sc_hd__xor2_2 _163_ (.A(\period_reg[3] ),
    .B(counter_value[3]),
    .X(_055_));
 sky130_fd_sc_hd__xor2_2 _164_ (.A(\period_reg[0] ),
    .B(counter_value[0]),
    .X(_056_));
 sky130_fd_sc_hd__xor2_2 _165_ (.A(\period_reg[7] ),
    .B(counter_value[7]),
    .X(_057_));
 sky130_fd_sc_hd__xor2_2 _166_ (.A(\period_reg[2] ),
    .B(counter_value[2]),
    .X(_058_));
 sky130_fd_sc_hd__xor2_2 _167_ (.A(\period_reg[6] ),
    .B(counter_value[6]),
    .X(_059_));
 sky130_fd_sc_hd__xor2_2 _168_ (.A(\period_reg[1] ),
    .B(counter_value[1]),
    .X(_060_));
 sky130_fd_sc_hd__xor2_2 _169_ (.A(\period_reg[5] ),
    .B(counter_value[5]),
    .X(_061_));
 sky130_fd_sc_hd__xor2_2 _170_ (.A(\period_reg[4] ),
    .B(counter_value[4]),
    .X(_062_));
 sky130_fd_sc_hd__or4_2 _171_ (.A(_055_),
    .B(_056_),
    .C(_057_),
    .D(_061_),
    .X(_063_));
 sky130_fd_sc_hd__or4_2 _172_ (.A(_058_),
    .B(_059_),
    .C(_060_),
    .D(_062_),
    .X(_064_));
 sky130_fd_sc_hd__or3_2 _173_ (.A(_054_),
    .B(_063_),
    .C(_064_),
    .X(_065_));
 sky130_fd_sc_hd__nand2_2 _174_ (.A(counter_value[0]),
    .B(_053_),
    .Y(_066_));
 sky130_fd_sc_hd__nand2_2 _175_ (.A(_088_),
    .B(_054_),
    .Y(_067_));
 sky130_fd_sc_hd__and3_2 _176_ (.A(_065_),
    .B(_066_),
    .C(_067_),
    .X(_009_));
 sky130_fd_sc_hd__a21o_2 _177_ (.A1(counter_value[0]),
    .A2(_053_),
    .B1(counter_value[1]),
    .X(_068_));
 sky130_fd_sc_hd__o311a_2 _178_ (.A1(_087_),
    .A2(_088_),
    .A3(_054_),
    .B1(_065_),
    .C1(_068_),
    .X(_010_));
 sky130_fd_sc_hd__a31o_2 _179_ (.A1(counter_value[1]),
    .A2(counter_value[0]),
    .A3(_053_),
    .B1(counter_value[2]),
    .X(_069_));
 sky130_fd_sc_hd__or4_2 _180_ (.A(_086_),
    .B(_087_),
    .C(_088_),
    .D(_054_),
    .X(_070_));
 sky130_fd_sc_hd__and3_2 _181_ (.A(_065_),
    .B(_069_),
    .C(_070_),
    .X(_011_));
 sky130_fd_sc_hd__a41o_2 _182_ (.A1(counter_value[2]),
    .A2(counter_value[1]),
    .A3(counter_value[0]),
    .A4(_053_),
    .B1(counter_value[3]),
    .X(_071_));
 sky130_fd_sc_hd__and4_2 _183_ (.A(counter_value[3]),
    .B(counter_value[2]),
    .C(counter_value[1]),
    .D(counter_value[0]),
    .X(_072_));
 sky130_fd_sc_hd__o211a_2 _184_ (.A1(_085_),
    .A2(_070_),
    .B1(_071_),
    .C1(_065_),
    .X(_012_));
 sky130_fd_sc_hd__a21o_2 _185_ (.A1(_053_),
    .A2(_072_),
    .B1(counter_value[4]),
    .X(_073_));
 sky130_fd_sc_hd__nand2_2 _186_ (.A(counter_value[4]),
    .B(_072_),
    .Y(_074_));
 sky130_fd_sc_hd__o211a_2 _187_ (.A1(_054_),
    .A2(_074_),
    .B1(_073_),
    .C1(_065_),
    .X(_013_));
 sky130_fd_sc_hd__a31o_2 _188_ (.A1(counter_value[4]),
    .A2(_053_),
    .A3(_072_),
    .B1(counter_value[5]),
    .X(_075_));
 sky130_fd_sc_hd__and3_2 _189_ (.A(counter_value[5]),
    .B(counter_value[4]),
    .C(_072_),
    .X(_076_));
 sky130_fd_sc_hd__nand2_2 _190_ (.A(_053_),
    .B(_076_),
    .Y(_077_));
 sky130_fd_sc_hd__and3_2 _191_ (.A(_065_),
    .B(_075_),
    .C(_077_),
    .X(_014_));
 sky130_fd_sc_hd__a21o_2 _192_ (.A1(_053_),
    .A2(_076_),
    .B1(counter_value[6]),
    .X(_078_));
 sky130_fd_sc_hd__or3b_2 _193_ (.A(_083_),
    .B(_054_),
    .C_N(_076_),
    .X(_079_));
 sky130_fd_sc_hd__and3_2 _194_ (.A(_065_),
    .B(_078_),
    .C(_079_),
    .X(_015_));
 sky130_fd_sc_hd__a31o_2 _195_ (.A1(counter_value[6]),
    .A2(_053_),
    .A3(_076_),
    .B1(counter_value[7]),
    .X(_080_));
 sky130_fd_sc_hd__o211a_2 _196_ (.A1(_082_),
    .A2(_079_),
    .B1(_080_),
    .C1(_065_),
    .X(_016_));
 sky130_fd_sc_hd__nand4b_2 _197_ (.A_N(wr_addr[2]),
    .B(wr_addr[3]),
    .C(_047_),
    .D(_048_),
    .Y(_081_));
 sky130_fd_sc_hd__mux2_1 _198_ (.A0(wr_data[0]),
    .A1(\period_reg[0] ),
    .S(_081_),
    .X(_017_));
 sky130_fd_sc_hd__mux2_1 _199_ (.A0(wr_data[1]),
    .A1(\period_reg[1] ),
    .S(_081_),
    .X(_018_));
 sky130_fd_sc_hd__mux2_1 _200_ (.A0(wr_data[2]),
    .A1(\period_reg[2] ),
    .S(_081_),
    .X(_019_));
 sky130_fd_sc_hd__mux2_1 _201_ (.A0(wr_data[3]),
    .A1(\period_reg[3] ),
    .S(_081_),
    .X(_020_));
 sky130_fd_sc_hd__mux2_1 _202_ (.A0(wr_data[4]),
    .A1(\period_reg[4] ),
    .S(_081_),
    .X(_021_));
 sky130_fd_sc_hd__sdfrtp_2 _203_ (.CLK(clk),
    .D(_000_),
    .RESET_B(reset_n),
    .SCD(scan_in[0]),
    .SCE(scan_en),
    .Q(control_reg));
 sky130_fd_sc_hd__sdfrtp_2 _204_ (.CLK(clk),
    .D(_001_),
    .RESET_B(reset_n),
    .SCD(scan_in[1]),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _205_ (.CLK(clk),
    .D(_002_),
    .RESET_B(reset_n),
    .SCD(scan_in[2]),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _206_ (.CLK(clk),
    .D(_003_),
    .RESET_B(reset_n),
    .SCD(scan_in[3]),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _207_ (.CLK(clk),
    .D(_004_),
    .RESET_B(reset_n),
    .SCD(control_reg),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _208_ (.CLK(clk),
    .D(_005_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[0] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _209_ (.CLK(clk),
    .D(_006_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[1] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _210_ (.CLK(clk),
    .D(_007_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[2] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _211_ (.CLK(clk),
    .D(_008_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[3] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _212_ (.CLK(clk),
    .D(_009_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[4] ),
    .SCE(scan_en),
    .Q(counter_value[0]));
 sky130_fd_sc_hd__sdfrtp_2 _213_ (.CLK(clk),
    .D(_010_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[5] ),
    .SCE(scan_en),
    .Q(counter_value[1]));
 sky130_fd_sc_hd__sdfrtp_2 _214_ (.CLK(clk),
    .D(_011_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[6] ),
    .SCE(scan_en),
    .Q(counter_value[2]));
 sky130_fd_sc_hd__sdfrtp_2 _215_ (.CLK(clk),
    .D(_012_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[7] ),
    .SCE(scan_en),
    .Q(counter_value[3]));
 sky130_fd_sc_hd__sdfrtp_2 _216_ (.CLK(clk),
    .D(_013_),
    .RESET_B(reset_n),
    .SCD(counter_value[0]),
    .SCE(scan_en),
    .Q(counter_value[4]));
 sky130_fd_sc_hd__sdfrtp_2 _217_ (.CLK(clk),
    .D(_014_),
    .RESET_B(reset_n),
    .SCD(counter_value[1]),
    .SCE(scan_en),
    .Q(counter_value[5]));
 sky130_fd_sc_hd__sdfrtp_2 _218_ (.CLK(clk),
    .D(_015_),
    .RESET_B(reset_n),
    .SCD(counter_value[2]),
    .SCE(scan_en),
    .Q(counter_value[6]));
 sky130_fd_sc_hd__sdfrtp_2 _219_ (.CLK(clk),
    .D(_016_),
    .RESET_B(reset_n),
    .SCD(counter_value[3]),
    .SCE(scan_en),
    .Q(counter_value[7]));
 sky130_fd_sc_hd__sdfrtp_2 _220_ (.CLK(clk),
    .D(_017_),
    .RESET_B(reset_n),
    .SCD(counter_value[4]),
    .SCE(scan_en),
    .Q(\period_reg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _221_ (.CLK(clk),
    .D(_018_),
    .RESET_B(reset_n),
    .SCD(counter_value[5]),
    .SCE(scan_en),
    .Q(\period_reg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _222_ (.CLK(clk),
    .D(_019_),
    .RESET_B(reset_n),
    .SCD(counter_value[6]),
    .SCE(scan_en),
    .Q(\period_reg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _223_ (.CLK(clk),
    .D(_020_),
    .RESET_B(reset_n),
    .SCD(counter_value[7]),
    .SCE(scan_en),
    .Q(\period_reg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _224_ (.CLK(clk),
    .D(_021_),
    .RESET_B(reset_n),
    .SCD(\period_reg[0] ),
    .SCE(scan_en),
    .Q(\period_reg[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _225_ (.CLK(clk),
    .D(_022_),
    .RESET_B(reset_n),
    .SCD(\period_reg[1] ),
    .SCE(scan_en),
    .Q(\period_reg[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _226_ (.CLK(clk),
    .D(_023_),
    .RESET_B(reset_n),
    .SCD(\period_reg[2] ),
    .SCE(scan_en),
    .Q(\period_reg[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _227_ (.CLK(clk),
    .D(_024_),
    .RESET_B(reset_n),
    .SCD(\period_reg[3] ),
    .SCE(scan_en),
    .Q(\period_reg[7] ));
 assign scan_out[1] = \period_reg[4] ;
 assign scan_out[2] = \period_reg[5] ;
 assign scan_out[3] = \period_reg[6] ;
 assign scan_out[0] = \period_reg[7] ;
endmodule
