# Digital Synthesis Summary

- **Workflow**: 8b4392da-4d9b-47d6-8d35-4b61e1e84b83
- **Status**: `ok` (rc=0)
- **Top module**: `pwm_controller_mmio`
- **Clock**: `clk` @ **10.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/8b4392da-4d9b-47d6-8d35-4b61e1e84b83/4dd8af3e-7647-4c70-976d-ae5f173c44fb/digital/arch2tapeout/digital/synth/runs/digital_8b4392da-4d9b-47d6-8d35-4b61e1e84b83/final/metrics.json`
- netlist candidates: 1 found
