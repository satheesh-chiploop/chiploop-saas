# Tapeout Logic Equivalence Check

- Status: `inconclusive_unresolved_cells`
- Comparison: `RTL vs final tapeout implementation netlist`
- Top module: `pwm_controller_mmio`
- RTL files: `1`
- Tapeout netlist: `pwm_controller_mmio.pnl.v`
- Standard-cell models loaded: `1`
- Missing standard-cell models: `0`
- Unproven points: `0`
- Return code: `1`
- Failure reason: `yosys_inconclusive_see_lec_log`

This is distinct from synthesis LEC. Synthesis LEC compares RTL against `digital/synth/netlist/*_synth.v`; tapeout LEC compares RTL against the final implementation netlist collected after physical implementation.
