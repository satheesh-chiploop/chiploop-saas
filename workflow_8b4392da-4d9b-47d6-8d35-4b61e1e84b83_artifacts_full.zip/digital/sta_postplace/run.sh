#!/usr/bin/env bash
set -euo pipefail
export OPENLANE_NUM_CORES=2
docker run --rm \
  -v "/root/chiploop-backend/backend/pdk":/pdk \
  -v "/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/8b4392da-4d9b-47d6-8d35-4b61e1e84b83/4dd8af3e-7647-4c70-976d-ae5f173c44fb/digital/arch2tapeout/digital/run_work":/work \
  -e PDK=sky130A \
  -e PDK_ROOT=/pdk \
  ghcr.io/efabless/openlane2:2.4.0.dev1 \
  bash -lc 'set -e; cd /work && openlane --flow Classic --run-tag digital_8b4392da-4d9b-47d6-8d35-4b61e1e84b83 --override-config RUN_LINTER=False --to OpenROAD.STAMidPNR place/config.json'
