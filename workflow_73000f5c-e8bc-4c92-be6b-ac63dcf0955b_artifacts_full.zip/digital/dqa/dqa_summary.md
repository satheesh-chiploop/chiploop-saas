# Digital DQA Summary
- workflow_id: `73000f5c-e8bc-4c92-be6b-ac63dcf0955b`
- status: `pass`
- rtl files: `8`
- warning count: `0`

## Stage Status
- rtl_lint: `warn`
- cdc: `pass`
- reset_integrity: `pass`
- synthesis_readiness: `pass`
