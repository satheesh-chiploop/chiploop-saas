{
  "type": "cdc_analysis_report",
  "version": "1.0",
  "inputs": {
    "clock_reset_intent_present": false,
    "rtl_file_count": 9
  },
  "observations": {
    "inferred_clocks": [
      "clk"
    ],
    "inferred_domains": [],
    "per_file": [
      {
        "file": "backend/workflows/73000f5c-e8bc-4c92-be6b-ac63dcf0955b/fpga/src/fpga/target_explorer/interface_adapter/adaptive_aero_control_top_spi_fpga_top.sv",
        "clock": null,
        "domain": null
      },
      {
        "file": "backend/workflows/73000f5c-e8bc-4c92-be6b-ac63dcf0955b/fpga/src/upstream/adaptive_aero_control_top.v",
        "clock": null,
        "domain": null
      },
      {
        "file": "backend/workflows/73000f5c-e8bc-4c92-be6b-ac63dcf0955b/fpga/src/upstream/adaptive_aero_control_top_spi_fpga_top.sv",
        "clock": null,
        "domain": null
      },
      {
        "file": "backend/workflows/73000f5c-e8bc-4c92-be6b-ac63dcf0955b/fpga/src/upstream/command_clamper.v",
        "clock": null,
        "domain": null
      },
      {
        "file": "backend/workflows/73000f5c-e8bc-4c92-be6b-ac63dcf0955b/fpga/src/upstream/request_packet_decoder.v",
        "clock": null,
        "domain": null
      },
      {
        "file": "backend/workflows/73000f5c-e8bc-4c92-be6b-ac63dcf0955b/fpga/src/upstream/response_packet_checker.v",
        "clock": null,
        "domain": null
      },
      {
        "file": "backend/workflows/73000f5c-e8bc-4c92-be6b-ac63dcf0955b/fpga/src/upstream/safe_fallback_controller.v",
        "clock": null,
        "domain": null
      },
      {
        "file": "backend/workflows/73000f5c-e8bc-4c92-be6b-ac63dcf0955b/fpga/src/upstream/status_observer.v",
        "clock": "clk",
        "domain": null
      },
      {
        "file": "backend/workflows/73000f5c-e8bc-4c92-be6b-ac63dcf0955b/fpga/src/upstream/transaction_supervisor.v",
        "clock": "clk",
        "domain": null
      }
    ]
  },
  "findings": [],
  "recommendations": [
    "Provide clock_reset_arch_intent.json for higher-fidelity CDC intent (domains, allowed crossings).",
    "For single-bit control crossings: use 2-flop synchronizers.",
    "For multi-bit data: use async FIFOs or validated handshake schemes.",
    "Run a real CDC tool in enterprise flow (Questa CDC / SpyGlass CDC / VC CDC) when available."
  ],
  "note": "This agent provides intent-level CDC screening. It is not a replacement for signoff CDC tools."
}