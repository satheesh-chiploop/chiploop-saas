module response_packet_checker (
    clk,
    rst_n,
    resp_valid_i,
    resp_data_i,
    resp_ready_o,
    expected_seq_i,
    response_seq_o,
    completion_status_o,
    drag_summary_o,
    lift_summary_o,
    response_flags_o,
    resp_status_ok_o,
    resp_seq_match_o,
    resp_accept_o
);
input clk;
input rst_n;
input resp_valid_i;
input [127:0] resp_data_i;
output resp_ready_o;
input [7:0] expected_seq_i;
output reg [7:0] response_seq_o;
output reg [3:0] completion_status_o;
output reg [15:0] drag_summary_o;
output reg [15:0] lift_summary_o;
output reg [7:0] response_flags_o;
output reg resp_status_ok_o;
output reg resp_seq_match_o;
output reg resp_accept_o;

assign resp_ready_o = 1'b1;

always @(*) begin
    response_seq_o = resp_data_i[127:120];
    completion_status_o = resp_data_i[119:116];
    drag_summary_o = resp_data_i[115:100];
    lift_summary_o = resp_data_i[99:84];
    response_flags_o = resp_data_i[83:76];
    resp_status_ok_o = (completion_status_o[1:0] == 2'b00) && (response_flags_o[0] == 1'b0);
    resp_seq_match_o = (response_seq_o == expected_seq_i);
    resp_accept_o = resp_valid_i & resp_seq_match_o & resp_status_ok_o;
end

endmodule
