// Auto-generated FPGA-only serialized transport shell.
// The verified core RTL remains unchanged; ASIC flows continue to use the core top.
module adaptive_aero_control_top_spi_fpga_top (
  input  logic clk,
  input  logic reset_n,
  input  logic spi_sclk,
  input  logic spi_cs_n,
  input  logic spi_mosi,
  output logic spi_miso,
  output logic fault_indicator
);
  localparam integer INPUT_BITS = 262;
  localparam integer OUTPUT_BITS = 35;
  logic [INPUT_BITS-1:0] rx_shift, rx_active;
  logic [OUTPUT_BITS-1:0] tx_shift, tx_snapshot;
  logic spi_active;
  logic spi_cs_meta, spi_cs_sync, spi_cs_prev;
  logic core_s_axis_req_valid;
  logic [127:0] core_s_axis_req_data;
  logic core_m_axis_resp_ready;
  logic core_m_axis_resp_valid;
  logic [127:0] core_m_axis_resp_data;
  logic core_actuator_cmd_ready;
  logic [1:0] core_mode_sel;
  wire core_s_axis_req_ready;
  wire core_actuator_cmd_valid;
  wire [31:0] core_actuator_cmd_data;
  wire core_status_irq;
  assign core_s_axis_req_valid = rx_active[0 +: 1];
  assign core_s_axis_req_data = rx_active[1 +: 128];
  assign core_m_axis_resp_ready = rx_active[129 +: 1];
  assign core_m_axis_resp_valid = rx_active[130 +: 1];
  assign core_m_axis_resp_data = rx_active[131 +: 128];
  assign core_actuator_cmd_ready = rx_active[259 +: 1];
  assign core_mode_sel = rx_active[260 +: 2];
  wire [OUTPUT_BITS-1:0] core_response = {core_s_axis_req_ready, core_actuator_cmd_valid, core_actuator_cmd_data, core_status_irq};
  assign fault_indicator = 1'b0;
  // Chip select asynchronously clears only the frame-state bit. Data
  // registers use SPI clock alone, which is legal in ECP5 fabric.
  always_ff @(posedge spi_sclk or posedge spi_cs_n) begin
    if (spi_cs_n) spi_active <= 1'b0;
    else spi_active <= 1'b1;
  end
  always_ff @(posedge spi_sclk) begin
    if (!spi_cs_n) begin
      rx_shift <= {rx_shift[260:0], spi_mosi};
      if (!spi_active) tx_shift <= {tx_snapshot[33:0], 1'b0};
      else tx_shift <= {tx_shift[33:0], 1'b0};
    end
  end
  // Synchronize frame completion into the core clock domain. The host
  // keeps MOSI stable around CS rising as required by the protocol.
  always_ff @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
      spi_cs_meta <= 1'b1; spi_cs_sync <= 1'b1; spi_cs_prev <= 1'b1;
      rx_active <= '0; tx_snapshot <= '0;
    end else begin
      spi_cs_meta <= spi_cs_n; spi_cs_sync <= spi_cs_meta; spi_cs_prev <= spi_cs_sync;
      if (spi_cs_sync && !spi_cs_prev) rx_active <= rx_shift;
      tx_snapshot <= core_response;
    end
  end
  always_comb spi_miso = spi_active ? tx_shift[OUTPUT_BITS-1] : tx_snapshot[OUTPUT_BITS-1];
  adaptive_aero_control_top u_core (
    .clk(clk),
    .rst_n(reset_n),
    .s_axis_req_valid(core_s_axis_req_valid),
    .s_axis_req_data(core_s_axis_req_data),
    .s_axis_req_ready(core_s_axis_req_ready),
    .m_axis_resp_ready(core_m_axis_resp_ready),
    .m_axis_resp_valid(core_m_axis_resp_valid),
    .m_axis_resp_data(core_m_axis_resp_data),
    .actuator_cmd_ready(core_actuator_cmd_ready),
    .actuator_cmd_valid(core_actuator_cmd_valid),
    .actuator_cmd_data(core_actuator_cmd_data),
    .mode_sel(core_mode_sel),
    .status_irq(core_status_irq)
  );
endmodule
