module command_clamper (
    clk,
    rst_n,
    cmd_in_i,
    cmd_valid_i,
    use_fallback_i,
    cmd_min_i,
    cmd_max_i,
    slew_limit_i,
    cmd_out_o,
    cmd_valid_o,
    clamp_active_o
);
input clk;
input rst_n;
input [31:0] cmd_in_i;
input cmd_valid_i;
input use_fallback_i;
input [31:0] cmd_min_i;
input [31:0] cmd_max_i;
input [15:0] slew_limit_i;
output reg [31:0] cmd_out_o;
output reg cmd_valid_o;
output reg clamp_active_o;

reg [31:0] clamp_lo;
reg [31:0] clamp_hi;
reg [31:0] tmp_cmd;

always @(*) begin
    clamp_lo = cmd_min_i;
    clamp_hi = cmd_max_i;
    tmp_cmd = cmd_in_i;
    clamp_active_o = 1'b0;
    if (tmp_cmd < clamp_lo) begin
        tmp_cmd = clamp_lo;
        clamp_active_o = 1'b1;
    end
    if (tmp_cmd > clamp_hi) begin
        tmp_cmd = clamp_hi;
        clamp_active_o = 1'b1;
    end
    if (use_fallback_i) begin
        clamp_active_o = 1'b1;
    end
    if (slew_limit_i == 16'h0000) begin
        tmp_cmd = tmp_cmd;
    end
    cmd_out_o = tmp_cmd;
    cmd_valid_o = cmd_valid_i;
end

endmodule
