module request_packet_decoder (
    clk,
    rst_n,
    req_valid_i,
    req_data_i,
    req_ready_o,
    req_seq_o,
    operating_point_o,
    velocity_cmd_o,
    geometry_handle_o,
    control_mode_o,
    mode_sel_o,
    req_format_ok_o,
    req_parity_ok_o,
    req_accept_o
);
input clk;
input rst_n;
input req_valid_i;
input [127:0] req_data_i;
input req_ready_o;
output reg [7:0] req_seq_o;
output reg [15:0] operating_point_o;
output reg [15:0] velocity_cmd_o;
output reg [7:0] geometry_handle_o;
output reg [3:0] control_mode_o;
output reg [1:0] mode_sel_o;
output reg req_format_ok_o;
output reg req_parity_ok_o;
output reg req_accept_o;

always @(*) begin
    req_seq_o = req_data_i[127:120];
    operating_point_o = req_data_i[119:104];
    velocity_cmd_o = req_data_i[103:88];
    geometry_handle_o = req_data_i[87:80];
    control_mode_o = req_data_i[79:76];
    mode_sel_o = req_data_i[75:74];
    req_format_ok_o = (req_data_i[73:72] == 2'b00);
    req_parity_ok_o = ~(^req_data_i);
    req_accept_o = req_valid_i & req_ready_o & req_format_ok_o & req_parity_ok_o & (mode_sel_o != 2'b11);
end

endmodule
