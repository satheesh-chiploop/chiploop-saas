module status_observer (
    clk,
    rst_n,
    busy_i,
    req_accepted_i,
    resp_accepted_i,
    stale_i,
    timeout_i,
    clamp_active_i,
    fallback_active_i,
    last_seq_i,
    status_irq_o,
    busy_o,
    request_accepted_o,
    response_accepted_o,
    stale_o,
    timeout_o,
    clamp_flag_o,
    fallback_flag_o,
    last_seq_o
);
input clk;
input rst_n;
input busy_i;
input req_accepted_i;
input resp_accepted_i;
input stale_i;
input timeout_i;
input clamp_active_i;
input fallback_active_i;
input [7:0] last_seq_i;
output reg status_irq_o;
output reg busy_o;
output reg request_accepted_o;
output reg response_accepted_o;
output reg stale_o;
output reg timeout_o;
output reg clamp_flag_o;
output reg fallback_flag_o;
output reg [7:0] last_seq_o;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        status_irq_o <= 1'b0;
        busy_o <= 1'b0;
        request_accepted_o <= 1'b0;
        response_accepted_o <= 1'b0;
        stale_o <= 1'b0;
        timeout_o <= 1'b0;
        clamp_flag_o <= 1'b0;
        fallback_flag_o <= 1'b1;
        last_seq_o <= 8'h00;
    end else begin
        busy_o <= busy_i;
        request_accepted_o <= req_accepted_i;
        response_accepted_o <= resp_accepted_i;
        stale_o <= stale_i;
        timeout_o <= timeout_i;
        clamp_flag_o <= clamp_active_i;
        fallback_flag_o <= fallback_active_i;
        last_seq_o <= last_seq_i;
        status_irq_o <= stale_i | timeout_i | fallback_active_i;
    end
end

endmodule
