module safe_fallback_controller (
    clk,
    rst_n,
    fallback_active_i,
    mode_sel_i,
    operating_point_i,
    velocity_cmd_i,
    safe_cmd_o,
    fallback_valid_o,
    clamp_req_o
);
input clk;
input rst_n;
input fallback_active_i;
input [1:0] mode_sel_i;
input [15:0] operating_point_i;
input [15:0] velocity_cmd_i;
output reg [31:0] safe_cmd_o;
output reg fallback_valid_o;
output reg clamp_req_o;

always @(*) begin
    safe_cmd_o = {8'b0, 8'h00, operating_point_i[7:0], velocity_cmd_i[7:0]};
    if (mode_sel_i == 2'b01) begin
        safe_cmd_o = {8'b0, 8'h00, operating_point_i[7:0], 8'h40};
    end else if (mode_sel_i == 2'b10) begin
        safe_cmd_o = {8'b0, 8'h00, 8'h20, velocity_cmd_i[7:0]};
    end
    fallback_valid_o = fallback_active_i;
    clamp_req_o = fallback_active_i;
end

endmodule
