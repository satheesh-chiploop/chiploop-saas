module transaction_supervisor (
    clk,
    rst_n,
    req_accept_i,
    req_seq_i,
    mode_sel_i,
    resp_valid_i,
    resp_seq_i,
    resp_status_ok_i,
    timeout_limit_i,
    busy_o,
    accept_req_o,
    outstanding_seq_o,
    timeout_expired_o,
    stale_o,
    fault_o,
    fallback_active_o,
    last_seq_o,
    request_accepted_pulse_o,
    response_accepted_pulse_o,
    busy_i
);
input clk;
input rst_n;
input req_accept_i;
input [7:0] req_seq_i;
input [1:0] mode_sel_i;
input resp_valid_i;
input [7:0] resp_seq_i;
input resp_status_ok_i;
input [15:0] timeout_limit_i;
output reg busy_o;
output reg accept_req_o;
output reg [7:0] outstanding_seq_o;
output reg timeout_expired_o;
output reg stale_o;
output reg fault_o;
output reg fallback_active_o;
output reg [7:0] last_seq_o;
output reg request_accepted_pulse_o;
output reg response_accepted_pulse_o;
input busy_i;

reg [15:0] age_q;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        busy_o <= 1'b0;
        accept_req_o <= 1'b1;
        outstanding_seq_o <= 8'h00;
        timeout_expired_o <= 1'b0;
        stale_o <= 1'b0;
        fault_o <= 1'b0;
        fallback_active_o <= 1'b1;
        last_seq_o <= 8'h00;
        request_accepted_pulse_o <= 1'b0;
        response_accepted_pulse_o <= 1'b0;
        age_q <= 16'h0000;
    end else begin
        request_accepted_pulse_o <= 1'b0;
        response_accepted_pulse_o <= 1'b0;
        timeout_expired_o <= 1'b0;
        stale_o <= 1'b0;
        fault_o <= 1'b0;
        if (req_accept_i && accept_req_o) begin
            busy_o <= 1'b1;
            outstanding_seq_o <= req_seq_i;
            last_seq_o <= req_seq_i;
            age_q <= 16'h0000;
            fallback_active_o <= 1'b0;
            request_accepted_pulse_o <= 1'b1;
        end else if (busy_o) begin
            age_q <= age_q + 16'h0001;
        end
        if (busy_o && (age_q >= timeout_limit_i)) begin
            timeout_expired_o <= 1'b1;
            stale_o <= 1'b1;
            fault_o <= 1'b1;
            fallback_active_o <= 1'b1;
            busy_o <= 1'b0;
        end
        if (resp_valid_i) begin
            if ((resp_seq_i == outstanding_seq_o) && resp_status_ok_i) begin
                busy_o <= 1'b0;
                last_seq_o <= resp_seq_i;
                response_accepted_pulse_o <= 1'b1;
            end else begin
                fault_o <= 1'b1;
                fallback_active_o <= 1'b1;
            end
        end
        if (mode_sel_i == 2'b11) begin
            fallback_active_o <= 1'b1;
        end
        if (busy_i) begin
            busy_o <= busy_o | busy_i;
        end
        if (!busy_o) begin
            accept_req_o <= 1'b1;
        end else begin
            accept_req_o <= 1'b0;
        end
    end
end

endmodule
