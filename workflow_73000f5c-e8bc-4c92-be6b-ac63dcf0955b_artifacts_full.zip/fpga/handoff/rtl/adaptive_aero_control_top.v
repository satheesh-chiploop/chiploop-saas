module adaptive_aero_control_top (
    clk,
    rst_n,
    s_axis_req_valid,
    s_axis_req_data,
    s_axis_req_ready,
    m_axis_resp_ready,
    m_axis_resp_valid,
    m_axis_resp_data,
    actuator_cmd_ready,
    actuator_cmd_valid,
    actuator_cmd_data,
    mode_sel,
    status_irq
);
input clk;
input rst_n;
input s_axis_req_valid;
input [127:0] s_axis_req_data;
output s_axis_req_ready;
input m_axis_resp_ready;
input m_axis_resp_valid;
input [127:0] m_axis_resp_data;
input actuator_cmd_ready;
output actuator_cmd_valid;
output [31:0] actuator_cmd_data;
input [1:0] mode_sel;
output status_irq;
wire [7:0] req_seq;
wire [15:0] operating_point;
wire [15:0] velocity_cmd;
wire [7:0] geometry_handle;
wire [3:0] control_mode;
wire [1:0] req_mode_sel;
wire req_format_ok;
wire req_parity_ok;
wire req_accept;
wire accept_req;
wire [7:0] outstanding_seq;
wire [15:0] timeout_limit;
wire busy;
wire fallback_active;
wire timeout_expired;
wire stale;
wire fault;
wire [7:0] resp_seq;
wire [3:0] completion_status;
wire [15:0] drag_summary;
wire [15:0] lift_summary;
wire [7:0] response_flags;
wire resp_status_ok;
wire resp_seq_match;
wire resp_accept;
wire [31:0] safe_cmd;
wire fallback_valid;
wire clamp_req;
wire [31:0] cmd_out;
wire cmd_valid;
wire clamp_active;
wire status_busy;
wire request_accepted_pulse;
wire response_accepted_pulse;
wire [7:0] last_seq;
assign s_axis_req_ready = accept_req;
assign actuator_cmd_valid = cmd_valid;
assign actuator_cmd_data = cmd_out;
assign status_irq = (fault | stale | timeout_expired | fallback_active);

request_packet_decoder u_request_packet_decoder (
    .clk(clk),
    .rst_n(rst_n),
    .req_valid_i(s_axis_req_valid),
    .req_data_i(s_axis_req_data),
    .req_ready_o(accept_req),
    .req_seq_o(req_seq),
    .operating_point_o(operating_point),
    .velocity_cmd_o(velocity_cmd),
    .geometry_handle_o(geometry_handle),
    .control_mode_o(control_mode),
    .mode_sel_o(req_mode_sel),
    .req_format_ok_o(req_format_ok),
    .req_parity_ok_o(req_parity_ok),
    .req_accept_o(req_accept)
);

transaction_supervisor u_transaction_supervisor (
    .clk(clk),
    .rst_n(rst_n),
    .req_accept_i(req_accept),
    .req_seq_i(req_seq),
    .mode_sel_i(mode_sel),
    .resp_valid_i(resp_accept),
    .resp_seq_i(resp_seq),
    .resp_status_ok_i(resp_status_ok),
    .timeout_limit_i(timeout_limit),
    .busy_o(busy),
    .accept_req_o(accept_req),
    .outstanding_seq_o(outstanding_seq),
    .timeout_expired_o(timeout_expired),
    .stale_o(stale),
    .fault_o(fault),
    .fallback_active_o(fallback_active),
    .last_seq_o(last_seq),
    .request_accepted_pulse_o(request_accepted_pulse),
    .response_accepted_pulse_o(response_accepted_pulse),
    .busy_i(status_busy)
);

response_packet_checker u_response_packet_checker (
    .clk(clk),
    .rst_n(rst_n),
    .resp_valid_i(m_axis_resp_valid),
    .resp_data_i(m_axis_resp_data),
    .resp_ready_o(),
    .expected_seq_i(outstanding_seq),
    .response_seq_o(resp_seq),
    .completion_status_o(completion_status),
    .drag_summary_o(drag_summary),
    .lift_summary_o(lift_summary),
    .response_flags_o(response_flags),
    .resp_status_ok_o(resp_status_ok),
    .resp_seq_match_o(resp_seq_match),
    .resp_accept_o(resp_accept)
);

safe_fallback_controller u_safe_fallback_controller (
    .clk(clk),
    .rst_n(rst_n),
    .fallback_active_i(fallback_active),
    .mode_sel_i(mode_sel),
    .operating_point_i(operating_point),
    .velocity_cmd_i(velocity_cmd),
    .safe_cmd_o(safe_cmd),
    .fallback_valid_o(fallback_valid),
    .clamp_req_o(clamp_req)
);

command_clamper u_command_clamper (
    .clk(clk),
    .rst_n(rst_n),
    .cmd_in_i(safe_cmd),
    .cmd_valid_i(fallback_valid),
    .use_fallback_i(clamp_req),
    .cmd_min_i(32'h00000000),
    .cmd_max_i(32'h000000FF),
    .slew_limit_i(16'h0000),
    .cmd_out_o(cmd_out),
    .cmd_valid_o(cmd_valid),
    .clamp_active_o(clamp_active)
);

status_observer u_status_observer (
    .clk(clk),
    .rst_n(rst_n),
    .busy_i(busy),
    .req_accepted_i(request_accepted_pulse),
    .resp_accepted_i(response_accepted_pulse),
    .stale_i(stale),
    .timeout_i(timeout_expired),
    .clamp_active_i(clamp_active),
    .fallback_active_i(fallback_active),
    .last_seq_i(last_seq),
    .status_irq_o(),
    .busy_o(status_busy),
    .request_accepted_o(),
    .response_accepted_o(),
    .stale_o(),
    .timeout_o(),
    .clamp_flag_o(),
    .fallback_flag_o(),
    .last_seq_o()
);

assign timeout_limit = operating_point;

endmodule
