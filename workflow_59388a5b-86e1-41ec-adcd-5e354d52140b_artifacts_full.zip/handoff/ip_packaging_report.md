# IP Packaging & Handoff Report

- Top: `pwm_fpga_demo`
- Package: `backend/workflows/59388a5b-86e1-41ec-adcd-5e354d52140b/handoff/pwm_fpga_demo_ip_package`
- Zip: `backend/workflows/59388a5b-86e1-41ec-adcd-5e354d52140b/handoff/pwm_fpga_demo_ip_package.zip`

## Bucket counts
- **rtl**: 1
- **spec**: 3
- **arch**: 1
- **microarch**: 1
- **regmap**: 2
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 7
