# Digital DQA Summary
- workflow_id: `59388a5b-86e1-41ec-adcd-5e354d52140b`
- status: `failed`
- rtl files: `1`
- warning count: `1`

## Stage Status
- rtl_lint: `pass`
- cdc: `pass`
- reset_integrity: `warning`
- synthesis_readiness: `failed`

## Blocking Issues
- yosys_synthesis_errors
