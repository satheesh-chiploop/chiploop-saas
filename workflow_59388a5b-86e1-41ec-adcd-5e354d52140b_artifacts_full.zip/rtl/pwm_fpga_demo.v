module pwm_fpga_demo (
    input clk,
    output led
);

reg [7:0] pwm_counter;
reg [7:0] duty_cycle;
reg       direction_up;
reg [15:0] step_counter;

assign led = (pwm_counter < duty_cycle);

always @(posedge clk) begin
    pwm_counter <= pwm_counter + 8'h01;

    if (step_counter == 16'd49999) begin
        step_counter <= 16'd0;

        if (direction_up) begin
            if (duty_cycle == 8'hFF) begin
                duty_cycle <= 8'hFF;
                direction_up <= 1'b0;
            end else begin
                duty_cycle <= duty_cycle + 8'h01;
                direction_up <= 1'b1;
            end
        end else begin
            if (duty_cycle == 8'h00) begin
                duty_cycle <= 8'h00;
                direction_up <= 1'b1;
            end else begin
                duty_cycle <= duty_cycle - 8'h01;
                direction_up <= 1'b0;
            end
        end
    end else begin
        step_counter <= step_counter + 16'd1;
        duty_cycle <= duty_cycle;
        direction_up <= direction_up;
    end
end

endmodule
