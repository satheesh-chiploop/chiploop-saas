#!/usr/bin/env bash
set -euo pipefail

echo "== ChipLoop: Digital Tapeout Agent =="
echo "PDK_VARIANT=sky130A"
echo "OPENLANE_IMAGE=ghcr.io/efabless/openlane2:2.4.0.dev1"
echo "WORKDIR=/work"

export OPENLANE_NUM_CORES=2

docker run --rm \
  -v "/root/chiploop-backend/backend/pdk":/pdk \
  -v "/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/3dfb6282-ae1b-401e-9da7-2cd8c69f139c/4d360c2c-4587-4fd7-8c89-8e3938ac81e8/digital/arch2tapeout/digital/run_work":/work \
  -e PDK=sky130A \
  -e PDK_ROOT=/pdk \
  ghcr.io/efabless/openlane2:2.4.0.dev1 \
  bash -lc 'set -e; cd /work && openlane --flow Classic --run-tag Digital_Arch2Tapeout_3dfb6282-ae1b-401e-9da7-2cd8c69f139c --override-config RUN_LINTER=False --to KLayout.StreamOut tapeout/config.json'

docker run --rm \
  -v "/root/chiploop-backend/backend/pdk":/pdk \
  -v "/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/3dfb6282-ae1b-401e-9da7-2cd8c69f139c/4d360c2c-4587-4fd7-8c89-8e3938ac81e8/digital/arch2tapeout/digital/run_work":/work \
  -e PDK=sky130A \
  -e PDK_ROOT=/pdk \
  ghcr.io/efabless/openlane2:2.4.0.dev1 \
  bash -lc 'set -e; cd /work && openlane --flow Classic --run-tag Digital_Arch2Tapeout_3dfb6282-ae1b-401e-9da7-2cd8c69f139c --override-config RUN_LINTER=False --to Magic.StreamOut tapeout/config.json || true'

docker run --rm \
  -v "/root/chiploop-backend/backend/pdk":/pdk \
  -v "/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/3dfb6282-ae1b-401e-9da7-2cd8c69f139c/4d360c2c-4587-4fd7-8c89-8e3938ac81e8/digital/arch2tapeout/digital/run_work":/work \
  -e PDK=sky130A \
  -e PDK_ROOT=/pdk \
  ghcr.io/efabless/openlane2:2.4.0.dev1 \
  bash -lc 'set -e; cd /work && openlane --flow Classic --run-tag Digital_Arch2Tapeout_3dfb6282-ae1b-401e-9da7-2cd8c69f139c --override-config RUN_LINTER=False --to KLayout.XOR tapeout/config.json || true'
