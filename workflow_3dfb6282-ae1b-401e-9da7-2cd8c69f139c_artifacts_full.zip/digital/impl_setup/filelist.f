/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/3dfb6282-ae1b-401e-9da7-2cd8c69f139c/4d360c2c-4587-4fd7-8c89-8e3938ac81e8/digital/arch2tapeout/handoff/rtl/pwm_controller.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/3dfb6282-ae1b-401e-9da7-2cd8c69f139c/4d360c2c-4587-4fd7-8c89-8e3938ac81e8/digital/arch2tapeout/handoff/rtl/pwm_controller_regs.v
