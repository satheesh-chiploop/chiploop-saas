# Digital Synthesis Summary

- **Workflow**: 3dfb6282-ae1b-401e-9da7-2cd8c69f139c
- **Status**: `ok` (rc=0)
- **Top module**: `pwm_controller`
- **Clock**: `clk` @ **10.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/3dfb6282-ae1b-401e-9da7-2cd8c69f139c/4d360c2c-4587-4fd7-8c89-8e3938ac81e8/digital/arch2tapeout/digital/synth/runs/Digital_Arch2Tapeout_3dfb6282-ae1b-401e-9da7-2cd8c69f139c/final/metrics.json`
- netlist candidates: 1 found
