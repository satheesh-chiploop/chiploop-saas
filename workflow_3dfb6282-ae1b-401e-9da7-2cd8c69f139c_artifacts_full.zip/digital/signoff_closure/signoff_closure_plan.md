# System PD Signoff Closure Plan

- closure_complete: `False`
- selected_restart_stage: `Digital Placement Agent`
- dominant_issue: `setup_timing`
- max_iterations: `2`
- stop_reason: `repair_plan_created`

## Post-Fill Timing
- setup WNS: `-0.08220713231716097`
- setup TNS: `-0.08220713231716097`
- setup violations: `3`
- hold WNS: `0`
- hold TNS: `0`
- hold violations: `0`

## Repair Actions
- `setup_timing` from `Digital Placement Agent`: Apply placement/sizing/routing timing ECO, then rerun later physical signoff.

## Skipped Repairs
- `tapeout_lec_blocked`: Blocked by earlier signoff failure; repair the upstream physical issue first.