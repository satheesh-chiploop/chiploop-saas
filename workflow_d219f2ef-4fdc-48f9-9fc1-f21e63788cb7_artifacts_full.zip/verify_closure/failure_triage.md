# Failure Triage

- Failing testcase/seed pairs: 6
- unknown seed 1: simulation_failure - Replay the failing seed with waveform and full logs.
- unknown seed 2: unknown - Review logs and rerun with debug waveform enabled.
- unknown seed 7: unknown - Review logs and rerun with debug waveform enabled.
- unknown seed 1: unknown - Review logs and rerun with debug waveform enabled.
- unknown seed 2: unknown - Review logs and rerun with debug waveform enabled.
- unknown seed 7: unknown - Review logs and rerun with debug waveform enabled.
