# Coverage Gap Analysis

- Functional coverage: 76.67 / target 100.0%
- Code line coverage: 49.3 / target 90.0%
- Code branch coverage: 0.9 / target 80.0%
- Code condition coverage: 0.9 / target 80.0%
- Code toggle coverage: 3.8 / target 80.0%
- Gap count: 12
- Functional bin gaps: 7

## Functional Coverage Gaps
- outputs.alert_irq: bins 1/2, missing nonzero, seen values [0]
- outputs.alert_status: bins 1/2, missing nonzero, seen values [0]
- outputs.rd_data: bins 1/2, missing nonzero, seen values [0]
- outputs.temp_code: bins 1/2, missing nonzero, seen values [0]
- outputs.threshold_code: bins 1/2, missing nonzero, seen values [0]
- inputs.clk: bins 1/2, missing zero, seen values [1]
- inputs.reset_n: bins 1/2, missing zero, seen values [1]

## Recommended Actions
- high: add_directed_tests - Coverage holes should first be mapped to explicit scenarios so closure is explainable.
- medium: increase_random_seeds - More seeds may close random-observable bins after directed gaps are handled.
- medium: review_coverage_model - Unreachable or incorrectly specified bins should be waived or corrected, not chased indefinitely.
