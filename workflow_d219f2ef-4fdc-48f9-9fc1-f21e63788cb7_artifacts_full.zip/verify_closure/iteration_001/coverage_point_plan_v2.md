# Coverage Point Plan

- Source: generated_by_closure_loop

## Closure Iteration 1 Coverage Points

- COV_ITER001_001: `outputs.alert_irq` target bins nonzero
- COV_ITER001_002: `outputs.alert_status` target bins nonzero
- COV_ITER001_003: `outputs.rd_data` target bins nonzero
- COV_ITER001_004: `outputs.temp_code` target bins nonzero
- COV_ITER001_005: `outputs.threshold_code` target bins nonzero
- COV_ITER001_006: `inputs.clk` target bins zero
- COV_ITER001_007: `inputs.reset_n` target bins zero
- COV_ITER001_008: `functional_coverage_below_target` target bins unhit
- COV_ITER001_009: `code_line_coverage_below_target` target bins unhit
- COV_ITER001_010: `code_branch_coverage_below_target` target bins unhit
- COV_ITER001_011: `code_condition_coverage_below_target` target bins unhit
- COV_ITER001_012: `code_toggle_coverage_below_target` target bins unhit
