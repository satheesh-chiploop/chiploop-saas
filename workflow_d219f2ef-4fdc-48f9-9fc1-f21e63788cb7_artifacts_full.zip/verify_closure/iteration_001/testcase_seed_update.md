# Testcase And Seed Update

- Iteration: 1
- Testcase intents added: 18
- Executable tests for rerun: smoke_test, constrained_random_sanity
- Seeds: 1, 2, 7, 3, 4, 5, 6, 8, 9, 10

## Testcase Intents
- `closure_cov_001_001` -> `smoke_test` (coverage_directed_intent)
- `closure_cov_001_002` -> `smoke_test` (coverage_directed_intent)
- `closure_cov_001_003` -> `smoke_test` (coverage_directed_intent)
- `closure_cov_001_004` -> `smoke_test` (coverage_directed_intent)
- `closure_cov_001_005` -> `smoke_test` (coverage_directed_intent)
- `closure_cov_001_006` -> `smoke_test` (coverage_directed_intent)
- `closure_cov_001_007` -> `smoke_test` (coverage_directed_intent)
- `closure_cov_001_008` -> `smoke_test` (coverage_directed_intent)
- `closure_cov_001_009` -> `constrained_random_sanity` (code_coverage_intent)
- `closure_cov_001_010` -> `constrained_random_sanity` (code_coverage_intent)
- `closure_cov_001_011` -> `constrained_random_sanity` (code_coverage_intent)
- `closure_cov_001_012` -> `constrained_random_sanity` (code_coverage_intent)
- `replay_unknown_seed_1` -> `smoke_test` (failure_replay)
- `replay_unknown_seed_2` -> `smoke_test` (failure_replay)
- `replay_unknown_seed_7` -> `smoke_test` (failure_replay)
- `replay_unknown_seed_1` -> `smoke_test` (failure_replay)
- `replay_unknown_seed_2` -> `smoke_test` (failure_replay)
- `replay_unknown_seed_7` -> `smoke_test` (failure_replay)
