# Verification Plan

- Source: generated_by_closure_loop

## Closure Iteration 1 Additions

### Coverage-Driven Objectives
- VCOV-01: `functional_coverage_below_target` (functional_coverage_below_target) - Generate directed tests for unhit functional bins before only increasing random seeds.
- VCOV-02: `code_line_coverage_below_target` (code_line_coverage_below_target) - Inspect uncovered lines; classify as missing stimulus, unreachable code, or RTL cleanup candidate.
- VCOV-03: `code_branch_coverage_below_target` (code_branch_coverage_below_target) - Add branch-directed tests around control conditions and error/edge paths.
- VCOV-04: `code_condition_coverage_below_target` (code_condition_coverage_below_target) - Add tests that exercise each boolean condition outcome in control logic.
- VCOV-05: `code_toggle_coverage_below_target` (code_toggle_coverage_below_target) - Add tests that toggle idle outputs, status bits, interrupts, and register-controlled datapath signals.
- VCOV-06: `outputs.alert_irq` (functional_bin_gap) - Add directed stimulus and checker sampling for outputs.alert_irq; target missing bins: nonzero.
- VCOV-07: `outputs.alert_status` (functional_bin_gap) - Add directed stimulus and checker sampling for outputs.alert_status; target missing bins: nonzero.
- VCOV-08: `outputs.rd_data` (functional_bin_gap) - Add directed stimulus and checker sampling for outputs.rd_data; target missing bins: nonzero.
- VCOV-09: `outputs.temp_code` (functional_bin_gap) - Add directed stimulus and checker sampling for outputs.temp_code; target missing bins: nonzero.
- VCOV-10: `outputs.threshold_code` (functional_bin_gap) - Add directed stimulus and checker sampling for outputs.threshold_code; target missing bins: nonzero.
- VCOV-11: `inputs.clk` (functional_bin_gap) - Add directed stimulus and checker sampling for inputs.clk; target missing bins: zero.
- VCOV-12: `inputs.reset_n` (functional_bin_gap) - Add directed stimulus and checker sampling for inputs.reset_n; target missing bins: zero.

### Failure Replay Objectives
- VFAIL-01: replay `unknown` seed `1` with waveform and preserve logs.
- VFAIL-02: replay `unknown` seed `2` with waveform and preserve logs.
- VFAIL-03: replay `unknown` seed `7` with waveform and preserve logs.
- VFAIL-04: replay `unknown` seed `1` with waveform and preserve logs.
- VFAIL-05: replay `unknown` seed `2` with waveform and preserve logs.
- VFAIL-06: replay `unknown` seed `7` with waveform and preserve logs.

### Guardrails
- Do not edit RTL in closure iterations unless failure triage classifies a true design bug and user approval is captured.
- Every added testcase or seed must map to a coverage gap, failed seed, or missing checker objective.
