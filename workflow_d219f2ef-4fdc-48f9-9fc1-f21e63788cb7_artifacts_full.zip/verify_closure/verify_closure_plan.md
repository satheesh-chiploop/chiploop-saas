# Verification Closure Plan

- Verdict: debug_failures_first
- Coverage gaps: 12
- Functional bin gaps: 7
- Failing testcase/seed pairs: 6

## Verify Evidence Snapshot
- Runs: 6
- Simulation pass/fail: 5 / 1
- Functional coverage: 76.67
- Code line/branch/condition/toggle coverage: 49.3 / 0.9 / 0.9 / 3.8
- Formal: fail
- Golden model: not_enabled
- Tools: verilator / verilator_coverage / symbiyosys
- Plans: verification=False, monitor/checker=False, coverage=False

## Functional Coverage Not Met
- outputs.alert_irq: bins 1/2, missing nonzero; Add directed stimulus and checker sampling for outputs.alert_irq; target missing bins: nonzero.
- outputs.alert_status: bins 1/2, missing nonzero; Add directed stimulus and checker sampling for outputs.alert_status; target missing bins: nonzero.
- outputs.rd_data: bins 1/2, missing nonzero; Add directed stimulus and checker sampling for outputs.rd_data; target missing bins: nonzero.
- outputs.temp_code: bins 1/2, missing nonzero; Add directed stimulus and checker sampling for outputs.temp_code; target missing bins: nonzero.
- outputs.threshold_code: bins 1/2, missing nonzero; Add directed stimulus and checker sampling for outputs.threshold_code; target missing bins: nonzero.
- inputs.clk: bins 1/2, missing zero; Add directed stimulus and checker sampling for inputs.clk; target missing bins: zero.
- inputs.reset_n: bins 1/2, missing zero; Add directed stimulus and checker sampling for inputs.reset_n; target missing bins: zero.

## Recommended Actions
- critical: Replay failing testcase/seed pairs with waveform enabled before changing RTL.
- high: Generate directed tests targeting unhit functional bins and uncovered code paths.
- medium: Review whether any coverage holes are unreachable or incorrectly modeled.
- medium: Add or regenerate a monitor/checker plan so each requirement has an observing monitor and a checker, assertion, scoreboard, or coverage point.
