# System Simulation Summary + Coverage

- Top module: None
- Status: None
- Total simulation runs: None
- Simulation pass count: None
- Simulation fail count: None
- Total runtime (s): None
- Coverage status: missing
- Functional coverage %: None
- Coverage bins hit: None
- Coverage total bins: None
- Assertions total: None
- Assertion failures: None
