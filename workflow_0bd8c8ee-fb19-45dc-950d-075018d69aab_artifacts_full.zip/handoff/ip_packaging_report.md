# IP Packaging & Handoff Report

- Top: `top`
- Package: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0bd8c8ee-fb19-45dc-950d-075018d69aab/595547c6-da8b-45f9-8681-53888de54e2e/digital/handoff/top_ip_package`
- Zip: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/0bd8c8ee-fb19-45dc-950d-075018d69aab/595547c6-da8b-45f9-8681-53888de54e2e/digital/handoff/top_ip_package.zip`

## Bucket counts
- **rtl**: 0
- **spec**: 0
- **arch**: 0
- **microarch**: 0
- **regmap**: 0
- **constraints**: 0
- **power_intent**: 0
- **verification**: 0
- **reports**: 0
- **other**: 0
