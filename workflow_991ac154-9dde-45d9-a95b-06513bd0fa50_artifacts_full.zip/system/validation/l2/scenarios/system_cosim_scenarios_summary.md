# CoSim Scenario Summary

- Contract ready: False
- Blocking error count: 1
- Total scenarios: 6
- Enabled scenarios: 0
- Disabled scenarios: 6
