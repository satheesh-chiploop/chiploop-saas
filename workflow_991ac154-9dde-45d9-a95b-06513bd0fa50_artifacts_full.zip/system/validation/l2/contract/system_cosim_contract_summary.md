# CoSim Contract Summary

- Overall status: not_ready
- Pass count: 7
- Issue count: 3
- Blocking error count: 1

## Open Issues
- [error] INGEST_NOT_READY: CoSim ingest did not reach ready_for_system_l2_contract = true.
- [warning] SOFTWARE_L1_STATUS_UNKNOWN: System Software L1 validation status could not be determined.
- [warning] DMA_UNRESOLVED: DMA presence could not be resolved cleanly.
