# System Software Validation Ingest Summary

- Generated at: 2026-06-09T18:31:24.312399+00:00
- Source workflow id: `716c097f-f499-4480-b878-5590ab3995b8`
- Validation scope: `software_only`
- Co-sim enabled: `False`
- Overall ingest status: `ready`

## Discovered assets

- `software_package_manifest` → exists=`True` | source=`supabase` | resolved=`backend/workflows/716c097f-f499-4480-b878-5590ab3995b8/system/software/package/system_software_package.json`
- `build_manifest` → exists=`True` | source=`supabase` | resolved=`backend/workflows/716c097f-f499-4480-b878-5590ab3995b8/system/software/system_software_build_manifest.json`
- `test_manifest` → exists=`False` | source=`missing` | resolved=``
- `mock_manifest` → exists=`False` | source=`missing` | resolved=``
- `sdk_manifest` → exists=`True` | source=`supabase` | resolved=`backend/workflows/716c097f-f499-4480-b878-5590ab3995b8/system/software/sdk/system_software_sdk_manifest.json`
- `application_manifest` → exists=`True` | source=`supabase` | resolved=`backend/workflows/716c097f-f499-4480-b878-5590ab3995b8/system/software/apps/system_software_application_manifest.json`
- `tools_manifest` → exists=`False` | source=`missing` | resolved=``
- `adapter_manifest` → exists=`True` | source=`supabase` | resolved=`backend/workflows/716c097f-f499-4480-b878-5590ab3995b8/system/software/adapter/system_software_adapter_manifest.json`
- `services_manifest` → exists=`True` | source=`supabase` | resolved=`backend/workflows/716c097f-f499-4480-b878-5590ab3995b8/system/software/services/system_software_core_services_manifest.json`
- `input_contract` → exists=`True` | source=`supabase` | resolved=`backend/workflows/716c097f-f499-4480-b878-5590ab3995b8/system/software/input/system_software_input_contract.json`
- `api_contract` → exists=`True` | source=`supabase` | resolved=`backend/workflows/716c097f-f499-4480-b878-5590ab3995b8/system/software/sdk/system_software_api_contract.json`
- `executive_summary` → exists=`False` | source=`missing` | resolved=``

## Workspace members

- `sdk/pwm_fan_control_software`
- `services`
- `adapter/pwm_fan_control_software_adapter`
- `apps/fan_status_cli`
- `apps/fan_profile_service`

## Missing required assets

- none
