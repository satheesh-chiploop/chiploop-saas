# System Software CoSim Harness Summary

- Generated at: `2026-06-09T18:31:27.478390+00:00`
- L1 ready: `None`
- Harness status: `blocked`
- Scenario count: `6`

## Blocked dependencies
- `digital_spec_missing`
- `integration_intent_missing`
- `no_executable_cosim_commands_resolved`

## Resolved commands
- none
