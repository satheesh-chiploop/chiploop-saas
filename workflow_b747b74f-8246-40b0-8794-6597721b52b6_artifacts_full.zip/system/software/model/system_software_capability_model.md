# System Software Capability Model

- Generated at: 2026-06-09T17:28:17.452518+00:00
- Source workflow id: 602daab4-364c-4d9c-91f8-24b6262eb3f3

## Platform identity

- Top module: `pwm_controller`
- RTL file count: `4`

## Software services

- `register_access` → `True`
- `driver_layer` → `True`
- `interrupt_control` → `True`
- `dma_control` → `False`
- `boot_orchestration` → `False`
- `clock_control` → `False`
- `reset_control` → `False`
- `power_mode_control` → `False`
- `runtime_validation_support` → `True`

## Register model

- Register count: `4`
- Field count: `5`
- Bus: `MINIMAL`

## Constraints

- system_integration_intent_missing
- system_integration_intent_path_missing
