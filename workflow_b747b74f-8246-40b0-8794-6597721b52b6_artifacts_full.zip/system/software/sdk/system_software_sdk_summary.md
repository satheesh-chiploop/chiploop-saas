# System Software SDK Scaffold Summary

- Generated at: 2026-06-09T17:28:19.398544+00:00
- Source workflow id: 602daab4-364c-4d9c-91f8-24b6262eb3f3
- Target language: `rust`
- Build system: `cargo`
- Crate name: `pwm_fan_control_software`

## Generated files

- `system/software/sdk/pwm_fan_control_software/Cargo.toml`
- `system/software/sdk/pwm_fan_control_software/src/lib.rs`
- `system/software/sdk/pwm_fan_control_software/examples/basic.rs`
- `system/software/sdk/pwm_fan_control_software/src/bin/diag_cli.rs`
- `system/software/sdk/pwm_fan_control_software/config/default.toml`
