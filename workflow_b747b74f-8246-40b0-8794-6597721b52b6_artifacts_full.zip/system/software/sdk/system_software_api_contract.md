# System Software API Contract

- Generated at: 2026-06-09T17:28:18.047803+00:00
- Source workflow id: 602daab4-364c-4d9c-91f8-24b6262eb3f3
- Public API language: rust

## Public API groups

### register_access
Public register access wrapper over the firmware HAL/driver layer.
- `read_register`(register_name: &str) -> `u64`
- `write_register`(register_name: &str, value: u64) -> `Result<(), SoftwareError>`

### device_driver
Primary software-facing driver contract for device lifecycle and status.
- `device_init`(config: DeviceConfig) -> `Result<(), SoftwareError>`
- `device_shutdown`() -> `Result<(), SoftwareError>`
- `get_status`() -> `DeviceStatus`

### interrupts
Optional interrupt control/service layer.
- `register_interrupt_handler`(irq_name: &str, callback: InterruptHandler) -> `Result<(), SoftwareError>`
- `enable_interrupt`(irq_name: &str) -> `Result<(), SoftwareError>`

### handoff_candidates
Candidate APIs derived directly from the upstream handoff.
- `firmware_firmware_manifest`() -> `candidate`
- `firmware_register_map`() -> `candidate`
- `firmware_register_map_debug`() -> `candidate`
- `firmware_register_map_summary`() -> `candidate`
- `firmware_src_hal_mod`() -> `candidate`
- `firmware_isr_interrupt_map`() -> `candidate`
- `firmware_isr_interrupts`() -> `candidate`
- `firmware_isr_interrupts_debug`() -> `candidate`
- `firmware_isr_interrupts_summary`() -> `candidate`
- `firmware_handoff_digital_handoff_ingest`() -> `candidate`
- `firmware_hal_register_validation`() -> `candidate`
- `firmware_hal_register_validation_2`() -> `candidate`
- `firmware_hal_register_validation_debug`() -> `candidate`
- `firmware_hal_registers`() -> `candidate`
- `firmware_hal_registers_debug`() -> `candidate`
- `firmware_hal_registers_summary`() -> `candidate`
- `firmware_drivers_driver_scaffold`() -> `candidate`
- `firmware_drivers_driver_scaffold_debug`() -> `candidate`
- `firmware_drivers_driver_scaffold_summary`() -> `candidate`
