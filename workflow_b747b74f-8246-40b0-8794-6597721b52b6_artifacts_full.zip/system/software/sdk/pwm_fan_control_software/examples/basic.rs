use pwm_fan_control_software::Sdk;

fn main() {
    let sdk = Sdk::new();
    let _ = sdk.get_status();
    println!("system software example app initialized");
}
