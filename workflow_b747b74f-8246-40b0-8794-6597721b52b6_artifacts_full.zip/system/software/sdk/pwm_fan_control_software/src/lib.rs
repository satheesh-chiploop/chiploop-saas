use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct DeviceConfig {
    pub profile: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct DeviceStatus {
    pub healthy: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct DmaDescriptor {
    pub channel: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct DmaToken {
    pub id: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct DmaStatus {
    pub complete: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct PlatformInfo {
    pub name: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct BootState {
    pub stage: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ClockMode {
    LowPower,
    Nominal,
    Performance,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum PowerMode {
    Sleep,
    Idle,
    Active,
}

pub type InterruptHandler = fn();
pub type RuntimeBackend = String;

#[derive(Debug, thiserror::Error)]
pub enum SoftwareError {
    #[error("unimplemented: {0}")]
    Unimplemented(String),
}

#[derive(Debug, Default, Clone)]
pub struct Sdk {}

impl Sdk {
    pub fn new() -> Self {
        Self {}
    }

    pub fn read_register(&self, register_name: &str) -> Result<u64, SoftwareError> {
        Ok(0)
    }

    pub fn write_register(&self, register_name: &str, value: u64) -> Result<(), SoftwareError> {
        Err(SoftwareError::Unimplemented("write_register".into()))
    }

    pub fn device_init(&self, config: DeviceConfig) -> Result<(), SoftwareError> {
        Err(SoftwareError::Unimplemented("device_init".into()))
    }

    pub fn device_shutdown(&self) -> Result<(), SoftwareError> {
        Err(SoftwareError::Unimplemented("device_shutdown".into()))
    }

    pub fn get_status(&self) -> Result<DeviceStatus, SoftwareError> {
        Ok(DeviceStatus::default())
    }

    pub fn register_interrupt_handler(&self, irq_name: &str, callback: InterruptHandler) -> Result<(), SoftwareError> {
        Err(SoftwareError::Unimplemented("register_interrupt_handler".into()))
    }

    pub fn enable_interrupt(&self, irq_name: &str) -> Result<(), SoftwareError> {
        Err(SoftwareError::Unimplemented("enable_interrupt".into()))
    }

    pub fn firmware_firmware_manifest(&self) -> Result<String, SoftwareError> {
        Ok(String::new())
    }

    pub fn firmware_register_map(&self) -> Result<String, SoftwareError> {
        Ok(String::new())
    }

    pub fn firmware_register_map_debug(&self) -> Result<String, SoftwareError> {
        Ok(String::new())
    }

    pub fn firmware_register_map_summary(&self) -> Result<String, SoftwareError> {
        Ok(String::new())
    }

    pub fn firmware_src_hal_mod(&self) -> Result<String, SoftwareError> {
        Ok(String::new())
    }

    pub fn firmware_isr_interrupt_map(&self) -> Result<String, SoftwareError> {
        Ok(String::new())
    }

    pub fn firmware_isr_interrupts(&self) -> Result<String, SoftwareError> {
        Ok(String::new())
    }

    pub fn firmware_isr_interrupts_debug(&self) -> Result<String, SoftwareError> {
        Ok(String::new())
    }

    pub fn firmware_isr_interrupts_summary(&self) -> Result<String, SoftwareError> {
        Ok(String::new())
    }

    pub fn firmware_handoff_digital_handoff_ingest(&self) -> Result<String, SoftwareError> {
        Ok(String::new())
    }

    pub fn firmware_hal_register_validation(&self) -> Result<String, SoftwareError> {
        Ok(String::new())
    }

    pub fn firmware_hal_register_validation_2(&self) -> Result<String, SoftwareError> {
        Ok(String::new())
    }

    pub fn firmware_hal_register_validation_debug(&self) -> Result<String, SoftwareError> {
        Ok(String::new())
    }

    pub fn firmware_hal_registers(&self) -> Result<String, SoftwareError> {
        Ok(String::new())
    }

    pub fn firmware_hal_registers_debug(&self) -> Result<String, SoftwareError> {
        Ok(String::new())
    }

    pub fn firmware_hal_registers_summary(&self) -> Result<String, SoftwareError> {
        Ok(String::new())
    }

    pub fn firmware_drivers_driver_scaffold(&self) -> Result<String, SoftwareError> {
        Ok(String::new())
    }

    pub fn firmware_drivers_driver_scaffold_debug(&self) -> Result<String, SoftwareError> {
        Ok(String::new())
    }

    pub fn firmware_drivers_driver_scaffold_summary(&self) -> Result<String, SoftwareError> {
        Ok(String::new())
    }

    pub fn platform_probe(&self) -> Result<PlatformInfo, SoftwareError> {
        Ok(PlatformInfo::default())
    }
}
