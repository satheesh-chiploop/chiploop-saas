# System Software Applications

- Generated at: 2026-06-09T17:28:25.215633+00:00
- Source workflow id: 602daab4-364c-4d9c-91f8-24b6262eb3f3
- Crate name: `pwm_fan_control_software`

## Applications

- `fan_status_cli` → package `ss_app_fan_status_cli`
- `fan_profile_service` → package `ss_app_fan_profile_service`

## Files

- `system/software/apps/fan_status_cli/src/main.rs`
- `system/software/apps/fan_status_cli/Cargo.toml`
- `system/software/apps/fan_profile_service/src/main.rs`
- `system/software/apps/fan_profile_service/Cargo.toml`
