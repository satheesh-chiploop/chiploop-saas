# System Software Config Schema

- Generated at: 2026-06-09T17:28:21.499805+00:00
- Source workflow id: 602daab4-364c-4d9c-91f8-24b6262eb3f3

## Feature toggles

- `interrupt_control` → `True`
- `dma_control` → `False`
- `power_mode_control` → `False`
- `clock_control` → `False`
- `reset_control` → `False`

## Generated files

- `system/software/config/default_config.json`
- `system/software/config/default_runtime_config.json`
- `system/software/config/default_runtime_config.toml`
