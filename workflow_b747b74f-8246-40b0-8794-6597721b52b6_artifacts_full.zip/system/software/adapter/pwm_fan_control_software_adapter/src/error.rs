#[derive(Debug, thiserror::Error)]
pub enum SoftwareError {
    #[error("unimplemented: {0}")]
    Unimplemented(String),
}
