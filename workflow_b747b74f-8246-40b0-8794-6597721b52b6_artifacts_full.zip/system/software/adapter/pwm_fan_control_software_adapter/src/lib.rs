pub mod adapter;
pub mod error;

pub use adapter::register_adapter::{RegisterAdapter, RegisterIo};
pub use adapter::device_adapter::DeviceAdapter;
pub use error::SoftwareError;
