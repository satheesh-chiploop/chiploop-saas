use crate::error::SoftwareError;

pub trait RegisterIo {
    fn read_u32(&self, register_name: &str) -> Result<u32, SoftwareError>;
    fn write_u32(&self, register_name: &str, value: u32) -> Result<(), SoftwareError>;
}

#[derive(Debug, Default, Clone)]
pub struct RegisterAdapter;

impl RegisterAdapter {
    pub fn new() -> Self {
        Self {}
    }
}

impl RegisterIo for RegisterAdapter {
    fn read_u32(&self, register_name: &str) -> Result<u32, SoftwareError> {
        Err(SoftwareError::Unimplemented(format!("read_u32:{register_name}")))
    }

    fn write_u32(&self, register_name: &str, value: u32) -> Result<(), SoftwareError> {
        let _ = value;
        Err(SoftwareError::Unimplemented(format!("write_u32:{register_name}")))
    }
}
