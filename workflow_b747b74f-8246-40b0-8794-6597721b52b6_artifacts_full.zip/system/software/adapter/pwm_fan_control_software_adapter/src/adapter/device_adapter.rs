use crate::error::SoftwareError;

#[derive(Debug, Default, Clone)]
pub struct DeviceAdapter;

impl DeviceAdapter {
    pub fn new() -> Self {
        Self {}
    }

    pub fn device_init(&self, profile: &str) -> Result<(), SoftwareError> {
        Err(SoftwareError::Unimplemented(format!("device_init:{profile}")))
    }

    pub fn device_shutdown(&self) -> Result<(), SoftwareError> {
        Err(SoftwareError::Unimplemented("device_shutdown".into()))
    }

    pub fn get_status(&self) -> Result<String, SoftwareError> {
        Ok("healthy".into())
    }

    pub fn enable_interrupt(&self, irq_name: &str) -> Result<(), SoftwareError> {
        Err(SoftwareError::Unimplemented(format!("enable_interrupt:{irq_name}")))
    }

}
