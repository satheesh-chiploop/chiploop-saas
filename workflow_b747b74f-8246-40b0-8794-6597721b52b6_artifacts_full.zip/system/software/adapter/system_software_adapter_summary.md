# System Software HAL/Driver Adapter

- Generated at: 2026-06-09T17:28:20.910493+00:00
- Source workflow id: 602daab4-364c-4d9c-91f8-24b6262eb3f3
- Adapter crate: `pwm_fan_control_software_adapter`
- Adapter package: `pwm_fan_control_software_adapter`

## Adapter contract

- `hal_path` → `firmware/hal/registers.rs`
- `driver_path` → `firmware/drivers/driver_scaffold.rs`
- `register_map_path` → `firmware/register_map.json`
- `interrupt_mapping_path` → `firmware/isr/interrupt_map.json`
- `dma_integration_path` → `unavailable`

## Generated files

- `system/software/adapter/pwm_fan_control_software_adapter/src/adapter/register_adapter.rs`
- `system/software/adapter/pwm_fan_control_software_adapter/src/adapter/device_adapter.rs`
- `system/software/adapter/pwm_fan_control_software_adapter/src/error.rs`
- `system/software/adapter/pwm_fan_control_software_adapter/Cargo.toml`
- `system/software/adapter/pwm_fan_control_software_adapter/src/lib.rs`
- `system/software/adapter/pwm_fan_control_software_adapter/src/adapter/mod.rs`
