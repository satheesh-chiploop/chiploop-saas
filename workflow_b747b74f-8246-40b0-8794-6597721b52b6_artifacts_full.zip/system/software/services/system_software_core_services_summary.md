# System Software Core Services

- Generated at: 2026-06-09T17:28:23.779051+00:00
- Source workflow id: 602daab4-364c-4d9c-91f8-24b6262eb3f3
- Service count: 4

## Services

- `init_manager`
- `health_monitor`
- `control_service`
- `interrupt_service`

## Files

- `system/software/services/src/init_manager.rs`
- `system/software/services/src/health_monitor.rs`
- `system/software/services/src/control_service.rs`
- `system/software/services/src/interrupt_service.rs`
- `system/software/services/src/error.rs`
- `system/software/services/Cargo.toml`
- `system/software/services/src/lib.rs`
