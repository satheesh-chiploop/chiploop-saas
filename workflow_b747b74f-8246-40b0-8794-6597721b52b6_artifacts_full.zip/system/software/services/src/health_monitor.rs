use crate::error::SoftwareError;

#[derive(Debug, Default, Clone)]
pub struct HealthMonitor;

impl HealthMonitor {
    pub fn new() -> Self {
        Self {}
    }

    pub fn responsibility(&self) -> &'static str {
        "health_status_and_fault_summarization"
    }

    pub fn start(&self) -> Result<(), SoftwareError> {
        Ok(())
    }

    pub fn stop(&self) -> Result<(), SoftwareError> {
        Ok(())
    }

    pub fn poll(&self) -> Result<String, SoftwareError> {
        Ok("ok".into())
    }
}
