#[derive(Debug, thiserror::Error)]
pub enum SoftwareError {
    #[error("service error: {0}")]
    Service(String),
}
