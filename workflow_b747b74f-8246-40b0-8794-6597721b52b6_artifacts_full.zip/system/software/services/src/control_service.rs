use crate::error::SoftwareError;

#[derive(Debug, Default, Clone)]
pub struct ControlService;

impl ControlService {
    pub fn new() -> Self {
        Self {}
    }

    pub fn responsibility(&self) -> &'static str {
        "platform_control_surface"
    }

    pub fn start(&self) -> Result<(), SoftwareError> {
        Ok(())
    }

    pub fn stop(&self) -> Result<(), SoftwareError> {
        Ok(())
    }

    pub fn poll(&self) -> Result<String, SoftwareError> {
        Ok("ok".into())
    }
}
