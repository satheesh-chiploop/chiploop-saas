use crate::error::SoftwareError;

#[derive(Debug, Default, Clone)]
pub struct InitManager;

impl InitManager {
    pub fn new() -> Self {
        Self {}
    }

    pub fn responsibility(&self) -> &'static str {
        "startup_order_and_readiness"
    }

    pub fn start(&self) -> Result<(), SoftwareError> {
        Ok(())
    }

    pub fn stop(&self) -> Result<(), SoftwareError> {
        Ok(())
    }

    pub fn poll(&self) -> Result<String, SoftwareError> {
        Ok("ok".into())
    }
}
