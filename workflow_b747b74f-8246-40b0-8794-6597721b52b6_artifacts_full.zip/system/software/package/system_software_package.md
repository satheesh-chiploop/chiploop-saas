# System Software Package

- Generated at: 2026-06-09T17:28:26.117822+00:00
- Source workflow id: 602daab4-364c-4d9c-91f8-24b6262eb3f3
- Artifact count: 22
- Inferred required files added: 6
- Package status: `incomplete`
- Entry binary: `ss_app_fan_status_cli`

## Missing required files

- `system/software/adapter/pwm_fan_control_software_adapter/Cargo.toml`
- `system/software/adapter/pwm_fan_control_software_adapter/src/lib.rs`
- `system/software/adapter/pwm_fan_control_software_adapter/src/adapter/mod.rs`
- `system/software/adapter/pwm_fan_control_software_adapter/src/adapter/register_adapter.rs`
- `system/software/adapter/pwm_fan_control_software_adapter/src/adapter/device_adapter.rs`
- `system/software/adapter/pwm_fan_control_software_adapter/src/error.rs`

## Artifacts

- `system/software/sdk/pwm_fan_control_software/Cargo.toml`
- `system/software/sdk/pwm_fan_control_software/src/lib.rs`
- `system/software/sdk/pwm_fan_control_software/examples/basic.rs`
- `system/software/sdk/pwm_fan_control_software/src/bin/diag_cli.rs`
- `system/software/sdk/pwm_fan_control_software/config/default.toml`
- `system/software/apps/fan_status_cli/src/main.rs`
- `system/software/apps/fan_status_cli/Cargo.toml`
- `system/software/apps/fan_profile_service/src/main.rs`
- `system/software/apps/fan_profile_service/Cargo.toml`
- `system/software/services/src/init_manager.rs`
- `system/software/services/src/health_monitor.rs`
- `system/software/services/src/control_service.rs`
- `system/software/services/src/interrupt_service.rs`
- `system/software/services/src/error.rs`
- `system/software/services/Cargo.toml`
- `system/software/services/src/lib.rs`
- `system/software/adapter/pwm_fan_control_software_adapter/Cargo.toml`
- `system/software/adapter/pwm_fan_control_software_adapter/src/lib.rs`
- `system/software/adapter/pwm_fan_control_software_adapter/src/adapter/mod.rs`
- `system/software/adapter/pwm_fan_control_software_adapter/src/adapter/register_adapter.rs`
- `system/software/adapter/pwm_fan_control_software_adapter/src/adapter/device_adapter.rs`
- `system/software/adapter/pwm_fan_control_software_adapter/src/error.rs`
