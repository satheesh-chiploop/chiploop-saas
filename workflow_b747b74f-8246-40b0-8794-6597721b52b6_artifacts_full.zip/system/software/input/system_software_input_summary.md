# System Software Input Contract Summary

- Generated at: 2026-06-09T17:28:15.593875+00:00
- Source handoff: `backend/workflows/602daab4-364c-4d9c-91f8-24b6262eb3f3/system/software_handoff/system_software_handoff.json`
- Source workflow id: `602daab4-364c-4d9c-91f8-24b6262eb3f3`
- Resolution mode: `supabase`
- Valid: `False`

## Required artifacts

- `register_map_path` → `firmware/register_map.json` | exists=`True` | source=`supabase`
- `hal_path` → `firmware/hal/registers.rs` | exists=`True` | source=`supabase`
- `driver_path` → `firmware/drivers/driver_scaffold.rs` | exists=`True` | source=`supabase`
- `firmware_manifest_path` → `firmware/firmware_manifest.json` | exists=`True` | source=`supabase`
- `system_integration_intent_path` → `missing` | exists=`False` | source=`missing`

## Validation

- system_integration_intent_path_missing

## Assumptions / gaps

- system_integration_intent_missing

## Conclusion

This artifact is the normalized, validated input contract for System_Software. Downstream software agents should consume the hydrated state objects and this contract rather than scraping firmware artifacts directly.
