# Digital DQA Summary
- workflow_id: `af282503-30bb-4337-90e1-64f10d4460c4`
- status: `pass`
- rtl files: `2`
- warning count: `0`

## Stage Status
- rtl_lint: `warn`
- cdc: `pass`
- reset_integrity: `pass`
- synthesis_readiness: `pass`
