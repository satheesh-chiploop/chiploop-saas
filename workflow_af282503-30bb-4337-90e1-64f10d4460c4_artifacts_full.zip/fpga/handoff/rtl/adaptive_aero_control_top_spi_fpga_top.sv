// Auto-generated FPGA-only serialized transport shell.
// The verified core RTL remains unchanged; ASIC flows continue to use the core top.
module adaptive_aero_control_top_spi_fpga_top (
  input  logic clk,
  input  logic reset_n,
  input  logic spi_sclk,
  input  logic spi_cs_n,
  input  logic spi_mosi,
  output logic spi_miso,
  output logic fault_indicator
);
  localparam integer INPUT_BITS = 148;
  localparam integer OUTPUT_BITS = 172;
  logic [INPUT_BITS-1:0] rx_shift, rx_active;
  logic [OUTPUT_BITS-1:0] tx_shift, tx_snapshot;
  logic spi_active;
  logic spi_cs_meta, spi_cs_sync, spi_cs_prev;
  logic [15:0] core_csr_addr;
  logic [63:0] core_csr_wdata;
  logic core_csr_write;
  logic core_csr_read;
  logic core_host_cmd_ready;
  logic core_host_rsp_valid;
  logic [63:0] core_host_rsp_data;
  wire [63:0] core_csr_rdata;
  wire core_csr_ready;
  wire core_host_cmd_valid;
  wire [63:0] core_host_cmd_data;
  wire core_host_rsp_ready;
  wire core_actuator_cmd_valid;
  wire [15:0] core_actuator_cmd_data;
  wire core_status_busy;
  wire core_status_request_pending;
  wire core_status_response_valid;
  wire core_status_timeout_fault;
  wire core_status_stale_fault;
  wire core_status_integrity_fault;
  wire core_status_fallback_active;
  wire [15:0] core_status_last_seq;
  wire core_status_applied_clamped_indicator;
  assign core_csr_addr = rx_active[0 +: 16];
  assign core_csr_wdata = rx_active[16 +: 64];
  assign core_csr_write = rx_active[80 +: 1];
  assign core_csr_read = rx_active[81 +: 1];
  assign core_host_cmd_ready = rx_active[82 +: 1];
  assign core_host_rsp_valid = rx_active[83 +: 1];
  assign core_host_rsp_data = rx_active[84 +: 64];
  wire [OUTPUT_BITS-1:0] core_response = {core_csr_rdata, core_csr_ready, core_host_cmd_valid, core_host_cmd_data, core_host_rsp_ready, core_actuator_cmd_valid, core_actuator_cmd_data, core_status_busy, core_status_request_pending, core_status_response_valid, core_status_timeout_fault, core_status_stale_fault, core_status_integrity_fault, core_status_fallback_active, core_status_last_seq, core_status_applied_clamped_indicator};
  assign fault_indicator = 1'b0;
  // Chip select asynchronously clears only the frame-state bit. Data
  // registers use SPI clock alone, which is legal in ECP5 fabric.
  always_ff @(posedge spi_sclk or posedge spi_cs_n) begin
    if (spi_cs_n) spi_active <= 1'b0;
    else spi_active <= 1'b1;
  end
  always_ff @(posedge spi_sclk) begin
    if (!spi_cs_n) begin
      rx_shift <= {rx_shift[146:0], spi_mosi};
      if (!spi_active) tx_shift <= {tx_snapshot[170:0], 1'b0};
      else tx_shift <= {tx_shift[170:0], 1'b0};
    end
  end
  // Synchronize frame completion into the core clock domain. The host
  // keeps MOSI stable around CS rising as required by the protocol.
  always_ff @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
      spi_cs_meta <= 1'b1; spi_cs_sync <= 1'b1; spi_cs_prev <= 1'b1;
      rx_active <= '0; tx_snapshot <= '0;
    end else begin
      spi_cs_meta <= spi_cs_n; spi_cs_sync <= spi_cs_meta; spi_cs_prev <= spi_cs_sync;
      if (spi_cs_sync && !spi_cs_prev) rx_active <= rx_shift;
      tx_snapshot <= core_response;
    end
  end
  always_comb spi_miso = spi_active ? tx_shift[OUTPUT_BITS-1] : tx_snapshot[OUTPUT_BITS-1];
  adaptive_aero_control_top u_core (
    .clk(clk),
    .rst_n(reset_n),
    .csr_addr(core_csr_addr),
    .csr_wdata(core_csr_wdata),
    .csr_rdata(core_csr_rdata),
    .csr_write(core_csr_write),
    .csr_read(core_csr_read),
    .csr_ready(core_csr_ready),
    .host_cmd_valid(core_host_cmd_valid),
    .host_cmd_ready(core_host_cmd_ready),
    .host_cmd_data(core_host_cmd_data),
    .host_rsp_valid(core_host_rsp_valid),
    .host_rsp_ready(core_host_rsp_ready),
    .host_rsp_data(core_host_rsp_data),
    .actuator_cmd_valid(core_actuator_cmd_valid),
    .actuator_cmd_data(core_actuator_cmd_data),
    .status_busy(core_status_busy),
    .status_request_pending(core_status_request_pending),
    .status_response_valid(core_status_response_valid),
    .status_timeout_fault(core_status_timeout_fault),
    .status_stale_fault(core_status_stale_fault),
    .status_integrity_fault(core_status_integrity_fault),
    .status_fallback_active(core_status_fallback_active),
    .status_last_seq(core_status_last_seq),
    .status_applied_clamped_indicator(core_status_applied_clamped_indicator)
  );
endmodule
