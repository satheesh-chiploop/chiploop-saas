module adaptive_aero_control_top (
    input         clk,
    input         rst_n,
    input  [15:0] csr_addr,
    input  [63:0] csr_wdata,
    output [63:0] csr_rdata,
    input         csr_write,
    input         csr_read,
    output        csr_ready,
    output        host_cmd_valid,
    input         host_cmd_ready,
    output [63:0] host_cmd_data,
    input         host_rsp_valid,
    output        host_rsp_ready,
    input  [63:0] host_rsp_data,
    output        actuator_cmd_valid,
    output [15:0] actuator_cmd_data,
    output        status_busy,
    output        status_request_pending,
    output        status_response_valid,
    output        status_timeout_fault,
    output        status_stale_fault,
    output        status_integrity_fault,
    output        status_fallback_active,
    output [15:0] status_last_seq,
    output        status_applied_clamped_indicator
);

  reg [15:0] cfg_max_velocity_mps_q;
  reg [15:0] cfg_min_velocity_mps_q;
  reg        cfg_enable_host_inference;
  reg [4:0]  cfg_mode_bits;
  reg [15:0] cfg_response_timeout_cycles;
  reg [15:0] cfg_freshness_timeout_cycles;
  reg        cfg_timeout_policy_sticky;
  reg        cfg_resp_ready_always;
  reg [15:0] cfg_actuator_min_code;
  reg [15:0] cfg_actuator_max_code;
  reg [15:0] cfg_safe_fallback_code;
  reg        cfg_bounds_signed_mode;
  reg [15:0] req_request_stream_vel_q;
  reg [15:0] req_request_geom_token;
  reg [15:0] req_request_aux_bits;
  reg [15:0] req_request_integrity_seed;

  reg [15:0] request_seq_current;
  reg [15:0] latest_accepted_seq;
  reg [15:0] outstanding_seq;
  reg [63:0] host_tx_packet;
  reg [63:0] host_rx_packet;

  reg [15:0] applied_actuator_cmd;
  reg        applied_clamped_indicator_r;
  reg        busy_r;
  reg        request_pending_r;
  reg        response_valid_r;
  reg        timeout_fault_r;
  reg        stale_fault_r;
  reg        integrity_fault_r;
  reg        fallback_active_r;

  reg [15:0] timeout_counter;
  reg [15:0] response_age;
  reg [63:0] request_packet_reg;
  reg [63:0] response_packet_reg;
  reg        request_inflight;
  reg        pending_launch;
  reg        accept_response;
  reg        accepted_clamp;
  reg        response_seq_match;
  reg        response_integrity_ok;
  reg        response_age_ok;
  reg        response_code_ok;
  reg        response_packet_ok;
  reg        timeout_expired;
  reg        trigger_pulse;
  reg        clear_faults_pulse;
  reg        clear_pending_pulse;
  reg        clear_timeout_pulse;
  reg        clear_stale_pulse;
  reg        clear_integrity_pulse;
  reg        clear_fallback_pulse;
  reg        clear_request_pending_pulse;
  reg [15:0] decoded_response_seq;
  reg [15:0] decoded_response_code;
  reg [15:0] decoded_response_age;
  reg [15:0] decoded_response_integrity;
  reg [15:0] request_integrity_calc;
  reg [15:0] response_integrity_calc;
  reg [15:0] next_applied_cmd;
  reg [15:0] clamped_cmd;

  wire [63:0] csr_rdata_w;
  wire        csr_ready_w;
  wire        host_cmd_valid_w;
  wire [63:0] host_cmd_data_w;
  wire        host_rsp_ready_w;
  wire        actuator_cmd_valid_w;
  wire [15:0] actuator_cmd_data_w;
  wire        status_busy_w;
  wire        status_request_pending_w;
  wire        status_response_valid_w;
  wire        status_timeout_fault_w;
  wire        status_stale_fault_w;
  wire        status_integrity_fault_w;
  wire        status_fallback_active_w;
  wire [15:0] status_last_seq_w;
  wire        status_applied_clamped_indicator_w;

  assign csr_rdata = csr_rdata_w;
  assign csr_ready = csr_ready_w;
  assign host_cmd_valid = host_cmd_valid_w;
  assign host_cmd_data = host_cmd_data_w;
  assign host_rsp_ready = host_rsp_ready_w;
  assign actuator_cmd_valid = actuator_cmd_valid_w;
  assign actuator_cmd_data = actuator_cmd_data_w;
  assign status_busy = status_busy_w;
  assign status_request_pending = status_request_pending_w;
  assign status_response_valid = status_response_valid_w;
  assign status_timeout_fault = status_timeout_fault_w;
  assign status_stale_fault = status_stale_fault_w;
  assign status_integrity_fault = status_integrity_fault_w;
  assign status_fallback_active = status_fallback_active_w;
  assign status_last_seq = status_last_seq_w;
  assign status_applied_clamped_indicator = status_applied_clamped_indicator_w;

  always @(*) begin
    request_integrity_calc = req_request_stream_vel_q ^ req_request_geom_token ^ req_request_aux_bits ^ req_request_integrity_seed ^ {11'h000, cfg_mode_bits};
    response_integrity_calc = decoded_response_seq ^ decoded_response_code ^ decoded_response_age ^ decoded_response_integrity;
  end

  assign csr_rdata_w = (csr_addr == 16'h0000) ? {24'h000000, cfg_max_velocity_mps_q, cfg_min_velocity_mps_q, cfg_enable_host_inference, cfg_mode_bits, 27'h0000000} :
                       (csr_addr == 16'h0008) ? {30'h00000000, cfg_timeout_policy_sticky, cfg_resp_ready_always, cfg_freshness_timeout_cycles, cfg_response_timeout_cycles} :
                       (csr_addr == 16'h0010) ? {15'h0000, cfg_bounds_signed_mode, cfg_safe_fallback_code, cfg_actuator_max_code, cfg_actuator_min_code} :
                       (csr_addr == 16'h0018) ? {24'h000000, applied_actuator_cmd, latest_accepted_seq, status_applied_clamped_indicator_w, status_fallback_active_w, status_integrity_fault_w, status_stale_fault_w, status_timeout_fault_w, status_response_valid_w, status_request_pending_w, status_busy_w} :
                       (csr_addr == 16'h0020) ? {16'h0000, req_request_integrity_seed, req_request_aux_bits, req_request_geom_token, req_request_stream_vel_q} :
                       (csr_addr == 16'h0028) ? {16'h0000, outstanding_seq, latest_accepted_seq, request_seq_current} :
                       (csr_addr == 16'h0030) ? host_tx_packet :
                       (csr_addr == 16'h0038) ? host_rx_packet :
                       64'h0000000000000000;

  assign csr_ready_w = 1'b1;

  assign host_cmd_data_w = request_packet_reg;
  assign host_cmd_valid_w = request_inflight & cfg_enable_host_inference & ~fallback_active_r;

  assign host_rsp_ready_w = cfg_resp_ready_always & request_inflight & cfg_enable_host_inference & ~fallback_active_r;

  assign status_busy_w = busy_r;
  assign status_request_pending_w = request_pending_r;
  assign status_response_valid_w = response_valid_r;
  assign status_timeout_fault_w = timeout_fault_r;
  assign status_stale_fault_w = stale_fault_r;
  assign status_integrity_fault_w = integrity_fault_r;
  assign status_fallback_active_w = fallback_active_r;
  assign status_last_seq_w = latest_accepted_seq;
  assign status_applied_clamped_indicator_w = applied_clamped_indicator_r;

  assign actuator_cmd_valid_w = 1'b1;
  assign actuator_cmd_data_w = fallback_active_r ? cfg_safe_fallback_code : applied_actuator_cmd;

  always @(*) begin
    pending_launch = 1'b0;
    accept_response = 1'b0;
    accepted_clamp = 1'b0;
    response_seq_match = 1'b0;
    response_integrity_ok = 1'b0;
    response_age_ok = 1'b0;
    response_code_ok = 1'b0;
    response_packet_ok = 1'b0;
    decoded_response_seq = host_rsp_data[63:48];
    decoded_response_code = host_rsp_data[47:32];
    decoded_response_age = host_rsp_data[31:16];
    decoded_response_integrity = host_rsp_data[15:0];
    next_applied_cmd = applied_actuator_cmd;
    clamped_cmd = applied_actuator_cmd;

    if (host_rsp_valid && host_rsp_ready_w) begin
      response_seq_match = (decoded_response_seq == outstanding_seq);
      response_integrity_ok = (response_integrity_calc == 16'h0000);
      response_age_ok = (decoded_response_age <= cfg_freshness_timeout_cycles);
      response_code_ok = (decoded_response_code >= cfg_actuator_min_code) && (decoded_response_code <= cfg_actuator_max_code);
      response_packet_ok = response_seq_match && response_integrity_ok && response_age_ok && response_code_ok;
      accept_response = response_packet_ok;
      if (response_packet_ok) begin
        if (cfg_bounds_signed_mode) begin
          if ($signed(decoded_response_code) < $signed(cfg_actuator_min_code))
            clamped_cmd = cfg_actuator_min_code;
          else if ($signed(decoded_response_code) > $signed(cfg_actuator_max_code))
            clamped_cmd = cfg_actuator_max_code;
          else
            clamped_cmd = decoded_response_code;
        end else begin
          if (decoded_response_code < cfg_actuator_min_code)
            clamped_cmd = cfg_actuator_min_code;
          else if (decoded_response_code > cfg_actuator_max_code)
            clamped_cmd = cfg_actuator_max_code;
          else
            clamped_cmd = decoded_response_code;
        end
        accepted_clamp = (clamped_cmd != decoded_response_code);
        next_applied_cmd = clamped_cmd;
      end
    end
  end

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cfg_max_velocity_mps_q <= 16'h0000;
      cfg_min_velocity_mps_q <= 16'h0000;
      cfg_enable_host_inference <= 1'b0;
      cfg_mode_bits <= 5'h00;
      cfg_response_timeout_cycles <= 16'h0000;
      cfg_freshness_timeout_cycles <= 16'h0000;
      cfg_timeout_policy_sticky <= 1'b1;
      cfg_resp_ready_always <= 1'b1;
      cfg_actuator_min_code <= 16'h0000;
      cfg_actuator_max_code <= 16'hffff;
      cfg_safe_fallback_code <= 16'h0000;
      cfg_bounds_signed_mode <= 1'b0;
      req_request_stream_vel_q <= 16'h0000;
      req_request_geom_token <= 16'h0000;
      req_request_aux_bits <= 16'h0000;
      req_request_integrity_seed <= 16'h0000;
      request_seq_current <= 16'h0000;
      latest_accepted_seq <= 16'h0000;
      outstanding_seq <= 16'h0000;
      host_tx_packet <= 64'h0000000000000000;
      host_rx_packet <= 64'h0000000000000000;
      applied_actuator_cmd <= 16'h0000;
      applied_clamped_indicator_r <= 1'b0;
      busy_r <= 1'b0;
      request_pending_r <= 1'b0;
      response_valid_r <= 1'b0;
      timeout_fault_r <= 1'b0;
      stale_fault_r <= 1'b0;
      integrity_fault_r <= 1'b0;
      fallback_active_r <= 1'b1;
      timeout_counter <= 16'h0000;
      response_age <= 16'h0000;
      request_packet_reg <= 64'h0000000000000000;
      response_packet_reg <= 64'h0000000000000000;
      request_inflight <= 1'b0;
    end else begin
      response_valid_r <= 1'b0;
      applied_clamped_indicator_r <= 1'b0;

      if (csr_write) begin
        case (csr_addr)
          16'h0000: begin
            cfg_max_velocity_mps_q <= csr_wdata[15:0];
            cfg_min_velocity_mps_q <= csr_wdata[31:16];
            cfg_enable_host_inference <= csr_wdata[32];
            cfg_mode_bits <= csr_wdata[36:33];
            if (csr_wdata[37])
              trigger_pulse <= 1'b1;
            if (csr_wdata[38])
              clear_faults_pulse <= 1'b1;
            if (csr_wdata[39])
              clear_pending_pulse <= 1'b1;
          end
          16'h0008: begin
            cfg_response_timeout_cycles <= csr_wdata[15:0];
            cfg_freshness_timeout_cycles <= csr_wdata[31:16];
            cfg_timeout_policy_sticky <= csr_wdata[32];
            cfg_resp_ready_always <= csr_wdata[33];
          end
          16'h0010: begin
            cfg_actuator_min_code <= csr_wdata[15:0];
            cfg_actuator_max_code <= csr_wdata[31:16];
            cfg_safe_fallback_code <= csr_wdata[47:32];
            cfg_bounds_signed_mode <= csr_wdata[48];
          end
          16'h0020: begin
            req_request_stream_vel_q <= csr_wdata[15:0];
            req_request_geom_token <= csr_wdata[31:16];
            req_request_aux_bits <= csr_wdata[47:32];
            req_request_integrity_seed <= csr_wdata[63:48];
          end
          16'h0040: begin
            if (csr_wdata[0]) clear_timeout_pulse <= 1'b1;
            if (csr_wdata[1]) clear_stale_pulse <= 1'b1;
            if (csr_wdata[2]) clear_integrity_pulse <= 1'b1;
            if (csr_wdata[3]) clear_fallback_pulse <= 1'b1;
            if (csr_wdata[4]) clear_request_pending_pulse <= 1'b1;
          end
          default: begin
          end
        endcase
      end

      if (csr_read) begin
        host_rx_packet <= response_packet_reg;
      end

      if (trigger_pulse && cfg_enable_host_inference && !request_inflight) begin
        request_packet_reg <= {request_seq_current, req_request_stream_vel_q, req_request_geom_token, req_request_aux_bits, req_request_integrity_seed};
        host_tx_packet <= {request_seq_current, req_request_stream_vel_q, req_request_geom_token, req_request_aux_bits, req_request_integrity_seed};
        request_inflight <= 1'b1;
        request_pending_r <= 1'b1;
        busy_r <= 1'b1;
        fallback_active_r <= 1'b0;
        timeout_counter <= 16'h0000;
        outstanding_seq <= request_seq_current;
      end

      if (host_cmd_valid_w && host_cmd_ready) begin
        request_seq_current <= request_seq_current + 16'h0001;
      end

      if (request_inflight) begin
        if (host_cmd_valid_w && host_cmd_ready) begin
          request_pending_r <= 1'b1;
        end
        if (cfg_response_timeout_cycles != 16'h0000) begin
          if (timeout_counter >= cfg_response_timeout_cycles) begin
            timeout_expired <= 1'b1;
          end else begin
            timeout_counter <= timeout_counter + 16'h0001;
          end
        end else begin
          timeout_expired <= 1'b1;
        end
      end

      if (host_rsp_valid && host_rsp_ready_w) begin
        response_packet_reg <= host_rsp_data;
        response_age <= host_rsp_data[31:16];
        if (accept_response) begin
          applied_actuator_cmd <= next_applied_cmd;
          latest_accepted_seq <= outstanding_seq;
          response_valid_r <= 1'b1;
          applied_clamped_indicator_r <= accepted_clamp;
          request_inflight <= 1'b0;
          request_pending_r <= 1'b0;
          busy_r <= 1'b0;
          fallback_active_r <= 1'b0;
          timeout_counter <= 16'h0000;
        end else begin
          integrity_fault_r <= integrity_fault_r | ~response_integrity_ok | ~response_seq_match | ~response_code_ok;
          if (~response_age_ok)
            stale_fault_r <= 1'b1;
          if (~response_integrity_ok || ~response_seq_match || ~response_code_ok)
            integrity_fault_r <= 1'b1;
          fallback_active_r <= 1'b1;
          applied_actuator_cmd <= cfg_safe_fallback_code;
          request_inflight <= 1'b0;
          request_pending_r <= 1'b0;
          busy_r <= 1'b0;
        end
      end

      if (timeout_expired && request_inflight) begin
        timeout_fault_r <= 1'b1;
        fallback_active_r <= 1'b1;
        applied_actuator_cmd <= cfg_safe_fallback_code;
        request_inflight <= 1'b0;
        request_pending_r <= 1'b0;
        busy_r <= 1'b0;
      end

      if (clear_faults_pulse) begin
        timeout_fault_r <= 1'b0;
        stale_fault_r <= 1'b0;
        integrity_fault_r <= 1'b0;
      end
      if (clear_timeout_pulse) timeout_fault_r <= 1'b0;
      if (clear_stale_pulse) stale_fault_r <= 1'b0;
      if (clear_integrity_pulse) integrity_fault_r <= 1'b0;

      if (clear_pending_pulse || clear_request_pending_pulse) begin
        request_inflight <= 1'b0;
        request_pending_r <= 1'b0;
        busy_r <= 1'b0;
      end
      if (clear_fallback_pulse) begin
        fallback_active_r <= 1'b0;
      end

      if (!cfg_enable_host_inference) begin
        fallback_active_r <= 1'b1;
      end

      if (fallback_active_r) begin
        applied_actuator_cmd <= cfg_safe_fallback_code;
      end
    end
  end

endmodule
