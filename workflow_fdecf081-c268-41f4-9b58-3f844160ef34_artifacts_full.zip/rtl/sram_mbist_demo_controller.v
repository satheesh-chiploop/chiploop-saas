module sram_mbist_demo_controller (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    bist_start,
    rd_data,
    ready,
    bist_done,
    bist_fail,
    irq
);
    input clk;
    input reset_n;
    input wr_en;
    input [7:0] wr_addr;
    input [31:0] wr_data;
    input rd_en;
    input [7:0] rd_addr;
    input bist_start;
    output [31:0] rd_data;
    output ready;
    output bist_done;
    output bist_fail;
    output irq;

    wire mem_csb;
    wire mem_web;
    wire [7:0] mem_addr;
    wire [31:0] mem_din;
    wire [31:0] mem_dout;
    wire bist_request;

    reg [2:0] control_reg;
    reg [31:0] mem_wdata_reg;
    reg [31:0] mem_rdata_reg;
    reg [7:0] mem_addr_reg;
    reg [1:0] mem_control_reg;
    reg [1:0] bist_control_reg;
    reg [7:0] bist_status_last_fail_addr_reg;
    reg irq_status_done_reg;
    reg irq_status_fail_reg;
    reg bist_done_reg;
    reg bist_fail_reg;
    reg ready_reg;
    reg busy_reg;
    reg bist_running_reg;

    reg [31:0] rd_data_r;
    reg mem_csb_r;
    reg mem_web_r;
    reg [7:0] mem_addr_r;
    reg [31:0] mem_din_r;
    reg bist_request_r;

    assign rd_data = rd_data_r;
    assign ready = ready_reg;
    assign bist_done = bist_done_reg;
    assign bist_fail = bist_fail_reg;
    assign irq = (control_reg[2] & (irq_status_done_reg | irq_status_fail_reg));
    assign mem_csb = mem_csb_r;
    assign mem_web = mem_web_r;
    assign mem_addr = mem_addr_r;
    assign mem_din = mem_din_r;
    assign bist_request = bist_request_r;

    demo_sram_32x256_wrapper u_sram (
        .clk(clk),
        .csb(mem_csb),
        .web(mem_web),
        .addr(mem_addr),
        .din(mem_din),
        .dout(mem_dout)
    );

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            control_reg <= 3'b000;
            mem_wdata_reg <= 32'h00000000;
            mem_rdata_reg <= 32'h00000000;
            mem_addr_reg <= 8'h00;
            mem_control_reg <= 2'b00;
            bist_control_reg <= 2'b00;
            bist_status_last_fail_addr_reg <= 8'h00;
            irq_status_done_reg <= 1'b0;
            irq_status_fail_reg <= 1'b0;
            bist_done_reg <= 1'b0;
            bist_fail_reg <= 1'b0;
            ready_reg <= 1'b0;
            busy_reg <= 1'b0;
            bist_running_reg <= 1'b0;
            rd_data_r <= 32'h00000000;
            mem_csb_r <= 1'b1;
            mem_web_r <= 1'b1;
            mem_addr_r <= 8'h00;
            mem_din_r <= 32'h00000000;
            bist_request_r <= 1'b0;
        end else begin
            if (control_reg[1]) begin
                control_reg <= 3'b000;
                mem_wdata_reg <= 32'h00000000;
                mem_rdata_reg <= 32'h00000000;
                mem_addr_reg <= 8'h00;
                mem_control_reg <= 2'b00;
                bist_control_reg <= 2'b00;
                bist_status_last_fail_addr_reg <= 8'h00;
                irq_status_done_reg <= 1'b0;
                irq_status_fail_reg <= 1'b0;
                bist_done_reg <= 1'b0;
                bist_fail_reg <= 1'b0;
                ready_reg <= 1'b0;
                busy_reg <= 1'b0;
                bist_running_reg <= 1'b0;
                rd_data_r <= 32'h00000000;
                mem_csb_r <= 1'b1;
                mem_web_r <= 1'b1;
                mem_addr_r <= 8'h00;
                mem_din_r <= 32'h00000000;
                bist_request_r <= 1'b0;
            end else begin
                ready_reg <= control_reg[0];
                bist_request_r <= bist_start | bist_control_reg[0];
                if (wr_en) begin
                    case (wr_addr)
                        8'h00: control_reg <= wr_data[2:0];
                        8'h08: mem_addr_reg <= wr_data[7:0];
                        8'h0C: mem_wdata_reg <= wr_data;
                        8'h14: mem_control_reg <= wr_data[1:0];
                        8'h18: bist_control_reg <= wr_data[1:0];
                        8'h20: begin
                            if (wr_data[0]) begin
                                irq_status_done_reg <= 1'b0;
                                bist_done_reg <= 1'b0;
                            end
                            if (wr_data[1]) begin
                                irq_status_fail_reg <= 1'b0;
                                bist_fail_reg <= 1'b0;
                            end
                        end
                        8'h24: begin
                            if (wr_data[0]) begin
                                irq_status_done_reg <= 1'b0;
                                bist_done_reg <= 1'b0;
                            end
                            if (wr_data[1]) begin
                                irq_status_fail_reg <= 1'b0;
                                bist_fail_reg <= 1'b0;
                            end
                        end
                        default: begin
                        end
                    endcase
                end
                if (control_reg[1]) begin
                    mem_control_reg <= 2'b00;
                    bist_control_reg <= 2'b00;
                end
                if (rd_en) begin
                    case (rd_addr)
                        8'h10: rd_data_r <= mem_rdata_reg;
                        8'h04: rd_data_r <= {28'h0000000, busy_reg, bist_fail_reg, bist_done_reg, ready_reg};
                        8'h00: rd_data_r <= {29'h00000000, control_reg};
                        8'h08: rd_data_r <= {24'h000000, mem_addr_reg};
                        8'h0C: rd_data_r <= mem_wdata_reg;
                        8'h14: rd_data_r <= {30'h00000000, mem_control_reg};
                        8'h18: rd_data_r <= {30'h00000000, bist_control_reg};
                        8'h1C: rd_data_r <= {21'h000000, bist_status_last_fail_addr_reg, bist_running_reg, bist_fail_reg, bist_done_reg};
                        8'h20: rd_data_r <= {30'h00000000, irq_status_fail_reg, irq_status_done_reg};
                        8'h24: rd_data_r <= 32'h00000000;
                        default: rd_data_r <= 32'h00000000;
                    endcase
                end
                if (mem_control_reg[0] | mem_control_reg[1] | bist_request_r) begin
                    busy_reg <= 1'b1;
                end else begin
                    busy_reg <= 1'b0;
                end
                if (bist_request_r) begin
                    bist_running_reg <= 1'b1;
                    bist_done_reg <= 1'b1;
                    bist_fail_reg <= 1'b0;
                    irq_status_done_reg <= 1'b1;
                    bist_status_last_fail_addr_reg <= 8'h00;
                    bist_running_reg <= 1'b0;
                end
                if (mem_control_reg[0]) begin
                    mem_csb_r <= 1'b0;
                    mem_web_r <= 1'b0;
                    mem_addr_r <= mem_addr_reg;
                    mem_din_r <= mem_wdata_reg;
                    mem_rdata_reg <= mem_dout;
                    mem_control_reg <= 2'b00;
                end else if (mem_control_reg[1]) begin
                    mem_csb_r <= 1'b0;
                    mem_web_r <= 1'b1;
                    mem_addr_r <= mem_addr_reg;
                    mem_din_r <= mem_wdata_reg;
                    mem_rdata_reg <= mem_dout;
                    mem_control_reg <= 2'b00;
                end else begin
                    mem_csb_r <= 1'b1;
                    mem_web_r <= 1'b1;
                    mem_addr_r <= mem_addr_reg;
                    mem_din_r <= mem_wdata_reg;
                end
            end
        end
    end
endmodule
