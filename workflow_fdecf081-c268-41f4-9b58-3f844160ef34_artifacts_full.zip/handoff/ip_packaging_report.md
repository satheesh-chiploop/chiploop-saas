# IP Packaging & Handoff Report

- Top: `sram_mbist_demo_controller`
- Package: `backend/workflows/fdecf081-c268-41f4-9b58-3f844160ef34/handoff/sram_mbist_demo_controller_ip_package`
- Zip: `backend/workflows/fdecf081-c268-41f4-9b58-3f844160ef34/handoff/sram_mbist_demo_controller_ip_package.zip`

## Bucket counts
- **rtl**: 40
- **spec**: 3
- **arch**: 1
- **microarch**: 1
- **regmap**: 2
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 11
