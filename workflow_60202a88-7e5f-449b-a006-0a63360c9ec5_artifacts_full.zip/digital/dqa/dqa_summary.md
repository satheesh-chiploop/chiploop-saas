# Digital DQA Summary
- workflow_id: `60202a88-7e5f-449b-a006-0a63360c9ec5`
- status: `failed`
- rtl files: `1`
- warning count: `0`

## Stage Status
- rtl_lint: `pass`
- cdc: `unavailable`
- reset_integrity: `unavailable`
- synthesis_readiness: `failed`

## Blocking Issues
- yosys_synthesis_errors
