module pwm_fpga_demo (
    input  clk,
    output led
);

    reg [7:0] pwm_cnt;
    reg [7:0] duty;
    reg       dir;
    reg [15:0] slow_cnt;

    always @(posedge clk) begin
        pwm_cnt <= pwm_cnt + 8'd1;
        slow_cnt <= slow_cnt + 16'd1;

        if (slow_cnt == 16'd0) begin
            if (dir) begin
                if (duty == 8'hFF) begin
                    dir <= 1'b0;
                    duty <= duty - 8'd1;
                end else begin
                    duty <= duty + 8'd1;
                end
            end else begin
                if (duty == 8'h00) begin
                    dir <= 1'b1;
                    duty <= duty + 8'd1;
                end else begin
                    duty <= duty - 8'd1;
                end
            end
        end
    end

    assign led = (pwm_cnt < duty);

endmodule
