module pwm_controller (
    clk,
    reset_n,
    enable,
    duty_cycle,
    period,
    pwm_out,
    counter_value
);

input clk;
input reset_n;
input enable;
input [7:0] duty_cycle;
input [7:0] period;
output pwm_out;
output [7:0] counter_value;
reg [7:0] counter_reg;
wire pwm_out_w;

assign counter_value = counter_reg;
assign pwm_out = pwm_out_w;
assign pwm_out_w = (counter_reg < duty_cycle) ? 1'b1 : 1'b0;

always @(posedge clk) begin
    if (!reset_n) begin
        counter_reg <= 8'b00000000;
    end else if (enable) begin
        if (counter_reg >= period) begin
            counter_reg <= 8'b00000000;
        end else begin
            counter_reg <= counter_reg + 8'b00000001;
        end
    end
end

endmodule
