module pwm_controller_assertions (
  input logic clk,
  input logic [7:0] counter_value,
  input logic [7:0] duty_cycle,
  input logic enable,
  input logic [7:0] period,
  input logic pwm_out,
  input logic reset_n
);

  property p_req_001;
    @(posedge clk) disable iff (!reset_n)
      1'b1 |-> ($bits(duty_cycle) == 8 && $bits(period) == 8);
  endproperty

  // REQ-001
  a_req_001: assert property (p_req_001);
  c_req_001: cover property (@(posedge clk) disable iff (!reset_n) 1'b1);

  property p_req_002;
    @(posedge clk) disable iff (!reset_n)
      enable |-> $stable(counter_value) or (counter_value == $past(counter_value) + 8'd1) or (counter_value == 8'd0);
  endproperty

  // REQ-002
  a_req_002: assert property (p_req_002);
  c_req_002: cover property (@(posedge clk) disable iff (!reset_n) enable);

  property p_req_008;
    @(posedge clk)
      !reset_n |-> (counter_value == 8'b00000000);
  endproperty

  // REQ-008
  a_req_008: assert property (p_req_008);
  c_req_008: cover property (@(posedge clk) !reset_n);

  property p_req_009;
    @(posedge clk) disable iff (!reset_n)
      (!enable) |-> $stable(counter_value);
  endproperty

  // REQ-009
  a_req_009: assert property (p_req_009);
  c_req_009: cover property (@(posedge clk) disable iff (!reset_n) !enable);

  property p_req_010;
    @(posedge clk) disable iff (!reset_n)
      (enable && (counter_value < period)) |-> (counter_value == $past(counter_value) + 8'd1);
  endproperty

  // REQ-010
  a_req_010: assert property (p_req_010);
  c_req_010: cover property (@(posedge clk) disable iff (!reset_n) (enable && (counter_value < period)));

  property p_req_011;
    @(posedge clk) disable iff (!reset_n)
      (enable && (counter_value >= period)) |-> (counter_value == 8'd0);
  endproperty

  // REQ-011
  a_req_011: assert property (p_req_011);
  c_req_011: cover property (@(posedge clk) disable iff (!reset_n) (enable && (counter_value >= period)));

  property p_req_012;
    @(posedge clk) disable iff (!reset_n)
      1'b1 |-> (pwm_out == (counter_value < duty_cycle));
  endproperty

  // REQ-012
  a_req_012: assert property (p_req_012);
  c_req_012: cover property (@(posedge clk) disable iff (!reset_n) 1'b1);

  property p_req_019;
    @(posedge clk)
      !reset_n |-> (counter_value == 8'd0);
  endproperty

  // REQ-019
  a_req_019: assert property (p_req_019);
  c_req_019: cover property (@(posedge clk) !reset_n);

endmodule