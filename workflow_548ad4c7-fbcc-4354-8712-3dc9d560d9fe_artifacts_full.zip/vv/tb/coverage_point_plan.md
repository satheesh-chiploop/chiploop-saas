# Coverage Point Plan

- Source: generated_from_spec
- Top module: `pwm_controller`

## Output Coverpoints
- Cover `pwm_out` zero and non-zero/value-transition bins.
- Cover `counter_value` zero and non-zero/value-transition bins.

## Input Coverpoints
- Cover `clk` zero and non-zero/input-stimulus bins.
- Cover `reset_n` zero and non-zero/input-stimulus bins.
- Cover `enable` zero and non-zero/input-stimulus bins.
- Cover `duty_cycle` zero and non-zero/input-stimulus bins.
- Cover `period` zero and non-zero/input-stimulus bins.

## Feature Coverage
- `reset_clears_counter_and_pwm_matches_combinational_compare`: reset_clears_counter_and_pwm_matches_combinational_compare.stimulus_applied, reset_clears_counter_and_pwm_matches_combinational_compare.expected_observed (executable)
- `counter_increments_when_enabled_before_period`: counter_increments_when_enabled_before_period.stimulus_applied, counter_increments_when_enabled_before_period.expected_observed (executable)
- `counter_wraps_to_zero_at_period`: counter_wraps_to_zero_at_period.stimulus_applied, counter_wraps_to_zero_at_period.expected_observed (executable)
- `disable_holds_counter_and_pwm_reflects_held_value`: disable_holds_counter_and_pwm_reflects_held_value.stimulus_applied, disable_holds_counter_and_pwm_reflects_held_value.expected_observed (executable)
- `pwm_low_when_counter_not_less_than_duty_cycle`: pwm_low_when_counter_not_less_than_duty_cycle.stimulus_applied, pwm_low_when_counter_not_less_than_duty_cycle.expected_observed (executable)

## Cross Coverage Candidates
- Cross reset release with first observed output activity.
- Cross primary control inputs with output response bins when both are present.

## Closure Guidance
- Review uncovered bins before accepting closure.
- Add directed tests for missed bins, or mark exclusions with reviewer rationale.
