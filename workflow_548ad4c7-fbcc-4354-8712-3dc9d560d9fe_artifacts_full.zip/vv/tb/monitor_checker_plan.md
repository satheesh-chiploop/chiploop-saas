# Monitor And Checker Plan

- Source: generated_from_spec
- Top module: `pwm_controller`
- Clock observations: `clk`
- Reset observations: `reset_n`

## Monitors
- Clock/reset monitor: observes reset assertion/deassertion and first active clock edges.
- Input stimulus monitor: records driven values on declared non-clock/reset inputs.
- Output response monitor: samples declared outputs after reset release and after stimulus changes.
- Coverage monitor: calls `CoverageModel.sample()` at transaction/checkpoint boundaries.

## Observed Inputs
- `enable`
- `duty_cycle`
- `period`

## Observed Outputs
- `pwm_out`
- `counter_value`

## Checkers
- Reset known-value checker: outputs must not remain unknown after reset release and settle.
- Width/value checker: sampled signals are interpreted using spec-declared widths.
- Scenario checker: directed tests should encode expected responses from the verification plan.
- Scoreboard hook: `Scoreboard` is loaded when `scoreboard.py` is present and can compare expected versus observed transactions.
- SVA hook: generated SVA/bind files are included through `verification_sources.mk` when available.

## Coverage Coupling
- Functional output points: `pwm_out`, `counter_value`
- Functional input points: `clk`, `reset_n`, `enable`, `duty_cycle`, `period`

## Feature Checkers
- `reset_clears_counter_and_pwm_matches_combinational_compare`: monitors=['counter_value', 'pwm_out', 'duty_cycle']; status=executable; reason=explicit expected behavior
- `counter_increments_when_enabled_before_period`: monitors=['counter_value', 'pwm_out', 'enable', 'period']; status=executable; reason=explicit expected behavior
- `counter_wraps_to_zero_at_period`: monitors=['counter_value', 'pwm_out', 'enable', 'period']; status=executable; reason=explicit expected behavior
- `disable_holds_counter_and_pwm_reflects_held_value`: monitors=['counter_value', 'pwm_out', 'enable', 'duty_cycle']; status=executable; reason=explicit expected behavior
- `pwm_low_when_counter_not_less_than_duty_cycle`: monitors=['pwm_out', 'counter_value']; status=executable; reason=explicit expected behavior

## Review Checklist
- Confirm each important requirement has a monitor point.
- Confirm each monitor feeds a checker, scoreboard, assertion, or coverage point.
- Add directed tests or custom scoreboard logic for behavior that cannot be inferred from ports alone.
