/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/bd966a80-8d10-4060-8c88-0ee9332b447a/7d9e923e-75f2-4222-9a7a-5188043496a2/digital/system/imported_rtl/temp_sensor_adc_model.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/bd966a80-8d10-4060-8c88-0ee9332b447a/7d9e923e-75f2-4222-9a7a-5188043496a2/digital/system/imported_rtl/temp_monitor_digital.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/bd966a80-8d10-4060-8c88-0ee9332b447a/7d9e923e-75f2-4222-9a7a-5188043496a2/digital/system/imported_rtl/temp_monitor_soc_phys.sv
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/bd966a80-8d10-4060-8c88-0ee9332b447a/7d9e923e-75f2-4222-9a7a-5188043496a2/digital/system/imported_rtl/temp_monitor_soc_sim.sv
