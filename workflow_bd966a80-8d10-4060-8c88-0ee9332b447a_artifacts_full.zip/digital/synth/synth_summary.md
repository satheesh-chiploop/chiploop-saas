# Digital Synthesis Summary

- **Workflow**: bd966a80-8d10-4060-8c88-0ee9332b447a
- **Status**: `failed` (rc=2)
- **Top module**: `temp_monitor_soc_phys`
- **Clock**: `clk` @ **10.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `not found`
- netlist candidates: 1 found
