# Digital Synthesis Summary

- **Workflow**: 34d798ba-7cfc-41c6-9623-f5ebf6a08660
- **Status**: `ok` (rc=0)
- **Top module**: `pwm_controller_mmio`
- **Clock**: `clk` @ **10.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/34d798ba-7cfc-41c6-9623-f5ebf6a08660/e504684d-f1b3-4877-9e1d-2890c5e0d3b0/digital/arch2synthesis/digital/synth/runs/digital_34d798ba-7cfc-41c6-9623-f5ebf6a08660/final/metrics.json`
- netlist candidates: 1 found
