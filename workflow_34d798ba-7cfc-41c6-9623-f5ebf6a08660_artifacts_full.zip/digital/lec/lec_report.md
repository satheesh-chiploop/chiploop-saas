# Logic Equivalence Check

- Status: `inconclusive`
- Tool: `yosys`
- Top module: `pwm_controller_mmio`
- RTL files: `1`
- Synth netlist: `pwm_controller_mmio_synth.v`
- Liberty files discovered: `1`
- Standard-cell Verilog models loaded: `1`
- Standard-cell model strategy: `pdk_stdcell_verilog`
- Missing standard-cell models: `0`
- Unproven points: `0`
- Return code: `1`
- Failure reason: `yosys_inconclusive_see_lec_log`

If this is inconclusive, inspect `digital/lec/logs/yosys_lec.log` and `digital/lec/lec_summary.json` for unsupported cells, black boxes, or reset/initial-state assumptions.
