# Scan ATPG Coverage

- Status: `wrong_tool_detected`
- Tool: `fault`
- Input netlist: `scan_stitched_netlist.v`
- Pattern count: `not reported`
- Stuck-at coverage: `not reported`

This agent is adapter-ready for open-source ATPG tools. Set `CHIPLOOP_ATPG_COMMAND` to the validated command for the installed toolchain to produce real pattern and coverage reports.
If status is `wrong_tool_detected`, the executable name matched but the binary is not a digital ATPG tool.
