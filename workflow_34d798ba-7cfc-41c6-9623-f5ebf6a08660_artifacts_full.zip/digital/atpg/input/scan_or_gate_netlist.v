module pwm_controller_mmio (clk,
    pwm_out,
    rd_en,
    reset_n,
    scan_en,
    wr_en,
    counter_value,
    rd_addr,
    rd_data,
    scan_in,
    scan_out,
    wr_addr,
    wr_data);
 input clk;
 output pwm_out;
 input rd_en;
 input reset_n;
 input scan_en;
 input wr_en;
 output [7:0] counter_value;
 input [7:0] rd_addr;
 output [7:0] rd_data;
 input [3:0] scan_in;
 output [3:0] scan_out;
 input [7:0] wr_addr;
 input [7:0] wr_data;

 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire _086_;
 wire _087_;
 wire _088_;
 wire _089_;
 wire _090_;
 wire _091_;
 wire _092_;
 wire _093_;
 wire _094_;
 wire _095_;
 wire _096_;
 wire _097_;
 wire _098_;
 wire _099_;
 wire _100_;
 wire _101_;
 wire _102_;
 wire _103_;
 wire _104_;
 wire _105_;
 wire control_reg;
 wire \duty_cycle_reg[0] ;
 wire \duty_cycle_reg[1] ;
 wire \duty_cycle_reg[2] ;
 wire \duty_cycle_reg[3] ;
 wire \duty_cycle_reg[4] ;
 wire \duty_cycle_reg[5] ;
 wire \duty_cycle_reg[6] ;
 wire \duty_cycle_reg[7] ;
 wire \period_reg[0] ;
 wire \period_reg[1] ;
 wire \period_reg[2] ;
 wire \period_reg[3] ;
 wire \period_reg[4] ;
 wire \period_reg[5] ;
 wire \period_reg[6] ;
 wire \period_reg[7] ;

 sky130_fd_sc_hd__inv_2 _106_ (.A(counter_value[6]),
    .Y(_083_));
 sky130_fd_sc_hd__inv_2 _107_ (.A(\period_reg[7] ),
    .Y(_084_));
 sky130_fd_sc_hd__inv_2 _108_ (.A(wr_addr[3]),
    .Y(_085_));
 sky130_fd_sc_hd__inv_2 _109_ (.A(counter_value[7]),
    .Y(_086_));
 sky130_fd_sc_hd__inv_2 _110_ (.A(counter_value[5]),
    .Y(_087_));
 sky130_fd_sc_hd__inv_2 _111_ (.A(counter_value[4]),
    .Y(_088_));
 sky130_fd_sc_hd__inv_2 _112_ (.A(counter_value[3]),
    .Y(_089_));
 sky130_fd_sc_hd__inv_2 _113_ (.A(counter_value[2]),
    .Y(_090_));
 sky130_fd_sc_hd__inv_2 _114_ (.A(counter_value[1]),
    .Y(_091_));
 sky130_fd_sc_hd__inv_2 _115_ (.A(counter_value[0]),
    .Y(_092_));
 sky130_fd_sc_hd__or4_2 _116_ (.A(rd_addr[5]),
    .B(rd_addr[4]),
    .C(rd_addr[7]),
    .D(rd_addr[6]),
    .X(_093_));
 sky130_fd_sc_hd__nor4b_2 _117_ (.A(rd_addr[1]),
    .B(_093_),
    .C(rd_addr[0]),
    .D_N(rd_addr[3]),
    .Y(_094_));
 sky130_fd_sc_hd__and2b_2 _118_ (.A_N(rd_addr[2]),
    .B(_094_),
    .X(_095_));
 sky130_fd_sc_hd__and2_2 _119_ (.A(rd_addr[2]),
    .B(_094_),
    .X(_096_));
 sky130_fd_sc_hd__and3_2 _120_ (.A(counter_value[3]),
    .B(rd_addr[2]),
    .C(_094_),
    .X(_097_));
 sky130_fd_sc_hd__nor4_2 _121_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .C(rd_addr[3]),
    .D(_093_),
    .Y(_026_));
 sky130_fd_sc_hd__and2_2 _122_ (.A(rd_addr[2]),
    .B(_026_),
    .X(_027_));
 sky130_fd_sc_hd__a221o_2 _123_ (.A1(\period_reg[3] ),
    .A2(_095_),
    .B1(_027_),
    .B2(\duty_cycle_reg[3] ),
    .C1(_097_),
    .X(_101_));
 sky130_fd_sc_hd__a22o_2 _124_ (.A1(\period_reg[4] ),
    .A2(_095_),
    .B1(_096_),
    .B2(counter_value[4]),
    .X(_028_));
 sky130_fd_sc_hd__a21o_2 _125_ (.A1(\duty_cycle_reg[4] ),
    .A2(_027_),
    .B1(_028_),
    .X(_102_));
 sky130_fd_sc_hd__a22o_2 _126_ (.A1(\period_reg[5] ),
    .A2(_095_),
    .B1(_096_),
    .B2(counter_value[5]),
    .X(_029_));
 sky130_fd_sc_hd__a21o_2 _127_ (.A1(\duty_cycle_reg[5] ),
    .A2(_027_),
    .B1(_029_),
    .X(_103_));
 sky130_fd_sc_hd__a22o_2 _128_ (.A1(counter_value[6]),
    .A2(_096_),
    .B1(_027_),
    .B2(\duty_cycle_reg[6] ),
    .X(_030_));
 sky130_fd_sc_hd__a21o_2 _129_ (.A1(\period_reg[6] ),
    .A2(_095_),
    .B1(_030_),
    .X(_104_));
 sky130_fd_sc_hd__a22o_2 _130_ (.A1(\period_reg[7] ),
    .A2(_095_),
    .B1(_096_),
    .B2(counter_value[7]),
    .X(_031_));
 sky130_fd_sc_hd__a21o_2 _131_ (.A1(\duty_cycle_reg[7] ),
    .A2(_027_),
    .B1(_031_),
    .X(_105_));
 sky130_fd_sc_hd__and2_2 _132_ (.A(\duty_cycle_reg[7] ),
    .B(_086_),
    .X(_032_));
 sky130_fd_sc_hd__o22a_2 _133_ (.A1(_083_),
    .A2(\duty_cycle_reg[6] ),
    .B1(\duty_cycle_reg[7] ),
    .B2(_086_),
    .X(_033_));
 sky130_fd_sc_hd__or2_2 _134_ (.A(\duty_cycle_reg[3] ),
    .B(_089_),
    .X(_034_));
 sky130_fd_sc_hd__o211a_2 _135_ (.A1(\duty_cycle_reg[1] ),
    .A2(_091_),
    .B1(\duty_cycle_reg[0] ),
    .C1(_092_),
    .X(_035_));
 sky130_fd_sc_hd__a22o_2 _136_ (.A1(\duty_cycle_reg[2] ),
    .A2(_090_),
    .B1(\duty_cycle_reg[1] ),
    .B2(_091_),
    .X(_036_));
 sky130_fd_sc_hd__o221a_2 _137_ (.A1(\duty_cycle_reg[2] ),
    .A2(_090_),
    .B1(_035_),
    .B2(_036_),
    .C1(_034_),
    .X(_037_));
 sky130_fd_sc_hd__a22o_2 _138_ (.A1(\duty_cycle_reg[4] ),
    .A2(_088_),
    .B1(_089_),
    .B2(\duty_cycle_reg[3] ),
    .X(_038_));
 sky130_fd_sc_hd__or2_2 _139_ (.A(\duty_cycle_reg[5] ),
    .B(_087_),
    .X(_039_));
 sky130_fd_sc_hd__o221a_2 _140_ (.A1(\duty_cycle_reg[4] ),
    .A2(_088_),
    .B1(_037_),
    .B2(_038_),
    .C1(_039_),
    .X(_040_));
 sky130_fd_sc_hd__a22o_2 _141_ (.A1(_083_),
    .A2(\duty_cycle_reg[6] ),
    .B1(_087_),
    .B2(\duty_cycle_reg[5] ),
    .X(_041_));
 sky130_fd_sc_hd__o21a_2 _142_ (.A1(_040_),
    .A2(_041_),
    .B1(_033_),
    .X(_042_));
 sky130_fd_sc_hd__or4_2 _143_ (.A(\period_reg[7] ),
    .B(\period_reg[1] ),
    .C(\period_reg[0] ),
    .D(\period_reg[2] ),
    .X(_043_));
 sky130_fd_sc_hd__or4_2 _144_ (.A(\period_reg[3] ),
    .B(\period_reg[4] ),
    .C(\period_reg[5] ),
    .D(\period_reg[6] ),
    .X(_044_));
 sky130_fd_sc_hd__nor2_2 _145_ (.A(_043_),
    .B(_044_),
    .Y(_045_));
 sky130_fd_sc_hd__inv_2 _146_ (.A(_045_),
    .Y(_046_));
 sky130_fd_sc_hd__o211a_2 _147_ (.A1(_032_),
    .A2(_042_),
    .B1(_046_),
    .C1(control_reg),
    .X(_000_));
 sky130_fd_sc_hd__mux2_1 _148_ (.A0(control_reg),
    .A1(\duty_cycle_reg[0] ),
    .S(rd_addr[2]),
    .X(_047_));
 sky130_fd_sc_hd__and2_2 _149_ (.A(_026_),
    .B(_047_),
    .X(_048_));
 sky130_fd_sc_hd__a221o_2 _150_ (.A1(\period_reg[0] ),
    .A2(_095_),
    .B1(_096_),
    .B2(counter_value[0]),
    .C1(_048_),
    .X(_098_));
 sky130_fd_sc_hd__and3_2 _151_ (.A(counter_value[1]),
    .B(rd_addr[2]),
    .C(_094_),
    .X(_049_));
 sky130_fd_sc_hd__a221o_2 _152_ (.A1(\period_reg[1] ),
    .A2(_095_),
    .B1(_027_),
    .B2(\duty_cycle_reg[1] ),
    .C1(_049_),
    .X(_099_));
 sky130_fd_sc_hd__a22o_2 _153_ (.A1(\period_reg[2] ),
    .A2(_095_),
    .B1(_027_),
    .B2(\duty_cycle_reg[2] ),
    .X(_050_));
 sky130_fd_sc_hd__a21o_2 _154_ (.A1(counter_value[2]),
    .A2(_096_),
    .B1(_050_),
    .X(_100_));
 sky130_fd_sc_hd__a2bb2o_2 _155_ (.A1_N(_083_),
    .A2_N(\period_reg[6] ),
    .B1(_084_),
    .B2(counter_value[7]),
    .X(_051_));
 sky130_fd_sc_hd__o22a_2 _156_ (.A1(\period_reg[5] ),
    .A2(_087_),
    .B1(_088_),
    .B2(\period_reg[4] ),
    .X(_052_));
 sky130_fd_sc_hd__o22a_2 _157_ (.A1(\period_reg[3] ),
    .A2(_089_),
    .B1(_090_),
    .B2(\period_reg[2] ),
    .X(_053_));
 sky130_fd_sc_hd__nand2b_2 _158_ (.A_N(\period_reg[1] ),
    .B(counter_value[1]),
    .Y(_054_));
 sky130_fd_sc_hd__and2b_2 _159_ (.A_N(counter_value[2]),
    .B(\period_reg[2] ),
    .X(_055_));
 sky130_fd_sc_hd__and2b_2 _160_ (.A_N(counter_value[1]),
    .B(\period_reg[1] ),
    .X(_056_));
 sky130_fd_sc_hd__a311o_2 _161_ (.A1(\period_reg[0] ),
    .A2(_092_),
    .A3(_054_),
    .B1(_055_),
    .C1(_056_),
    .X(_057_));
 sky130_fd_sc_hd__a22o_2 _162_ (.A1(\period_reg[4] ),
    .A2(_088_),
    .B1(_089_),
    .B2(\period_reg[3] ),
    .X(_058_));
 sky130_fd_sc_hd__a21o_2 _163_ (.A1(_053_),
    .A2(_057_),
    .B1(_058_),
    .X(_059_));
 sky130_fd_sc_hd__a22o_2 _164_ (.A1(_083_),
    .A2(\period_reg[6] ),
    .B1(_087_),
    .B2(\period_reg[5] ),
    .X(_060_));
 sky130_fd_sc_hd__a21oi_2 _165_ (.A1(_052_),
    .A2(_059_),
    .B1(_060_),
    .Y(_061_));
 sky130_fd_sc_hd__or2_2 _166_ (.A(control_reg),
    .B(_045_),
    .X(_062_));
 sky130_fd_sc_hd__o221a_2 _167_ (.A1(_084_),
    .A2(counter_value[7]),
    .B1(_051_),
    .B2(_061_),
    .C1(_062_),
    .X(_063_));
 sky130_fd_sc_hd__xnor2_2 _168_ (.A(counter_value[0]),
    .B(_062_),
    .Y(_064_));
 sky130_fd_sc_hd__nor2_2 _169_ (.A(_063_),
    .B(_064_),
    .Y(_001_));
 sky130_fd_sc_hd__a21oi_2 _170_ (.A1(counter_value[0]),
    .A2(_062_),
    .B1(counter_value[1]),
    .Y(_065_));
 sky130_fd_sc_hd__and3_2 _171_ (.A(counter_value[1]),
    .B(counter_value[0]),
    .C(_062_),
    .X(_066_));
 sky130_fd_sc_hd__nor3_2 _172_ (.A(_063_),
    .B(_065_),
    .C(_066_),
    .Y(_002_));
 sky130_fd_sc_hd__xnor2_2 _173_ (.A(counter_value[2]),
    .B(_066_),
    .Y(_067_));
 sky130_fd_sc_hd__nor2_2 _174_ (.A(_063_),
    .B(_067_),
    .Y(_003_));
 sky130_fd_sc_hd__and4_2 _175_ (.A(counter_value[3]),
    .B(counter_value[2]),
    .C(counter_value[1]),
    .D(counter_value[0]),
    .X(_068_));
 sky130_fd_sc_hd__nand2_2 _176_ (.A(_062_),
    .B(_068_),
    .Y(_069_));
 sky130_fd_sc_hd__a21o_2 _177_ (.A1(counter_value[2]),
    .A2(_066_),
    .B1(counter_value[3]),
    .X(_070_));
 sky130_fd_sc_hd__and3b_2 _178_ (.A_N(_063_),
    .B(_069_),
    .C(_070_),
    .X(_004_));
 sky130_fd_sc_hd__xnor2_2 _179_ (.A(_088_),
    .B(_069_),
    .Y(_071_));
 sky130_fd_sc_hd__nor2_2 _180_ (.A(_063_),
    .B(_071_),
    .Y(_005_));
 sky130_fd_sc_hd__o21a_2 _181_ (.A1(_088_),
    .A2(_069_),
    .B1(_087_),
    .X(_072_));
 sky130_fd_sc_hd__and4_2 _182_ (.A(counter_value[5]),
    .B(counter_value[4]),
    .C(_062_),
    .D(_068_),
    .X(_073_));
 sky130_fd_sc_hd__nor3_2 _183_ (.A(_063_),
    .B(_072_),
    .C(_073_),
    .Y(_006_));
 sky130_fd_sc_hd__xnor2_2 _184_ (.A(counter_value[6]),
    .B(_073_),
    .Y(_074_));
 sky130_fd_sc_hd__nor2_2 _185_ (.A(_063_),
    .B(_074_),
    .Y(_007_));
 sky130_fd_sc_hd__a21oi_2 _186_ (.A1(counter_value[6]),
    .A2(_073_),
    .B1(counter_value[7]),
    .Y(_075_));
 sky130_fd_sc_hd__nor2_2 _187_ (.A(_063_),
    .B(_075_),
    .Y(_008_));
 sky130_fd_sc_hd__or3_2 _188_ (.A(wr_addr[5]),
    .B(wr_addr[4]),
    .C(wr_addr[7]),
    .X(_076_));
 sky130_fd_sc_hd__or3b_2 _189_ (.A(_076_),
    .B(wr_addr[6]),
    .C_N(wr_en),
    .X(_077_));
 sky130_fd_sc_hd__or2_2 _190_ (.A(wr_addr[3]),
    .B(_077_),
    .X(_078_));
 sky130_fd_sc_hd__or3_2 _191_ (.A(wr_addr[1]),
    .B(wr_addr[0]),
    .C(wr_addr[2]),
    .X(_079_));
 sky130_fd_sc_hd__or2_2 _192_ (.A(_078_),
    .B(_079_),
    .X(_080_));
 sky130_fd_sc_hd__mux2_1 _193_ (.A0(wr_data[0]),
    .A1(control_reg),
    .S(_080_),
    .X(_009_));
 sky130_fd_sc_hd__or4b_2 _194_ (.A(wr_addr[1]),
    .B(_078_),
    .C(wr_addr[0]),
    .D_N(wr_addr[2]),
    .X(_081_));
 sky130_fd_sc_hd__mux2_1 _195_ (.A0(wr_data[0]),
    .A1(\duty_cycle_reg[0] ),
    .S(_081_),
    .X(_010_));
 sky130_fd_sc_hd__mux2_1 _196_ (.A0(wr_data[1]),
    .A1(\duty_cycle_reg[1] ),
    .S(_081_),
    .X(_011_));
 sky130_fd_sc_hd__mux2_1 _197_ (.A0(wr_data[2]),
    .A1(\duty_cycle_reg[2] ),
    .S(_081_),
    .X(_012_));
 sky130_fd_sc_hd__mux2_1 _198_ (.A0(wr_data[3]),
    .A1(\duty_cycle_reg[3] ),
    .S(_081_),
    .X(_013_));
 sky130_fd_sc_hd__mux2_1 _199_ (.A0(wr_data[4]),
    .A1(\duty_cycle_reg[4] ),
    .S(_081_),
    .X(_014_));
 sky130_fd_sc_hd__mux2_1 _200_ (.A0(wr_data[5]),
    .A1(\duty_cycle_reg[5] ),
    .S(_081_),
    .X(_015_));
 sky130_fd_sc_hd__mux2_1 _201_ (.A0(wr_data[6]),
    .A1(\duty_cycle_reg[6] ),
    .S(_081_),
    .X(_016_));
 sky130_fd_sc_hd__mux2_1 _202_ (.A0(wr_data[7]),
    .A1(\duty_cycle_reg[7] ),
    .S(_081_),
    .X(_017_));
 sky130_fd_sc_hd__or3_2 _203_ (.A(_085_),
    .B(_077_),
    .C(_079_),
    .X(_082_));
 sky130_fd_sc_hd__mux2_1 _204_ (.A0(wr_data[0]),
    .A1(\period_reg[0] ),
    .S(_082_),
    .X(_018_));
 sky130_fd_sc_hd__mux2_1 _205_ (.A0(wr_data[1]),
    .A1(\period_reg[1] ),
    .S(_082_),
    .X(_019_));
 sky130_fd_sc_hd__mux2_1 _206_ (.A0(wr_data[2]),
    .A1(\period_reg[2] ),
    .S(_082_),
    .X(_020_));
 sky130_fd_sc_hd__mux2_1 _207_ (.A0(wr_data[3]),
    .A1(\period_reg[3] ),
    .S(_082_),
    .X(_021_));
 sky130_fd_sc_hd__mux2_1 _208_ (.A0(wr_data[4]),
    .A1(\period_reg[4] ),
    .S(_082_),
    .X(_022_));
 sky130_fd_sc_hd__mux2_1 _209_ (.A0(wr_data[5]),
    .A1(\period_reg[5] ),
    .S(_082_),
    .X(_023_));
 sky130_fd_sc_hd__mux2_1 _210_ (.A0(wr_data[6]),
    .A1(\period_reg[6] ),
    .S(_082_),
    .X(_024_));
 sky130_fd_sc_hd__mux2_1 _211_ (.A0(wr_data[7]),
    .A1(\period_reg[7] ),
    .S(_082_),
    .X(_025_));
 sky130_fd_sc_hd__sdfrtp_2 _212_ (.CLK(clk),
    .D(_001_),
    .RESET_B(reset_n),
    .SCD(scan_in[0]),
    .SCE(scan_en),
    .Q(counter_value[0]));
 sky130_fd_sc_hd__sdfrtp_2 _213_ (.CLK(clk),
    .D(_002_),
    .RESET_B(reset_n),
    .SCD(scan_in[1]),
    .SCE(scan_en),
    .Q(counter_value[1]));
 sky130_fd_sc_hd__sdfrtp_2 _214_ (.CLK(clk),
    .D(_003_),
    .RESET_B(reset_n),
    .SCD(scan_in[2]),
    .SCE(scan_en),
    .Q(counter_value[2]));
 sky130_fd_sc_hd__sdfrtp_2 _215_ (.CLK(clk),
    .D(_004_),
    .RESET_B(reset_n),
    .SCD(scan_in[3]),
    .SCE(scan_en),
    .Q(counter_value[3]));
 sky130_fd_sc_hd__sdfrtp_2 _216_ (.CLK(clk),
    .D(_005_),
    .RESET_B(reset_n),
    .SCD(counter_value[0]),
    .SCE(scan_en),
    .Q(counter_value[4]));
 sky130_fd_sc_hd__sdfrtp_2 _217_ (.CLK(clk),
    .D(_006_),
    .RESET_B(reset_n),
    .SCD(counter_value[1]),
    .SCE(scan_en),
    .Q(counter_value[5]));
 sky130_fd_sc_hd__sdfrtp_2 _218_ (.CLK(clk),
    .D(_007_),
    .RESET_B(reset_n),
    .SCD(counter_value[2]),
    .SCE(scan_en),
    .Q(counter_value[6]));
 sky130_fd_sc_hd__sdfrtp_2 _219_ (.CLK(clk),
    .D(_008_),
    .RESET_B(reset_n),
    .SCD(counter_value[3]),
    .SCE(scan_en),
    .Q(counter_value[7]));
 sky130_fd_sc_hd__sdfrtp_2 _220_ (.CLK(clk),
    .D(_009_),
    .RESET_B(reset_n),
    .SCD(counter_value[4]),
    .SCE(scan_en),
    .Q(control_reg));
 sky130_fd_sc_hd__sdfrtp_2 _221_ (.CLK(clk),
    .D(_010_),
    .RESET_B(reset_n),
    .SCD(counter_value[5]),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _222_ (.CLK(clk),
    .D(_011_),
    .RESET_B(reset_n),
    .SCD(counter_value[6]),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _223_ (.CLK(clk),
    .D(_012_),
    .RESET_B(reset_n),
    .SCD(counter_value[7]),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _224_ (.CLK(clk),
    .D(_013_),
    .RESET_B(reset_n),
    .SCD(control_reg),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _225_ (.CLK(clk),
    .D(_014_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[0] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _226_ (.CLK(clk),
    .D(_015_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[1] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _227_ (.CLK(clk),
    .D(_016_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[2] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _228_ (.CLK(clk),
    .D(_017_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[3] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _229_ (.CLK(clk),
    .D(_018_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[4] ),
    .SCE(scan_en),
    .Q(\period_reg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _230_ (.CLK(clk),
    .D(_019_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[5] ),
    .SCE(scan_en),
    .Q(\period_reg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _231_ (.CLK(clk),
    .D(_020_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[6] ),
    .SCE(scan_en),
    .Q(\period_reg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _232_ (.CLK(clk),
    .D(_021_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[7] ),
    .SCE(scan_en),
    .Q(\period_reg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _233_ (.CLK(clk),
    .D(_022_),
    .RESET_B(reset_n),
    .SCD(\period_reg[0] ),
    .SCE(scan_en),
    .Q(\period_reg[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _234_ (.CLK(clk),
    .D(_023_),
    .RESET_B(reset_n),
    .SCD(\period_reg[1] ),
    .SCE(scan_en),
    .Q(\period_reg[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _235_ (.CLK(clk),
    .D(_024_),
    .RESET_B(reset_n),
    .SCD(\period_reg[2] ),
    .SCE(scan_en),
    .Q(\period_reg[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _236_ (.CLK(clk),
    .D(_025_),
    .RESET_B(reset_n),
    .SCD(\period_reg[3] ),
    .SCE(scan_en),
    .Q(\period_reg[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _237_ (.CLK(clk),
    .D(_098_),
    .RESET_B(reset_n),
    .SCD(\period_reg[4] ),
    .SCE(scan_en),
    .Q(rd_data[0]));
 sky130_fd_sc_hd__sdfrtp_2 _238_ (.CLK(clk),
    .D(_099_),
    .RESET_B(reset_n),
    .SCD(\period_reg[5] ),
    .SCE(scan_en),
    .Q(rd_data[1]));
 sky130_fd_sc_hd__sdfrtp_2 _239_ (.CLK(clk),
    .D(_100_),
    .RESET_B(reset_n),
    .SCD(\period_reg[6] ),
    .SCE(scan_en),
    .Q(rd_data[2]));
 sky130_fd_sc_hd__sdfrtp_2 _240_ (.CLK(clk),
    .D(_101_),
    .RESET_B(reset_n),
    .SCD(\period_reg[7] ),
    .SCE(scan_en),
    .Q(rd_data[3]));
 sky130_fd_sc_hd__sdfrtp_2 _241_ (.CLK(clk),
    .D(_102_),
    .RESET_B(reset_n),
    .SCD(rd_data[0]),
    .SCE(scan_en),
    .Q(rd_data[4]));
 sky130_fd_sc_hd__sdfrtp_2 _242_ (.CLK(clk),
    .D(_103_),
    .RESET_B(reset_n),
    .SCD(rd_data[1]),
    .SCE(scan_en),
    .Q(rd_data[5]));
 sky130_fd_sc_hd__sdfrtp_2 _243_ (.CLK(clk),
    .D(_104_),
    .RESET_B(reset_n),
    .SCD(rd_data[2]),
    .SCE(scan_en),
    .Q(rd_data[6]));
 sky130_fd_sc_hd__sdfrtp_2 _244_ (.CLK(clk),
    .D(_105_),
    .RESET_B(reset_n),
    .SCD(rd_data[3]),
    .SCE(scan_en),
    .Q(rd_data[7]));
 sky130_fd_sc_hd__sdfrtp_2 _245_ (.CLK(clk),
    .D(_000_),
    .RESET_B(reset_n),
    .SCD(rd_data[4]),
    .SCE(scan_en),
    .Q(pwm_out));
 assign scan_out[1] = pwm_out;
 assign scan_out[2] = rd_data[5];
 assign scan_out[3] = rd_data[6];
 assign scan_out[0] = rd_data[7];
endmodule
