# System Software Applications

- Generated at: 2026-09-16T21:58:56.018436+00:00
- Source workflow id: 80f34b26-8242-4533-b573-f689774d6e8d
- Crate name: `physical_ai_product`

## Applications

- `control_service` → package `ss_app_control_service`
- `diagnostics` → package `ss_app_diagnostics`
- `demo_cli` → package `ss_app_demo_cli`

## Files

- `system/software/apps/control_service/src/main.rs`
- `system/software/apps/control_service/Cargo.toml`
- `system/software/apps/diagnostics/src/main.rs`
- `system/software/apps/diagnostics/Cargo.toml`
- `system/software/apps/demo_cli/src/main.rs`
- `system/software/apps/demo_cli/Cargo.toml`
