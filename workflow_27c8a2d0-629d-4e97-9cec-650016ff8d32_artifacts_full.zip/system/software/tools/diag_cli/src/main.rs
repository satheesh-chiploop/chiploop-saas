use clap::{Parser, Subcommand};
use physical_ai_product::Sdk;

#[derive(Parser)]
#[command(author, version, about)]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    Status,
    Probe,
}

fn main() {
    let cli = Cli::parse();
    let sdk = Sdk::new();
    match cli.command {
        Commands::Status => println!("{:?}", sdk.get_status()),
        Commands::Probe => println!("{:?}", sdk.platform_probe()),
    }
}
