use clap::{Parser, Subcommand};
use physical_ai_product::Sdk;

#[derive(Parser)]
#[command(author, version, about)]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    Read { register: String },
    Write { register: String, value: u64 },
}

fn main() {
    let cli = Cli::parse();
    let sdk = Sdk::new();
    match cli.command {
        Commands::Read { register } => println!("{:?}", sdk.read_register(&register)),
        Commands::Write { register, value } => println!("{:?}", sdk.write_register(&register, value)),
    }
}
