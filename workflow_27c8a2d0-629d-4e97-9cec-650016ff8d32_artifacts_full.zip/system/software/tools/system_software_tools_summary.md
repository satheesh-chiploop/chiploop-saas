# System Software Tooling

- Generated at: 2026-09-16T21:58:57.409168+00:00
- Source workflow id: 80f34b26-8242-4533-b573-f689774d6e8d
- SDK crate name: `physical_ai_product`

## Tools

- `reg_viewer` → package `ss_tool_reg_viewer`
- `diag_cli` → package `ss_tool_diag_cli`

## Files

- `system/software/tools/reg_viewer/Cargo.toml`
- `system/software/tools/reg_viewer/src/main.rs`
- `system/software/tools/diag_cli/Cargo.toml`
- `system/software/tools/diag_cli/src/main.rs`
