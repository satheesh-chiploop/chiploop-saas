# System Software SDK Scaffold Summary

- Generated at: 2026-09-16T21:58:48.671209+00:00
- Source workflow id: 80f34b26-8242-4533-b573-f689774d6e8d
- Target language: `rust`
- Build system: `cargo`
- Crate name: `physical_ai_product`

## Generated files

- `system/software/sdk/physical_ai_product/Cargo.toml`
- `system/software/sdk/physical_ai_product/src/lib.rs`
- `system/software/sdk/physical_ai_product/examples/basic.rs`
- `system/software/sdk/physical_ai_product/src/bin/diag_cli.rs`
- `system/software/sdk/physical_ai_product/config/default.toml`
