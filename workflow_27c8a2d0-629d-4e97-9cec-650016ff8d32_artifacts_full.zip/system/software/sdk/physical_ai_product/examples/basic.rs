use physical_ai_product::Sdk;

fn main() {
    let sdk = Sdk::new();
    let _ = sdk.get_status();
    println!("system software example app initialized");
}
