# System Software Service Architecture

- Generated at: 2026-09-16T21:58:52.381551+00:00
- Source workflow id: 80f34b26-8242-4533-b573-f689774d6e8d

## Nodes

- `sdk` (library) → `developer_facing_api_layer`
- `adapter` (library) → `firmware_to_software_bridge`
- `config_runtime` (library) → `config_loading_and_validation`
- `init_manager` (service) → `startup_order_and_readiness`
- `health_monitor` (service) → `health_status_and_fault_summarization`
- `control_service` (service) → `platform_control_surface`
- `diag_cli` (tool) → `operator_diagnostics`
- `interrupt_service` (service) → `interrupt_registration_and_dispatch`

## Edges

- `sdk` -> `adapter` : sdk uses stable adapter layer
- `sdk` -> `config_runtime` : sdk consumes runtime config
- `init_manager` -> `adapter` : startup uses firmware bridge
- `health_monitor` -> `adapter` : health polling reads device status
- `control_service` -> `adapter` : control operations dispatch through adapter
- `diag_cli` -> `sdk` : tooling should call public sdk
