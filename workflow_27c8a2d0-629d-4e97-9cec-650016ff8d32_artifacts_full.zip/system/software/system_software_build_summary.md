# System Software Build System

- Generated at: 2026-09-16T21:58:58.756696+00:00
- Source workflow id: 80f34b26-8242-4533-b573-f689774d6e8d

## Workspace members

- `sdk/physical_ai_product`
- `services`
- `adapter/physical_ai_product_adapter`
- `apps/control_service`
- `apps/diagnostics`
- `apps/demo_cli`
- `tools/reg_viewer`
- `tools/diag_cli`

## Files

- `system/software/Cargo.toml`
- `system/software/Makefile`
- `system/software/build_plan.json`
