# System Software Core Services

- Generated at: 2026-09-16T21:58:53.960534+00:00
- Source workflow id: 80f34b26-8242-4533-b573-f689774d6e8d
- Service count: 4

## Services

- `init_manager`
- `health_monitor`
- `control_service`
- `interrupt_service`

## Files

- `system/software/services/src/init_manager.rs`
- `system/software/services/src/health_monitor.rs`
- `system/software/services/src/control_service.rs`
- `system/software/services/src/interrupt_service.rs`
- `system/software/services/src/error.rs`
- `system/software/services/Cargo.toml`
- `system/software/services/src/lib.rs`
