# System Software Input Contract Summary

- Generated at: 2026-09-16T21:58:45.606326+00:00
- Source handoff: `backend/workflows/80f34b26-8242-4533-b573-f689774d6e8d/system/software_handoff/system_software_handoff.json`
- Source workflow id: `80f34b26-8242-4533-b573-f689774d6e8d`
- Resolution mode: `supabase`
- Valid: `False`

## Required artifacts

- `register_map_path` → `firmware/register_map.json` | exists=`True` | source=`supabase`
- `hal_path` → `firmware/hal/registers.rs` | exists=`True` | source=`supabase`
- `driver_path` → `firmware/drivers/driver_scaffold.rs` | exists=`True` | source=`supabase`
- `firmware_manifest_path` → `firmware/firmware_manifest.json` | exists=`True` | source=`supabase`
- `system_integration_intent_path` → `missing` | exists=`False` | source=`missing`

## Validation

- system_integration_intent_path_missing

## Assumptions / gaps

- system_integration_intent_missing

## Conclusion

This artifact is the normalized, validated input contract for System_Software. Downstream software agents should consume the hydrated state objects and this contract rather than scraping firmware artifacts directly.
