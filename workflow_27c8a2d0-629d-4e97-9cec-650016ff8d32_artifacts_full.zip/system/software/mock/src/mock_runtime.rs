use std::collections::HashMap;

#[derive(Debug, Default, Clone)]
pub struct MockRuntime {
    registers: HashMap<String, u32>,
    power_mode: String,
}

impl MockRuntime {
    pub fn new() -> Self {
        Self {
            registers: HashMap::new(),
            power_mode: "active".into(),
        }
    }

    pub fn read_register(&self, register_name: &str) -> u32 {
        *self.registers.get(register_name).unwrap_or(&0)
    }

    pub fn write_register(&mut self, register_name: &str, value: u32) {
        self.registers.insert(register_name.to_string(), value);
    }

    pub fn set_power_mode(&mut self, mode: &str) {
        self.power_mode = mode.to_string();
    }

    pub fn power_mode(&self) -> &str {
        &self.power_mode
    }
}
