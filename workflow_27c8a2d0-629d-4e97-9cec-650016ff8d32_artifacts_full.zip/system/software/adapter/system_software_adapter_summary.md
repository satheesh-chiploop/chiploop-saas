# System Software HAL/Driver Adapter

- Generated at: 2026-09-16T21:58:50.259960+00:00
- Source workflow id: 80f34b26-8242-4533-b573-f689774d6e8d
- Adapter crate: `physical_ai_product_adapter`
- Adapter package: `physical_ai_product_adapter`

## Adapter contract

- `hal_path` → `firmware/hal/registers.rs`
- `driver_path` → `firmware/drivers/driver_scaffold.rs`
- `register_map_path` → `firmware/register_map.json`
- `interrupt_mapping_path` → `firmware/isr/interrupt_map.json`
- `dma_integration_path` → `unavailable`

## Generated files

- `system/software/adapter/physical_ai_product_adapter/src/adapter/register_adapter.rs`
- `system/software/adapter/physical_ai_product_adapter/src/adapter/device_adapter.rs`
- `system/software/adapter/physical_ai_product_adapter/src/error.rs`
- `system/software/adapter/physical_ai_product_adapter/Cargo.toml`
- `system/software/adapter/physical_ai_product_adapter/src/lib.rs`
- `system/software/adapter/physical_ai_product_adapter/src/adapter/mod.rs`
