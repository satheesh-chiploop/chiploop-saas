use physical_ai_product::Sdk;

#[test]
fn sdk_constructs() {
    let _sdk = Sdk::new();
}

#[test]
fn sdk_status_is_callable() {
    let sdk = Sdk::new();
    let _ = sdk.get_status();
}
