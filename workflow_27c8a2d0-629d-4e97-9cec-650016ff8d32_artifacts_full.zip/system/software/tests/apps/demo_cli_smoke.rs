
    use std::process::Command;

    #[test]
    fn test_demo_cli_smoke() {
        let status = Command::new("cargo")
            .args(["run", "-p", "ss_app_demo_cli", "--", "--scenario", "demo_cli_boot_smoke"])
            .status()
            .expect("failed to run app");

        assert!(status.success());
    }
    