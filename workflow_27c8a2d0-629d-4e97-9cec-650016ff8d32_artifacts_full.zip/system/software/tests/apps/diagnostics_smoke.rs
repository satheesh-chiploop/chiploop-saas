
    use std::process::Command;

    #[test]
    fn test_diagnostics_smoke() {
        let status = Command::new("cargo")
            .args(["run", "-p", "ss_app_diagnostics", "--", "--scenario", "diagnostics_boot_smoke"])
            .status()
            .expect("failed to run app");

        assert!(status.success());
    }
    