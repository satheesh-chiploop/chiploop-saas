
    use std::process::Command;

    #[test]
    fn test_control_service_smoke() {
        let status = Command::new("cargo")
            .args(["run", "-p", "ss_app_control_service", "--", "--scenario", "control_service_boot_smoke"])
            .status()
            .expect("failed to run app");

        assert!(status.success());
    }
    