# System Software Unit Tests

- Generated at: 2026-09-16T21:59:00.399844+00:00
- Source workflow id: 80f34b26-8242-4533-b573-f689774d6e8d

## Files

- `system/software/tests/sdk/sdk_tests.rs`
- `system/software/tests/services/service_tests.rs`
- `system/software/tests/apps/control_service_smoke.rs`
- `system/software/tests/apps/diagnostics_smoke.rs`
- `system/software/tests/apps/demo_cli_smoke.rs`
