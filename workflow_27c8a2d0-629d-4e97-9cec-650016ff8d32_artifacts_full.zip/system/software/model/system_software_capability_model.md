# System Software Capability Model

- Generated at: 2026-09-16T21:58:46.458769+00:00
- Source workflow id: 80f34b26-8242-4533-b573-f689774d6e8d

## Platform identity

- Top module: `adaptive_aero_control_top`
- RTL file count: `1`

## Software services

- `register_access` → `True`
- `driver_layer` → `True`
- `interrupt_control` → `True`
- `dma_control` → `False`
- `boot_orchestration` → `False`
- `clock_control` → `False`
- `reset_control` → `False`
- `power_mode_control` → `False`
- `runtime_validation_support` → `True`

## Register model

- Register count: `4`
- Field count: `21`
- Bus: `MINIMAL`

## Constraints

- system_integration_intent_missing
- system_integration_intent_path_missing
