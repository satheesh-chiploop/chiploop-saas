# System Software Config Schema

- Generated at: 2026-09-16T21:58:51.114090+00:00
- Source workflow id: 80f34b26-8242-4533-b573-f689774d6e8d

## Feature toggles

- `interrupt_control` → `True`
- `dma_control` → `False`
- `power_mode_control` → `False`
- `clock_control` → `False`
- `reset_control` → `False`

## Generated files

- `system/software/config/default_config.json`
- `system/software/config/default_runtime_config.json`
- `system/software/config/default_runtime_config.toml`
