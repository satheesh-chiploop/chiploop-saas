module pwm_fpga_demo (
    input clk,
    output led
);

reg [7:0] pwm_counter;
reg [7:0] duty_cycle;
reg [15:0] slow_counter;
reg direction_up;
reg led_r;

localparam [7:0] DUTY_MIN = 8'h10;
localparam [7:0] DUTY_MAX = 8'hF0;
localparam [15:0] SLOW_MAX = 16'd49999;

always @(posedge clk) begin
    pwm_counter <= pwm_counter + 8'd1;

    if (slow_counter == SLOW_MAX) begin
        slow_counter <= 16'd0;

        if (direction_up) begin
            if (duty_cycle >= DUTY_MAX - 8'd1) begin
                duty_cycle <= DUTY_MAX;
                direction_up <= 1'b0;
            end else begin
                duty_cycle <= duty_cycle + 8'd1;
                direction_up <= 1'b1;
            end
        end else begin
            if (duty_cycle <= DUTY_MIN + 8'd1) begin
                duty_cycle <= DUTY_MIN;
                direction_up <= 1'b1;
            end else begin
                duty_cycle <= duty_cycle - 8'd1;
                direction_up <= 1'b0;
            end
        end
    end else begin
        slow_counter <= slow_counter + 16'd1;
        duty_cycle <= duty_cycle;
        direction_up <= direction_up;
    end

    led_r <= (pwm_counter < duty_cycle);
end

assign led = led_r;

initial begin
    pwm_counter = 8'd0;
    duty_cycle = DUTY_MIN;
    slow_counter = 16'd0;
    direction_up = 1'b1;
    led_r = 1'b0;
end

endmodule
