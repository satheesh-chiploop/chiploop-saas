# Simulation Summary + Coverage

- Total simulation runs: 2
- Simulation pass count: 2
- Simulation fail count: 0
- Coverage status: ok
- Functional coverage %: 75.0
- Coverage bins hit: 3
- Coverage total bins: 4
- Functional bin gaps: 1
- Code line coverage: 58.33%
- Code branch coverage: 8.75%
- Code condition coverage: 8.75%
- Code toggle coverage: 36.11%
- SVA/assertion status: missing
- SVA/assertion pass %: missing
- Formal status: not_enabled
- Golden model status: not_enabled
- Simulator tool: verilator
- Code coverage tool: verilator_coverage
- Formal tool: none
- Golden model tool: none

## Functional Coverage Not Met
- inputs.clk: bins 1/2, missing zero, seen values [1]
