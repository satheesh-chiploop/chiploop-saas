# Digital DQA Summary
- workflow_id: `66451696-c8ea-4962-96d0-7cd43f0e871b`
- status: `failed`
- rtl files: `1`
- warning count: `0`

## Stage Status
- rtl_lint: `warn`
- cdc: `unavailable`
- reset_integrity: `unavailable`
- synthesis_readiness: `failed`

## Blocking Issues
- yosys_synthesis_errors
