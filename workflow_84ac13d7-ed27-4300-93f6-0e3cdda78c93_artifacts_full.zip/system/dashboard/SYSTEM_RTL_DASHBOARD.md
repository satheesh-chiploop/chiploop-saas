# System RTL Evidence Dashboard

## System
- Top module: temp_monitor_soc_sim
- RTL files: 4
- Modules: 4
- Input bits: 54
- Output bits: 42
- Flip-flops: 213
- Latches: 0
- Full-cycle paths: 3
- Half-cycle paths: 1

## Soc
- Top module: temp_monitor_soc_sim
- RTL files: 2
- Modules: 2
- Input bits: 54
- Output bits: 42
- Flip-flops: 0
- Latches: 0
- Full-cycle paths: 2
- Half-cycle paths: 0

## Digital
- Top module: temp_monitor_digital
- RTL files: 1
- Modules: 1
- Input bits: 49
- Output bits: 43
- Flip-flops: 136
- Latches: 0
- Full-cycle paths: 3
- Half-cycle paths: 1

## Analog
- Top module: temp_sensor_adc_model
- RTL files: 1
- Modules: 1
- Input bits: 19
- Output bits: 13
- Flip-flops: 77
- Latches: 0
- Full-cycle paths: 3
- Half-cycle paths: 0
