module temp_monitor_digital (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    adc_code,
    adc_valid,
    rd_data,
    sample_req,
    alert_irq,
    temp_code,
    threshold_code,
    alert_status
);

input clk;
input reset_n;
input wr_en;
input [7:0] wr_addr;
input [15:0] wr_data;
input rd_en;
input [7:0] rd_addr;
input [11:0] adc_code;
input adc_valid;
output [15:0] rd_data;
output sample_req;
output alert_irq;
output [11:0] temp_code;
output [11:0] threshold_code;
output alert_status;

reg [15:0] rd_data_r;
reg sample_req_r;
reg alert_irq_r;
reg [11:0] temp_code_r;
reg [11:0] threshold_code_r;
reg alert_status_r;

reg enable_reg;
reg irq_enable_reg;
reg sample_start_pulse;
reg alert_clear_pulse;
reg [11:0] latest_temp;
reg [15:0] sample_count;
reg irq_status_alert;
reg irq_status_sample_done;
reg status_sample_done;
reg status_alert_pending;
reg status_adc_valid_seen;
reg status_busy;
reg [11:0] prev_adc_sample;
reg filter_valid;
reg [12:0] sample_sum;
reg [11:0] current_filtered;
reg sample_req_periodic;
reg [15:0] read_data_next;

assign rd_data = rd_data_r;
assign sample_req = sample_req_r;
assign alert_irq = alert_irq_r;
assign temp_code = temp_code_r;
assign threshold_code = threshold_code_r;
assign alert_status = alert_status_r;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        rd_data_r <= 16'h0000;
        sample_req_r <= 1'b0;
        alert_irq_r <= 1'b0;
        temp_code_r <= 12'h000;
        threshold_code_r <= 12'h000;
        alert_status_r <= 1'b0;
        enable_reg <= 1'b0;
        irq_enable_reg <= 1'b0;
        sample_start_pulse <= 1'b0;
        alert_clear_pulse <= 1'b0;
        latest_temp <= 12'h000;
        sample_count <= 16'h0000;
        irq_status_alert <= 1'b0;
        irq_status_sample_done <= 1'b0;
        status_sample_done <= 1'b0;
        status_alert_pending <= 1'b0;
        status_adc_valid_seen <= 1'b0;
        status_busy <= 1'b0;
        prev_adc_sample <= 12'h000;
        filter_valid <= 1'b0;
        sample_sum <= 13'h0000;
        current_filtered <= 12'h000;
        sample_req_periodic <= 1'b0;
        read_data_next <= 16'h0000;
    end else begin
        sample_start_pulse <= 1'b0;
        alert_clear_pulse <= 1'b0;
        sample_req_periodic <= 1'b0;
        sample_req_r <= 1'b0;

        if (wr_en) begin
            case (wr_addr)
                8'h00: begin
                    enable_reg <= wr_data[0];
                    if (wr_data[1]) begin
                        sample_start_pulse <= 1'b1;
                    end
                    irq_enable_reg <= wr_data[2];
                    if (wr_data[3]) begin
                        alert_clear_pulse <= 1'b1;
                    end
                end
                8'h08: begin
                    threshold_code_r <= wr_data[11:0];
                end
                8'h18: begin
                    if (wr_data[0]) begin
                        irq_status_alert <= 1'b0;
                        alert_status_r <= 1'b0;
                        status_alert_pending <= 1'b0;
                    end
                    if (wr_data[1]) begin
                        irq_status_sample_done <= 1'b0;
                        status_sample_done <= 1'b0;
                    end
                end
                default: begin
                end
            endcase
        end

        if (sample_start_pulse) begin
            sample_req_r <= 1'b1;
        end else if (enable_reg) begin
            sample_req_periodic <= ~status_busy;
            sample_req_r <= ~status_busy;
        end

        if (alert_clear_pulse) begin
            alert_status_r <= 1'b0;
            status_alert_pending <= 1'b0;
            irq_status_alert <= 1'b0;
        end

        if (adc_valid) begin
            status_adc_valid_seen <= 1'b1;
            status_sample_done <= 1'b1;
            irq_status_sample_done <= 1'b1;
            status_busy <= 1'b0;
            sample_count <= sample_count + 16'h0001;
            if (filter_valid) begin
                sample_sum <= {1'b0, prev_adc_sample} + {1'b0, adc_code};
                current_filtered <= sample_sum[12:1];
            end else begin
                current_filtered <= adc_code[11:0];
                sample_sum <= {1'b0, adc_code};
            end
            filter_valid <= 1'b1;
            prev_adc_sample <= adc_code[11:0];
            latest_temp <= current_filtered;
            temp_code_r <= current_filtered;
            if (current_filtered > threshold_code_r) begin
                alert_status_r <= 1'b1;
                status_alert_pending <= 1'b1;
                irq_status_alert <= 1'b1;
            end
        end else if (sample_start_pulse) begin
            status_busy <= 1'b1;
        end else if (enable_reg && !status_busy) begin
            status_busy <= 1'b1;
        end

        if (enable_reg && !status_busy) begin
            sample_req_periodic <= 1'b1;
        end

        if (rd_en) begin
            case (rd_addr)
                8'h00: read_data_next <= {12'h000, 1'b0, 1'b0, irq_enable_reg, enable_reg};
                8'h04: read_data_next <= {12'h000, status_busy, status_adc_valid_seen, status_alert_pending, status_sample_done};
                8'h08: read_data_next <= {4'h0, threshold_code_r};
                8'h0C: read_data_next <= {4'h0, latest_temp};
                8'h10: read_data_next <= sample_count;
                8'h14: read_data_next <= {14'h0000, irq_status_sample_done, irq_status_alert};
                8'h18: read_data_next <= 16'h0000;
                default: read_data_next <= 16'h0000;
            endcase
        end else begin
            read_data_next <= 16'h0000;
        end

        rd_data_r <= read_data_next;
        alert_irq_r <= irq_enable_reg && (irq_status_alert || irq_status_sample_done);
    end
end

endmodule
