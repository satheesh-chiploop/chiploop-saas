module temp_sensor_adc_model (
    input  sample_req,
    input  [15:0] sensor_temp_celsius,
    input  avdd,
    input  avss,
    output reg [11:0] adc_code,
    output reg adc_valid
);

    parameter integer GAIN_ERROR_PPM = 0;
    parameter integer OFFSET_ERROR_CODES = 0;
    parameter integer NOMINAL_SAMPLE_LATENCY = 1;
    parameter integer TEMP_SCALE = 1;
    parameter integer TEMP_OFFSET_C = 0;

    reg [15:0] latched_temperature_sample;
    reg [11:0] latched_adc_code;
    reg valid_pending;
    reg [31:0] sample_latency_counter;
    reg sample_req_d;
    reg supply_present;

    reg [31:0] temp_term;
    reg signed [31:0] nominal_code_signed;
    reg signed [31:0] gain_scaled_code_signed;
    reg signed [31:0] offset_applied_code_signed;
    reg signed [31:0] clamped_code_signed;
    reg signed [31:0] temp_offset_signed;
    reg signed [31:0] temp_scale_signed;
    reg signed [31:0] latched_temp_signed;
    reg signed [31:0] gain_factor_signed;
    reg signed [63:0] gain_mult_full;

    wire sample_req_rise;

    assign sample_req_rise = sample_req & ~sample_req_d;

    always @(*) begin
        temp_term = 32'd0;
        nominal_code_signed = 32'sd0;
        gain_scaled_code_signed = 32'sd0;
        offset_applied_code_signed = 32'sd0;
        clamped_code_signed = 32'sd0;
        temp_offset_signed = $signed(TEMP_OFFSET_C);
        temp_scale_signed = $signed(TEMP_SCALE);
        latched_temp_signed = $signed({1'b0, latched_temperature_sample});
        gain_factor_signed = $signed(32'd1000000 + GAIN_ERROR_PPM);
        gain_mult_full = 64'sd0;

        temp_term = (latched_temperature_sample - TEMP_OFFSET_C) * TEMP_SCALE;
        nominal_code_signed = $signed(temp_term);
        offset_applied_code_signed = nominal_code_signed + $signed(OFFSET_ERROR_CODES);

        gain_mult_full = $signed(offset_applied_code_signed) * $signed(gain_factor_signed);
        gain_scaled_code_signed = $signed(gain_mult_full / 64'sd1000000);

        clamped_code_signed = gain_scaled_code_signed;
        if (clamped_code_signed < 0)
            clamped_code_signed = 0;
        else if (clamped_code_signed > 4095)
            clamped_code_signed = 4095;
    end

    always @(posedge sample_req or posedge avdd or posedge avss) begin
        if (avdd || avss) begin
            supply_present <= avdd & ~avss;
        end else begin
            sample_req_d <= sample_req;
        end
    end

    always @(posedge sample_req) begin
        if (sample_req_rise) begin
            latched_temperature_sample <= sensor_temp_celsius;
            sample_latency_counter <= (NOMINAL_SAMPLE_LATENCY < 0) ? 32'd0 : NOMINAL_SAMPLE_LATENCY[31:0];
            valid_pending <= 1'b1;
            adc_valid <= 1'b0;
            adc_code <= latched_adc_code;
        end
    end

    always @(*) begin
        if (valid_pending && (sample_latency_counter == 32'd0)) begin
            adc_valid = 1'b1;
            adc_code = clamped_code_signed[11:0];
        end else begin
            adc_valid = 1'b0;
            adc_code = latched_adc_code;
        end
    end

    always @(posedge sample_req) begin
        if (sample_req_rise) begin
            if (NOMINAL_SAMPLE_LATENCY <= 0) begin
                latched_adc_code <= clamped_code_signed[11:0];
                adc_code <= clamped_code_signed[11:0];
                adc_valid <= 1'b1;
                valid_pending <= 1'b0;
                sample_latency_counter <= 32'd0;
            end else begin
                latched_adc_code <= clamped_code_signed[11:0];
            end
        end
    end

    initial begin
        adc_code = 12'd0;
        adc_valid = 1'b0;
        latched_temperature_sample = 16'd0;
        latched_adc_code = 12'd0;
        valid_pending = 1'b0;
        sample_latency_counter = 32'd0;
        sample_req_d = 1'b0;
        supply_present = 1'b0;
    end

endmodule
