# Spec-to-RTL Conformance Report

Status: **partial**

- Requirements checked: 41
- Matched: 39
- Partial: 0
- Missing: 2
- Inconclusive: 0
- Interface: pass
- Register map: pass
- Clock/reset: pass

## Missing Or Partial Requirements
- REQ-008 [missing]: Maintain sticky STATUS and IRQ_STATUS bits with independent clear mechanisms.
- REQ-023 [missing]: IRQ_STATUS bit 1 sample_done is sticky until cleared by IRQ_CLEAR bit 1.
