module temp_sensor_adc_model (
    input  wire        sample_req,
    input  wire [15:0] sensor_temp_celsius,
    input  wire        avdd,
    input  wire        avss,
    output reg  [11:0] adc_code,
    output reg         adc_valid
);

    localparam integer NOMINAL_GAIN_PPM  = 1000000;
    localparam integer GAIN_ERROR_PPM    = 0;
    localparam integer OFFSET_ERROR_CODE  = 0;
    localparam integer SAMPLE_LATENCY_CYC = 1;

    reg        req_d;
    reg        pending_conv;
    reg [31:0] latency_cnt;
    reg [11:0] latched_code;

    reg [31:0] temp_ext;
    reg [31:0] code_nominal;
    reg [31:0] code_with_offset;
    reg [63:0] code_scaled_wide;
    reg [31:0] gain_total_u32;
    reg [63:0] gain_total_wide;
    reg [31:0] code_scaled;
    reg [31:0] code_clamped_u32;

    always @(*) begin
        temp_ext         = {16'd0, sensor_temp_celsius};
        code_nominal     = temp_ext << 4;
        code_with_offset = code_nominal + OFFSET_ERROR_CODE;

        gain_total_u32   = NOMINAL_GAIN_PPM + GAIN_ERROR_PPM;
        gain_total_wide  = {32'd0, gain_total_u32};

        code_scaled_wide = code_with_offset * gain_total_wide;
        code_scaled      = code_scaled_wide / NOMINAL_GAIN_PPM;

        if ($signed(code_scaled) < 0)
            code_clamped_u32 = 32'd0;
        else if (code_scaled > 32'd4095)
            code_clamped_u32 = 32'd4095;
        else
            code_clamped_u32 = code_scaled;
    end

    always @(posedge avdd or negedge avdd) begin
        if (1'b0) begin
            req_d        <= 1'b0;
            pending_conv <= 1'b0;
            latency_cnt  <= 32'd0;
            latched_code <= 12'd0;
            adc_code     <= 12'd0;
            adc_valid    <= 1'b0;
        end else begin
            req_d <= sample_req;

            if (sample_req && !req_d) begin
                latched_code <= code_clamped_u32[11:0];
                if (SAMPLE_LATENCY_CYC == 0) begin
                    adc_code     <= code_clamped_u32[11:0];
                    adc_valid    <= 1'b1;
                    pending_conv <= 1'b0;
                    latency_cnt  <= 32'd0;
                end else begin
                    pending_conv <= 1'b1;
                    latency_cnt  <= SAMPLE_LATENCY_CYC[31:0];
                    adc_valid    <= 1'b0;
                end
            end else if (pending_conv) begin
                if (latency_cnt <= 32'd1) begin
                    adc_code     <= latched_code;
                    adc_valid    <= 1'b1;
                    pending_conv <= 1'b0;
                    latency_cnt  <= 32'd0;
                end else begin
                    latency_cnt  <= latency_cnt - 32'd1;
                    adc_valid    <= 1'b0;
                end
            end else begin
                adc_valid <= 1'b0;
            end
        end
    end

endmodule
