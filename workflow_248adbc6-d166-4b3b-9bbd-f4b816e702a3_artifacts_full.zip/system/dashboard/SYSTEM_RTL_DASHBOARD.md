# System RTL Evidence Dashboard

## System
- Top module: temp_monitor_soc_sim
- RTL files: 6
- Modules: 6
- Input bits: 10
- Output bits: 5
- Flip-flops: 142
- Latches: 0
- Full-cycle paths: 3
- Half-cycle paths: 3

## Soc
- Top module: temp_monitor_soc_sim
- RTL files: 2
- Modules: 2
- Input bits: 10
- Output bits: 5
- Flip-flops: 0
- Latches: 0
- Full-cycle paths: 2
- Half-cycle paths: 0

## Digital
- Top module: temp_monitor_datapath
- RTL files: 3
- Modules: 3
- Input bits: 33
- Output bits: 36
- Flip-flops: 83
- Latches: 0
- Full-cycle paths: 3
- Half-cycle paths: 2

## Analog
- Top module: temp_sensor_adc_model
- RTL files: 1
- Modules: 1
- Input bits: 19
- Output bits: 13
- Flip-flops: 59
- Latches: 0
- Full-cycle paths: 3
- Half-cycle paths: 1
