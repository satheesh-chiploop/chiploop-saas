module temp_monitor_digital (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    adc_code,
    adc_valid,
    rd_data,
    sample_req,
    alert_irq,
    temp_code,
    threshold_code,
    alert_status,
    irq_enable
);

input clk;
input reset_n;
input wr_en;
input [7:0] wr_addr;
input [15:0] wr_data;
input rd_en;
input [7:0] rd_addr;
input [11:0] adc_code;
input adc_valid;
output [15:0] rd_data;
output sample_req;
output alert_irq;
output [11:0] temp_code;
output [11:0] threshold_code;
output alert_status;
input irq_enable;

wire enable_out;
wire sample_start_pulse_out;
wire irq_enable_out;
wire alert_clear_pulse_out;
wire irq_clear_alert_pulse_out;
wire irq_clear_sample_done_pulse_out;
wire [11:0] threshold_code_out;
wire [15:0] reg_rd_data;

wire [11:0] datapath_temp_code;
wire [15:0] datapath_sample_count_out;
wire irq_status_alert;
wire irq_status_sample_done;
wire status_sample_done;
wire status_alert_pending;
wire status_adc_valid_seen;
wire status_busy;
wire datapath_sample_req;
wire datapath_alert_status;

temp_monitor_registers u_temp_monitor_registers (
    .clk(clk),
    .reset_n(reset_n),
    .wr_en(wr_en),
    .wr_addr(wr_addr),
    .wr_data(wr_data),
    .rd_en(rd_en),
    .rd_addr(rd_addr),
    .adc_valid(adc_valid),
    .adc_code(adc_code),
    .temp_code_in(datapath_temp_code),
    .sample_count_in(datapath_sample_count_out),
    .irq_status_alert_in(irq_status_alert),
    .irq_status_sample_done_in(irq_status_sample_done),
    .status_sample_done_in(status_sample_done),
    .status_alert_pending_in(status_alert_pending),
    .status_adc_valid_seen_in(status_adc_valid_seen),
    .status_busy_in(status_busy),
    .sample_req_in(datapath_sample_req),
    .alert_status_in(datapath_alert_status),
    .enable_out(enable_out),
    .sample_start_pulse_out(sample_start_pulse_out),
    .irq_enable_out(irq_enable_out),
    .alert_clear_pulse_out(alert_clear_pulse_out),
    .irq_clear_alert_pulse_out(irq_clear_alert_pulse_out),
    .irq_clear_sample_done_pulse_out(irq_clear_sample_done_pulse_out),
    .threshold_code_out(threshold_code_out),
    .rd_data(reg_rd_data)
);

temp_monitor_datapath u_temp_monitor_datapath (
    .clk(clk),
    .reset_n(reset_n),
    .enable_in(enable_out),
    .sample_start_pulse_in(sample_start_pulse_out),
    .irq_enable_in(irq_enable_out),
    .alert_clear_pulse_in(alert_clear_pulse_out),
    .irq_clear_alert_pulse_in(irq_clear_alert_pulse_out),
    .irq_clear_sample_done_pulse_in(irq_clear_sample_done_pulse_out),
    .threshold_code_in(threshold_code_out),
    .adc_code(adc_code),
    .adc_valid(adc_valid),
    .sample_req(datapath_sample_req),
    .temp_code(datapath_temp_code),
    .sample_count_out(datapath_sample_count_out),
    .irq_status_alert(irq_status_alert),
    .irq_status_sample_done(irq_status_sample_done),
    .status_sample_done(status_sample_done),
    .status_alert_pending(status_alert_pending),
    .status_adc_valid_seen(status_adc_valid_seen),
    .status_busy(status_busy),
    .alert_status(datapath_alert_status)
);

assign rd_data = reg_rd_data;
assign sample_req = datapath_sample_req;
assign temp_code = datapath_temp_code;
assign threshold_code = threshold_code_out;
assign alert_status = datapath_alert_status;
assign alert_irq = irq_enable & (irq_status_alert | irq_status_sample_done);

endmodule
