module temp_monitor_registers (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    adc_valid,
    adc_code,
    temp_code_in,
    sample_count_in,
    irq_status_alert_in,
    irq_status_sample_done_in,
    status_sample_done_in,
    status_alert_pending_in,
    status_adc_valid_seen_in,
    status_busy_in,
    sample_req_in,
    alert_status_in,
    enable_out,
    sample_start_pulse_out,
    irq_enable_out,
    alert_clear_pulse_out,
    irq_clear_alert_pulse_out,
    irq_clear_sample_done_pulse_out,
    threshold_code_out,
    rd_data
);

input clk;
input reset_n;
input wr_en;
input [7:0] wr_addr;
input [15:0] wr_data;
input rd_en;
input [7:0] rd_addr;
input adc_valid;
input [11:0] adc_code;
input [11:0] temp_code_in;
input [15:0] sample_count_in;
input irq_status_alert_in;
input irq_status_sample_done_in;
input status_sample_done_in;
input status_alert_pending_in;
input status_adc_valid_seen_in;
input status_busy_in;
input sample_req_in;
input alert_status_in;
output enable_out;
output sample_start_pulse_out;
output irq_enable_out;
output alert_clear_pulse_out;
output irq_clear_alert_pulse_out;
output irq_clear_sample_done_pulse_out;
output [11:0] threshold_code_out;
output [15:0] rd_data;

reg enable_reg;
reg irq_enable_reg;
reg [11:0] threshold_reg;
reg sample_start_pulse_reg;
reg alert_clear_pulse_reg;
reg irq_clear_alert_pulse_reg;
reg irq_clear_sample_done_pulse_reg;
reg [15:0] rd_data_reg;
reg [15:0] rd_data_mux;

assign enable_out = enable_reg;
assign irq_enable_out = irq_enable_reg;
assign threshold_code_out = threshold_reg;
assign sample_start_pulse_out = sample_start_pulse_reg;
assign alert_clear_pulse_out = alert_clear_pulse_reg;
assign irq_clear_alert_pulse_out = irq_clear_alert_pulse_reg;
assign irq_clear_sample_done_pulse_out = irq_clear_sample_done_pulse_reg;
assign rd_data = rd_data_reg;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        enable_reg <= 1'b0;
        irq_enable_reg <= 1'b0;
        threshold_reg <= 12'b000000000000;
        sample_start_pulse_reg <= 1'b0;
        alert_clear_pulse_reg <= 1'b0;
        irq_clear_alert_pulse_reg <= 1'b0;
        irq_clear_sample_done_pulse_reg <= 1'b0;
        rd_data_reg <= 16'b0000000000000000;
    end else begin
        sample_start_pulse_reg <= 1'b0;
        alert_clear_pulse_reg <= 1'b0;
        irq_clear_alert_pulse_reg <= 1'b0;
        irq_clear_sample_done_pulse_reg <= 1'b0;
        rd_data_reg <= rd_data_mux;

        if (wr_en) begin
            case (wr_addr)
                8'h00: begin
                    enable_reg <= wr_data[0];
                    irq_enable_reg <= wr_data[2];
                    if (wr_data[1]) begin
                        sample_start_pulse_reg <= 1'b1;
                    end
                    if (wr_data[3]) begin
                        alert_clear_pulse_reg <= 1'b1;
                    end
                end
                8'h08: begin
                    threshold_reg <= wr_data[11:0];
                end
                8'h18: begin
                    if (wr_data[0]) begin
                        irq_clear_alert_pulse_reg <= 1'b1;
                    end
                    if (wr_data[1]) begin
                        irq_clear_sample_done_pulse_reg <= 1'b1;
                    end
                end
                default: begin
                end
            endcase
        end
    end
end

always @(*) begin
    rd_data_mux = 16'h0000;
    if (rd_en) begin
        case (rd_addr)
            8'h00: begin
                rd_data_mux = {12'b000000000000, 1'b0, irq_enable_reg, 1'b0, enable_reg};
            end
            8'h04: begin
                rd_data_mux = {12'b000000000000, status_busy_in, status_adc_valid_seen_in, status_alert_pending_in, status_sample_done_in};
            end
            8'h08: begin
                rd_data_mux = {4'b0000, threshold_reg};
            end
            8'h0C: begin
                rd_data_mux = {4'b0000, temp_code_in};
            end
            8'h10: begin
                rd_data_mux = sample_count_in;
            end
            8'h14: begin
                rd_data_mux = {14'b00000000000000, irq_status_sample_done_in, irq_status_alert_in};
            end
            8'h18: begin
                rd_data_mux = 16'h0000;
            end
            default: begin
                rd_data_mux = 16'h0000;
            end
        endcase
    end else begin
        rd_data_mux = 16'h0000;
    end
end

endmodule
