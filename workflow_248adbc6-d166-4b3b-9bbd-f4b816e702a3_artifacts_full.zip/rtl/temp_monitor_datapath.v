module temp_monitor_datapath (
    clk,
    reset_n,
    enable_in,
    sample_start_pulse_in,
    irq_enable_in,
    alert_clear_pulse_in,
    irq_clear_alert_pulse_in,
    irq_clear_sample_done_pulse_in,
    threshold_code_in,
    adc_code,
    adc_valid,
    sample_req,
    temp_code,
    sample_count_out,
    irq_status_alert,
    irq_status_sample_done,
    status_sample_done,
    status_alert_pending,
    status_adc_valid_seen,
    status_busy,
    alert_status
);

input clk;
input reset_n;
input enable_in;
input sample_start_pulse_in;
input irq_enable_in;
input alert_clear_pulse_in;
input irq_clear_alert_pulse_in;
input irq_clear_sample_done_pulse_in;
input [11:0] threshold_code_in;
input [11:0] adc_code;
input adc_valid;
output sample_req;
output [11:0] temp_code;
output [15:0] sample_count_out;
output irq_status_alert;
output irq_status_sample_done;
output status_sample_done;
output status_alert_pending;
output status_adc_valid_seen;
output status_busy;
output alert_status;

reg sample_req_reg;
reg [11:0] temp_code_reg;
reg [11:0] prev_adc_code_reg;
reg prev_adc_valid_reg;
reg [15:0] sample_count_reg;
reg irq_status_alert_reg;
reg irq_status_sample_done_reg;
reg status_sample_done_reg;
reg status_alert_pending_reg;
reg status_adc_valid_seen_reg;
reg status_busy_reg;
reg alert_status_reg;

wire [12:0] avg_sum;
wire [11:0] avg_code;
wire start_sample_event;

assign avg_sum = adc_code + prev_adc_code_reg;
assign avg_code = avg_sum[12:1];
assign start_sample_event = sample_start_pulse_in | (enable_in & ~status_busy_reg & ~adc_valid);
assign sample_req = sample_req_reg;
assign temp_code = temp_code_reg;
assign sample_count_out = sample_count_reg;
assign irq_status_alert = irq_status_alert_reg;
assign irq_status_sample_done = irq_status_sample_done_reg;
assign status_sample_done = status_sample_done_reg;
assign status_alert_pending = status_alert_pending_reg;
assign status_adc_valid_seen = status_adc_valid_seen_reg;
assign status_busy = status_busy_reg;
assign alert_status = alert_status_reg;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        sample_req_reg <= 1'b0;
        temp_code_reg <= 12'b000000000000;
        prev_adc_code_reg <= 12'b000000000000;
        prev_adc_valid_reg <= 1'b0;
        sample_count_reg <= 16'b0000000000000000;
        irq_status_alert_reg <= 1'b0;
        irq_status_sample_done_reg <= 1'b0;
        status_sample_done_reg <= 1'b0;
        status_alert_pending_reg <= 1'b0;
        status_adc_valid_seen_reg <= 1'b0;
        status_busy_reg <= 1'b0;
        alert_status_reg <= 1'b0;
    end else begin
        sample_req_reg <= 1'b0;

        if (sample_start_pulse_in) begin
            sample_req_reg <= 1'b1;
        end else if (enable_in & ~status_busy_reg & ~adc_valid) begin
            sample_req_reg <= 1'b1;
        end

        if (sample_req_reg) begin
            status_busy_reg <= 1'b1;
        end

        if (adc_valid) begin
            prev_adc_code_reg <= adc_code;
            prev_adc_valid_reg <= 1'b1;
            status_busy_reg <= 1'b0;
            status_adc_valid_seen_reg <= 1'b1;
            sample_count_reg <= sample_count_reg + 16'h0001;
            status_sample_done_reg <= 1'b1;
            irq_status_sample_done_reg <= 1'b1;
            temp_code_reg <= avg_code;
            if (avg_code > threshold_code_in) begin
                alert_status_reg <= 1'b1;
                status_alert_pending_reg <= 1'b1;
                irq_status_alert_reg <= 1'b1;
            end
        end

        if (alert_clear_pulse_in | irq_clear_alert_pulse_in) begin
            alert_status_reg <= 1'b0;
            status_alert_pending_reg <= 1'b0;
            irq_status_alert_reg <= 1'b0;
        end

        if (irq_clear_sample_done_pulse_in) begin
            status_sample_done_reg <= 1'b0;
            irq_status_sample_done_reg <= 1'b0;
        end
    end
end

endmodule
