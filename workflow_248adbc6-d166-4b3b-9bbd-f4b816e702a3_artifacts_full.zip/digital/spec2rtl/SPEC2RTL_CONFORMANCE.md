# Spec-to-RTL Conformance Report

Status: **partial**

- Requirements checked: 84
- Matched: 79
- Partial: 0
- Missing: 4
- Inconclusive: 1
- Interface: pass
- Register map: issues
- Clock/reset: pass

## Missing Or Partial Requirements
- REQ-008 [missing]: Track completed sample count and sticky adc_valid_seen.
- REQ-012 [missing]: CONTROL bit 0 ENABLE is stored.
- REQ-045 [missing]: Writing CONTROL bit 0 stores ENABLE.
