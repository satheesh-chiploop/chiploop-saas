# Auto-generated from ChipLoop clock intent
create_clock -name clk -period 4.545 [get_ports {clk}]
