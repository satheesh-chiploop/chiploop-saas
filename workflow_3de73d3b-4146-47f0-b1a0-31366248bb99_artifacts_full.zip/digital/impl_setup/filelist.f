/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/3de73d3b-4146-47f0-b1a0-31366248bb99/67b9fa5e-47b8-4e41-9ebc-63eafab7ab86/digital/system/imported_rtl/temp_sensor_adc_model.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/3de73d3b-4146-47f0-b1a0-31366248bb99/67b9fa5e-47b8-4e41-9ebc-63eafab7ab86/digital/system/imported_rtl/temp_monitor_digital.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/3de73d3b-4146-47f0-b1a0-31366248bb99/67b9fa5e-47b8-4e41-9ebc-63eafab7ab86/digital/system/imported_rtl/temp_monitor_soc_phys.sv
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/3de73d3b-4146-47f0-b1a0-31366248bb99/67b9fa5e-47b8-4e41-9ebc-63eafab7ab86/digital/system/imported_rtl/temp_monitor_soc_sim.sv
