# IP Packaging & Handoff Report

- Top: `safety_fault_watchdog`
- Package: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/dd095a60-e45f-44c3-beb0-943e030b19e3/ff5167b1-75d5-4b82-8bf2-b2321c18cdb9/digital/arch2tapeout/handoff/safety_fault_watchdog_ip_package`
- Zip: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/dd095a60-e45f-44c3-beb0-943e030b19e3/ff5167b1-75d5-4b82-8bf2-b2321c18cdb9/digital/arch2tapeout/handoff/safety_fault_watchdog_ip_package.zip`

## Bucket counts
- **rtl**: 3
- **spec**: 1
- **arch**: 0
- **microarch**: 0
- **regmap**: 0
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 2
