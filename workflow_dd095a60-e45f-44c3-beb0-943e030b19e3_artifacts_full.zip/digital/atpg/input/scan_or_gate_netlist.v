module safety_fault_watchdog (clk,
    external_reset_done,
    heartbeat,
    rd_en,
    reset_n,
    reset_request,
    safety_irq,
    scan_en,
    watchdog_expired,
    wr_en,
    escalation_level,
    fault_in,
    fault_latched,
    rd_addr,
    rd_data,
    scan_in,
    scan_out,
    wr_addr,
    wr_data);
 input clk;
 input external_reset_done;
 input heartbeat;
 input rd_en;
 input reset_n;
 output reset_request;
 output safety_irq;
 input scan_en;
 output watchdog_expired;
 input wr_en;
 output [1:0] escalation_level;
 input [7:0] fault_in;
 output [7:0] fault_latched;
 input [11:0] rd_addr;
 output [31:0] rd_data;
 input [3:0] scan_in;
 output [3:0] scan_out;
 input [11:0] wr_addr;
 input [31:0] wr_data;

 wire _0000_;
 wire _0001_;
 wire _0002_;
 wire _0003_;
 wire _0004_;
 wire _0005_;
 wire _0006_;
 wire _0007_;
 wire _0008_;
 wire _0009_;
 wire _0010_;
 wire _0011_;
 wire _0012_;
 wire _0013_;
 wire _0014_;
 wire _0015_;
 wire _0016_;
 wire _0017_;
 wire _0018_;
 wire _0019_;
 wire _0020_;
 wire _0021_;
 wire _0022_;
 wire _0023_;
 wire _0024_;
 wire _0025_;
 wire _0026_;
 wire _0027_;
 wire _0028_;
 wire _0029_;
 wire _0030_;
 wire _0031_;
 wire _0032_;
 wire _0033_;
 wire _0034_;
 wire _0035_;
 wire _0036_;
 wire _0037_;
 wire _0038_;
 wire _0039_;
 wire _0040_;
 wire _0041_;
 wire _0042_;
 wire _0043_;
 wire _0044_;
 wire _0045_;
 wire _0046_;
 wire _0047_;
 wire _0048_;
 wire _0049_;
 wire _0050_;
 wire _0051_;
 wire _0052_;
 wire _0053_;
 wire _0054_;
 wire _0055_;
 wire _0056_;
 wire _0057_;
 wire _0058_;
 wire _0059_;
 wire _0060_;
 wire _0061_;
 wire _0062_;
 wire _0063_;
 wire _0064_;
 wire _0065_;
 wire _0066_;
 wire _0067_;
 wire _0068_;
 wire _0069_;
 wire _0070_;
 wire _0071_;
 wire _0072_;
 wire _0073_;
 wire _0074_;
 wire _0075_;
 wire _0076_;
 wire _0077_;
 wire _0078_;
 wire _0079_;
 wire _0080_;
 wire _0081_;
 wire _0082_;
 wire _0083_;
 wire _0084_;
 wire _0085_;
 wire _0086_;
 wire _0087_;
 wire _0088_;
 wire _0089_;
 wire _0090_;
 wire _0091_;
 wire _0092_;
 wire _0093_;
 wire _0094_;
 wire _0095_;
 wire _0096_;
 wire _0097_;
 wire _0098_;
 wire _0099_;
 wire _0100_;
 wire _0101_;
 wire _0102_;
 wire _0103_;
 wire _0104_;
 wire _0105_;
 wire _0106_;
 wire _0107_;
 wire _0108_;
 wire _0109_;
 wire _0110_;
 wire _0111_;
 wire _0112_;
 wire _0113_;
 wire _0114_;
 wire _0115_;
 wire _0116_;
 wire _0117_;
 wire _0118_;
 wire _0119_;
 wire _0120_;
 wire _0121_;
 wire _0122_;
 wire _0123_;
 wire _0124_;
 wire _0125_;
 wire _0126_;
 wire _0127_;
 wire _0128_;
 wire _0129_;
 wire _0130_;
 wire _0131_;
 wire _0132_;
 wire _0133_;
 wire _0134_;
 wire _0135_;
 wire _0136_;
 wire _0137_;
 wire _0138_;
 wire _0139_;
 wire _0140_;
 wire _0141_;
 wire _0142_;
 wire _0143_;
 wire _0144_;
 wire _0145_;
 wire _0146_;
 wire _0147_;
 wire _0148_;
 wire _0149_;
 wire _0150_;
 wire _0151_;
 wire _0152_;
 wire _0153_;
 wire _0154_;
 wire _0155_;
 wire _0156_;
 wire _0157_;
 wire _0158_;
 wire _0159_;
 wire _0160_;
 wire _0161_;
 wire _0162_;
 wire _0163_;
 wire _0164_;
 wire _0165_;
 wire _0166_;
 wire _0167_;
 wire _0168_;
 wire _0169_;
 wire _0170_;
 wire _0171_;
 wire _0172_;
 wire _0173_;
 wire _0174_;
 wire _0175_;
 wire _0176_;
 wire _0177_;
 wire _0178_;
 wire _0179_;
 wire _0180_;
 wire _0181_;
 wire _0182_;
 wire _0183_;
 wire _0184_;
 wire _0185_;
 wire _0186_;
 wire _0187_;
 wire _0188_;
 wire _0189_;
 wire _0190_;
 wire _0191_;
 wire _0192_;
 wire _0193_;
 wire _0194_;
 wire _0195_;
 wire _0196_;
 wire _0197_;
 wire _0198_;
 wire _0199_;
 wire _0200_;
 wire _0201_;
 wire _0202_;
 wire _0203_;
 wire _0204_;
 wire _0205_;
 wire _0206_;
 wire _0207_;
 wire _0208_;
 wire _0209_;
 wire _0210_;
 wire _0211_;
 wire _0212_;
 wire _0213_;
 wire _0214_;
 wire _0215_;
 wire _0216_;
 wire _0217_;
 wire _0218_;
 wire _0219_;
 wire _0220_;
 wire _0221_;
 wire _0222_;
 wire _0223_;
 wire _0224_;
 wire _0225_;
 wire _0226_;
 wire _0227_;
 wire _0228_;
 wire _0229_;
 wire _0230_;
 wire _0231_;
 wire _0232_;
 wire _0233_;
 wire _0234_;
 wire _0235_;
 wire _0236_;
 wire _0237_;
 wire _0238_;
 wire _0239_;
 wire _0240_;
 wire _0241_;
 wire _0242_;
 wire _0243_;
 wire _0244_;
 wire _0245_;
 wire _0246_;
 wire _0247_;
 wire _0248_;
 wire _0249_;
 wire _0250_;
 wire _0251_;
 wire _0252_;
 wire _0253_;
 wire _0254_;
 wire _0255_;
 wire _0256_;
 wire _0257_;
 wire _0258_;
 wire _0259_;
 wire _0260_;
 wire _0261_;
 wire _0262_;
 wire _0263_;
 wire _0264_;
 wire _0265_;
 wire _0266_;
 wire _0267_;
 wire _0268_;
 wire _0269_;
 wire _0270_;
 wire _0271_;
 wire _0272_;
 wire _0273_;
 wire _0274_;
 wire _0275_;
 wire _0276_;
 wire _0277_;
 wire _0278_;
 wire _0279_;
 wire _0280_;
 wire _0281_;
 wire _0282_;
 wire _0283_;
 wire _0284_;
 wire _0285_;
 wire _0286_;
 wire _0287_;
 wire _0288_;
 wire _0289_;
 wire _0290_;
 wire _0291_;
 wire _0292_;
 wire _0293_;
 wire _0294_;
 wire _0295_;
 wire _0296_;
 wire _0297_;
 wire _0298_;
 wire _0299_;
 wire _0300_;
 wire _0301_;
 wire _0302_;
 wire _0303_;
 wire _0304_;
 wire _0305_;
 wire _0306_;
 wire _0307_;
 wire _0308_;
 wire _0309_;
 wire _0310_;
 wire _0311_;
 wire _0312_;
 wire _0313_;
 wire _0314_;
 wire _0315_;
 wire _0316_;
 wire _0317_;
 wire _0318_;
 wire _0319_;
 wire _0320_;
 wire _0321_;
 wire _0322_;
 wire _0323_;
 wire _0324_;
 wire _0325_;
 wire _0326_;
 wire _0327_;
 wire _0328_;
 wire _0329_;
 wire _0330_;
 wire _0331_;
 wire _0332_;
 wire _0333_;
 wire _0334_;
 wire _0335_;
 wire _0336_;
 wire _0337_;
 wire _0338_;
 wire _0339_;
 wire _0340_;
 wire _0341_;
 wire _0342_;
 wire _0343_;
 wire _0344_;
 wire _0345_;
 wire _0346_;
 wire _0347_;
 wire _0348_;
 wire _0349_;
 wire _0350_;
 wire _0351_;
 wire _0352_;
 wire _0353_;
 wire _0354_;
 wire _0355_;
 wire _0356_;
 wire _0357_;
 wire _0358_;
 wire _0359_;
 wire _0360_;
 wire _0361_;
 wire _0362_;
 wire _0363_;
 wire _0364_;
 wire _0365_;
 wire _0366_;
 wire _0367_;
 wire _0368_;
 wire _0369_;
 wire _0370_;
 wire _0371_;
 wire _0372_;
 wire _0373_;
 wire _0374_;
 wire _0375_;
 wire _0376_;
 wire _0377_;
 wire _0378_;
 wire _0379_;
 wire _0380_;
 wire _0381_;
 wire _0382_;
 wire _0383_;
 wire _0384_;
 wire _0385_;
 wire _0386_;
 wire _0387_;
 wire _0388_;
 wire _0389_;
 wire _0390_;
 wire _0391_;
 wire _0392_;
 wire _0393_;
 wire _0394_;
 wire _0395_;
 wire _0396_;
 wire _0397_;
 wire _0398_;
 wire _0399_;
 wire _0400_;
 wire _0401_;
 wire _0402_;
 wire _0403_;
 wire _0404_;
 wire _0405_;
 wire _0406_;
 wire _0407_;
 wire _0408_;
 wire _0409_;
 wire _0410_;
 wire _0411_;
 wire _0412_;
 wire _0413_;
 wire _0414_;
 wire _0415_;
 wire _0416_;
 wire _0417_;
 wire _0418_;
 wire _0419_;
 wire _0420_;
 wire _0421_;
 wire _0422_;
 wire _0423_;
 wire _0424_;
 wire _0425_;
 wire _0426_;
 wire _0427_;
 wire _0428_;
 wire _0429_;
 wire _0430_;
 wire _0431_;
 wire _0432_;
 wire _0433_;
 wire _0434_;
 wire _0435_;
 wire _0436_;
 wire _0437_;
 wire _0438_;
 wire _0439_;
 wire _0440_;
 wire _0441_;
 wire _0442_;
 wire _0443_;
 wire _0444_;
 wire _0445_;
 wire _0446_;
 wire _0447_;
 wire _0448_;
 wire _0449_;
 wire _0450_;
 wire _0451_;
 wire _0452_;
 wire _0453_;
 wire _0454_;
 wire _0455_;
 wire _0456_;
 wire _0457_;
 wire _0458_;
 wire _0459_;
 wire _0460_;
 wire _0461_;
 wire _0462_;
 wire _0463_;
 wire _0464_;
 wire _0465_;
 wire _0466_;
 wire _0467_;
 wire _0468_;
 wire _0469_;
 wire _0470_;
 wire _0471_;
 wire _0472_;
 wire _0473_;
 wire _0474_;
 wire _0475_;
 wire _0476_;
 wire _0477_;
 wire _0478_;
 wire _0479_;
 wire _0480_;
 wire _0481_;
 wire _0482_;
 wire _0483_;
 wire _0484_;
 wire _0485_;
 wire _0486_;
 wire _0487_;
 wire _0488_;
 wire _0489_;
 wire _0490_;
 wire _0491_;
 wire _0492_;
 wire _0493_;
 wire _0494_;
 wire _0495_;
 wire _0496_;
 wire _0497_;
 wire _0498_;
 wire _0499_;
 wire _0500_;
 wire _0501_;
 wire _0502_;
 wire _0503_;
 wire _0504_;
 wire _0505_;
 wire _0506_;
 wire _0507_;
 wire _0508_;
 wire _0509_;
 wire _0510_;
 wire _0511_;
 wire _0512_;
 wire _0513_;
 wire _0514_;
 wire _0515_;
 wire _0516_;
 wire _0517_;
 wire _0518_;
 wire _0519_;
 wire _0520_;
 wire _0521_;
 wire _0522_;
 wire _0523_;
 wire _0524_;
 wire _0525_;
 wire _0526_;
 wire _0527_;
 wire _0528_;
 wire _0529_;
 wire _0530_;
 wire _0531_;
 wire _0532_;
 wire _0533_;
 wire _0534_;
 wire _0535_;
 wire _0536_;
 wire _0537_;
 wire _0538_;
 wire _0539_;
 wire _0540_;
 wire _0541_;
 wire _0542_;
 wire _0543_;
 wire _0544_;
 wire _0545_;
 wire _0546_;
 wire _0547_;
 wire _0548_;
 wire _0549_;
 wire _0550_;
 wire _0551_;
 wire _0552_;
 wire _0553_;
 wire _0554_;
 wire _0555_;
 wire _0556_;
 wire _0557_;
 wire _0558_;
 wire _0559_;
 wire _0560_;
 wire _0561_;
 wire _0562_;
 wire _0563_;
 wire _0564_;
 wire _0565_;
 wire _0566_;
 wire _0567_;
 wire _0568_;
 wire _0569_;
 wire _0570_;
 wire _0571_;
 wire _0572_;
 wire _0573_;
 wire _0574_;
 wire _0575_;
 wire _0576_;
 wire _0577_;
 wire _0578_;
 wire _0579_;
 wire _0580_;
 wire _0581_;
 wire _0582_;
 wire _0583_;
 wire _0584_;
 wire _0585_;
 wire _0586_;
 wire _0587_;
 wire _0588_;
 wire _0589_;
 wire _0590_;
 wire _0591_;
 wire _0592_;
 wire _0593_;
 wire _0594_;
 wire _0595_;
 wire _0596_;
 wire _0597_;
 wire _0598_;
 wire _0599_;
 wire _0600_;
 wire _0601_;
 wire _0602_;
 wire _0603_;
 wire _0604_;
 wire _0605_;
 wire _0606_;
 wire _0607_;
 wire _0608_;
 wire _0609_;
 wire _0610_;
 wire _0611_;
 wire _0612_;
 wire _0613_;
 wire _0614_;
 wire _0615_;
 wire _0616_;
 wire _0617_;
 wire _0618_;
 wire _0619_;
 wire _0620_;
 wire _0621_;
 wire _0622_;
 wire _0623_;
 wire _0624_;
 wire _0625_;
 wire _0626_;
 wire _0627_;
 wire _0628_;
 wire _0629_;
 wire _0630_;
 wire _0631_;
 wire _0632_;
 wire _0633_;
 wire _0634_;
 wire _0635_;
 wire _0636_;
 wire _0637_;
 wire _0638_;
 wire _0639_;
 wire _0640_;
 wire _0641_;
 wire _0642_;
 wire _0643_;
 wire _0644_;
 wire _0645_;
 wire _0646_;
 wire _0647_;
 wire _0648_;
 wire _0649_;
 wire _0650_;
 wire _0651_;
 wire _0652_;
 wire _0653_;
 wire _0654_;
 wire _0655_;
 wire _0656_;
 wire _0657_;
 wire _0658_;
 wire _0659_;
 wire _0660_;
 wire _0661_;
 wire _0662_;
 wire _0663_;
 wire _0664_;
 wire _0665_;
 wire _0666_;
 wire _0667_;
 wire _0668_;
 wire _0669_;
 wire _0670_;
 wire _0671_;
 wire _0672_;
 wire _0673_;
 wire _0674_;
 wire _0675_;
 wire _0676_;
 wire _0677_;
 wire _0678_;
 wire _0679_;
 wire _0680_;
 wire _0681_;
 wire _0682_;
 wire _0683_;
 wire _0684_;
 wire _0685_;
 wire _0686_;
 wire _0687_;
 wire _0688_;
 wire _0689_;
 wire _0690_;
 wire _0691_;
 wire _0692_;
 wire _0693_;
 wire _0694_;
 wire _0695_;
 wire _0696_;
 wire _0697_;
 wire _0698_;
 wire _0699_;
 wire _0700_;
 wire _0701_;
 wire _0702_;
 wire _0703_;
 wire _0704_;
 wire _0705_;
 wire _0706_;
 wire _0707_;
 wire _0708_;
 wire _0709_;
 wire _0710_;
 wire _0711_;
 wire _0712_;
 wire _0713_;
 wire _0714_;
 wire _0715_;
 wire _0716_;
 wire _0717_;
 wire _0718_;
 wire _0719_;
 wire _0720_;
 wire _0721_;
 wire _0722_;
 wire _0723_;
 wire _0724_;
 wire _0725_;
 wire _0726_;
 wire _0727_;
 wire _0728_;
 wire _0729_;
 wire _0730_;
 wire _0731_;
 wire _0732_;
 wire _0733_;
 wire _0734_;
 wire _0735_;
 wire _0736_;
 wire _0737_;
 wire _0738_;
 wire _0739_;
 wire _0740_;
 wire _0741_;
 wire _0742_;
 wire _0743_;
 wire _0744_;
 wire _0745_;
 wire _0746_;
 wire _0747_;
 wire _0748_;
 wire _0749_;
 wire _0750_;
 wire _0751_;
 wire _0752_;
 wire _0753_;
 wire _0754_;
 wire _0755_;
 wire _0756_;
 wire _0757_;
 wire _0758_;
 wire _0759_;
 wire control_enable;
 wire \escalation_policy_cfg[0] ;
 wire \escalation_policy_cfg[10] ;
 wire \escalation_policy_cfg[11] ;
 wire \escalation_policy_cfg[12] ;
 wire \escalation_policy_cfg[13] ;
 wire \escalation_policy_cfg[14] ;
 wire \escalation_policy_cfg[15] ;
 wire \escalation_policy_cfg[16] ;
 wire \escalation_policy_cfg[17] ;
 wire \escalation_policy_cfg[18] ;
 wire \escalation_policy_cfg[19] ;
 wire \escalation_policy_cfg[1] ;
 wire \escalation_policy_cfg[20] ;
 wire \escalation_policy_cfg[21] ;
 wire \escalation_policy_cfg[22] ;
 wire \escalation_policy_cfg[23] ;
 wire \escalation_policy_cfg[24] ;
 wire \escalation_policy_cfg[25] ;
 wire \escalation_policy_cfg[26] ;
 wire \escalation_policy_cfg[27] ;
 wire \escalation_policy_cfg[28] ;
 wire \escalation_policy_cfg[29] ;
 wire \escalation_policy_cfg[2] ;
 wire \escalation_policy_cfg[30] ;
 wire \escalation_policy_cfg[31] ;
 wire \escalation_policy_cfg[3] ;
 wire \escalation_policy_cfg[4] ;
 wire \escalation_policy_cfg[5] ;
 wire \escalation_policy_cfg[6] ;
 wire \escalation_policy_cfg[7] ;
 wire \escalation_policy_cfg[8] ;
 wire \escalation_policy_cfg[9] ;
 wire fault_clear_pulse;
 wire \fault_mask_cfg[0] ;
 wire \fault_mask_cfg[1] ;
 wire \fault_mask_cfg[2] ;
 wire \fault_mask_cfg[3] ;
 wire \fault_mask_cfg[4] ;
 wire \fault_mask_cfg[5] ;
 wire \fault_mask_cfg[6] ;
 wire \fault_mask_cfg[7] ;
 wire \fault_status_value[0] ;
 wire \fault_status_value[1] ;
 wire \fault_status_value[2] ;
 wire \fault_status_value[3] ;
 wire \fault_status_value[4] ;
 wire \fault_status_value[5] ;
 wire \fault_status_value[6] ;
 wire \fault_status_value[7] ;
 wire \heartbeat_count_value[0] ;
 wire \heartbeat_count_value[10] ;
 wire \heartbeat_count_value[11] ;
 wire \heartbeat_count_value[12] ;
 wire \heartbeat_count_value[13] ;
 wire \heartbeat_count_value[14] ;
 wire \heartbeat_count_value[15] ;
 wire \heartbeat_count_value[16] ;
 wire \heartbeat_count_value[17] ;
 wire \heartbeat_count_value[18] ;
 wire \heartbeat_count_value[19] ;
 wire \heartbeat_count_value[1] ;
 wire \heartbeat_count_value[20] ;
 wire \heartbeat_count_value[21] ;
 wire \heartbeat_count_value[22] ;
 wire \heartbeat_count_value[23] ;
 wire \heartbeat_count_value[24] ;
 wire \heartbeat_count_value[25] ;
 wire \heartbeat_count_value[26] ;
 wire \heartbeat_count_value[27] ;
 wire \heartbeat_count_value[28] ;
 wire \heartbeat_count_value[29] ;
 wire \heartbeat_count_value[2] ;
 wire \heartbeat_count_value[30] ;
 wire \heartbeat_count_value[31] ;
 wire \heartbeat_count_value[3] ;
 wire \heartbeat_count_value[4] ;
 wire \heartbeat_count_value[5] ;
 wire \heartbeat_count_value[6] ;
 wire \heartbeat_count_value[7] ;
 wire \heartbeat_count_value[8] ;
 wire \heartbeat_count_value[9] ;
 wire \irq_clear_pulse[0] ;
 wire \irq_clear_pulse[1] ;
 wire \irq_clear_pulse[2] ;
 wire \irq_clear_pulse[3] ;
 wire irq_enable;
 wire \irq_status_value[0] ;
 wire \irq_status_value[1] ;
 wire \irq_status_value[2] ;
 wire \irq_status_value[3] ;
 wire \reset_count_value[0] ;
 wire \reset_count_value[10] ;
 wire \reset_count_value[11] ;
 wire \reset_count_value[12] ;
 wire \reset_count_value[13] ;
 wire \reset_count_value[14] ;
 wire \reset_count_value[15] ;
 wire \reset_count_value[16] ;
 wire \reset_count_value[17] ;
 wire \reset_count_value[18] ;
 wire \reset_count_value[19] ;
 wire \reset_count_value[1] ;
 wire \reset_count_value[20] ;
 wire \reset_count_value[21] ;
 wire \reset_count_value[22] ;
 wire \reset_count_value[23] ;
 wire \reset_count_value[24] ;
 wire \reset_count_value[25] ;
 wire \reset_count_value[26] ;
 wire \reset_count_value[27] ;
 wire \reset_count_value[28] ;
 wire \reset_count_value[29] ;
 wire \reset_count_value[2] ;
 wire \reset_count_value[30] ;
 wire \reset_count_value[31] ;
 wire \reset_count_value[3] ;
 wire \reset_count_value[4] ;
 wire \reset_count_value[5] ;
 wire \reset_count_value[6] ;
 wire \reset_count_value[7] ;
 wire \reset_count_value[8] ;
 wire \reset_count_value[9] ;
 wire status_escalation_active;
 wire status_fault_pending;
 wire status_healthy;
 wire status_reset_requested;
 wire status_watchdog_expired;
 wire \u_safety_fault_watchdog_controller.event_score[0] ;
 wire \u_safety_fault_watchdog_controller.event_score[10] ;
 wire \u_safety_fault_watchdog_controller.event_score[11] ;
 wire \u_safety_fault_watchdog_controller.event_score[12] ;
 wire \u_safety_fault_watchdog_controller.event_score[13] ;
 wire \u_safety_fault_watchdog_controller.event_score[14] ;
 wire \u_safety_fault_watchdog_controller.event_score[15] ;
 wire \u_safety_fault_watchdog_controller.event_score[16] ;
 wire \u_safety_fault_watchdog_controller.event_score[17] ;
 wire \u_safety_fault_watchdog_controller.event_score[18] ;
 wire \u_safety_fault_watchdog_controller.event_score[19] ;
 wire \u_safety_fault_watchdog_controller.event_score[1] ;
 wire \u_safety_fault_watchdog_controller.event_score[20] ;
 wire \u_safety_fault_watchdog_controller.event_score[21] ;
 wire \u_safety_fault_watchdog_controller.event_score[22] ;
 wire \u_safety_fault_watchdog_controller.event_score[23] ;
 wire \u_safety_fault_watchdog_controller.event_score[24] ;
 wire \u_safety_fault_watchdog_controller.event_score[25] ;
 wire \u_safety_fault_watchdog_controller.event_score[26] ;
 wire \u_safety_fault_watchdog_controller.event_score[27] ;
 wire \u_safety_fault_watchdog_controller.event_score[28] ;
 wire \u_safety_fault_watchdog_controller.event_score[29] ;
 wire \u_safety_fault_watchdog_controller.event_score[2] ;
 wire \u_safety_fault_watchdog_controller.event_score[30] ;
 wire \u_safety_fault_watchdog_controller.event_score[31] ;
 wire \u_safety_fault_watchdog_controller.event_score[3] ;
 wire \u_safety_fault_watchdog_controller.event_score[4] ;
 wire \u_safety_fault_watchdog_controller.event_score[5] ;
 wire \u_safety_fault_watchdog_controller.event_score[6] ;
 wire \u_safety_fault_watchdog_controller.event_score[7] ;
 wire \u_safety_fault_watchdog_controller.event_score[8] ;
 wire \u_safety_fault_watchdog_controller.event_score[9] ;
 wire \u_safety_fault_watchdog_controller.masked_faults[0] ;
 wire \u_safety_fault_watchdog_controller.masked_faults[1] ;
 wire \u_safety_fault_watchdog_controller.masked_faults[2] ;
 wire \u_safety_fault_watchdog_controller.masked_faults[3] ;
 wire \u_safety_fault_watchdog_controller.masked_faults[4] ;
 wire \u_safety_fault_watchdog_controller.masked_faults[5] ;
 wire \u_safety_fault_watchdog_controller.masked_faults[6] ;
 wire \u_safety_fault_watchdog_controller.masked_faults[7] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[0] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[10] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[11] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[12] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[13] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[14] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[15] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[16] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[17] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[18] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[19] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[1] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[20] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[21] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[22] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[23] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[24] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[25] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[26] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[27] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[28] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[29] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[2] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[30] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[31] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[3] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[4] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[5] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[6] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[7] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[8] ;
 wire \u_safety_fault_watchdog_controller.watchdog_counter[9] ;
 wire \u_safety_fault_watchdog_controller.watchdog_enable ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[0] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[10] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[11] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[12] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[13] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[14] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[15] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[16] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[17] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[18] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[19] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[1] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[20] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[21] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[22] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[23] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[24] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[25] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[26] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[27] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[28] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[29] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[2] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[30] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[31] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[3] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[4] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[5] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[6] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[7] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[8] ;
 wire \u_safety_fault_watchdog_controller.watchdog_timeout_cfg[9] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[0] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[10] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[11] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[12] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[13] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[14] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[15] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[16] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[17] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[18] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[19] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[1] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[20] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[21] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[22] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[23] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[24] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[25] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[26] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[27] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[28] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[29] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[2] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[30] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[31] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[3] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[4] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[5] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[6] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[7] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[8] ;
 wire \u_safety_fault_watchdog_mmio.control_reg[9] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[0] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[10] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[11] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[12] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[13] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[14] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[15] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[16] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[17] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[18] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[19] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[1] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[20] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[21] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[22] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[23] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[24] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[25] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[26] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[27] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[28] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[29] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[2] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[30] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[31] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[3] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[4] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[5] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[6] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[7] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[8] ;
 wire \u_safety_fault_watchdog_mmio.irq_clear_reg[9] ;

 sky130_fd_sc_hd__inv_2 _0760_ (.A(\u_safety_fault_watchdog_controller.event_score[0] ),
    .Y(_0534_));
 sky130_fd_sc_hd__inv_2 _0761_ (.A(\u_safety_fault_watchdog_controller.event_score[7] ),
    .Y(_0535_));
 sky130_fd_sc_hd__inv_2 _0762_ (.A(\escalation_policy_cfg[23] ),
    .Y(_0536_));
 sky130_fd_sc_hd__inv_2 _0763_ (.A(\u_safety_fault_watchdog_controller.event_score[6] ),
    .Y(_0537_));
 sky130_fd_sc_hd__inv_2 _0764_ (.A(\u_safety_fault_watchdog_controller.event_score[5] ),
    .Y(_0538_));
 sky130_fd_sc_hd__inv_2 _0765_ (.A(\u_safety_fault_watchdog_controller.event_score[4] ),
    .Y(_0539_));
 sky130_fd_sc_hd__inv_2 _0766_ (.A(\u_safety_fault_watchdog_controller.event_score[3] ),
    .Y(_0540_));
 sky130_fd_sc_hd__inv_2 _0767_ (.A(\u_safety_fault_watchdog_controller.event_score[2] ),
    .Y(_0541_));
 sky130_fd_sc_hd__inv_2 _0768_ (.A(\u_safety_fault_watchdog_controller.event_score[1] ),
    .Y(_0542_));
 sky130_fd_sc_hd__inv_2 _0769_ (.A(\irq_clear_pulse[3] ),
    .Y(_0543_));
 sky130_fd_sc_hd__inv_2 _0770_ (.A(wr_data[3]),
    .Y(_0544_));
 sky130_fd_sc_hd__inv_2 _0771_ (.A(\reset_count_value[30] ),
    .Y(_0545_));
 sky130_fd_sc_hd__or2_2 _0772_ (.A(_0541_),
    .B(\escalation_policy_cfg[18] ),
    .X(_0546_));
 sky130_fd_sc_hd__and2b_2 _0773_ (.A_N(\u_safety_fault_watchdog_controller.event_score[1] ),
    .B(\escalation_policy_cfg[17] ),
    .X(_0547_));
 sky130_fd_sc_hd__nand2b_2 _0774_ (.A_N(\escalation_policy_cfg[17] ),
    .B(\u_safety_fault_watchdog_controller.event_score[1] ),
    .Y(_0548_));
 sky130_fd_sc_hd__a31o_2 _0775_ (.A1(_0534_),
    .A2(\escalation_policy_cfg[16] ),
    .A3(_0548_),
    .B1(_0547_),
    .X(_0549_));
 sky130_fd_sc_hd__and2_2 _0776_ (.A(_0541_),
    .B(\escalation_policy_cfg[18] ),
    .X(_0550_));
 sky130_fd_sc_hd__a221o_2 _0777_ (.A1(_0540_),
    .A2(\escalation_policy_cfg[19] ),
    .B1(_0546_),
    .B2(_0549_),
    .C1(_0550_),
    .X(_0551_));
 sky130_fd_sc_hd__or2_2 _0778_ (.A(_0540_),
    .B(\escalation_policy_cfg[19] ),
    .X(_0552_));
 sky130_fd_sc_hd__or2_2 _0779_ (.A(\escalation_policy_cfg[20] ),
    .B(_0539_),
    .X(_0553_));
 sky130_fd_sc_hd__a22o_2 _0780_ (.A1(_0538_),
    .A2(\escalation_policy_cfg[21] ),
    .B1(\escalation_policy_cfg[20] ),
    .B2(_0539_),
    .X(_0554_));
 sky130_fd_sc_hd__a31o_2 _0781_ (.A1(_0551_),
    .A2(_0552_),
    .A3(_0553_),
    .B1(_0554_),
    .X(_0555_));
 sky130_fd_sc_hd__o22a_2 _0782_ (.A1(_0537_),
    .A2(\escalation_policy_cfg[22] ),
    .B1(_0538_),
    .B2(\escalation_policy_cfg[21] ),
    .X(_0556_));
 sky130_fd_sc_hd__a22o_2 _0783_ (.A1(_0535_),
    .A2(\escalation_policy_cfg[23] ),
    .B1(_0537_),
    .B2(\escalation_policy_cfg[22] ),
    .X(_0557_));
 sky130_fd_sc_hd__a21o_2 _0784_ (.A1(_0555_),
    .A2(_0556_),
    .B1(_0557_),
    .X(_0558_));
 sky130_fd_sc_hd__or4_2 _0785_ (.A(\u_safety_fault_watchdog_controller.event_score[11] ),
    .B(\u_safety_fault_watchdog_controller.event_score[10] ),
    .C(\u_safety_fault_watchdog_controller.event_score[8] ),
    .D(\u_safety_fault_watchdog_controller.event_score[9] ),
    .X(_0559_));
 sky130_fd_sc_hd__or4_2 _0786_ (.A(\u_safety_fault_watchdog_controller.event_score[15] ),
    .B(\u_safety_fault_watchdog_controller.event_score[14] ),
    .C(\u_safety_fault_watchdog_controller.event_score[13] ),
    .D(\u_safety_fault_watchdog_controller.event_score[12] ),
    .X(_0560_));
 sky130_fd_sc_hd__or4_2 _0787_ (.A(\u_safety_fault_watchdog_controller.event_score[18] ),
    .B(\u_safety_fault_watchdog_controller.event_score[19] ),
    .C(\u_safety_fault_watchdog_controller.event_score[17] ),
    .D(\u_safety_fault_watchdog_controller.event_score[16] ),
    .X(_0561_));
 sky130_fd_sc_hd__or4_2 _0788_ (.A(\u_safety_fault_watchdog_controller.event_score[25] ),
    .B(\u_safety_fault_watchdog_controller.event_score[24] ),
    .C(\u_safety_fault_watchdog_controller.event_score[26] ),
    .D(\u_safety_fault_watchdog_controller.event_score[27] ),
    .X(_0562_));
 sky130_fd_sc_hd__or4_2 _0789_ (.A(\u_safety_fault_watchdog_controller.event_score[23] ),
    .B(\u_safety_fault_watchdog_controller.event_score[22] ),
    .C(\u_safety_fault_watchdog_controller.event_score[20] ),
    .D(\u_safety_fault_watchdog_controller.event_score[21] ),
    .X(_0563_));
 sky130_fd_sc_hd__or4_2 _0790_ (.A(\u_safety_fault_watchdog_controller.event_score[30] ),
    .B(\u_safety_fault_watchdog_controller.event_score[31] ),
    .C(\u_safety_fault_watchdog_controller.event_score[29] ),
    .D(\u_safety_fault_watchdog_controller.event_score[28] ),
    .X(_0564_));
 sky130_fd_sc_hd__a2111o_2 _0791_ (.A1(\u_safety_fault_watchdog_controller.event_score[7] ),
    .A2(_0536_),
    .B1(_0562_),
    .C1(_0563_),
    .D1(_0564_),
    .X(_0565_));
 sky130_fd_sc_hd__nor4_2 _0792_ (.A(_0559_),
    .B(_0560_),
    .C(_0561_),
    .D(_0565_),
    .Y(_0566_));
 sky130_fd_sc_hd__nand2_2 _0793_ (.A(_0558_),
    .B(_0566_),
    .Y(_0567_));
 sky130_fd_sc_hd__a22o_2 _0794_ (.A1(_0535_),
    .A2(\escalation_policy_cfg[15] ),
    .B1(\escalation_policy_cfg[14] ),
    .B2(_0537_),
    .X(_0568_));
 sky130_fd_sc_hd__a22o_2 _0795_ (.A1(_0538_),
    .A2(\escalation_policy_cfg[13] ),
    .B1(\escalation_policy_cfg[12] ),
    .B2(_0539_),
    .X(_0569_));
 sky130_fd_sc_hd__a22o_2 _0796_ (.A1(_0540_),
    .A2(\escalation_policy_cfg[11] ),
    .B1(\escalation_policy_cfg[10] ),
    .B2(_0541_),
    .X(_0570_));
 sky130_fd_sc_hd__and2b_2 _0797_ (.A_N(\u_safety_fault_watchdog_controller.event_score[1] ),
    .B(\escalation_policy_cfg[9] ),
    .X(_0571_));
 sky130_fd_sc_hd__and2b_2 _0798_ (.A_N(\u_safety_fault_watchdog_controller.event_score[0] ),
    .B(\escalation_policy_cfg[8] ),
    .X(_0572_));
 sky130_fd_sc_hd__nand2b_2 _0799_ (.A_N(\escalation_policy_cfg[9] ),
    .B(\u_safety_fault_watchdog_controller.event_score[1] ),
    .Y(_0573_));
 sky130_fd_sc_hd__o221a_2 _0800_ (.A1(_0541_),
    .A2(\escalation_policy_cfg[10] ),
    .B1(_0571_),
    .B2(_0572_),
    .C1(_0573_),
    .X(_0574_));
 sky130_fd_sc_hd__o22a_2 _0801_ (.A1(_0540_),
    .A2(\escalation_policy_cfg[11] ),
    .B1(\escalation_policy_cfg[12] ),
    .B2(_0539_),
    .X(_0575_));
 sky130_fd_sc_hd__o21a_2 _0802_ (.A1(_0570_),
    .A2(_0574_),
    .B1(_0575_),
    .X(_0576_));
 sky130_fd_sc_hd__o22a_2 _0803_ (.A1(_0537_),
    .A2(\escalation_policy_cfg[14] ),
    .B1(\escalation_policy_cfg[13] ),
    .B2(_0538_),
    .X(_0577_));
 sky130_fd_sc_hd__o21a_2 _0804_ (.A1(_0569_),
    .A2(_0576_),
    .B1(_0577_),
    .X(_0578_));
 sky130_fd_sc_hd__o22a_2 _0805_ (.A1(_0535_),
    .A2(\escalation_policy_cfg[15] ),
    .B1(_0568_),
    .B2(_0578_),
    .X(_0579_));
 sky130_fd_sc_hd__o211a_2 _0806_ (.A1(_0542_),
    .A2(\escalation_policy_cfg[1] ),
    .B1(\escalation_policy_cfg[0] ),
    .C1(_0534_),
    .X(_0580_));
 sky130_fd_sc_hd__a221o_2 _0807_ (.A1(_0542_),
    .A2(\escalation_policy_cfg[1] ),
    .B1(\escalation_policy_cfg[2] ),
    .B2(_0541_),
    .C1(_0580_),
    .X(_0581_));
 sky130_fd_sc_hd__o221a_2 _0808_ (.A1(_0540_),
    .A2(\escalation_policy_cfg[3] ),
    .B1(\escalation_policy_cfg[2] ),
    .B2(_0541_),
    .C1(_0581_),
    .X(_0582_));
 sky130_fd_sc_hd__a221o_2 _0809_ (.A1(_0540_),
    .A2(\escalation_policy_cfg[3] ),
    .B1(\escalation_policy_cfg[4] ),
    .B2(_0539_),
    .C1(_0582_),
    .X(_0583_));
 sky130_fd_sc_hd__o22a_2 _0810_ (.A1(_0538_),
    .A2(\escalation_policy_cfg[5] ),
    .B1(\escalation_policy_cfg[4] ),
    .B2(_0539_),
    .X(_0584_));
 sky130_fd_sc_hd__a22o_2 _0811_ (.A1(_0537_),
    .A2(\escalation_policy_cfg[6] ),
    .B1(\escalation_policy_cfg[5] ),
    .B2(_0538_),
    .X(_0585_));
 sky130_fd_sc_hd__a21o_2 _0812_ (.A1(_0583_),
    .A2(_0584_),
    .B1(_0585_),
    .X(_0586_));
 sky130_fd_sc_hd__o22a_2 _0813_ (.A1(_0535_),
    .A2(\escalation_policy_cfg[7] ),
    .B1(\escalation_policy_cfg[6] ),
    .B2(_0537_),
    .X(_0587_));
 sky130_fd_sc_hd__a22oi_2 _0814_ (.A1(_0535_),
    .A2(\escalation_policy_cfg[7] ),
    .B1(_0586_),
    .B2(_0587_),
    .Y(_0588_));
 sky130_fd_sc_hd__a21o_2 _0815_ (.A1(_0579_),
    .A2(_0588_),
    .B1(_0567_),
    .X(_0041_));
 sky130_fd_sc_hd__and3_2 _0816_ (.A(_0558_),
    .B(_0566_),
    .C(_0579_),
    .X(_0589_));
 sky130_fd_sc_hd__inv_2 _0817_ (.A(_0589_),
    .Y(_0042_));
 sky130_fd_sc_hd__or2_2 _0818_ (.A(_0588_),
    .B(_0042_),
    .X(_0000_));
 sky130_fd_sc_hd__or4_2 _0819_ (.A(fault_latched[5]),
    .B(fault_latched[4]),
    .C(fault_latched[7]),
    .D(fault_latched[6]),
    .X(_0590_));
 sky130_fd_sc_hd__or4_2 _0820_ (.A(fault_latched[1]),
    .B(fault_latched[0]),
    .C(fault_latched[3]),
    .D(fault_latched[2]),
    .X(_0591_));
 sky130_fd_sc_hd__or2_2 _0821_ (.A(_0590_),
    .B(_0591_),
    .X(_0002_));
 sky130_fd_sc_hd__or3b_2 _0822_ (.A(wr_addr[1]),
    .B(wr_addr[0]),
    .C_N(wr_en),
    .X(_0592_));
 sky130_fd_sc_hd__or4_2 _0823_ (.A(wr_addr[9]),
    .B(wr_addr[8]),
    .C(wr_addr[11]),
    .D(wr_addr[10]),
    .X(_0593_));
 sky130_fd_sc_hd__or4_2 _0824_ (.A(wr_addr[3]),
    .B(wr_addr[2]),
    .C(_0592_),
    .D(_0593_),
    .X(_0594_));
 sky130_fd_sc_hd__or2_2 _0825_ (.A(wr_addr[7]),
    .B(wr_addr[6]),
    .X(_0595_));
 sky130_fd_sc_hd__or4_2 _0826_ (.A(wr_addr[4]),
    .B(wr_addr[5]),
    .C(_0594_),
    .D(_0595_),
    .X(_0596_));
 sky130_fd_sc_hd__nor2_2 _0827_ (.A(_0544_),
    .B(_0596_),
    .Y(_0036_));
 sky130_fd_sc_hd__nand2_2 _0828_ (.A(wr_addr[2]),
    .B(wr_addr[5]),
    .Y(_0597_));
 sky130_fd_sc_hd__or4_2 _0829_ (.A(wr_addr[4]),
    .B(_0592_),
    .C(_0595_),
    .D(_0597_),
    .X(_0598_));
 sky130_fd_sc_hd__nor3_2 _0830_ (.A(wr_addr[3]),
    .B(_0593_),
    .C(_0598_),
    .Y(_0599_));
 sky130_fd_sc_hd__and2_2 _0831_ (.A(wr_data[0]),
    .B(_0599_),
    .X(_0037_));
 sky130_fd_sc_hd__and2_2 _0832_ (.A(wr_data[1]),
    .B(_0599_),
    .X(_0038_));
 sky130_fd_sc_hd__and2_2 _0833_ (.A(wr_data[2]),
    .B(_0599_),
    .X(_0039_));
 sky130_fd_sc_hd__and2_2 _0834_ (.A(wr_data[3]),
    .B(_0599_),
    .X(_0040_));
 sky130_fd_sc_hd__nand3b_2 _0835_ (.A_N(heartbeat),
    .B(control_enable),
    .C(\u_safety_fault_watchdog_controller.watchdog_enable ),
    .Y(_0600_));
 sky130_fd_sc_hd__inv_2 _0836_ (.A(_0600_),
    .Y(_0601_));
 sky130_fd_sc_hd__or3_2 _0837_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[1] ),
    .B(\u_safety_fault_watchdog_controller.watchdog_counter[0] ),
    .C(\u_safety_fault_watchdog_controller.watchdog_counter[2] ),
    .X(_0602_));
 sky130_fd_sc_hd__or4_2 _0838_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[1] ),
    .B(\u_safety_fault_watchdog_controller.watchdog_counter[0] ),
    .C(\u_safety_fault_watchdog_controller.watchdog_counter[3] ),
    .D(\u_safety_fault_watchdog_controller.watchdog_counter[2] ),
    .X(_0603_));
 sky130_fd_sc_hd__or2_2 _0839_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[4] ),
    .B(_0603_),
    .X(_0604_));
 sky130_fd_sc_hd__or3_2 _0840_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[5] ),
    .B(\u_safety_fault_watchdog_controller.watchdog_counter[4] ),
    .C(\u_safety_fault_watchdog_controller.watchdog_counter[6] ),
    .X(_0605_));
 sky130_fd_sc_hd__or3_2 _0841_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[7] ),
    .B(_0603_),
    .C(_0605_),
    .X(_0606_));
 sky130_fd_sc_hd__or2_2 _0842_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[8] ),
    .B(_0606_),
    .X(_0607_));
 sky130_fd_sc_hd__or4_2 _0843_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[9] ),
    .B(\u_safety_fault_watchdog_controller.watchdog_counter[8] ),
    .C(\u_safety_fault_watchdog_controller.watchdog_counter[11] ),
    .D(\u_safety_fault_watchdog_controller.watchdog_counter[10] ),
    .X(_0608_));
 sky130_fd_sc_hd__or3_2 _0844_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[12] ),
    .B(_0606_),
    .C(_0608_),
    .X(_0609_));
 sky130_fd_sc_hd__or2_2 _0845_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[13] ),
    .B(_0609_),
    .X(_0610_));
 sky130_fd_sc_hd__or4_2 _0846_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[13] ),
    .B(\u_safety_fault_watchdog_controller.watchdog_counter[12] ),
    .C(\u_safety_fault_watchdog_controller.watchdog_counter[15] ),
    .D(\u_safety_fault_watchdog_controller.watchdog_counter[14] ),
    .X(_0611_));
 sky130_fd_sc_hd__or4_2 _0847_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[16] ),
    .B(_0606_),
    .C(_0608_),
    .D(_0611_),
    .X(_0612_));
 sky130_fd_sc_hd__or4_2 _0848_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[21] ),
    .B(\u_safety_fault_watchdog_controller.watchdog_counter[20] ),
    .C(\u_safety_fault_watchdog_controller.watchdog_counter[23] ),
    .D(\u_safety_fault_watchdog_controller.watchdog_counter[22] ),
    .X(_0613_));
 sky130_fd_sc_hd__or4_2 _0849_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[17] ),
    .B(\u_safety_fault_watchdog_controller.watchdog_counter[19] ),
    .C(\u_safety_fault_watchdog_controller.watchdog_counter[18] ),
    .D(_0613_),
    .X(_0614_));
 sky130_fd_sc_hd__or3_2 _0850_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[24] ),
    .B(_0612_),
    .C(_0614_),
    .X(_0615_));
 sky130_fd_sc_hd__or2_2 _0851_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[25] ),
    .B(_0615_),
    .X(_0616_));
 sky130_fd_sc_hd__or4_2 _0852_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[25] ),
    .B(\u_safety_fault_watchdog_controller.watchdog_counter[24] ),
    .C(\u_safety_fault_watchdog_controller.watchdog_counter[27] ),
    .D(\u_safety_fault_watchdog_controller.watchdog_counter[26] ),
    .X(_0617_));
 sky130_fd_sc_hd__or3_2 _0853_ (.A(_0612_),
    .B(_0614_),
    .C(_0617_),
    .X(_0618_));
 sky130_fd_sc_hd__or2_2 _0854_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[28] ),
    .B(_0618_),
    .X(_0619_));
 sky130_fd_sc_hd__nor2_2 _0855_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[29] ),
    .B(_0619_),
    .Y(_0620_));
 sky130_fd_sc_hd__or4_2 _0856_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[29] ),
    .B(\u_safety_fault_watchdog_controller.watchdog_counter[28] ),
    .C(\u_safety_fault_watchdog_controller.watchdog_counter[31] ),
    .D(\u_safety_fault_watchdog_controller.watchdog_counter[30] ),
    .X(_0621_));
 sky130_fd_sc_hd__nor2_2 _0857_ (.A(_0618_),
    .B(_0621_),
    .Y(_0622_));
 sky130_fd_sc_hd__nor2_2 _0858_ (.A(_0600_),
    .B(_0622_),
    .Y(_0623_));
 sky130_fd_sc_hd__or2_2 _0859_ (.A(_0600_),
    .B(_0622_),
    .X(_0624_));
 sky130_fd_sc_hd__a2bb2o_2 _0860_ (.A1_N(\u_safety_fault_watchdog_controller.watchdog_counter[0] ),
    .A2_N(_0624_),
    .B1(_0600_),
    .B2(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[0] ),
    .X(_0004_));
 sky130_fd_sc_hd__xnor2_2 _0861_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[1] ),
    .B(\u_safety_fault_watchdog_controller.watchdog_counter[0] ),
    .Y(_0625_));
 sky130_fd_sc_hd__a22o_2 _0862_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[1] ),
    .A2(_0600_),
    .B1(_0623_),
    .B2(_0625_),
    .X(_0015_));
 sky130_fd_sc_hd__o21ai_2 _0863_ (.A1(\u_safety_fault_watchdog_controller.watchdog_counter[1] ),
    .A2(\u_safety_fault_watchdog_controller.watchdog_counter[0] ),
    .B1(\u_safety_fault_watchdog_controller.watchdog_counter[2] ),
    .Y(_0626_));
 sky130_fd_sc_hd__nand2_2 _0864_ (.A(_0602_),
    .B(_0626_),
    .Y(_0627_));
 sky130_fd_sc_hd__a22o_2 _0865_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[2] ),
    .A2(_0600_),
    .B1(_0623_),
    .B2(_0627_),
    .X(_0026_));
 sky130_fd_sc_hd__nand2_2 _0866_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[3] ),
    .B(_0602_),
    .Y(_0628_));
 sky130_fd_sc_hd__nand2_2 _0867_ (.A(_0603_),
    .B(_0628_),
    .Y(_0629_));
 sky130_fd_sc_hd__a22o_2 _0868_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[3] ),
    .A2(_0600_),
    .B1(_0623_),
    .B2(_0629_),
    .X(_0029_));
 sky130_fd_sc_hd__nand2_2 _0869_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[4] ),
    .B(_0603_),
    .Y(_0630_));
 sky130_fd_sc_hd__nand2_2 _0870_ (.A(_0604_),
    .B(_0630_),
    .Y(_0631_));
 sky130_fd_sc_hd__a22o_2 _0871_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[4] ),
    .A2(_0600_),
    .B1(_0623_),
    .B2(_0631_),
    .X(_0030_));
 sky130_fd_sc_hd__xnor2_2 _0872_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[5] ),
    .B(_0604_),
    .Y(_0632_));
 sky130_fd_sc_hd__a22o_2 _0873_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[5] ),
    .A2(_0600_),
    .B1(_0623_),
    .B2(_0632_),
    .X(_0031_));
 sky130_fd_sc_hd__o21a_2 _0874_ (.A1(\u_safety_fault_watchdog_controller.watchdog_counter[5] ),
    .A2(_0604_),
    .B1(\u_safety_fault_watchdog_controller.watchdog_counter[6] ),
    .X(_0633_));
 sky130_fd_sc_hd__o21bai_2 _0875_ (.A1(_0603_),
    .A2(_0605_),
    .B1_N(_0633_),
    .Y(_0634_));
 sky130_fd_sc_hd__a22o_2 _0876_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[6] ),
    .A2(_0600_),
    .B1(_0623_),
    .B2(_0634_),
    .X(_0032_));
 sky130_fd_sc_hd__o21ai_2 _0877_ (.A1(_0603_),
    .A2(_0605_),
    .B1(\u_safety_fault_watchdog_controller.watchdog_counter[7] ),
    .Y(_0635_));
 sky130_fd_sc_hd__a21oi_2 _0878_ (.A1(_0606_),
    .A2(_0635_),
    .B1(_0624_),
    .Y(_0636_));
 sky130_fd_sc_hd__a21o_2 _0879_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[7] ),
    .A2(_0600_),
    .B1(_0636_),
    .X(_0033_));
 sky130_fd_sc_hd__nand2_2 _0880_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[8] ),
    .B(_0606_),
    .Y(_0637_));
 sky130_fd_sc_hd__nand2_2 _0881_ (.A(_0607_),
    .B(_0637_),
    .Y(_0638_));
 sky130_fd_sc_hd__a22o_2 _0882_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[8] ),
    .A2(_0600_),
    .B1(_0623_),
    .B2(_0638_),
    .X(_0034_));
 sky130_fd_sc_hd__xnor2_2 _0883_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[9] ),
    .B(_0607_),
    .Y(_0639_));
 sky130_fd_sc_hd__a22o_2 _0884_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[9] ),
    .A2(_0600_),
    .B1(_0623_),
    .B2(_0639_),
    .X(_0035_));
 sky130_fd_sc_hd__or3_2 _0885_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[9] ),
    .B(\u_safety_fault_watchdog_controller.watchdog_counter[10] ),
    .C(_0607_),
    .X(_0640_));
 sky130_fd_sc_hd__o21ai_2 _0886_ (.A1(\u_safety_fault_watchdog_controller.watchdog_counter[9] ),
    .A2(_0607_),
    .B1(\u_safety_fault_watchdog_controller.watchdog_counter[10] ),
    .Y(_0641_));
 sky130_fd_sc_hd__nand2_2 _0887_ (.A(_0640_),
    .B(_0641_),
    .Y(_0642_));
 sky130_fd_sc_hd__a22o_2 _0888_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[10] ),
    .A2(_0600_),
    .B1(_0623_),
    .B2(_0642_),
    .X(_0005_));
 sky130_fd_sc_hd__a2bb2o_2 _0889_ (.A1_N(_0606_),
    .A2_N(_0608_),
    .B1(_0640_),
    .B2(\u_safety_fault_watchdog_controller.watchdog_counter[11] ),
    .X(_0643_));
 sky130_fd_sc_hd__a22o_2 _0890_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[11] ),
    .A2(_0600_),
    .B1(_0623_),
    .B2(_0643_),
    .X(_0006_));
 sky130_fd_sc_hd__o21ai_2 _0891_ (.A1(_0606_),
    .A2(_0608_),
    .B1(\u_safety_fault_watchdog_controller.watchdog_counter[12] ),
    .Y(_0644_));
 sky130_fd_sc_hd__nand2_2 _0892_ (.A(_0609_),
    .B(_0644_),
    .Y(_0645_));
 sky130_fd_sc_hd__a22o_2 _0893_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[12] ),
    .A2(_0600_),
    .B1(_0623_),
    .B2(_0645_),
    .X(_0007_));
 sky130_fd_sc_hd__nand2_2 _0894_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[13] ),
    .B(_0609_),
    .Y(_0646_));
 sky130_fd_sc_hd__a21oi_2 _0895_ (.A1(_0610_),
    .A2(_0646_),
    .B1(_0624_),
    .Y(_0647_));
 sky130_fd_sc_hd__a21o_2 _0896_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[13] ),
    .A2(_0600_),
    .B1(_0647_),
    .X(_0008_));
 sky130_fd_sc_hd__xnor2_2 _0897_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[14] ),
    .B(_0610_),
    .Y(_0648_));
 sky130_fd_sc_hd__a22o_2 _0898_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[14] ),
    .A2(_0600_),
    .B1(_0623_),
    .B2(_0648_),
    .X(_0009_));
 sky130_fd_sc_hd__or3b_2 _0899_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[14] ),
    .B(_0610_),
    .C_N(\u_safety_fault_watchdog_controller.watchdog_counter[15] ),
    .X(_0649_));
 sky130_fd_sc_hd__o21bai_2 _0900_ (.A1(\u_safety_fault_watchdog_controller.watchdog_counter[14] ),
    .A2(_0610_),
    .B1_N(\u_safety_fault_watchdog_controller.watchdog_counter[15] ),
    .Y(_0650_));
 sky130_fd_sc_hd__a32o_2 _0901_ (.A1(_0623_),
    .A2(_0649_),
    .A3(_0650_),
    .B1(_0600_),
    .B2(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[15] ),
    .X(_0010_));
 sky130_fd_sc_hd__o31ai_2 _0902_ (.A1(_0606_),
    .A2(_0608_),
    .A3(_0611_),
    .B1(\u_safety_fault_watchdog_controller.watchdog_counter[16] ),
    .Y(_0651_));
 sky130_fd_sc_hd__nand2_2 _0903_ (.A(_0612_),
    .B(_0651_),
    .Y(_0652_));
 sky130_fd_sc_hd__a22o_2 _0904_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[16] ),
    .A2(_0600_),
    .B1(_0623_),
    .B2(_0652_),
    .X(_0011_));
 sky130_fd_sc_hd__or2_2 _0905_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[17] ),
    .B(_0612_),
    .X(_0653_));
 sky130_fd_sc_hd__nand2_2 _0906_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[17] ),
    .B(_0612_),
    .Y(_0654_));
 sky130_fd_sc_hd__nand2_2 _0907_ (.A(_0653_),
    .B(_0654_),
    .Y(_0655_));
 sky130_fd_sc_hd__a22o_2 _0908_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[17] ),
    .A2(_0600_),
    .B1(_0623_),
    .B2(_0655_),
    .X(_0012_));
 sky130_fd_sc_hd__or2_2 _0909_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[18] ),
    .B(_0653_),
    .X(_0656_));
 sky130_fd_sc_hd__nand2_2 _0910_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[18] ),
    .B(_0653_),
    .Y(_0657_));
 sky130_fd_sc_hd__nand2_2 _0911_ (.A(_0656_),
    .B(_0657_),
    .Y(_0658_));
 sky130_fd_sc_hd__a22o_2 _0912_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[18] ),
    .A2(_0600_),
    .B1(_0623_),
    .B2(_0658_),
    .X(_0013_));
 sky130_fd_sc_hd__or2_2 _0913_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[19] ),
    .B(_0656_),
    .X(_0659_));
 sky130_fd_sc_hd__xnor2_2 _0914_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[19] ),
    .B(_0656_),
    .Y(_0660_));
 sky130_fd_sc_hd__a22o_2 _0915_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[19] ),
    .A2(_0600_),
    .B1(_0623_),
    .B2(_0660_),
    .X(_0014_));
 sky130_fd_sc_hd__or2_2 _0916_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[20] ),
    .B(_0659_),
    .X(_0661_));
 sky130_fd_sc_hd__nand2_2 _0917_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[20] ),
    .B(_0659_),
    .Y(_0662_));
 sky130_fd_sc_hd__nand2_2 _0918_ (.A(_0661_),
    .B(_0662_),
    .Y(_0663_));
 sky130_fd_sc_hd__a22o_2 _0919_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[20] ),
    .A2(_0600_),
    .B1(_0623_),
    .B2(_0663_),
    .X(_0016_));
 sky130_fd_sc_hd__xnor2_2 _0920_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[21] ),
    .B(_0661_),
    .Y(_0664_));
 sky130_fd_sc_hd__a22o_2 _0921_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[21] ),
    .A2(_0600_),
    .B1(_0623_),
    .B2(_0664_),
    .X(_0017_));
 sky130_fd_sc_hd__o21ai_2 _0922_ (.A1(\u_safety_fault_watchdog_controller.watchdog_counter[21] ),
    .A2(_0661_),
    .B1(\u_safety_fault_watchdog_controller.watchdog_counter[22] ),
    .Y(_0665_));
 sky130_fd_sc_hd__or3_2 _0923_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[21] ),
    .B(\u_safety_fault_watchdog_controller.watchdog_counter[22] ),
    .C(_0661_),
    .X(_0666_));
 sky130_fd_sc_hd__nand2_2 _0924_ (.A(_0665_),
    .B(_0666_),
    .Y(_0667_));
 sky130_fd_sc_hd__a22o_2 _0925_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[22] ),
    .A2(_0600_),
    .B1(_0623_),
    .B2(_0667_),
    .X(_0018_));
 sky130_fd_sc_hd__xnor2_2 _0926_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[23] ),
    .B(_0666_),
    .Y(_0668_));
 sky130_fd_sc_hd__a22o_2 _0927_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[23] ),
    .A2(_0600_),
    .B1(_0623_),
    .B2(_0668_),
    .X(_0019_));
 sky130_fd_sc_hd__o21ai_2 _0928_ (.A1(_0612_),
    .A2(_0614_),
    .B1(\u_safety_fault_watchdog_controller.watchdog_counter[24] ),
    .Y(_0669_));
 sky130_fd_sc_hd__nand2_2 _0929_ (.A(_0615_),
    .B(_0669_),
    .Y(_0670_));
 sky130_fd_sc_hd__a22o_2 _0930_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[24] ),
    .A2(_0600_),
    .B1(_0623_),
    .B2(_0670_),
    .X(_0020_));
 sky130_fd_sc_hd__nand2_2 _0931_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[25] ),
    .B(_0615_),
    .Y(_0671_));
 sky130_fd_sc_hd__nand2_2 _0932_ (.A(_0616_),
    .B(_0671_),
    .Y(_0672_));
 sky130_fd_sc_hd__a22o_2 _0933_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[25] ),
    .A2(_0600_),
    .B1(_0623_),
    .B2(_0672_),
    .X(_0021_));
 sky130_fd_sc_hd__xnor2_2 _0934_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[26] ),
    .B(_0616_),
    .Y(_0673_));
 sky130_fd_sc_hd__a22o_2 _0935_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[26] ),
    .A2(_0600_),
    .B1(_0623_),
    .B2(_0673_),
    .X(_0022_));
 sky130_fd_sc_hd__o21ai_2 _0936_ (.A1(\u_safety_fault_watchdog_controller.watchdog_counter[26] ),
    .A2(_0616_),
    .B1(\u_safety_fault_watchdog_controller.watchdog_counter[27] ),
    .Y(_0674_));
 sky130_fd_sc_hd__nand2_2 _0937_ (.A(_0618_),
    .B(_0674_),
    .Y(_0675_));
 sky130_fd_sc_hd__a22o_2 _0938_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[27] ),
    .A2(_0600_),
    .B1(_0623_),
    .B2(_0675_),
    .X(_0023_));
 sky130_fd_sc_hd__xnor2_2 _0939_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[28] ),
    .B(_0618_),
    .Y(_0676_));
 sky130_fd_sc_hd__a22o_2 _0940_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[28] ),
    .A2(_0600_),
    .B1(_0623_),
    .B2(_0676_),
    .X(_0024_));
 sky130_fd_sc_hd__nand2_2 _0941_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[29] ),
    .B(_0619_),
    .Y(_0677_));
 sky130_fd_sc_hd__nand2b_2 _0942_ (.A_N(_0620_),
    .B(_0677_),
    .Y(_0678_));
 sky130_fd_sc_hd__a22o_2 _0943_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[29] ),
    .A2(_0600_),
    .B1(_0623_),
    .B2(_0678_),
    .X(_0025_));
 sky130_fd_sc_hd__xor2_2 _0944_ (.A(\u_safety_fault_watchdog_controller.watchdog_counter[30] ),
    .B(_0620_),
    .X(_0679_));
 sky130_fd_sc_hd__a22o_2 _0945_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[30] ),
    .A2(_0600_),
    .B1(_0623_),
    .B2(_0679_),
    .X(_0027_));
 sky130_fd_sc_hd__o311a_2 _0946_ (.A1(\u_safety_fault_watchdog_controller.watchdog_counter[29] ),
    .A2(\u_safety_fault_watchdog_controller.watchdog_counter[30] ),
    .A3(_0619_),
    .B1(_0601_),
    .C1(\u_safety_fault_watchdog_controller.watchdog_counter[31] ),
    .X(_0680_));
 sky130_fd_sc_hd__a21o_2 _0947_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[31] ),
    .A2(_0600_),
    .B1(_0680_),
    .X(_0028_));
 sky130_fd_sc_hd__or4_2 _0948_ (.A(rd_addr[4]),
    .B(rd_addr[5]),
    .C(rd_addr[7]),
    .D(rd_addr[6]),
    .X(_0681_));
 sky130_fd_sc_hd__or4_2 _0949_ (.A(rd_addr[9]),
    .B(rd_addr[8]),
    .C(rd_addr[11]),
    .D(rd_addr[10]),
    .X(_0682_));
 sky130_fd_sc_hd__or3_2 _0950_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .C(_0682_),
    .X(_0683_));
 sky130_fd_sc_hd__inv_2 _0951_ (.A(_0683_),
    .Y(_0684_));
 sky130_fd_sc_hd__or3b_2 _0952_ (.A(_0683_),
    .B(rd_addr[2]),
    .C_N(rd_addr[3]),
    .X(_0685_));
 sky130_fd_sc_hd__nor2_2 _0953_ (.A(_0681_),
    .B(_0685_),
    .Y(_0686_));
 sky130_fd_sc_hd__or3_2 _0954_ (.A(rd_addr[2]),
    .B(rd_addr[3]),
    .C(_0683_),
    .X(_0687_));
 sky130_fd_sc_hd__nor2_2 _0955_ (.A(_0681_),
    .B(_0687_),
    .Y(_0688_));
 sky130_fd_sc_hd__or3b_2 _0956_ (.A(rd_addr[3]),
    .B(_0683_),
    .C_N(rd_addr[2]),
    .X(_0689_));
 sky130_fd_sc_hd__nor2_2 _0957_ (.A(_0681_),
    .B(_0689_),
    .Y(_0690_));
 sky130_fd_sc_hd__or4b_2 _0958_ (.A(rd_addr[4]),
    .B(rd_addr[7]),
    .C(rd_addr[6]),
    .D_N(rd_addr[5]),
    .X(_0691_));
 sky130_fd_sc_hd__nor2_2 _0959_ (.A(_0685_),
    .B(_0691_),
    .Y(_0692_));
 sky130_fd_sc_hd__nor2_2 _0960_ (.A(_0689_),
    .B(_0691_),
    .Y(_0693_));
 sky130_fd_sc_hd__or4b_2 _0961_ (.A(rd_addr[5]),
    .B(rd_addr[7]),
    .C(rd_addr[6]),
    .D_N(rd_addr[4]),
    .X(_0694_));
 sky130_fd_sc_hd__nor2_2 _0962_ (.A(_0687_),
    .B(_0694_),
    .Y(_0695_));
 sky130_fd_sc_hd__nor2_2 _0963_ (.A(_0685_),
    .B(_0694_),
    .Y(_0696_));
 sky130_fd_sc_hd__nand3_2 _0964_ (.A(rd_addr[2]),
    .B(rd_addr[3]),
    .C(_0684_),
    .Y(_0697_));
 sky130_fd_sc_hd__nor2_2 _0965_ (.A(_0681_),
    .B(_0697_),
    .Y(_0698_));
 sky130_fd_sc_hd__nor2_2 _0966_ (.A(_0689_),
    .B(_0694_),
    .Y(_0699_));
 sky130_fd_sc_hd__nor2_2 _0967_ (.A(_0687_),
    .B(_0691_),
    .Y(_0700_));
 sky130_fd_sc_hd__nor2_2 _0968_ (.A(_0694_),
    .B(_0697_),
    .Y(_0701_));
 sky130_fd_sc_hd__a22o_2 _0969_ (.A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[0] ),
    .A2(_0693_),
    .B1(_0695_),
    .B2(\fault_mask_cfg[0] ),
    .X(_0702_));
 sky130_fd_sc_hd__a21o_2 _0970_ (.A1(\heartbeat_count_value[0] ),
    .A2(_0698_),
    .B1(_0702_),
    .X(_0703_));
 sky130_fd_sc_hd__a22o_2 _0971_ (.A1(status_healthy),
    .A2(_0690_),
    .B1(_0701_),
    .B2(escalation_level[0]),
    .X(_0704_));
 sky130_fd_sc_hd__a22o_2 _0972_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[0] ),
    .A2(_0686_),
    .B1(_0700_),
    .B2(\irq_status_value[0] ),
    .X(_0705_));
 sky130_fd_sc_hd__a221o_2 _0973_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[0] ),
    .A2(_0688_),
    .B1(_0692_),
    .B2(\reset_count_value[0] ),
    .C1(_0705_),
    .X(_0706_));
 sky130_fd_sc_hd__a221o_2 _0974_ (.A1(\escalation_policy_cfg[0] ),
    .A2(_0696_),
    .B1(_0699_),
    .B2(\fault_status_value[0] ),
    .C1(_0704_),
    .X(_0707_));
 sky130_fd_sc_hd__o31a_2 _0975_ (.A1(_0703_),
    .A2(_0706_),
    .A3(_0707_),
    .B1(rd_en),
    .X(rd_data[0]));
 sky130_fd_sc_hd__a22o_2 _0976_ (.A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[1] ),
    .A2(_0693_),
    .B1(_0695_),
    .B2(\fault_mask_cfg[1] ),
    .X(_0708_));
 sky130_fd_sc_hd__a21o_2 _0977_ (.A1(escalation_level[1]),
    .A2(_0701_),
    .B1(_0708_),
    .X(_0709_));
 sky130_fd_sc_hd__a22o_2 _0978_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[1] ),
    .A2(_0688_),
    .B1(_0690_),
    .B2(status_watchdog_expired),
    .X(_0710_));
 sky130_fd_sc_hd__a22o_2 _0979_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[1] ),
    .A2(_0686_),
    .B1(_0692_),
    .B2(\reset_count_value[1] ),
    .X(_0711_));
 sky130_fd_sc_hd__a221o_2 _0980_ (.A1(\heartbeat_count_value[1] ),
    .A2(_0698_),
    .B1(_0699_),
    .B2(\fault_status_value[1] ),
    .C1(_0711_),
    .X(_0712_));
 sky130_fd_sc_hd__a221o_2 _0981_ (.A1(\escalation_policy_cfg[1] ),
    .A2(_0696_),
    .B1(_0700_),
    .B2(\irq_status_value[1] ),
    .C1(_0710_),
    .X(_0713_));
 sky130_fd_sc_hd__o31a_2 _0982_ (.A1(_0709_),
    .A2(_0712_),
    .A3(_0713_),
    .B1(rd_en),
    .X(rd_data[1]));
 sky130_fd_sc_hd__a22o_2 _0983_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[2] ),
    .A2(_0686_),
    .B1(_0690_),
    .B2(status_fault_pending),
    .X(_0714_));
 sky130_fd_sc_hd__a221o_2 _0984_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[2] ),
    .A2(_0688_),
    .B1(_0699_),
    .B2(\fault_status_value[2] ),
    .C1(_0714_),
    .X(_0715_));
 sky130_fd_sc_hd__a22o_2 _0985_ (.A1(\escalation_policy_cfg[2] ),
    .A2(_0696_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[2] ),
    .X(_0716_));
 sky130_fd_sc_hd__a22o_2 _0986_ (.A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[2] ),
    .A2(_0693_),
    .B1(_0700_),
    .B2(\irq_status_value[2] ),
    .X(_0717_));
 sky130_fd_sc_hd__a221o_2 _0987_ (.A1(\reset_count_value[2] ),
    .A2(_0692_),
    .B1(_0695_),
    .B2(\fault_mask_cfg[2] ),
    .C1(_0717_),
    .X(_0718_));
 sky130_fd_sc_hd__o31a_2 _0988_ (.A1(_0715_),
    .A2(_0716_),
    .A3(_0718_),
    .B1(rd_en),
    .X(rd_data[2]));
 sky130_fd_sc_hd__a22o_2 _0989_ (.A1(status_reset_requested),
    .A2(_0690_),
    .B1(_0695_),
    .B2(\fault_mask_cfg[3] ),
    .X(_0719_));
 sky130_fd_sc_hd__a221o_2 _0990_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[3] ),
    .A2(_0686_),
    .B1(_0699_),
    .B2(\fault_status_value[3] ),
    .C1(_0719_),
    .X(_0720_));
 sky130_fd_sc_hd__a22o_2 _0991_ (.A1(\reset_count_value[3] ),
    .A2(_0692_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[3] ),
    .X(_0721_));
 sky130_fd_sc_hd__a22o_2 _0992_ (.A1(\escalation_policy_cfg[3] ),
    .A2(_0696_),
    .B1(_0700_),
    .B2(\irq_status_value[3] ),
    .X(_0722_));
 sky130_fd_sc_hd__a221o_2 _0993_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[3] ),
    .A2(_0688_),
    .B1(_0693_),
    .B2(\u_safety_fault_watchdog_mmio.irq_clear_reg[3] ),
    .C1(_0722_),
    .X(_0723_));
 sky130_fd_sc_hd__o31a_2 _0994_ (.A1(_0720_),
    .A2(_0721_),
    .A3(_0723_),
    .B1(rd_en),
    .X(rd_data[3]));
 sky130_fd_sc_hd__a22o_2 _0995_ (.A1(status_escalation_active),
    .A2(_0690_),
    .B1(_0693_),
    .B2(\u_safety_fault_watchdog_mmio.irq_clear_reg[4] ),
    .X(_0724_));
 sky130_fd_sc_hd__a21o_2 _0996_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[4] ),
    .A2(_0688_),
    .B1(_0724_),
    .X(_0725_));
 sky130_fd_sc_hd__a22o_2 _0997_ (.A1(\reset_count_value[4] ),
    .A2(_0692_),
    .B1(_0696_),
    .B2(\escalation_policy_cfg[4] ),
    .X(_0726_));
 sky130_fd_sc_hd__a22o_2 _0998_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[4] ),
    .A2(_0686_),
    .B1(_0699_),
    .B2(\fault_status_value[4] ),
    .X(_0727_));
 sky130_fd_sc_hd__a221o_2 _0999_ (.A1(\fault_mask_cfg[4] ),
    .A2(_0695_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[4] ),
    .C1(_0727_),
    .X(_0728_));
 sky130_fd_sc_hd__o31a_2 _1000_ (.A1(_0725_),
    .A2(_0726_),
    .A3(_0728_),
    .B1(rd_en),
    .X(rd_data[4]));
 sky130_fd_sc_hd__a22o_2 _1001_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[5] ),
    .A2(_0686_),
    .B1(_0693_),
    .B2(\u_safety_fault_watchdog_mmio.irq_clear_reg[5] ),
    .X(_0729_));
 sky130_fd_sc_hd__a221o_2 _1002_ (.A1(\escalation_policy_cfg[5] ),
    .A2(_0696_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[5] ),
    .C1(_0729_),
    .X(_0730_));
 sky130_fd_sc_hd__a22o_2 _1003_ (.A1(\fault_mask_cfg[5] ),
    .A2(_0695_),
    .B1(_0699_),
    .B2(\fault_status_value[5] ),
    .X(_0731_));
 sky130_fd_sc_hd__a221o_2 _1004_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[5] ),
    .A2(_0688_),
    .B1(_0692_),
    .B2(\reset_count_value[5] ),
    .C1(_0731_),
    .X(_0732_));
 sky130_fd_sc_hd__o21a_2 _1005_ (.A1(_0730_),
    .A2(_0732_),
    .B1(rd_en),
    .X(rd_data[5]));
 sky130_fd_sc_hd__a22o_2 _1006_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[6] ),
    .A2(_0686_),
    .B1(_0699_),
    .B2(\fault_status_value[6] ),
    .X(_0733_));
 sky130_fd_sc_hd__a221o_2 _1007_ (.A1(\fault_mask_cfg[6] ),
    .A2(_0695_),
    .B1(_0696_),
    .B2(\escalation_policy_cfg[6] ),
    .C1(_0733_),
    .X(_0734_));
 sky130_fd_sc_hd__a22o_2 _1008_ (.A1(\reset_count_value[6] ),
    .A2(_0692_),
    .B1(_0693_),
    .B2(\u_safety_fault_watchdog_mmio.irq_clear_reg[6] ),
    .X(_0735_));
 sky130_fd_sc_hd__a221o_2 _1009_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[6] ),
    .A2(_0688_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[6] ),
    .C1(_0735_),
    .X(_0736_));
 sky130_fd_sc_hd__o21a_2 _1010_ (.A1(_0734_),
    .A2(_0736_),
    .B1(rd_en),
    .X(rd_data[6]));
 sky130_fd_sc_hd__a22o_2 _1011_ (.A1(\fault_mask_cfg[7] ),
    .A2(_0695_),
    .B1(_0699_),
    .B2(\fault_status_value[7] ),
    .X(_0737_));
 sky130_fd_sc_hd__a22o_2 _1012_ (.A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[7] ),
    .A2(_0693_),
    .B1(_0696_),
    .B2(\escalation_policy_cfg[7] ),
    .X(_0738_));
 sky130_fd_sc_hd__a221o_2 _1013_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[7] ),
    .A2(_0686_),
    .B1(_0688_),
    .B2(\u_safety_fault_watchdog_mmio.control_reg[7] ),
    .C1(_0737_),
    .X(_0739_));
 sky130_fd_sc_hd__a221o_2 _1014_ (.A1(\reset_count_value[7] ),
    .A2(_0692_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[7] ),
    .C1(_0738_),
    .X(_0740_));
 sky130_fd_sc_hd__o21a_2 _1015_ (.A1(_0739_),
    .A2(_0740_),
    .B1(rd_en),
    .X(rd_data[7]));
 sky130_fd_sc_hd__a22o_2 _1016_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[8] ),
    .A2(_0688_),
    .B1(_0696_),
    .B2(\escalation_policy_cfg[8] ),
    .X(_0741_));
 sky130_fd_sc_hd__a22o_2 _1017_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[8] ),
    .A2(_0686_),
    .B1(_0693_),
    .B2(\u_safety_fault_watchdog_mmio.irq_clear_reg[8] ),
    .X(_0742_));
 sky130_fd_sc_hd__a221o_2 _1018_ (.A1(\reset_count_value[8] ),
    .A2(_0692_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[8] ),
    .C1(_0742_),
    .X(_0743_));
 sky130_fd_sc_hd__o21a_2 _1019_ (.A1(_0741_),
    .A2(_0743_),
    .B1(rd_en),
    .X(rd_data[8]));
 sky130_fd_sc_hd__a22o_2 _1020_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[9] ),
    .A2(_0686_),
    .B1(_0693_),
    .B2(\u_safety_fault_watchdog_mmio.irq_clear_reg[9] ),
    .X(_0744_));
 sky130_fd_sc_hd__a22o_2 _1021_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[9] ),
    .A2(_0688_),
    .B1(_0696_),
    .B2(\escalation_policy_cfg[9] ),
    .X(_0745_));
 sky130_fd_sc_hd__a221o_2 _1022_ (.A1(\reset_count_value[9] ),
    .A2(_0692_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[9] ),
    .C1(_0745_),
    .X(_0746_));
 sky130_fd_sc_hd__o21a_2 _1023_ (.A1(_0744_),
    .A2(_0746_),
    .B1(rd_en),
    .X(rd_data[9]));
 sky130_fd_sc_hd__a22o_2 _1024_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[10] ),
    .A2(_0688_),
    .B1(_0692_),
    .B2(\reset_count_value[10] ),
    .X(_0747_));
 sky130_fd_sc_hd__a22o_2 _1025_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[10] ),
    .A2(_0686_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[10] ),
    .X(_0748_));
 sky130_fd_sc_hd__a22o_2 _1026_ (.A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[10] ),
    .A2(_0693_),
    .B1(_0696_),
    .B2(\escalation_policy_cfg[10] ),
    .X(_0749_));
 sky130_fd_sc_hd__o31a_2 _1027_ (.A1(_0747_),
    .A2(_0748_),
    .A3(_0749_),
    .B1(rd_en),
    .X(rd_data[10]));
 sky130_fd_sc_hd__a22o_2 _1028_ (.A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[11] ),
    .A2(_0693_),
    .B1(_0696_),
    .B2(\escalation_policy_cfg[11] ),
    .X(_0750_));
 sky130_fd_sc_hd__a22o_2 _1029_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[11] ),
    .A2(_0686_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[11] ),
    .X(_0751_));
 sky130_fd_sc_hd__a22o_2 _1030_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[11] ),
    .A2(_0688_),
    .B1(_0692_),
    .B2(\reset_count_value[11] ),
    .X(_0752_));
 sky130_fd_sc_hd__o31a_2 _1031_ (.A1(_0750_),
    .A2(_0751_),
    .A3(_0752_),
    .B1(rd_en),
    .X(rd_data[11]));
 sky130_fd_sc_hd__a22o_2 _1032_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[12] ),
    .A2(_0686_),
    .B1(_0696_),
    .B2(\escalation_policy_cfg[12] ),
    .X(_0753_));
 sky130_fd_sc_hd__a22o_2 _1033_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[12] ),
    .A2(_0688_),
    .B1(_0693_),
    .B2(\u_safety_fault_watchdog_mmio.irq_clear_reg[12] ),
    .X(_0754_));
 sky130_fd_sc_hd__a221o_2 _1034_ (.A1(\reset_count_value[12] ),
    .A2(_0692_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[12] ),
    .C1(_0754_),
    .X(_0755_));
 sky130_fd_sc_hd__o21a_2 _1035_ (.A1(_0753_),
    .A2(_0755_),
    .B1(rd_en),
    .X(rd_data[12]));
 sky130_fd_sc_hd__a22o_2 _1036_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[13] ),
    .A2(_0688_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[13] ),
    .X(_0756_));
 sky130_fd_sc_hd__a22o_2 _1037_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[13] ),
    .A2(_0686_),
    .B1(_0693_),
    .B2(\u_safety_fault_watchdog_mmio.irq_clear_reg[13] ),
    .X(_0757_));
 sky130_fd_sc_hd__a221o_2 _1038_ (.A1(\reset_count_value[13] ),
    .A2(_0692_),
    .B1(_0696_),
    .B2(\escalation_policy_cfg[13] ),
    .C1(_0757_),
    .X(_0758_));
 sky130_fd_sc_hd__o21a_2 _1039_ (.A1(_0756_),
    .A2(_0758_),
    .B1(rd_en),
    .X(rd_data[13]));
 sky130_fd_sc_hd__a22o_2 _1040_ (.A1(\reset_count_value[14] ),
    .A2(_0692_),
    .B1(_0696_),
    .B2(\escalation_policy_cfg[14] ),
    .X(_0759_));
 sky130_fd_sc_hd__a22o_2 _1041_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[14] ),
    .A2(_0686_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[14] ),
    .X(_0308_));
 sky130_fd_sc_hd__a22o_2 _1042_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[14] ),
    .A2(_0688_),
    .B1(_0693_),
    .B2(\u_safety_fault_watchdog_mmio.irq_clear_reg[14] ),
    .X(_0309_));
 sky130_fd_sc_hd__o31a_2 _1043_ (.A1(_0759_),
    .A2(_0308_),
    .A3(_0309_),
    .B1(rd_en),
    .X(rd_data[14]));
 sky130_fd_sc_hd__a22o_2 _1044_ (.A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[15] ),
    .A2(_0693_),
    .B1(_0696_),
    .B2(\escalation_policy_cfg[15] ),
    .X(_0310_));
 sky130_fd_sc_hd__a22o_2 _1045_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[15] ),
    .A2(_0688_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[15] ),
    .X(_0311_));
 sky130_fd_sc_hd__a22o_2 _1046_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[15] ),
    .A2(_0686_),
    .B1(_0692_),
    .B2(\reset_count_value[15] ),
    .X(_0312_));
 sky130_fd_sc_hd__o31a_2 _1047_ (.A1(_0310_),
    .A2(_0311_),
    .A3(_0312_),
    .B1(rd_en),
    .X(rd_data[15]));
 sky130_fd_sc_hd__a22o_2 _1048_ (.A1(\reset_count_value[16] ),
    .A2(_0692_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[16] ),
    .X(_0313_));
 sky130_fd_sc_hd__a22o_2 _1049_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[16] ),
    .A2(_0688_),
    .B1(_0696_),
    .B2(\escalation_policy_cfg[16] ),
    .X(_0314_));
 sky130_fd_sc_hd__a22o_2 _1050_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[16] ),
    .A2(_0686_),
    .B1(_0693_),
    .B2(\u_safety_fault_watchdog_mmio.irq_clear_reg[16] ),
    .X(_0315_));
 sky130_fd_sc_hd__o31a_2 _1051_ (.A1(_0313_),
    .A2(_0314_),
    .A3(_0315_),
    .B1(rd_en),
    .X(rd_data[16]));
 sky130_fd_sc_hd__a22o_2 _1052_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[17] ),
    .A2(_0688_),
    .B1(_0696_),
    .B2(\escalation_policy_cfg[17] ),
    .X(_0316_));
 sky130_fd_sc_hd__a22o_2 _1053_ (.A1(\reset_count_value[17] ),
    .A2(_0692_),
    .B1(_0693_),
    .B2(\u_safety_fault_watchdog_mmio.irq_clear_reg[17] ),
    .X(_0317_));
 sky130_fd_sc_hd__a221o_2 _1054_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[17] ),
    .A2(_0686_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[17] ),
    .C1(_0317_),
    .X(_0318_));
 sky130_fd_sc_hd__o21a_2 _1055_ (.A1(_0316_),
    .A2(_0318_),
    .B1(rd_en),
    .X(rd_data[17]));
 sky130_fd_sc_hd__a22o_2 _1056_ (.A1(\reset_count_value[18] ),
    .A2(_0692_),
    .B1(_0693_),
    .B2(\u_safety_fault_watchdog_mmio.irq_clear_reg[18] ),
    .X(_0319_));
 sky130_fd_sc_hd__a22o_2 _1057_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[18] ),
    .A2(_0686_),
    .B1(_0688_),
    .B2(\u_safety_fault_watchdog_mmio.control_reg[18] ),
    .X(_0320_));
 sky130_fd_sc_hd__a221o_2 _1058_ (.A1(\escalation_policy_cfg[18] ),
    .A2(_0696_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[18] ),
    .C1(_0320_),
    .X(_0321_));
 sky130_fd_sc_hd__o21a_2 _1059_ (.A1(_0319_),
    .A2(_0321_),
    .B1(rd_en),
    .X(rd_data[18]));
 sky130_fd_sc_hd__a22o_2 _1060_ (.A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[19] ),
    .A2(_0693_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[19] ),
    .X(_0322_));
 sky130_fd_sc_hd__a22o_2 _1061_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[19] ),
    .A2(_0688_),
    .B1(_0692_),
    .B2(\reset_count_value[19] ),
    .X(_0323_));
 sky130_fd_sc_hd__a221o_2 _1062_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[19] ),
    .A2(_0686_),
    .B1(_0696_),
    .B2(\escalation_policy_cfg[19] ),
    .C1(_0323_),
    .X(_0324_));
 sky130_fd_sc_hd__o21a_2 _1063_ (.A1(_0322_),
    .A2(_0324_),
    .B1(rd_en),
    .X(rd_data[19]));
 sky130_fd_sc_hd__a22o_2 _1064_ (.A1(\reset_count_value[20] ),
    .A2(_0692_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[20] ),
    .X(_0325_));
 sky130_fd_sc_hd__a22o_2 _1065_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[20] ),
    .A2(_0688_),
    .B1(_0693_),
    .B2(\u_safety_fault_watchdog_mmio.irq_clear_reg[20] ),
    .X(_0326_));
 sky130_fd_sc_hd__a221o_2 _1066_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[20] ),
    .A2(_0686_),
    .B1(_0696_),
    .B2(\escalation_policy_cfg[20] ),
    .C1(_0326_),
    .X(_0327_));
 sky130_fd_sc_hd__o21a_2 _1067_ (.A1(_0325_),
    .A2(_0327_),
    .B1(rd_en),
    .X(rd_data[20]));
 sky130_fd_sc_hd__a22o_2 _1068_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[21] ),
    .A2(_0686_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[21] ),
    .X(_0328_));
 sky130_fd_sc_hd__a22o_2 _1069_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[21] ),
    .A2(_0688_),
    .B1(_0693_),
    .B2(\u_safety_fault_watchdog_mmio.irq_clear_reg[21] ),
    .X(_0329_));
 sky130_fd_sc_hd__a221o_2 _1070_ (.A1(\reset_count_value[21] ),
    .A2(_0692_),
    .B1(_0696_),
    .B2(\escalation_policy_cfg[21] ),
    .C1(_0329_),
    .X(_0330_));
 sky130_fd_sc_hd__o21a_2 _1071_ (.A1(_0328_),
    .A2(_0330_),
    .B1(rd_en),
    .X(rd_data[21]));
 sky130_fd_sc_hd__a22o_2 _1072_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[22] ),
    .A2(_0688_),
    .B1(_0696_),
    .B2(\escalation_policy_cfg[22] ),
    .X(_0331_));
 sky130_fd_sc_hd__a22o_2 _1073_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[22] ),
    .A2(_0686_),
    .B1(_0693_),
    .B2(\u_safety_fault_watchdog_mmio.irq_clear_reg[22] ),
    .X(_0332_));
 sky130_fd_sc_hd__a221o_2 _1074_ (.A1(\reset_count_value[22] ),
    .A2(_0692_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[22] ),
    .C1(_0332_),
    .X(_0333_));
 sky130_fd_sc_hd__o21a_2 _1075_ (.A1(_0331_),
    .A2(_0333_),
    .B1(rd_en),
    .X(rd_data[22]));
 sky130_fd_sc_hd__a22o_2 _1076_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[23] ),
    .A2(_0686_),
    .B1(_0693_),
    .B2(\u_safety_fault_watchdog_mmio.irq_clear_reg[23] ),
    .X(_0334_));
 sky130_fd_sc_hd__a22o_2 _1077_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[23] ),
    .A2(_0688_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[23] ),
    .X(_0335_));
 sky130_fd_sc_hd__a22o_2 _1078_ (.A1(\reset_count_value[23] ),
    .A2(_0692_),
    .B1(_0696_),
    .B2(\escalation_policy_cfg[23] ),
    .X(_0336_));
 sky130_fd_sc_hd__o31a_2 _1079_ (.A1(_0334_),
    .A2(_0335_),
    .A3(_0336_),
    .B1(rd_en),
    .X(rd_data[23]));
 sky130_fd_sc_hd__a22o_2 _1080_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[24] ),
    .A2(_0688_),
    .B1(_0692_),
    .B2(\reset_count_value[24] ),
    .X(_0337_));
 sky130_fd_sc_hd__a22o_2 _1081_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[24] ),
    .A2(_0686_),
    .B1(_0696_),
    .B2(\escalation_policy_cfg[24] ),
    .X(_0338_));
 sky130_fd_sc_hd__a221o_2 _1082_ (.A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[24] ),
    .A2(_0693_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[24] ),
    .C1(_0338_),
    .X(_0339_));
 sky130_fd_sc_hd__o21a_2 _1083_ (.A1(_0337_),
    .A2(_0339_),
    .B1(rd_en),
    .X(rd_data[24]));
 sky130_fd_sc_hd__a22o_2 _1084_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[25] ),
    .A2(_0688_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[25] ),
    .X(_0340_));
 sky130_fd_sc_hd__a22o_2 _1085_ (.A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[25] ),
    .A2(_0693_),
    .B1(_0696_),
    .B2(\escalation_policy_cfg[25] ),
    .X(_0341_));
 sky130_fd_sc_hd__a221o_2 _1086_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[25] ),
    .A2(_0686_),
    .B1(_0692_),
    .B2(\reset_count_value[25] ),
    .C1(_0341_),
    .X(_0342_));
 sky130_fd_sc_hd__o21a_2 _1087_ (.A1(_0340_),
    .A2(_0342_),
    .B1(rd_en),
    .X(rd_data[25]));
 sky130_fd_sc_hd__a22o_2 _1088_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[26] ),
    .A2(_0686_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[26] ),
    .X(_0343_));
 sky130_fd_sc_hd__a22o_2 _1089_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[26] ),
    .A2(_0688_),
    .B1(_0696_),
    .B2(\escalation_policy_cfg[26] ),
    .X(_0344_));
 sky130_fd_sc_hd__a221o_2 _1090_ (.A1(\reset_count_value[26] ),
    .A2(_0692_),
    .B1(_0693_),
    .B2(\u_safety_fault_watchdog_mmio.irq_clear_reg[26] ),
    .C1(_0344_),
    .X(_0345_));
 sky130_fd_sc_hd__o21a_2 _1091_ (.A1(_0343_),
    .A2(_0345_),
    .B1(rd_en),
    .X(rd_data[26]));
 sky130_fd_sc_hd__a22o_2 _1092_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[27] ),
    .A2(_0688_),
    .B1(_0692_),
    .B2(\reset_count_value[27] ),
    .X(_0346_));
 sky130_fd_sc_hd__a22o_2 _1093_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[27] ),
    .A2(_0686_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[27] ),
    .X(_0347_));
 sky130_fd_sc_hd__a22o_2 _1094_ (.A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[27] ),
    .A2(_0693_),
    .B1(_0696_),
    .B2(\escalation_policy_cfg[27] ),
    .X(_0348_));
 sky130_fd_sc_hd__o31a_2 _1095_ (.A1(_0346_),
    .A2(_0347_),
    .A3(_0348_),
    .B1(rd_en),
    .X(rd_data[27]));
 sky130_fd_sc_hd__a22o_2 _1096_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[28] ),
    .A2(_0688_),
    .B1(_0693_),
    .B2(\u_safety_fault_watchdog_mmio.irq_clear_reg[28] ),
    .X(_0349_));
 sky130_fd_sc_hd__a22o_2 _1097_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[28] ),
    .A2(_0686_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[28] ),
    .X(_0350_));
 sky130_fd_sc_hd__a22o_2 _1098_ (.A1(\reset_count_value[28] ),
    .A2(_0692_),
    .B1(_0696_),
    .B2(\escalation_policy_cfg[28] ),
    .X(_0351_));
 sky130_fd_sc_hd__o31a_2 _1099_ (.A1(_0349_),
    .A2(_0350_),
    .A3(_0351_),
    .B1(rd_en),
    .X(rd_data[28]));
 sky130_fd_sc_hd__a22o_2 _1100_ (.A1(\escalation_policy_cfg[29] ),
    .A2(_0696_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[29] ),
    .X(_0352_));
 sky130_fd_sc_hd__a22o_2 _1101_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[29] ),
    .A2(_0688_),
    .B1(_0693_),
    .B2(\u_safety_fault_watchdog_mmio.irq_clear_reg[29] ),
    .X(_0353_));
 sky130_fd_sc_hd__a221o_2 _1102_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[29] ),
    .A2(_0686_),
    .B1(_0692_),
    .B2(\reset_count_value[29] ),
    .C1(_0353_),
    .X(_0354_));
 sky130_fd_sc_hd__o21a_2 _1103_ (.A1(_0352_),
    .A2(_0354_),
    .B1(rd_en),
    .X(rd_data[29]));
 sky130_fd_sc_hd__a22o_2 _1104_ (.A1(\reset_count_value[30] ),
    .A2(_0692_),
    .B1(_0693_),
    .B2(\u_safety_fault_watchdog_mmio.irq_clear_reg[30] ),
    .X(_0355_));
 sky130_fd_sc_hd__a22o_2 _1105_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[30] ),
    .A2(_0688_),
    .B1(_0696_),
    .B2(\escalation_policy_cfg[30] ),
    .X(_0356_));
 sky130_fd_sc_hd__a221o_2 _1106_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[30] ),
    .A2(_0686_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[30] ),
    .C1(_0356_),
    .X(_0357_));
 sky130_fd_sc_hd__o21a_2 _1107_ (.A1(_0355_),
    .A2(_0357_),
    .B1(rd_en),
    .X(rd_data[30]));
 sky130_fd_sc_hd__a22o_2 _1108_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[31] ),
    .A2(_0688_),
    .B1(_0693_),
    .B2(\u_safety_fault_watchdog_mmio.irq_clear_reg[31] ),
    .X(_0358_));
 sky130_fd_sc_hd__a22o_2 _1109_ (.A1(\reset_count_value[31] ),
    .A2(_0692_),
    .B1(_0698_),
    .B2(\heartbeat_count_value[31] ),
    .X(_0359_));
 sky130_fd_sc_hd__a22o_2 _1110_ (.A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[31] ),
    .A2(_0686_),
    .B1(_0696_),
    .B2(\escalation_policy_cfg[31] ),
    .X(_0360_));
 sky130_fd_sc_hd__o31a_2 _1111_ (.A1(_0358_),
    .A2(_0359_),
    .A3(_0360_),
    .B1(rd_en),
    .X(rd_data[31]));
 sky130_fd_sc_hd__nor4_2 _1112_ (.A(status_watchdog_expired),
    .B(status_fault_pending),
    .C(status_reset_requested),
    .D(status_escalation_active),
    .Y(_0003_));
 sky130_fd_sc_hd__o41a_2 _1113_ (.A1(\irq_status_value[0] ),
    .A2(\irq_status_value[1] ),
    .A3(\irq_status_value[2] ),
    .A4(\irq_status_value[3] ),
    .B1(irq_enable),
    .X(_0001_));
 sky130_fd_sc_hd__or4_2 _1114_ (.A(wr_addr[1]),
    .B(wr_addr[0]),
    .C(wr_addr[7]),
    .D(wr_addr[6]),
    .X(_0361_));
 sky130_fd_sc_hd__and4b_2 _1115_ (.A_N(wr_addr[4]),
    .B(wr_addr[5]),
    .C(wr_en),
    .D(wr_addr[2]),
    .X(_0362_));
 sky130_fd_sc_hd__or4b_2 _1116_ (.A(wr_addr[3]),
    .B(_0593_),
    .C(_0361_),
    .D_N(_0362_),
    .X(_0363_));
 sky130_fd_sc_hd__a21o_2 _1117_ (.A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[0] ),
    .A2(_0363_),
    .B1(_0037_),
    .X(_0043_));
 sky130_fd_sc_hd__a21o_2 _1118_ (.A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[1] ),
    .A2(_0363_),
    .B1(_0038_),
    .X(_0044_));
 sky130_fd_sc_hd__a21o_2 _1119_ (.A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[2] ),
    .A2(_0363_),
    .B1(_0039_),
    .X(_0045_));
 sky130_fd_sc_hd__a21o_2 _1120_ (.A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[3] ),
    .A2(_0363_),
    .B1(_0040_),
    .X(_0046_));
 sky130_fd_sc_hd__mux2_1 _1121_ (.A0(wr_data[4]),
    .A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[4] ),
    .S(_0363_),
    .X(_0047_));
 sky130_fd_sc_hd__mux2_1 _1122_ (.A0(wr_data[5]),
    .A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[5] ),
    .S(_0363_),
    .X(_0048_));
 sky130_fd_sc_hd__mux2_1 _1123_ (.A0(wr_data[6]),
    .A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[6] ),
    .S(_0363_),
    .X(_0049_));
 sky130_fd_sc_hd__mux2_1 _1124_ (.A0(wr_data[7]),
    .A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[7] ),
    .S(_0363_),
    .X(_0050_));
 sky130_fd_sc_hd__mux2_1 _1125_ (.A0(wr_data[8]),
    .A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[8] ),
    .S(_0363_),
    .X(_0051_));
 sky130_fd_sc_hd__mux2_1 _1126_ (.A0(wr_data[9]),
    .A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[9] ),
    .S(_0363_),
    .X(_0052_));
 sky130_fd_sc_hd__mux2_1 _1127_ (.A0(wr_data[10]),
    .A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[10] ),
    .S(_0363_),
    .X(_0053_));
 sky130_fd_sc_hd__mux2_1 _1128_ (.A0(wr_data[11]),
    .A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[11] ),
    .S(_0363_),
    .X(_0054_));
 sky130_fd_sc_hd__mux2_1 _1129_ (.A0(wr_data[12]),
    .A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[12] ),
    .S(_0363_),
    .X(_0055_));
 sky130_fd_sc_hd__mux2_1 _1130_ (.A0(wr_data[13]),
    .A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[13] ),
    .S(_0363_),
    .X(_0056_));
 sky130_fd_sc_hd__mux2_1 _1131_ (.A0(wr_data[14]),
    .A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[14] ),
    .S(_0363_),
    .X(_0057_));
 sky130_fd_sc_hd__mux2_1 _1132_ (.A0(wr_data[15]),
    .A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[15] ),
    .S(_0363_),
    .X(_0058_));
 sky130_fd_sc_hd__mux2_1 _1133_ (.A0(wr_data[16]),
    .A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[16] ),
    .S(_0363_),
    .X(_0059_));
 sky130_fd_sc_hd__mux2_1 _1134_ (.A0(wr_data[17]),
    .A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[17] ),
    .S(_0363_),
    .X(_0060_));
 sky130_fd_sc_hd__mux2_1 _1135_ (.A0(wr_data[18]),
    .A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[18] ),
    .S(_0363_),
    .X(_0061_));
 sky130_fd_sc_hd__mux2_1 _1136_ (.A0(wr_data[19]),
    .A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[19] ),
    .S(_0363_),
    .X(_0062_));
 sky130_fd_sc_hd__mux2_1 _1137_ (.A0(wr_data[20]),
    .A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[20] ),
    .S(_0363_),
    .X(_0063_));
 sky130_fd_sc_hd__mux2_1 _1138_ (.A0(wr_data[21]),
    .A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[21] ),
    .S(_0363_),
    .X(_0064_));
 sky130_fd_sc_hd__mux2_1 _1139_ (.A0(wr_data[22]),
    .A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[22] ),
    .S(_0363_),
    .X(_0065_));
 sky130_fd_sc_hd__mux2_1 _1140_ (.A0(wr_data[23]),
    .A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[23] ),
    .S(_0363_),
    .X(_0066_));
 sky130_fd_sc_hd__mux2_1 _1141_ (.A0(wr_data[24]),
    .A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[24] ),
    .S(_0363_),
    .X(_0067_));
 sky130_fd_sc_hd__mux2_1 _1142_ (.A0(wr_data[25]),
    .A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[25] ),
    .S(_0363_),
    .X(_0068_));
 sky130_fd_sc_hd__mux2_1 _1143_ (.A0(wr_data[26]),
    .A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[26] ),
    .S(_0363_),
    .X(_0069_));
 sky130_fd_sc_hd__mux2_1 _1144_ (.A0(wr_data[27]),
    .A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[27] ),
    .S(_0363_),
    .X(_0070_));
 sky130_fd_sc_hd__mux2_1 _1145_ (.A0(wr_data[28]),
    .A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[28] ),
    .S(_0363_),
    .X(_0071_));
 sky130_fd_sc_hd__mux2_1 _1146_ (.A0(wr_data[29]),
    .A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[29] ),
    .S(_0363_),
    .X(_0072_));
 sky130_fd_sc_hd__mux2_1 _1147_ (.A0(wr_data[30]),
    .A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[30] ),
    .S(_0363_),
    .X(_0073_));
 sky130_fd_sc_hd__mux2_1 _1148_ (.A0(wr_data[31]),
    .A1(\u_safety_fault_watchdog_mmio.irq_clear_reg[31] ),
    .S(_0363_),
    .X(_0074_));
 sky130_fd_sc_hd__or4_2 _1149_ (.A(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[5] ),
    .B(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[4] ),
    .C(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[7] ),
    .D(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[6] ),
    .X(_0364_));
 sky130_fd_sc_hd__or4_2 _1150_ (.A(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[1] ),
    .B(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[0] ),
    .C(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[3] ),
    .D(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[2] ),
    .X(_0365_));
 sky130_fd_sc_hd__or4_2 _1151_ (.A(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[9] ),
    .B(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[8] ),
    .C(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[11] ),
    .D(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[10] ),
    .X(_0366_));
 sky130_fd_sc_hd__or4_2 _1152_ (.A(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[13] ),
    .B(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[12] ),
    .C(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[15] ),
    .D(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[14] ),
    .X(_0367_));
 sky130_fd_sc_hd__or3_2 _1153_ (.A(_0364_),
    .B(_0365_),
    .C(_0367_),
    .X(_0368_));
 sky130_fd_sc_hd__or4_2 _1154_ (.A(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[21] ),
    .B(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[20] ),
    .C(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[23] ),
    .D(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[22] ),
    .X(_0369_));
 sky130_fd_sc_hd__or4_2 _1155_ (.A(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[17] ),
    .B(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[16] ),
    .C(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[19] ),
    .D(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[18] ),
    .X(_0370_));
 sky130_fd_sc_hd__or4_2 _1156_ (.A(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[29] ),
    .B(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[28] ),
    .C(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[31] ),
    .D(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[30] ),
    .X(_0371_));
 sky130_fd_sc_hd__or2_2 _1157_ (.A(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[25] ),
    .B(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[26] ),
    .X(_0372_));
 sky130_fd_sc_hd__or4_2 _1158_ (.A(_0369_),
    .B(_0370_),
    .C(_0371_),
    .D(_0372_),
    .X(_0373_));
 sky130_fd_sc_hd__or4_2 _1159_ (.A(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[24] ),
    .B(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[27] ),
    .C(_0366_),
    .D(_0368_),
    .X(_0374_));
 sky130_fd_sc_hd__nor2_2 _1160_ (.A(_0373_),
    .B(_0374_),
    .Y(_0375_));
 sky130_fd_sc_hd__nor4_2 _1161_ (.A(_0600_),
    .B(_0618_),
    .C(_0621_),
    .D(_0375_),
    .Y(_0376_));
 sky130_fd_sc_hd__or2_2 _1162_ (.A(watchdog_expired),
    .B(_0376_),
    .X(_0075_));
 sky130_fd_sc_hd__nand2b_2 _1163_ (.A_N(\irq_clear_pulse[2] ),
    .B(\irq_status_value[2] ),
    .Y(_0377_));
 sky130_fd_sc_hd__a21oi_2 _1164_ (.A1(_0589_),
    .A2(_0377_),
    .B1(external_reset_done),
    .Y(_0076_));
 sky130_fd_sc_hd__o21ba_2 _1165_ (.A1(reset_request),
    .A2(_0042_),
    .B1_N(external_reset_done),
    .X(_0077_));
 sky130_fd_sc_hd__o21ba_2 _1166_ (.A1(\u_safety_fault_watchdog_controller.masked_faults[0] ),
    .A2(\fault_status_value[0] ),
    .B1_N(fault_clear_pulse),
    .X(_0078_));
 sky130_fd_sc_hd__o21ba_2 _1167_ (.A1(\u_safety_fault_watchdog_controller.masked_faults[1] ),
    .A2(\fault_status_value[1] ),
    .B1_N(fault_clear_pulse),
    .X(_0079_));
 sky130_fd_sc_hd__o21ba_2 _1168_ (.A1(\u_safety_fault_watchdog_controller.masked_faults[2] ),
    .A2(\fault_status_value[2] ),
    .B1_N(fault_clear_pulse),
    .X(_0080_));
 sky130_fd_sc_hd__o21ba_2 _1169_ (.A1(\u_safety_fault_watchdog_controller.masked_faults[3] ),
    .A2(\fault_status_value[3] ),
    .B1_N(fault_clear_pulse),
    .X(_0081_));
 sky130_fd_sc_hd__o21ba_2 _1170_ (.A1(\u_safety_fault_watchdog_controller.masked_faults[4] ),
    .A2(\fault_status_value[4] ),
    .B1_N(fault_clear_pulse),
    .X(_0082_));
 sky130_fd_sc_hd__o21ba_2 _1171_ (.A1(\u_safety_fault_watchdog_controller.masked_faults[5] ),
    .A2(\fault_status_value[5] ),
    .B1_N(fault_clear_pulse),
    .X(_0083_));
 sky130_fd_sc_hd__o21ba_2 _1172_ (.A1(\u_safety_fault_watchdog_controller.masked_faults[6] ),
    .A2(\fault_status_value[6] ),
    .B1_N(fault_clear_pulse),
    .X(_0084_));
 sky130_fd_sc_hd__o21ba_2 _1173_ (.A1(\u_safety_fault_watchdog_controller.masked_faults[7] ),
    .A2(\fault_status_value[7] ),
    .B1_N(fault_clear_pulse),
    .X(_0085_));
 sky130_fd_sc_hd__xor2_2 _1174_ (.A(heartbeat),
    .B(\heartbeat_count_value[0] ),
    .X(_0086_));
 sky130_fd_sc_hd__and3_2 _1175_ (.A(heartbeat),
    .B(\heartbeat_count_value[0] ),
    .C(\heartbeat_count_value[1] ),
    .X(_0378_));
 sky130_fd_sc_hd__a21oi_2 _1176_ (.A1(heartbeat),
    .A2(\heartbeat_count_value[0] ),
    .B1(\heartbeat_count_value[1] ),
    .Y(_0379_));
 sky130_fd_sc_hd__nor2_2 _1177_ (.A(_0378_),
    .B(_0379_),
    .Y(_0087_));
 sky130_fd_sc_hd__and4_2 _1178_ (.A(heartbeat),
    .B(\heartbeat_count_value[0] ),
    .C(\heartbeat_count_value[1] ),
    .D(\heartbeat_count_value[2] ),
    .X(_0380_));
 sky130_fd_sc_hd__nor2_2 _1179_ (.A(\heartbeat_count_value[2] ),
    .B(_0378_),
    .Y(_0381_));
 sky130_fd_sc_hd__nor2_2 _1180_ (.A(_0380_),
    .B(_0381_),
    .Y(_0088_));
 sky130_fd_sc_hd__nand2_2 _1181_ (.A(\heartbeat_count_value[3] ),
    .B(_0380_),
    .Y(_0382_));
 sky130_fd_sc_hd__or2_2 _1182_ (.A(\heartbeat_count_value[3] ),
    .B(_0380_),
    .X(_0383_));
 sky130_fd_sc_hd__and2_2 _1183_ (.A(_0382_),
    .B(_0383_),
    .X(_0089_));
 sky130_fd_sc_hd__xnor2_2 _1184_ (.A(\heartbeat_count_value[4] ),
    .B(_0382_),
    .Y(_0090_));
 sky130_fd_sc_hd__and2_2 _1185_ (.A(\heartbeat_count_value[4] ),
    .B(\heartbeat_count_value[5] ),
    .X(_0384_));
 sky130_fd_sc_hd__and3_2 _1186_ (.A(\heartbeat_count_value[3] ),
    .B(_0380_),
    .C(_0384_),
    .X(_0385_));
 sky130_fd_sc_hd__a31o_2 _1187_ (.A1(\heartbeat_count_value[3] ),
    .A2(\heartbeat_count_value[4] ),
    .A3(_0380_),
    .B1(\heartbeat_count_value[5] ),
    .X(_0386_));
 sky130_fd_sc_hd__and2b_2 _1188_ (.A_N(_0385_),
    .B(_0386_),
    .X(_0091_));
 sky130_fd_sc_hd__and4_2 _1189_ (.A(\heartbeat_count_value[3] ),
    .B(\heartbeat_count_value[6] ),
    .C(_0380_),
    .D(_0384_),
    .X(_0387_));
 sky130_fd_sc_hd__nor2_2 _1190_ (.A(\heartbeat_count_value[6] ),
    .B(_0385_),
    .Y(_0388_));
 sky130_fd_sc_hd__nor2_2 _1191_ (.A(_0387_),
    .B(_0388_),
    .Y(_0092_));
 sky130_fd_sc_hd__nand2_2 _1192_ (.A(\heartbeat_count_value[7] ),
    .B(_0387_),
    .Y(_0389_));
 sky130_fd_sc_hd__or2_2 _1193_ (.A(\heartbeat_count_value[7] ),
    .B(_0387_),
    .X(_0390_));
 sky130_fd_sc_hd__and2_2 _1194_ (.A(_0389_),
    .B(_0390_),
    .X(_0093_));
 sky130_fd_sc_hd__xnor2_2 _1195_ (.A(\heartbeat_count_value[8] ),
    .B(_0389_),
    .Y(_0094_));
 sky130_fd_sc_hd__and4_2 _1196_ (.A(\heartbeat_count_value[7] ),
    .B(\heartbeat_count_value[8] ),
    .C(\heartbeat_count_value[9] ),
    .D(_0387_),
    .X(_0391_));
 sky130_fd_sc_hd__a31o_2 _1197_ (.A1(\heartbeat_count_value[7] ),
    .A2(\heartbeat_count_value[8] ),
    .A3(_0387_),
    .B1(\heartbeat_count_value[9] ),
    .X(_0392_));
 sky130_fd_sc_hd__and2b_2 _1198_ (.A_N(_0391_),
    .B(_0392_),
    .X(_0095_));
 sky130_fd_sc_hd__nand2_2 _1199_ (.A(\heartbeat_count_value[10] ),
    .B(_0391_),
    .Y(_0393_));
 sky130_fd_sc_hd__or2_2 _1200_ (.A(\heartbeat_count_value[10] ),
    .B(_0391_),
    .X(_0394_));
 sky130_fd_sc_hd__and2_2 _1201_ (.A(_0393_),
    .B(_0394_),
    .X(_0096_));
 sky130_fd_sc_hd__xnor2_2 _1202_ (.A(\heartbeat_count_value[11] ),
    .B(_0393_),
    .Y(_0097_));
 sky130_fd_sc_hd__and4_2 _1203_ (.A(\heartbeat_count_value[10] ),
    .B(\heartbeat_count_value[11] ),
    .C(\heartbeat_count_value[12] ),
    .D(_0391_),
    .X(_0395_));
 sky130_fd_sc_hd__a31o_2 _1204_ (.A1(\heartbeat_count_value[10] ),
    .A2(\heartbeat_count_value[11] ),
    .A3(_0391_),
    .B1(\heartbeat_count_value[12] ),
    .X(_0396_));
 sky130_fd_sc_hd__and2b_2 _1205_ (.A_N(_0395_),
    .B(_0396_),
    .X(_0098_));
 sky130_fd_sc_hd__nand2_2 _1206_ (.A(\heartbeat_count_value[13] ),
    .B(_0395_),
    .Y(_0397_));
 sky130_fd_sc_hd__or2_2 _1207_ (.A(\heartbeat_count_value[13] ),
    .B(_0395_),
    .X(_0398_));
 sky130_fd_sc_hd__and2_2 _1208_ (.A(_0397_),
    .B(_0398_),
    .X(_0099_));
 sky130_fd_sc_hd__xnor2_2 _1209_ (.A(\heartbeat_count_value[14] ),
    .B(_0397_),
    .Y(_0100_));
 sky130_fd_sc_hd__and4_2 _1210_ (.A(\heartbeat_count_value[13] ),
    .B(\heartbeat_count_value[14] ),
    .C(\heartbeat_count_value[15] ),
    .D(_0395_),
    .X(_0399_));
 sky130_fd_sc_hd__a31o_2 _1211_ (.A1(\heartbeat_count_value[13] ),
    .A2(\heartbeat_count_value[14] ),
    .A3(_0395_),
    .B1(\heartbeat_count_value[15] ),
    .X(_0400_));
 sky130_fd_sc_hd__and2b_2 _1212_ (.A_N(_0399_),
    .B(_0400_),
    .X(_0101_));
 sky130_fd_sc_hd__nand2_2 _1213_ (.A(\heartbeat_count_value[16] ),
    .B(_0399_),
    .Y(_0401_));
 sky130_fd_sc_hd__or2_2 _1214_ (.A(\heartbeat_count_value[16] ),
    .B(_0399_),
    .X(_0402_));
 sky130_fd_sc_hd__and2_2 _1215_ (.A(_0401_),
    .B(_0402_),
    .X(_0102_));
 sky130_fd_sc_hd__xnor2_2 _1216_ (.A(\heartbeat_count_value[17] ),
    .B(_0401_),
    .Y(_0103_));
 sky130_fd_sc_hd__and4_2 _1217_ (.A(\heartbeat_count_value[16] ),
    .B(\heartbeat_count_value[17] ),
    .C(\heartbeat_count_value[18] ),
    .D(_0399_),
    .X(_0403_));
 sky130_fd_sc_hd__a31o_2 _1218_ (.A1(\heartbeat_count_value[16] ),
    .A2(\heartbeat_count_value[17] ),
    .A3(_0399_),
    .B1(\heartbeat_count_value[18] ),
    .X(_0404_));
 sky130_fd_sc_hd__and2b_2 _1219_ (.A_N(_0403_),
    .B(_0404_),
    .X(_0104_));
 sky130_fd_sc_hd__nand2_2 _1220_ (.A(\heartbeat_count_value[19] ),
    .B(_0403_),
    .Y(_0405_));
 sky130_fd_sc_hd__or2_2 _1221_ (.A(\heartbeat_count_value[19] ),
    .B(_0403_),
    .X(_0406_));
 sky130_fd_sc_hd__and2_2 _1222_ (.A(_0405_),
    .B(_0406_),
    .X(_0105_));
 sky130_fd_sc_hd__xnor2_2 _1223_ (.A(\heartbeat_count_value[20] ),
    .B(_0405_),
    .Y(_0106_));
 sky130_fd_sc_hd__and4_2 _1224_ (.A(\heartbeat_count_value[19] ),
    .B(\heartbeat_count_value[20] ),
    .C(\heartbeat_count_value[21] ),
    .D(_0403_),
    .X(_0407_));
 sky130_fd_sc_hd__a31o_2 _1225_ (.A1(\heartbeat_count_value[19] ),
    .A2(\heartbeat_count_value[20] ),
    .A3(_0403_),
    .B1(\heartbeat_count_value[21] ),
    .X(_0408_));
 sky130_fd_sc_hd__and2b_2 _1226_ (.A_N(_0407_),
    .B(_0408_),
    .X(_0107_));
 sky130_fd_sc_hd__nand2_2 _1227_ (.A(\heartbeat_count_value[22] ),
    .B(_0407_),
    .Y(_0409_));
 sky130_fd_sc_hd__or2_2 _1228_ (.A(\heartbeat_count_value[22] ),
    .B(_0407_),
    .X(_0410_));
 sky130_fd_sc_hd__and2_2 _1229_ (.A(_0409_),
    .B(_0410_),
    .X(_0108_));
 sky130_fd_sc_hd__xnor2_2 _1230_ (.A(\heartbeat_count_value[23] ),
    .B(_0409_),
    .Y(_0109_));
 sky130_fd_sc_hd__and4_2 _1231_ (.A(\heartbeat_count_value[22] ),
    .B(\heartbeat_count_value[23] ),
    .C(\heartbeat_count_value[24] ),
    .D(_0407_),
    .X(_0411_));
 sky130_fd_sc_hd__a31o_2 _1232_ (.A1(\heartbeat_count_value[22] ),
    .A2(\heartbeat_count_value[23] ),
    .A3(_0407_),
    .B1(\heartbeat_count_value[24] ),
    .X(_0412_));
 sky130_fd_sc_hd__and2b_2 _1233_ (.A_N(_0411_),
    .B(_0412_),
    .X(_0110_));
 sky130_fd_sc_hd__nand2_2 _1234_ (.A(\heartbeat_count_value[25] ),
    .B(_0411_),
    .Y(_0413_));
 sky130_fd_sc_hd__or2_2 _1235_ (.A(\heartbeat_count_value[25] ),
    .B(_0411_),
    .X(_0414_));
 sky130_fd_sc_hd__and2_2 _1236_ (.A(_0413_),
    .B(_0414_),
    .X(_0111_));
 sky130_fd_sc_hd__xnor2_2 _1237_ (.A(\heartbeat_count_value[26] ),
    .B(_0413_),
    .Y(_0112_));
 sky130_fd_sc_hd__and4_2 _1238_ (.A(\heartbeat_count_value[25] ),
    .B(\heartbeat_count_value[26] ),
    .C(\heartbeat_count_value[27] ),
    .D(_0411_),
    .X(_0415_));
 sky130_fd_sc_hd__a31o_2 _1239_ (.A1(\heartbeat_count_value[25] ),
    .A2(\heartbeat_count_value[26] ),
    .A3(_0411_),
    .B1(\heartbeat_count_value[27] ),
    .X(_0416_));
 sky130_fd_sc_hd__and2b_2 _1240_ (.A_N(_0415_),
    .B(_0416_),
    .X(_0113_));
 sky130_fd_sc_hd__nand2_2 _1241_ (.A(\heartbeat_count_value[28] ),
    .B(_0415_),
    .Y(_0417_));
 sky130_fd_sc_hd__xor2_2 _1242_ (.A(\heartbeat_count_value[28] ),
    .B(_0415_),
    .X(_0114_));
 sky130_fd_sc_hd__xnor2_2 _1243_ (.A(\heartbeat_count_value[29] ),
    .B(_0417_),
    .Y(_0115_));
 sky130_fd_sc_hd__and4_2 _1244_ (.A(\heartbeat_count_value[28] ),
    .B(\heartbeat_count_value[29] ),
    .C(\heartbeat_count_value[30] ),
    .D(_0415_),
    .X(_0418_));
 sky130_fd_sc_hd__a31o_2 _1245_ (.A1(\heartbeat_count_value[28] ),
    .A2(\heartbeat_count_value[29] ),
    .A3(_0415_),
    .B1(\heartbeat_count_value[30] ),
    .X(_0419_));
 sky130_fd_sc_hd__and2b_2 _1246_ (.A_N(_0418_),
    .B(_0419_),
    .X(_0116_));
 sky130_fd_sc_hd__xor2_2 _1247_ (.A(\heartbeat_count_value[31] ),
    .B(_0418_),
    .X(_0117_));
 sky130_fd_sc_hd__a31oi_2 _1248_ (.A1(_0558_),
    .A2(_0566_),
    .A3(_0579_),
    .B1(reset_request),
    .Y(_0420_));
 sky130_fd_sc_hd__xor2_2 _1249_ (.A(\reset_count_value[0] ),
    .B(_0420_),
    .X(_0118_));
 sky130_fd_sc_hd__and3_2 _1250_ (.A(\reset_count_value[0] ),
    .B(\reset_count_value[1] ),
    .C(_0420_),
    .X(_0421_));
 sky130_fd_sc_hd__a21oi_2 _1251_ (.A1(\reset_count_value[0] ),
    .A2(_0420_),
    .B1(\reset_count_value[1] ),
    .Y(_0422_));
 sky130_fd_sc_hd__nor2_2 _1252_ (.A(_0421_),
    .B(_0422_),
    .Y(_0119_));
 sky130_fd_sc_hd__nor2_2 _1253_ (.A(\reset_count_value[2] ),
    .B(_0421_),
    .Y(_0423_));
 sky130_fd_sc_hd__and2_2 _1254_ (.A(\reset_count_value[2] ),
    .B(_0421_),
    .X(_0424_));
 sky130_fd_sc_hd__nor2_2 _1255_ (.A(_0423_),
    .B(_0424_),
    .Y(_0120_));
 sky130_fd_sc_hd__xor2_2 _1256_ (.A(\reset_count_value[3] ),
    .B(_0424_),
    .X(_0121_));
 sky130_fd_sc_hd__and3_2 _1257_ (.A(\reset_count_value[3] ),
    .B(\reset_count_value[4] ),
    .C(_0424_),
    .X(_0425_));
 sky130_fd_sc_hd__a21oi_2 _1258_ (.A1(\reset_count_value[3] ),
    .A2(_0424_),
    .B1(\reset_count_value[4] ),
    .Y(_0426_));
 sky130_fd_sc_hd__nor2_2 _1259_ (.A(_0425_),
    .B(_0426_),
    .Y(_0122_));
 sky130_fd_sc_hd__and2_2 _1260_ (.A(\reset_count_value[5] ),
    .B(_0425_),
    .X(_0427_));
 sky130_fd_sc_hd__xor2_2 _1261_ (.A(\reset_count_value[5] ),
    .B(_0425_),
    .X(_0123_));
 sky130_fd_sc_hd__and4_2 _1262_ (.A(\reset_count_value[0] ),
    .B(\reset_count_value[1] ),
    .C(\reset_count_value[2] ),
    .D(\reset_count_value[6] ),
    .X(_0428_));
 sky130_fd_sc_hd__and4_2 _1263_ (.A(\reset_count_value[3] ),
    .B(\reset_count_value[4] ),
    .C(\reset_count_value[5] ),
    .D(_0428_),
    .X(_0429_));
 sky130_fd_sc_hd__o2bb2a_2 _1264_ (.A1_N(_0420_),
    .A2_N(_0429_),
    .B1(_0427_),
    .B2(\reset_count_value[6] ),
    .X(_0124_));
 sky130_fd_sc_hd__and3_2 _1265_ (.A(\reset_count_value[7] ),
    .B(_0420_),
    .C(_0429_),
    .X(_0430_));
 sky130_fd_sc_hd__a21oi_2 _1266_ (.A1(_0420_),
    .A2(_0429_),
    .B1(\reset_count_value[7] ),
    .Y(_0431_));
 sky130_fd_sc_hd__nor2_2 _1267_ (.A(_0430_),
    .B(_0431_),
    .Y(_0125_));
 sky130_fd_sc_hd__xor2_2 _1268_ (.A(\reset_count_value[8] ),
    .B(_0430_),
    .X(_0126_));
 sky130_fd_sc_hd__a21oi_2 _1269_ (.A1(\reset_count_value[8] ),
    .A2(_0430_),
    .B1(\reset_count_value[9] ),
    .Y(_0432_));
 sky130_fd_sc_hd__and3_2 _1270_ (.A(\reset_count_value[8] ),
    .B(\reset_count_value[9] ),
    .C(_0430_),
    .X(_0433_));
 sky130_fd_sc_hd__nor2_2 _1271_ (.A(_0432_),
    .B(_0433_),
    .Y(_0127_));
 sky130_fd_sc_hd__xor2_2 _1272_ (.A(\reset_count_value[10] ),
    .B(_0433_),
    .X(_0128_));
 sky130_fd_sc_hd__a21oi_2 _1273_ (.A1(\reset_count_value[10] ),
    .A2(_0433_),
    .B1(\reset_count_value[11] ),
    .Y(_0434_));
 sky130_fd_sc_hd__and3_2 _1274_ (.A(\reset_count_value[10] ),
    .B(\reset_count_value[11] ),
    .C(_0433_),
    .X(_0435_));
 sky130_fd_sc_hd__nor2_2 _1275_ (.A(_0434_),
    .B(_0435_),
    .Y(_0129_));
 sky130_fd_sc_hd__and4_2 _1276_ (.A(\reset_count_value[10] ),
    .B(\reset_count_value[11] ),
    .C(\reset_count_value[12] ),
    .D(_0433_),
    .X(_0436_));
 sky130_fd_sc_hd__o21ba_2 _1277_ (.A1(\reset_count_value[12] ),
    .A2(_0435_),
    .B1_N(_0436_),
    .X(_0130_));
 sky130_fd_sc_hd__and4_2 _1278_ (.A(\reset_count_value[10] ),
    .B(\reset_count_value[11] ),
    .C(\reset_count_value[12] ),
    .D(\reset_count_value[13] ),
    .X(_0437_));
 sky130_fd_sc_hd__and2_2 _1279_ (.A(_0433_),
    .B(_0437_),
    .X(_0438_));
 sky130_fd_sc_hd__o21ba_2 _1280_ (.A1(\reset_count_value[13] ),
    .A2(_0436_),
    .B1_N(_0438_),
    .X(_0131_));
 sky130_fd_sc_hd__and4_2 _1281_ (.A(\reset_count_value[8] ),
    .B(\reset_count_value[9] ),
    .C(\reset_count_value[14] ),
    .D(_0437_),
    .X(_0439_));
 sky130_fd_sc_hd__o2bb2a_2 _1282_ (.A1_N(_0430_),
    .A2_N(_0439_),
    .B1(_0438_),
    .B2(\reset_count_value[14] ),
    .X(_0132_));
 sky130_fd_sc_hd__a21oi_2 _1283_ (.A1(_0430_),
    .A2(_0439_),
    .B1(\reset_count_value[15] ),
    .Y(_0440_));
 sky130_fd_sc_hd__and2_2 _1284_ (.A(\reset_count_value[15] ),
    .B(_0439_),
    .X(_0441_));
 sky130_fd_sc_hd__and4_2 _1285_ (.A(\reset_count_value[7] ),
    .B(_0420_),
    .C(_0429_),
    .D(_0441_),
    .X(_0442_));
 sky130_fd_sc_hd__and4_2 _1286_ (.A(\reset_count_value[7] ),
    .B(\reset_count_value[15] ),
    .C(_0429_),
    .D(_0439_),
    .X(_0443_));
 sky130_fd_sc_hd__and2_2 _1287_ (.A(_0420_),
    .B(_0443_),
    .X(_0444_));
 sky130_fd_sc_hd__nor2_2 _1288_ (.A(_0440_),
    .B(_0444_),
    .Y(_0133_));
 sky130_fd_sc_hd__nor2_2 _1289_ (.A(\reset_count_value[16] ),
    .B(_0444_),
    .Y(_0445_));
 sky130_fd_sc_hd__and3_2 _1290_ (.A(\reset_count_value[16] ),
    .B(_0420_),
    .C(_0443_),
    .X(_0446_));
 sky130_fd_sc_hd__nor2_2 _1291_ (.A(_0445_),
    .B(_0446_),
    .Y(_0134_));
 sky130_fd_sc_hd__and3_2 _1292_ (.A(\reset_count_value[16] ),
    .B(\reset_count_value[17] ),
    .C(_0444_),
    .X(_0447_));
 sky130_fd_sc_hd__o21ba_2 _1293_ (.A1(\reset_count_value[17] ),
    .A2(_0446_),
    .B1_N(_0447_),
    .X(_0135_));
 sky130_fd_sc_hd__and3_2 _1294_ (.A(\reset_count_value[16] ),
    .B(\reset_count_value[17] ),
    .C(\reset_count_value[18] ),
    .X(_0448_));
 sky130_fd_sc_hd__o2bb2a_2 _1295_ (.A1_N(_0444_),
    .A2_N(_0448_),
    .B1(_0447_),
    .B2(\reset_count_value[18] ),
    .X(_0136_));
 sky130_fd_sc_hd__a21oi_2 _1296_ (.A1(_0444_),
    .A2(_0448_),
    .B1(\reset_count_value[19] ),
    .Y(_0449_));
 sky130_fd_sc_hd__and3_2 _1297_ (.A(\reset_count_value[17] ),
    .B(\reset_count_value[18] ),
    .C(\reset_count_value[19] ),
    .X(_0450_));
 sky130_fd_sc_hd__and3_2 _1298_ (.A(\reset_count_value[16] ),
    .B(_0442_),
    .C(_0450_),
    .X(_0451_));
 sky130_fd_sc_hd__and3_2 _1299_ (.A(\reset_count_value[19] ),
    .B(_0443_),
    .C(_0448_),
    .X(_0452_));
 sky130_fd_sc_hd__nor2_2 _1300_ (.A(_0449_),
    .B(_0451_),
    .Y(_0137_));
 sky130_fd_sc_hd__nor2_2 _1301_ (.A(\reset_count_value[20] ),
    .B(_0451_),
    .Y(_0453_));
 sky130_fd_sc_hd__and2_2 _1302_ (.A(\reset_count_value[20] ),
    .B(_0451_),
    .X(_0454_));
 sky130_fd_sc_hd__nor2_2 _1303_ (.A(_0453_),
    .B(_0454_),
    .Y(_0138_));
 sky130_fd_sc_hd__and2_2 _1304_ (.A(\reset_count_value[20] ),
    .B(\reset_count_value[21] ),
    .X(_0455_));
 sky130_fd_sc_hd__and4_2 _1305_ (.A(\reset_count_value[16] ),
    .B(_0442_),
    .C(_0450_),
    .D(_0455_),
    .X(_0456_));
 sky130_fd_sc_hd__o21ba_2 _1306_ (.A1(\reset_count_value[21] ),
    .A2(_0454_),
    .B1_N(_0456_),
    .X(_0139_));
 sky130_fd_sc_hd__nand2_2 _1307_ (.A(\reset_count_value[22] ),
    .B(_0456_),
    .Y(_0457_));
 sky130_fd_sc_hd__xor2_2 _1308_ (.A(\reset_count_value[22] ),
    .B(_0456_),
    .X(_0140_));
 sky130_fd_sc_hd__and3_2 _1309_ (.A(\reset_count_value[22] ),
    .B(\reset_count_value[23] ),
    .C(_0455_),
    .X(_0458_));
 sky130_fd_sc_hd__and3_2 _1310_ (.A(_0420_),
    .B(_0452_),
    .C(_0458_),
    .X(_0459_));
 sky130_fd_sc_hd__xnor2_2 _1311_ (.A(\reset_count_value[23] ),
    .B(_0457_),
    .Y(_0141_));
 sky130_fd_sc_hd__xor2_2 _1312_ (.A(\reset_count_value[24] ),
    .B(_0459_),
    .X(_0142_));
 sky130_fd_sc_hd__a21oi_2 _1313_ (.A1(\reset_count_value[24] ),
    .A2(_0459_),
    .B1(\reset_count_value[25] ),
    .Y(_0460_));
 sky130_fd_sc_hd__and2_2 _1314_ (.A(\reset_count_value[24] ),
    .B(\reset_count_value[25] ),
    .X(_0461_));
 sky130_fd_sc_hd__and4_2 _1315_ (.A(\reset_count_value[22] ),
    .B(\reset_count_value[23] ),
    .C(_0456_),
    .D(_0461_),
    .X(_0462_));
 sky130_fd_sc_hd__nor2_2 _1316_ (.A(_0460_),
    .B(_0462_),
    .Y(_0143_));
 sky130_fd_sc_hd__or2_2 _1317_ (.A(\reset_count_value[26] ),
    .B(_0462_),
    .X(_0463_));
 sky130_fd_sc_hd__nand2_2 _1318_ (.A(\reset_count_value[26] ),
    .B(_0462_),
    .Y(_0464_));
 sky130_fd_sc_hd__and3_2 _1319_ (.A(\reset_count_value[24] ),
    .B(\reset_count_value[25] ),
    .C(\reset_count_value[26] ),
    .X(_0465_));
 sky130_fd_sc_hd__and2_2 _1320_ (.A(_0463_),
    .B(_0464_),
    .X(_0144_));
 sky130_fd_sc_hd__xnor2_2 _1321_ (.A(\reset_count_value[27] ),
    .B(_0464_),
    .Y(_0145_));
 sky130_fd_sc_hd__a31o_2 _1322_ (.A1(\reset_count_value[27] ),
    .A2(_0459_),
    .A3(_0465_),
    .B1(\reset_count_value[28] ),
    .X(_0466_));
 sky130_fd_sc_hd__nand2_2 _1323_ (.A(\reset_count_value[27] ),
    .B(\reset_count_value[28] ),
    .Y(_0467_));
 sky130_fd_sc_hd__o21a_2 _1324_ (.A1(_0464_),
    .A2(_0467_),
    .B1(_0466_),
    .X(_0146_));
 sky130_fd_sc_hd__a41o_2 _1325_ (.A1(\reset_count_value[26] ),
    .A2(\reset_count_value[27] ),
    .A3(\reset_count_value[28] ),
    .A4(_0462_),
    .B1(\reset_count_value[29] ),
    .X(_0468_));
 sky130_fd_sc_hd__and4_2 _1326_ (.A(\reset_count_value[27] ),
    .B(\reset_count_value[28] ),
    .C(\reset_count_value[29] ),
    .D(_0465_),
    .X(_0469_));
 sky130_fd_sc_hd__nand2_2 _1327_ (.A(_0459_),
    .B(_0469_),
    .Y(_0470_));
 sky130_fd_sc_hd__and2_2 _1328_ (.A(_0468_),
    .B(_0470_),
    .X(_0147_));
 sky130_fd_sc_hd__xnor2_2 _1329_ (.A(\reset_count_value[30] ),
    .B(_0470_),
    .Y(_0148_));
 sky130_fd_sc_hd__o21ai_2 _1330_ (.A1(_0545_),
    .A2(_0470_),
    .B1(\reset_count_value[31] ),
    .Y(_0471_));
 sky130_fd_sc_hd__or3_2 _1331_ (.A(_0545_),
    .B(\reset_count_value[31] ),
    .C(_0470_),
    .X(_0472_));
 sky130_fd_sc_hd__nand2_2 _1332_ (.A(_0471_),
    .B(_0472_),
    .Y(_0149_));
 sky130_fd_sc_hd__or4_2 _1333_ (.A(\u_safety_fault_watchdog_controller.masked_faults[5] ),
    .B(\u_safety_fault_watchdog_controller.masked_faults[4] ),
    .C(\u_safety_fault_watchdog_controller.masked_faults[7] ),
    .D(\u_safety_fault_watchdog_controller.masked_faults[6] ),
    .X(_0473_));
 sky130_fd_sc_hd__or3_2 _1334_ (.A(\u_safety_fault_watchdog_controller.masked_faults[1] ),
    .B(\u_safety_fault_watchdog_controller.masked_faults[0] ),
    .C(\u_safety_fault_watchdog_controller.masked_faults[3] ),
    .X(_0474_));
 sky130_fd_sc_hd__or4_2 _1335_ (.A(\u_safety_fault_watchdog_controller.masked_faults[2] ),
    .B(_0376_),
    .C(_0473_),
    .D(_0474_),
    .X(_0475_));
 sky130_fd_sc_hd__xnor2_2 _1336_ (.A(_0534_),
    .B(_0475_),
    .Y(_0150_));
 sky130_fd_sc_hd__and3_2 _1337_ (.A(\u_safety_fault_watchdog_controller.event_score[0] ),
    .B(\u_safety_fault_watchdog_controller.event_score[1] ),
    .C(_0475_),
    .X(_0476_));
 sky130_fd_sc_hd__a21oi_2 _1338_ (.A1(\u_safety_fault_watchdog_controller.event_score[0] ),
    .A2(_0475_),
    .B1(\u_safety_fault_watchdog_controller.event_score[1] ),
    .Y(_0477_));
 sky130_fd_sc_hd__nor2_2 _1339_ (.A(_0476_),
    .B(_0477_),
    .Y(_0151_));
 sky130_fd_sc_hd__xor2_2 _1340_ (.A(\u_safety_fault_watchdog_controller.event_score[2] ),
    .B(_0476_),
    .X(_0152_));
 sky130_fd_sc_hd__and4_2 _1341_ (.A(\u_safety_fault_watchdog_controller.event_score[0] ),
    .B(\u_safety_fault_watchdog_controller.event_score[3] ),
    .C(\u_safety_fault_watchdog_controller.event_score[2] ),
    .D(\u_safety_fault_watchdog_controller.event_score[1] ),
    .X(_0478_));
 sky130_fd_sc_hd__and2_2 _1342_ (.A(_0475_),
    .B(_0478_),
    .X(_0479_));
 sky130_fd_sc_hd__a21oi_2 _1343_ (.A1(\u_safety_fault_watchdog_controller.event_score[2] ),
    .A2(_0476_),
    .B1(\u_safety_fault_watchdog_controller.event_score[3] ),
    .Y(_0480_));
 sky130_fd_sc_hd__nor2_2 _1344_ (.A(_0479_),
    .B(_0480_),
    .Y(_0153_));
 sky130_fd_sc_hd__nand2_2 _1345_ (.A(\u_safety_fault_watchdog_controller.event_score[4] ),
    .B(_0479_),
    .Y(_0481_));
 sky130_fd_sc_hd__or2_2 _1346_ (.A(\u_safety_fault_watchdog_controller.event_score[4] ),
    .B(_0479_),
    .X(_0482_));
 sky130_fd_sc_hd__and2_2 _1347_ (.A(_0481_),
    .B(_0482_),
    .X(_0154_));
 sky130_fd_sc_hd__xnor2_2 _1348_ (.A(\u_safety_fault_watchdog_controller.event_score[5] ),
    .B(_0481_),
    .Y(_0155_));
 sky130_fd_sc_hd__and4_2 _1349_ (.A(\u_safety_fault_watchdog_controller.event_score[6] ),
    .B(\u_safety_fault_watchdog_controller.event_score[5] ),
    .C(\u_safety_fault_watchdog_controller.event_score[4] ),
    .D(_0479_),
    .X(_0483_));
 sky130_fd_sc_hd__o21a_2 _1350_ (.A1(_0538_),
    .A2(_0481_),
    .B1(_0537_),
    .X(_0484_));
 sky130_fd_sc_hd__nor2_2 _1351_ (.A(_0483_),
    .B(_0484_),
    .Y(_0156_));
 sky130_fd_sc_hd__and4_2 _1352_ (.A(\u_safety_fault_watchdog_controller.event_score[7] ),
    .B(\u_safety_fault_watchdog_controller.event_score[6] ),
    .C(\u_safety_fault_watchdog_controller.event_score[5] ),
    .D(\u_safety_fault_watchdog_controller.event_score[4] ),
    .X(_0485_));
 sky130_fd_sc_hd__nand2_2 _1353_ (.A(_0479_),
    .B(_0485_),
    .Y(_0486_));
 sky130_fd_sc_hd__o21a_2 _1354_ (.A1(\u_safety_fault_watchdog_controller.event_score[7] ),
    .A2(_0483_),
    .B1(_0486_),
    .X(_0157_));
 sky130_fd_sc_hd__xnor2_2 _1355_ (.A(\u_safety_fault_watchdog_controller.event_score[8] ),
    .B(_0486_),
    .Y(_0158_));
 sky130_fd_sc_hd__a31oi_2 _1356_ (.A1(\u_safety_fault_watchdog_controller.event_score[8] ),
    .A2(_0479_),
    .A3(_0485_),
    .B1(\u_safety_fault_watchdog_controller.event_score[9] ),
    .Y(_0487_));
 sky130_fd_sc_hd__and4_2 _1357_ (.A(\u_safety_fault_watchdog_controller.event_score[8] ),
    .B(\u_safety_fault_watchdog_controller.event_score[9] ),
    .C(_0479_),
    .D(_0485_),
    .X(_0488_));
 sky130_fd_sc_hd__nor2_2 _1358_ (.A(_0487_),
    .B(_0488_),
    .Y(_0159_));
 sky130_fd_sc_hd__and3_2 _1359_ (.A(\u_safety_fault_watchdog_controller.event_score[10] ),
    .B(\u_safety_fault_watchdog_controller.event_score[8] ),
    .C(\u_safety_fault_watchdog_controller.event_score[9] ),
    .X(_0489_));
 sky130_fd_sc_hd__xor2_2 _1360_ (.A(\u_safety_fault_watchdog_controller.event_score[10] ),
    .B(_0488_),
    .X(_0160_));
 sky130_fd_sc_hd__a21oi_2 _1361_ (.A1(\u_safety_fault_watchdog_controller.event_score[10] ),
    .A2(_0488_),
    .B1(\u_safety_fault_watchdog_controller.event_score[11] ),
    .Y(_0490_));
 sky130_fd_sc_hd__and4_2 _1362_ (.A(\u_safety_fault_watchdog_controller.event_score[11] ),
    .B(\u_safety_fault_watchdog_controller.event_score[10] ),
    .C(\u_safety_fault_watchdog_controller.event_score[8] ),
    .D(\u_safety_fault_watchdog_controller.event_score[9] ),
    .X(_0491_));
 sky130_fd_sc_hd__and4_2 _1363_ (.A(_0475_),
    .B(_0478_),
    .C(_0485_),
    .D(_0491_),
    .X(_0492_));
 sky130_fd_sc_hd__and4_2 _1364_ (.A(\u_safety_fault_watchdog_controller.event_score[11] ),
    .B(_0478_),
    .C(_0485_),
    .D(_0489_),
    .X(_0493_));
 sky130_fd_sc_hd__nor2_2 _1365_ (.A(_0490_),
    .B(_0492_),
    .Y(_0161_));
 sky130_fd_sc_hd__xor2_2 _1366_ (.A(\u_safety_fault_watchdog_controller.event_score[12] ),
    .B(_0492_),
    .X(_0162_));
 sky130_fd_sc_hd__a21oi_2 _1367_ (.A1(\u_safety_fault_watchdog_controller.event_score[12] ),
    .A2(_0492_),
    .B1(\u_safety_fault_watchdog_controller.event_score[13] ),
    .Y(_0494_));
 sky130_fd_sc_hd__and4_2 _1368_ (.A(\u_safety_fault_watchdog_controller.event_score[13] ),
    .B(\u_safety_fault_watchdog_controller.event_score[12] ),
    .C(_0475_),
    .D(_0493_),
    .X(_0495_));
 sky130_fd_sc_hd__nor2_2 _1369_ (.A(_0494_),
    .B(_0495_),
    .Y(_0163_));
 sky130_fd_sc_hd__xor2_2 _1370_ (.A(\u_safety_fault_watchdog_controller.event_score[14] ),
    .B(_0495_),
    .X(_0164_));
 sky130_fd_sc_hd__a21oi_2 _1371_ (.A1(\u_safety_fault_watchdog_controller.event_score[14] ),
    .A2(_0495_),
    .B1(\u_safety_fault_watchdog_controller.event_score[15] ),
    .Y(_0496_));
 sky130_fd_sc_hd__and4_2 _1372_ (.A(\u_safety_fault_watchdog_controller.event_score[15] ),
    .B(\u_safety_fault_watchdog_controller.event_score[14] ),
    .C(\u_safety_fault_watchdog_controller.event_score[13] ),
    .D(\u_safety_fault_watchdog_controller.event_score[12] ),
    .X(_0497_));
 sky130_fd_sc_hd__a21oi_2 _1373_ (.A1(_0492_),
    .A2(_0497_),
    .B1(_0496_),
    .Y(_0165_));
 sky130_fd_sc_hd__a21oi_2 _1374_ (.A1(_0492_),
    .A2(_0497_),
    .B1(\u_safety_fault_watchdog_controller.event_score[16] ),
    .Y(_0498_));
 sky130_fd_sc_hd__and3_2 _1375_ (.A(\u_safety_fault_watchdog_controller.event_score[16] ),
    .B(_0493_),
    .C(_0497_),
    .X(_0499_));
 sky130_fd_sc_hd__and2_2 _1376_ (.A(_0475_),
    .B(_0499_),
    .X(_0500_));
 sky130_fd_sc_hd__nor2_2 _1377_ (.A(_0498_),
    .B(_0500_),
    .Y(_0166_));
 sky130_fd_sc_hd__xor2_2 _1378_ (.A(\u_safety_fault_watchdog_controller.event_score[17] ),
    .B(_0500_),
    .X(_0167_));
 sky130_fd_sc_hd__a21oi_2 _1379_ (.A1(\u_safety_fault_watchdog_controller.event_score[17] ),
    .A2(_0500_),
    .B1(\u_safety_fault_watchdog_controller.event_score[18] ),
    .Y(_0501_));
 sky130_fd_sc_hd__and3_2 _1380_ (.A(\u_safety_fault_watchdog_controller.event_score[18] ),
    .B(\u_safety_fault_watchdog_controller.event_score[17] ),
    .C(_0500_),
    .X(_0502_));
 sky130_fd_sc_hd__nor2_2 _1381_ (.A(_0501_),
    .B(_0502_),
    .Y(_0168_));
 sky130_fd_sc_hd__and4_2 _1382_ (.A(\u_safety_fault_watchdog_controller.event_score[18] ),
    .B(\u_safety_fault_watchdog_controller.event_score[19] ),
    .C(\u_safety_fault_watchdog_controller.event_score[17] ),
    .D(_0499_),
    .X(_0503_));
 sky130_fd_sc_hd__and2_2 _1383_ (.A(_0475_),
    .B(_0503_),
    .X(_0504_));
 sky130_fd_sc_hd__o21ba_2 _1384_ (.A1(\u_safety_fault_watchdog_controller.event_score[19] ),
    .A2(_0502_),
    .B1_N(_0504_),
    .X(_0169_));
 sky130_fd_sc_hd__xor2_2 _1385_ (.A(\u_safety_fault_watchdog_controller.event_score[20] ),
    .B(_0504_),
    .X(_0170_));
 sky130_fd_sc_hd__a21oi_2 _1386_ (.A1(\u_safety_fault_watchdog_controller.event_score[20] ),
    .A2(_0504_),
    .B1(\u_safety_fault_watchdog_controller.event_score[21] ),
    .Y(_0505_));
 sky130_fd_sc_hd__and3_2 _1387_ (.A(\u_safety_fault_watchdog_controller.event_score[20] ),
    .B(\u_safety_fault_watchdog_controller.event_score[21] ),
    .C(_0504_),
    .X(_0506_));
 sky130_fd_sc_hd__nor2_2 _1388_ (.A(_0505_),
    .B(_0506_),
    .Y(_0171_));
 sky130_fd_sc_hd__xor2_2 _1389_ (.A(\u_safety_fault_watchdog_controller.event_score[22] ),
    .B(_0506_),
    .X(_0172_));
 sky130_fd_sc_hd__a21oi_2 _1390_ (.A1(\u_safety_fault_watchdog_controller.event_score[22] ),
    .A2(_0506_),
    .B1(\u_safety_fault_watchdog_controller.event_score[23] ),
    .Y(_0507_));
 sky130_fd_sc_hd__and4_2 _1391_ (.A(\u_safety_fault_watchdog_controller.event_score[23] ),
    .B(\u_safety_fault_watchdog_controller.event_score[22] ),
    .C(\u_safety_fault_watchdog_controller.event_score[20] ),
    .D(\u_safety_fault_watchdog_controller.event_score[21] ),
    .X(_0508_));
 sky130_fd_sc_hd__and3_2 _1392_ (.A(_0475_),
    .B(_0503_),
    .C(_0508_),
    .X(_0509_));
 sky130_fd_sc_hd__nor2_2 _1393_ (.A(_0507_),
    .B(_0509_),
    .Y(_0173_));
 sky130_fd_sc_hd__xor2_2 _1394_ (.A(\u_safety_fault_watchdog_controller.event_score[24] ),
    .B(_0509_),
    .X(_0174_));
 sky130_fd_sc_hd__a21oi_2 _1395_ (.A1(\u_safety_fault_watchdog_controller.event_score[24] ),
    .A2(_0509_),
    .B1(\u_safety_fault_watchdog_controller.event_score[25] ),
    .Y(_0510_));
 sky130_fd_sc_hd__and3_2 _1396_ (.A(\u_safety_fault_watchdog_controller.event_score[25] ),
    .B(\u_safety_fault_watchdog_controller.event_score[24] ),
    .C(_0509_),
    .X(_0511_));
 sky130_fd_sc_hd__nor2_2 _1397_ (.A(_0510_),
    .B(_0511_),
    .Y(_0175_));
 sky130_fd_sc_hd__and3_2 _1398_ (.A(\u_safety_fault_watchdog_controller.event_score[25] ),
    .B(\u_safety_fault_watchdog_controller.event_score[24] ),
    .C(\u_safety_fault_watchdog_controller.event_score[26] ),
    .X(_0512_));
 sky130_fd_sc_hd__nand2_2 _1399_ (.A(_0509_),
    .B(_0512_),
    .Y(_0513_));
 sky130_fd_sc_hd__o21a_2 _1400_ (.A1(\u_safety_fault_watchdog_controller.event_score[26] ),
    .A2(_0511_),
    .B1(_0513_),
    .X(_0176_));
 sky130_fd_sc_hd__a21oi_2 _1401_ (.A1(_0509_),
    .A2(_0512_),
    .B1(\u_safety_fault_watchdog_controller.event_score[27] ),
    .Y(_0514_));
 sky130_fd_sc_hd__and3_2 _1402_ (.A(\u_safety_fault_watchdog_controller.event_score[27] ),
    .B(_0509_),
    .C(_0512_),
    .X(_0515_));
 sky130_fd_sc_hd__nor2_2 _1403_ (.A(_0514_),
    .B(_0515_),
    .Y(_0177_));
 sky130_fd_sc_hd__xor2_2 _1404_ (.A(\u_safety_fault_watchdog_controller.event_score[28] ),
    .B(_0515_),
    .X(_0178_));
 sky130_fd_sc_hd__a21oi_2 _1405_ (.A1(\u_safety_fault_watchdog_controller.event_score[28] ),
    .A2(_0515_),
    .B1(\u_safety_fault_watchdog_controller.event_score[29] ),
    .Y(_0516_));
 sky130_fd_sc_hd__and3_2 _1406_ (.A(\u_safety_fault_watchdog_controller.event_score[29] ),
    .B(\u_safety_fault_watchdog_controller.event_score[28] ),
    .C(_0515_),
    .X(_0517_));
 sky130_fd_sc_hd__nor2_2 _1407_ (.A(_0516_),
    .B(_0517_),
    .Y(_0179_));
 sky130_fd_sc_hd__nor2_2 _1408_ (.A(\u_safety_fault_watchdog_controller.event_score[30] ),
    .B(_0517_),
    .Y(_0518_));
 sky130_fd_sc_hd__nand2_2 _1409_ (.A(\u_safety_fault_watchdog_controller.event_score[30] ),
    .B(_0517_),
    .Y(_0519_));
 sky130_fd_sc_hd__and2b_2 _1410_ (.A_N(_0518_),
    .B(_0519_),
    .X(_0180_));
 sky130_fd_sc_hd__xnor2_2 _1411_ (.A(\u_safety_fault_watchdog_controller.event_score[31] ),
    .B(_0519_),
    .Y(_0181_));
 sky130_fd_sc_hd__o21ba_2 _1412_ (.A1(\u_safety_fault_watchdog_controller.masked_faults[0] ),
    .A2(fault_latched[0]),
    .B1_N(fault_clear_pulse),
    .X(_0182_));
 sky130_fd_sc_hd__o21ba_2 _1413_ (.A1(\u_safety_fault_watchdog_controller.masked_faults[1] ),
    .A2(fault_latched[1]),
    .B1_N(fault_clear_pulse),
    .X(_0183_));
 sky130_fd_sc_hd__o21ba_2 _1414_ (.A1(\u_safety_fault_watchdog_controller.masked_faults[2] ),
    .A2(fault_latched[2]),
    .B1_N(fault_clear_pulse),
    .X(_0184_));
 sky130_fd_sc_hd__o21ba_2 _1415_ (.A1(\u_safety_fault_watchdog_controller.masked_faults[3] ),
    .A2(fault_latched[3]),
    .B1_N(fault_clear_pulse),
    .X(_0185_));
 sky130_fd_sc_hd__o21ba_2 _1416_ (.A1(\u_safety_fault_watchdog_controller.masked_faults[4] ),
    .A2(fault_latched[4]),
    .B1_N(fault_clear_pulse),
    .X(_0186_));
 sky130_fd_sc_hd__o21ba_2 _1417_ (.A1(\u_safety_fault_watchdog_controller.masked_faults[5] ),
    .A2(fault_latched[5]),
    .B1_N(fault_clear_pulse),
    .X(_0187_));
 sky130_fd_sc_hd__o21ba_2 _1418_ (.A1(\u_safety_fault_watchdog_controller.masked_faults[6] ),
    .A2(fault_latched[6]),
    .B1_N(fault_clear_pulse),
    .X(_0188_));
 sky130_fd_sc_hd__o21ba_2 _1419_ (.A1(\u_safety_fault_watchdog_controller.masked_faults[7] ),
    .A2(fault_latched[7]),
    .B1_N(fault_clear_pulse),
    .X(_0189_));
 sky130_fd_sc_hd__a21o_2 _1420_ (.A1(_0543_),
    .A2(\irq_status_value[3] ),
    .B1(_0000_),
    .X(_0190_));
 sky130_fd_sc_hd__nor2_2 _1421_ (.A(fault_clear_pulse),
    .B(\irq_clear_pulse[1] ),
    .Y(_0520_));
 sky130_fd_sc_hd__o41a_2 _1422_ (.A1(\u_safety_fault_watchdog_controller.masked_faults[2] ),
    .A2(\irq_status_value[1] ),
    .A3(_0473_),
    .A4(_0474_),
    .B1(_0520_),
    .X(_0191_));
 sky130_fd_sc_hd__o21ba_2 _1423_ (.A1(\irq_status_value[0] ),
    .A2(_0376_),
    .B1_N(\irq_clear_pulse[0] ),
    .X(_0192_));
 sky130_fd_sc_hd__or3b_2 _1424_ (.A(wr_addr[5]),
    .B(_0595_),
    .C_N(wr_addr[4]),
    .X(_0521_));
 sky130_fd_sc_hd__or2_2 _1425_ (.A(_0594_),
    .B(_0521_),
    .X(_0522_));
 sky130_fd_sc_hd__mux2_1 _1426_ (.A0(wr_data[0]),
    .A1(\fault_mask_cfg[0] ),
    .S(_0522_),
    .X(_0193_));
 sky130_fd_sc_hd__mux2_1 _1427_ (.A0(wr_data[1]),
    .A1(\fault_mask_cfg[1] ),
    .S(_0522_),
    .X(_0194_));
 sky130_fd_sc_hd__mux2_1 _1428_ (.A0(wr_data[2]),
    .A1(\fault_mask_cfg[2] ),
    .S(_0522_),
    .X(_0195_));
 sky130_fd_sc_hd__mux2_1 _1429_ (.A0(wr_data[3]),
    .A1(\fault_mask_cfg[3] ),
    .S(_0522_),
    .X(_0196_));
 sky130_fd_sc_hd__mux2_1 _1430_ (.A0(wr_data[4]),
    .A1(\fault_mask_cfg[4] ),
    .S(_0522_),
    .X(_0197_));
 sky130_fd_sc_hd__mux2_1 _1431_ (.A0(wr_data[5]),
    .A1(\fault_mask_cfg[5] ),
    .S(_0522_),
    .X(_0198_));
 sky130_fd_sc_hd__mux2_1 _1432_ (.A0(wr_data[6]),
    .A1(\fault_mask_cfg[6] ),
    .S(_0522_),
    .X(_0199_));
 sky130_fd_sc_hd__mux2_1 _1433_ (.A0(wr_data[7]),
    .A1(\fault_mask_cfg[7] ),
    .S(_0522_),
    .X(_0200_));
 sky130_fd_sc_hd__mux2_1 _1434_ (.A0(wr_data[2]),
    .A1(irq_enable),
    .S(_0596_),
    .X(_0201_));
 sky130_fd_sc_hd__or4b_2 _1435_ (.A(wr_addr[2]),
    .B(_0592_),
    .C(_0593_),
    .D_N(wr_addr[3]),
    .X(_0523_));
 sky130_fd_sc_hd__or2_2 _1436_ (.A(_0521_),
    .B(_0523_),
    .X(_0524_));
 sky130_fd_sc_hd__mux2_1 _1437_ (.A0(wr_data[0]),
    .A1(\escalation_policy_cfg[0] ),
    .S(_0524_),
    .X(_0202_));
 sky130_fd_sc_hd__mux2_1 _1438_ (.A0(wr_data[1]),
    .A1(\escalation_policy_cfg[1] ),
    .S(_0524_),
    .X(_0203_));
 sky130_fd_sc_hd__mux2_1 _1439_ (.A0(wr_data[2]),
    .A1(\escalation_policy_cfg[2] ),
    .S(_0524_),
    .X(_0204_));
 sky130_fd_sc_hd__mux2_1 _1440_ (.A0(wr_data[3]),
    .A1(\escalation_policy_cfg[3] ),
    .S(_0524_),
    .X(_0205_));
 sky130_fd_sc_hd__mux2_1 _1441_ (.A0(wr_data[4]),
    .A1(\escalation_policy_cfg[4] ),
    .S(_0524_),
    .X(_0206_));
 sky130_fd_sc_hd__mux2_1 _1442_ (.A0(wr_data[5]),
    .A1(\escalation_policy_cfg[5] ),
    .S(_0524_),
    .X(_0207_));
 sky130_fd_sc_hd__mux2_1 _1443_ (.A0(wr_data[6]),
    .A1(\escalation_policy_cfg[6] ),
    .S(_0524_),
    .X(_0208_));
 sky130_fd_sc_hd__mux2_1 _1444_ (.A0(wr_data[7]),
    .A1(\escalation_policy_cfg[7] ),
    .S(_0524_),
    .X(_0209_));
 sky130_fd_sc_hd__mux2_1 _1445_ (.A0(wr_data[8]),
    .A1(\escalation_policy_cfg[8] ),
    .S(_0524_),
    .X(_0210_));
 sky130_fd_sc_hd__mux2_1 _1446_ (.A0(wr_data[9]),
    .A1(\escalation_policy_cfg[9] ),
    .S(_0524_),
    .X(_0211_));
 sky130_fd_sc_hd__mux2_1 _1447_ (.A0(wr_data[10]),
    .A1(\escalation_policy_cfg[10] ),
    .S(_0524_),
    .X(_0212_));
 sky130_fd_sc_hd__mux2_1 _1448_ (.A0(wr_data[11]),
    .A1(\escalation_policy_cfg[11] ),
    .S(_0524_),
    .X(_0213_));
 sky130_fd_sc_hd__mux2_1 _1449_ (.A0(wr_data[12]),
    .A1(\escalation_policy_cfg[12] ),
    .S(_0524_),
    .X(_0214_));
 sky130_fd_sc_hd__mux2_1 _1450_ (.A0(wr_data[13]),
    .A1(\escalation_policy_cfg[13] ),
    .S(_0524_),
    .X(_0215_));
 sky130_fd_sc_hd__mux2_1 _1451_ (.A0(wr_data[14]),
    .A1(\escalation_policy_cfg[14] ),
    .S(_0524_),
    .X(_0216_));
 sky130_fd_sc_hd__mux2_1 _1452_ (.A0(wr_data[15]),
    .A1(\escalation_policy_cfg[15] ),
    .S(_0524_),
    .X(_0217_));
 sky130_fd_sc_hd__mux2_1 _1453_ (.A0(wr_data[16]),
    .A1(\escalation_policy_cfg[16] ),
    .S(_0524_),
    .X(_0218_));
 sky130_fd_sc_hd__mux2_1 _1454_ (.A0(wr_data[17]),
    .A1(\escalation_policy_cfg[17] ),
    .S(_0524_),
    .X(_0219_));
 sky130_fd_sc_hd__mux2_1 _1455_ (.A0(wr_data[18]),
    .A1(\escalation_policy_cfg[18] ),
    .S(_0524_),
    .X(_0220_));
 sky130_fd_sc_hd__mux2_1 _1456_ (.A0(wr_data[19]),
    .A1(\escalation_policy_cfg[19] ),
    .S(_0524_),
    .X(_0221_));
 sky130_fd_sc_hd__mux2_1 _1457_ (.A0(wr_data[20]),
    .A1(\escalation_policy_cfg[20] ),
    .S(_0524_),
    .X(_0222_));
 sky130_fd_sc_hd__mux2_1 _1458_ (.A0(wr_data[21]),
    .A1(\escalation_policy_cfg[21] ),
    .S(_0524_),
    .X(_0223_));
 sky130_fd_sc_hd__mux2_1 _1459_ (.A0(wr_data[22]),
    .A1(\escalation_policy_cfg[22] ),
    .S(_0524_),
    .X(_0224_));
 sky130_fd_sc_hd__mux2_1 _1460_ (.A0(wr_data[23]),
    .A1(\escalation_policy_cfg[23] ),
    .S(_0524_),
    .X(_0225_));
 sky130_fd_sc_hd__mux2_1 _1461_ (.A0(wr_data[24]),
    .A1(\escalation_policy_cfg[24] ),
    .S(_0524_),
    .X(_0226_));
 sky130_fd_sc_hd__mux2_1 _1462_ (.A0(wr_data[25]),
    .A1(\escalation_policy_cfg[25] ),
    .S(_0524_),
    .X(_0227_));
 sky130_fd_sc_hd__mux2_1 _1463_ (.A0(wr_data[26]),
    .A1(\escalation_policy_cfg[26] ),
    .S(_0524_),
    .X(_0228_));
 sky130_fd_sc_hd__mux2_1 _1464_ (.A0(wr_data[27]),
    .A1(\escalation_policy_cfg[27] ),
    .S(_0524_),
    .X(_0229_));
 sky130_fd_sc_hd__mux2_1 _1465_ (.A0(wr_data[28]),
    .A1(\escalation_policy_cfg[28] ),
    .S(_0524_),
    .X(_0230_));
 sky130_fd_sc_hd__mux2_1 _1466_ (.A0(wr_data[29]),
    .A1(\escalation_policy_cfg[29] ),
    .S(_0524_),
    .X(_0231_));
 sky130_fd_sc_hd__mux2_1 _1467_ (.A0(wr_data[30]),
    .A1(\escalation_policy_cfg[30] ),
    .S(_0524_),
    .X(_0232_));
 sky130_fd_sc_hd__mux2_1 _1468_ (.A0(wr_data[31]),
    .A1(\escalation_policy_cfg[31] ),
    .S(_0524_),
    .X(_0233_));
 sky130_fd_sc_hd__mux2_1 _1469_ (.A0(wr_data[1]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_enable ),
    .S(_0596_),
    .X(_0234_));
 sky130_fd_sc_hd__mux2_1 _1470_ (.A0(wr_data[0]),
    .A1(control_enable),
    .S(_0596_),
    .X(_0235_));
 sky130_fd_sc_hd__or4_2 _1471_ (.A(wr_addr[4]),
    .B(wr_addr[5]),
    .C(_0595_),
    .D(_0523_),
    .X(_0525_));
 sky130_fd_sc_hd__mux2_1 _1472_ (.A0(wr_data[0]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[0] ),
    .S(_0525_),
    .X(_0236_));
 sky130_fd_sc_hd__mux2_1 _1473_ (.A0(wr_data[1]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[1] ),
    .S(_0525_),
    .X(_0237_));
 sky130_fd_sc_hd__mux2_1 _1474_ (.A0(wr_data[2]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[2] ),
    .S(_0525_),
    .X(_0238_));
 sky130_fd_sc_hd__mux2_1 _1475_ (.A0(wr_data[3]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[3] ),
    .S(_0525_),
    .X(_0239_));
 sky130_fd_sc_hd__mux2_1 _1476_ (.A0(wr_data[4]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[4] ),
    .S(_0525_),
    .X(_0240_));
 sky130_fd_sc_hd__mux2_1 _1477_ (.A0(wr_data[5]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[5] ),
    .S(_0525_),
    .X(_0241_));
 sky130_fd_sc_hd__mux2_1 _1478_ (.A0(wr_data[6]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[6] ),
    .S(_0525_),
    .X(_0242_));
 sky130_fd_sc_hd__mux2_1 _1479_ (.A0(wr_data[7]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[7] ),
    .S(_0525_),
    .X(_0243_));
 sky130_fd_sc_hd__mux2_1 _1480_ (.A0(wr_data[8]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[8] ),
    .S(_0525_),
    .X(_0244_));
 sky130_fd_sc_hd__mux2_1 _1481_ (.A0(wr_data[9]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[9] ),
    .S(_0525_),
    .X(_0245_));
 sky130_fd_sc_hd__mux2_1 _1482_ (.A0(wr_data[10]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[10] ),
    .S(_0525_),
    .X(_0246_));
 sky130_fd_sc_hd__mux2_1 _1483_ (.A0(wr_data[11]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[11] ),
    .S(_0525_),
    .X(_0247_));
 sky130_fd_sc_hd__mux2_1 _1484_ (.A0(wr_data[12]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[12] ),
    .S(_0525_),
    .X(_0248_));
 sky130_fd_sc_hd__mux2_1 _1485_ (.A0(wr_data[13]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[13] ),
    .S(_0525_),
    .X(_0249_));
 sky130_fd_sc_hd__mux2_1 _1486_ (.A0(wr_data[14]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[14] ),
    .S(_0525_),
    .X(_0250_));
 sky130_fd_sc_hd__mux2_1 _1487_ (.A0(wr_data[15]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[15] ),
    .S(_0525_),
    .X(_0251_));
 sky130_fd_sc_hd__mux2_1 _1488_ (.A0(wr_data[16]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[16] ),
    .S(_0525_),
    .X(_0252_));
 sky130_fd_sc_hd__mux2_1 _1489_ (.A0(wr_data[17]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[17] ),
    .S(_0525_),
    .X(_0253_));
 sky130_fd_sc_hd__mux2_1 _1490_ (.A0(wr_data[18]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[18] ),
    .S(_0525_),
    .X(_0254_));
 sky130_fd_sc_hd__mux2_1 _1491_ (.A0(wr_data[19]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[19] ),
    .S(_0525_),
    .X(_0255_));
 sky130_fd_sc_hd__mux2_1 _1492_ (.A0(wr_data[20]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[20] ),
    .S(_0525_),
    .X(_0256_));
 sky130_fd_sc_hd__mux2_1 _1493_ (.A0(wr_data[21]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[21] ),
    .S(_0525_),
    .X(_0257_));
 sky130_fd_sc_hd__mux2_1 _1494_ (.A0(wr_data[22]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[22] ),
    .S(_0525_),
    .X(_0258_));
 sky130_fd_sc_hd__mux2_1 _1495_ (.A0(wr_data[23]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[23] ),
    .S(_0525_),
    .X(_0259_));
 sky130_fd_sc_hd__mux2_1 _1496_ (.A0(wr_data[24]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[24] ),
    .S(_0525_),
    .X(_0260_));
 sky130_fd_sc_hd__mux2_1 _1497_ (.A0(wr_data[25]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[25] ),
    .S(_0525_),
    .X(_0261_));
 sky130_fd_sc_hd__mux2_1 _1498_ (.A0(wr_data[26]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[26] ),
    .S(_0525_),
    .X(_0262_));
 sky130_fd_sc_hd__mux2_1 _1499_ (.A0(wr_data[27]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[27] ),
    .S(_0525_),
    .X(_0263_));
 sky130_fd_sc_hd__mux2_1 _1500_ (.A0(wr_data[28]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[28] ),
    .S(_0525_),
    .X(_0264_));
 sky130_fd_sc_hd__mux2_1 _1501_ (.A0(wr_data[29]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[29] ),
    .S(_0525_),
    .X(_0265_));
 sky130_fd_sc_hd__mux2_1 _1502_ (.A0(wr_data[30]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[30] ),
    .S(_0525_),
    .X(_0266_));
 sky130_fd_sc_hd__mux2_1 _1503_ (.A0(wr_data[31]),
    .A1(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[31] ),
    .S(_0525_),
    .X(_0267_));
 sky130_fd_sc_hd__and2b_2 _1504_ (.A_N(reset_n),
    .B(\u_safety_fault_watchdog_controller.masked_faults[0] ),
    .X(_0526_));
 sky130_fd_sc_hd__a31o_2 _1505_ (.A1(\fault_mask_cfg[0] ),
    .A2(fault_in[0]),
    .A3(reset_n),
    .B1(_0526_),
    .X(_0268_));
 sky130_fd_sc_hd__and2b_2 _1506_ (.A_N(reset_n),
    .B(\u_safety_fault_watchdog_controller.masked_faults[1] ),
    .X(_0527_));
 sky130_fd_sc_hd__a31o_2 _1507_ (.A1(\fault_mask_cfg[1] ),
    .A2(fault_in[1]),
    .A3(reset_n),
    .B1(_0527_),
    .X(_0269_));
 sky130_fd_sc_hd__and2b_2 _1508_ (.A_N(reset_n),
    .B(\u_safety_fault_watchdog_controller.masked_faults[2] ),
    .X(_0528_));
 sky130_fd_sc_hd__a31o_2 _1509_ (.A1(\fault_mask_cfg[2] ),
    .A2(fault_in[2]),
    .A3(reset_n),
    .B1(_0528_),
    .X(_0270_));
 sky130_fd_sc_hd__and2b_2 _1510_ (.A_N(reset_n),
    .B(\u_safety_fault_watchdog_controller.masked_faults[3] ),
    .X(_0529_));
 sky130_fd_sc_hd__a31o_2 _1511_ (.A1(\fault_mask_cfg[3] ),
    .A2(fault_in[3]),
    .A3(reset_n),
    .B1(_0529_),
    .X(_0271_));
 sky130_fd_sc_hd__and2b_2 _1512_ (.A_N(reset_n),
    .B(\u_safety_fault_watchdog_controller.masked_faults[4] ),
    .X(_0530_));
 sky130_fd_sc_hd__a31o_2 _1513_ (.A1(\fault_mask_cfg[4] ),
    .A2(fault_in[4]),
    .A3(reset_n),
    .B1(_0530_),
    .X(_0272_));
 sky130_fd_sc_hd__and2b_2 _1514_ (.A_N(reset_n),
    .B(\u_safety_fault_watchdog_controller.masked_faults[5] ),
    .X(_0531_));
 sky130_fd_sc_hd__a31o_2 _1515_ (.A1(\fault_mask_cfg[5] ),
    .A2(fault_in[5]),
    .A3(reset_n),
    .B1(_0531_),
    .X(_0273_));
 sky130_fd_sc_hd__and2b_2 _1516_ (.A_N(reset_n),
    .B(\u_safety_fault_watchdog_controller.masked_faults[6] ),
    .X(_0532_));
 sky130_fd_sc_hd__a31o_2 _1517_ (.A1(\fault_mask_cfg[6] ),
    .A2(fault_in[6]),
    .A3(reset_n),
    .B1(_0532_),
    .X(_0274_));
 sky130_fd_sc_hd__and2b_2 _1518_ (.A_N(reset_n),
    .B(\u_safety_fault_watchdog_controller.masked_faults[7] ),
    .X(_0533_));
 sky130_fd_sc_hd__a31o_2 _1519_ (.A1(\fault_mask_cfg[7] ),
    .A2(fault_in[7]),
    .A3(reset_n),
    .B1(_0533_),
    .X(_0275_));
 sky130_fd_sc_hd__mux2_1 _1520_ (.A0(wr_data[0]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[0] ),
    .S(_0596_),
    .X(_0276_));
 sky130_fd_sc_hd__mux2_1 _1521_ (.A0(wr_data[1]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[1] ),
    .S(_0596_),
    .X(_0277_));
 sky130_fd_sc_hd__mux2_1 _1522_ (.A0(wr_data[2]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[2] ),
    .S(_0596_),
    .X(_0278_));
 sky130_fd_sc_hd__a21o_2 _1523_ (.A1(\u_safety_fault_watchdog_mmio.control_reg[3] ),
    .A2(_0596_),
    .B1(_0036_),
    .X(_0279_));
 sky130_fd_sc_hd__mux2_1 _1524_ (.A0(wr_data[4]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[4] ),
    .S(_0596_),
    .X(_0280_));
 sky130_fd_sc_hd__mux2_1 _1525_ (.A0(wr_data[5]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[5] ),
    .S(_0596_),
    .X(_0281_));
 sky130_fd_sc_hd__mux2_1 _1526_ (.A0(wr_data[6]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[6] ),
    .S(_0596_),
    .X(_0282_));
 sky130_fd_sc_hd__mux2_1 _1527_ (.A0(wr_data[7]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[7] ),
    .S(_0596_),
    .X(_0283_));
 sky130_fd_sc_hd__mux2_1 _1528_ (.A0(wr_data[8]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[8] ),
    .S(_0596_),
    .X(_0284_));
 sky130_fd_sc_hd__mux2_1 _1529_ (.A0(wr_data[9]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[9] ),
    .S(_0596_),
    .X(_0285_));
 sky130_fd_sc_hd__mux2_1 _1530_ (.A0(wr_data[10]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[10] ),
    .S(_0596_),
    .X(_0286_));
 sky130_fd_sc_hd__mux2_1 _1531_ (.A0(wr_data[11]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[11] ),
    .S(_0596_),
    .X(_0287_));
 sky130_fd_sc_hd__mux2_1 _1532_ (.A0(wr_data[12]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[12] ),
    .S(_0596_),
    .X(_0288_));
 sky130_fd_sc_hd__mux2_1 _1533_ (.A0(wr_data[13]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[13] ),
    .S(_0596_),
    .X(_0289_));
 sky130_fd_sc_hd__mux2_1 _1534_ (.A0(wr_data[14]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[14] ),
    .S(_0596_),
    .X(_0290_));
 sky130_fd_sc_hd__mux2_1 _1535_ (.A0(wr_data[15]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[15] ),
    .S(_0596_),
    .X(_0291_));
 sky130_fd_sc_hd__mux2_1 _1536_ (.A0(wr_data[16]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[16] ),
    .S(_0596_),
    .X(_0292_));
 sky130_fd_sc_hd__mux2_1 _1537_ (.A0(wr_data[17]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[17] ),
    .S(_0596_),
    .X(_0293_));
 sky130_fd_sc_hd__mux2_1 _1538_ (.A0(wr_data[18]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[18] ),
    .S(_0596_),
    .X(_0294_));
 sky130_fd_sc_hd__mux2_1 _1539_ (.A0(wr_data[19]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[19] ),
    .S(_0596_),
    .X(_0295_));
 sky130_fd_sc_hd__mux2_1 _1540_ (.A0(wr_data[20]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[20] ),
    .S(_0596_),
    .X(_0296_));
 sky130_fd_sc_hd__mux2_1 _1541_ (.A0(wr_data[21]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[21] ),
    .S(_0596_),
    .X(_0297_));
 sky130_fd_sc_hd__mux2_1 _1542_ (.A0(wr_data[22]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[22] ),
    .S(_0596_),
    .X(_0298_));
 sky130_fd_sc_hd__mux2_1 _1543_ (.A0(wr_data[23]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[23] ),
    .S(_0596_),
    .X(_0299_));
 sky130_fd_sc_hd__mux2_1 _1544_ (.A0(wr_data[24]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[24] ),
    .S(_0596_),
    .X(_0300_));
 sky130_fd_sc_hd__mux2_1 _1545_ (.A0(wr_data[25]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[25] ),
    .S(_0596_),
    .X(_0301_));
 sky130_fd_sc_hd__mux2_1 _1546_ (.A0(wr_data[26]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[26] ),
    .S(_0596_),
    .X(_0302_));
 sky130_fd_sc_hd__mux2_1 _1547_ (.A0(wr_data[27]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[27] ),
    .S(_0596_),
    .X(_0303_));
 sky130_fd_sc_hd__mux2_1 _1548_ (.A0(wr_data[28]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[28] ),
    .S(_0596_),
    .X(_0304_));
 sky130_fd_sc_hd__mux2_1 _1549_ (.A0(wr_data[29]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[29] ),
    .S(_0596_),
    .X(_0305_));
 sky130_fd_sc_hd__mux2_1 _1550_ (.A0(wr_data[30]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[30] ),
    .S(_0596_),
    .X(_0306_));
 sky130_fd_sc_hd__mux2_1 _1551_ (.A0(wr_data[31]),
    .A1(\u_safety_fault_watchdog_mmio.control_reg[31] ),
    .S(_0596_),
    .X(_0307_));
 sky130_fd_sc_hd__sdfrtp_2 _1552_ (.CLK(clk),
    .D(_0043_),
    .RESET_B(reset_n),
    .SCD(scan_in[0]),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1553_ (.CLK(clk),
    .D(_0044_),
    .RESET_B(reset_n),
    .SCD(scan_in[1]),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1554_ (.CLK(clk),
    .D(_0045_),
    .RESET_B(reset_n),
    .SCD(scan_in[2]),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1555_ (.CLK(clk),
    .D(_0046_),
    .RESET_B(reset_n),
    .SCD(scan_in[3]),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1556_ (.CLK(clk),
    .D(_0047_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[0] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1557_ (.CLK(clk),
    .D(_0048_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[1] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1558_ (.CLK(clk),
    .D(_0049_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[2] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1559_ (.CLK(clk),
    .D(_0050_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[3] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _1560_ (.CLK(clk),
    .D(_0051_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[4] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[8] ));
 sky130_fd_sc_hd__sdfrtp_2 _1561_ (.CLK(clk),
    .D(_0052_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[5] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[9] ));
 sky130_fd_sc_hd__sdfrtp_2 _1562_ (.CLK(clk),
    .D(_0053_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[6] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[10] ));
 sky130_fd_sc_hd__sdfrtp_2 _1563_ (.CLK(clk),
    .D(_0054_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[7] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[11] ));
 sky130_fd_sc_hd__sdfrtp_2 _1564_ (.CLK(clk),
    .D(_0055_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[8] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[12] ));
 sky130_fd_sc_hd__sdfrtp_2 _1565_ (.CLK(clk),
    .D(_0056_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[9] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[13] ));
 sky130_fd_sc_hd__sdfrtp_2 _1566_ (.CLK(clk),
    .D(_0057_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[10] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[14] ));
 sky130_fd_sc_hd__sdfrtp_2 _1567_ (.CLK(clk),
    .D(_0058_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[11] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[15] ));
 sky130_fd_sc_hd__sdfrtp_2 _1568_ (.CLK(clk),
    .D(_0059_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[12] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[16] ));
 sky130_fd_sc_hd__sdfrtp_2 _1569_ (.CLK(clk),
    .D(_0060_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[13] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[17] ));
 sky130_fd_sc_hd__sdfrtp_2 _1570_ (.CLK(clk),
    .D(_0061_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[14] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[18] ));
 sky130_fd_sc_hd__sdfrtp_2 _1571_ (.CLK(clk),
    .D(_0062_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[15] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[19] ));
 sky130_fd_sc_hd__sdfrtp_2 _1572_ (.CLK(clk),
    .D(_0063_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[16] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[20] ));
 sky130_fd_sc_hd__sdfrtp_2 _1573_ (.CLK(clk),
    .D(_0064_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[17] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[21] ));
 sky130_fd_sc_hd__sdfrtp_2 _1574_ (.CLK(clk),
    .D(_0065_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[18] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[22] ));
 sky130_fd_sc_hd__sdfrtp_2 _1575_ (.CLK(clk),
    .D(_0066_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[19] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[23] ));
 sky130_fd_sc_hd__sdfrtp_2 _1576_ (.CLK(clk),
    .D(_0067_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[20] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[24] ));
 sky130_fd_sc_hd__sdfrtp_2 _1577_ (.CLK(clk),
    .D(_0068_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[21] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[25] ));
 sky130_fd_sc_hd__sdfrtp_2 _1578_ (.CLK(clk),
    .D(_0069_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[22] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[26] ));
 sky130_fd_sc_hd__sdfrtp_2 _1579_ (.CLK(clk),
    .D(_0070_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[23] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[27] ));
 sky130_fd_sc_hd__sdfrtp_2 _1580_ (.CLK(clk),
    .D(_0071_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[24] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[28] ));
 sky130_fd_sc_hd__sdfrtp_2 _1581_ (.CLK(clk),
    .D(_0072_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[25] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[29] ));
 sky130_fd_sc_hd__sdfrtp_2 _1582_ (.CLK(clk),
    .D(_0073_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[26] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[30] ));
 sky130_fd_sc_hd__sdfrtp_2 _1583_ (.CLK(clk),
    .D(_0074_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[27] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.irq_clear_reg[31] ));
 sky130_fd_sc_hd__sdfrtp_2 _1584_ (.CLK(clk),
    .D(_0075_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[28] ),
    .SCE(scan_en),
    .Q(watchdog_expired));
 sky130_fd_sc_hd__sdfrtp_2 _1585_ (.CLK(clk),
    .D(_0076_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[29] ),
    .SCE(scan_en),
    .Q(\irq_status_value[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1586_ (.CLK(clk),
    .D(_0000_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[30] ),
    .SCE(scan_en),
    .Q(status_escalation_active));
 sky130_fd_sc_hd__sdfrtp_2 _1587_ (.CLK(clk),
    .D(reset_request),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.irq_clear_reg[31] ),
    .SCE(scan_en),
    .Q(status_reset_requested));
 sky130_fd_sc_hd__sdfrtp_2 _1588_ (.CLK(clk),
    .D(_0002_),
    .RESET_B(reset_n),
    .SCD(watchdog_expired),
    .SCE(scan_en),
    .Q(status_fault_pending));
 sky130_fd_sc_hd__sdfrtp_2 _1589_ (.CLK(clk),
    .D(watchdog_expired),
    .RESET_B(reset_n),
    .SCD(\irq_status_value[2] ),
    .SCE(scan_en),
    .Q(status_watchdog_expired));
 sky130_fd_sc_hd__sdfxtp_2 _1822_ (.CLK(clk),
    .D(_0268_),
    .Q(\u_safety_fault_watchdog_controller.masked_faults[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1591_ (.CLK(clk),
    .D(_0077_),
    .RESET_B(reset_n),
    .SCD(status_escalation_active),
    .SCE(scan_en),
    .Q(reset_request));
 sky130_fd_sc_hd__sdfrtp_2 _1592_ (.CLK(clk),
    .D(_0078_),
    .RESET_B(reset_n),
    .SCD(status_reset_requested),
    .SCE(scan_en),
    .Q(\fault_status_value[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1593_ (.CLK(clk),
    .D(_0079_),
    .RESET_B(reset_n),
    .SCD(status_fault_pending),
    .SCE(scan_en),
    .Q(\fault_status_value[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1594_ (.CLK(clk),
    .D(_0080_),
    .RESET_B(reset_n),
    .SCD(status_watchdog_expired),
    .SCE(scan_en),
    .Q(\fault_status_value[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1595_ (.CLK(clk),
    .D(_0081_),
    .RESET_B(reset_n),
    .SCD(reset_request),
    .SCE(scan_en),
    .Q(\fault_status_value[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1596_ (.CLK(clk),
    .D(_0082_),
    .RESET_B(reset_n),
    .SCD(\fault_status_value[0] ),
    .SCE(scan_en),
    .Q(\fault_status_value[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1597_ (.CLK(clk),
    .D(_0083_),
    .RESET_B(reset_n),
    .SCD(\fault_status_value[1] ),
    .SCE(scan_en),
    .Q(\fault_status_value[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1598_ (.CLK(clk),
    .D(_0084_),
    .RESET_B(reset_n),
    .SCD(\fault_status_value[2] ),
    .SCE(scan_en),
    .Q(\fault_status_value[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1599_ (.CLK(clk),
    .D(_0085_),
    .RESET_B(reset_n),
    .SCD(\fault_status_value[3] ),
    .SCE(scan_en),
    .Q(\fault_status_value[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _1600_ (.CLK(clk),
    .D(_0086_),
    .RESET_B(reset_n),
    .SCD(\fault_status_value[4] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1601_ (.CLK(clk),
    .D(_0087_),
    .RESET_B(reset_n),
    .SCD(\fault_status_value[5] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1602_ (.CLK(clk),
    .D(_0088_),
    .RESET_B(reset_n),
    .SCD(\fault_status_value[6] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1603_ (.CLK(clk),
    .D(_0089_),
    .RESET_B(reset_n),
    .SCD(\fault_status_value[7] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1604_ (.CLK(clk),
    .D(_0090_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[0] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1605_ (.CLK(clk),
    .D(_0091_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[1] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1606_ (.CLK(clk),
    .D(_0092_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[2] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1607_ (.CLK(clk),
    .D(_0093_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[3] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _1608_ (.CLK(clk),
    .D(_0094_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[4] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[8] ));
 sky130_fd_sc_hd__sdfrtp_2 _1609_ (.CLK(clk),
    .D(_0095_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[5] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[9] ));
 sky130_fd_sc_hd__sdfrtp_2 _1610_ (.CLK(clk),
    .D(_0096_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[6] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[10] ));
 sky130_fd_sc_hd__sdfrtp_2 _1611_ (.CLK(clk),
    .D(_0097_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[7] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[11] ));
 sky130_fd_sc_hd__sdfrtp_2 _1612_ (.CLK(clk),
    .D(_0098_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[8] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[12] ));
 sky130_fd_sc_hd__sdfrtp_2 _1613_ (.CLK(clk),
    .D(_0099_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[9] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[13] ));
 sky130_fd_sc_hd__sdfrtp_2 _1614_ (.CLK(clk),
    .D(_0100_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[10] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[14] ));
 sky130_fd_sc_hd__sdfrtp_2 _1615_ (.CLK(clk),
    .D(_0101_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[11] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[15] ));
 sky130_fd_sc_hd__sdfrtp_2 _1616_ (.CLK(clk),
    .D(_0102_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[12] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[16] ));
 sky130_fd_sc_hd__sdfrtp_2 _1617_ (.CLK(clk),
    .D(_0103_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[13] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[17] ));
 sky130_fd_sc_hd__sdfrtp_2 _1618_ (.CLK(clk),
    .D(_0104_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[14] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[18] ));
 sky130_fd_sc_hd__sdfrtp_2 _1619_ (.CLK(clk),
    .D(_0105_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[15] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[19] ));
 sky130_fd_sc_hd__sdfrtp_2 _1620_ (.CLK(clk),
    .D(_0106_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[16] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[20] ));
 sky130_fd_sc_hd__sdfrtp_2 _1621_ (.CLK(clk),
    .D(_0107_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[17] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[21] ));
 sky130_fd_sc_hd__sdfrtp_2 _1622_ (.CLK(clk),
    .D(_0108_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[18] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[22] ));
 sky130_fd_sc_hd__sdfrtp_2 _1623_ (.CLK(clk),
    .D(_0109_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[19] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[23] ));
 sky130_fd_sc_hd__sdfrtp_2 _1624_ (.CLK(clk),
    .D(_0110_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[20] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[24] ));
 sky130_fd_sc_hd__sdfrtp_2 _1625_ (.CLK(clk),
    .D(_0111_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[21] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[25] ));
 sky130_fd_sc_hd__sdfrtp_2 _1626_ (.CLK(clk),
    .D(_0112_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[22] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[26] ));
 sky130_fd_sc_hd__sdfrtp_2 _1627_ (.CLK(clk),
    .D(_0113_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[23] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[27] ));
 sky130_fd_sc_hd__sdfrtp_2 _1628_ (.CLK(clk),
    .D(_0114_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[24] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[28] ));
 sky130_fd_sc_hd__sdfrtp_2 _1629_ (.CLK(clk),
    .D(_0115_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[25] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[29] ));
 sky130_fd_sc_hd__sdfrtp_2 _1630_ (.CLK(clk),
    .D(_0116_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[26] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[30] ));
 sky130_fd_sc_hd__sdfrtp_2 _1631_ (.CLK(clk),
    .D(_0117_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[27] ),
    .SCE(scan_en),
    .Q(\heartbeat_count_value[31] ));
 sky130_fd_sc_hd__sdfrtp_2 _1632_ (.CLK(clk),
    .D(_0041_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[28] ),
    .SCE(scan_en),
    .Q(escalation_level[0]));
 sky130_fd_sc_hd__sdfrtp_2 _1633_ (.CLK(clk),
    .D(_0042_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[29] ),
    .SCE(scan_en),
    .Q(escalation_level[1]));
 sky130_fd_sc_hd__sdfrtp_2 _1634_ (.CLK(clk),
    .D(_0118_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[30] ),
    .SCE(scan_en),
    .Q(\reset_count_value[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1635_ (.CLK(clk),
    .D(_0119_),
    .RESET_B(reset_n),
    .SCD(\heartbeat_count_value[31] ),
    .SCE(scan_en),
    .Q(\reset_count_value[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1636_ (.CLK(clk),
    .D(_0120_),
    .RESET_B(reset_n),
    .SCD(escalation_level[0]),
    .SCE(scan_en),
    .Q(\reset_count_value[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1637_ (.CLK(clk),
    .D(_0121_),
    .RESET_B(reset_n),
    .SCD(escalation_level[1]),
    .SCE(scan_en),
    .Q(\reset_count_value[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1638_ (.CLK(clk),
    .D(_0122_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[0] ),
    .SCE(scan_en),
    .Q(\reset_count_value[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1639_ (.CLK(clk),
    .D(_0123_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[1] ),
    .SCE(scan_en),
    .Q(\reset_count_value[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1640_ (.CLK(clk),
    .D(_0124_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[2] ),
    .SCE(scan_en),
    .Q(\reset_count_value[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1641_ (.CLK(clk),
    .D(_0125_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[3] ),
    .SCE(scan_en),
    .Q(\reset_count_value[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _1642_ (.CLK(clk),
    .D(_0126_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[4] ),
    .SCE(scan_en),
    .Q(\reset_count_value[8] ));
 sky130_fd_sc_hd__sdfrtp_2 _1643_ (.CLK(clk),
    .D(_0127_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[5] ),
    .SCE(scan_en),
    .Q(\reset_count_value[9] ));
 sky130_fd_sc_hd__sdfrtp_2 _1644_ (.CLK(clk),
    .D(_0128_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[6] ),
    .SCE(scan_en),
    .Q(\reset_count_value[10] ));
 sky130_fd_sc_hd__sdfrtp_2 _1645_ (.CLK(clk),
    .D(_0129_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[7] ),
    .SCE(scan_en),
    .Q(\reset_count_value[11] ));
 sky130_fd_sc_hd__sdfrtp_2 _1646_ (.CLK(clk),
    .D(_0130_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[8] ),
    .SCE(scan_en),
    .Q(\reset_count_value[12] ));
 sky130_fd_sc_hd__sdfrtp_2 _1647_ (.CLK(clk),
    .D(_0131_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[9] ),
    .SCE(scan_en),
    .Q(\reset_count_value[13] ));
 sky130_fd_sc_hd__sdfrtp_2 _1648_ (.CLK(clk),
    .D(_0132_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[10] ),
    .SCE(scan_en),
    .Q(\reset_count_value[14] ));
 sky130_fd_sc_hd__sdfrtp_2 _1649_ (.CLK(clk),
    .D(_0133_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[11] ),
    .SCE(scan_en),
    .Q(\reset_count_value[15] ));
 sky130_fd_sc_hd__sdfrtp_2 _1650_ (.CLK(clk),
    .D(_0134_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[12] ),
    .SCE(scan_en),
    .Q(\reset_count_value[16] ));
 sky130_fd_sc_hd__sdfrtp_2 _1651_ (.CLK(clk),
    .D(_0135_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[13] ),
    .SCE(scan_en),
    .Q(\reset_count_value[17] ));
 sky130_fd_sc_hd__sdfrtp_2 _1652_ (.CLK(clk),
    .D(_0136_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[14] ),
    .SCE(scan_en),
    .Q(\reset_count_value[18] ));
 sky130_fd_sc_hd__sdfrtp_2 _1653_ (.CLK(clk),
    .D(_0137_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[15] ),
    .SCE(scan_en),
    .Q(\reset_count_value[19] ));
 sky130_fd_sc_hd__sdfrtp_2 _1654_ (.CLK(clk),
    .D(_0138_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[16] ),
    .SCE(scan_en),
    .Q(\reset_count_value[20] ));
 sky130_fd_sc_hd__sdfrtp_2 _1655_ (.CLK(clk),
    .D(_0139_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[17] ),
    .SCE(scan_en),
    .Q(\reset_count_value[21] ));
 sky130_fd_sc_hd__sdfrtp_2 _1656_ (.CLK(clk),
    .D(_0140_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[18] ),
    .SCE(scan_en),
    .Q(\reset_count_value[22] ));
 sky130_fd_sc_hd__sdfrtp_2 _1657_ (.CLK(clk),
    .D(_0141_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[19] ),
    .SCE(scan_en),
    .Q(\reset_count_value[23] ));
 sky130_fd_sc_hd__sdfrtp_2 _1658_ (.CLK(clk),
    .D(_0142_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[20] ),
    .SCE(scan_en),
    .Q(\reset_count_value[24] ));
 sky130_fd_sc_hd__sdfrtp_2 _1659_ (.CLK(clk),
    .D(_0143_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[21] ),
    .SCE(scan_en),
    .Q(\reset_count_value[25] ));
 sky130_fd_sc_hd__sdfrtp_2 _1660_ (.CLK(clk),
    .D(_0144_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[22] ),
    .SCE(scan_en),
    .Q(\reset_count_value[26] ));
 sky130_fd_sc_hd__sdfrtp_2 _1661_ (.CLK(clk),
    .D(_0145_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[23] ),
    .SCE(scan_en),
    .Q(\reset_count_value[27] ));
 sky130_fd_sc_hd__sdfrtp_2 _1662_ (.CLK(clk),
    .D(_0146_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[24] ),
    .SCE(scan_en),
    .Q(\reset_count_value[28] ));
 sky130_fd_sc_hd__sdfrtp_2 _1663_ (.CLK(clk),
    .D(_0147_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[25] ),
    .SCE(scan_en),
    .Q(\reset_count_value[29] ));
 sky130_fd_sc_hd__sdfrtp_2 _1664_ (.CLK(clk),
    .D(_0148_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[26] ),
    .SCE(scan_en),
    .Q(\reset_count_value[30] ));
 sky130_fd_sc_hd__sdfrtp_2 _1665_ (.CLK(clk),
    .D(_0149_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[27] ),
    .SCE(scan_en),
    .Q(\reset_count_value[31] ));
 sky130_fd_sc_hd__sdfrtp_2 _1666_ (.CLK(clk),
    .D(_0150_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[28] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1667_ (.CLK(clk),
    .D(_0151_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[29] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1668_ (.CLK(clk),
    .D(_0152_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[30] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1669_ (.CLK(clk),
    .D(_0153_),
    .RESET_B(reset_n),
    .SCD(\reset_count_value[31] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1670_ (.CLK(clk),
    .D(_0154_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[0] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1671_ (.CLK(clk),
    .D(_0155_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[1] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1672_ (.CLK(clk),
    .D(_0156_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[2] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1673_ (.CLK(clk),
    .D(_0157_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[3] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _1674_ (.CLK(clk),
    .D(_0158_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[4] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[8] ));
 sky130_fd_sc_hd__sdfrtp_2 _1675_ (.CLK(clk),
    .D(_0159_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[5] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[9] ));
 sky130_fd_sc_hd__sdfrtp_2 _1676_ (.CLK(clk),
    .D(_0160_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[6] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[10] ));
 sky130_fd_sc_hd__sdfrtp_2 _1677_ (.CLK(clk),
    .D(_0161_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[7] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[11] ));
 sky130_fd_sc_hd__sdfrtp_2 _1678_ (.CLK(clk),
    .D(_0162_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[8] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[12] ));
 sky130_fd_sc_hd__sdfrtp_2 _1679_ (.CLK(clk),
    .D(_0163_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[9] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[13] ));
 sky130_fd_sc_hd__sdfrtp_2 _1680_ (.CLK(clk),
    .D(_0164_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[10] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[14] ));
 sky130_fd_sc_hd__sdfrtp_2 _1681_ (.CLK(clk),
    .D(_0165_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[11] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[15] ));
 sky130_fd_sc_hd__sdfrtp_2 _1682_ (.CLK(clk),
    .D(_0166_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[12] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[16] ));
 sky130_fd_sc_hd__sdfrtp_2 _1683_ (.CLK(clk),
    .D(_0167_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[13] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[17] ));
 sky130_fd_sc_hd__sdfrtp_2 _1684_ (.CLK(clk),
    .D(_0168_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[14] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[18] ));
 sky130_fd_sc_hd__sdfrtp_2 _1685_ (.CLK(clk),
    .D(_0169_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[15] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[19] ));
 sky130_fd_sc_hd__sdfrtp_2 _1686_ (.CLK(clk),
    .D(_0170_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[16] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[20] ));
 sky130_fd_sc_hd__sdfrtp_2 _1687_ (.CLK(clk),
    .D(_0171_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[17] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[21] ));
 sky130_fd_sc_hd__sdfrtp_2 _1688_ (.CLK(clk),
    .D(_0172_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[18] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[22] ));
 sky130_fd_sc_hd__sdfrtp_2 _1689_ (.CLK(clk),
    .D(_0173_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[19] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[23] ));
 sky130_fd_sc_hd__sdfrtp_2 _1690_ (.CLK(clk),
    .D(_0174_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[20] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[24] ));
 sky130_fd_sc_hd__sdfrtp_2 _1691_ (.CLK(clk),
    .D(_0175_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[21] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[25] ));
 sky130_fd_sc_hd__sdfrtp_2 _1692_ (.CLK(clk),
    .D(_0176_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[22] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[26] ));
 sky130_fd_sc_hd__sdfrtp_2 _1693_ (.CLK(clk),
    .D(_0177_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[23] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[27] ));
 sky130_fd_sc_hd__sdfrtp_2 _1694_ (.CLK(clk),
    .D(_0178_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[24] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[28] ));
 sky130_fd_sc_hd__sdfrtp_2 _1695_ (.CLK(clk),
    .D(_0179_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[25] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[29] ));
 sky130_fd_sc_hd__sdfrtp_2 _1696_ (.CLK(clk),
    .D(_0180_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[26] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[30] ));
 sky130_fd_sc_hd__sdfrtp_2 _1697_ (.CLK(clk),
    .D(_0181_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[27] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.event_score[31] ));
 sky130_fd_sc_hd__sdfrtp_2 _1698_ (.CLK(clk),
    .D(_0182_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[28] ),
    .SCE(scan_en),
    .Q(fault_latched[0]));
 sky130_fd_sc_hd__sdfrtp_2 _1699_ (.CLK(clk),
    .D(_0183_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[29] ),
    .SCE(scan_en),
    .Q(fault_latched[1]));
 sky130_fd_sc_hd__sdfrtp_2 _1700_ (.CLK(clk),
    .D(_0184_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[30] ),
    .SCE(scan_en),
    .Q(fault_latched[2]));
 sky130_fd_sc_hd__sdfrtp_2 _1701_ (.CLK(clk),
    .D(_0185_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.event_score[31] ),
    .SCE(scan_en),
    .Q(fault_latched[3]));
 sky130_fd_sc_hd__sdfrtp_2 _1702_ (.CLK(clk),
    .D(_0186_),
    .RESET_B(reset_n),
    .SCD(fault_latched[0]),
    .SCE(scan_en),
    .Q(fault_latched[4]));
 sky130_fd_sc_hd__sdfrtp_2 _1703_ (.CLK(clk),
    .D(_0187_),
    .RESET_B(reset_n),
    .SCD(fault_latched[1]),
    .SCE(scan_en),
    .Q(fault_latched[5]));
 sky130_fd_sc_hd__sdfrtp_2 _1704_ (.CLK(clk),
    .D(_0188_),
    .RESET_B(reset_n),
    .SCD(fault_latched[2]),
    .SCE(scan_en),
    .Q(fault_latched[6]));
 sky130_fd_sc_hd__sdfrtp_2 _1705_ (.CLK(clk),
    .D(_0189_),
    .RESET_B(reset_n),
    .SCD(fault_latched[3]),
    .SCE(scan_en),
    .Q(fault_latched[7]));
 sky130_fd_sc_hd__sdfrtp_2 _1706_ (.CLK(clk),
    .D(_0004_),
    .RESET_B(reset_n),
    .SCD(fault_latched[4]),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1707_ (.CLK(clk),
    .D(_0015_),
    .RESET_B(reset_n),
    .SCD(fault_latched[5]),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1708_ (.CLK(clk),
    .D(_0026_),
    .RESET_B(reset_n),
    .SCD(fault_latched[6]),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1709_ (.CLK(clk),
    .D(_0029_),
    .RESET_B(reset_n),
    .SCD(fault_latched[7]),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1710_ (.CLK(clk),
    .D(_0030_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[0] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1711_ (.CLK(clk),
    .D(_0031_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[1] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1712_ (.CLK(clk),
    .D(_0032_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[2] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1713_ (.CLK(clk),
    .D(_0033_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[3] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _1714_ (.CLK(clk),
    .D(_0034_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[4] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[8] ));
 sky130_fd_sc_hd__sdfrtp_2 _1715_ (.CLK(clk),
    .D(_0035_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[5] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[9] ));
 sky130_fd_sc_hd__sdfrtp_2 _1716_ (.CLK(clk),
    .D(_0005_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[6] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[10] ));
 sky130_fd_sc_hd__sdfrtp_2 _1717_ (.CLK(clk),
    .D(_0006_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[7] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[11] ));
 sky130_fd_sc_hd__sdfrtp_2 _1718_ (.CLK(clk),
    .D(_0007_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[8] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[12] ));
 sky130_fd_sc_hd__sdfrtp_2 _1719_ (.CLK(clk),
    .D(_0008_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[9] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[13] ));
 sky130_fd_sc_hd__sdfrtp_2 _1720_ (.CLK(clk),
    .D(_0009_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[10] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[14] ));
 sky130_fd_sc_hd__sdfrtp_2 _1721_ (.CLK(clk),
    .D(_0010_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[11] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[15] ));
 sky130_fd_sc_hd__sdfrtp_2 _1722_ (.CLK(clk),
    .D(_0011_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[12] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[16] ));
 sky130_fd_sc_hd__sdfrtp_2 _1723_ (.CLK(clk),
    .D(_0012_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[13] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[17] ));
 sky130_fd_sc_hd__sdfrtp_2 _1724_ (.CLK(clk),
    .D(_0013_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[14] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[18] ));
 sky130_fd_sc_hd__sdfrtp_2 _1725_ (.CLK(clk),
    .D(_0014_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[15] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[19] ));
 sky130_fd_sc_hd__sdfrtp_2 _1726_ (.CLK(clk),
    .D(_0016_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[16] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[20] ));
 sky130_fd_sc_hd__sdfrtp_2 _1727_ (.CLK(clk),
    .D(_0017_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[17] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[21] ));
 sky130_fd_sc_hd__sdfrtp_2 _1728_ (.CLK(clk),
    .D(_0018_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[18] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[22] ));
 sky130_fd_sc_hd__sdfrtp_2 _1729_ (.CLK(clk),
    .D(_0019_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[19] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[23] ));
 sky130_fd_sc_hd__sdfrtp_2 _1730_ (.CLK(clk),
    .D(_0020_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[20] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[24] ));
 sky130_fd_sc_hd__sdfrtp_2 _1731_ (.CLK(clk),
    .D(_0021_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[21] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[25] ));
 sky130_fd_sc_hd__sdfrtp_2 _1732_ (.CLK(clk),
    .D(_0022_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[22] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[26] ));
 sky130_fd_sc_hd__sdfrtp_2 _1733_ (.CLK(clk),
    .D(_0023_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[23] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[27] ));
 sky130_fd_sc_hd__sdfrtp_2 _1734_ (.CLK(clk),
    .D(_0024_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[24] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[28] ));
 sky130_fd_sc_hd__sdfrtp_2 _1735_ (.CLK(clk),
    .D(_0025_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[25] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[29] ));
 sky130_fd_sc_hd__sdfrtp_2 _1736_ (.CLK(clk),
    .D(_0027_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[26] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[30] ));
 sky130_fd_sc_hd__sdfrtp_2 _1737_ (.CLK(clk),
    .D(_0028_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[27] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_counter[31] ));
 sky130_fd_sc_hd__sdfrtp_2 _1738_ (.CLK(clk),
    .D(_0001_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[28] ),
    .SCE(scan_en),
    .Q(safety_irq));
 sky130_fd_sc_hd__sdfrtp_2 _1739_ (.CLK(clk),
    .D(_0190_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[29] ),
    .SCE(scan_en),
    .Q(\irq_status_value[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1740_ (.CLK(clk),
    .D(_0191_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[30] ),
    .SCE(scan_en),
    .Q(\irq_status_value[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1741_ (.CLK(clk),
    .D(_0192_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_counter[31] ),
    .SCE(scan_en),
    .Q(\irq_status_value[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1742_ (.CLK(clk),
    .D(_0193_),
    .RESET_B(reset_n),
    .SCD(safety_irq),
    .SCE(scan_en),
    .Q(\fault_mask_cfg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1743_ (.CLK(clk),
    .D(_0194_),
    .RESET_B(reset_n),
    .SCD(\irq_status_value[3] ),
    .SCE(scan_en),
    .Q(\fault_mask_cfg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1744_ (.CLK(clk),
    .D(_0195_),
    .RESET_B(reset_n),
    .SCD(\irq_status_value[1] ),
    .SCE(scan_en),
    .Q(\fault_mask_cfg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1745_ (.CLK(clk),
    .D(_0196_),
    .RESET_B(reset_n),
    .SCD(\irq_status_value[0] ),
    .SCE(scan_en),
    .Q(\fault_mask_cfg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1746_ (.CLK(clk),
    .D(_0197_),
    .RESET_B(reset_n),
    .SCD(\fault_mask_cfg[0] ),
    .SCE(scan_en),
    .Q(\fault_mask_cfg[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1747_ (.CLK(clk),
    .D(_0198_),
    .RESET_B(reset_n),
    .SCD(\fault_mask_cfg[1] ),
    .SCE(scan_en),
    .Q(\fault_mask_cfg[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1748_ (.CLK(clk),
    .D(_0199_),
    .RESET_B(reset_n),
    .SCD(\fault_mask_cfg[2] ),
    .SCE(scan_en),
    .Q(\fault_mask_cfg[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1749_ (.CLK(clk),
    .D(_0200_),
    .RESET_B(reset_n),
    .SCD(\fault_mask_cfg[3] ),
    .SCE(scan_en),
    .Q(\fault_mask_cfg[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _1750_ (.CLK(clk),
    .D(_0201_),
    .RESET_B(reset_n),
    .SCD(\fault_mask_cfg[4] ),
    .SCE(scan_en),
    .Q(irq_enable));
 sky130_fd_sc_hd__sdfrtp_2 _1751_ (.CLK(clk),
    .D(_0037_),
    .RESET_B(reset_n),
    .SCD(\fault_mask_cfg[5] ),
    .SCE(scan_en),
    .Q(\irq_clear_pulse[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1752_ (.CLK(clk),
    .D(_0038_),
    .RESET_B(reset_n),
    .SCD(\fault_mask_cfg[6] ),
    .SCE(scan_en),
    .Q(\irq_clear_pulse[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1753_ (.CLK(clk),
    .D(_0039_),
    .RESET_B(reset_n),
    .SCD(\fault_mask_cfg[7] ),
    .SCE(scan_en),
    .Q(\irq_clear_pulse[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1754_ (.CLK(clk),
    .D(_0040_),
    .RESET_B(reset_n),
    .SCD(irq_enable),
    .SCE(scan_en),
    .Q(\irq_clear_pulse[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1755_ (.CLK(clk),
    .D(_0036_),
    .RESET_B(reset_n),
    .SCD(\irq_clear_pulse[0] ),
    .SCE(scan_en),
    .Q(fault_clear_pulse));
 sky130_fd_sc_hd__sdfrtp_2 _1756_ (.CLK(clk),
    .D(_0202_),
    .RESET_B(reset_n),
    .SCD(\irq_clear_pulse[1] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1757_ (.CLK(clk),
    .D(_0203_),
    .RESET_B(reset_n),
    .SCD(\irq_clear_pulse[2] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1758_ (.CLK(clk),
    .D(_0204_),
    .RESET_B(reset_n),
    .SCD(\irq_clear_pulse[3] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1759_ (.CLK(clk),
    .D(_0205_),
    .RESET_B(reset_n),
    .SCD(fault_clear_pulse),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1760_ (.CLK(clk),
    .D(_0206_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[0] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1761_ (.CLK(clk),
    .D(_0207_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[1] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1762_ (.CLK(clk),
    .D(_0208_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[2] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1763_ (.CLK(clk),
    .D(_0209_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[3] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _1764_ (.CLK(clk),
    .D(_0210_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[4] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[8] ));
 sky130_fd_sc_hd__sdfrtp_2 _1765_ (.CLK(clk),
    .D(_0211_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[5] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[9] ));
 sky130_fd_sc_hd__sdfrtp_2 _1766_ (.CLK(clk),
    .D(_0212_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[6] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[10] ));
 sky130_fd_sc_hd__sdfrtp_2 _1767_ (.CLK(clk),
    .D(_0213_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[7] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[11] ));
 sky130_fd_sc_hd__sdfrtp_2 _1768_ (.CLK(clk),
    .D(_0214_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[8] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[12] ));
 sky130_fd_sc_hd__sdfrtp_2 _1769_ (.CLK(clk),
    .D(_0215_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[9] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[13] ));
 sky130_fd_sc_hd__sdfrtp_2 _1770_ (.CLK(clk),
    .D(_0216_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[10] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[14] ));
 sky130_fd_sc_hd__sdfrtp_2 _1771_ (.CLK(clk),
    .D(_0217_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[11] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[15] ));
 sky130_fd_sc_hd__sdfrtp_2 _1772_ (.CLK(clk),
    .D(_0218_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[12] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[16] ));
 sky130_fd_sc_hd__sdfrtp_2 _1773_ (.CLK(clk),
    .D(_0219_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[13] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[17] ));
 sky130_fd_sc_hd__sdfrtp_2 _1774_ (.CLK(clk),
    .D(_0220_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[14] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[18] ));
 sky130_fd_sc_hd__sdfrtp_2 _1775_ (.CLK(clk),
    .D(_0221_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[15] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[19] ));
 sky130_fd_sc_hd__sdfrtp_2 _1776_ (.CLK(clk),
    .D(_0222_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[16] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[20] ));
 sky130_fd_sc_hd__sdfrtp_2 _1777_ (.CLK(clk),
    .D(_0223_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[17] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[21] ));
 sky130_fd_sc_hd__sdfrtp_2 _1778_ (.CLK(clk),
    .D(_0224_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[18] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[22] ));
 sky130_fd_sc_hd__sdfrtp_2 _1779_ (.CLK(clk),
    .D(_0225_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[19] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[23] ));
 sky130_fd_sc_hd__sdfrtp_2 _1780_ (.CLK(clk),
    .D(_0226_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[20] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[24] ));
 sky130_fd_sc_hd__sdfrtp_2 _1781_ (.CLK(clk),
    .D(_0227_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[21] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[25] ));
 sky130_fd_sc_hd__sdfrtp_2 _1782_ (.CLK(clk),
    .D(_0228_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[22] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[26] ));
 sky130_fd_sc_hd__sdfrtp_2 _1783_ (.CLK(clk),
    .D(_0229_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[23] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[27] ));
 sky130_fd_sc_hd__sdfrtp_2 _1784_ (.CLK(clk),
    .D(_0230_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[24] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[28] ));
 sky130_fd_sc_hd__sdfrtp_2 _1785_ (.CLK(clk),
    .D(_0231_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[25] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[29] ));
 sky130_fd_sc_hd__sdfrtp_2 _1786_ (.CLK(clk),
    .D(_0232_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[26] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[30] ));
 sky130_fd_sc_hd__sdfrtp_2 _1787_ (.CLK(clk),
    .D(_0233_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[27] ),
    .SCE(scan_en),
    .Q(\escalation_policy_cfg[31] ));
 sky130_fd_sc_hd__sdfrtp_2 _1788_ (.CLK(clk),
    .D(_0234_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[28] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_enable ));
 sky130_fd_sc_hd__sdfrtp_2 _1789_ (.CLK(clk),
    .D(_0235_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[29] ),
    .SCE(scan_en),
    .Q(control_enable));
 sky130_fd_sc_hd__sdfrtp_2 _1790_ (.CLK(clk),
    .D(_0236_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[30] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1791_ (.CLK(clk),
    .D(_0237_),
    .RESET_B(reset_n),
    .SCD(\escalation_policy_cfg[31] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1792_ (.CLK(clk),
    .D(_0238_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_enable ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1793_ (.CLK(clk),
    .D(_0239_),
    .RESET_B(reset_n),
    .SCD(control_enable),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1794_ (.CLK(clk),
    .D(_0240_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[0] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1795_ (.CLK(clk),
    .D(_0241_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[1] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1796_ (.CLK(clk),
    .D(_0242_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[2] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1797_ (.CLK(clk),
    .D(_0243_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[3] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _1798_ (.CLK(clk),
    .D(_0244_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[4] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[8] ));
 sky130_fd_sc_hd__sdfrtp_2 _1799_ (.CLK(clk),
    .D(_0245_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[5] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[9] ));
 sky130_fd_sc_hd__sdfrtp_2 _1800_ (.CLK(clk),
    .D(_0246_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[6] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[10] ));
 sky130_fd_sc_hd__sdfrtp_2 _1801_ (.CLK(clk),
    .D(_0247_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[7] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[11] ));
 sky130_fd_sc_hd__sdfrtp_2 _1802_ (.CLK(clk),
    .D(_0248_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[8] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[12] ));
 sky130_fd_sc_hd__sdfrtp_2 _1803_ (.CLK(clk),
    .D(_0249_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[9] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[13] ));
 sky130_fd_sc_hd__sdfrtp_2 _1804_ (.CLK(clk),
    .D(_0250_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[10] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[14] ));
 sky130_fd_sc_hd__sdfrtp_2 _1805_ (.CLK(clk),
    .D(_0251_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[11] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[15] ));
 sky130_fd_sc_hd__sdfrtp_2 _1806_ (.CLK(clk),
    .D(_0252_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[12] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[16] ));
 sky130_fd_sc_hd__sdfrtp_2 _1807_ (.CLK(clk),
    .D(_0253_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[13] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[17] ));
 sky130_fd_sc_hd__sdfrtp_2 _1808_ (.CLK(clk),
    .D(_0254_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[14] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[18] ));
 sky130_fd_sc_hd__sdfrtp_2 _1809_ (.CLK(clk),
    .D(_0255_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[15] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[19] ));
 sky130_fd_sc_hd__sdfrtp_2 _1810_ (.CLK(clk),
    .D(_0256_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[16] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[20] ));
 sky130_fd_sc_hd__sdfrtp_2 _1811_ (.CLK(clk),
    .D(_0257_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[17] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[21] ));
 sky130_fd_sc_hd__sdfrtp_2 _1812_ (.CLK(clk),
    .D(_0258_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[18] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[22] ));
 sky130_fd_sc_hd__sdfrtp_2 _1813_ (.CLK(clk),
    .D(_0259_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[19] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[23] ));
 sky130_fd_sc_hd__sdfrtp_2 _1814_ (.CLK(clk),
    .D(_0260_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[20] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[24] ));
 sky130_fd_sc_hd__sdfrtp_2 _1815_ (.CLK(clk),
    .D(_0261_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[21] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[25] ));
 sky130_fd_sc_hd__sdfrtp_2 _1816_ (.CLK(clk),
    .D(_0262_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[22] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[26] ));
 sky130_fd_sc_hd__sdfrtp_2 _1817_ (.CLK(clk),
    .D(_0263_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[23] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[27] ));
 sky130_fd_sc_hd__sdfrtp_2 _1818_ (.CLK(clk),
    .D(_0264_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[24] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[28] ));
 sky130_fd_sc_hd__sdfrtp_2 _1819_ (.CLK(clk),
    .D(_0265_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[25] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[29] ));
 sky130_fd_sc_hd__sdfrtp_2 _1820_ (.CLK(clk),
    .D(_0266_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[26] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[30] ));
 sky130_fd_sc_hd__sdfrtp_2 _1821_ (.CLK(clk),
    .D(_0267_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[27] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[31] ));
 sky130_fd_sc_hd__sdfxtp_2 _1823_ (.CLK(clk),
    .D(_0269_),
    .Q(\u_safety_fault_watchdog_controller.masked_faults[1] ));
 sky130_fd_sc_hd__sdfxtp_2 _1824_ (.CLK(clk),
    .D(_0270_),
    .Q(\u_safety_fault_watchdog_controller.masked_faults[2] ));
 sky130_fd_sc_hd__sdfxtp_2 _1825_ (.CLK(clk),
    .D(_0271_),
    .Q(\u_safety_fault_watchdog_controller.masked_faults[3] ));
 sky130_fd_sc_hd__sdfxtp_2 _1826_ (.CLK(clk),
    .D(_0272_),
    .Q(\u_safety_fault_watchdog_controller.masked_faults[4] ));
 sky130_fd_sc_hd__sdfxtp_2 _1827_ (.CLK(clk),
    .D(_0273_),
    .Q(\u_safety_fault_watchdog_controller.masked_faults[5] ));
 sky130_fd_sc_hd__sdfxtp_2 _1828_ (.CLK(clk),
    .D(_0274_),
    .Q(\u_safety_fault_watchdog_controller.masked_faults[6] ));
 sky130_fd_sc_hd__sdfxtp_2 _1829_ (.CLK(clk),
    .D(_0275_),
    .Q(\u_safety_fault_watchdog_controller.masked_faults[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _1830_ (.CLK(clk),
    .D(_0276_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[28] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1831_ (.CLK(clk),
    .D(_0277_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[29] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1832_ (.CLK(clk),
    .D(_0278_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[30] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1833_ (.CLK(clk),
    .D(_0279_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_controller.watchdog_timeout_cfg[31] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1834_ (.CLK(clk),
    .D(_0280_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.control_reg[0] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1835_ (.CLK(clk),
    .D(_0281_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.control_reg[1] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1836_ (.CLK(clk),
    .D(_0282_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.control_reg[2] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1837_ (.CLK(clk),
    .D(_0283_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.control_reg[3] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _1838_ (.CLK(clk),
    .D(_0284_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.control_reg[4] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[8] ));
 sky130_fd_sc_hd__sdfrtp_2 _1839_ (.CLK(clk),
    .D(_0285_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.control_reg[5] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[9] ));
 sky130_fd_sc_hd__sdfrtp_2 _1840_ (.CLK(clk),
    .D(_0286_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.control_reg[6] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[10] ));
 sky130_fd_sc_hd__sdfrtp_2 _1841_ (.CLK(clk),
    .D(_0287_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.control_reg[7] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[11] ));
 sky130_fd_sc_hd__sdfrtp_2 _1842_ (.CLK(clk),
    .D(_0288_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.control_reg[8] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[12] ));
 sky130_fd_sc_hd__sdfrtp_2 _1843_ (.CLK(clk),
    .D(_0289_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.control_reg[9] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[13] ));
 sky130_fd_sc_hd__sdfrtp_2 _1844_ (.CLK(clk),
    .D(_0290_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.control_reg[10] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[14] ));
 sky130_fd_sc_hd__sdfrtp_2 _1845_ (.CLK(clk),
    .D(_0291_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.control_reg[11] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[15] ));
 sky130_fd_sc_hd__sdfrtp_2 _1846_ (.CLK(clk),
    .D(_0292_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.control_reg[12] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[16] ));
 sky130_fd_sc_hd__sdfrtp_2 _1847_ (.CLK(clk),
    .D(_0293_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.control_reg[13] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[17] ));
 sky130_fd_sc_hd__sdfrtp_2 _1848_ (.CLK(clk),
    .D(_0294_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.control_reg[14] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[18] ));
 sky130_fd_sc_hd__sdfrtp_2 _1849_ (.CLK(clk),
    .D(_0295_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.control_reg[15] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[19] ));
 sky130_fd_sc_hd__sdfrtp_2 _1850_ (.CLK(clk),
    .D(_0296_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.control_reg[16] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[20] ));
 sky130_fd_sc_hd__sdfrtp_2 _1851_ (.CLK(clk),
    .D(_0297_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.control_reg[17] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[21] ));
 sky130_fd_sc_hd__sdfrtp_2 _1852_ (.CLK(clk),
    .D(_0298_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.control_reg[18] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[22] ));
 sky130_fd_sc_hd__sdfrtp_2 _1853_ (.CLK(clk),
    .D(_0299_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.control_reg[19] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[23] ));
 sky130_fd_sc_hd__sdfrtp_2 _1854_ (.CLK(clk),
    .D(_0300_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.control_reg[20] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[24] ));
 sky130_fd_sc_hd__sdfrtp_2 _1855_ (.CLK(clk),
    .D(_0301_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.control_reg[21] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[25] ));
 sky130_fd_sc_hd__sdfrtp_2 _1856_ (.CLK(clk),
    .D(_0302_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.control_reg[22] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[26] ));
 sky130_fd_sc_hd__sdfrtp_2 _1857_ (.CLK(clk),
    .D(_0303_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.control_reg[23] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[27] ));
 sky130_fd_sc_hd__sdfrtp_2 _1858_ (.CLK(clk),
    .D(_0304_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.control_reg[24] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[28] ));
 sky130_fd_sc_hd__sdfrtp_2 _1859_ (.CLK(clk),
    .D(_0305_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.control_reg[25] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[29] ));
 sky130_fd_sc_hd__sdfrtp_2 _1860_ (.CLK(clk),
    .D(_0306_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.control_reg[26] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[30] ));
 sky130_fd_sc_hd__sdfrtp_2 _1861_ (.CLK(clk),
    .D(_0307_),
    .RESET_B(reset_n),
    .SCD(\u_safety_fault_watchdog_mmio.control_reg[27] ),
    .SCE(scan_en),
    .Q(\u_safety_fault_watchdog_mmio.control_reg[31] ));
 sky130_fd_sc_hd__sdfsbp_2 _1590_ (.CLK(clk),
    .D(_0003_),
    .SET_B(reset_n),
    .Q(status_healthy));
 assign scan_out[1] = \u_safety_fault_watchdog_mmio.control_reg[28] ;
 assign scan_out[2] = \u_safety_fault_watchdog_mmio.control_reg[29] ;
 assign scan_out[3] = \u_safety_fault_watchdog_mmio.control_reg[30] ;
 assign scan_out[0] = \u_safety_fault_watchdog_mmio.control_reg[31] ;
endmodule
