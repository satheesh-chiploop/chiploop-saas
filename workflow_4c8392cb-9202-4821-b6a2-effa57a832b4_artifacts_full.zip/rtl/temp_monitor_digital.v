module temp_monitor_digital (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    adc_code,
    adc_valid,
    rd_data,
    sample_req,
    alert_irq,
    temp_code,
    threshold_code,
    alert_status
);

input clk;
input reset_n;
input wr_en;
input [7:0] wr_addr;
input [15:0] wr_data;
input rd_en;
input [7:0] rd_addr;
input [11:0] adc_code;
input adc_valid;

output [15:0] rd_data;
output sample_req;
output alert_irq;
output [11:0] temp_code;
output [11:0] threshold_code;
output alert_status;

reg [15:0] rd_data_r;
reg sample_req_r;
reg alert_irq_r;
reg [11:0] temp_code_r;
reg [11:0] threshold_code_r;
reg alert_status_r;

reg [15:0] control_reg;
reg [11:0] latest_temp_reg;
reg [15:0] sample_count_reg;
reg irq_status_alert_reg;
reg irq_status_sample_done_reg;
reg status_sample_done_reg;
reg status_alert_pending_reg;
reg status_adc_valid_seen_reg;
reg status_busy_reg;

reg [11:0] adc_code_prev_reg;
reg pending_sample_reg;
reg [11:0] sample_avg_reg;
reg sample_avg_valid_reg;

wire [12:0] avg_sum_w;
wire [11:0] avg_next_w;
wire [15:0] control_read_w;
wire [15:0] status_read_w;
wire [15:0] threshold_read_w;
wire [15:0] latest_temp_read_w;
wire [15:0] sample_count_read_w;
wire [15:0] irq_status_read_w;
wire irq_clear_alert_w;
wire irq_clear_sample_done_w;
wire control_enable_w;
wire control_irq_enable_w;
wire control_sample_start_w;
wire control_alert_clear_w;
wire sample_req_pulse_w;
wire periodic_sample_req_w;
wire adc_event_w;
wire alert_condition_w;
wire irq_any_w;

assign rd_data = rd_data_r;
assign sample_req = sample_req_r;
assign alert_irq = alert_irq_r;
assign temp_code = temp_code_r;
assign threshold_code = threshold_code_r;
assign alert_status = alert_status_r;

assign control_enable_w = control_reg[0];
assign control_sample_start_w = control_reg[1];
assign control_irq_enable_w = control_reg[2];
assign control_alert_clear_w = control_reg[3];

assign irq_clear_alert_w = (wr_en && (wr_addr == 8'h18) && wr_data[0]);
assign irq_clear_sample_done_w = (wr_en && (wr_addr == 8'h18) && wr_data[1]);

assign sample_req_pulse_w = (wr_en && (wr_addr == 8'h00) && wr_data[1]);
assign periodic_sample_req_w = control_enable_w & (~status_busy_reg);
assign adc_event_w = adc_valid;
assign alert_condition_w = (temp_code_r > threshold_code_r);
assign irq_any_w = (irq_status_alert_reg | irq_status_sample_done_reg);

assign control_read_w = {12'b000000000000, control_reg[3:0]};
assign status_read_w = {12'b000000000000, status_busy_reg, status_adc_valid_seen_reg, status_alert_pending_reg, status_sample_done_reg};
assign threshold_read_w = {4'b0000, threshold_code_r};
assign latest_temp_read_w = {4'b0000, latest_temp_reg};
assign sample_count_read_w = sample_count_reg;
assign irq_status_read_w = {14'b00000000000000, irq_status_sample_done_reg, irq_status_alert_reg};

always @(*) begin
    rd_data_r = 16'h0000;
    if (rd_en) begin
        case (rd_addr)
            8'h00: rd_data_r = control_read_w;
            8'h04: rd_data_r = status_read_w;
            8'h08: rd_data_r = threshold_read_w;
            8'h0C: rd_data_r = latest_temp_read_w;
            8'h10: rd_data_r = sample_count_read_w;
            8'h14: rd_data_r = irq_status_read_w;
            8'h18: rd_data_r = 16'h0000;
            default: rd_data_r = 16'h0000;
        endcase
    end
end

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        control_reg <= 16'h0000;
        threshold_code_r <= 12'h000;
        latest_temp_reg <= 12'h000;
        sample_count_reg <= 16'h0000;
        irq_status_alert_reg <= 1'b0;
        irq_status_sample_done_reg <= 1'b0;
        status_sample_done_reg <= 1'b0;
        status_alert_pending_reg <= 1'b0;
        status_adc_valid_seen_reg <= 1'b0;
        status_busy_reg <= 1'b0;
        adc_code_prev_reg <= 12'h000;
        pending_sample_reg <= 1'b0;
        sample_avg_reg <= 12'h000;
        sample_avg_valid_reg <= 1'b0;
        alert_status_r <= 1'b0;
        temp_code_r <= 12'h000;
        sample_req_r <= 1'b0;
        alert_irq_r <= 1'b0;
    end else begin
        sample_req_r <= 1'b0;

        if (wr_en && (wr_addr == 8'h00)) begin
            control_reg[0] <= wr_data[0];
            control_reg[2] <= wr_data[2];
            if (wr_data[3]) begin
                alert_status_r <= 1'b0;
                status_alert_pending_reg <= 1'b0;
                irq_status_alert_reg <= 1'b0;
            end
        end
        if (wr_en && (wr_addr == 8'h08)) begin
            threshold_code_r <= wr_data[11:0];
        end
        if (wr_en && (wr_addr == 8'h18)) begin
            if (wr_data[0]) begin
                alert_status_r <= 1'b0;
                status_alert_pending_reg <= 1'b0;
                irq_status_alert_reg <= 1'b0;
            end
            if (wr_data[1]) begin
                status_sample_done_reg <= 1'b0;
                irq_status_sample_done_reg <= 1'b0;
            end
        end

        if (sample_req_pulse_w) begin
            sample_req_r <= 1'b1;
            pending_sample_reg <= 1'b1;
            status_busy_reg <= 1'b1;
        end else if (periodic_sample_req_w && !pending_sample_reg) begin
            sample_req_r <= 1'b1;
            pending_sample_reg <= 1'b1;
            status_busy_reg <= 1'b1;
        end

        if (adc_event_w) begin
            adc_code_prev_reg <= adc_code;
            sample_avg_reg <= (adc_code_prev_reg + adc_code) >> 1;
            sample_avg_valid_reg <= 1'b1;
            latest_temp_reg <= sample_avg_valid_reg ? ((adc_code_prev_reg + adc_code) >> 1) : adc_code;
            temp_code_r <= sample_avg_valid_reg ? ((adc_code_prev_reg + adc_code) >> 1) : adc_code;
            sample_count_reg <= sample_count_reg + 16'h0001;
            status_sample_done_reg <= 1'b1;
            irq_status_sample_done_reg <= 1'b1;
            status_adc_valid_seen_reg <= 1'b1;
            pending_sample_reg <= 1'b0;
            status_busy_reg <= 1'b0;
            if ((sample_avg_valid_reg ? ((adc_code_prev_reg + adc_code) >> 1) : adc_code) > threshold_code_r) begin
                alert_status_r <= 1'b1;
                status_alert_pending_reg <= 1'b1;
                irq_status_alert_reg <= 1'b1;
            end
        end

        if (control_alert_clear_w || irq_clear_alert_w) begin
            alert_status_r <= 1'b0;
            status_alert_pending_reg <= 1'b0;
            irq_status_alert_reg <= 1'b0;
        end
        if (irq_clear_sample_done_w) begin
            status_sample_done_reg <= 1'b0;
            irq_status_sample_done_reg <= 1'b0;
        end

        alert_irq_r <= control_irq_enable_w & irq_any_w;
    end
end

assign avg_sum_w = {1'b0, adc_code_prev_reg} + {1'b0, adc_code};
assign avg_next_w = avg_sum_w[12:1];

endmodule
