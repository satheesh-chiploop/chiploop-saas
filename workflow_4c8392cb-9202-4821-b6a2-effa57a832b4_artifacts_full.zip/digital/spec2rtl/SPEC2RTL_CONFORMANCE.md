# Spec-to-RTL Conformance Report

Status: **partial**

- Requirements checked: 37
- Matched: 34
- Partial: 0
- Missing: 3
- Inconclusive: 0
- Interface: pass
- Register map: issues
- Clock/reset: pass

## Missing Or Partial Requirements
- REQ-018 [missing]: LATEST_TEMP returns the current filtered temperature in bits [11:0] with upper bits zero.
- REQ-024 [missing]: The design must not clear LATEST_TEMP, THRESHOLD, or SAMPLE_COUNT when ALERT_CLEAR or IRQ_CLEAR is written.
