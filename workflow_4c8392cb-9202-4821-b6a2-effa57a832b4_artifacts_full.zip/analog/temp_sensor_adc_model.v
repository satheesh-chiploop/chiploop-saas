module temp_sensor_adc_model (
    input  sample_req,
    input  [15:0] sensor_temp_celsius,
    input  avdd,
    input  avss,
    output reg [11:0] adc_code,
    output reg adc_valid
);

    localparam integer TEMP_OFFSET_C        = 0;
    localparam integer TEMP_SCALE_NUM       = 4095;
    localparam integer TEMP_SCALE_DEN       = 100;
    localparam integer GAIN_ERROR_PPM       = 0;
    localparam integer OFFSET_ERROR_CODE    = 0;
    localparam integer SAMPLE_LATENCY_CYC   = 1;

    reg pending_sample;
    reg [31:0] latency_count;

    reg [31:0] temp_unsigned;
    reg signed [31:0] temp_signed;
    reg signed [31:0] ideal_code_signed;
    reg signed [31:0] gain_scaled_code;
    reg signed [31:0] offset_scaled_code;
    reg signed [31:0] computed_code_signed;
    reg [11:0] computed_code_clamped;

    reg [31:0] abs_temp;
    reg signed [31:0] temp_minus_offset;

    always @(*) begin
        temp_unsigned = {16'd0, sensor_temp_celsius};
        temp_signed = $signed({1'b0, sensor_temp_celsius});

        temp_minus_offset = temp_signed - TEMP_OFFSET_C;
        ideal_code_signed = (temp_minus_offset * TEMP_SCALE_NUM) / TEMP_SCALE_DEN;

        gain_scaled_code = (ideal_code_signed * GAIN_ERROR_PPM) / 1000000;
        offset_scaled_code = OFFSET_ERROR_CODE;

        computed_code_signed = ideal_code_signed + gain_scaled_code + offset_scaled_code;

        if (computed_code_signed < 0)
            computed_code_clamped = 12'd0;
        else if (computed_code_signed > 4095)
            computed_code_clamped = 12'd4095;
        else
            computed_code_clamped = computed_code_signed[11:0];
    end

    always @(posedge sample_req or posedge avdd or posedge avss) begin
        if (avdd === 1'b0 || avss === 1'b1) begin
            adc_code <= 12'd0;
            adc_valid <= 1'b0;
            pending_sample <= 1'b0;
            latency_count <= 32'd0;
        end else begin
            if (sample_req === 1'b1) begin
                pending_sample <= 1'b1;
                latency_count <= SAMPLE_LATENCY_CYC[31:0];
                adc_valid <= 1'b0;
            end
        end
    end


endmodule
