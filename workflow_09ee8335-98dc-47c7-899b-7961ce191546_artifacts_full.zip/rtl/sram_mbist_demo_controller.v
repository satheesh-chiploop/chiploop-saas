module sram_mbist_demo_controller (
    input clk,
    input csb,
    input web,
    input [7:0] addr,
    input [31:0] din,
    output [31:0] dout
);

reg [31:0] mem [0:255];
reg [31:0] dout_r;

assign dout = dout_r;

integer i;

always @(posedge clk) begin
    if (csb == 1'b0) begin
        if (web == 1'b0) begin
            mem[addr] <= din;
            dout_r <= din;
        end else begin
            dout_r <= mem[addr];
        end
    end
end

endmodule
