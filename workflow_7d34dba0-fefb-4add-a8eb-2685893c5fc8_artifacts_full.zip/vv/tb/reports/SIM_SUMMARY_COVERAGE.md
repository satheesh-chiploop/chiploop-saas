# Simulation Summary + Coverage

- Total simulation runs: 8
- Simulation pass count: 8
- Simulation fail count: 0
- Coverage status: ok
- Functional coverage %: 76.92
- Coverage bins hit: 20
- Coverage total bins: 26
- Functional bin gaps: 6
- Code line coverage: 59.91%
- Code branch coverage: 3.19%
- Code condition coverage: 3.19%
- Code toggle coverage: 9.43%
- SVA/assertion status: ok
- SVA/assertion pass %: 100.0%
- Formal status: fail
- Golden model status: generated
- Simulator tool: verilator
- Code coverage tool: verilator_coverage
- Formal tool: symbiyosys
- Golden model tool: chiploop_python_scoreboard

## Functional Coverage Not Met
- outputs.bist_fail: bins 1/2, missing nonzero, seen values [0]
- outputs.irq: bins 1/2, missing nonzero, seen values [0]
- outputs.rd_data: bins 1/2, missing nonzero, seen values [0]
- outputs.ready: bins 1/2, missing nonzero, seen values [0]
- inputs.clk: bins 1/2, missing zero, seen values [1]
- inputs.reset_n: bins 1/2, missing zero, seen values [1]
