module sram_mbist_demo_controller (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    bist_start,
    rd_data,
    ready,
    bist_done,
    bist_fail,
    irq
);
    input clk;
    input reset_n;
    input wr_en;
    input [7:0] wr_addr;
    input [31:0] wr_data;
    input rd_en;
    input [7:0] rd_addr;
    input bist_start;
    output [31:0] rd_data;
    output ready;
    output bist_done;
    output bist_fail;
    output irq;

    wire mem_csb;
    wire mem_web;
    wire [7:0] mem_addr;
    wire [31:0] mem_din;
    wire [31:0] mem_dout;
    wire bist_request;
    wire irq_enable;

    reg [31:0] control_reg;
    reg [31:0] mem_addr_reg;
    reg [31:0] mem_wdata_reg;
    reg [31:0] mem_rdata_reg;
    reg [31:0] mem_control_reg;
    reg [31:0] bist_control_reg;
    reg [31:0] bist_status_reg;
    reg [31:0] irq_status_reg;
    reg [31:0] last_fail_addr_reg;
    reg op_active;
    reg op_read;
    reg bist_running;
    reg bist_done_latched;
    reg bist_fail_latched;
    reg irq_latched;

    reg [31:0] rd_data_r;
    reg ready_r;
    reg bist_done_r;
    reg bist_fail_r;
    reg irq_r;

    reg mem_csb_r;
    reg mem_web_r;
    reg [7:0] mem_addr_r;
    reg [31:0] mem_din_r;
    reg bist_request_r;
    reg irq_enable_r;

    assign rd_data = rd_data_r;
    assign ready = ready_r;
    assign bist_done = bist_done_r;
    assign bist_fail = bist_fail_r;
    assign irq = irq_r;

    assign mem_csb = mem_csb_r;
    assign mem_web = mem_web_r;
    assign mem_addr = mem_addr_r;
    assign mem_din = mem_din_r;
    assign bist_request = bist_request_r;
    assign irq_enable = irq_enable_r;

    demo_sram_32x256_wrapper u_sram (
        .clk(clk),
        .csb(mem_csb),
        .web(mem_web),
        .addr(mem_addr),
        .din(mem_din),
        .dout(mem_dout)
    );

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            control_reg <= 32'h00000000;
            mem_addr_reg <= 32'h00000000;
            mem_wdata_reg <= 32'h00000000;
            mem_rdata_reg <= 32'h00000000;
            mem_control_reg <= 32'h00000000;
            bist_control_reg <= 32'h00000000;
            bist_status_reg <= 32'h00000000;
            irq_status_reg <= 32'h00000000;
            last_fail_addr_reg <= 32'h00000000;
            op_active <= 1'b0;
            op_read <= 1'b0;
            bist_running <= 1'b0;
            bist_done_latched <= 1'b0;
            bist_fail_latched <= 1'b0;
            irq_latched <= 1'b0;
            rd_data_r <= 32'h00000000;
            ready_r <= 1'b0;
            bist_done_r <= 1'b0;
            bist_fail_r <= 1'b0;
            irq_r <= 1'b0;
            mem_csb_r <= 1'b1;
            mem_web_r <= 1'b1;
            mem_addr_r <= 8'h00;
            mem_din_r <= 32'h00000000;
            bist_request_r <= 1'b0;
            irq_enable_r <= 1'b0;
        end else begin
            control_reg[0] <= control_reg[0];
            control_reg[1] <= control_reg[1];
            control_reg[2] <= control_reg[2];
            control_reg[31:3] <= control_reg[31:3];
            mem_addr_reg <= mem_addr_reg;
            mem_wdata_reg <= mem_wdata_reg;
            mem_rdata_reg <= mem_dout;
            mem_control_reg <= 32'h00000000;
            bist_control_reg <= 32'h00000000;
            bist_status_reg <= {21'h000000, last_fail_addr_reg[7:0], bist_running, bist_fail_latched, bist_done_latched, 20'h00000};
            irq_status_reg <= {30'h00000000, irq_status_reg[1:0]};
            last_fail_addr_reg <= last_fail_addr_reg;
            op_active <= 1'b0;
            op_read <= 1'b0;
            bist_running <= bist_running;
            bist_done_latched <= bist_done_latched;
            bist_fail_latched <= bist_fail_latched;
            irq_latched <= irq_latched;
            rd_data_r <= rd_data_r;
            ready_r <= control_reg[0] & ~control_reg[1] & ~bist_running;
            bist_done_r <= bist_done_latched;
            bist_fail_r <= bist_fail_latched;
            irq_r <= irq_enable_r & (irq_status_reg[0] | irq_status_reg[1]);
            mem_csb_r <= 1'b1;
            mem_web_r <= 1'b1;
            mem_addr_r <= mem_addr_r;
            mem_din_r <= mem_din_r;
            bist_request_r <= 1'b0;
            irq_enable_r <= control_reg[2];

            if (control_reg[1]) begin
                control_reg <= 32'h00000000;
                mem_addr_reg <= 32'h00000000;
                mem_wdata_reg <= 32'h00000000;
                mem_rdata_reg <= 32'h00000000;
                mem_control_reg <= 32'h00000000;
                bist_control_reg <= 32'h00000000;
                bist_status_reg <= 32'h00000000;
                irq_status_reg <= 32'h00000000;
                last_fail_addr_reg <= 32'h00000000;
                bist_running <= 1'b0;
                bist_done_latched <= 1'b0;
                bist_fail_latched <= 1'b0;
                irq_latched <= 1'b0;
                ready_r <= 1'b0;
                bist_done_r <= 1'b0;
                bist_fail_r <= 1'b0;
                irq_r <= 1'b0;
                irq_enable_r <= 1'b0;
            end else begin
                if (wr_en) begin
                    case (wr_addr)
                        8'h00: begin
                            control_reg[0] <= wr_data[0];
                            control_reg[1] <= wr_data[1];
                            control_reg[2] <= wr_data[2];
                        end
                        8'h08: begin
                            mem_addr_reg[7:0] <= wr_data[7:0];
                        end
                        8'h0C: begin
                            mem_wdata_reg <= wr_data;
                        end
                        8'h14: begin
                            mem_control_reg <= wr_data;
                        end
                        8'h18: begin
                            bist_control_reg <= wr_data;
                        end
                        8'h20: begin
                            irq_status_reg[0] <= wr_data[0] ? 1'b1 : irq_status_reg[0];
                            irq_status_reg[1] <= wr_data[1] ? 1'b1 : irq_status_reg[1];
                        end
                        8'h24: begin
                            irq_status_reg[0] <= wr_data[0] ? 1'b0 : irq_status_reg[0];
                            irq_status_reg[1] <= wr_data[1] ? 1'b0 : irq_status_reg[1];
                        end
                        default: begin
                        end
                    endcase
                end

                if (rd_en) begin
                    case (rd_addr)
                        8'h00: rd_data_r <= control_reg;
                        8'h04: rd_data_r <= {28'h0000000, bist_running, bist_fail_latched, bist_done_latched, ready_r};
                        8'h08: rd_data_r <= {24'h000000, mem_addr_reg[7:0]};
                        8'h0C: rd_data_r <= mem_wdata_reg;
                        8'h10: rd_data_r <= mem_rdata_reg;
                        8'h14: rd_data_r <= mem_control_reg;
                        8'h18: rd_data_r <= bist_control_reg;
                        8'h1C: rd_data_r <= {22'h000000, last_fail_addr_reg[7:0], bist_running, bist_fail_latched, bist_done_latched, 20'h00000};
                        8'h20: rd_data_r <= irq_status_reg;
                        8'h24: rd_data_r <= 32'h00000000;
                        default: rd_data_r <= 32'h00000000;
                    endcase
                end

                if (wr_en && (wr_addr == 8'h14) && wr_data[0]) begin
                    mem_csb_r <= 1'b0;
                    mem_web_r <= 1'b0;
                    mem_addr_r <= mem_addr_reg[7:0];
                    mem_din_r <= mem_wdata_reg;
                end else if (wr_en && (wr_addr == 8'h14) && wr_data[1]) begin
                    mem_csb_r <= 1'b0;
                    mem_web_r <= 1'b1;
                    mem_addr_r <= mem_addr_reg[7:0];
                    mem_din_r <= mem_din_r;
                end else begin
                    mem_csb_r <= 1'b1;
                    mem_web_r <= 1'b1;
                end

                if (bist_start || bist_control_reg[0]) begin
                    bist_request_r <= 1'b1;
                    bist_running <= 1'b1;
                    bist_done_latched <= 1'b0;
                    bist_fail_latched <= 1'b0;
                    irq_status_reg[0] <= 1'b0;
                    irq_status_reg[1] <= 1'b0;
                end

                if (bist_control_reg[1]) begin
                    bist_running <= 1'b0;
                    bist_done_latched <= 1'b0;
                    bist_fail_latched <= 1'b0;
                    last_fail_addr_reg <= 32'h00000000;
                    irq_status_reg[0] <= 1'b0;
                    irq_status_reg[1] <= 1'b0;
                end

                if (op_active && op_read) begin
                    mem_rdata_reg <= mem_dout;
                end

                if (bist_running) begin
                    bist_done_latched <= 1'b1;
                    bist_running <= 1'b0;
                    irq_status_reg[0] <= 1'b1;
                    irq_latched <= 1'b1;
                end

                if (irq_status_reg[0] || irq_status_reg[1]) begin
                    irq_latched <= 1'b1;
                end

                ready_r <= control_reg[0] & ~control_reg[1] & ~bist_running;
                bist_done_r <= bist_done_latched;
                bist_fail_r <= bist_fail_latched;
                irq_r <= irq_enable_r & (irq_status_reg[0] | irq_status_reg[1]);

                if (control_reg[0] == 1'b0) begin
                    ready_r <= 1'b0;
                end
            end
        end
    end
endmodule
