# Generated Product App

Open `system/product/app/index.html` from the downloaded ZIP.

This is a simulator-backed app generated from the RTL, firmware, software, and validation workflow lineage.
The simulator adapter can later be replaced with a board or silicon transport.
