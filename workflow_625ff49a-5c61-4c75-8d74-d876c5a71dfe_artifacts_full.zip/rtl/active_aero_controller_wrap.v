module active_aero_controller_wrap (
    clk,
    reset_n,
    vehicle_geometry_valid,
    vehicle_geometry_start,
    vehicle_geometry_last,
    vehicle_geometry_len,
    vehicle_geometry_desc,
    vehicle_geometry_payload,
    flow_conditions_valid,
    flow_conditions_velocity_mps,
    flow_conditions_meta,
    flow_conditions_update,
    model_request_ready,
    model_response_valid,
    model_response_ready,
    model_response_id,
    model_response_drag_force,
    model_response_lift_force,
    model_response_surface_pressure,
    model_response_flow_field,
    model_response_error,
    actuator0_min_limit,
    actuator0_max_limit,
    actuator0_rate_limit_delta,
    actuator1_min_limit,
    actuator1_max_limit,
    actuator1_rate_limit_delta,
    actuator_safe_hold_value,
    actuator_command0,
    actuator_command1,
    request_valid,
    request_id,
    request_geometry_desc,
    request_geometry_payload,
    request_flow_velocity_mps,
    request_flow_meta,
    request_age,
    safe_fallback_request,
    fault_input_range,
    fault_request_outstanding,
    fault_response_valid,
    fault_stale_reject,
    fault_timeout,
    fault_clamp_active,
    fault_fallback_active,
    diagnostic_live_faults,
    diagnostic_sticky_faults,
    diagnostic_request_seq,
    diagnostic_response_seq,
    diagnostic_timeout_counter,
    diagnostic_outstanding,
    diagnostic_response_age
);
    input clk;
    input reset_n;
    input vehicle_geometry_valid;
    input vehicle_geometry_start;
    input vehicle_geometry_last;
    input [15:0] vehicle_geometry_len;
    input [31:0] vehicle_geometry_desc;
    input [63:0] vehicle_geometry_payload;
    input flow_conditions_valid;
    input [15:0] flow_conditions_velocity_mps;
    input [15:0] flow_conditions_meta;
    input flow_conditions_update;
    input model_request_ready;
    input model_response_valid;
    input model_response_ready;
    input [15:0] model_response_id;
    input [31:0] model_response_drag_force;
    input [31:0] model_response_lift_force;
    input [31:0] model_response_surface_pressure;
    input [63:0] model_response_flow_field;
    input model_response_error;
    input [15:0] actuator0_min_limit;
    input [15:0] actuator0_max_limit;
    input [15:0] actuator0_rate_limit_delta;
    input [15:0] actuator1_min_limit;
    input [15:0] actuator1_max_limit;
    input [15:0] actuator1_rate_limit_delta;
    input [15:0] actuator_safe_hold_value;
    output [15:0] actuator_command0;
    output [15:0] actuator_command1;
    output request_valid;
    output [15:0] request_id;
    output [31:0] request_geometry_desc;
    output [63:0] request_geometry_payload;
    output [15:0] request_flow_velocity_mps;
    output [15:0] request_flow_meta;
    output [15:0] request_age;
    output safe_fallback_request;
    output fault_input_range;
    output fault_request_outstanding;
    output fault_response_valid;
    output fault_stale_reject;
    output fault_timeout;
    output fault_clamp_active;
    output fault_fallback_active;
    output [7:0] diagnostic_live_faults;
    output [7:0] diagnostic_sticky_faults;
    output [15:0] diagnostic_request_seq;
    output [15:0] diagnostic_response_seq;
    output [15:0] diagnostic_timeout_counter;
    output diagnostic_outstanding;
    output [15:0] diagnostic_response_age;
    reg [15:0] request_id_r;
    reg [31:0] request_geometry_desc_r;
    reg [63:0] request_geometry_payload_r;
    reg [15:0] request_flow_velocity_mps_r;
    reg [15:0] request_flow_meta_r;
    reg [15:0] request_age_r;
    reg request_valid_r;
    reg safe_fallback_request_r;
    reg fault_input_range_r;
    reg fault_request_outstanding_r;
    reg fault_response_valid_r;
    reg fault_stale_reject_r;
    reg fault_timeout_r;
    reg fault_clamp_active_r;
    reg fault_fallback_active_r;
    reg [7:0] diagnostic_live_faults_r;
    reg [7:0] diagnostic_sticky_faults_r;
    reg [15:0] diagnostic_request_seq_r;
    reg [15:0] diagnostic_response_seq_r;
    reg [15:0] diagnostic_timeout_counter_r;
    reg diagnostic_outstanding_r;
    reg [15:0] diagnostic_response_age_r;
    reg [15:0] actuator_command0_r;
    reg [15:0] actuator_command1_r;
    reg [15:0] sampled_vehicle_geometry_len;
    reg [31:0] sampled_vehicle_geometry_desc;
    reg [63:0] sampled_vehicle_geometry_payload;
    reg sampled_vehicle_geometry_valid;
    reg sampled_vehicle_geometry_start;
    reg sampled_vehicle_geometry_last;
    reg sampled_flow_conditions_valid;
    reg [15:0] sampled_flow_conditions_velocity_mps;
    reg [15:0] sampled_flow_conditions_meta;
    reg sampled_flow_conditions_update;
    reg sampled_model_request_ready;
    reg sampled_model_response_valid;
    reg sampled_model_response_ready;
    reg [15:0] sampled_model_response_id;
    reg [31:0] sampled_model_response_drag_force;
    reg [31:0] sampled_model_response_lift_force;
    reg [31:0] sampled_model_response_surface_pressure;
    reg [63:0] sampled_model_response_flow_field;
    reg sampled_model_response_error;
    reg [15:0] sampled_actuator0_min_limit;
    reg [15:0] sampled_actuator0_max_limit;
    reg [15:0] sampled_actuator0_rate_limit_delta;
    reg [15:0] sampled_actuator1_min_limit;
    reg [15:0] sampled_actuator1_max_limit;
    reg [15:0] sampled_actuator1_rate_limit_delta;
    reg [15:0] sampled_actuator_safe_hold_value;

    reg [15:0] target0;
    reg [15:0] target1;
    reg [15:0] clamped0;
    reg [15:0] clamped1;
    reg [15:0] limited0;
    reg [15:0] limited1;
    reg [15:0] prev_command0;
    reg [15:0] prev_command1;
    reg [15:0] age_next;
    reg [15:0] timeout_next;

    wire input_range_ok;
    wire request_outstanding_next;
    wire response_match;
    wire response_good;
    wire response_stale;
    wire timeout_event;
    wire clamp0_low;
    wire clamp0_high;
    wire clamp1_low;
    wire clamp1_high;
    wire clamp_event0;
    wire clamp_event1;
    wire clamp_event_any;
    wire fallback_active_next;
    wire [15:0] response_age_plus_one;
    wire [15:0] request_id_next;
    wire [15:0] request_age_next;
    wire [15:0] diag_timeout_next;
    wire [7:0] live_faults_next;
    wire [7:0] sticky_faults_next;

    assign input_range_ok = (sampled_flow_conditions_valid && (sampled_flow_conditions_velocity_mps >= 16'd20) && (sampled_flow_conditions_velocity_mps <= 16'd55));
    assign response_match = (sampled_model_response_valid && sampled_model_response_ready && request_valid_r && diagnostic_outstanding_r && (sampled_model_response_id == request_id_r));
    assign response_good = (response_match && !sampled_model_response_error && input_range_ok);
    assign response_stale = (sampled_model_response_valid && sampled_model_response_ready && (!request_valid_r || !diagnostic_outstanding_r || (sampled_model_response_id != request_id_r)));
    assign timeout_event = (diagnostic_outstanding_r && (diagnostic_timeout_counter_r == 16'hFFFF));
    assign clamp0_low = (target0 < sampled_actuator0_min_limit);
    assign clamp0_high = (target0 > sampled_actuator0_max_limit);
    assign clamp1_low = (target1 < sampled_actuator1_min_limit);
    assign clamp1_high = (target1 > sampled_actuator1_max_limit);
    assign clamp_event0 = (clamp0_low || clamp0_high);
    assign clamp_event1 = (clamp1_low || clamp1_high);
    assign clamp_event_any = (clamp_event0 || clamp_event1);
    assign fallback_active_next = (!input_range_ok || response_stale || timeout_event || sampled_model_response_error || clamp_event_any || fault_fallback_active_r);
    assign response_age_plus_one = diagnostic_response_age_r + 16'd1;
    assign request_id_next = request_id_r + 16'd1;
    assign request_age_next = diagnostic_response_age_r;
    assign diag_timeout_next = diagnostic_timeout_counter_r + 16'd1;
    assign live_faults_next = {1'b0, fallback_active_next, clamp_event_any, timeout_event, response_stale, response_good, request_outstanding_next, !input_range_ok};
    assign sticky_faults_next = diagnostic_sticky_faults_r | live_faults_next;

    assign request_outstanding_next = (request_valid_r && !response_good && !timeout_event);
    assign actuator_command0 = actuator_command0_r;
    assign actuator_command1 = actuator_command1_r;
    assign request_valid = request_valid_r;
    assign request_id = request_id_r;
    assign request_geometry_desc = request_geometry_desc_r;
    assign request_geometry_payload = request_geometry_payload_r;
    assign request_flow_velocity_mps = request_flow_velocity_mps_r;
    assign request_flow_meta = request_flow_meta_r;
    assign request_age = request_age_r;
    assign safe_fallback_request = safe_fallback_request_r;
    assign fault_input_range = fault_input_range_r;
    assign fault_request_outstanding = fault_request_outstanding_r;
    assign fault_response_valid = fault_response_valid_r;
    assign fault_stale_reject = fault_stale_reject_r;
    assign fault_timeout = fault_timeout_r;
    assign fault_clamp_active = fault_clamp_active_r;
    assign fault_fallback_active = fault_fallback_active_r;
    assign diagnostic_live_faults = diagnostic_live_faults_r;
    assign diagnostic_sticky_faults = diagnostic_sticky_faults_r;
    assign diagnostic_request_seq = diagnostic_request_seq_r;
    assign diagnostic_response_seq = diagnostic_response_seq_r;
    assign diagnostic_timeout_counter = diagnostic_timeout_counter_r;
    assign diagnostic_outstanding = diagnostic_outstanding_r;
    assign diagnostic_response_age = diagnostic_response_age_r;

    always @(posedge clk) begin
        if (!reset_n) begin
            sampled_vehicle_geometry_len <= 16'h0000;
            sampled_vehicle_geometry_desc <= 32'h00000000;
            sampled_vehicle_geometry_payload <= 64'h0000000000000000;
            sampled_vehicle_geometry_valid <= 1'b0;
            sampled_vehicle_geometry_start <= 1'b0;
            sampled_vehicle_geometry_last <= 1'b0;
            sampled_flow_conditions_valid <= 1'b0;
            sampled_flow_conditions_velocity_mps <= 16'h0000;
            sampled_flow_conditions_meta <= 16'h0000;
            sampled_flow_conditions_update <= 1'b0;
            sampled_model_request_ready <= 1'b0;
            sampled_model_response_valid <= 1'b0;
            sampled_model_response_ready <= 1'b0;
            sampled_model_response_id <= 16'h0000;
            sampled_model_response_drag_force <= 32'h00000000;
            sampled_model_response_lift_force <= 32'h00000000;
            sampled_model_response_surface_pressure <= 32'h00000000;
            sampled_model_response_flow_field <= 64'h0000000000000000;
            sampled_model_response_error <= 1'b0;
            sampled_actuator0_min_limit <= 16'h0000;
            sampled_actuator0_max_limit <= 16'h0000;
            sampled_actuator0_rate_limit_delta <= 16'h0000;
            sampled_actuator1_min_limit <= 16'h0000;
            sampled_actuator1_max_limit <= 16'h0000;
            sampled_actuator1_rate_limit_delta <= 16'h0000;
            sampled_actuator_safe_hold_value <= 16'h0000;
            request_id_r <= 16'h0000;
            request_geometry_desc_r <= 32'h00000000;
            request_geometry_payload_r <= 64'h0000000000000000;
            request_flow_velocity_mps_r <= 16'h0000;
            request_flow_meta_r <= 16'h0000;
            request_age_r <= 16'h0000;
            request_valid_r <= 1'b0;
            safe_fallback_request_r <= 1'b1;
            fault_input_range_r <= 1'b0;
            fault_request_outstanding_r <= 1'b0;
            fault_response_valid_r <= 1'b0;
            fault_stale_reject_r <= 1'b0;
            fault_timeout_r <= 1'b0;
            fault_clamp_active_r <= 1'b0;
            fault_fallback_active_r <= 1'b1;
            diagnostic_live_faults_r <= 8'h40;
            diagnostic_sticky_faults_r <= 8'h40;
            diagnostic_request_seq_r <= 16'h0000;
            diagnostic_response_seq_r <= 16'h0000;
            diagnostic_timeout_counter_r <= 16'h0000;
            diagnostic_outstanding_r <= 1'b0;
            diagnostic_response_age_r <= 16'h0000;
            actuator_command0_r <= 16'h0000;
            actuator_command1_r <= 16'h0000;
            prev_command0 <= 16'h0000;
            prev_command1 <= 16'h0000;
        end else begin
            sampled_vehicle_geometry_len <= vehicle_geometry_len;
            sampled_vehicle_geometry_desc <= vehicle_geometry_desc;
            sampled_vehicle_geometry_payload <= vehicle_geometry_payload;
            sampled_vehicle_geometry_valid <= vehicle_geometry_valid;
            sampled_vehicle_geometry_start <= vehicle_geometry_start;
            sampled_vehicle_geometry_last <= vehicle_geometry_last;
            sampled_flow_conditions_valid <= flow_conditions_valid;
            sampled_flow_conditions_velocity_mps <= flow_conditions_velocity_mps;
            sampled_flow_conditions_meta <= flow_conditions_meta;
            sampled_flow_conditions_update <= flow_conditions_update;
            sampled_model_request_ready <= model_request_ready;
            sampled_model_response_valid <= model_response_valid;
            sampled_model_response_ready <= model_response_ready;
            sampled_model_response_id <= model_response_id;
            sampled_model_response_drag_force <= model_response_drag_force;
            sampled_model_response_lift_force <= model_response_lift_force;
            sampled_model_response_surface_pressure <= model_response_surface_pressure;
            sampled_model_response_flow_field <= model_response_flow_field;
            sampled_model_response_error <= model_response_error;
            sampled_actuator0_min_limit <= actuator0_min_limit;
            sampled_actuator0_max_limit <= actuator0_max_limit;
            sampled_actuator0_rate_limit_delta <= actuator0_rate_limit_delta;
            sampled_actuator1_min_limit <= actuator1_min_limit;
            sampled_actuator1_max_limit <= actuator1_max_limit;
            sampled_actuator1_rate_limit_delta <= actuator1_rate_limit_delta;
            sampled_actuator_safe_hold_value <= actuator_safe_hold_value;

            request_geometry_desc_r <= sampled_vehicle_geometry_desc;
            request_geometry_payload_r <= sampled_vehicle_geometry_payload;
            request_flow_velocity_mps_r <= sampled_flow_conditions_velocity_mps;
            request_flow_meta_r <= sampled_flow_conditions_meta;
            request_age_r <= diagnostic_response_age_r;
            diagnostic_request_seq_r <= request_id_r;
            diagnostic_response_seq_r <= sampled_model_response_id;
            diagnostic_response_age_r <= request_outstanding_next ? response_age_plus_one : 16'h0000;
            diagnostic_timeout_counter_r <= timeout_event ? diag_timeout_next : 16'h0000;
            diagnostic_outstanding_r <= request_outstanding_next;

            if (input_range_ok && sampled_vehicle_geometry_valid && sampled_vehicle_geometry_start && sampled_vehicle_geometry_last && sampled_model_request_ready && !request_valid_r && !diagnostic_outstanding_r) begin
                request_valid_r <= 1'b1;
                request_id_r <= request_id_next;
                diagnostic_outstanding_r <= 1'b1;
                diagnostic_response_age_r <= 16'h0000;
            end else if (response_good) begin
                request_valid_r <= 1'b0;
                diagnostic_outstanding_r <= 1'b0;
                fault_response_valid_r <= 1'b1;
                fault_stale_reject_r <= 1'b0;
                fault_timeout_r <= 1'b0;
                actuator_command0_r <= limited0;
                actuator_command1_r <= limited1;
                prev_command0 <= limited0;
                prev_command1 <= limited1;
            end else if (response_stale) begin
                fault_stale_reject_r <= 1'b1;
                fault_response_valid_r <= 1'b0;
            end

            if (timeout_event) begin
                fault_timeout_r <= 1'b1;
                request_valid_r <= 1'b0;
                diagnostic_outstanding_r <= 1'b0;
                diagnostic_timeout_counter_r <= 16'h0000;
            end else if (diagnostic_outstanding_r) begin
                diagnostic_timeout_counter_r <= diag_timeout_next;
            end

            if (!input_range_ok) begin
                fault_input_range_r <= 1'b1;
            end else begin
                fault_input_range_r <= 1'b0;
            end

            if (clamp_event_any) begin
                fault_clamp_active_r <= 1'b1;
            end else begin
                fault_clamp_active_r <= 1'b0;
            end

            if (fallback_active_next) begin
                safe_fallback_request_r <= 1'b1;
                fault_fallback_active_r <= 1'b1;
                actuator_command0_r <= sampled_actuator_safe_hold_value;
                actuator_command1_r <= sampled_actuator_safe_hold_value;
                prev_command0 <= sampled_actuator_safe_hold_value;
                prev_command1 <= sampled_actuator_safe_hold_value;
            end else begin
                safe_fallback_request_r <= 1'b0;
                fault_fallback_active_r <= 1'b0;
            end

            if (request_valid_r && !response_good) begin
                fault_request_outstanding_r <= 1'b1;
            end else begin
                fault_request_outstanding_r <= diagnostic_outstanding_r;
            end

            diagnostic_live_faults_r <= live_faults_next;
            diagnostic_sticky_faults_r <= sticky_faults_next;

            target0 <= sampled_model_response_drag_force[15:0] ^ sampled_model_response_surface_pressure[15:0];
            target1 <= sampled_model_response_lift_force[15:0] ^ sampled_model_response_flow_field[15:0];

            if (clamp0_low) begin
                clamped0 <= sampled_actuator0_min_limit;
            end else if (clamp0_high) begin
                clamped0 <= sampled_actuator0_max_limit;
            end else begin
                clamped0 <= target0;
            end

            if (clamp1_low) begin
                clamped1 <= sampled_actuator1_min_limit;
            end else if (clamp1_high) begin
                clamped1 <= sampled_actuator1_max_limit;
            end else begin
                clamped1 <= target1;
            end

            if (clamped0 > prev_command0) begin
                if ((clamped0 - prev_command0) > sampled_actuator0_rate_limit_delta) begin
                    limited0 <= prev_command0 + sampled_actuator0_rate_limit_delta;
                end else begin
                    limited0 <= clamped0;
                end
            end else begin
                if ((prev_command0 - clamped0) > sampled_actuator0_rate_limit_delta) begin
                    limited0 <= prev_command0 - sampled_actuator0_rate_limit_delta;
                end else begin
                    limited0 <= clamped0;
                end
            end

            if (clamped1 > prev_command1) begin
                if ((clamped1 - prev_command1) > sampled_actuator1_rate_limit_delta) begin
                    limited1 <= prev_command1 + sampled_actuator1_rate_limit_delta;
                end else begin
                    limited1 <= clamped1;
                end
            end else begin
                if ((prev_command1 - clamped1) > sampled_actuator1_rate_limit_delta) begin
                    limited1 <= prev_command1 - sampled_actuator1_rate_limit_delta;
                end else begin
                    limited1 <= clamped1;
                end
            end
        end
    end
endmodule
