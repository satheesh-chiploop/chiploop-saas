module pwm_fpga_demo (
    clk,
    led
);

input clk;
output led;

reg [7:0] pwm_cnt;
reg [7:0] duty_cycle;
reg       direction;
reg [23:0] slow_cnt;
reg       led_r;

assign led = led_r;

always @(posedge clk) begin
    pwm_cnt <= pwm_cnt + 8'd1;

    slow_cnt <= slow_cnt + 24'd1;

    if (slow_cnt == 24'd0) begin
        if (direction) begin
            if (duty_cycle == 8'hFF) begin
                duty_cycle <= 8'hFF;
                direction <= 1'b0;
            end else begin
                duty_cycle <= duty_cycle + 8'd1;
                direction <= 1'b1;
            end
        end else begin
            if (duty_cycle == 8'h00) begin
                duty_cycle <= 8'h00;
                direction <= 1'b1;
            end else begin
                duty_cycle <= duty_cycle - 8'd1;
                direction <= 1'b0;
            end
        end
    end

    led_r <= (pwm_cnt < duty_cycle);
end

initial begin
    pwm_cnt = 8'h00;
    duty_cycle = 8'h10;
    direction = 1'b1;
    slow_cnt = 24'h000000;
    led_r = 1'b0;
end

endmodule
