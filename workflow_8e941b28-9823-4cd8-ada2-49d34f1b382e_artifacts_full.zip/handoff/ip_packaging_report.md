# IP Packaging & Handoff Report

- Top: `pwm_fpga_demo`
- Package: `backend/workflows/8e941b28-9823-4cd8-ada2-49d34f1b382e/handoff/pwm_fpga_demo_ip_package`
- Zip: `backend/workflows/8e941b28-9823-4cd8-ada2-49d34f1b382e/handoff/pwm_fpga_demo_ip_package.zip`

## Bucket counts
- **rtl**: 1
- **spec**: 3
- **arch**: 1
- **microarch**: 1
- **regmap**: 2
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 7
