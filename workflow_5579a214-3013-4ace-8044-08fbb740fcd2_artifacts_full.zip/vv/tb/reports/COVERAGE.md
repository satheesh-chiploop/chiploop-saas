# System Functional Coverage Summary

- Top module: temp_monitor_soc_sim
- Functional coverage: 17.86%
- Bins hit: 15
- Total bins: 84

## Outputs
- alert_irq: samples=40, bins=1/2
- alert_status: samples=40, bins=1/2
- rd_data: samples=40, bins=1/2
- temp_code: samples=40, bins=1/2
- threshold_code: samples=40, bins=1/2

## Inputs
- avdd: samples=40, bins=2/2
- avss: samples=40, bins=2/2
- clk: samples=40, bins=1/2
- rd_addr: samples=40, bins=0/2
- rd_en: samples=40, bins=2/2
- reset_n: samples=40, bins=1/2
- sensor_temp_celsius: samples=40, bins=0/2
- wr_addr: samples=40, bins=0/2
- wr_data: samples=40, bins=0/2
- wr_en: samples=40, bins=2/2

## Registers
- CONTROL_L: reads=0, writes=0, bins=0/2
- CONTROL_H: reads=0, writes=0, bins=0/2
- STATUS_L: reads=0, writes=0, bins=0/1
- STATUS_H: reads=0, writes=0, bins=0/1
- THRESHOLD_L: reads=0, writes=0, bins=0/2
- THRESHOLD_H: reads=0, writes=0, bins=0/2
- LATEST_TEMP_L: reads=0, writes=0, bins=0/1
- LATEST_TEMP_H: reads=0, writes=0, bins=0/1
- SAMPLE_COUNT_L: reads=0, writes=0, bins=0/1
- SAMPLE_COUNT_H: reads=0, writes=0, bins=0/1
- IRQ_STATUS_L: reads=0, writes=0, bins=0/1
- IRQ_STATUS_H: reads=0, writes=0, bins=0/1
- IRQ_CLEAR_L: reads=0, writes=0, bins=0/1
- IRQ_CLEAR_H: reads=0, writes=0, bins=0/1

## Fields
- CONTROL_L.ENABLE: writes_non_reset=0, reads=0, bins=0/2
- CONTROL_L.SAMPLE_START: writes_non_reset=0, reads=0, bins=0/2
- CONTROL_L.IRQ_ENABLE: writes_non_reset=0, reads=0, bins=0/2
- CONTROL_L.ALERT_CLEAR: writes_non_reset=0, reads=0, bins=0/2
- STATUS_L.sample_done: writes_non_reset=0, reads=0, bins=0/2
- STATUS_L.alert_pending: writes_non_reset=0, reads=0, bins=0/2
- STATUS_L.adc_valid_seen: writes_non_reset=0, reads=0, bins=0/2
- STATUS_L.busy: writes_non_reset=0, reads=0, bins=0/2
- THRESHOLD_L.threshold_code[7:0]: writes_non_reset=0, reads=0, bins=0/2
- THRESHOLD_H.threshold_code[11:8]: writes_non_reset=0, reads=0, bins=0/2
- LATEST_TEMP_L.temp_code[7:0]: writes_non_reset=0, reads=0, bins=0/2
- LATEST_TEMP_H.temp_code[11:8]: writes_non_reset=0, reads=0, bins=0/2
- SAMPLE_COUNT_L.sample_count[7:0]: writes_non_reset=0, reads=0, bins=0/2
- SAMPLE_COUNT_H.sample_count[15:8]: writes_non_reset=0, reads=0, bins=0/2
- IRQ_STATUS_L.alert: writes_non_reset=0, reads=0, bins=0/2
- IRQ_STATUS_L.sample_done: writes_non_reset=0, reads=0, bins=0/2
- IRQ_CLEAR_L.clear_alert: writes_non_reset=0, reads=0, bins=0/2
- IRQ_CLEAR_L.clear_sample_done: writes_non_reset=0, reads=0, bins=0/2
