# System Simulation Control

Generated files:
- `run_regression.py`: orchestrates multi-seed runs via `make TESTCASE=...`
- `simulation_manifest.json`: consolidated simulation-control manifest for the integrated system DUT

Key resolved inputs:
- Top module: `temp_monitor_soc_sim`
- System integration intent: `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/5579a214-3013-4ace-8044-08fbb740fcd2/7bd4aa9d-08fc-4bd1-b9ad-7820a6b00ab2/digital/system/integration/system_integration_intent.json`
- SoC top (sim): `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/5579a214-3013-4ace-8044-08fbb740fcd2/7bd4aa9d-08fc-4bd1-b9ad-7820a6b00ab2/digital/system/imported_rtl/temp_monitor_soc_sim.sv`
- RTL file count: `4`

Seed management:
- override with `RANDOM_SEED=<int>`

Usage:
```bash
python run_regression.py --tests system_smoke_test integrated_input_sanity --seeds 1 2 3 4 5
```
