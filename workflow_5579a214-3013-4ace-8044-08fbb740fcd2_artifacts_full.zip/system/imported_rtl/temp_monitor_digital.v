module temp_monitor_digital (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    adc_code,
    adc_valid,
    rd_data,
    sample_req,
    alert_irq,
    temp_code,
    threshold_code,
    alert_status
);
input clk;
input reset_n;
input wr_en;
input [7:0] wr_addr;
input [15:0] wr_data;
input rd_en;
input [7:0] rd_addr;
input [11:0] adc_code;
input adc_valid;
output [15:0] rd_data;
output sample_req;
output alert_irq;
output [11:0] temp_code;
output [11:0] threshold_code;
output alert_status;

reg [15:0] rd_data;
reg sample_req;
reg alert_irq;
reg [11:0] temp_code;
reg [11:0] threshold_code;
reg alert_status;

reg [3:0] control_reg;
reg [11:0] threshold_code_reg;
reg [11:0] latest_temp;
reg [15:0] sample_count;
reg irq_status_alert;
reg irq_status_sample_done;
reg status_sample_done;
reg status_alert_pending;
reg status_adc_valid_seen;
reg status_busy;
reg [11:0] prev_adc_code;
reg sample_req_pending;

wire [12:0] adc_sum;
wire [11:0] adc_avg;
wire sample_complete;
wire sample_req_pulse;
wire alert_condition;
wire periodic_sample_req;
wire clear_alert_pulse;
wire clear_sample_done_pulse;
wire start_req_pulse;

assign adc_sum = {1'b0, prev_adc_code} + {1'b0, adc_code};
assign adc_avg = adc_sum[12:1];
assign sample_complete = adc_valid;
assign clear_alert_pulse = wr_en && (wr_addr == 8'h18) && wr_data[0];
assign clear_sample_done_pulse = wr_en && (wr_addr == 8'h18) && wr_data[1];
assign start_req_pulse = wr_en && (wr_addr == 8'h00) && wr_data[1];
assign periodic_sample_req = control_reg[0] && !status_busy && !sample_req_pending && !adc_valid;
assign sample_req_pulse = start_req_pulse || periodic_sample_req;
assign alert_condition = (latest_temp > threshold_code_reg);

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        control_reg <= 4'b0000;
        threshold_code_reg <= 12'h000;
        latest_temp <= 12'h000;
        sample_count <= 16'h0000;
        irq_status_alert <= 1'b0;
        irq_status_sample_done <= 1'b0;
        status_sample_done <= 1'b0;
        status_alert_pending <= 1'b0;
        status_adc_valid_seen <= 1'b0;
        status_busy <= 1'b0;
        prev_adc_code <= 12'h000;
        sample_req_pending <= 1'b0;
        sample_req <= 1'b0;
        alert_irq <= 1'b0;
        temp_code <= 12'h000;
        threshold_code <= 12'h000;
        alert_status <= 1'b0;
    end else begin
        sample_req <= sample_req_pulse;
        alert_irq <= control_reg[2] && (irq_status_alert || irq_status_sample_done);
        temp_code <= latest_temp;
        threshold_code <= threshold_code_reg;
        alert_status <= status_alert_pending;

        if (wr_en && (wr_addr == 8'h00)) begin
            control_reg[0] <= wr_data[0];
            control_reg[2] <= wr_data[2];
            if (wr_data[1]) begin
                sample_req_pending <= 1'b1;
            end
            if (wr_data[3]) begin
                status_alert_pending <= 1'b0;
                irq_status_alert <= 1'b0;
                alert_status <= 1'b0;
            end
        end
        if (wr_en && (wr_addr == 8'h08)) begin
            threshold_code_reg[7:0] <= wr_data[7:0];
        end
        if (wr_en && (wr_addr == 8'h09)) begin
            threshold_code_reg[11:8] <= wr_data[3:0];
        end
        if (wr_en && (wr_addr == 8'h18)) begin
            if (wr_data[0]) begin
                irq_status_alert <= 1'b0;
                status_alert_pending <= 1'b0;
                alert_status <= 1'b0;
            end
            if (wr_data[1]) begin
                irq_status_sample_done <= 1'b0;
                status_sample_done <= 1'b0;
            end
        end
        if (clear_alert_pulse) begin
            status_alert_pending <= 1'b0;
            irq_status_alert <= 1'b0;
            alert_status <= 1'b0;
        end
        if (sample_req_pulse) begin
            sample_req_pending <= 1'b1;
            status_busy <= 1'b1;
        end
        if (sample_complete) begin
            prev_adc_code <= adc_code;
            status_adc_valid_seen <= 1'b1;
            sample_count <= sample_count + 16'd1;
            status_sample_done <= 1'b1;
            irq_status_sample_done <= 1'b1;
            status_busy <= 1'b0;
            sample_req_pending <= 1'b0;
            latest_temp <= adc_avg;
            temp_code <= adc_avg;
            if (adc_avg > threshold_code_reg) begin
                status_alert_pending <= 1'b1;
                irq_status_alert <= 1'b1;
                alert_status <= 1'b1;
            end
        end
        if (clear_sample_done_pulse) begin
            status_sample_done <= 1'b0;
            irq_status_sample_done <= 1'b0;
        end
        if (!control_reg[0] && !sample_req_pending && !adc_valid) begin
            status_busy <= 1'b0;
        end
    end
end

always @(*) begin
    if (rd_en) begin
        case (rd_addr)
            8'h00: rd_data = {12'h000, control_reg};
            8'h04: rd_data = {12'h000, status_busy, status_adc_valid_seen, status_alert_pending, status_sample_done};
            8'h08: rd_data = {4'h0, threshold_code_reg};
            8'h09: rd_data = {12'h000, threshold_code_reg[11:8]};
            8'h0C: rd_data = {4'h0, latest_temp};
            8'h0D: rd_data = {12'h000, latest_temp[11:8]};
            8'h10: rd_data = sample_count;
            8'h11: rd_data = sample_count;
            8'h14: rd_data = {14'h0000, irq_status_sample_done, irq_status_alert};
            8'h15: rd_data = 16'h0000;
            8'h18: rd_data = 16'h0000;
            8'h19: rd_data = 16'h0000;
            default: rd_data = 16'h0000;
        endcase
    end
end

endmodule
