module temp_sensor_adc_model (
    input  sample_req,
    input  [15:0] sensor_temp_celsius,
    input  avdd,
    input  avss,
    output reg [11:0] adc_code,
    output reg adc_valid
);

    localparam integer NOMINAL_SAMPLE_LATENCY = 2;
    localparam integer GAIN_ERROR_PPM = 0;
    localparam integer OFFSET_ERROR_LSB = 0;
    localparam integer TEMP_SCALE = 1;
    localparam integer TEMP_BIAS = 0;
    localparam integer CODE_MIN = 0;
    localparam integer CODE_MAX = 4095;
    localparam integer BASE_NUM = 0;
    localparam integer BASE_DEN = 1;

    reg conversion_pending;
    reg [31:0] conversion_timer;
    reg [11:0] last_conversion_code;

    reg [31:0] temp_u32;
    reg [31:0] temp_scaled_u32;
    reg signed [63:0] temp_signed_ext;
    reg signed [63:0] gain_factor;
    reg signed [63:0] code_calc;
    reg [11:0] code_clamped;

    always @(*) begin
        temp_u32 = {16'b0, sensor_temp_celsius};
        temp_scaled_u32 = temp_u32 * TEMP_SCALE;
        temp_signed_ext = $signed({1'b0, temp_scaled_u32}) - TEMP_BIAS;
        gain_factor = 1000000 + GAIN_ERROR_PPM;
        code_calc = ((temp_signed_ext * gain_factor) / 1000000) + OFFSET_ERROR_LSB;
        if (code_calc < CODE_MIN)
            code_clamped = 12'd0;
        else if (code_calc > CODE_MAX)
            code_clamped = 12'd4095;
        else
            code_clamped = code_calc[11:0];
    end

    always @(posedge sample_req or posedge avdd or posedge avss) begin
        if (avdd !== 1'b1 || avss !== 1'b0) begin
            adc_code <= 12'd0;
            adc_valid <= 1'b0;
            conversion_pending <= 1'b0;
            conversion_timer <= 32'd0;
            last_conversion_code <= 12'd0;
        end else begin
            adc_valid <= 1'b0;
            if (sample_req === 1'b1) begin
                last_conversion_code <= code_clamped;
                conversion_pending <= 1'b1;
                conversion_timer <= NOMINAL_SAMPLE_LATENCY[31:0];
                if (NOMINAL_SAMPLE_LATENCY == 0) begin
                    adc_code <= code_clamped;
                    adc_valid <= 1'b1;
                    conversion_pending <= 1'b0;
                    conversion_timer <= 32'd0;
                end
            end
        end
    end

    always @(posedge conversion_pending or posedge sample_req) begin
        if (sample_req === 1'b1 && NOMINAL_SAMPLE_LATENCY == 0) begin
            adc_code <= code_clamped;
            adc_valid <= 1'b1;
            conversion_pending <= 1'b0;
            conversion_timer <= 32'd0;
        end
    end

    initial begin
        adc_code <= 12'd0;
        adc_valid <= 1'b0;
        conversion_pending <= 1'b0;
        conversion_timer <= 32'd0;
        last_conversion_code <= 12'd0;
    end

endmodule
