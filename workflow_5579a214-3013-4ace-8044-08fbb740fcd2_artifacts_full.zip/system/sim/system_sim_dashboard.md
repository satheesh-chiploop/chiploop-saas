# System Simulation Summary + Coverage

- Top module: temp_monitor_soc_sim
- Status: passed
- Total simulation runs: 6
- Simulation pass count: 6
- Simulation fail count: 0
- Total runtime (s): 16.626
- Coverage status: ok
- Functional coverage %: 17.86
- Coverage bins hit: 15
- Coverage total bins: 84
- Code line coverage %: 46.46
- Code branch coverage %: 20.74
- Code condition coverage %: 20.74
- Code toggle coverage %: 29.05
- Assertions total: 0
- Assertion failures: 0
- Formal status: fail
- Golden model status: pass

## Waveforms
- `vv/tb/dump.vcd`
