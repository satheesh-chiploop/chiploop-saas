# System Simulation Execution Report

- Top: `temp_monitor_soc_sim`
- Tests run: 6
- Passed: 6
- Failed: 0
- Total runtime (s): 16.626
- Coverage JSON present: True
- Coverage MD present: True

## Run Matrix
- `system_smoke_test` / seed `1` → PASS (rc=0, 5.152s)
- `system_smoke_test` / seed `2` → PASS (rc=0, 2.352s)
- `system_smoke_test` / seed `7` → PASS (rc=0, 2.235s)
- `integrated_input_sanity` / seed `1` → PASS (rc=0, 2.245s)
- `integrated_input_sanity` / seed `2` → PASS (rc=0, 2.298s)
- `integrated_input_sanity` / seed `7` → PASS (rc=0, 2.344s)

## Waveforms
- `vv/tb/dump.vcd`
