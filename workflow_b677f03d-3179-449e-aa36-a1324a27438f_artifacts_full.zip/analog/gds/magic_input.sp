.lib "$PDK_ROOT/sky130A/libs.tech/ngspice/sky130.lib.spice" tt

.subckt temp_sensor_adc_model VGND VPWR adc_code adc_code[0] adc_code[10] adc_code[11] adc_code[1] adc_code[2] adc_code[3] adc_code[4] adc_code[5] adc_code[6] adc_code[7] adc_code[8] adc_code[9] adc_valid avdd avss sample_req sensor_temp_celsius sensor_temp_celsius[0] sensor_temp_celsius[10] sensor_temp_celsius[11] sensor_temp_celsius[12] sensor_temp_celsius[13] sensor_temp_celsius[14] sensor_temp_celsius[15] sensor_temp_celsius[1] sensor_temp_celsius[2] sensor_temp_celsius[3] sensor_temp_celsius[4] sensor_temp_celsius[5] sensor_temp_celsius[6] sensor_temp_celsius[7] sensor_temp_celsius[8] sensor_temp_celsius[9]

M1 n_valid_pre sample_req avdd avdd sky130_fd_pr__pfet_01v8 W=1.2 L=0.15
M2 n_valid_pre sample_req avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M3 adc_valid n_valid_pre avdd avdd sky130_fd_pr__pfet_01v8 W=1.2 L=0.15
M4 adc_valid n_valid_pre avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15

M5 n_code_src sensor_temp_celsius[15] avdd avdd sky130_fd_pr__pfet_01v8 W=1.2 L=0.15
M6 n_code_src sensor_temp_celsius[15] avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M7 adc_code[11] n_code_src avdd avdd sky130_fd_pr__pfet_01v8 W=1.2 L=0.15
M8 adc_code[11] n_code_src avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15

M9 n_c10 sensor_temp_celsius[14] avdd avdd sky130_fd_pr__pfet_01v8 W=1 L=0.15
M10 n_c10 sensor_temp_celsius[14] avss avss sky130_fd_pr__nfet_01v8 W=0.72 L=0.15
M11 adc_code[10] n_c10 avdd avdd sky130_fd_pr__pfet_01v8 W=1 L=0.15
M12 adc_code[10] n_c10 avss avss sky130_fd_pr__nfet_01v8 W=0.72 L=0.15

M13 n_c9 sensor_temp_celsius[13] avdd avdd sky130_fd_pr__pfet_01v8 W=1 L=0.15
M14 n_c9 sensor_temp_celsius[13] avss avss sky130_fd_pr__nfet_01v8 W=0.72 L=0.15
M15 adc_code[9] n_c9 avdd avdd sky130_fd_pr__pfet_01v8 W=1 L=0.15
M16 adc_code[9] n_c9 avss avss sky130_fd_pr__nfet_01v8 W=0.72 L=0.15

M17 n_c8 sensor_temp_celsius[12] avdd avdd sky130_fd_pr__pfet_01v8 W=1 L=0.15
M18 n_c8 sensor_temp_celsius[12] avss avss sky130_fd_pr__nfet_01v8 W=0.72 L=0.15
M19 adc_code[8] n_c8 avdd avdd sky130_fd_pr__pfet_01v8 W=1 L=0.15
M20 adc_code[8] n_c8 avss avss sky130_fd_pr__nfet_01v8 W=0.72 L=0.15

M21 n_c7 sensor_temp_celsius[11] avdd avdd sky130_fd_pr__pfet_01v8 W=1 L=0.15
M22 n_c7 sensor_temp_celsius[11] avss avss sky130_fd_pr__nfet_01v8 W=0.72 L=0.15
M23 adc_code[7] n_c7 avdd avdd sky130_fd_pr__pfet_01v8 W=1 L=0.15
M24 adc_code[7] n_c7 avss avss sky130_fd_pr__nfet_01v8 W=0.72 L=0.15

M25 n_c6 sensor_temp_celsius[10] avdd avdd sky130_fd_pr__pfet_01v8 W=1 L=0.15
M26 n_c6 sensor_temp_celsius[10] avss avss sky130_fd_pr__nfet_01v8 W=0.72 L=0.15
M27 adc_code[6] n_c6 avdd avdd sky130_fd_pr__pfet_01v8 W=1 L=0.15
M28 adc_code[6] n_c6 avss avss sky130_fd_pr__nfet_01v8 W=0.72 L=0.15

M29 n_c5 sensor_temp_celsius[9] avdd avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M30 n_c5 sensor_temp_celsius[9] avss avss sky130_fd_pr__nfet_01v8 W=0.6 L=0.15
M31 adc_code[5] n_c5 avdd avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M32 adc_code[5] n_c5 avss avss sky130_fd_pr__nfet_01v8 W=0.6 L=0.15

M33 n_c4 sensor_temp_celsius[8] avdd avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M34 n_c4 sensor_temp_celsius[8] avss avss sky130_fd_pr__nfet_01v8 W=0.6 L=0.15
M35 adc_code[4] n_c4 avdd avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M36 adc_code[4] n_c4 avss avss sky130_fd_pr__nfet_01v8 W=0.6 L=0.15

M37 n_c3 sensor_temp_celsius[7] avdd avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M38 n_c3 sensor_temp_celsius[7] avss avss sky130_fd_pr__nfet_01v8 W=0.6 L=0.15
M39 adc_code[3] n_c3 avdd avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M40 adc_code[3] n_c3 avss avss sky130_fd_pr__nfet_01v8 W=0.6 L=0.15

M41 n_c2 sensor_temp_celsius[6] avdd avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M42 n_c2 sensor_temp_celsius[6] avss avss sky130_fd_pr__nfet_01v8 W=0.6 L=0.15
M43 adc_code[2] n_c2 avdd avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M44 adc_code[2] n_c2 avss avss sky130_fd_pr__nfet_01v8 W=0.6 L=0.15

M45 n_c1 sensor_temp_celsius[5] avdd avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M46 n_c1 sensor_temp_celsius[5] avss avss sky130_fd_pr__nfet_01v8 W=0.6 L=0.15
M47 adc_code[1] n_c1 avdd avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M48 adc_code[1] n_c1 avss avss sky130_fd_pr__nfet_01v8 W=0.6 L=0.15

M49 n_c0 sensor_temp_celsius[4] avdd avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M50 n_c0 sensor_temp_celsius[4] avss avss sky130_fd_pr__nfet_01v8 W=0.6 L=0.15
M51 adc_code[0] n_c0 avdd avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M52 adc_code[0] n_c0 avss avss sky130_fd_pr__nfet_01v8 W=0.6 L=0.15

M53 tie_hi avdd avdd avdd sky130_fd_pr__pfet_01v8 W=1.2 L=0.15
M54 tie_lo avss avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15

M55 sensor_temp_celsius[3] sensor_temp_celsius[2] avdd avdd sky130_fd_pr__pfet_01v8 W=0.42 L=0.15
M56 sensor_temp_celsius[2] sensor_temp_celsius[1] avss avss sky130_fd_pr__nfet_01v8 W=0.42 L=0.15
M57 sensor_temp_celsius[1] sensor_temp_celsius[0] avdd avdd sky130_fd_pr__pfet_01v8 W=0.42 L=0.15
M58 sensor_temp_celsius[0] sample_req avss avss sky130_fd_pr__nfet_01v8 W=0.42 L=0.15

M59 adc_code avdd avdd avdd sky130_fd_pr__pfet_01v8 W=1.2 L=0.15
M60 adc_code avss avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15

.ends temp_sensor_adc_model
.end
