# Digital Synthesis Summary

- **Workflow**: b677f03d-3179-449e-aa36-a1324a27438f
- **Status**: `ok` (rc=0)
- **Top module**: `temp_monitor_soc_phys`
- **Clock**: `clk` @ **10.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/b677f03d-3179-449e-aa36-a1324a27438f/1d535e58-f58e-47b9-bfa3-2bb6daa8f93e/digital/digital/synth/runs/System_PD_b677f03d-3179-449e-aa36-a1324a27438f/final/metrics.json`
- netlist candidates: 1 found
