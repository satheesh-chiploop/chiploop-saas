/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/b677f03d-3179-449e-aa36-a1324a27438f/1d535e58-f58e-47b9-bfa3-2bb6daa8f93e/digital/system/imported_rtl/temp_sensor_adc_model.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/b677f03d-3179-449e-aa36-a1324a27438f/1d535e58-f58e-47b9-bfa3-2bb6daa8f93e/digital/system/imported_rtl/temp_monitor_digital.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/b677f03d-3179-449e-aa36-a1324a27438f/1d535e58-f58e-47b9-bfa3-2bb6daa8f93e/digital/system/imported_rtl/temp_monitor_soc_phys.sv
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/b677f03d-3179-449e-aa36-a1324a27438f/1d535e58-f58e-47b9-bfa3-2bb6daa8f93e/digital/system/imported_rtl/temp_monitor_soc_sim.sv
