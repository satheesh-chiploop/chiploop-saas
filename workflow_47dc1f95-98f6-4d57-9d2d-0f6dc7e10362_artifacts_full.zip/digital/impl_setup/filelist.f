/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/47dc1f95-98f6-4d57-9d2d-0f6dc7e10362/5536e1a7-1ed3-42cf-a661-8c77a5430717/digital/system/imported_rtl/temp_sensor_adc_model.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/47dc1f95-98f6-4d57-9d2d-0f6dc7e10362/5536e1a7-1ed3-42cf-a661-8c77a5430717/digital/system/imported_rtl/temp_monitor_digital.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/47dc1f95-98f6-4d57-9d2d-0f6dc7e10362/5536e1a7-1ed3-42cf-a661-8c77a5430717/digital/system/imported_rtl/temp_monitor_registers.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/47dc1f95-98f6-4d57-9d2d-0f6dc7e10362/5536e1a7-1ed3-42cf-a661-8c77a5430717/digital/system/imported_rtl/temp_monitor_sample_ctrl.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/47dc1f95-98f6-4d57-9d2d-0f6dc7e10362/5536e1a7-1ed3-42cf-a661-8c77a5430717/digital/system/imported_rtl/temp_monitor_soc_phys.sv
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/47dc1f95-98f6-4d57-9d2d-0f6dc7e10362/5536e1a7-1ed3-42cf-a661-8c77a5430717/digital/system/imported_rtl/temp_monitor_soc_sim.sv
