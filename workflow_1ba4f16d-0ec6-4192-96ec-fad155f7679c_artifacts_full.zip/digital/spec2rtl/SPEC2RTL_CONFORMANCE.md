# Spec-to-RTL Conformance Report

Status: **partial**

- Requirements checked: 41
- Matched: 37
- Partial: 1
- Missing: 2
- Inconclusive: 1
- Interface: pass
- Register map: pass
- Clock/reset: pass

## Missing Or Partial Requirements
- REQ-007 [missing]: Latch STATUS.sample_done and IRQ_STATUS.sample_done on every completed sample.
- REQ-027 [missing]: If the first sample arrives before a history value exists, the filter may initialize from the first observed sample code in a deterministic manner.
- REQ-028 [partial]: A periodic sample request may be generated while ENABLE is set using a simple internal periodic mechanism; explicit SAMPLE_START has priority for immediate request generation.
