# System RTL Evidence Dashboard

## System
- Top module: temp_monitor_soc_sim
- RTL files: 4
- Modules: 4
- Input bits: 84
- Output bits: 43
- Flip-flops: 173
- Latches: 0
- Full-cycle paths: 3
- Half-cycle paths: 1

## Soc
- Top module: temp_monitor_soc_sim
- RTL files: 0
- Modules: 0
- Input bits: 0
- Output bits: 0
- Flip-flops: 0
- Latches: 0
- Full-cycle paths: 2
- Half-cycle paths: 0

## Digital
- Top module: temp_monitor_digital
- RTL files: 3
- Modules: 3
- Input bits: 49
- Output bits: 43
- Flip-flops: 110
- Latches: 0
- Full-cycle paths: 3
- Half-cycle paths: 1

## Analog
- Top module: temp_sensor_adc_model
- RTL files: 1
- Modules: 1
- Input bits: 19
- Output bits: 13
- Flip-flops: 63
- Latches: 0
- Full-cycle paths: 3
- Half-cycle paths: 0
