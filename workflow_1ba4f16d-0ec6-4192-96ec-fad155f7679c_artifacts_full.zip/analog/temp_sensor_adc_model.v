module temp_sensor_adc_model (
    input               sample_req,
    input      [15:0]   sensor_temp_celsius,
    input               avdd,
    input               avss,
    output reg [11:0]   adc_code,
    output reg          adc_valid
);

    parameter integer GAIN_ERROR_PPM  = 0;
    parameter integer OFFSET_ERROR_LSB = 0;
    parameter integer SAMPLE_LATENCY   = 1;

    reg [15:0] prev_sample_req;
    reg [31:0] pending_cnt;
    reg        pending;
    reg signed [31:0] temp_signed_ext;
    reg signed [31:0] gain_error_ext;
    reg signed [31:0] offset_error_ext;
    reg signed [31:0] temp_term_ext;
    reg signed [31:0] gain_scale_ext;
    reg signed [31:0] corr_ext;
    reg signed [31:0] code_signed_ext;
    reg [11:0]        next_adc_code;

    always @(*) begin
        temp_signed_ext = $signed({{16{sensor_temp_celsius[15]}}, sensor_temp_celsius});
        gain_error_ext   = $signed(GAIN_ERROR_PPM);
        offset_error_ext  = $signed(OFFSET_ERROR_LSB);

        temp_term_ext    = temp_signed_ext <<< 4;
        gain_scale_ext   = temp_term_ext * (32'sd1000000 + gain_error_ext);
        corr_ext         = gain_scale_ext / 32'sd1000000;
        code_signed_ext  = corr_ext + offset_error_ext;

        if (code_signed_ext < 0)
            next_adc_code = 12'd0;
        else if (code_signed_ext > 32'sd4095)
            next_adc_code = 12'd4095;
        else
            next_adc_code = code_signed_ext[11:0];
    end

    always @(posedge sample_req or posedge avdd or posedge avss) begin
        if (avdd || avss) begin
            adc_code       <= 12'd0;
            adc_valid      <= 1'b0;
            prev_sample_req <= 16'd0;
            pending        <= 1'b0;
            pending_cnt    <= 32'd0;
        end else begin
            prev_sample_req <= {15'd0, sample_req};
            pending        <= 1'b1;
            if (SAMPLE_LATENCY <= 0)
                pending_cnt <= 32'd0;
            else
                pending_cnt <= SAMPLE_LATENCY[31:0];
            adc_code       <= next_adc_code;
            adc_valid      <= 1'b1;
        end
    end

    always @(*) begin
        if (pending)
            adc_valid = 1'b1;
        else
            adc_valid = 1'b0;
    end

endmodule
