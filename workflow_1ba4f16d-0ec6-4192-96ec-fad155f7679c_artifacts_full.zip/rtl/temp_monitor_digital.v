module temp_monitor_digital (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    adc_code,
    adc_valid,
    rd_data,
    sample_req,
    alert_irq,
    temp_code,
    threshold_code,
    alert_status
);

input clk;
input reset_n;
input wr_en;
input [7:0] wr_addr;
input [15:0] wr_data;
input rd_en;
input [7:0] rd_addr;
input [11:0] adc_code;
input adc_valid;

output [15:0] rd_data;
output sample_req;
output alert_irq;
output [11:0] temp_code;
output [11:0] threshold_code;
output alert_status;

reg [15:0] rd_data;
reg sample_req;
reg alert_irq;
reg [11:0] temp_code;
reg [11:0] threshold_code;
reg alert_status;

reg [7:0] control_reg;
reg [15:0] status_reg;
reg [15:0] sample_count;
reg [15:0] irq_status_reg;

reg [11:0] latest_temp;
reg [11:0] prev_sample;
reg prev_sample_valid;
reg pending_sample;
reg adc_valid_seen;

reg adc_valid_d;
wire adc_valid_rise;

assign adc_valid_rise = adc_valid & ~adc_valid_d;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        control_reg <= 8'h00;
        status_reg <= 16'h0000;
        sample_count <= 16'h0000;
        irq_status_reg <= 16'h0000;
        latest_temp <= 12'h000;
        prev_sample <= 12'h000;
        prev_sample_valid <= 1'b0;
        pending_sample <= 1'b0;
        adc_valid_seen <= 1'b0;
        adc_valid_d <= 1'b0;
        temp_code <= 12'h000;
        threshold_code <= 12'h000;
        alert_status <= 1'b0;
        sample_req <= 1'b0;
    end else begin
        adc_valid_d <= adc_valid;

        sample_req <= 1'b0;

        if (wr_en) begin
            case (wr_addr)
                8'h00: begin
                    control_reg[0] <= wr_data[0];
                    control_reg[2] <= wr_data[2];
                    if (wr_data[1]) begin
                        sample_req <= 1'b1;
                        pending_sample <= 1'b1;
                    end
                    if (wr_data[3]) begin
                        alert_status <= 1'b0;
                        status_reg[1] <= 1'b0;
                        irq_status_reg[0] <= 1'b0;
                    end
                end
                8'h08: begin
                    threshold_code <= wr_data[11:0];
                end
                8'h18: begin
                    if (wr_data[0]) begin
                        irq_status_reg[0] <= 1'b0;
                        alert_status <= 1'b0;
                        status_reg[1] <= 1'b0;
                    end
                    if (wr_data[1]) begin
                        irq_status_reg[1] <= 1'b0;
                        status_reg[0] <= 1'b0;
                    end
                end
                default: begin
                end
            endcase
        end

        if (control_reg[0] && !pending_sample && !adc_valid_rise) begin
            control_reg[7] <= control_reg[7];
        end

        if (control_reg[0]) begin
            if (!pending_sample && !adc_valid_rise) begin
                if (status_reg[3] == 1'b0) begin
                    if (sample_count[2:0] == 3'b111) begin
                        sample_req <= 1'b1;
                        pending_sample <= 1'b1;
                    end else begin
                        sample_count <= sample_count;
                    end
                end
            end
        end

        if (adc_valid_rise) begin
            latest_temp <= adc_code;
            if (prev_sample_valid) begin
                temp_code <= (adc_code + prev_sample) >> 1;
            end else begin
                temp_code <= adc_code;
            end
            prev_sample <= adc_code;
            prev_sample_valid <= 1'b1;
            pending_sample <= 1'b0;
            adc_valid_seen <= 1'b1;
            sample_count <= sample_count + 16'h0001;
            status_reg[0] <= 1'b1;
            status_reg[2] <= 1'b1;
            status_reg[3] <= 1'b0;
            irq_status_reg[1] <= 1'b1;
            if (temp_code > threshold_code || ((prev_sample_valid ? ((adc_code + prev_sample) >> 1) : adc_code) > threshold_code)) begin
                alert_status <= 1'b1;
                status_reg[1] <= 1'b1;
                irq_status_reg[0] <= 1'b1;
            end
        end

        if (control_reg[3]) begin
            alert_status <= 1'b0;
            status_reg[1] <= 1'b0;
            irq_status_reg[0] <= 1'b0;
        end

        status_reg[3] <= pending_sample;

        status_reg[0] <= status_reg[0];
        status_reg[1] <= status_reg[1];
        status_reg[2] <= adc_valid_seen;
        status_reg[3] <= pending_sample;

        if (control_reg[0] && !pending_sample && !adc_valid_seen) begin
            pending_sample <= 1'b1;
            sample_req <= 1'b1;
        end

        if (!control_reg[0]) begin
            pending_sample <= 1'b0;
        end
    end
end

always @(*) begin
    rd_data = 16'h0000;
    alert_irq = 1'b0;

    case (rd_addr)
        8'h00: rd_data = {12'h000, control_reg[3], control_reg[2], control_reg[1], control_reg[0]};
        8'h04: rd_data = {12'h000, status_reg[3], status_reg[2], status_reg[1], status_reg[0]};
        8'h08: rd_data = {4'h0, threshold_code};
        8'h0C: rd_data = {4'h0, latest_temp};
        8'h10: rd_data = sample_count;
        8'h14: rd_data = irq_status_reg;
        8'h18: rd_data = 16'h0000;
        default: rd_data = 16'h0000;
    endcase

    if (control_reg[2] && (irq_status_reg[0] | irq_status_reg[1])) begin
        alert_irq = 1'b1;
    end
end

endmodule
