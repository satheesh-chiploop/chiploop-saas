# Digital DQA Summary
- workflow_id: `d351f8ca-bde9-4bbe-a896-d21260c5112c`
- status: `pass`
- rtl files: `2`
- warning count: `0`

## Stage Status
- rtl_lint: `warn`
- cdc: `pass`
- reset_integrity: `pass`
- synthesis_readiness: `pass`
