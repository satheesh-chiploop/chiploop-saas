module adaptive_aero_control_top (
    clk,
    rst_n,
    cfg_valid,
    cfg_we,
    cfg_re,
    cfg_addr,
    cfg_wdata,
    cfg_ready,
    cfg_rdata,
    req_valid,
    req_ready,
    req_data,
    rsp_valid,
    rsp_ready,
    rsp_data,
    actuator_valid,
    actuator_enable,
    actuator_position,
    actuator_rate_limit,
    actuator_mode,
    fault_irq
);
    input clk;
    input rst_n;
    input cfg_valid;
    input cfg_we;
    input cfg_re;
    input [5:0] cfg_addr;
    input [31:0] cfg_wdata;
    output cfg_ready;
    output [31:0] cfg_rdata;
    output req_valid;
    input req_ready;
    output [127:0] req_data;
    input rsp_valid;
    output rsp_ready;
    input [127:0] rsp_data;
    output actuator_valid;
    output actuator_enable;
    output [15:0] actuator_position;
    output [15:0] actuator_rate_limit;
    output [3:0] actuator_mode;
    output fault_irq;

    reg cfg_ready_r;
    reg [31:0] cfg_rdata_r;
    reg req_valid_r;
    reg [127:0] req_data_r;
    reg rsp_ready_r;
    reg actuator_valid_r;
    reg actuator_enable_r;
    reg [15:0] actuator_position_r;
    reg [15:0] actuator_rate_limit_r;
    reg [3:0] actuator_mode_r;
    reg fault_irq_r;

    reg [31:0] ctrl_reg;
    reg [31:0] pkt_meta_reg;
    reg [31:0] env_cfg_reg;
    reg [31:0] act_min_reg;
    reg [31:0] act_max_reg;
    reg [31:0] cmd_target_reg;
    reg [31:0] fault_clr_reg;

    reg [15:0] last_accepted_sequence_reg;
    reg stale_reject_reg;
    reg timeout_fault_reg;
    reg envelope_fault_reg;
    reg clamp_applied_reg;
    reg response_valid_reg;
    reg request_pending_reg;
    reg busy_reg;
    reg fault_latched_reg;
    reg fallback_active_reg;

    reg [15:0] outstanding_sequence_reg;
    reg [7:0] outstanding_request_id_reg;
    reg [7:0] outstanding_age_reg;
    reg [15:0] timeout_counter_reg;
    reg outstanding_valid_reg;
    reg [7:0] sequence_counter_reg;

    reg [15:0] accepted_position_reg;
    reg [15:0] accepted_rate_reg;
    reg [3:0] accepted_mode_reg;

    reg [15:0] req_position_reg;
    reg [15:0] req_rate_reg;
    reg [3:0] req_mode_reg;
    reg [7:0] req_proto_reg;
    reg [7:0] req_request_id_reg;
    reg [15:0] req_sequence_reg;
    reg [15:0] req_age_reg;
    reg [7:0] req_velocity_reg;
    reg [15:0] req_geometry_reg;

    reg [31:0] read_data;

    wire arm_enable;
    wire req_fire;
    wire debug_envelope_bypass;
    wire rate_limit_en;
    wire clear_fault_ctrl;
    wire protocol_version_ok;
    wire [7:0] request_id_seed;
    wire [15:0] geometry_handle;
    wire [7:0] freshness_threshold;
    wire [15:0] timeout_threshold;
    wire [7:0] velocity_min;
    wire [7:0] actuator_min_position;
    wire [15:0] actuator_min_rate;
    wire [7:0] actuator_max_position;
    wire [15:0] actuator_max_rate;
    wire [7:0] target_position;
    wire [15:0] target_rate_limit;
    wire status_busy;
    wire status_request_pending;
    wire status_response_valid;
    wire status_stale_reject;
    wire status_timeout_fault;
    wire status_envelope_fault;
    wire status_clamp_applied;
    wire status_fallback_active;
    wire status_fault_latched;

    assign cfg_ready = cfg_ready_r;
    assign cfg_rdata = cfg_rdata_r;
    assign req_valid = req_valid_r;
    assign req_data = req_data_r;
    assign rsp_ready = rsp_ready_r;
    assign actuator_valid = actuator_valid_r;
    assign actuator_enable = actuator_enable_r;
    assign actuator_position = actuator_position_r;
    assign actuator_rate_limit = actuator_rate_limit_r;
    assign actuator_mode = actuator_mode_r;
    assign fault_irq = fault_irq_r;

    assign arm_enable = ctrl_reg[0];
    assign req_fire = ctrl_reg[1];
    assign debug_envelope_bypass = ctrl_reg[2];
    assign rate_limit_en = ctrl_reg[3];
    assign clear_fault_ctrl = ctrl_reg[4];
    assign protocol_version_ok = pkt_meta_reg[3:0];
    assign request_id_seed = pkt_meta_reg[15:8];
    assign geometry_handle = pkt_meta_reg[31:16];
    assign freshness_threshold = env_cfg_reg[7:0];
    assign timeout_threshold = env_cfg_reg[23:8];
    assign velocity_min = env_cfg_reg[31:24];
    assign actuator_min_position = act_min_reg[7:0];
    assign actuator_min_rate = act_min_reg[31:16];
    assign actuator_max_position = act_max_reg[15:8];
    assign actuator_max_rate = act_max_reg[31:16];
    assign target_position = cmd_target_reg[15:8];
    assign target_rate_limit = cmd_target_reg[31:16];

    assign status_busy = busy_reg;
    assign status_request_pending = request_pending_reg;
    assign status_response_valid = response_valid_reg;
    assign status_stale_reject = stale_reject_reg;
    assign status_timeout_fault = timeout_fault_reg;
    assign status_envelope_fault = envelope_fault_reg;
    assign status_clamp_applied = clamp_applied_reg;
    assign status_fallback_active = fallback_active_reg;
    assign status_fault_latched = fault_latched_reg;

    always @(*) begin
        read_data = 32'h00000000;
        case (cfg_addr)
            6'd0: read_data = ctrl_reg;
            6'd1: read_data = pkt_meta_reg;
            6'd2: read_data = env_cfg_reg;
            6'd3: read_data = act_min_reg;
            6'd4: read_data = act_max_reg;
            6'd5: read_data = cmd_target_reg;
            6'd6: begin
                read_data[0] = status_busy;
                read_data[1] = status_request_pending;
                read_data[2] = status_response_valid;
                read_data[3] = status_stale_reject;
                read_data[4] = status_timeout_fault;
                read_data[5] = status_envelope_fault;
                read_data[6] = status_clamp_applied;
                read_data[7] = status_fallback_active;
                read_data[23:8] = last_accepted_sequence_reg;
                read_data[24] = status_fault_latched;
                read_data[31:25] = 7'b0000000;
            end
            6'd7: read_data = fault_clr_reg;
            default: read_data = 32'h00000000;
        endcase
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            cfg_ready_r <= 1'b0;
            cfg_rdata_r <= 32'h00000000;
            req_valid_r <= 1'b0;
            req_data_r <= 128'h00000000000000000000000000000000;
            rsp_ready_r <= 1'b1;
            actuator_valid_r <= 1'b0;
            actuator_enable_r <= 1'b0;
            actuator_position_r <= 16'h0000;
            actuator_rate_limit_r <= 16'h0000;
            actuator_mode_r <= 4'h0;
            fault_irq_r <= 1'b0;

            ctrl_reg <= 32'h00000000;
            pkt_meta_reg <= 32'h00000001;
            env_cfg_reg <= 32'h00000000;
            act_min_reg <= 32'h00000000;
            act_max_reg <= 32'h0000ffff;
            cmd_target_reg <= 32'h00000000;
            fault_clr_reg <= 32'h00000000;

            last_accepted_sequence_reg <= 16'h0000;
            stale_reject_reg <= 1'b0;
            timeout_fault_reg <= 1'b0;
            envelope_fault_reg <= 1'b0;
            clamp_applied_reg <= 1'b0;
            response_valid_reg <= 1'b0;
            request_pending_reg <= 1'b0;
            busy_reg <= 1'b0;
            fault_latched_reg <= 1'b0;
            fallback_active_reg <= 1'b1;

            outstanding_sequence_reg <= 16'h0000;
            outstanding_request_id_reg <= 8'h00;
            outstanding_age_reg <= 8'h00;
            timeout_counter_reg <= 16'h0000;
            outstanding_valid_reg <= 1'b0;
            sequence_counter_reg <= 8'h00;

            accepted_position_reg <= 16'h0000;
            accepted_rate_reg <= 16'h0000;
            accepted_mode_reg <= 4'h0;
        end else begin
            cfg_ready_r <= 1'b1;
            cfg_rdata_r <= read_data;
            req_valid_r <= 1'b0;
            rsp_ready_r <= arm_enable & ~fault_latched_reg;
            response_valid_reg <= 1'b0;
            stale_reject_reg <= 1'b0;

            if (cfg_valid && cfg_we) begin
                case (cfg_addr)
                    6'd0: ctrl_reg <= {27'b000000000000000000000000000, cfg_wdata[4:0]};
                    6'd1: pkt_meta_reg <= {4'b0, cfg_wdata[31:16], cfg_wdata[15:8], 4'b0001};
                    6'd2: env_cfg_reg <= {cfg_wdata[31:24], cfg_wdata[23:8], cfg_wdata[7:0]};
                    6'd3: act_min_reg <= cfg_wdata;
                    6'd4: act_max_reg <= cfg_wdata;
                    6'd5: cmd_target_reg <= cfg_wdata;
                    6'd7: fault_clr_reg <= cfg_wdata;
                    default: begin end
                endcase
            end

            if (cfg_valid && cfg_we && cfg_addr == 6'd0 && cfg_wdata[4]) begin
                fault_latched_reg <= 1'b0;
                timeout_fault_reg <= 1'b0;
                envelope_fault_reg <= 1'b0;
                clamp_applied_reg <= 1'b0;
                fault_irq_r <= 1'b0;
            end

            if (cfg_valid && cfg_we && cfg_addr == 6'd7 && cfg_wdata[0]) begin
                fault_clr_reg[0] <= 1'b1;
                fault_latched_reg <= 1'b0;
                timeout_fault_reg <= 1'b0;
                envelope_fault_reg <= 1'b0;
                stale_reject_reg <= 1'b0;
                fault_irq_r <= 1'b0;
            end

            if (cfg_valid && cfg_we && cfg_addr == 6'd0 && cfg_wdata[1] && arm_enable && !fault_latched_reg && !outstanding_valid_reg) begin
                req_valid_r <= 1'b1;
                req_request_id_reg <= request_id_seed;
                req_sequence_reg <= {8'h00, sequence_counter_reg} + 16'h0001;
                req_age_reg <= 16'h0000;
                req_proto_reg <= protocol_version_ok;
                req_velocity_reg <= velocity_min;
                req_mode_reg <= cmd_target_reg[3:0];
                req_geometry_reg <= geometry_handle;
                req_position_reg <= target_position;
                req_rate_reg <= target_rate_limit;
                req_data_r <= {geometry_handle, velocity_min, cmd_target_reg[31:16], cmd_target_reg[15:0], request_id_seed, protocol_version_ok, sequence_counter_reg, 55'b0};
                if (req_ready) begin
                    outstanding_valid_reg <= 1'b1;
                    request_pending_reg <= 1'b1;
                    busy_reg <= 1'b1;
                    timeout_counter_reg <= 16'h0001;
                    outstanding_sequence_reg <= {8'h00, sequence_counter_reg} + 16'h0001;
                    outstanding_request_id_reg <= request_id_seed;
                    outstanding_age_reg <= 8'h00;
                    sequence_counter_reg <= sequence_counter_reg + 8'h01;
                end
            end

            if (outstanding_valid_reg) begin
                if (timeout_threshold != 16'h0000 && timeout_counter_reg >= timeout_threshold) begin
                    timeout_fault_reg <= 1'b1;
                    fault_latched_reg <= 1'b1;
                    fault_irq_r <= 1'b1;
                    outstanding_valid_reg <= 1'b0;
                    request_pending_reg <= 1'b0;
                    busy_reg <= 1'b0;
                    actuator_valid_r <= 1'b0;
                    fallback_active_reg <= 1'b1;
                end else begin
                    timeout_counter_reg <= timeout_counter_reg + 16'h0001;
                end
            end

            if (rsp_valid && rsp_ready_r) begin
                if (!outstanding_valid_reg) begin
                    fault_latched_reg <= 1'b1;
                    fault_irq_r <= 1'b1;
                    actuator_valid_r <= 1'b0;
                    fallback_active_reg <= 1'b1;
                end else if (rsp_data[7:0] != outstanding_request_id_reg || rsp_data[23:8] != outstanding_sequence_reg) begin
                    fault_latched_reg <= 1'b1;
                    fault_irq_r <= 1'b1;
                    actuator_valid_r <= 1'b0;
                    outstanding_valid_reg <= 1'b0;
                    request_pending_reg <= 1'b0;
                    busy_reg <= 1'b0;
                    fallback_active_reg <= 1'b1;
                end else begin
                    response_valid_reg <= 1'b1;
                    if ((rsp_data[31:24] < 8'd20 || rsp_data[31:24] > 8'd55) && !debug_envelope_bypass) begin
                        envelope_fault_reg <= 1'b1;
                        fault_latched_reg <= 1'b1;
                        fault_irq_r <= 1'b1;
                        actuator_valid_r <= 1'b0;
                        outstanding_valid_reg <= 1'b0;
                        request_pending_reg <= 1'b0;
                        busy_reg <= 1'b0;
                        fallback_active_reg <= 1'b1;
                    end else begin
                        accepted_position_reg <= rsp_data[47:32];
                        accepted_rate_reg <= rsp_data[63:48];
                        accepted_mode_reg <= rsp_data[67:64];
                        last_accepted_sequence_reg <= outstanding_sequence_reg;
                        clamp_applied_reg <= 1'b0;
                        if (rsp_data[47:32] < {8'h00, act_min_reg[7:0]}) begin
                            accepted_position_reg <= {8'h00, act_min_reg[7:0]};
                            clamp_applied_reg <= 1'b1;
                        end else if (rsp_data[47:32] > {8'h00, act_max_reg[15:8]}) begin
                            accepted_position_reg <= {8'h00, act_max_reg[15:8]};
                            clamp_applied_reg <= 1'b1;
                        end
                        if (rsp_data[63:48] < actuator_min_rate) begin
                            accepted_rate_reg <= actuator_min_rate;
                            clamp_applied_reg <= 1'b1;
                        end else if (rsp_data[63:48] > actuator_max_rate) begin
                            accepted_rate_reg <= actuator_max_rate;
                            clamp_applied_reg <= 1'b1;
                        end
                        if (rate_limit_en && accepted_rate_reg > actuator_rate_limit_r) begin
                            accepted_rate_reg <= actuator_rate_limit_r;
                            clamp_applied_reg <= 1'b1;
                        end
                        actuator_position_r <= accepted_position_reg;
                        actuator_rate_limit_r <= accepted_rate_reg;
                        actuator_mode_r <= accepted_mode_reg;
                        actuator_enable_r <= arm_enable;
                        actuator_valid_r <= 1'b1;
                        fault_latched_reg <= 1'b0;
                        timeout_fault_reg <= 1'b0;
                        envelope_fault_reg <= 1'b0;
                        outstanding_valid_reg <= 1'b0;
                        request_pending_reg <= 1'b0;
                        busy_reg <= 1'b0;
                        fallback_active_reg <= 1'b0;
                        fault_irq_r <= 1'b0;
                    end
                end
            end else begin
                if (cfg_valid && cfg_re) begin
                    cfg_rdata_r <= read_data;
                end
            end

            if (fault_latched_reg) begin
                actuator_valid_r <= 1'b0;
                actuator_enable_r <= 1'b0;
                fallback_active_reg <= 1'b1;
            end

            if (!arm_enable) begin
                actuator_enable_r <= 1'b0;
                actuator_valid_r <= 1'b0;
                fallback_active_reg <= 1'b1;
            end
        end
    end
endmodule
