module temp_monitor_digital (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    adc_code,
    adc_valid,
    rd_data,
    sample_req,
    alert_irq,
    temp_code,
    threshold_code,
    alert_status
);

input clk;
input reset_n;
input wr_en;
input [7:0] wr_addr;
input [15:0] wr_data;
input rd_en;
input [7:0] rd_addr;
input [11:0] adc_code;
input adc_valid;
output [15:0] rd_data;
output sample_req;
output alert_irq;
output [11:0] temp_code;
output [11:0] threshold_code;
output alert_status;

reg [15:0] rd_data_r;
reg sample_req_r;
reg alert_irq_r;
reg [11:0] temp_code_r;
reg [11:0] threshold_code_r;
reg alert_status_r;

reg enable_reg;
reg irq_enable_reg;
reg [15:0] sample_count;
reg status_sample_done;
reg status_alert_pending;
reg status_adc_valid_seen;
reg status_busy;
reg irq_status_alert;
reg irq_status_sample_done;
reg [11:0] latest_temp;
reg request_pending;
reg [11:0] adc_prev;
reg adc_prev_valid;

reg [15:0] control_reg_rd;
reg [15:0] status_reg_rd;
reg [15:0] threshold_reg_rd;
reg [15:0] latest_temp_reg_rd;
reg [15:0] sample_count_reg_rd;
reg [15:0] irq_status_reg_rd;

assign rd_data = rd_data_r;
assign sample_req = sample_req_r;
assign alert_irq = alert_irq_r;
assign temp_code = temp_code_r;
assign threshold_code = threshold_code_r;
assign alert_status = alert_status_r;

always @(*) begin
    control_reg_rd = 16'h0000;
    status_reg_rd = 16'h0000;
    threshold_reg_rd = 16'h0000;
    latest_temp_reg_rd = 16'h0000;
    sample_count_reg_rd = 16'h0000;
    irq_status_reg_rd = 16'h0000;
    control_reg_rd[0] = enable_reg;
    control_reg_rd[2] = irq_enable_reg;
    status_reg_rd[0] = status_sample_done;
    status_reg_rd[1] = status_alert_pending;
    status_reg_rd[2] = status_adc_valid_seen;
    status_reg_rd[3] = status_busy;
    threshold_reg_rd[11:0] = threshold_code_r;
    latest_temp_reg_rd[11:0] = temp_code_r;
    sample_count_reg_rd = sample_count;
    irq_status_reg_rd[0] = irq_status_alert;
    irq_status_reg_rd[1] = irq_status_sample_done;
end

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        rd_data_r <= 16'h0000;
        sample_req_r <= 1'b0;
        alert_irq_r <= 1'b0;
        temp_code_r <= 12'h000;
        threshold_code_r <= 12'h000;
        alert_status_r <= 1'b0;
        enable_reg <= 1'b0;
        irq_enable_reg <= 1'b0;
        sample_count <= 16'h0000;
        status_sample_done <= 1'b0;
        status_alert_pending <= 1'b0;
        status_adc_valid_seen <= 1'b0;
        status_busy <= 1'b0;
        irq_status_alert <= 1'b0;
        irq_status_sample_done <= 1'b0;
        latest_temp <= 12'h000;
        request_pending <= 1'b0;
        adc_prev <= 12'h000;
        adc_prev_valid <= 1'b0;
    end else begin
        sample_req_r <= 1'b0;

        if (wr_en && (wr_addr == 8'h00)) begin
            enable_reg <= wr_data[0];
            irq_enable_reg <= wr_data[2];
            if (wr_data[1]) begin
                sample_req_r <= 1'b1;
                request_pending <= 1'b1;
            end
            if (wr_data[3]) begin
                alert_status_r <= 1'b0;
                status_alert_pending <= 1'b0;
                irq_status_alert <= 1'b0;
            end
        end

        if (wr_en && (wr_addr == 8'h08)) begin
            threshold_code_r <= wr_data[11:0];
        end

        if (wr_en && (wr_addr == 8'h18)) begin
            if (wr_data[0]) begin
                alert_status_r <= 1'b0;
                status_alert_pending <= 1'b0;
                irq_status_alert <= 1'b0;
            end
            if (wr_data[1]) begin
                irq_status_sample_done <= 1'b0;
                status_sample_done <= 1'b0;
            end
        end

        if (enable_reg && !request_pending) begin
            sample_req_r <= 1'b1;
            request_pending <= 1'b1;
        end

        if (adc_valid) begin
            if (adc_prev_valid) begin
                latest_temp <= ((adc_prev + adc_code) >> 1);
            end else begin
                latest_temp <= adc_code;
            end
            adc_prev <= adc_code;
            adc_prev_valid <= 1'b1;
            temp_code_r <= latest_temp;
            sample_count <= sample_count + 16'h0001;
            status_sample_done <= 1'b1;
            status_adc_valid_seen <= 1'b1;
            irq_status_sample_done <= 1'b1;
            request_pending <= 1'b0;
            status_busy <= 1'b0;
            if (latest_temp > threshold_code_r) begin
                alert_status_r <= 1'b1;
                status_alert_pending <= 1'b1;
                irq_status_alert <= 1'b1;
            end
        end else begin
            if (request_pending) begin
                status_busy <= 1'b1;
            end else begin
                status_busy <= 1'b0;
            end
        end

        temp_code_r <= latest_temp;

        if (irq_enable_reg && (irq_status_alert || irq_status_sample_done)) begin
            alert_irq_r <= 1'b1;
        end else begin
            alert_irq_r <= 1'b0;
        end

        if (rd_en) begin
            case (rd_addr)
                8'h00: rd_data_r <= control_reg_rd;
                8'h04: rd_data_r <= status_reg_rd;
                8'h08: rd_data_r <= threshold_reg_rd;
                8'h0C: rd_data_r <= latest_temp_reg_rd;
                8'h10: rd_data_r <= sample_count_reg_rd;
                8'h14: rd_data_r <= irq_status_reg_rd;
                8'h18: rd_data_r <= 16'h0000;
                default: rd_data_r <= 16'h0000;
            endcase
        end else begin
            rd_data_r <= rd_data_r;
        end
    end
end

endmodule
