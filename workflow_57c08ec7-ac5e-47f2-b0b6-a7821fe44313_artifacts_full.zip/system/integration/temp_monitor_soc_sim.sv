module temp_monitor_soc_sim (
  output logic alert_irq,
  output logic alert_status,
  input  logic avdd,
  input  logic avss,
  input  logic clk,
  input  logic [7:0] rd_addr,
  output logic [15:0] rd_data,
  input  logic rd_en,
  input  logic reset_n,
  input  logic [15:0] sensor_temp_celsius,
  output logic [11:0] temp_code,
  output logic [11:0] threshold_code,
  input  logic [7:0] wr_addr,
  input  logic [15:0] wr_data,
  input  logic wr_en
);

  // Internal interconnect
  wire        sample_req;
  wire [11:0] adc_code;
  wire        adc_valid;

  temp_sensor_adc_model u_analog (
    .adc_code(adc_code),
    .adc_valid(adc_valid),
    .avdd(avdd),
    .avss(avss),
    .sample_req(sample_req),
    .sensor_temp_celsius(sensor_temp_celsius)
  );

  temp_monitor_digital u_digital (
    .adc_code(adc_code),
    .adc_valid(adc_valid),
    .alert_irq(alert_irq),
    .alert_status(alert_status),
    .clk(clk),
    .rd_addr(rd_addr),
    .rd_data(rd_data),
    .rd_en(rd_en),
    .reset_n(reset_n),
    .sample_req(sample_req),
    .temp_code(temp_code),
    .threshold_code(threshold_code),
    .wr_addr(wr_addr),
    .wr_data(wr_data),
    .wr_en(wr_en)
  );

endmodule