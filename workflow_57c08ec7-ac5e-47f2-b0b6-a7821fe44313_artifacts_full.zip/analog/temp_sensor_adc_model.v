module temp_sensor_adc_model (
    input        sample_req,
    input  [15:0] sensor_temp_celsius,
    input        avdd,
    input        avss,
    output reg [11:0] adc_code,
    output reg       adc_valid
);

    parameter integer GAIN_ERROR_PPM    = 0;
    parameter integer OFFSET_ERROR_CODE  = 0;
    parameter integer NOMINAL_LATENCY_CYC = 1;
    parameter integer TEMP_SCALE_CODE_PER_C = 16;
    parameter integer TEMP_ZERO_C = 0;

    reg        sample_req_d;
    reg        sample_event;
    reg [11:0] computed_code;
    reg [11:0] pending_code;
    reg [31:0] pending_count;
    reg        busy;

    reg signed [63:0] temp_ext_s;
    reg signed [63:0] temp_delta_s;
    reg signed [63:0] base_code_s;
    reg signed [63:0] gain_ppm_s;
    reg signed [63:0] scale_factor_s;
    reg signed [63:0] gain_code_s;
    reg signed [63:0] offset_code_s;
    reg signed [63:0] computed_code_s;
    reg signed [63:0] clamped_code_s;

    initial begin
        adc_code <= 12'd0;
        adc_valid <= 1'b0;
        sample_req_d <= 1'b0;
        sample_event = 1'b0;
        computed_code = 12'd0;
        pending_code <= 12'd0;
        pending_count <= 32'd0;
        busy <= 1'b0;
        temp_ext_s = 64'sd0;
        temp_delta_s = 64'sd0;
        base_code_s = 64'sd0;
        gain_ppm_s = 64'sd0;
        scale_factor_s = 64'sd0;
        gain_code_s = 64'sd0;
        offset_code_s = 64'sd0;
        computed_code_s = 64'sd0;
        clamped_code_s = 64'sd0;
    end

    always @(*) begin
        sample_event = sample_req & ~sample_req_d;

        temp_ext_s = $signed({16'd0, sensor_temp_celsius});
        temp_delta_s = temp_ext_s - $signed(TEMP_ZERO_C);
        base_code_s = temp_delta_s * $signed(TEMP_SCALE_CODE_PER_C);

        gain_ppm_s = $signed(GAIN_ERROR_PPM);
        scale_factor_s = 64'sd1000000 + gain_ppm_s;
        gain_code_s = (base_code_s * scale_factor_s) / 64'sd1000000;

        offset_code_s = $signed(OFFSET_ERROR_CODE);
        computed_code_s = gain_code_s + offset_code_s;

        clamped_code_s = computed_code_s;
        if (clamped_code_s < 64'sd0)
            clamped_code_s = 64'sd0;
        else if (clamped_code_s > 64'sd4095)
            clamped_code_s = 64'sd4095;

        computed_code = clamped_code_s[11:0];
    end

    always @(posedge sample_req) begin
        sample_req_d <= 1'b1;
    end

    always @(negedge sample_req) begin
        sample_req_d <= 1'b0;
    end

    always @(sample_req or sensor_temp_celsius or avdd or avss or sample_req_d or busy or pending_count or pending_code or computed_code) begin
        adc_valid = 1'b0;

        if (busy) begin
            if (pending_count == 32'd0) begin
                adc_code = pending_code;
                adc_valid = 1'b1;
            end else begin
                adc_code = adc_code;
            end
        end else begin
            adc_code = adc_code;
        end

        if (sample_event) begin
            if (NOMINAL_LATENCY_CYC <= 0) begin
                adc_code = computed_code;
                adc_valid = 1'b1;
            end
        end
    end

    always @(posedge sample_req) begin
        if (sample_event) begin
            if (NOMINAL_LATENCY_CYC <= 0) begin
                pending_code <= computed_code;
                pending_count <= 32'd0;
                busy <= 1'b0;
                adc_code <= computed_code;
                adc_valid <= 1'b1;
            end else begin
                pending_code <= computed_code;
                pending_count <= NOMINAL_LATENCY_CYC[31:0];
                busy <= 1'b1;
                adc_valid <= 1'b0;
            end
        end
    end

    always @(posedge avdd or posedge avss) begin
        adc_code <= adc_code;
        adc_valid <= adc_valid;
    end

endmodule
