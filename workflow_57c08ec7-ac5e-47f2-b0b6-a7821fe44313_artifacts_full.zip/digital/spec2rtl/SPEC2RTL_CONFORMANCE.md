# Spec-to-RTL Conformance Report

Status: **partial**

- Requirements checked: 36
- Matched: 35
- Partial: 0
- Missing: 1
- Inconclusive: 0
- Interface: pass
- Register map: issues
- Clock/reset: pass

## Missing Or Partial Requirements
- None reported.
