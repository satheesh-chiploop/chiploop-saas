module pwm_fpga_demo (
    input clk,
    output led
);

reg [7:0] pwm_counter;
reg [7:0] duty_cycle;
reg dir_up;
reg [15:0] slow_counter;

wire pwm_out;

assign pwm_out = (pwm_counter < duty_cycle);
assign led = pwm_out;

always @(posedge clk) begin
    pwm_counter <= pwm_counter + 8'd1;
end

always @(posedge clk) begin
    slow_counter <= slow_counter + 16'd1;
    if (slow_counter == 16'hFFFF) begin
        if (dir_up) begin
            if (duty_cycle == 8'hFF) begin
                dir_up <= 1'b0;
                duty_cycle <= 8'hFE;
            end else begin
                duty_cycle <= duty_cycle + 8'd1;
            end
        end else begin
            if (duty_cycle == 8'h00) begin
                dir_up <= 1'b1;
                duty_cycle <= 8'h01;
            end else begin
                duty_cycle <= duty_cycle - 8'd1;
            end
        end
    end
end

initial begin
    pwm_counter = 8'h00;
    duty_cycle = 8'h00;
    dir_up = 1'b1;
    slow_counter = 16'h0000;
end

endmodule
