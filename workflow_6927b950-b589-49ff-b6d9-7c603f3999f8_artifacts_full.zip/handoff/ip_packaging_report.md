# IP Packaging & Handoff Report

- Top: `pwm_fpga_demo`
- Package: `backend/workflows/6927b950-b589-49ff-b6d9-7c603f3999f8/handoff/pwm_fpga_demo_ip_package`
- Zip: `backend/workflows/6927b950-b589-49ff-b6d9-7c603f3999f8/handoff/pwm_fpga_demo_ip_package.zip`

## Bucket counts
- **rtl**: 1
- **spec**: 3
- **arch**: 1
- **microarch**: 1
- **regmap**: 2
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 7
