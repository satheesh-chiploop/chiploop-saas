# Digital DQA Summary
- workflow_id: `6927b950-b589-49ff-b6d9-7c603f3999f8`
- status: `failed`
- rtl files: `1`
- warning count: `0`

## Stage Status
- rtl_lint: `warn`
- cdc: `unavailable`
- reset_integrity: `unavailable`
- synthesis_readiness: `failed`

## Blocking Issues
- yosys_synthesis_errors
