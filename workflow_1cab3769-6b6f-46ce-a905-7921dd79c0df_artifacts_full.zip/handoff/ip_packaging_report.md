# IP Packaging & Handoff Report

- Top: `sram_mbist_demo_controller`
- Package: `backend/workflows/1cab3769-6b6f-46ce-a905-7921dd79c0df/handoff/sram_mbist_demo_controller_ip_package`
- Zip: `backend/workflows/1cab3769-6b6f-46ce-a905-7921dd79c0df/handoff/sram_mbist_demo_controller_ip_package.zip`

## Bucket counts
- **rtl**: 44
- **spec**: 3
- **arch**: 1
- **microarch**: 1
- **regmap**: 2
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 11
