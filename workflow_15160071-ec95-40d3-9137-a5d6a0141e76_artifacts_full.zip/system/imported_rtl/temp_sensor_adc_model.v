module temp_sensor_adc_model (
    input  sample_req,
    input  [15:0] sensor_temp_celsius,
    input  avdd,
    input  avss,
    output reg [11:0] adc_code,
    output reg adc_valid
);

    parameter integer NOMINAL_SAMPLE_LATENCY = 2;
    parameter integer TEMP_TO_CODE_GAIN = 16;
    parameter integer CODE_OFFSET = 0;
    parameter integer GAIN_ERROR_PPM = 0;
    parameter integer OFFSET_ERROR_LSB = 0;

    reg [31:0] conversion_timer;
    reg pending_conversion;
    reg sample_req_d;
    reg sample_event;

    reg [11:0] next_adc_code;
    reg next_adc_valid;

    reg signed [31:0] temp_signed;
    reg signed [63:0] scaled_gain;
    reg signed [63:0] scaled_code;
    reg signed [63:0] gain_factor;
    reg signed [63:0] nominal_code;
    reg signed [63:0] adjusted_code;
    reg signed [63:0] clamped_code;
    reg signed [63:0] gain_error_term;
    reg signed [63:0] temp_term;

    initial begin
        adc_code = 12'd0;
        adc_valid = 1'b0;
        conversion_timer <= 32'd0;
        pending_conversion <= 1'b0;
        sample_req_d <= 1'b0;
    end

    always @(*) begin
        temp_signed = $signed(sensor_temp_celsius);
        temp_term = $signed(TEMP_TO_CODE_GAIN) * $signed(temp_signed);
        nominal_code = temp_term + $signed(CODE_OFFSET);
        gain_error_term = ($signed(nominal_code) * $signed(GAIN_ERROR_PPM)) / 1000000;
        gain_factor = $signed(nominal_code) + gain_error_term;
        adjusted_code = gain_factor + $signed(OFFSET_ERROR_LSB);

        clamped_code = adjusted_code;
        if (adjusted_code < 0)
            clamped_code = 0;
        else if (adjusted_code > 4095)
            clamped_code = 4095;

        next_adc_code = clamped_code[11:0];
        next_adc_valid = 1'b0;
        if (pending_conversion && (conversion_timer == 0))
            next_adc_valid = 1'b1;
    end

    always @(posedge sample_req) begin
        sample_req_d <= 1'b1;
    end

    always @(negedge sample_req) begin
        sample_req_d <= 1'b0;
    end

    always @(posedge sample_req or posedge sample_req_d) begin
        if (sample_req) begin
            pending_conversion <= 1'b1;
            conversion_timer <= NOMINAL_SAMPLE_LATENCY[31:0];
        end
    end

    always @(posedge sample_req) begin
        if (!pending_conversion) begin
            pending_conversion <= 1'b1;
            conversion_timer <= NOMINAL_SAMPLE_LATENCY[31:0];
        end
    end

    always @(*) begin
        if (pending_conversion && (conversion_timer == 0)) begin
            adc_code = next_adc_code;
            adc_valid = 1'b1;
        end else begin
            adc_valid = 1'b0;
        end
    end

    always @(*) begin
        if (pending_conversion && (conversion_timer != 0)) begin
            adc_code = adc_code;
        end
    end

endmodule
