module temp_monitor_digital (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    adc_code,
    adc_valid,
    rd_data,
    sample_req,
    alert_irq,
    temp_code,
    threshold_code,
    alert_status
);
    input clk;
    input reset_n;
    input wr_en;
    input [7:0] wr_addr;
    input [15:0] wr_data;
    input rd_en;
    input [7:0] rd_addr;
    input [11:0] adc_code;
    input adc_valid;
    output [15:0] rd_data;
    output sample_req;
    output alert_irq;
    output [11:0] temp_code;
    output [11:0] threshold_code;
    output alert_status;

    reg [15:0] rd_data_r;
    reg sample_req_r;
    reg alert_irq_r;
    reg [11:0] temp_code_r;
    reg [11:0] threshold_code_r;
    reg alert_status_r;

    reg [15:0] control_reg;
    reg [11:0] threshold_reg;
    reg [11:0] latest_temp;
    reg [15:0] sample_count;
    reg irq_status_alert;
    reg irq_status_sample_done;
    reg status_sample_done;
    reg status_alert_pending;
    reg status_adc_valid_seen;
    reg status_busy;
    reg [11:0] adc_sample_prev;
    reg adc_sample_prev_valid;
    reg [12:0] avg_sum;
    reg [11:0] avg_temp;
    reg sample_req_periodic_pulse;
    reg sample_req_start_pulse;
    reg [15:0] read_mux;

    assign rd_data = rd_data_r;
    assign sample_req = sample_req_r;
    assign alert_irq = alert_irq_r;
    assign temp_code = temp_code_r;
    assign threshold_code = threshold_code_r;
    assign alert_status = alert_status_r;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            control_reg <= 16'h0000;
            threshold_reg <= 12'h000;
            latest_temp <= 12'h000;
            sample_count <= 16'h0000;
            irq_status_alert <= 1'b0;
            irq_status_sample_done <= 1'b0;
            status_sample_done <= 1'b0;
            status_alert_pending <= 1'b0;
            status_adc_valid_seen <= 1'b0;
            status_busy <= 1'b0;
            adc_sample_prev <= 12'h000;
            adc_sample_prev_valid <= 1'b0;
            avg_sum <= 13'h0000;
            avg_temp <= 12'h000;
            sample_req_periodic_pulse <= 1'b0;
            sample_req_start_pulse <= 1'b0;
            rd_data_r <= 16'h0000;
            sample_req_r <= 1'b0;
            alert_irq_r <= 1'b0;
            temp_code_r <= 12'h000;
            threshold_code_r <= 12'h000;
            alert_status_r <= 1'b0;
        end else begin
            sample_req_start_pulse <= 1'b0;
            sample_req_periodic_pulse <= 1'b0;

            if (wr_en) begin
                case (wr_addr)
                    8'h00: begin
                        control_reg[0] <= wr_data[0];
                        control_reg[2] <= wr_data[2];
                        if (wr_data[1]) begin
                            sample_req_start_pulse <= 1'b1;
                        end
                        if (wr_data[3]) begin
                            alert_status_r <= 1'b0;
                            status_alert_pending <= 1'b0;
                        end
                    end
                    8'h08: begin
                        threshold_reg <= wr_data[11:0];
                    end
                    8'h18: begin
                        if (wr_data[0]) begin
                            irq_status_alert <= 1'b0;
                            alert_status_r <= 1'b0;
                        end
                        if (wr_data[1]) begin
                            irq_status_sample_done <= 1'b0;
                            status_sample_done <= 1'b0;
                        end
                    end
                    default: begin
                    end
                endcase
            end

            if (adc_valid) begin
                avg_sum <= {1'b0, adc_sample_prev} + {1'b0, adc_code};
                avg_temp <= avg_sum[12:1];
                latest_temp <= avg_temp;
                temp_code_r <= avg_temp;
                adc_sample_prev <= adc_code;
                adc_sample_prev_valid <= 1'b1;
                sample_count <= sample_count + 16'd1;
                status_sample_done <= 1'b1;
                irq_status_sample_done <= 1'b1;
                status_adc_valid_seen <= 1'b1;
                if (avg_temp > threshold_reg) begin
                    alert_status_r <= 1'b1;
                    status_alert_pending <= 1'b1;
                    irq_status_alert <= 1'b1;
                end
            end

            if (control_reg[0] && !adc_valid && !sample_req_start_pulse) begin
                sample_req_periodic_pulse <= 1'b1;
            end

            if (sample_req_start_pulse || sample_req_periodic_pulse) begin
                status_busy <= 1'b1;
            end else if (adc_valid) begin
                status_busy <= 1'b0;
            end

            sample_req_r <= sample_req_start_pulse | sample_req_periodic_pulse;
            threshold_code_r <= threshold_reg;
            alert_irq_r <= control_reg[2] & (irq_status_alert | irq_status_sample_done);
        end
    end

    always @(*) begin
        read_mux = 16'h0000;
        case (rd_addr)
            8'h00: begin
                read_mux = {12'h000, control_reg[3:0] & 4'b0101};
            end
            8'h04: begin
                read_mux = {12'h000, status_busy, status_alert_pending, status_adc_valid_seen, status_sample_done};
            end
            8'h08: begin
                read_mux = {4'h0, threshold_reg};
            end
            8'h0C: begin
                read_mux = {4'h0, latest_temp};
            end
            8'h10: begin
                read_mux = sample_count;
            end
            8'h14: begin
                read_mux = {14'h0000, irq_status_sample_done, irq_status_alert};
            end
            8'h18: begin
                read_mux = 16'h0000;
            end
            default: begin
                read_mux = 16'h0000;
            end
        endcase

        if (rd_en) begin
        end else begin
        end
    end
endmodule
