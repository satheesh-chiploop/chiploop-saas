# Arch2RTL Evidence Dashboard

- Lint: warnings
- Flip-flops: 294
- Latches: 2
- Full-cycle paths: 3
- Half-cycle paths: 5
- Input bits: 214
- Output bits: 220
- Input ports: 10
- Output ports: 8
- Clock: clk
- Reset: clk_rst_n
- Modules: 7
- RTL files: 7
