# Spec-to-RTL Conformance Report

Status: **partial**

- Requirements checked: 84
- Matched: 50
- Partial: 0
- Missing: 34
- Inconclusive: 0
- Interface: pass
- Register map: issues
- Clock/reset: pass

## Missing Or Partial Requirements
- REQ-001 [missing]: Own the firmware-visible CSR/MMIO decode and register readback.
- REQ-003 [missing]: Emit request valid/data and receive request ready according to the mandatory transport direction contract.
- REQ-004 [missing]: Receive response valid/data and emit response ready according to the mandatory transport direction contract.
- REQ-006 [missing]: Latch invalid-format, stale-data, timeout, configuration, and host-interface faults until explicit software clear/ack.
- REQ-007 [missing]: Clamp commanded output to programmable min/max bounds and optional rate limits.
- REQ-009 [missing]: Maintain top-level scalar-equivalent I/O count below 256.
- REQ-010 [missing]: Avoid any tensor, per-cell, or geometry-array interface at the top level.
- REQ-011 [missing]: cfg_bus must be a real 64-bit wide MMIO window with address, write-data, read-data, valid, write-enable, ready, and read-valid semantics.
- REQ-012 [missing]: Register decode must implement all documented registers; no declared software-visible register may be unreachable.
- REQ-014 [missing]: Response frames are fixed-format 128-bit words and must be validated before any command update.
- REQ-017 [missing]: If response framing fails, assert invalid_format_fault and ignore the response.
- REQ-020 [missing]: HOLD_LAST_SAFE retains the last safe command value internally but must still deassert act_cmd_valid on unsafe conditions; it is not a substitute command path.
- REQ-021 [missing]: SAFE_FALLBACK indicates persistent faults or violated safety preconditions; act_cmd_valid is deasserted and no silent substitute command is emitted.
- REQ-022 [missing]: Actuator clamping must enforce programmable min/max and optional rate limit; under fault conditions the output envelope may only narrow, never widen.
- REQ-024 [missing]: Faults latch until a defined clear/ack write pattern is observed in the firmware-visible register map.
- REQ-025 [missing]: Recovery from SAFE_FALLBACK requires explicit clear and a valid rearm sequence from software.
- REQ-026 [missing]: Transparent reference mode routes control decisions from the CPU reference path using compact control fields; it does not instantiate or assume surrogate model numeric outputs.
- REQ-045 [missing]: Implement firmware-visible MMIO decode and readback.
- REQ-046 [missing]: Provide explicit semantic signals rather than raw transport bus reuse.
- REQ-047 [missing]: Enforce that all declared registers are reachable through RTL decode.
- REQ-048 [missing]: Expose the clear/ack pattern and arm key semantics to the supervisor.
- REQ-049 [missing]: Supply compact configuration words for request packing and safety supervision.
- REQ-051 [missing]: Read and write semantics must be deterministic and side-effect controlled.
- REQ-052 [missing]: Clear/ack write pattern must be explicit and not inferred from any fallback behavior.
- REQ-053 [missing]: The module must not expose any tensor, geometry array, or bulk payload field.
- REQ-054 [missing]: cfg_bus accesses are bounded to 64 bits per access.
- REQ-073 [missing]: Build the outbound request frame.
- REQ-074 [missing]: Apply the mandatory model-request transport direction contract.
- REQ-075 [missing]: Emit sequence issuance metadata to the supervisor.
- REQ-076 [missing]: Keep payload handling compact and non-tensor.
- REQ-077 [missing]: Request frame format must remain fixed and documented.
- REQ-078 [missing]: The packer must not assume any numeric surrogate output.
- REQ-080 [missing]: Request sequencing is monotonic under supervisor control.
