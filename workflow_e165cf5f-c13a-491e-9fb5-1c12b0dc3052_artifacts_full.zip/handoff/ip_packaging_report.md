# IP Packaging & Handoff Report

- Top: `adaptive_aero_control_top`
- Package: `backend/workflows/e165cf5f-c13a-491e-9fb5-1c12b0dc3052/handoff/adaptive_aero_control_top_ip_package`
- Zip: `backend/workflows/e165cf5f-c13a-491e-9fb5-1c12b0dc3052/handoff/adaptive_aero_control_top_ip_package.zip`

## Bucket counts
- **rtl**: 35
- **spec**: 8
- **arch**: 1
- **microarch**: 1
- **regmap**: 2
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 7
