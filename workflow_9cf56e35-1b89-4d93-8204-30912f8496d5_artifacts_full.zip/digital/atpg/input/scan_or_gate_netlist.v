module pwm_controller (clk,
    pwm_out,
    rd_en,
    reset_n,
    scan_en,
    wr_en,
    counter_value,
    rd_addr,
    rd_data,
    scan_in,
    scan_out,
    wr_addr,
    wr_data);
 input clk;
 output pwm_out;
 input rd_en;
 input reset_n;
 input scan_en;
 input wr_en;
 output [7:0] counter_value;
 input [7:0] rd_addr;
 output [7:0] rd_data;
 input [3:0] scan_in;
 output [3:0] scan_out;
 input [7:0] wr_addr;
 input [7:0] wr_data;

 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire _086_;
 wire _087_;
 wire _088_;
 wire _089_;
 wire _090_;
 wire _091_;
 wire _092_;
 wire _093_;
 wire _094_;
 wire _095_;
 wire _096_;
 wire _097_;
 wire _098_;
 wire _099_;
 wire _100_;
 wire _101_;
 wire _102_;
 wire _103_;
 wire _104_;
 wire _105_;
 wire _106_;
 wire _107_;
 wire _108_;
 wire _109_;
 wire _110_;
 wire _111_;
 wire _112_;
 wire _113_;
 wire _114_;
 wire _115_;
 wire _116_;
 wire _117_;
 wire _118_;
 wire _119_;
 wire _120_;
 wire _121_;
 wire \duty_cycle[0] ;
 wire \duty_cycle[1] ;
 wire \duty_cycle[2] ;
 wire \duty_cycle[3] ;
 wire \duty_cycle[4] ;
 wire \duty_cycle[5] ;
 wire \duty_cycle[6] ;
 wire \duty_cycle[7] ;
 wire enable;
 wire \period[0] ;
 wire \period[1] ;
 wire \period[2] ;
 wire \period[3] ;
 wire \period[4] ;
 wire \period[5] ;
 wire \period[6] ;
 wire \period[7] ;
 wire \u_register_map.control_reg[1] ;
 wire \u_register_map.control_reg[2] ;
 wire \u_register_map.control_reg[3] ;
 wire \u_register_map.control_reg[4] ;
 wire \u_register_map.control_reg[5] ;
 wire \u_register_map.control_reg[6] ;
 wire \u_register_map.control_reg[7] ;

 sky130_fd_sc_hd__inv_2 _122_ (.A(counter_value[3]),
    .Y(_041_));
 sky130_fd_sc_hd__inv_2 _123_ (.A(counter_value[2]),
    .Y(_042_));
 sky130_fd_sc_hd__inv_2 _124_ (.A(counter_value[5]),
    .Y(_043_));
 sky130_fd_sc_hd__inv_2 _125_ (.A(counter_value[4]),
    .Y(_044_));
 sky130_fd_sc_hd__inv_2 _126_ (.A(wr_addr[3]),
    .Y(_045_));
 sky130_fd_sc_hd__inv_2 _127_ (.A(counter_value[7]),
    .Y(_046_));
 sky130_fd_sc_hd__inv_2 _128_ (.A(\duty_cycle[7] ),
    .Y(_047_));
 sky130_fd_sc_hd__inv_2 _129_ (.A(\duty_cycle[6] ),
    .Y(_048_));
 sky130_fd_sc_hd__inv_2 _130_ (.A(counter_value[1]),
    .Y(_049_));
 sky130_fd_sc_hd__inv_2 _131_ (.A(counter_value[0]),
    .Y(_050_));
 sky130_fd_sc_hd__inv_2 _132_ (.A(rd_addr[2]),
    .Y(_051_));
 sky130_fd_sc_hd__o22a_2 _133_ (.A1(_044_),
    .A2(\period[4] ),
    .B1(\period[5] ),
    .B2(_043_),
    .X(_052_));
 sky130_fd_sc_hd__or2_2 _134_ (.A(_042_),
    .B(\period[2] ),
    .X(_053_));
 sky130_fd_sc_hd__o211a_2 _135_ (.A1(_049_),
    .A2(\period[1] ),
    .B1(\period[0] ),
    .C1(_050_),
    .X(_054_));
 sky130_fd_sc_hd__a22o_2 _136_ (.A1(_049_),
    .A2(\period[1] ),
    .B1(\period[2] ),
    .B2(_042_),
    .X(_055_));
 sky130_fd_sc_hd__o221a_2 _137_ (.A1(_041_),
    .A2(\period[3] ),
    .B1(_054_),
    .B2(_055_),
    .C1(_053_),
    .X(_056_));
 sky130_fd_sc_hd__a22o_2 _138_ (.A1(_041_),
    .A2(\period[3] ),
    .B1(\period[4] ),
    .B2(_044_),
    .X(_057_));
 sky130_fd_sc_hd__o21a_2 _139_ (.A1(_056_),
    .A2(_057_),
    .B1(_052_),
    .X(_058_));
 sky130_fd_sc_hd__and2_2 _140_ (.A(_046_),
    .B(\period[7] ),
    .X(_059_));
 sky130_fd_sc_hd__xor2_2 _141_ (.A(counter_value[6]),
    .B(\period[6] ),
    .X(_060_));
 sky130_fd_sc_hd__a211o_2 _142_ (.A1(_043_),
    .A2(\period[5] ),
    .B1(_059_),
    .C1(_060_),
    .X(_061_));
 sky130_fd_sc_hd__or3b_2 _143_ (.A(\period[6] ),
    .B(_059_),
    .C_N(counter_value[6]),
    .X(_062_));
 sky130_fd_sc_hd__or2_2 _144_ (.A(_046_),
    .B(\period[7] ),
    .X(_063_));
 sky130_fd_sc_hd__o211a_2 _145_ (.A1(_058_),
    .A2(_061_),
    .B1(_062_),
    .C1(_063_),
    .X(_064_));
 sky130_fd_sc_hd__or4_2 _146_ (.A(\period[0] ),
    .B(\period[1] ),
    .C(\period[2] ),
    .D(\period[3] ),
    .X(_065_));
 sky130_fd_sc_hd__or4_2 _147_ (.A(\period[4] ),
    .B(\period[5] ),
    .C(\period[6] ),
    .D(\period[7] ),
    .X(_066_));
 sky130_fd_sc_hd__o21a_2 _148_ (.A1(_065_),
    .A2(_066_),
    .B1(enable),
    .X(_067_));
 sky130_fd_sc_hd__and2_2 _149_ (.A(counter_value[1]),
    .B(counter_value[0]),
    .X(_068_));
 sky130_fd_sc_hd__nand2_2 _150_ (.A(counter_value[2]),
    .B(_068_),
    .Y(_069_));
 sky130_fd_sc_hd__or2_2 _151_ (.A(counter_value[2]),
    .B(_068_),
    .X(_070_));
 sky130_fd_sc_hd__and4_2 _152_ (.A(_064_),
    .B(_067_),
    .C(_069_),
    .D(_070_),
    .X(_002_));
 sky130_fd_sc_hd__and3_2 _153_ (.A(counter_value[3]),
    .B(counter_value[2]),
    .C(_068_),
    .X(_071_));
 sky130_fd_sc_hd__a31o_2 _154_ (.A1(counter_value[2]),
    .A2(counter_value[1]),
    .A3(counter_value[0]),
    .B1(counter_value[3]),
    .X(_072_));
 sky130_fd_sc_hd__and4b_2 _155_ (.A_N(_071_),
    .B(_072_),
    .C(_064_),
    .D(_067_),
    .X(_003_));
 sky130_fd_sc_hd__nand2_2 _156_ (.A(counter_value[4]),
    .B(_071_),
    .Y(_073_));
 sky130_fd_sc_hd__o21a_2 _157_ (.A1(counter_value[4]),
    .A2(_071_),
    .B1(_067_),
    .X(_074_));
 sky130_fd_sc_hd__and3_2 _158_ (.A(_064_),
    .B(_073_),
    .C(_074_),
    .X(_004_));
 sky130_fd_sc_hd__and3_2 _159_ (.A(counter_value[5]),
    .B(counter_value[4]),
    .C(_071_),
    .X(_075_));
 sky130_fd_sc_hd__nand2_2 _160_ (.A(_043_),
    .B(_073_),
    .Y(_076_));
 sky130_fd_sc_hd__and4b_2 _161_ (.A_N(_075_),
    .B(_076_),
    .C(_064_),
    .D(_067_),
    .X(_005_));
 sky130_fd_sc_hd__nand2_2 _162_ (.A(counter_value[6]),
    .B(_075_),
    .Y(_077_));
 sky130_fd_sc_hd__o2111a_2 _163_ (.A1(counter_value[6]),
    .A2(_075_),
    .B1(_077_),
    .C1(_064_),
    .D1(_067_),
    .X(_006_));
 sky130_fd_sc_hd__nand2_2 _164_ (.A(_046_),
    .B(_077_),
    .Y(_078_));
 sky130_fd_sc_hd__o2111a_2 _165_ (.A1(_046_),
    .A2(_077_),
    .B1(_078_),
    .C1(_064_),
    .D1(_067_),
    .X(_007_));
 sky130_fd_sc_hd__nor2_2 _166_ (.A(counter_value[7]),
    .B(_047_),
    .Y(_079_));
 sky130_fd_sc_hd__a22o_2 _167_ (.A1(counter_value[7]),
    .A2(_047_),
    .B1(_048_),
    .B2(counter_value[6]),
    .X(_080_));
 sky130_fd_sc_hd__o2bb2a_2 _168_ (.A1_N(_043_),
    .A2_N(\duty_cycle[5] ),
    .B1(counter_value[6]),
    .B2(_048_),
    .X(_081_));
 sky130_fd_sc_hd__o22a_2 _169_ (.A1(_043_),
    .A2(\duty_cycle[5] ),
    .B1(\duty_cycle[4] ),
    .B2(_044_),
    .X(_082_));
 sky130_fd_sc_hd__o211a_2 _170_ (.A1(\duty_cycle[1] ),
    .A2(_049_),
    .B1(\duty_cycle[0] ),
    .C1(_050_),
    .X(_083_));
 sky130_fd_sc_hd__a22o_2 _171_ (.A1(_042_),
    .A2(\duty_cycle[2] ),
    .B1(\duty_cycle[1] ),
    .B2(_049_),
    .X(_084_));
 sky130_fd_sc_hd__o22a_2 _172_ (.A1(_041_),
    .A2(\duty_cycle[3] ),
    .B1(\duty_cycle[2] ),
    .B2(_042_),
    .X(_085_));
 sky130_fd_sc_hd__o21a_2 _173_ (.A1(_083_),
    .A2(_084_),
    .B1(_085_),
    .X(_086_));
 sky130_fd_sc_hd__a22o_2 _174_ (.A1(_044_),
    .A2(\duty_cycle[4] ),
    .B1(\duty_cycle[3] ),
    .B2(_041_),
    .X(_087_));
 sky130_fd_sc_hd__o21ai_2 _175_ (.A1(_086_),
    .A2(_087_),
    .B1(_082_),
    .Y(_088_));
 sky130_fd_sc_hd__a21oi_2 _176_ (.A1(_081_),
    .A2(_088_),
    .B1(_080_),
    .Y(_089_));
 sky130_fd_sc_hd__o21a_2 _177_ (.A1(_079_),
    .A2(_089_),
    .B1(enable),
    .X(_008_));
 sky130_fd_sc_hd__or4_2 _178_ (.A(rd_addr[5]),
    .B(rd_addr[4]),
    .C(rd_addr[7]),
    .D(rd_addr[6]),
    .X(_090_));
 sky130_fd_sc_hd__or2_2 _179_ (.A(_051_),
    .B(_090_),
    .X(_091_));
 sky130_fd_sc_hd__or3_2 _180_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .C(rd_addr[3]),
    .X(_092_));
 sky130_fd_sc_hd__nor2_2 _181_ (.A(_091_),
    .B(_092_),
    .Y(_093_));
 sky130_fd_sc_hd__nor3_2 _182_ (.A(rd_addr[2]),
    .B(_090_),
    .C(_092_),
    .Y(_094_));
 sky130_fd_sc_hd__a22o_2 _183_ (.A1(\duty_cycle[0] ),
    .A2(_093_),
    .B1(_094_),
    .B2(enable),
    .X(_095_));
 sky130_fd_sc_hd__or3b_2 _184_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .C_N(rd_addr[3]),
    .X(_096_));
 sky130_fd_sc_hd__nor2_2 _185_ (.A(_091_),
    .B(_096_),
    .Y(_097_));
 sky130_fd_sc_hd__nor3_2 _186_ (.A(rd_addr[2]),
    .B(_090_),
    .C(_096_),
    .Y(_098_));
 sky130_fd_sc_hd__a22o_2 _187_ (.A1(counter_value[0]),
    .A2(_097_),
    .B1(_098_),
    .B2(\period[0] ),
    .X(_099_));
 sky130_fd_sc_hd__o21a_2 _188_ (.A1(_095_),
    .A2(_099_),
    .B1(rd_en),
    .X(_009_));
 sky130_fd_sc_hd__a22o_2 _189_ (.A1(\duty_cycle[1] ),
    .A2(_093_),
    .B1(_094_),
    .B2(\u_register_map.control_reg[1] ),
    .X(_100_));
 sky130_fd_sc_hd__a22o_2 _190_ (.A1(counter_value[1]),
    .A2(_097_),
    .B1(_098_),
    .B2(\period[1] ),
    .X(_101_));
 sky130_fd_sc_hd__o21a_2 _191_ (.A1(_100_),
    .A2(_101_),
    .B1(rd_en),
    .X(_010_));
 sky130_fd_sc_hd__a22o_2 _192_ (.A1(\duty_cycle[2] ),
    .A2(_093_),
    .B1(_094_),
    .B2(\u_register_map.control_reg[2] ),
    .X(_102_));
 sky130_fd_sc_hd__a22o_2 _193_ (.A1(counter_value[2]),
    .A2(_097_),
    .B1(_098_),
    .B2(\period[2] ),
    .X(_103_));
 sky130_fd_sc_hd__o21a_2 _194_ (.A1(_102_),
    .A2(_103_),
    .B1(rd_en),
    .X(_011_));
 sky130_fd_sc_hd__a22o_2 _195_ (.A1(\duty_cycle[3] ),
    .A2(_093_),
    .B1(_094_),
    .B2(\u_register_map.control_reg[3] ),
    .X(_104_));
 sky130_fd_sc_hd__a22o_2 _196_ (.A1(counter_value[3]),
    .A2(_097_),
    .B1(_098_),
    .B2(\period[3] ),
    .X(_105_));
 sky130_fd_sc_hd__o21a_2 _197_ (.A1(_104_),
    .A2(_105_),
    .B1(rd_en),
    .X(_012_));
 sky130_fd_sc_hd__a22o_2 _198_ (.A1(\duty_cycle[4] ),
    .A2(_093_),
    .B1(_094_),
    .B2(\u_register_map.control_reg[4] ),
    .X(_106_));
 sky130_fd_sc_hd__a22o_2 _199_ (.A1(counter_value[4]),
    .A2(_097_),
    .B1(_098_),
    .B2(\period[4] ),
    .X(_107_));
 sky130_fd_sc_hd__o21a_2 _200_ (.A1(_106_),
    .A2(_107_),
    .B1(rd_en),
    .X(_013_));
 sky130_fd_sc_hd__a22o_2 _201_ (.A1(\duty_cycle[5] ),
    .A2(_093_),
    .B1(_094_),
    .B2(\u_register_map.control_reg[5] ),
    .X(_108_));
 sky130_fd_sc_hd__a22o_2 _202_ (.A1(counter_value[5]),
    .A2(_097_),
    .B1(_098_),
    .B2(\period[5] ),
    .X(_109_));
 sky130_fd_sc_hd__o21a_2 _203_ (.A1(_108_),
    .A2(_109_),
    .B1(rd_en),
    .X(_014_));
 sky130_fd_sc_hd__a22o_2 _204_ (.A1(\duty_cycle[6] ),
    .A2(_093_),
    .B1(_094_),
    .B2(\u_register_map.control_reg[6] ),
    .X(_110_));
 sky130_fd_sc_hd__a22o_2 _205_ (.A1(counter_value[6]),
    .A2(_097_),
    .B1(_098_),
    .B2(\period[6] ),
    .X(_111_));
 sky130_fd_sc_hd__o21a_2 _206_ (.A1(_110_),
    .A2(_111_),
    .B1(rd_en),
    .X(_015_));
 sky130_fd_sc_hd__a22o_2 _207_ (.A1(\duty_cycle[7] ),
    .A2(_093_),
    .B1(_094_),
    .B2(\u_register_map.control_reg[7] ),
    .X(_112_));
 sky130_fd_sc_hd__a22o_2 _208_ (.A1(counter_value[7]),
    .A2(_097_),
    .B1(_098_),
    .B2(\period[7] ),
    .X(_113_));
 sky130_fd_sc_hd__o21a_2 _209_ (.A1(_112_),
    .A2(_113_),
    .B1(rd_en),
    .X(_016_));
 sky130_fd_sc_hd__and3_2 _210_ (.A(_050_),
    .B(_064_),
    .C(_067_),
    .X(_000_));
 sky130_fd_sc_hd__or2_2 _211_ (.A(counter_value[1]),
    .B(counter_value[0]),
    .X(_114_));
 sky130_fd_sc_hd__and4b_2 _212_ (.A_N(_068_),
    .B(_114_),
    .C(_064_),
    .D(_067_),
    .X(_001_));
 sky130_fd_sc_hd__or3_2 _213_ (.A(wr_addr[5]),
    .B(wr_addr[4]),
    .C(wr_addr[7]),
    .X(_115_));
 sky130_fd_sc_hd__or3b_2 _214_ (.A(_115_),
    .B(wr_addr[6]),
    .C_N(wr_en),
    .X(_116_));
 sky130_fd_sc_hd__or2_2 _215_ (.A(wr_addr[3]),
    .B(_116_),
    .X(_117_));
 sky130_fd_sc_hd__or3_2 _216_ (.A(wr_addr[1]),
    .B(wr_addr[0]),
    .C(wr_addr[2]),
    .X(_118_));
 sky130_fd_sc_hd__or2_2 _217_ (.A(_117_),
    .B(_118_),
    .X(_119_));
 sky130_fd_sc_hd__mux2_1 _218_ (.A0(wr_data[0]),
    .A1(enable),
    .S(_119_),
    .X(_017_));
 sky130_fd_sc_hd__mux2_1 _219_ (.A0(wr_data[1]),
    .A1(\u_register_map.control_reg[1] ),
    .S(_119_),
    .X(_018_));
 sky130_fd_sc_hd__mux2_1 _220_ (.A0(wr_data[2]),
    .A1(\u_register_map.control_reg[2] ),
    .S(_119_),
    .X(_019_));
 sky130_fd_sc_hd__mux2_1 _221_ (.A0(wr_data[3]),
    .A1(\u_register_map.control_reg[3] ),
    .S(_119_),
    .X(_020_));
 sky130_fd_sc_hd__mux2_1 _222_ (.A0(wr_data[4]),
    .A1(\u_register_map.control_reg[4] ),
    .S(_119_),
    .X(_021_));
 sky130_fd_sc_hd__mux2_1 _223_ (.A0(wr_data[5]),
    .A1(\u_register_map.control_reg[5] ),
    .S(_119_),
    .X(_022_));
 sky130_fd_sc_hd__mux2_1 _224_ (.A0(wr_data[6]),
    .A1(\u_register_map.control_reg[6] ),
    .S(_119_),
    .X(_023_));
 sky130_fd_sc_hd__mux2_1 _225_ (.A0(wr_data[7]),
    .A1(\u_register_map.control_reg[7] ),
    .S(_119_),
    .X(_024_));
 sky130_fd_sc_hd__or4b_2 _226_ (.A(wr_addr[1]),
    .B(_117_),
    .C(wr_addr[0]),
    .D_N(wr_addr[2]),
    .X(_120_));
 sky130_fd_sc_hd__mux2_1 _227_ (.A0(wr_data[0]),
    .A1(\duty_cycle[0] ),
    .S(_120_),
    .X(_025_));
 sky130_fd_sc_hd__mux2_1 _228_ (.A0(wr_data[1]),
    .A1(\duty_cycle[1] ),
    .S(_120_),
    .X(_026_));
 sky130_fd_sc_hd__mux2_1 _229_ (.A0(wr_data[2]),
    .A1(\duty_cycle[2] ),
    .S(_120_),
    .X(_027_));
 sky130_fd_sc_hd__mux2_1 _230_ (.A0(wr_data[3]),
    .A1(\duty_cycle[3] ),
    .S(_120_),
    .X(_028_));
 sky130_fd_sc_hd__mux2_1 _231_ (.A0(wr_data[4]),
    .A1(\duty_cycle[4] ),
    .S(_120_),
    .X(_029_));
 sky130_fd_sc_hd__mux2_1 _232_ (.A0(wr_data[5]),
    .A1(\duty_cycle[5] ),
    .S(_120_),
    .X(_030_));
 sky130_fd_sc_hd__mux2_1 _233_ (.A0(wr_data[6]),
    .A1(\duty_cycle[6] ),
    .S(_120_),
    .X(_031_));
 sky130_fd_sc_hd__mux2_1 _234_ (.A0(wr_data[7]),
    .A1(\duty_cycle[7] ),
    .S(_120_),
    .X(_032_));
 sky130_fd_sc_hd__or3_2 _235_ (.A(_045_),
    .B(_116_),
    .C(_118_),
    .X(_121_));
 sky130_fd_sc_hd__mux2_1 _236_ (.A0(wr_data[0]),
    .A1(\period[0] ),
    .S(_121_),
    .X(_033_));
 sky130_fd_sc_hd__mux2_1 _237_ (.A0(wr_data[1]),
    .A1(\period[1] ),
    .S(_121_),
    .X(_034_));
 sky130_fd_sc_hd__mux2_1 _238_ (.A0(wr_data[2]),
    .A1(\period[2] ),
    .S(_121_),
    .X(_035_));
 sky130_fd_sc_hd__mux2_1 _239_ (.A0(wr_data[3]),
    .A1(\period[3] ),
    .S(_121_),
    .X(_036_));
 sky130_fd_sc_hd__mux2_1 _240_ (.A0(wr_data[4]),
    .A1(\period[4] ),
    .S(_121_),
    .X(_037_));
 sky130_fd_sc_hd__mux2_1 _241_ (.A0(wr_data[5]),
    .A1(\period[5] ),
    .S(_121_),
    .X(_038_));
 sky130_fd_sc_hd__mux2_1 _242_ (.A0(wr_data[6]),
    .A1(\period[6] ),
    .S(_121_),
    .X(_039_));
 sky130_fd_sc_hd__mux2_1 _243_ (.A0(wr_data[7]),
    .A1(\period[7] ),
    .S(_121_),
    .X(_040_));
 sky130_fd_sc_hd__sdfrtp_2 _244_ (.CLK(clk),
    .D(_017_),
    .RESET_B(reset_n),
    .SCD(scan_in[0]),
    .SCE(scan_en),
    .Q(enable));
 sky130_fd_sc_hd__sdfrtp_2 _245_ (.CLK(clk),
    .D(_018_),
    .RESET_B(reset_n),
    .SCD(scan_in[1]),
    .SCE(scan_en),
    .Q(\u_register_map.control_reg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _246_ (.CLK(clk),
    .D(_019_),
    .RESET_B(reset_n),
    .SCD(scan_in[2]),
    .SCE(scan_en),
    .Q(\u_register_map.control_reg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _247_ (.CLK(clk),
    .D(_020_),
    .RESET_B(reset_n),
    .SCD(scan_in[3]),
    .SCE(scan_en),
    .Q(\u_register_map.control_reg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _248_ (.CLK(clk),
    .D(_021_),
    .RESET_B(reset_n),
    .SCD(enable),
    .SCE(scan_en),
    .Q(\u_register_map.control_reg[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _249_ (.CLK(clk),
    .D(_022_),
    .RESET_B(reset_n),
    .SCD(\u_register_map.control_reg[1] ),
    .SCE(scan_en),
    .Q(\u_register_map.control_reg[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _250_ (.CLK(clk),
    .D(_023_),
    .RESET_B(reset_n),
    .SCD(\u_register_map.control_reg[2] ),
    .SCE(scan_en),
    .Q(\u_register_map.control_reg[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _251_ (.CLK(clk),
    .D(_024_),
    .RESET_B(reset_n),
    .SCD(\u_register_map.control_reg[3] ),
    .SCE(scan_en),
    .Q(\u_register_map.control_reg[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _252_ (.CLK(clk),
    .D(_025_),
    .RESET_B(reset_n),
    .SCD(\u_register_map.control_reg[4] ),
    .SCE(scan_en),
    .Q(\duty_cycle[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _253_ (.CLK(clk),
    .D(_026_),
    .RESET_B(reset_n),
    .SCD(\u_register_map.control_reg[5] ),
    .SCE(scan_en),
    .Q(\duty_cycle[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _254_ (.CLK(clk),
    .D(_027_),
    .RESET_B(reset_n),
    .SCD(\u_register_map.control_reg[6] ),
    .SCE(scan_en),
    .Q(\duty_cycle[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _255_ (.CLK(clk),
    .D(_028_),
    .RESET_B(reset_n),
    .SCD(\u_register_map.control_reg[7] ),
    .SCE(scan_en),
    .Q(\duty_cycle[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _256_ (.CLK(clk),
    .D(_029_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle[0] ),
    .SCE(scan_en),
    .Q(\duty_cycle[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _257_ (.CLK(clk),
    .D(_030_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle[1] ),
    .SCE(scan_en),
    .Q(\duty_cycle[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _258_ (.CLK(clk),
    .D(_031_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle[2] ),
    .SCE(scan_en),
    .Q(\duty_cycle[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _259_ (.CLK(clk),
    .D(_032_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle[3] ),
    .SCE(scan_en),
    .Q(\duty_cycle[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _260_ (.CLK(clk),
    .D(_009_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle[4] ),
    .SCE(scan_en),
    .Q(rd_data[0]));
 sky130_fd_sc_hd__sdfrtp_2 _261_ (.CLK(clk),
    .D(_010_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle[5] ),
    .SCE(scan_en),
    .Q(rd_data[1]));
 sky130_fd_sc_hd__sdfrtp_2 _262_ (.CLK(clk),
    .D(_011_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle[6] ),
    .SCE(scan_en),
    .Q(rd_data[2]));
 sky130_fd_sc_hd__sdfrtp_2 _263_ (.CLK(clk),
    .D(_012_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle[7] ),
    .SCE(scan_en),
    .Q(rd_data[3]));
 sky130_fd_sc_hd__sdfrtp_2 _264_ (.CLK(clk),
    .D(_013_),
    .RESET_B(reset_n),
    .SCD(rd_data[0]),
    .SCE(scan_en),
    .Q(rd_data[4]));
 sky130_fd_sc_hd__sdfrtp_2 _265_ (.CLK(clk),
    .D(_014_),
    .RESET_B(reset_n),
    .SCD(rd_data[1]),
    .SCE(scan_en),
    .Q(rd_data[5]));
 sky130_fd_sc_hd__sdfrtp_2 _266_ (.CLK(clk),
    .D(_015_),
    .RESET_B(reset_n),
    .SCD(rd_data[2]),
    .SCE(scan_en),
    .Q(rd_data[6]));
 sky130_fd_sc_hd__sdfrtp_2 _267_ (.CLK(clk),
    .D(_016_),
    .RESET_B(reset_n),
    .SCD(rd_data[3]),
    .SCE(scan_en),
    .Q(rd_data[7]));
 sky130_fd_sc_hd__sdfrtp_2 _268_ (.CLK(clk),
    .D(_033_),
    .RESET_B(reset_n),
    .SCD(rd_data[4]),
    .SCE(scan_en),
    .Q(\period[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _269_ (.CLK(clk),
    .D(_034_),
    .RESET_B(reset_n),
    .SCD(rd_data[5]),
    .SCE(scan_en),
    .Q(\period[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _270_ (.CLK(clk),
    .D(_035_),
    .RESET_B(reset_n),
    .SCD(rd_data[6]),
    .SCE(scan_en),
    .Q(\period[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _271_ (.CLK(clk),
    .D(_036_),
    .RESET_B(reset_n),
    .SCD(rd_data[7]),
    .SCE(scan_en),
    .Q(\period[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _272_ (.CLK(clk),
    .D(_037_),
    .RESET_B(reset_n),
    .SCD(\period[0] ),
    .SCE(scan_en),
    .Q(\period[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _273_ (.CLK(clk),
    .D(_038_),
    .RESET_B(reset_n),
    .SCD(\period[1] ),
    .SCE(scan_en),
    .Q(\period[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _274_ (.CLK(clk),
    .D(_039_),
    .RESET_B(reset_n),
    .SCD(\period[2] ),
    .SCE(scan_en),
    .Q(\period[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _275_ (.CLK(clk),
    .D(_040_),
    .RESET_B(reset_n),
    .SCD(\period[3] ),
    .SCE(scan_en),
    .Q(\period[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _276_ (.CLK(clk),
    .D(_000_),
    .RESET_B(reset_n),
    .SCD(\period[4] ),
    .SCE(scan_en),
    .Q(counter_value[0]));
 sky130_fd_sc_hd__sdfrtp_2 _277_ (.CLK(clk),
    .D(_001_),
    .RESET_B(reset_n),
    .SCD(\period[5] ),
    .SCE(scan_en),
    .Q(counter_value[1]));
 sky130_fd_sc_hd__sdfrtp_2 _278_ (.CLK(clk),
    .D(_002_),
    .RESET_B(reset_n),
    .SCD(\period[6] ),
    .SCE(scan_en),
    .Q(counter_value[2]));
 sky130_fd_sc_hd__sdfrtp_2 _279_ (.CLK(clk),
    .D(_003_),
    .RESET_B(reset_n),
    .SCD(\period[7] ),
    .SCE(scan_en),
    .Q(counter_value[3]));
 sky130_fd_sc_hd__sdfrtp_2 _280_ (.CLK(clk),
    .D(_004_),
    .RESET_B(reset_n),
    .SCD(counter_value[0]),
    .SCE(scan_en),
    .Q(counter_value[4]));
 sky130_fd_sc_hd__sdfrtp_2 _281_ (.CLK(clk),
    .D(_005_),
    .RESET_B(reset_n),
    .SCD(counter_value[1]),
    .SCE(scan_en),
    .Q(counter_value[5]));
 sky130_fd_sc_hd__sdfrtp_2 _282_ (.CLK(clk),
    .D(_006_),
    .RESET_B(reset_n),
    .SCD(counter_value[2]),
    .SCE(scan_en),
    .Q(counter_value[6]));
 sky130_fd_sc_hd__sdfrtp_2 _283_ (.CLK(clk),
    .D(_007_),
    .RESET_B(reset_n),
    .SCD(counter_value[3]),
    .SCE(scan_en),
    .Q(counter_value[7]));
 sky130_fd_sc_hd__sdfrtp_2 _284_ (.CLK(clk),
    .D(_008_),
    .RESET_B(reset_n),
    .SCD(counter_value[4]),
    .SCE(scan_en),
    .Q(pwm_out));
 assign scan_out[1] = counter_value[5];
 assign scan_out[2] = counter_value[6];
 assign scan_out[3] = counter_value[7];
 assign scan_out[0] = pwm_out;
endmodule
