# Digital Synthesis Summary

- **Workflow**: 9cf56e35-1b89-4d93-8204-30912f8496d5
- **Status**: `ok` (rc=0)
- **Top module**: `pwm_controller`
- **Clock**: `clk` @ **10.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/9cf56e35-1b89-4d93-8204-30912f8496d5/7f62ea6e-197a-4717-ae23-3dc0eb972a7f/digital/arch2synthesis/digital/synth/runs/Digital_Arch2Synthesis_9cf56e35-1b89-4d93-8204-30912f8496d5/final/metrics.json`
- netlist candidates: 1 found
