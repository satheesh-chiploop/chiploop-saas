/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/9cf56e35-1b89-4d93-8204-30912f8496d5/7f62ea6e-197a-4717-ae23-3dc0eb972a7f/digital/arch2synthesis/handoff/rtl/pwm_controller.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/9cf56e35-1b89-4d93-8204-30912f8496d5/7f62ea6e-197a-4717-ae23-3dc0eb972a7f/digital/arch2synthesis/handoff/rtl/pwm_core.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/9cf56e35-1b89-4d93-8204-30912f8496d5/7f62ea6e-197a-4717-ae23-3dc0eb972a7f/digital/arch2synthesis/handoff/rtl/register_map.v
