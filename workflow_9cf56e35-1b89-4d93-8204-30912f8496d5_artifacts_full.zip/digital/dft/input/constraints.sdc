# Auto-generated from ChipLoop clock intent
create_clock -name clk -period 2.500 [get_ports {clk}]
