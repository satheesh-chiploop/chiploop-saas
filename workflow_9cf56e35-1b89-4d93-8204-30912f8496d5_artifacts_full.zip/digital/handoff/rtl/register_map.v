module register_map (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    counter_value,
    rd_data,
    enable,
    duty_cycle,
    period
);
input clk;
input reset_n;
input wr_en;
input [7:0] wr_addr;
input [7:0] wr_data;
input rd_en;
input [7:0] rd_addr;
input [7:0] counter_value;
output [7:0] rd_data;
output enable;
output [7:0] duty_cycle;
output [7:0] period;

reg [7:0] control_reg;
reg [7:0] duty_cycle_reg;
reg [7:0] period_reg;
reg [7:0] rd_data_r;

assign rd_data = rd_data_r;
assign enable = control_reg[0];
assign duty_cycle = duty_cycle_reg;
assign period = period_reg;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        control_reg <= 8'h00;
        duty_cycle_reg <= 8'h00;
        period_reg <= 8'h00;
        rd_data_r <= 8'h00;
    end else begin
        if (wr_en) begin
            case (wr_addr)
                8'h00: control_reg <= wr_data;
                8'h04: duty_cycle_reg <= wr_data;
                8'h08: period_reg <= wr_data;
                default: begin
                    control_reg <= control_reg;
                    duty_cycle_reg <= duty_cycle_reg;
                    period_reg <= period_reg;
                end
            endcase
        end
        if (rd_en) begin
            case (rd_addr)
                8'h00: rd_data_r <= control_reg;
                8'h04: rd_data_r <= duty_cycle_reg;
                8'h08: rd_data_r <= period_reg;
                8'h0C: rd_data_r <= counter_value;
                default: rd_data_r <= 8'h00;
            endcase
        end else begin
            rd_data_r <= 8'h00;
        end
    end
end

endmodule
