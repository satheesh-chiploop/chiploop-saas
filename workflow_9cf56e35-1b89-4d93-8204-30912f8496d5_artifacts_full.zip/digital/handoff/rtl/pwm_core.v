module pwm_core (
    clk,
    reset_n,
    enable,
    duty_cycle,
    period,
    counter_value,
    pwm_out
);
input clk;
input reset_n;
input enable;
input [7:0] duty_cycle;
input [7:0] period;
output [7:0] counter_value;
output pwm_out;

reg [7:0] counter_reg;
reg pwm_out_r;

assign counter_value = counter_reg;
assign pwm_out = pwm_out_r;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        counter_reg <= 8'h00;
        pwm_out_r <= 1'b0;
    end else begin
        if (enable && (period != 8'h00)) begin
            if (counter_reg >= period) begin
                counter_reg <= 8'h00;
            end else begin
                counter_reg <= counter_reg + 8'h01;
            end
        end else begin
            counter_reg <= 8'h00;
        end
        if (enable && (counter_reg < duty_cycle)) begin
            pwm_out_r <= 1'b1;
        end else begin
            pwm_out_r <= 1'b0;
        end
    end
end

endmodule
