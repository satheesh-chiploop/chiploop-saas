# IP Packaging & Handoff Report

- Top: `adaptive_aero_control_top`
- Package: `backend/workflows/ecb44ca5-f158-4a58-8096-bfae204f3f36/handoff/adaptive_aero_control_top_ip_package`
- Zip: `backend/workflows/ecb44ca5-f158-4a58-8096-bfae204f3f36/handoff/adaptive_aero_control_top_ip_package.zip`

## Bucket counts
- **rtl**: 1
- **spec**: 4
- **arch**: 1
- **microarch**: 1
- **regmap**: 2
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 7
