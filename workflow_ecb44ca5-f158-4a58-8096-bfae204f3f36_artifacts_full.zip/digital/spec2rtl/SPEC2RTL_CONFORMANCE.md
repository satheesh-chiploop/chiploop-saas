# Spec-to-RTL Conformance Report

Status: **partial**

- Requirements checked: 37
- Matched: 27
- Partial: 0
- Missing: 10
- Inconclusive: 0
- Interface: issues
- Register map: issues
- Clock/reset: pass

## Missing Or Partial Requirements
- REQ-001 [missing]: Expose a real firmware-visible CSR/MMIO interface with address, write-data, read-data, transaction-valid/select, write-enable, and ready semantics.
- REQ-003 [missing]: Form compact deterministic request words containing sequence ID, operating-point metadata, reference speed, and normalized control context.
- REQ-004 [missing]: Drive request valid only when a request is ready and downstream is not backpressured; hold request data stable while waiting for ready.
- REQ-005 [missing]: Accept model responses only when valid/ready framing is correct and the embedded sequence matches the outstanding request.
- REQ-007 [missing]: Clamp actuator intent within configured min/max limits and apply optional rate limiting when a valid response is accepted.
- REQ-008 [missing]: Provide status interrupt indication for timeout, stale rejection, malformed response, and safe-inhibit entry.
- REQ-010 [missing]: Configuration writes take effect only when enable is deasserted or when an explicit update strobe is provided.
- REQ-016 [missing]: No fallback controller, fallback command, substitute command, or silent replacement command shall be generated on error conditions.
