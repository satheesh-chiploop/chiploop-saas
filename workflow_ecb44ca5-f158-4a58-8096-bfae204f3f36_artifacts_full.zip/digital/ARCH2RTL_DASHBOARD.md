# Arch2RTL Evidence Dashboard

- Lint: warnings
- Flip-flops: 400
- Latches: 0
- Full-cycle paths: 3
- Half-cycle paths: 1
- Input bits: 206
- Output bits: 213
- Input ports: 9
- Output ports: 8
- Clock: clk
- Reset: clk_rst_n
- Modules: 1
- RTL files: 1
