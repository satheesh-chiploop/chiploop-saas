# Digital DQA Summary
- workflow_id: `a82c6a3a-c1f7-456f-862a-7db3a95717c0`
- status: `failed`
- rtl files: `1`
- warning count: `0`

## Stage Status
- rtl_lint: `warn`
- cdc: `unavailable`
- reset_integrity: `unavailable`
- synthesis_readiness: `failed`

## Blocking Issues
- yosys_synthesis_errors
