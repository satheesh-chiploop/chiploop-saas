# IP Packaging & Handoff Report

- Top: `pwm_fpga_demo`
- Package: `backend/workflows/a82c6a3a-c1f7-456f-862a-7db3a95717c0/handoff/pwm_fpga_demo_ip_package`
- Zip: `backend/workflows/a82c6a3a-c1f7-456f-862a-7db3a95717c0/handoff/pwm_fpga_demo_ip_package.zip`

## Bucket counts
- **rtl**: 1
- **spec**: 3
- **arch**: 1
- **microarch**: 1
- **regmap**: 2
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 7
