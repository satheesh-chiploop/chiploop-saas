module pwm_fpga_demo (
    input  clk,
    output led
);

reg [7:0] pwm_cnt;
reg [7:0] duty_cycle;
reg [15:0] slow_cnt;
reg dir;

assign led = (pwm_cnt < duty_cycle);

always @(posedge clk) begin
    pwm_cnt <= pwm_cnt + 8'd1;

    if (slow_cnt == 16'd49999) begin
        slow_cnt <= 16'd0;
        if (dir) begin
            if (duty_cycle == 8'hFF) begin
                duty_cycle <= duty_cycle - 8'd1;
                dir <= 1'b0;
            end else begin
                duty_cycle <= duty_cycle + 8'd1;
                dir <= 1'b1;
            end
        end else begin
            if (duty_cycle == 8'h00) begin
                duty_cycle <= duty_cycle + 8'd1;
                dir <= 1'b1;
            end else begin
                duty_cycle <= duty_cycle - 8'd1;
                dir <= 1'b0;
            end
        end
    end else begin
        slow_cnt <= slow_cnt + 16'd1;
    end
end

initial begin
    pwm_cnt = 8'd0;
    duty_cycle = 8'd0;
    slow_cnt = 16'd0;
    dir = 1'b1;
end

endmodule
