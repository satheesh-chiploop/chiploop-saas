module pwm_fpga_demo (
    clk,
    led
);

input clk;
output led;

reg [7:0] pwm_counter;
reg [15:0] slow_counter;
reg [7:0] duty_cycle;
reg direction;

assign led = (pwm_counter < duty_cycle);

always @(posedge clk) begin
    pwm_counter <= pwm_counter + 8'h01;
    slow_counter <= slow_counter + 16'h0001;

    if (slow_counter == 16'hFFFF) begin
        if (direction) begin
            if (duty_cycle == 8'hFF) begin
                duty_cycle <= 8'hFE;
                direction <= 1'b0;
            end else begin
                duty_cycle <= duty_cycle + 8'h01;
            end
        end else begin
            if (duty_cycle == 8'h00) begin
                duty_cycle <= 8'h01;
                direction <= 1'b1;
            end else begin
                duty_cycle <= duty_cycle - 8'h01;
            end
        end
    end
end

initial begin
    pwm_counter = 8'h00;
    slow_counter = 16'h0000;
    duty_cycle = 8'h00;
    direction = 1'b1;
end

endmodule
