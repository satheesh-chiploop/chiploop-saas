# Digital DQA Summary
- workflow_id: `39bf251f-298b-41e9-81b3-7d2e0083574f`
- status: `pass`
- rtl files: `7`
- warning count: `0`

## Stage Status
- rtl_lint: `warn`
- cdc: `pass`
- reset_integrity: `pass`
- synthesis_readiness: `pass`
