{
  "type": "cdc_analysis_report",
  "version": "1.0",
  "inputs": {
    "clock_reset_intent_present": false,
    "rtl_file_count": 8
  },
  "observations": {
    "inferred_clocks": [
      "clk"
    ],
    "inferred_domains": [],
    "per_file": [
      {
        "file": "backend/workflows/39bf251f-298b-41e9-81b3-7d2e0083574f/fpga/src/fpga/target_explorer/interface_adapter/adaptive_aero_control_top_spi_fpga_top.sv",
        "clock": null,
        "domain": null
      },
      {
        "file": "backend/workflows/39bf251f-298b-41e9-81b3-7d2e0083574f/fpga/src/upstream/adaptive_aero_command_validator.v",
        "clock": "clk",
        "domain": null
      },
      {
        "file": "backend/workflows/39bf251f-298b-41e9-81b3-7d2e0083574f/fpga/src/upstream/adaptive_aero_control_top.v",
        "clock": null,
        "domain": null
      },
      {
        "file": "backend/workflows/39bf251f-298b-41e9-81b3-7d2e0083574f/fpga/src/upstream/adaptive_aero_control_top_spi_fpga_top.sv",
        "clock": null,
        "domain": null
      },
      {
        "file": "backend/workflows/39bf251f-298b-41e9-81b3-7d2e0083574f/fpga/src/upstream/adaptive_aero_register_window.v",
        "clock": "clk",
        "domain": null
      },
      {
        "file": "backend/workflows/39bf251f-298b-41e9-81b3-7d2e0083574f/fpga/src/upstream/adaptive_aero_safety_fsm.v",
        "clock": "clk",
        "domain": null
      },
      {
        "file": "backend/workflows/39bf251f-298b-41e9-81b3-7d2e0083574f/fpga/src/upstream/adaptive_aero_sensor_if.v",
        "clock": "clk",
        "domain": null
      },
      {
        "file": "backend/workflows/39bf251f-298b-41e9-81b3-7d2e0083574f/fpga/src/upstream/adaptive_aero_transport_bridge.v",
        "clock": "clk",
        "domain": null
      }
    ]
  },
  "findings": [],
  "recommendations": [
    "Provide clock_reset_arch_intent.json for higher-fidelity CDC intent (domains, allowed crossings).",
    "For single-bit control crossings: use 2-flop synchronizers.",
    "For multi-bit data: use async FIFOs or validated handshake schemes.",
    "Run a real CDC tool in enterprise flow (Questa CDC / SpyGlass CDC / VC CDC) when available."
  ],
  "note": "This agent provides intent-level CDC screening. It is not a replacement for signoff CDC tools."
}