module adaptive_aero_transport_bridge (
    clk,
    reset_n,
    cfg_mode,
    cfg_seq_num,
    cfg_enable,
    model_req_valid,
    model_req_ready,
    model_req_data,
    model_rsp_valid,
    model_rsp_ready,
    model_rsp_data,
    liveness_ok,
    completion_code,
    fault_code
);
input clk;
input reset_n;
input [2:0] cfg_mode;
input [15:0] cfg_seq_num;
input cfg_enable;
output model_req_valid;
input model_req_ready;
output [31:0] model_req_data;
input model_rsp_valid;
output model_rsp_ready;
input [31:0] model_rsp_data;
output liveness_ok;
output [7:0] completion_code;
output [7:0] fault_code;
reg model_req_valid_r;
reg [31:0] model_req_data_r;
reg model_rsp_ready_r;
reg liveness_ok_r;
reg [7:0] completion_code_r;
reg [7:0] fault_code_r;
reg [31:0] req_meta;

assign model_req_valid = model_req_valid_r;
assign model_req_data = model_req_data_r;
assign model_rsp_ready = model_rsp_ready_r;
assign liveness_ok = liveness_ok_r;
assign completion_code = completion_code_r;
assign fault_code = fault_code_r;

always @(*) begin
    req_meta = {cfg_mode, cfg_enable, cfg_seq_num, 12'h000};
end

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        model_req_valid_r <= 1'b0;
        model_req_data_r <= 32'h00000000;
        model_rsp_ready_r <= 1'b1;
        liveness_ok_r <= 1'b0;
        completion_code_r <= 8'h00;
        fault_code_r <= 8'h00;
    end else begin
        model_req_valid_r <= cfg_enable;
        model_req_data_r <= req_meta;
        model_rsp_ready_r <= 1'b1;
        liveness_ok_r <= cfg_enable & model_req_ready;
        completion_code_r <= {cfg_mode, 5'b00000};
        fault_code_r <= {model_rsp_valid, model_rsp_data[6:0]};
    end
end
endmodule
