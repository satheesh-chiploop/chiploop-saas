module adaptive_aero_register_window (
    clk,
    reset_n,
    reg_wr_en,
    reg_rd_en,
    reg_addr,
    reg_wdata,
    reg_rdata,
    reg_ready,
    cfg_mode,
    cfg_enable,
    cfg_seq_num,
    cfg_cmd_age,
    cfg_stale_timeout,
    cfg_watchdog_period,
    cfg_cmd_valid,
    cfg_clear_status,
    cfg_clear_on_read,
    cfg_act_min,
    cfg_act_max,
    cfg_safe_fallback,
    cfg_status_clear_w1c,
    status_last_seq_in,
    status_stale_fault_in,
    status_timeout_fault_in,
    status_invalid_cmd_fault_in,
    status_clamp_event_in,
    status_fallback_active_in
);
input clk;
input reset_n;
input reg_wr_en;
input reg_rd_en;
input [7:0] reg_addr;
input [63:0] reg_wdata;
output [63:0] reg_rdata;
output reg_ready;
output [2:0] cfg_mode;
output cfg_enable;
output [15:0] cfg_seq_num;
output [15:0] cfg_cmd_age;
output [15:0] cfg_stale_timeout;
output [15:0] cfg_watchdog_period;
output cfg_cmd_valid;
output cfg_clear_status;
output cfg_clear_on_read;
output [31:0] cfg_act_min;
output [31:0] cfg_act_max;
output [31:0] cfg_safe_fallback;
output cfg_status_clear_w1c;
input [15:0] status_last_seq_in;
input status_stale_fault_in;
input status_timeout_fault_in;
input status_invalid_cmd_fault_in;
input status_clamp_event_in;
input status_fallback_active_in;

reg [2:0] cfg_mode_r;
reg cfg_enable_r;
reg [15:0] cfg_seq_num_r;
reg [15:0] cfg_cmd_age_r;
reg [15:0] cfg_stale_timeout_r;
reg [15:0] cfg_watchdog_period_r;
reg cfg_cmd_valid_r;
reg cfg_clear_status_r;
reg cfg_clear_on_read_r;
reg [31:0] cfg_act_min_r;
reg [31:0] cfg_act_max_r;
reg [31:0] cfg_safe_fallback_r;
reg cfg_status_clear_w1c_r;
reg [63:0] reg_rdata_r;
reg reg_ready_r;

assign cfg_mode = cfg_mode_r;
assign cfg_enable = cfg_enable_r;
assign cfg_seq_num = cfg_seq_num_r;
assign cfg_cmd_age = cfg_cmd_age_r;
assign cfg_stale_timeout = cfg_stale_timeout_r;
assign cfg_watchdog_period = cfg_watchdog_period_r;
assign cfg_cmd_valid = cfg_cmd_valid_r;
assign cfg_clear_status = cfg_clear_status_r;
assign cfg_clear_on_read = cfg_clear_on_read_r;
assign cfg_act_min = cfg_act_min_r;
assign cfg_act_max = cfg_act_max_r;
assign cfg_safe_fallback = cfg_safe_fallback_r;
assign cfg_status_clear_w1c = cfg_status_clear_w1c_r;
assign reg_rdata = reg_rdata_r;
assign reg_ready = reg_ready_r;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        cfg_mode_r <= 3'b000;
        cfg_enable_r <= 1'b0;
        cfg_seq_num_r <= 16'h0000;
        cfg_cmd_age_r <= 16'h0000;
        cfg_stale_timeout_r <= 16'h0000;
        cfg_watchdog_period_r <= 16'h0000;
        cfg_cmd_valid_r <= 1'b0;
        cfg_clear_status_r <= 1'b0;
        cfg_clear_on_read_r <= 1'b0;
        cfg_act_min_r <= 32'h00000000;
        cfg_act_max_r <= 32'h00000000;
        cfg_safe_fallback_r <= 32'h00000000;
        cfg_status_clear_w1c_r <= 1'b0;
        reg_rdata_r <= 64'h0000000000000000;
        reg_ready_r <= 1'b1;
    end else begin
        reg_ready_r <= 1'b1;
        if (reg_wr_en) begin
            case (reg_addr)
                8'h00: begin
                    cfg_mode_r <= reg_wdata[2:0];
                    cfg_enable_r <= reg_wdata[3];
                    cfg_cmd_valid_r <= reg_wdata[4];
                    cfg_clear_status_r <= reg_wdata[5];
                    cfg_clear_on_read_r <= reg_wdata[6];
                    cfg_status_clear_w1c_r <= reg_wdata[7];
                    cfg_seq_num_r <= reg_wdata[23:8];
                    cfg_cmd_age_r <= reg_wdata[39:24];
                    cfg_stale_timeout_r <= reg_wdata[55:40];
                    cfg_watchdog_period_r <= reg_wdata[63:56];
                end
                8'h08: begin
                    cfg_act_min_r <= reg_wdata[31:0];
                    cfg_act_max_r <= reg_wdata[63:32];
                end
                8'h10: begin
                    cfg_safe_fallback_r <= reg_wdata[31:0];
                end
                default: begin
                end
            endcase
        end
        if (reg_rd_en) begin
            case (reg_addr)
                8'h00: reg_rdata_r <= {reg_watchdog_period_pad, cfg_stale_timeout_r, cfg_cmd_age_r, cfg_seq_num_r, cfg_status_clear_w1c_r, cfg_clear_on_read_r, cfg_clear_status_r, cfg_cmd_valid_r, cfg_enable_r, cfg_mode_r};
                8'h08: reg_rdata_r <= {cfg_act_max_r, cfg_act_min_r};
                8'h10: reg_rdata_r <= {32'h00000000, cfg_safe_fallback_r};
                8'h18: reg_rdata_r <= {16'b0, 21'h000000, status_last_seq_in, status_fallback_active_in, status_clamp_event_in, status_invalid_cmd_fault_in, status_timeout_fault_in, status_stale_fault_in, 1'b0, 1'b1, cfg_enable_r, cfg_mode_r};
                8'h20: reg_rdata_r <= {4'b0, 39'h0000000000, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, status_fallback_active_in, status_clamp_event_in, status_invalid_cmd_fault_in, status_timeout_fault_in, status_stale_fault_in, 8'h00};
                default: reg_rdata_r <= 64'h0000000000000000;
            endcase
        end
    end
end

wire [7:0] reg_watchdog_period_pad = cfg_watchdog_period_r;
endmodule
