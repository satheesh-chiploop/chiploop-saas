// Auto-generated FPGA-only serialized transport shell.
// The verified core RTL remains unchanged; ASIC flows continue to use the core top.
module adaptive_aero_control_top_spi_fpga_top (
  input  logic clk,
  input  logic reset_n,
  input  logic spi_sclk,
  input  logic spi_cs_n,
  input  logic spi_mosi,
  output logic spi_miso,
  output logic fault_indicator
);
  localparam integer INPUT_BITS = 135;
  localparam integer OUTPUT_BITS = 177;
  logic [INPUT_BITS-1:0] rx_shift, rx_active;
  logic [OUTPUT_BITS-1:0] tx_shift, tx_snapshot;
  logic spi_active;
  logic spi_cs_meta, spi_cs_sync, spi_cs_prev;
  logic core_reg_wr_en;
  logic core_reg_rd_en;
  logic [7:0] core_reg_addr;
  logic [63:0] core_reg_wdata;
  logic core_sensor_valid;
  logic [15:0] core_sensor_speed_mps;
  logic [7:0] core_sensor_health;
  logic core_model_req_ready;
  logic core_model_rsp_valid;
  logic [31:0] core_model_rsp_data;
  logic core_actuator_cmd_ready;
  logic core_heartbeat_in;
  wire [63:0] core_reg_rdata;
  wire core_reg_ready;
  wire core_sensor_ready;
  wire core_model_req_valid;
  wire [31:0] core_model_req_data;
  wire core_model_rsp_ready;
  wire core_actuator_cmd_valid;
  wire [31:0] core_actuator_cmd_data;
  wire core_status_busy;
  wire core_status_ready;
  wire core_status_enabled;
  wire [2:0] core_status_mode;
  wire [15:0] core_status_speed_mps;
  wire core_status_stale_fault;
  wire core_status_timeout_fault;
  wire core_status_invalid_cmd_fault;
  wire core_status_clamp_event;
  wire core_status_fallback_active;
  wire [15:0] core_status_last_seq;
  wire core_irq;
  assign core_reg_wr_en = rx_active[0 +: 1];
  assign core_reg_rd_en = rx_active[1 +: 1];
  assign core_reg_addr = rx_active[2 +: 8];
  assign core_reg_wdata = rx_active[10 +: 64];
  assign core_sensor_valid = rx_active[74 +: 1];
  assign core_sensor_speed_mps = rx_active[75 +: 16];
  assign core_sensor_health = rx_active[91 +: 8];
  assign core_model_req_ready = rx_active[99 +: 1];
  assign core_model_rsp_valid = rx_active[100 +: 1];
  assign core_model_rsp_data = rx_active[101 +: 32];
  assign core_actuator_cmd_ready = rx_active[133 +: 1];
  assign core_heartbeat_in = rx_active[134 +: 1];
  wire [OUTPUT_BITS-1:0] core_response = {core_reg_rdata, core_reg_ready, core_sensor_ready, core_model_req_valid, core_model_req_data, core_model_rsp_ready, core_actuator_cmd_valid, core_actuator_cmd_data, core_status_busy, core_status_ready, core_status_enabled, core_status_mode, core_status_speed_mps, core_status_stale_fault, core_status_timeout_fault, core_status_invalid_cmd_fault, core_status_clamp_event, core_status_fallback_active, core_status_last_seq, core_irq};
  assign fault_indicator = 1'b0;
  // Chip select asynchronously clears only the frame-state bit. Data
  // registers use SPI clock alone, which is legal in ECP5 fabric.
  always_ff @(posedge spi_sclk or posedge spi_cs_n) begin
    if (spi_cs_n) spi_active <= 1'b0;
    else spi_active <= 1'b1;
  end
  always_ff @(posedge spi_sclk) begin
    if (!spi_cs_n) begin
      rx_shift <= {rx_shift[133:0], spi_mosi};
      if (!spi_active) tx_shift <= {tx_snapshot[175:0], 1'b0};
      else tx_shift <= {tx_shift[175:0], 1'b0};
    end
  end
  // Synchronize frame completion into the core clock domain. The host
  // keeps MOSI stable around CS rising as required by the protocol.
  always_ff @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
      spi_cs_meta <= 1'b1; spi_cs_sync <= 1'b1; spi_cs_prev <= 1'b1;
      rx_active <= '0; tx_snapshot <= '0;
    end else begin
      spi_cs_meta <= spi_cs_n; spi_cs_sync <= spi_cs_meta; spi_cs_prev <= spi_cs_sync;
      if (spi_cs_sync && !spi_cs_prev) rx_active <= rx_shift;
      tx_snapshot <= core_response;
    end
  end
  always_comb spi_miso = spi_active ? tx_shift[OUTPUT_BITS-1] : tx_snapshot[OUTPUT_BITS-1];
  adaptive_aero_control_top u_core (
    .clk(clk),
    .reset_n(reset_n),
    .reg_wr_en(core_reg_wr_en),
    .reg_rd_en(core_reg_rd_en),
    .reg_addr(core_reg_addr),
    .reg_wdata(core_reg_wdata),
    .reg_rdata(core_reg_rdata),
    .reg_ready(core_reg_ready),
    .sensor_valid(core_sensor_valid),
    .sensor_ready(core_sensor_ready),
    .sensor_speed_mps(core_sensor_speed_mps),
    .sensor_health(core_sensor_health),
    .model_req_valid(core_model_req_valid),
    .model_req_ready(core_model_req_ready),
    .model_req_data(core_model_req_data),
    .model_rsp_valid(core_model_rsp_valid),
    .model_rsp_ready(core_model_rsp_ready),
    .model_rsp_data(core_model_rsp_data),
    .actuator_cmd_valid(core_actuator_cmd_valid),
    .actuator_cmd_ready(core_actuator_cmd_ready),
    .actuator_cmd_data(core_actuator_cmd_data),
    .status_busy(core_status_busy),
    .status_ready(core_status_ready),
    .status_enabled(core_status_enabled),
    .status_mode(core_status_mode),
    .status_speed_mps(core_status_speed_mps),
    .status_stale_fault(core_status_stale_fault),
    .status_timeout_fault(core_status_timeout_fault),
    .status_invalid_cmd_fault(core_status_invalid_cmd_fault),
    .status_clamp_event(core_status_clamp_event),
    .status_fallback_active(core_status_fallback_active),
    .status_last_seq(core_status_last_seq),
    .heartbeat_in(core_heartbeat_in),
    .irq(core_irq)
  );
endmodule
