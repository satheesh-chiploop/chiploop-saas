module adaptive_aero_command_validator (
    clk,
    reset_n,
    cfg_seq_num,
    cfg_cmd_age,
    cfg_stale_timeout,
    cfg_cmd_valid,
    cfg_act_min,
    cfg_act_max,
    raw_cmd,
    raw_cmd_valid,
    validated_cmd,
    validated_cmd_valid,
    clamp_event,
    stale_fault,
    invalid_cmd_fault,
    seq_ok
);
input clk;
input reset_n;
input [15:0] cfg_seq_num;
input [15:0] cfg_cmd_age;
input [15:0] cfg_stale_timeout;
input cfg_cmd_valid;
input [31:0] cfg_act_min;
input [31:0] cfg_act_max;
input [31:0] raw_cmd;
input raw_cmd_valid;
output [31:0] validated_cmd;
output validated_cmd_valid;
output clamp_event;
output stale_fault;
output invalid_cmd_fault;
output seq_ok;

reg [31:0] validated_cmd_r;
reg validated_cmd_valid_r;
reg clamp_event_r;
reg stale_fault_r;
reg invalid_cmd_fault_r;
reg seq_ok_r;
reg [31:0] clamped_cmd;
reg [31:0] tmp_cmd;
reg clamp_low;
reg clamp_high;
reg stale_calc;
reg seq_calc;
reg invalid_calc;

assign validated_cmd = validated_cmd_r;
assign validated_cmd_valid = validated_cmd_valid_r;
assign clamp_event = clamp_event_r;
assign stale_fault = stale_fault_r;
assign invalid_cmd_fault = invalid_cmd_fault_r;
assign seq_ok = seq_ok_r;

always @(*) begin
    clamped_cmd = raw_cmd;
    clamp_low = 1'b0;
    clamp_high = 1'b0;
    stale_calc = 1'b0;
    seq_calc = 1'b1;
    invalid_calc = 1'b0;
    if (raw_cmd < cfg_act_min) begin
        clamped_cmd = cfg_act_min;
        clamp_low = 1'b1;
    end else if (raw_cmd > cfg_act_max) begin
        clamped_cmd = cfg_act_max;
        clamp_high = 1'b1;
    end
    if (cfg_cmd_age > cfg_stale_timeout) begin
        stale_calc = 1'b1;
    end
    if (!cfg_cmd_valid || !raw_cmd_valid) begin
        invalid_calc = 1'b1;
    end
    if (cfg_seq_num == 16'h0000) begin
        seq_calc = 1'b0;
    end
    tmp_cmd = clamped_cmd;
end

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        validated_cmd_r <= 32'h00000000;
        validated_cmd_valid_r <= 1'b0;
        clamp_event_r <= 1'b0;
        stale_fault_r <= 1'b0;
        invalid_cmd_fault_r <= 1'b0;
        seq_ok_r <= 1'b0;
    end else begin
        validated_cmd_r <= tmp_cmd;
        validated_cmd_valid_r <= cfg_cmd_valid & raw_cmd_valid & ~stale_calc & seq_calc & ~invalid_calc;
        clamp_event_r <= clamp_low | clamp_high;
        stale_fault_r <= stale_calc;
        invalid_cmd_fault_r <= invalid_calc;
        seq_ok_r <= seq_calc;
    end
end
endmodule
