module adaptive_aero_sensor_if (
    clk,
    reset_n,
    sensor_valid,
    sensor_ready,
    sensor_speed_mps,
    sensor_health,
    current_speed_mps,
    current_health,
    speed_sample_valid
);
input clk;
input reset_n;
input sensor_valid;
output sensor_ready;
input [15:0] sensor_speed_mps;
input [7:0] sensor_health;
output [15:0] current_speed_mps;
output [7:0] current_health;
output speed_sample_valid;

reg sensor_ready_r;
reg [15:0] current_speed_mps_r;
reg [7:0] current_health_r;
reg speed_sample_valid_r;

assign sensor_ready = sensor_ready_r;
assign current_speed_mps = current_speed_mps_r;
assign current_health = current_health_r;
assign speed_sample_valid = speed_sample_valid_r;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        sensor_ready_r <= 1'b1;
        current_speed_mps_r <= 16'h0000;
        current_health_r <= 8'h00;
        speed_sample_valid_r <= 1'b0;
    end else begin
        sensor_ready_r <= 1'b1;
        if (sensor_valid && sensor_ready_r) begin
            current_speed_mps_r <= sensor_speed_mps;
            current_health_r <= sensor_health;
            speed_sample_valid_r <= 1'b1;
        end
    end
end
endmodule
