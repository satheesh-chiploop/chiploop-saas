module adaptive_aero_safety_fsm (
    clk,
    reset_n,
    cfg_mode,
    cfg_enable,
    cfg_seq_num,
    cfg_cmd_age,
    cfg_stale_timeout,
    cfg_watchdog_period,
    cfg_cmd_valid,
    cfg_clear_status,
    cfg_clear_on_read,
    current_speed_mps,
    current_health,
    speed_sample_valid,
    heartbeat_in,
    validated_cmd,
    validated_cmd_valid,
    safe_fallback_cmd,
    status_busy,
    status_ready,
    status_enabled,
    status_mode,
    status_speed_mps,
    status_stale_fault,
    status_timeout_fault,
    status_invalid_cmd_fault,
    status_clamp_event,
    status_fallback_active,
    status_last_seq,
    actuator_cmd_valid,
    actuator_cmd_data,
    irq,
    actuator_cmd_ready
);
input clk;
input reset_n;
input [2:0] cfg_mode;
input cfg_enable;
input [15:0] cfg_seq_num;
input [15:0] cfg_cmd_age;
input [15:0] cfg_stale_timeout;
input [15:0] cfg_watchdog_period;
input cfg_cmd_valid;
input cfg_clear_status;
input cfg_clear_on_read;
input [15:0] current_speed_mps;
input [7:0] current_health;
input speed_sample_valid;
input heartbeat_in;
input [31:0] validated_cmd;
input validated_cmd_valid;
input [31:0] safe_fallback_cmd;
output status_busy;
output status_ready;
output status_enabled;
output [2:0] status_mode;
output [15:0] status_speed_mps;
output status_stale_fault;
output status_timeout_fault;
output status_invalid_cmd_fault;
output status_clamp_event;
output status_fallback_active;
output [15:0] status_last_seq;
output actuator_cmd_valid;
output [31:0] actuator_cmd_data;
output irq;
input actuator_cmd_ready;

reg status_busy_r;
reg status_ready_r;
reg status_enabled_r;
reg [2:0] status_mode_r;
reg [15:0] status_speed_mps_r;
reg status_stale_fault_r;
reg status_timeout_fault_r;
reg status_invalid_cmd_fault_r;
reg status_clamp_event_r;
reg status_fallback_active_r;
reg [15:0] status_last_seq_r;
reg actuator_cmd_valid_r;
reg [31:0] actuator_cmd_data_r;
reg irq_r;
reg [15:0] watchdog_cnt;
reg [15:0] last_heartbeat;
reg [15:0] last_seq_seen;

assign status_busy = status_busy_r;
assign status_ready = status_ready_r;
assign status_enabled = status_enabled_r;
assign status_mode = status_mode_r;
assign status_speed_mps = status_speed_mps_r;
assign status_stale_fault = status_stale_fault_r;
assign status_timeout_fault = status_timeout_fault_r;
assign status_invalid_cmd_fault = status_invalid_cmd_fault_r;
assign status_clamp_event = status_clamp_event_r;
assign status_fallback_active = status_fallback_active_r;
assign status_last_seq = status_last_seq_r;
assign actuator_cmd_valid = actuator_cmd_valid_r;
assign actuator_cmd_data = actuator_cmd_data_r;
assign irq = irq_r;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        status_busy_r <= 1'b0;
        status_ready_r <= 1'b1;
        status_enabled_r <= 1'b0;
        status_mode_r <= 3'b000;
        status_speed_mps_r <= 16'h0000;
        status_stale_fault_r <= 1'b0;
        status_timeout_fault_r <= 1'b0;
        status_invalid_cmd_fault_r <= 1'b0;
        status_clamp_event_r <= 1'b0;
        status_fallback_active_r <= 1'b1;
        status_last_seq_r <= 16'h0000;
        actuator_cmd_valid_r <= 1'b0;
        actuator_cmd_data_r <= 32'h00000000;
        irq_r <= 1'b0;
        watchdog_cnt <= 16'h0000;
        last_heartbeat <= 16'h0000;
        last_seq_seen <= 16'h0000;
    end else begin
        status_mode_r <= cfg_mode;
        status_enabled_r <= cfg_enable;
        if (speed_sample_valid) begin
            status_speed_mps_r <= current_speed_mps;
        end
        if (heartbeat_in) begin
            watchdog_cnt <= 16'h0000;
            last_heartbeat <= last_heartbeat + 16'h0001;
        end else if (watchdog_cnt != cfg_watchdog_period) begin
            watchdog_cnt <= watchdog_cnt + 16'h0001;
        end
        status_stale_fault_r <= (cfg_cmd_age > cfg_stale_timeout) | ~cfg_cmd_valid;
        status_timeout_fault_r <= (watchdog_cnt >= cfg_watchdog_period) & (cfg_watchdog_period != 16'h0000);
        status_invalid_cmd_fault_r <= ~cfg_cmd_valid;
        status_clamp_event_r <= validated_cmd_valid & ((validated_cmd != safe_fallback_cmd) | (current_health != 8'h00));
        status_last_seq_r <= cfg_seq_num;
        status_fallback_active_r <= (~cfg_enable) | status_stale_fault_r | status_timeout_fault_r | status_invalid_cmd_fault_r;
        status_busy_r <= ~status_ready_r;
        status_ready_r <= cfg_enable & validated_cmd_valid & ~status_stale_fault_r & ~status_timeout_fault_r & ~status_invalid_cmd_fault_r;
        if (status_fallback_active_r) begin
            actuator_cmd_valid_r <= 1'b1;
            actuator_cmd_data_r <= safe_fallback_cmd;
        end else begin
            actuator_cmd_valid_r <= validated_cmd_valid;
            actuator_cmd_data_r <= validated_cmd;
        end
        irq_r <= status_stale_fault_r | status_timeout_fault_r | status_invalid_cmd_fault_r | status_clamp_event_r | status_fallback_active_r;
        if (cfg_clear_status | cfg_clear_on_read) begin
            status_stale_fault_r <= 1'b0;
            status_timeout_fault_r <= 1'b0;
            status_invalid_cmd_fault_r <= 1'b0;
            status_clamp_event_r <= 1'b0;
        end
        if (actuator_cmd_ready) begin
            last_seq_seen <= cfg_seq_num;
        end
    end
end
endmodule
