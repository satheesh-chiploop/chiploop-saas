module adaptive_aero_control_top (
    clk,
    reset_n,
    reg_wr_en,
    reg_rd_en,
    reg_addr,
    reg_wdata,
    reg_rdata,
    reg_ready,
    sensor_valid,
    sensor_ready,
    sensor_speed_mps,
    sensor_health,
    model_req_valid,
    model_req_ready,
    model_req_data,
    model_rsp_valid,
    model_rsp_ready,
    model_rsp_data,
    actuator_cmd_valid,
    actuator_cmd_ready,
    actuator_cmd_data,
    status_busy,
    status_ready,
    status_enabled,
    status_mode,
    status_speed_mps,
    status_stale_fault,
    status_timeout_fault,
    status_invalid_cmd_fault,
    status_clamp_event,
    status_fallback_active,
    status_last_seq,
    heartbeat_in,
    irq
);
input clk;
input reset_n;
input reg_wr_en;
input reg_rd_en;
input [7:0] reg_addr;
input [63:0] reg_wdata;
output [63:0] reg_rdata;
output reg_ready;
input sensor_valid;
output sensor_ready;
input [15:0] sensor_speed_mps;
input [7:0] sensor_health;
output model_req_valid;
input model_req_ready;
output [31:0] model_req_data;
input model_rsp_valid;
output model_rsp_ready;
input [31:0] model_rsp_data;
output actuator_cmd_valid;
input actuator_cmd_ready;
output [31:0] actuator_cmd_data;
output status_busy;
output status_ready;
output status_enabled;
output [2:0] status_mode;
output [15:0] status_speed_mps;
output status_stale_fault;
output status_timeout_fault;
output status_invalid_cmd_fault;
output status_clamp_event;
output status_fallback_active;
output [15:0] status_last_seq;
input heartbeat_in;
output irq;
wire [2:0] cfg_mode;
wire cfg_enable;
wire [15:0] cfg_seq_num;
wire [15:0] cfg_cmd_age;
wire [15:0] cfg_stale_timeout;
wire [15:0] cfg_watchdog_period;
wire cfg_cmd_valid;
wire cfg_clear_status;
wire cfg_clear_on_read;
wire [31:0] cfg_act_min;
wire [31:0] cfg_act_max;
wire [31:0] cfg_safe_fallback;
wire cfg_status_clear_w1c;
wire [15:0] status_last_seq_in;
wire status_stale_fault_in;
wire status_timeout_fault_in;
wire status_invalid_cmd_fault_in;
wire status_clamp_event_in;
wire status_fallback_active_in;
wire [15:0] current_speed_mps;
wire [7:0] current_health;
wire speed_sample_valid;
wire [31:0] validated_cmd;
wire validated_cmd_valid;
wire clamp_event;
wire stale_fault;
wire invalid_cmd_fault;
wire seq_ok;

wire liveness_ok;
wire [7:0] completion_code;
wire [7:0] fault_code;

adaptive_aero_register_window u_adaptive_aero_register_window (
    .clk(clk),
    .reset_n(reset_n),
    .reg_wr_en(reg_wr_en),
    .reg_rd_en(reg_rd_en),
    .reg_addr(reg_addr),
    .reg_wdata(reg_wdata),
    .reg_rdata(reg_rdata),
    .reg_ready(reg_ready),
    .cfg_mode(cfg_mode),
    .cfg_enable(cfg_enable),
    .cfg_seq_num(cfg_seq_num),
    .cfg_cmd_age(cfg_cmd_age),
    .cfg_stale_timeout(cfg_stale_timeout),
    .cfg_watchdog_period(cfg_watchdog_period),
    .cfg_cmd_valid(cfg_cmd_valid),
    .cfg_clear_status(cfg_clear_status),
    .cfg_clear_on_read(cfg_clear_on_read),
    .cfg_act_min(cfg_act_min),
    .cfg_act_max(cfg_act_max),
    .cfg_safe_fallback(cfg_safe_fallback),
    .cfg_status_clear_w1c(cfg_status_clear_w1c),
    .status_last_seq_in(status_last_seq_in),
    .status_stale_fault_in(status_stale_fault_in),
    .status_timeout_fault_in(status_timeout_fault_in),
    .status_invalid_cmd_fault_in(status_invalid_cmd_fault_in),
    .status_clamp_event_in(status_clamp_event_in),
    .status_fallback_active_in(status_fallback_active_in)
);

adaptive_aero_sensor_if u_adaptive_aero_sensor_if (
    .clk(clk),
    .reset_n(reset_n),
    .sensor_valid(sensor_valid),
    .sensor_ready(sensor_ready),
    .sensor_speed_mps(sensor_speed_mps),
    .sensor_health(sensor_health),
    .current_speed_mps(current_speed_mps),
    .current_health(current_health),
    .speed_sample_valid(speed_sample_valid)
);

adaptive_aero_command_validator u_adaptive_aero_command_validator (
    .clk(clk),
    .reset_n(reset_n),
    .cfg_seq_num(cfg_seq_num),
    .cfg_cmd_age(cfg_cmd_age),
    .cfg_stale_timeout(cfg_stale_timeout),
    .cfg_cmd_valid(cfg_cmd_valid),
    .cfg_act_min(cfg_act_min),
    .cfg_act_max(cfg_act_max),
    .raw_cmd(cfg_safe_fallback),
    .raw_cmd_valid(cfg_cmd_valid),
    .validated_cmd(validated_cmd),
    .validated_cmd_valid(validated_cmd_valid),
    .clamp_event(clamp_event),
    .stale_fault(stale_fault),
    .invalid_cmd_fault(invalid_cmd_fault),
    .seq_ok(seq_ok)
);

adaptive_aero_transport_bridge u_adaptive_aero_transport_bridge (
    .clk(clk),
    .reset_n(reset_n),
    .cfg_mode(cfg_mode),
    .cfg_seq_num(cfg_seq_num),
    .cfg_enable(cfg_enable),
    .model_req_valid(model_req_valid),
    .model_req_ready(model_req_ready),
    .model_req_data(model_req_data),
    .model_rsp_valid(model_rsp_valid),
    .model_rsp_ready(model_rsp_ready),
    .model_rsp_data(model_rsp_data),
    .liveness_ok(liveness_ok),
    .completion_code(completion_code),
    .fault_code(fault_code)
);

adaptive_aero_safety_fsm u_adaptive_aero_safety_fsm (
    .clk(clk),
    .reset_n(reset_n),
    .cfg_mode(cfg_mode),
    .cfg_enable(cfg_enable),
    .cfg_seq_num(cfg_seq_num),
    .cfg_cmd_age(cfg_cmd_age),
    .cfg_stale_timeout(cfg_stale_timeout),
    .cfg_watchdog_period(cfg_watchdog_period),
    .cfg_cmd_valid(cfg_cmd_valid),
    .cfg_clear_status(cfg_clear_status),
    .cfg_clear_on_read(cfg_clear_on_read),
    .current_speed_mps(current_speed_mps),
    .current_health(current_health),
    .speed_sample_valid(speed_sample_valid),
    .heartbeat_in(heartbeat_in),
    .validated_cmd(validated_cmd),
    .validated_cmd_valid(validated_cmd_valid),
    .safe_fallback_cmd(cfg_safe_fallback),
    .status_busy(status_busy),
    .status_ready(status_ready),
    .status_enabled(status_enabled),
    .status_mode(status_mode),
    .status_speed_mps(status_speed_mps),
    .status_stale_fault(status_stale_fault),
    .status_timeout_fault(status_timeout_fault),
    .status_invalid_cmd_fault(status_invalid_cmd_fault),
    .status_clamp_event(status_clamp_event),
    .status_fallback_active(status_fallback_active),
    .status_last_seq(status_last_seq),
    .actuator_cmd_valid(actuator_cmd_valid),
    .actuator_cmd_data(actuator_cmd_data),
    .irq(irq),
    .actuator_cmd_ready(actuator_cmd_ready)
);

assign status_last_seq_in = status_last_seq;
assign status_stale_fault_in = status_stale_fault;
assign status_timeout_fault_in = status_timeout_fault;
assign status_invalid_cmd_fault_in = status_invalid_cmd_fault;
assign status_clamp_event_in = status_clamp_event;
assign status_fallback_active_in = status_fallback_active;

endmodule
