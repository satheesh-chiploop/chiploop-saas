# System Software CoSim Harness Summary

- Generated at: `2026-09-16T18:06:43.562085+00:00`
- L1 ready: `True`
- Harness status: `ready`
- Scenario count: `9`

## Blocked dependencies
- none

## Resolved commands
- `control_service_boot_smoke` → `make -C /root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/a2a3259a-2aa3-4b5f-a267-b0080ac33a7a/0a3d6e1a-819c-41ba-be66-018d47c49598/system/system/restored_rtl_sim/6f5eef13-5f22-4388-a297-ba3156910590/vv/tb`
- `control_service_boot_smoke` → `cargo run -p ss_app_control_service -- --scenario control_service_boot_smoke`
- `control_service_register_rw_basic` → `cargo run -p ss_app_control_service -- --scenario control_service_register_rw_basic`
- `diagnostics_boot_smoke` → `cargo run -p ss_app_diagnostics -- --scenario diagnostics_boot_smoke`
- `diagnostics_register_rw_basic` → `cargo run -p ss_app_diagnostics -- --scenario diagnostics_register_rw_basic`
- `demo_cli_boot_smoke` → `cargo run -p ss_app_demo_cli -- --scenario demo_cli_boot_smoke`
- `demo_cli_register_rw_basic` → `cargo run -p ss_app_demo_cli -- --scenario demo_cli_register_rw_basic`
