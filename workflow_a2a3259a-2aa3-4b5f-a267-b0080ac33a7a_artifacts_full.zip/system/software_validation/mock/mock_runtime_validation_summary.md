# Mock Runtime Validation

- Status: **pass**
- Build root: `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/a2a3259a-2aa3-4b5f-a267-b0080ac33a7a/0a3d6e1a-819c-41ba-be66-018d47c49598/system/restored_system_software/system/software`
- Mock manifest present: `True`
- Mock root present: `True`
- Cargo: `/root/.cargo/bin/cargo`
- Command: `/root/.cargo/bin/cargo test --workspace --all-targets`
- Return code: `0`
