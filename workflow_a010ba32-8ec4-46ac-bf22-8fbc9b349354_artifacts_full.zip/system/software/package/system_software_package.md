# System Software Package

- Generated at: 2026-08-11T20:05:52.236759+00:00
- Source workflow id: 4abcd6e9-433b-4903-ba67-eff79da91e74
- Artifact count: 27
- Inferred required files added: 0
- Package status: `complete`
- Entry binary: `ss_app_control_service`

## Artifacts

- `system/software/sdk/adaptive_aero_control/Cargo.toml`
- `system/software/sdk/adaptive_aero_control/src/lib.rs`
- `system/software/sdk/adaptive_aero_control/examples/basic.rs`
- `system/software/sdk/adaptive_aero_control/src/bin/diag_cli.rs`
- `system/software/sdk/adaptive_aero_control/config/default.toml`
- `system/software/apps/control_service/src/main.rs`
- `system/software/apps/control_service/Cargo.toml`
- `system/software/apps/diagnostics/src/main.rs`
- `system/software/apps/diagnostics/Cargo.toml`
- `system/software/apps/demo_cli/src/main.rs`
- `system/software/apps/demo_cli/Cargo.toml`
- `system/software/Cargo.toml`
- `system/software/Makefile`
- `system/software/build_plan.json`
- `system/software/adapter/adaptive_aero_control_adapter/src/adapter/register_adapter.rs`
- `system/software/adapter/adaptive_aero_control_adapter/src/adapter/device_adapter.rs`
- `system/software/adapter/adaptive_aero_control_adapter/src/error.rs`
- `system/software/adapter/adaptive_aero_control_adapter/Cargo.toml`
- `system/software/adapter/adaptive_aero_control_adapter/src/lib.rs`
- `system/software/adapter/adaptive_aero_control_adapter/src/adapter/mod.rs`
- `system/software/services/src/init_manager.rs`
- `system/software/services/src/health_monitor.rs`
- `system/software/services/src/control_service.rs`
- `system/software/services/src/interrupt_service.rs`
- `system/software/services/src/error.rs`
- `system/software/services/Cargo.toml`
- `system/software/services/src/lib.rs`
