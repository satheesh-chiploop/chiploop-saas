# System Software HAL/Driver Adapter

- Generated at: 2026-08-11T20:05:44.303872+00:00
- Source workflow id: 4abcd6e9-433b-4903-ba67-eff79da91e74
- Adapter crate: `adaptive_aero_control_adapter`
- Adapter package: `adaptive_aero_control_adapter`

## Adapter contract

- `hal_path` → `firmware/hal/registers.rs`
- `driver_path` → `firmware/drivers/driver_scaffold.rs`
- `register_map_path` → `firmware/register_map.json`
- `interrupt_mapping_path` → `firmware/isr/interrupt_map.json`
- `dma_integration_path` → `unavailable`

## Generated files

- `system/software/adapter/adaptive_aero_control_adapter/src/adapter/register_adapter.rs`
- `system/software/adapter/adaptive_aero_control_adapter/src/adapter/device_adapter.rs`
- `system/software/adapter/adaptive_aero_control_adapter/src/error.rs`
- `system/software/adapter/adaptive_aero_control_adapter/Cargo.toml`
- `system/software/adapter/adaptive_aero_control_adapter/src/lib.rs`
- `system/software/adapter/adaptive_aero_control_adapter/src/adapter/mod.rs`
