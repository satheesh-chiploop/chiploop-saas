
use adaptive_aero_control::Sdk;
use std::env;

fn main() {
    let args: Vec<String> = env::args().collect();
    let scenario = args.iter()
        .position(|x| x == "--scenario")
        .and_then(|i| args.get(i+1))
        .map(|s| s.as_str())
        .unwrap_or("default");

    let sdk = Sdk::new();
    let status = sdk.get_status();

    println!("app=demo_cli scenario={} status={:?}", scenario, status);

    if scenario.contains("register") {
        println!("register_write=0x10");
    }

    if scenario.contains("interrupt") {
        println!("interrupt_triggered=1");
    }
}
