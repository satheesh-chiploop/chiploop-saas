# System Software Applications

- Generated at: 2026-08-11T20:05:50.177869+00:00
- Source workflow id: 4abcd6e9-433b-4903-ba67-eff79da91e74
- Crate name: `adaptive_aero_control`

## Applications

- `control_service` → package `ss_app_control_service`
- `diagnostics` → package `ss_app_diagnostics`
- `demo_cli` → package `ss_app_demo_cli`

## Files

- `system/software/apps/control_service/src/main.rs`
- `system/software/apps/control_service/Cargo.toml`
- `system/software/apps/diagnostics/src/main.rs`
- `system/software/apps/diagnostics/Cargo.toml`
- `system/software/apps/demo_cli/src/main.rs`
- `system/software/apps/demo_cli/Cargo.toml`
