# System Software Config Schema

- Generated at: 2026-08-11T20:05:45.230937+00:00
- Source workflow id: 4abcd6e9-433b-4903-ba67-eff79da91e74

## Feature toggles

- `interrupt_control` → `True`
- `dma_control` → `False`
- `power_mode_control` → `False`
- `clock_control` → `False`
- `reset_control` → `False`

## Generated files

- `system/software/config/default_config.json`
- `system/software/config/default_runtime_config.json`
- `system/software/config/default_runtime_config.toml`
