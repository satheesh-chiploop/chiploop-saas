# System Software Capability Model

- Generated at: 2026-08-11T20:05:40.038869+00:00
- Source workflow id: 4abcd6e9-433b-4903-ba67-eff79da91e74

## Platform identity

- Top module: `adaptive_aero_control_top`
- RTL file count: `2`

## Software services

- `register_access` → `True`
- `driver_layer` → `True`
- `interrupt_control` → `True`
- `dma_control` → `False`
- `boot_orchestration` → `False`
- `clock_control` → `False`
- `reset_control` → `False`
- `power_mode_control` → `False`
- `runtime_validation_support` → `True`

## Register model

- Register count: `9`
- Field count: `45`
- Bus: `AXI_LITE`

## Constraints

- system_integration_intent_missing
- firmware_elf_missing
- system_firmware_execution_blocked
- system_integration_intent_path_missing
