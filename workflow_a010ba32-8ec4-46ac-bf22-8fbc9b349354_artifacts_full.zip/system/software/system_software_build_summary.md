# System Software Build System

- Generated at: 2026-08-11T20:05:51.467161+00:00
- Source workflow id: 4abcd6e9-433b-4903-ba67-eff79da91e74

## Workspace members

- `sdk/adaptive_aero_control`
- `services`
- `adapter/adaptive_aero_control_adapter`
- `apps/control_service`
- `apps/diagnostics`
- `apps/demo_cli`

## Files

- `system/software/Cargo.toml`
- `system/software/Makefile`
- `system/software/build_plan.json`
