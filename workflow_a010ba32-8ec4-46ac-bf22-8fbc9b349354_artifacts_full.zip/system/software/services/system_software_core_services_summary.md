# System Software Core Services

- Generated at: 2026-08-11T20:05:48.302855+00:00
- Source workflow id: 4abcd6e9-433b-4903-ba67-eff79da91e74
- Service count: 4

## Services

- `init_manager`
- `health_monitor`
- `control_service`
- `interrupt_service`

## Files

- `system/software/services/src/init_manager.rs`
- `system/software/services/src/health_monitor.rs`
- `system/software/services/src/control_service.rs`
- `system/software/services/src/interrupt_service.rs`
- `system/software/services/src/error.rs`
- `system/software/services/Cargo.toml`
- `system/software/services/src/lib.rs`
