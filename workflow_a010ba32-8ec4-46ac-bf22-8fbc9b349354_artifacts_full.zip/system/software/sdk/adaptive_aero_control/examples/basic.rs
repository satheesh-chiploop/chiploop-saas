use adaptive_aero_control::Sdk;

fn main() {
    let sdk = Sdk::new();
    let _ = sdk.get_status();
    println!("system software example app initialized");
}
