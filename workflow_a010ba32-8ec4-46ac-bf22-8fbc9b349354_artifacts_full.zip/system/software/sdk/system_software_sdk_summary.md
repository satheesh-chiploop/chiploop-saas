# System Software SDK Scaffold Summary

- Generated at: 2026-08-11T20:05:42.655790+00:00
- Source workflow id: 4abcd6e9-433b-4903-ba67-eff79da91e74
- Target language: `rust`
- Build system: `cargo`
- Crate name: `adaptive_aero_control`

## Generated files

- `system/software/sdk/adaptive_aero_control/Cargo.toml`
- `system/software/sdk/adaptive_aero_control/src/lib.rs`
- `system/software/sdk/adaptive_aero_control/examples/basic.rs`
- `system/software/sdk/adaptive_aero_control/src/bin/diag_cli.rs`
- `system/software/sdk/adaptive_aero_control/config/default.toml`
