# Monitor And Checker Plan

- Source: generated_from_spec
- Top module: `pwm_controller`
- Clock observations: `clk`
- Reset observations: `reset_n`

## Monitors
- Clock/reset monitor: observes reset assertion/deassertion and first active clock edges.
- Input stimulus monitor: records driven values on declared non-clock/reset inputs.
- Output response monitor: samples declared outputs after reset release and after stimulus changes.
- Coverage monitor: calls `CoverageModel.sample()` at transaction/checkpoint boundaries.

## Observed Inputs
- `enable`
- `duty_cycle`
- `period`

## Observed Outputs
- `pwm_out`
- `counter_value`

## Checkers
- Reset known-value checker: outputs must not remain unknown after reset release and settle.
- Width/value checker: sampled signals are interpreted using spec-declared widths.
- Scenario checker: directed tests should encode expected responses from the verification plan.
- Scoreboard hook: `Scoreboard` is loaded when `scoreboard.py` is present and can compare expected versus observed transactions.
- SVA hook: generated SVA/bind files are included through `verification_sources.mk` when available.

## Coverage Coupling
- Functional output points: `pwm_out`, `counter_value`
- Functional input points: `clk`, `reset_n`, `enable`, `duty_cycle`, `period`

## Feature Checkers
- `reset_clears_outputs_and_counter`: monitors=['counter_value', 'pwm_out']; status=executable; reason=explicit expected behavior
- `counting_advances_when_enabled`: monitors=['counter_value', 'pwm_out', 'enable']; status=executable; reason=explicit expected behavior
- `counter_holds_when_disabled`: monitors=['counter_value', 'pwm_out', 'enable']; status=executable; reason=explicit expected behavior
- `pwm_deasserts_at_or_above_duty`: monitors=['pwm_out']; status=executable; reason=explicit expected behavior
- `rollover_on_period`: monitors=['counter_value', 'pwm_out', 'period']; status=executable; reason=explicit expected behavior

## Review Checklist
- Confirm each important requirement has a monitor point.
- Confirm each monitor feeds a checker, scoreboard, assertion, or coverage point.
- Add directed tests or custom scoreboard logic for behavior that cannot be inferred from ports alone.
