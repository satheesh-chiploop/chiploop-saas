# System Firmware CoSim Execution Summary

- Generated at: 2026-06-10T19:25:50.458851
- Execution mode: artifact_readiness_only
- Overall status: blocked_missing_inputs
- Readiness: blocked

## Key Inputs

- SoC top: `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/9e8732bc-5b2c-4d87-ae22-972f29b4e4ac/91efa996-34b4-4a18-a18f-453952d3dcae/digital/system/imported_rtl/temp_monitor_soc_sim.sv`
- Firmware ELF: `firmware/build/target/x86_64-unknown-linux-gnu/release/firmware_app.elf`
- Cocotb Makefile: `firmware/validate/Makefile`
- Test files: `1`
- Verilog/SystemVerilog files: `4`

## Missing Required Inputs

- firmware_elf_path

## Planned Test Matrix

- test_firmware_smoke.py | seed=1 | status=planned
- test_firmware_smoke.py | seed=2 | status=planned

## Notes

- Execution was not attempted because one or more required inputs were missing.
- No coverage model detected; downstream summary should avoid reporting functional coverage percentages.
- No digital assertions collateral detected; assertion coverage should remain unavailable, not fabricated.
- Firmware ELF was not detected; this run should be treated as not executable, not as a passing simulation.

## Conclusion

The co-simulation bundle is incomplete. Downstream agents should treat coverage as unavailable rather than infer passing results.
