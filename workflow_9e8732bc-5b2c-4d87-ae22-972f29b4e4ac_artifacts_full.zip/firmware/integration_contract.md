# Contract Overview

- Defines the global integration contract for Embedded_Run / full-chain firmware operation.
- Specifies the firmware-facing APIs, expected call/response behavior, error reporting, and versioning rules.
- Establishes ownership boundaries between firmware, system/host software, and validation.
- Defines logging schema expectations for integration and field diagnostics.
- Defines power-mode and readiness semantics at the firmware/system boundary.
- Defines compatibility policy for future firmware and host updates.
- Provides validation hooks to verify contract compliance in integration testing.

# Contract Version + Compatibility Policy

- **Contract version:** `1.0.0`
- **Compatibility model:** semantic versioning
  - **MAJOR**: incompatible interface or behavior changes
  - **MINOR**: backward-compatible additions
  - **PATCH**: clarifications, bug fixes, non-behavioral updates
- **Compatibility rule:** firmware must reject or explicitly flag unsupported major-version mismatches at initialization time.
- **Default expectation:** host/system software is backward-compatible with the latest released firmware MINOR/PATCH within the same MAJOR.
- **Version reporting:** firmware shall expose its contract version and firmware build version in the boot/status path.

# Interfaces

## Firmware Runtime Interfaces

| Interface | Direction | Behavior | Success Criteria | Error Handling |
|---|---|---|---|---|
| `Init()` | System/Host → FW | Initializes firmware runtime, internal state, and dependencies required for Embedded_Run | Returns ready state or equivalent completion status | Returns a defined initialization error code on failure |
| `Run()` | System/Host → FW | Enters normal operating state and maintains runtime service execution | Firmware reaches operational state and remains responsive | Returns or reports a runtime error code if it cannot enter or sustain operation |
| `GetStatus()` | System/Host ↔ FW | Retrieves current firmware state, readiness, and summary health | Returns a structured status snapshot | Returns status error if data is unavailable or invalid |
| `GetVersion()` | System/Host ↔ FW | Returns firmware build version and contract version | Version tuple is returned consistently | Returns version-unavailable error only if storage is corrupted or uninitialized |
| `SetPowerMode(mode)` | System/Host → FW | Requests supported power mode transition | Transition accepted only if allowed by current state | Returns unsupported/invalid-state error for disallowed transitions |
| `RequestShutdown()` | System/Host → FW | Requests controlled shutdown or stop sequence | Firmware acknowledges and transitions to safe stopped state | Returns failure if shutdown cannot be safely initiated |
| `ReportFault(code, context)` | FW → System/Host | Reports runtime fault with code and context | Fault is logged and surfaced through status/log path | N/A; must not silently drop critical faults |

## Status and Readiness Model

| State | Meaning | Host Expectation |
|---|---|---|
| `RESET` | Firmware not yet initialized | No runtime API dependence |
| `INIT` | Firmware initialization in progress | Poll status or wait for ready indication |
| `READY` | Firmware ready for normal operation | Safe to issue runtime requests |
| `RUNNING` | Firmware actively servicing runtime workload | Monitor health and fault indications |
| `DEGRADED` | Firmware operational with reduced capability | Host should limit nonessential requests |
| `FAULT` | Firmware encountered unrecoverable or latched fault | Host should stop normal operation and follow recovery policy |
| `SHUTDOWN` | Firmware has completed stop sequence | Host must not issue runtime requests |

## Logging Schema

| Field | Required | Description |
|---|---|---|
| `timestamp` | Yes | Monotonic or absolute time associated with event |
| `level` | Yes | Severity such as DEBUG, INFO, WARN, ERROR, FATAL |
| `component` | Yes | Firmware component or module name |
| `event_id` | Yes | Stable event identifier for machine parsing |
| `message` | Yes | Human-readable event text |
| `error_code` | No | Present for error/fault events |
| `context` | No | Structured key/value diagnostic data |
| `version` | Yes | Firmware or contract version associated with the event |

Logging requirements:
- Event identifiers must be stable across patch releases.
- Error events must include a machine-readable error code.
- Logs used for contract compliance must be parseable without relying on free-form text.
- Firmware must not emit ambiguous duplicate event IDs for different failure classes.

## Error Code Policy

| Class | Range/Pattern | Meaning |
|---|---|---|
| `OK` | `0` | Operation completed successfully |
| `E_INIT_*` | Initialization failures | Failure during startup or dependency setup |
| `E_STATE_*` | Invalid state or transition | API called in wrong state or illegal transition requested |
| `E_PARAM_*` | Invalid parameter | Bad input or out-of-range value |
| `E_HW_*` | Hardware dependency failure | Underlying hardware/resource failure |
| `E_TIMEOUT_*` | Operation timed out | Response not completed within allowed interval |
| `E_UNSUPPORTED_*` | Unsupported feature or mode | Requested feature not implemented or allowed |
| `E_FAULT_*` | Internal fault | Firmware-detected unrecoverable condition |

Rules:
- Error codes must be stable within a MAJOR version.
- Minor/PATCH releases may add new codes but must not repurpose existing ones.
- Host/system software must treat unknown nonzero codes as generic failure unless documented otherwise.

## Power Mode Semantics

| Mode | Firmware Behavior | Host Responsibility |
|---|---|---|
| `ACTIVE` | Full runtime capability enabled | May issue normal runtime requests |
| `LOW_POWER` | Reduced activity, limited background service, wake-capable if supported | Avoid nonessential requests; respect reduced availability |
| `SLEEP` | Runtime execution suspended or minimized per platform policy | Host must not assume immediate service availability |
| `OFF` | Firmware inactive or power-gated | Host must reinitialize on restore |

Rules:
- Power mode transitions are valid only if the current state permits them.
- Firmware must return explicit unsupported or invalid-state errors for illegal requests.
- Host must not infer readiness from power mode alone; readiness must come from status/ready signaling.

# Ownership Boundaries

| Area | Firmware (FW) | System/Host | Validation |
|---|---|---|---|
| Contract implementation | Owns behavior, state transitions, and error reporting | Consumes the contract | Verifies contract adherence |
| Initialization and runtime sequencing | Implements init/run/shutdown semantics | Calls APIs in supported order | Tests legal and illegal sequences |
| Status and readiness | Publishes state and readiness | Polls/consumes status | Confirms timing and correctness |
| Logging | Emits structured events and codes | Collects and stores logs | Checks schema, IDs, and severity mapping |
| Versioning | Reports firmware and contract versions | Uses version to gate compatibility | Validates compatibility behavior |
| Power modes | Implements supported transitions | Requests modes within policy | Verifies transition legality and outcomes |

# Assumptions

- Host/system software can access firmware status and version information through a defined integration path.
- All interface names above map to the actual platform entry points or message handlers used in Embedded_Run.
- A monotonic or otherwise ordered timestamp source is available for logs.
- The platform defines the actual supported power modes; unsupported modes must be rejected cleanly.
- Validation can observe logs, status, and return codes during integration testing.
- No interrupt, DMA, or BOOT-ONLY-specific contract was requested in this specification.

# Validation Hooks

- Verify `GetVersion()` returns the correct firmware version and contract version on every boot.
- Exercise `Init()` → `Run()` → `RequestShutdown()` in supported order and confirm expected state transitions.
- Call each API with invalid state and confirm deterministic `E_STATE_*` or equivalent error handling.
- Inject invalid parameters and confirm `E_PARAM_*` handling without undefined behavior.
- Force dependency failures and confirm `E_HW_*` or `E_INIT_*` classification as appropriate.
- Validate that every error event emits a structured log entry with `event_id`, `error_code`, and `component`.
- Confirm log event IDs remain stable across PATCH updates.
- Confirm firmware rejects unsupported MAJOR contract versions or flags incompatibility explicitly.
- Verify power mode transitions only succeed from allowed states and produce explicit failures otherwise.
- Confirm `GetStatus()` reflects `RESET`, `INIT`, `READY`, `RUNNING`, `DEGRADED`, `FAULT`, and `SHUTDOWN` as applicable to the platform implementation.