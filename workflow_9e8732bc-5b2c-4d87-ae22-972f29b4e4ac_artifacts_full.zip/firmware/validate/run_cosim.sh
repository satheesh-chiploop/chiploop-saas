#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT_DIR=$(cd "${SCRIPT_DIR}/../.." && pwd)
VALIDATE_DIR="${ROOT_DIR}/firmware/validate"
BUILD_DIR="${BUILD_DIR:-${VALIDATE_DIR}/build}"
OUT_DIR="${COSIM_OUT:-${VALIDATE_DIR}/out}"

RTL_TOP=${RTL_TOP:-<RTL_TOP>}
RTL_DIR=${RTL_DIR:-<RTL_DIR>}
FILELIST=${FILELIST:-<FILELIST>}

mkdir -p "${BUILD_DIR}" "${OUT_DIR}"

VERILATOR_BUILD_MD="${VALIDATE_DIR}/verilator_build.md"

build_rtl() {
  if [[ -f "${VERILATOR_BUILD_MD}" ]]; then
    echo "Using build steps from ${VERILATOR_BUILD_MD}"
    if command -v python3 >/dev/null 2>&1; then
      python3 - <<'PY'
from pathlib import Path
p = Path("firmware/validate/verilator_build.md")
print(p.read_text())
PY
    fi
  fi

  if [[ "${FILELIST}" == "<FILELIST>" || "${RTL_TOP}" == "<RTL_TOP>" ]]; then
    echo "RTL_TOP/FILELIST placeholders are not overridden; skipping explicit Verilator invocation" >&2
    return 0
  fi

  verilator --cc \
    --top-module "${RTL_TOP}" \
    --Mdir "${BUILD_DIR}" \
    -f "${FILELIST}"
}

build_fw() {
  if [[ -f "${ROOT_DIR}/firmware/Makefile" || -d "${ROOT_DIR}/firmware" ]]; then
    if make -C "${ROOT_DIR}/firmware" -n build >/dev/null 2>&1; then
      make -C "${ROOT_DIR}/firmware" build
    fi
  fi
}

run_pytest() {
  pushd "${VALIDATE_DIR}" >/dev/null
  pytest -q --junitxml="${OUT_DIR}/junit.xml"
  popd >/dev/null
}

build_rtl
build_fw
run_pytest
