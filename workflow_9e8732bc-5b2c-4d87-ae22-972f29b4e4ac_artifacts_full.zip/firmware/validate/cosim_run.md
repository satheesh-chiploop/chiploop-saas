<!-- ASSUMPTION: verilator is installed and available on PATH -->
<!-- ASSUMPTION: python3 is installed and available on PATH -->
<!-- ASSUMPTION: pytest and cocotb are installed in the active Python environment -->
<!-- ASSUMPTION: the RTL build flow is described by firmware/validate/verilator_build.md when present -->
<!-- ASSUMPTION: environment overrides may be used for RTL_TOP, RTL_DIR, and FILELIST -->

# Co-simulation runner steps

This document describes how to build the RTL simulation model, build firmware if needed, and run cocotb-based co-simulation from `firmware/validate/`.

## Prerequisites

- Verilator
- Python 3
- pytest
- cocotb

Recommended Python packages:
- `pytest`
- `cocotb`
- any test dependencies required by your design or firmware

## Environment variables

These variables are expected by the runner script and may be overridden by the user:

- `RTL_TOP=${RTL_TOP:-<RTL_TOP>}`
- `RTL_DIR=${RTL_DIR:-<RTL_DIR>}`
- `FILELIST=${FILELIST:-<FILELIST>}`

Optional overrides:
- `BUILD_DIR=${BUILD_DIR:-firmware/validate/build}`
- `COSIM_OUT=${COSIM_OUT:-firmware/validate/out}`

## Build and run flow

### 1) Prepare output directories

Commands:
```bash
mkdir -p firmware/validate/build
mkdir -p firmware/validate/out
```

### 2) Build RTL simulation model

If `firmware/validate/verilator_build.md` exists, use the build commands described there.

Otherwise, use a Verilator-based build flow that consumes the environment overrides above. The exact command shape depends on your RTL tree and filelist format, but the build should produce a runnable simulation artifact under `firmware/validate/build/`.

Example pattern:
```bash
verilator --cc \
  --top-module "$RTL_TOP" \
  --Mdir firmware/validate/build \
  --exe \
  --build \
  -f "$FILELIST"
```

If your project requires additional Verilator flags, include them in the build step described by `firmware/validate/verilator_build.md` or in your local environment.

### 3) Build firmware, if applicable

If the DUT requires firmware or a memory image, build it before running cocotb.

Example pattern:
```bash
make -C firmware build
```

If firmware build artifacts are required by the testbench, ensure they are copied or referenced from `firmware/validate/out/` or another path passed into the testbench through environment variables.

If no firmware is required, this step may be skipped.

### 4) Run cocotb through pytest

Run cocotb via `pytest -q` from `firmware/validate/` so results and logs are written locally.

Example pattern:
```bash
pytest -q --junitxml=firmware/validate/out/junit.xml
```

If your cocotb testbench requires environment variables, pass them through the shell environment before invoking pytest.

## Expected outputs

After a successful run, expect some or all of the following under `firmware/validate/`:

- simulation logs
- pytest output
- cocotb logs
- optional JUnit XML report, for example:
  - `firmware/validate/out/junit.xml`
- optional coverage artifacts, if enabled by the RTL build flow:
  - Verilator coverage files
  - HTML or lcov-style coverage reports
- build artifacts under:
  - `firmware/validate/build/`

If the test fails, logs should still be available in `firmware/validate/out/` and/or in the pytest console output.

## Notes

- Keep the RTL build command aligned with `firmware/validate/verilator_build.md` when that file exists.
- Do not assume fixed RTL source paths unless they are explicitly provided by the environment or build documentation.
- Prefer environment overrides for all design-specific paths and filenames.
