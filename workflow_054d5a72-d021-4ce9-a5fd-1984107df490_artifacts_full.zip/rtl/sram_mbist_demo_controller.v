module sram_mbist_demo_controller (
    input        clk,
    input        csb,
    input        web,
    input [7:0]  addr,
    input [31:0] din,
    output [31:0] dout
);
    reg [31:0] mem [0:255];
    reg [31:0] dout_r;
    integer i;
    assign dout = dout_r;

    always @(posedge clk) begin
        if (!csb) begin
            if (!web) begin
                mem[addr] <= din;
            end
            dout_r <= mem[addr];
        end
    end

    initial begin
        for (i = 0; i < 256; i = i + 1) begin
            mem[i] = 32'h00000000;
        end
        dout_r = 32'h00000000;
    end
endmodule
