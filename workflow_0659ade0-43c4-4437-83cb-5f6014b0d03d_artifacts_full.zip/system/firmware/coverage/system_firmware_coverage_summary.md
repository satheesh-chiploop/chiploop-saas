# System Firmware Coverage Summary

- Generated at: 2026-06-09T14:53:41.076325
- Headline status: blocked
- Execution status: blocked_missing_inputs
- Execution readiness: blocked

## Coverage Metrics

- Functional coverage: `unavailable`
- RTL/code coverage: `unavailable`
- Assertion coverage: `unavailable`
- Coverage available: `False`

## Run Health

- Executed tests: `0`
- Passed tests: `0`
- Failed tests: `0`

## Notes

- Coverage percentages are intentionally left unavailable because execution did not actually run or no coverage numbers were provided.
- No firmware functional coverage percentage was detected from upstream coverage artifacts.
- No RTL/code coverage percentage was detected from upstream coverage artifacts.
- No assertion coverage percentage was detected from upstream coverage artifacts.
- Missing execution inputs recorded upstream: makefile_path, test_paths

## Conclusion

Execution was not attempted or did not complete; coverage is unavailable.
