# System Firmware CoSim Execution Summary

- Generated at: 2026-06-09T14:53:40.292020
- Execution mode: artifact_readiness_only
- Overall status: blocked_missing_inputs
- Readiness: blocked

## Key Inputs

- SoC top: `digital/rtl/pwm_controller.v`
- Firmware ELF: `firmware/build/target/x86_64-unknown-linux-gnu/release/firmware_app.elf`
- Cocotb Makefile: `(missing)`
- Test files: `0`
- Verilog/SystemVerilog files: `1`

## Missing Required Inputs

- makefile_path
- test_paths

## Planned Test Matrix

- test_system_firmware_smoke.py | seed=1 | status=planned
- test_system_firmware_smoke.py | seed=2 | status=planned

## Notes

- Execution was not attempted because one or more required inputs were missing.
- No coverage model detected; downstream summary should avoid reporting functional coverage percentages.
- No digital assertions collateral detected; assertion coverage should remain unavailable, not fabricated.
- Firmware ELF was detected for firmware-aware co-simulation.

## Conclusion

The co-simulation bundle is incomplete. Downstream agents should treat coverage as unavailable rather than infer passing results.
