#!/usr/bin/env bash
set -euo pipefail

RTL_TOP=${RTL_TOP:-<RTL_TOP>}
RTL_DIR=${RTL_DIR:-<RTL_DIR>}
FILELIST=${FILELIST:-<FILELIST>}
FW_DIR=${FW_DIR:-$(pwd)}
BUILD_DIR=${BUILD_DIR:-firmware/validate/build}
COSIM_DIR=${COSIM_DIR:-firmware/validate}
PYTEST_ARGS=${PYTEST_ARGS:-}
COCOTB_TEST_MODULE=${COCOTB_TEST_MODULE:-}

mkdir -p "$BUILD_DIR" "$COSIM_DIR"

if [[ -f "$COSIM_DIR/verilator_build.md" ]]; then
  echo "Using build guidance from $COSIM_DIR/verilator_build.md"
fi

if [[ -f "$COSIM_DIR/verilator_build.md" ]]; then
  echo "Please follow the exact build recipe in $COSIM_DIR/verilator_build.md before running this script."
fi

if [[ "$RTL_TOP" == "<RTL_TOP>" || "$RTL_DIR" == "<RTL_DIR>" || "$FILELIST" == "<FILELIST>" ]]; then
  echo "ERROR: RTL_TOP, RTL_DIR, and FILELIST must be set via environment overrides." >&2
  exit 1
fi

VERILATOR_BUILD_DIR="$BUILD_DIR/verilator"
mkdir -p "$VERILATOR_BUILD_DIR"

if [[ -f "$COSIM_DIR/verilator_build.md" ]]; then
  echo "Detected verilator_build.md; no generic verilator invocation will be forced here."
else
  verilator -Wall --cc --trace --Mdir "$VERILATOR_BUILD_DIR" -top-module "$RTL_TOP" -f "$FILELIST"
fi

if [[ -f Cargo.toml ]]; then
  cargo build --release
elif [[ -f "$FW_DIR/Cargo.toml" ]]; then
  (cd "$FW_DIR" && cargo build --release)
else
  echo "WARNING: Cargo.toml not found; skipping Rust firmware build." >&2
fi

export COCOTB_RESULTS_FILE="$COSIM_DIR/cocotb_results.xml"
export PYTEST_ADDOPTS="${PYTEST_ADDOPTS:-} --junitxml=$COCOTB_RESULTS_FILE"

if [[ -n "$COCOTB_TEST_MODULE" ]]; then
  export COCOTB_TEST_MODULE
fi

pytest -q -s $PYTEST_ARGS "$COSIM_DIR" | tee "$COSIM_DIR/cosim.log"
