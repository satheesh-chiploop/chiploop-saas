<!-- ASSUMPTION: RTL sources, filelist, and top module are supplied via environment overrides (RTL_DIR, FILELIST, RTL_TOP) or via the existing verification collateral referenced by firmware/validate/verilator_build.md. -->
<!-- ASSUMPTION: The cocotb testbench and pytest entrypoint already exist or will be provided in the firmware/validate/ directory tree. -->
<!-- ASSUMPTION: Rust firmware is a Cargo workspace/member available at the repository root or a path supplied by environment variables. -->
<!-- ASSUMPTION: verilator, python3, pytest, and cocotb are installed and available on PATH. -->

# Co-simulation Runner

This document describes how to build the RTL simulation, build the Rust firmware, and run the cocotb-based co-simulation for the verified PWM fan-control interface.

## Prerequisites

Required tools:
- Verilator
- Python 3
- pytest
- cocotb
- Rust toolchain with cargo

Optional, for coverage:
- verilator_cov
- llvm-cov

Environment overrides expected by the scripts:
- `RTL_TOP`
- `RTL_DIR`
- `FILELIST`
- `FW_DIR` (optional, defaults to repository root)
- `BUILD_DIR` (optional, defaults to `firmware/validate/build`)
- `PYTEST_ARGS` (optional extra pytest args)
- `COCOTB_TEST_MODULE` (optional cocotb test module name)

## Build and Run Steps

### 1) Build the RTL simulation model

Preferred flow:
1. Inspect `firmware/validate/verilator_build.md` if present.
2. Use the build recipe described there.
3. If no recipe is present, invoke Verilator using the provided environment overrides.

Example command pattern:
- `verilator -Wall --cc --trace --Mdir "$BUILD_DIR/verilator" -top-module "$RTL_TOP" -f "$FILELIST"`

If the imported flow requires a generated C++ simulation wrapper or specific flags, use the documented recipe from `firmware/validate/verilator_build.md`.

### 2) Build the Rust firmware

From the firmware project root:
- `cargo build --release`

If the firmware is a workspace member or lives in a subdirectory, set the working directory accordingly before invoking cargo.

### 3) Run cocotb co-simulation via pytest

Use pytest to launch cocotb and connect the firmware-facing register model to the RTL PWM controller.

Example:
- `pytest -q -s firmware/validate`

If a specific test module is required:
- `pytest -q -s -k pwm firmware/validate`
- or
- `pytest -q -s -m cocotb firmware/validate`

For explicit cocotb module selection:
- `COCOTB_TEST_MODULE=<module_name> pytest -q -s firmware/validate`

## Exact Commands

A typical run sequence is:

1. Export environment variables as needed:
- `export RTL_TOP=<RTL_TOP>`
- `export RTL_DIR=<RTL_DIR>`
- `export FILELIST=<FILELIST>`

2. Build RTL:
- `mkdir -p firmware/validate/build/verilator`
- `verilator -Wall --cc --trace --Mdir firmware/validate/build/verilator -top-module "$RTL_TOP" -f "$FILELIST"`

3. Build firmware:
- `cargo build --release`

4. Run co-simulation:
- `pytest -q -s firmware/validate`

## Expected Outputs

The co-simulation run should create artifacts under `firmware/validate/`, including:
- Build logs
- Verilator build outputs in `firmware/validate/build/verilator/`
- Pytest console log
- Optional JUnit XML report if enabled by pytest args
- Optional waveform dump if enabled by the testbench
- Optional coverage outputs:
  - RTL coverage files from Verilator
  - FW coverage files from llvm-cov, if the firmware test harness is instrumented for coverage

Typical expected artifacts:
- `firmware/validate/build/verilator/`
- `firmware/validate/*.log`
- `firmware/validate/*.xml`
- `firmware/validate/*.vcd` or equivalent waveform file
- `firmware/validate/coverage/` or tool-specific coverage directories

## Notes

- The PWM policy expected by the firmware is:
  - Below 30 C: 0% duty
  - 30 C to 49 C: 25% duty
  - 50 C to 69 C: 55% duty
  - 70 C and above: 90% duty
- This co-simulation validates the software-facing PWM interface against the imported RTL register map and observable `pwm_out`.
- If `firmware/validate/verilator_build.md` exists, its commands take precedence over the generic example above.
