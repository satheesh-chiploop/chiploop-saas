# firmware/integration_contract.md

## Contract Overview
- This firmware owns PWM fan-control policy and register programming for the verified `pwm_controller` RTL.
- Firmware reads temperature from an upstream sensor source and computes duty-cycle from the fixed policy bands.
- Firmware programs `enable`, `period`, and `duty` registers only; `pwm_out` is the observed hardware output.
- Firmware must not modify RTL behavior, timing implementation, or register semantics outside the imported Arch2RTL register map.
- The software-visible contract is deterministic: the same temperature input range must always map to the same duty setting.
- Validation must confirm register writes, RTL observability, and end-to-end PWM behavior through co-simulation.
- Error handling is limited to driver-level register access and policy application failures; no hidden recovery behavior.
- Coverage-enabled validation must demonstrate all policy bands and enable/disable transitions.

## Contract Version + Compatibility Policy
- **Contract version:** `1.0.0`
- **Compatibility policy:**
  - **Patch updates** may clarify wording, logging text, or validation details without changing register semantics.
  - **Minor updates** may add non-breaking helper APIs or validation hooks, provided existing register programming behavior remains unchanged.
  - **Major updates** may change register mappings, duty policy, or initialization sequencing and require coordinated RTL/FW re-validation.
- **Compatibility rule:** firmware built against this contract is only valid with the imported verified `pwm_controller` RTL register map from the same Arch2RTL artifact set.

## Interfaces

### Firmware Register Layer
| Item | Type | Direction | Semantics |
|---|---:|---|---|
| `enable` | RW | FW → RTL | Enables PWM output generation when set. |
| `period` | RW | FW → RTL | Sets PWM period in controller clock cycles or RTL-defined period units. |
| `duty` | RW | FW → RTL | Sets active high time in controller-defined duty units. |
| `pwm_out` | RO | RTL → external | Observable fan-control output. |

### Driver API
| API | Inputs | Outputs | Behavior |
|---|---|---|---|
| `init()` | none | `Result<()>` | Initializes register interface and applies a safe default fan state. |
| `set_enabled(bool)` | enable/disable | `Result<()>` | Writes controller enable state. |
| `set_period(u32)` | period value | `Result<()>` | Programs PWM period. |
| `set_duty(u32)` | duty value | `Result<()>` | Programs PWM duty. |
| `apply_temp_c(i32)` | temperature in °C | `Result<()>` | Maps temperature band to the required duty policy and programs controller registers. |
| `readback()` | none | register snapshot | Returns current programmed values for validation. |

### Policy Mapping
| Temperature Range | Required Duty | Policy Class |
|---|---:|---|
| `< 30 C` | `0%` | Fan off |
| `30 C ..= 49 C` | `25%` | Quiet cooling |
| `50 C ..= 69 C` | `55%` | Normal cooling |
| `>= 70 C` | `90%` | Emergency cooling |

### Logging Schema
| Field | Type | Meaning |
|---|---|---|
| `ts` | u64 | Firmware timestamp or monotonic tick count. |
| `level` | string | Severity such as `INFO`, `WARN`, `ERROR`. |
| `component` | string | Fixed component tag, e.g. `pwm_fan_driver`. |
| `event` | string | Short event name, e.g. `policy_apply`, `reg_write`. |
| `temp_c` | i32 | Temperature that triggered policy selection. |
| `duty_pct` | u8 | Applied duty percentage. |
| `result` | string | `ok` or error code. |

### Error Codes
| Code | Meaning | Typical Cause |
|---|---|---|
| `E_CFG` | Configuration error | Invalid period/duty relationship or unsupported register state. |
| `E_IO` | Register access failure | Bus or MMIO write/read failure. |
| `E_RANGE` | Input out of range | Invalid temperature or duty input outside policy bounds. |
| `E_STATE` | Invalid state transition | Attempt to apply policy before initialization. |

### Power Modes
| Mode | Firmware Behavior |
|---|---|
| Active | Firmware applies temperature policy and updates PWM registers. |
| Low-power idle | Firmware may retain last programmed PWM state; no register semantics change. |
| Reset | Firmware must restore safe default behavior on re-init. |

## Ownership Boundaries

| Area | FW | System/Host | Validation |
|---|---|---|---|
| Temperature acquisition source | Consumes value | Supplies sensor data | Stimulates inputs |
| PWM register programming | Owns | Must not directly override | Observes transactions |
| `pwm_out` behavior | Configures via RTL registers | Reads/monitors only | Measures waveform |
| Logging | Emits contract logs | Collects/archives | Verifies schema |
| Error handling | Returns defined error codes | Handles higher-level policy | Checks fault paths |

## Assumptions
- The imported Arch2RTL RTL artifact includes the verified `pwm_controller` register map and stable bus access semantics.
- `period` and `duty` units are defined by the RTL register map and are not reinterpreted by firmware.
- A valid temperature reading is provided by the system/host layer before policy application.
- Firmware does not own sensor calibration or thermal hysteresis unless present in the imported design contract.
- `pwm_out` is the sole externally observable fan-control signal for validation.
- Co-simulation can access register transactions and waveform observability.
- Coverage collection is enabled and must include all four duty-policy bands plus enable/disable transitions.

## Validation Hooks
- **Register write checks:** confirm `enable`, `period`, and `duty` writes match the mapped policy for each temperature band.
- **Policy band tests:** drive representative temperatures for each band: below 30, 30–49, 50–69, and 70+ °C.
- **State transition tests:** verify init, enable, disable, and re-apply paths preserve contract behavior.
- **Co-simulation checks:** compare firmware register writes against RTL-observed behavior and confirm `pwm_out` duty changes accordingly.
- **Coverage checks:** require coverage over all policy bands, register write paths, and safe/default state behavior.
- **Error-path checks:** inject register access failure and invalid state conditions, then verify defined error codes are returned.
- **Readback checks:** compare firmware readback values against programmed register values.
- **Handoff checks:** verify logs, version string, and error codes match the integration contract for host consumption.

## Software-Facing Handoff Package
- **Artifact set:** Rust register layer, PWM driver, validation collateral, co-simulation collateral, and this integration contract.
- **Consumption rule:** host software should treat firmware as the sole owner of PWM register programming.
- **Integration rule:** host software may provide temperature samples and consume logs, but must not directly bypass the driver for control writes.
- **Release rule:** any RTL register-map change requires regeneration of the Rust register layer and re-execution of co-simulation and coverage validation.