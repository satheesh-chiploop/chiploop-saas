module pwm_controller (
    input         clk,
    input         reset_n,
    input         wr_en,
    input  [7:0]  wr_addr,
    input  [7:0]  wr_data,
    input         rd_en,
    input  [7:0]  rd_addr,
    output [7:0]  rd_data,
    output        pwm_out,
    output [7:0]  counter_value
);

wire        enable;
wire [7:0]  duty_cycle;
wire [7:0]  period;
wire [7:0]  reg_rd_data;
wire [7:0]  core_counter_value;
wire        core_pwm_out;

assign rd_data = reg_rd_data;
assign counter_value = core_counter_value;
assign pwm_out = core_pwm_out;

pwm_register_map u_pwm_register_map (
    .clk(clk),
    .reset_n(reset_n),
    .wr_en(wr_en),
    .wr_addr(wr_addr),
    .wr_data(wr_data),
    .rd_en(rd_en),
    .rd_addr(rd_addr),
    .rd_data(reg_rd_data),
    .counter_value_in(core_counter_value),
    .enable(enable),
    .duty_cycle(duty_cycle),
    .period(period)
);

pwm_core u_pwm_core (
    .clk(clk),
    .reset_n(reset_n),
    .enable(enable),
    .duty_cycle(duty_cycle),
    .period(period),
    .counter_value(core_counter_value),
    .pwm_out(core_pwm_out)
);

endmodule
