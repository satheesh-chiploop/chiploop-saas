/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/a7c0ff9c-83f6-4f1a-9e4a-9aa88dccb845/0d7182d4-7984-4408-ab4a-da33ac855a1d/digital/system/imported_rtl/temp_sensor_adc_model.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/a7c0ff9c-83f6-4f1a-9e4a-9aa88dccb845/0d7182d4-7984-4408-ab4a-da33ac855a1d/digital/system/imported_rtl/temp_monitor_digital.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/a7c0ff9c-83f6-4f1a-9e4a-9aa88dccb845/0d7182d4-7984-4408-ab4a-da33ac855a1d/digital/system/imported_rtl/temp_monitor_soc_phys.sv
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/a7c0ff9c-83f6-4f1a-9e4a-9aa88dccb845/0d7182d4-7984-4408-ab4a-da33ac855a1d/digital/system/imported_rtl/temp_monitor_soc_sim.sv
