{
  "type": "cdc_analysis_report",
  "version": "1.0",
  "inputs": {
    "clock_reset_intent_present": false,
    "rtl_file_count": 8
  },
  "observations": {
    "inferred_clocks": [
      "reg_clk"
    ],
    "inferred_domains": [],
    "per_file": [
      {
        "file": "backend/workflows/a223096f-59d9-4b4c-9626-0cbcce1064d7/fpga/src/handoff/rtl/adaptive_aero_command_shaper.v",
        "clock": "reg_clk",
        "domain": null
      },
      {
        "file": "backend/workflows/a223096f-59d9-4b4c-9626-0cbcce1064d7/fpga/src/handoff/rtl/adaptive_aero_control_fsm.v",
        "clock": "reg_clk",
        "domain": null
      },
      {
        "file": "backend/workflows/a223096f-59d9-4b4c-9626-0cbcce1064d7/fpga/src/handoff/rtl/adaptive_aero_control_top.v",
        "clock": null,
        "domain": null
      },
      {
        "file": "backend/workflows/a223096f-59d9-4b4c-9626-0cbcce1064d7/fpga/src/handoff/rtl/adaptive_aero_control_top_spi_fpga_top.sv",
        "clock": null,
        "domain": null
      },
      {
        "file": "backend/workflows/a223096f-59d9-4b4c-9626-0cbcce1064d7/fpga/src/handoff/rtl/adaptive_aero_event_irq.v",
        "clock": "reg_clk",
        "domain": null
      },
      {
        "file": "backend/workflows/a223096f-59d9-4b4c-9626-0cbcce1064d7/fpga/src/handoff/rtl/adaptive_aero_mmio_register_file.v",
        "clock": "reg_clk",
        "domain": null
      },
      {
        "file": "backend/workflows/a223096f-59d9-4b4c-9626-0cbcce1064d7/fpga/src/handoff/rtl/adaptive_aero_request_packager.v",
        "clock": "reg_clk",
        "domain": null
      },
      {
        "file": "backend/workflows/a223096f-59d9-4b4c-9626-0cbcce1064d7/fpga/src/handoff/rtl/adaptive_aero_response_monitor.v",
        "clock": "reg_clk",
        "domain": null
      }
    ]
  },
  "findings": [],
  "recommendations": [
    "Provide clock_reset_arch_intent.json for higher-fidelity CDC intent (domains, allowed crossings).",
    "For single-bit control crossings: use 2-flop synchronizers.",
    "For multi-bit data: use async FIFOs or validated handshake schemes.",
    "Run a real CDC tool in enterprise flow (Questa CDC / SpyGlass CDC / VC CDC) when available."
  ],
  "note": "This agent provides intent-level CDC screening. It is not a replacement for signoff CDC tools."
}