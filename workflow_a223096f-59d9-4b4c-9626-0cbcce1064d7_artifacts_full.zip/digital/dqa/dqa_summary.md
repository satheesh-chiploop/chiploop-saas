# Digital DQA Summary
- workflow_id: `a223096f-59d9-4b4c-9626-0cbcce1064d7`
- status: `pass`
- rtl files: `8`
- warning count: `0`

## Stage Status
- rtl_lint: `warn`
- cdc: `pass`
- reset_integrity: `pass`
- synthesis_readiness: `pass`
