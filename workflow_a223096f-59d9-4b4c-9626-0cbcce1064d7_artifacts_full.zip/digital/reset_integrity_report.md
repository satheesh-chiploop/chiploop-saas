{
  "type": "reset_integrity_report",
  "version": "1.0",
  "rtl_file_count": 8,
  "detected_reset_signals": [
    "reg_rst_n",
    "reset_n"
  ],
  "async_reset_blocks": [
    {
      "file": "backend/workflows/a223096f-59d9-4b4c-9626-0cbcce1064d7/fpga/src/handoff/rtl/adaptive_aero_command_shaper.v",
      "reset": "reg_rst_n",
      "edge": "negedge"
    },
    {
      "file": "backend/workflows/a223096f-59d9-4b4c-9626-0cbcce1064d7/fpga/src/handoff/rtl/adaptive_aero_control_fsm.v",
      "reset": "reg_rst_n",
      "edge": "negedge"
    },
    {
      "file": "backend/workflows/a223096f-59d9-4b4c-9626-0cbcce1064d7/fpga/src/handoff/rtl/adaptive_aero_event_irq.v",
      "reset": "reg_rst_n",
      "edge": "negedge"
    },
    {
      "file": "backend/workflows/a223096f-59d9-4b4c-9626-0cbcce1064d7/fpga/src/handoff/rtl/adaptive_aero_mmio_register_file.v",
      "reset": "reg_rst_n",
      "edge": "negedge"
    },
    {
      "file": "backend/workflows/a223096f-59d9-4b4c-9626-0cbcce1064d7/fpga/src/handoff/rtl/adaptive_aero_request_packager.v",
      "reset": "reg_rst_n",
      "edge": "negedge"
    },
    {
      "file": "backend/workflows/a223096f-59d9-4b4c-9626-0cbcce1064d7/fpga/src/handoff/rtl/adaptive_aero_response_monitor.v",
      "reset": "reg_rst_n",
      "edge": "negedge"
    }
  ],
  "reset_usage_locations": [
    {
      "file": "backend/workflows/a223096f-59d9-4b4c-9626-0cbcce1064d7/fpga/src/handoff/rtl/adaptive_aero_command_shaper.v",
      "reset": "reg_rst_n",
      "context": "if_condition"
    },
    {
      "file": "backend/workflows/a223096f-59d9-4b4c-9626-0cbcce1064d7/fpga/src/handoff/rtl/adaptive_aero_control_fsm.v",
      "reset": "reg_rst_n",
      "context": "if_condition"
    },
    {
      "file": "backend/workflows/a223096f-59d9-4b4c-9626-0cbcce1064d7/fpga/src/handoff/rtl/adaptive_aero_control_top_spi_fpga_top.sv",
      "reset": "reset_n",
      "context": "if_condition"
    },
    {
      "file": "backend/workflows/a223096f-59d9-4b4c-9626-0cbcce1064d7/fpga/src/handoff/rtl/adaptive_aero_event_irq.v",
      "reset": "reg_rst_n",
      "context": "if_condition"
    },
    {
      "file": "backend/workflows/a223096f-59d9-4b4c-9626-0cbcce1064d7/fpga/src/handoff/rtl/adaptive_aero_mmio_register_file.v",
      "reset": "reg_rst_n",
      "context": "if_condition"
    },
    {
      "file": "backend/workflows/a223096f-59d9-4b4c-9626-0cbcce1064d7/fpga/src/handoff/rtl/adaptive_aero_request_packager.v",
      "reset": "reg_rst_n",
      "context": "if_condition"
    },
    {
      "file": "backend/workflows/a223096f-59d9-4b4c-9626-0cbcce1064d7/fpga/src/handoff/rtl/adaptive_aero_response_monitor.v",
      "reset": "reg_rst_n",
      "context": "if_condition"
    }
  ],
  "findings": [],
  "recommendations": [
    "Prefer async-assert / sync-deassert reset strategy in multi-clock designs.",
    "Ensure reset deassertion is synchronized per clock domain.",
    "Avoid mixing async and sync reset styles without clear intent.",
    "Add reset-specific assertions: no X after reset release; stable reset sequencing."
  ],
  "note": "Heuristic scan only; use signoff reset/CDC checks in enterprise flows when available."
}