module adaptive_aero_mmio_register_file (
    reg_clk,
    reg_rst_n,
    reg_addr,
    reg_wdata,
    reg_rdata,
    reg_we,
    reg_re,
    reg_valid,
    reg_ready,
    cfg_enable,
    cfg_mode,
    cfg_velocity_setpoint_mps,
    cfg_timeout_cycles,
    cfg_freshness_threshold_cycles,
    cfg_cmd_min,
    cfg_cmd_max,
    cfg_cmd_rate_limit,
    cfg_sequence_seed,
    cfg_interrupt_enable,
    status_seq_tx,
    status_seq_rx,
    status_last_response_code,
    status_last_result_word,
    status_fault_flags,
    status_actuator_cmd,
    status_cmd_valid,
    status_safe_inhibit,
    status_request_inflight,
    status_clamp_event
);

input reg_clk;
input reg_rst_n;
input [15:0] reg_addr;
input [63:0] reg_wdata;
output [63:0] reg_rdata;
input reg_we;
input reg_re;
input reg_valid;
output reg reg_ready;

output reg cfg_enable;
output reg [2:0] cfg_mode;
output reg [15:0] cfg_velocity_setpoint_mps;
output reg [15:0] cfg_timeout_cycles;
output reg [15:0] cfg_freshness_threshold_cycles;
output reg [7:0] cfg_cmd_min;
output reg [7:0] cfg_cmd_max;
output reg [7:0] cfg_cmd_rate_limit;
output reg [15:0] cfg_sequence_seed;
output reg cfg_interrupt_enable;

input [15:0] status_seq_tx;
input [15:0] status_seq_rx;
input [7:0] status_last_response_code;
input [15:0] status_last_result_word;
input [7:0] status_fault_flags;
input [7:0] status_actuator_cmd;
input status_cmd_valid;
input status_safe_inhibit;
input status_request_inflight;
input status_clamp_event;

reg [63:0] reg_rdata_r;
assign reg_rdata = reg_rdata_r;

localparam [15:0] REG_CTRL    = 16'h0000;
localparam [15:0] REG_SETPT   = 16'h0008;
localparam [15:0] REG_TIMING  = 16'h0010;
localparam [15:0] REG_SEED    = 16'h0018;
localparam [15:0] REG_STATUS0 = 16'h0020;
localparam [15:0] REG_STATUS1 = 16'h0028;

always @(posedge reg_clk or negedge reg_rst_n) begin
    if (!reg_rst_n) begin
        reg_ready <= 1'b0;
        cfg_enable <= 1'b0;
        cfg_mode <= 3'b000;
        cfg_velocity_setpoint_mps <= 16'h0000;
        cfg_timeout_cycles <= 16'd1024;
        cfg_freshness_threshold_cycles <= 16'd256;
        cfg_cmd_min <= 8'h00;
        cfg_cmd_max <= 8'hFF;
        cfg_cmd_rate_limit <= 8'h00;
        cfg_sequence_seed <= 16'h0000;
        cfg_interrupt_enable <= 1'b0;
        reg_rdata_r <= 64'h0000000000000000;
    end else begin
        reg_ready <= reg_valid;
        if (reg_valid && reg_we) begin
            case (reg_addr)
                REG_CTRL: begin
                    cfg_enable <= reg_wdata[0];
                    cfg_mode <= reg_wdata[3:1];
                    cfg_interrupt_enable <= reg_wdata[4];
                end
                REG_SETPT: begin
                    cfg_velocity_setpoint_mps <= reg_wdata[15:0];
                    cfg_cmd_min <= reg_wdata[23:16];
                    cfg_cmd_max <= reg_wdata[31:24];
                    cfg_cmd_rate_limit <= reg_wdata[39:32];
                end
                REG_TIMING: begin
                    cfg_timeout_cycles <= reg_wdata[15:0];
                    cfg_freshness_threshold_cycles <= reg_wdata[31:16];
                end
                REG_SEED: begin
                    cfg_sequence_seed <= reg_wdata[15:0];
                end
                default: begin
                end
            endcase
        end
        if (reg_valid && reg_re) begin
            case (reg_addr)
                REG_CTRL: begin
                    reg_rdata_r <= {47'b0, cfg_interrupt_enable, 9'h000, cfg_mode, 3'h0, cfg_enable};
                end
                REG_SETPT: begin
                    reg_rdata_r <= {24'h000000, cfg_cmd_rate_limit, cfg_cmd_max, cfg_cmd_min, cfg_velocity_setpoint_mps};
                end
                REG_TIMING: begin
                    reg_rdata_r <= {32'h00000000, cfg_freshness_threshold_cycles, cfg_timeout_cycles};
                end
                REG_SEED: begin
                    reg_rdata_r <= {48'h000000000000, cfg_sequence_seed};
                end
                REG_STATUS0: begin
                    reg_rdata_r <= {28'h0000000, status_clamp_event, status_request_inflight, status_safe_inhibit, status_cmd_valid, status_seq_rx, status_seq_tx};
                end
                REG_STATUS1: begin
                    reg_rdata_r <= {24'h000000, status_actuator_cmd, status_fault_flags, status_last_result_word, status_last_response_code};
                end
                default: begin
                    reg_rdata_r <= 64'h0000000000000000;
                end
            endcase
        end else begin
            reg_rdata_r <= reg_rdata_r;
        end
    end
end

endmodule
