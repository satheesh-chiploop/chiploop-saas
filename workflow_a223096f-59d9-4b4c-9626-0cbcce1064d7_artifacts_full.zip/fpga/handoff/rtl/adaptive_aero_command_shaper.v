module adaptive_aero_command_shaper (
    reg_clk,
    reg_rst_n,
    cfg_cmd_min,
    cfg_cmd_max,
    cfg_cmd_rate_limit,
    latest_result_word_in,
    latest_response_code_in,
    command_update_pulse_in,
    command_valid_gate_in,
    fallback_inhibit_in,
    actuator_cmd,
    actuator_cmd_valid,
    actuator_clamped,
    actuator_rate_limited,
    actuator_safe_inhibit
);

input reg_clk;
input reg_rst_n;
input [7:0] cfg_cmd_min;
input [7:0] cfg_cmd_max;
input [7:0] cfg_cmd_rate_limit;
input [15:0] latest_result_word_in;
input [7:0] latest_response_code_in;
input command_update_pulse_in;
input command_valid_gate_in;
input fallback_inhibit_in;
output reg [7:0] actuator_cmd;
output reg actuator_cmd_valid;
output reg actuator_clamped;
output reg actuator_rate_limited;
output reg actuator_safe_inhibit;

reg [7:0] prev_cmd;
reg [8:0] target_sum;
reg [8:0] clamped_sum;
reg [7:0] target_cmd;
reg [7:0] delta_cmd;
reg [7:0] limit_mag;

always @(posedge reg_clk or negedge reg_rst_n) begin
    if (!reg_rst_n) begin
        actuator_cmd <= 8'h00;
        actuator_cmd_valid <= 1'b0;
        actuator_clamped <= 1'b0;
        actuator_rate_limited <= 1'b0;
        actuator_safe_inhibit <= 1'b1;
        prev_cmd <= 8'h00;
        target_sum <= 9'h000;
        clamped_sum <= 9'h000;
        target_cmd <= 8'h00;
        delta_cmd <= 8'h00;
        limit_mag <= 8'h00;
    end else begin
        actuator_clamped <= 1'b0;
        actuator_rate_limited <= 1'b0;
        if (fallback_inhibit_in || !command_valid_gate_in) begin
            actuator_safe_inhibit <= 1'b1;
            actuator_cmd_valid <= 1'b0;
        end else begin
            actuator_safe_inhibit <= 1'b0;
            if (command_update_pulse_in) begin
                target_sum <= {1'b0, latest_result_word_in[15:8]} + {1'b0, latest_result_word_in[7:0]} + {1'b0, latest_response_code_in};
                if (target_sum > {1'b0, cfg_cmd_max}) begin
                    clamped_sum <= {1'b0, cfg_cmd_max};
                    actuator_clamped <= 1'b1;
                end else if (target_sum < {1'b0, cfg_cmd_min}) begin
                    clamped_sum <= {1'b0, cfg_cmd_min};
                    actuator_clamped <= 1'b1;
                end else begin
                    clamped_sum <= target_sum;
                end
                target_cmd <= clamped_sum[7:0];
                if (cfg_cmd_rate_limit != 8'h00) begin
                    limit_mag <= cfg_cmd_rate_limit;
                    if ((clamped_sum[7:0] > prev_cmd && (clamped_sum[7:0] - prev_cmd) > limit_mag) ||
                        (clamped_sum[7:0] < prev_cmd && (prev_cmd - clamped_sum[7:0]) > limit_mag)) begin
                        actuator_rate_limited <= 1'b1;
                        if (clamped_sum[7:0] > prev_cmd)
                            actuator_cmd <= prev_cmd + limit_mag;
                        else
                            actuator_cmd <= prev_cmd - limit_mag;
                    end else begin
                        actuator_cmd <= clamped_sum[7:0];
                    end
                end else begin
                    actuator_cmd <= clamped_sum[7:0];
                end
                prev_cmd <= actuator_cmd;
                actuator_cmd_valid <= 1'b1;
            end else begin
                actuator_cmd_valid <= 1'b0;
            end
        end
    end
end

endmodule
