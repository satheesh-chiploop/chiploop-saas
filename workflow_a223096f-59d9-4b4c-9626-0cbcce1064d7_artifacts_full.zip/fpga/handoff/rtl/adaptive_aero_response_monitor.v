module adaptive_aero_response_monitor (
    reg_clk,
    reg_rst_n,
    resp_valid,
    resp_ready,
    resp_data,
    expected_seq_in,
    request_age_in,
    cfg_freshness_threshold_cycles,
    cfg_timeout_cycles,
    response_accepted,
    response_rejected_stale,
    response_rejected_duplicate,
    response_rejected_malformed,
    response_timeout,
    accepted_seq_out,
    accepted_result_word,
    accepted_response_code,
    accepted_metadata
);

input reg_clk;
input reg_rst_n;
input resp_valid;
output reg resp_ready;
input [63:0] resp_data;
input [15:0] expected_seq_in;
input [7:0] request_age_in;
input [15:0] cfg_freshness_threshold_cycles;
input [15:0] cfg_timeout_cycles;
output reg response_accepted;
output reg response_rejected_stale;
output reg response_rejected_duplicate;
output reg response_rejected_malformed;
output reg response_timeout;
output reg [15:0] accepted_seq_out;
output reg [15:0] accepted_result_word;
output reg [7:0] accepted_response_code;
output reg [7:0] accepted_metadata;
reg [15:0] last_accepted_seq;
reg [15:0] timeout_ctr;

always @(posedge reg_clk or negedge reg_rst_n) begin
    if (!reg_rst_n) begin
        resp_ready <= 1'b0;
        response_accepted <= 1'b0;
        response_rejected_stale <= 1'b0;
        response_rejected_duplicate <= 1'b0;
        response_rejected_malformed <= 1'b0;
        response_timeout <= 1'b0;
        accepted_seq_out <= 16'h0000;
        accepted_result_word <= 16'h0000;
        accepted_response_code <= 8'h00;
        accepted_metadata <= 8'h00;
        last_accepted_seq <= 16'hFFFF;
        timeout_ctr <= 16'h0000;
    end else begin
        response_accepted <= 1'b0;
        response_rejected_stale <= 1'b0;
        response_rejected_duplicate <= 1'b0;
        response_rejected_malformed <= 1'b0;
        response_timeout <= 1'b0;
        resp_ready <= 1'b1;
        if (resp_valid && resp_ready) begin
            if (resp_data[63:60] != 4'hA) begin
                response_rejected_malformed <= 1'b1;
            end else if (resp_data[47:32] != expected_seq_in) begin
                if (resp_data[47:32] < expected_seq_in) begin
                    response_rejected_duplicate <= 1'b1;
                end else begin
                    response_rejected_stale <= 1'b1;
                end
            end else if (request_age_in > cfg_freshness_threshold_cycles[7:0]) begin
                response_rejected_stale <= 1'b1;
            end else if (expected_seq_in == last_accepted_seq) begin
                response_rejected_duplicate <= 1'b1;
            end else begin
                response_accepted <= 1'b1;
                accepted_seq_out <= resp_data[47:32];
                accepted_result_word <= resp_data[15:0];
                accepted_response_code <= resp_data[55:48];
                accepted_metadata <= resp_data[23:16];
                last_accepted_seq <= resp_data[47:32];
                timeout_ctr <= 16'h0000;
            end
        end else begin
            if (timeout_ctr < cfg_timeout_cycles) timeout_ctr <= timeout_ctr + 16'h0001;
            if (timeout_ctr >= cfg_timeout_cycles && cfg_timeout_cycles != 16'h0000) begin
                response_timeout <= 1'b1;
            end
        end
    end
end

endmodule
