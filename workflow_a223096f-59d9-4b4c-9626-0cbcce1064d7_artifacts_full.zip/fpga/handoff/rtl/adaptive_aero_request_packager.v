module adaptive_aero_request_packager (
    reg_clk,
    reg_rst_n,
    cfg_enable,
    cfg_mode,
    cfg_velocity_setpoint_mps,
    cfg_timeout_cycles,
    cfg_freshness_threshold_cycles,
    cfg_sequence_seed,
    stream_velocity_mps,
    vehicle_state_valid,
    vehicle_state_fault,
    request_seq_out,
    request_age_out,
    request_frame_valid,
    req_ready,
    req_valid,
    req_data,
    request_inflight
);

input reg_clk;
input reg_rst_n;
input cfg_enable;
input [2:0] cfg_mode;
input [15:0] cfg_velocity_setpoint_mps;
input [15:0] cfg_timeout_cycles;
input [15:0] cfg_freshness_threshold_cycles;
input [15:0] cfg_sequence_seed;
input [15:0] stream_velocity_mps;
input vehicle_state_valid;
input vehicle_state_fault;
output reg [15:0] request_seq_out;
output reg [7:0] request_age_out;
output reg request_frame_valid;
input req_ready;
output reg req_valid;
output reg [63:0] req_data;
output reg request_inflight;

reg [15:0] seq_reg;
reg [7:0] age_reg;
reg [7:0] wait_ctr;
reg [7:0] age_limit_r;

always @(posedge reg_clk or negedge reg_rst_n) begin
    if (!reg_rst_n) begin
        seq_reg <= 16'h0000;
        age_reg <= 8'h00;
        wait_ctr <= 8'h00;
        age_limit_r <= 8'h00;
        request_seq_out <= 16'h0000;
        request_age_out <= 8'h00;
        request_frame_valid <= 1'b0;
        req_valid <= 1'b0;
        req_data <= 64'h0000000000000000;
        request_inflight <= 1'b0;
    end else begin
        age_limit_r <= cfg_freshness_threshold_cycles[7:0];
        request_frame_valid <= 1'b0;
        if (!cfg_enable) begin
            req_valid <= 1'b0;
            request_inflight <= 1'b0;
            age_reg <= 8'h00;
            wait_ctr <= 8'h00;
        end else begin
            if (request_inflight) begin
                if (req_valid && req_ready) begin
                    request_inflight <= 1'b0;
                    req_valid <= 1'b0;
                    age_reg <= 8'h00;
                    wait_ctr <= 8'h00;
                    seq_reg <= seq_reg + 16'h0001;
                    request_seq_out <= seq_reg + 16'h0001;
                    request_frame_valid <= 1'b1;
                end else begin
                    request_age_out <= age_reg;
                    if (age_reg != 8'hFF) age_reg <= age_reg + 8'h01;
                    if (wait_ctr != 8'hFF) wait_ctr <= wait_ctr + 8'h01;
                    if (wait_ctr >= age_limit_r) begin
                        req_valid <= 1'b0;
                        request_inflight <= 1'b0;
                    end
                end
            end else begin
                request_seq_out <= seq_reg;
                request_age_out <= age_reg;
                if (vehicle_state_valid && req_ready && (wait_ctr >= age_limit_r || age_limit_r == 8'h00)) begin
                    req_valid <= 1'b1;
                    request_inflight <= 1'b1;
                    req_data <= {stream_velocity_mps, cfg_velocity_setpoint_mps, 5'b00000, cfg_mode, cfg_sequence_seed, cfg_timeout_cycles, cfg_freshness_threshold_cycles, vehicle_state_fault, 7'h00};
                    request_frame_valid <= 1'b1;
                    age_reg <= 8'h00;
                    wait_ctr <= 8'h00;
                end else begin
                    if (vehicle_state_valid && !request_inflight && (wait_ctr < age_limit_r || age_limit_r == 8'h00)) begin
                        if (!req_valid) begin
                            req_data <= {stream_velocity_mps, cfg_velocity_setpoint_mps, 5'b00000, cfg_mode, cfg_sequence_seed, cfg_timeout_cycles, cfg_freshness_threshold_cycles, vehicle_state_fault, 7'h00};
                        end
                        req_valid <= req_valid;
                    end else begin
                        req_valid <= 1'b0;
                    end
                    if (wait_ctr != 8'hFF) wait_ctr <= wait_ctr + 8'h01;
                    if (age_reg != 8'hFF) age_reg <= age_reg + 8'h01;
                end
            end
        end
    end
end

endmodule
