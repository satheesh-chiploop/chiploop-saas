module adaptive_aero_event_irq (
    reg_clk,
    reg_rst_n,
    cfg_interrupt_enable,
    response_accepted,
    response_rejected_stale,
    response_timeout,
    fallback_inhibit,
    irq_new_response,
    irq_stale_data,
    irq_timeout,
    irq_fallback,
    event_latched_flags
);

input reg_clk;
input reg_rst_n;
input cfg_interrupt_enable;
input response_accepted;
input response_rejected_stale;
input response_timeout;
input fallback_inhibit;
output reg irq_new_response;
output reg irq_stale_data;
output reg irq_timeout;
output reg irq_fallback;
output reg [7:0] event_latched_flags;
always @(posedge reg_clk or negedge reg_rst_n) begin
    if (!reg_rst_n) begin
        irq_new_response <= 1'b0;
        irq_stale_data <= 1'b0;
        irq_timeout <= 1'b0;
        irq_fallback <= 1'b0;
        event_latched_flags <= 8'h00;
    end else begin
        irq_new_response <= 1'b0;
        irq_stale_data <= 1'b0;
        irq_timeout <= 1'b0;
        irq_fallback <= 1'b0;
        if (cfg_interrupt_enable) begin
            if (response_accepted) begin
                irq_new_response <= 1'b1;
                event_latched_flags[0] <= 1'b1;
            end
            if (response_rejected_stale) begin
                irq_stale_data <= 1'b1;
                event_latched_flags[1] <= 1'b1;
            end
            if (response_timeout) begin
                irq_timeout <= 1'b1;
                event_latched_flags[2] <= 1'b1;
            end
            if (fallback_inhibit) begin
                irq_fallback <= 1'b1;
                event_latched_flags[3] <= 1'b1;
            end
        end
    end
end

endmodule
