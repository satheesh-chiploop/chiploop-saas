// Auto-generated FPGA-only serialized transport shell.
// The verified core RTL remains unchanged; ASIC flows continue to use the core top.
module adaptive_aero_control_top_spi_fpga_top (
  input  logic clk,
  input  logic reset_n,
  input  logic spi_sclk,
  input  logic spi_cs_n,
  input  logic spi_mosi,
  output logic spi_miso,
  output logic fault_indicator
);
  localparam integer INPUT_BITS = 169;
  localparam integer OUTPUT_BITS = 145;
  localparam integer FRAME_BITS = 176;
  logic [FRAME_BITS-1:0] rx_shift;
  logic [INPUT_BITS-1:0] rx_active;
  logic [FRAME_BITS-1:0] tx_shift, tx_snapshot;
  logic spi_active;
  logic spi_cs_meta, spi_cs_sync, spi_cs_prev;
  logic core_reg_clk;
  logic core_reg_rst_n;
  logic [15:0] core_reg_addr;
  logic [63:0] core_reg_wdata;
  logic core_reg_we;
  logic core_reg_re;
  logic core_reg_valid;
  logic core_req_ready;
  logic core_resp_valid;
  logic [63:0] core_resp_data;
  logic [15:0] core_stream_velocity_mps;
  logic core_vehicle_state_valid;
  logic core_vehicle_state_fault;
  wire [63:0] core_reg_rdata;
  wire core_reg_ready;
  wire core_req_valid;
  wire [63:0] core_req_data;
  wire core_resp_ready;
  wire [7:0] core_actuator_cmd;
  wire core_actuator_cmd_valid;
  wire core_actuator_safe_fallback;
  wire core_irq_new_response;
  wire core_irq_stale_data;
  wire core_irq_timeout;
  wire core_irq_fallback;
  assign core_reg_clk = rx_active[0 +: 1];
  assign core_reg_rst_n = rx_active[1 +: 1];
  assign core_reg_addr = rx_active[2 +: 16];
  assign core_reg_wdata = rx_active[18 +: 64];
  assign core_reg_we = rx_active[82 +: 1];
  assign core_reg_re = rx_active[83 +: 1];
  assign core_reg_valid = rx_active[84 +: 1];
  assign core_req_ready = rx_active[85 +: 1];
  assign core_resp_valid = rx_active[86 +: 1];
  assign core_resp_data = rx_active[87 +: 64];
  assign core_stream_velocity_mps = rx_active[151 +: 16];
  assign core_vehicle_state_valid = rx_active[167 +: 1];
  assign core_vehicle_state_fault = rx_active[168 +: 1];
  wire [OUTPUT_BITS-1:0] core_response = {core_reg_rdata, core_reg_ready, core_req_valid, core_req_data, core_resp_ready, core_actuator_cmd, core_actuator_cmd_valid, core_actuator_safe_fallback, core_irq_new_response, core_irq_stale_data, core_irq_timeout, core_irq_fallback};
  wire [FRAME_BITS-1:0] framed_response = {core_response, {(FRAME_BITS-OUTPUT_BITS){1'b0}}};
  assign fault_indicator = 1'b0;
  // Chip select asynchronously clears only the frame-state bit. Data
  // registers use SPI clock alone, which is legal in ECP5 fabric.
  always_ff @(posedge spi_sclk or posedge spi_cs_n) begin
    if (spi_cs_n) spi_active <= 1'b0;
    else spi_active <= 1'b1;
  end
  always_ff @(posedge spi_sclk) begin
    if (!spi_cs_n) begin
      rx_shift <= {rx_shift[174:0], spi_mosi};
      if (!spi_active) tx_shift <= {tx_snapshot[174:0], 1'b0};
      else tx_shift <= {tx_shift[174:0], 1'b0};
    end
  end
  // Synchronize frame completion into the core clock domain. The host
  // keeps MOSI stable around CS rising as required by the protocol.
  always_ff @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
      spi_cs_meta <= 1'b1; spi_cs_sync <= 1'b1; spi_cs_prev <= 1'b1;
      rx_active <= '0; tx_snapshot <= '0;
    end else begin
      spi_cs_meta <= spi_cs_n; spi_cs_sync <= spi_cs_meta; spi_cs_prev <= spi_cs_sync;
      if (spi_cs_sync && !spi_cs_prev) begin
        rx_active <= rx_shift[INPUT_BITS-1:0];
        // Bundled-data CDC: capture once, then hold this mailbox stable
        // until the next completed frame. The host observes response N in frame N+2.
        tx_snapshot <= framed_response;
      end
    end
  end
  // MISO is a dedicated top-level output. Drive a defined idle value
  // instead of inferring an internal tri-state cell, which is not a
  // portable fabric primitive and breaks mapped equivalence on targets
  // such as ECP5. Board-specific shared-data buses require an explicit
  // vendor I/O-buffer wrapper outside this transport shell.
  always_comb spi_miso = !spi_cs_n ? (spi_active ? tx_shift[FRAME_BITS-1] : tx_snapshot[FRAME_BITS-1]) : 1'b0;
  adaptive_aero_control_top u_core (
    .reg_clk(core_reg_clk),
    .reg_rst_n(core_reg_rst_n),
    .reg_addr(core_reg_addr),
    .reg_wdata(core_reg_wdata),
    .reg_rdata(core_reg_rdata),
    .reg_we(core_reg_we),
    .reg_re(core_reg_re),
    .reg_valid(core_reg_valid),
    .reg_ready(core_reg_ready),
    .req_valid(core_req_valid),
    .req_ready(core_req_ready),
    .req_data(core_req_data),
    .resp_valid(core_resp_valid),
    .resp_ready(core_resp_ready),
    .resp_data(core_resp_data),
    .stream_velocity_mps(core_stream_velocity_mps),
    .vehicle_state_valid(core_vehicle_state_valid),
    .vehicle_state_fault(core_vehicle_state_fault),
    .actuator_cmd(core_actuator_cmd),
    .actuator_cmd_valid(core_actuator_cmd_valid),
    .actuator_safe_fallback(core_actuator_safe_fallback),
    .irq_new_response(core_irq_new_response),
    .irq_stale_data(core_irq_stale_data),
    .irq_timeout(core_irq_timeout),
    .irq_fallback(core_irq_fallback)
  );
endmodule
