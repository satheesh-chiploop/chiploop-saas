module adaptive_aero_control_fsm (
    reg_clk,
    reg_rst_n,
    cfg_enable,
    cfg_mode,
    cfg_cmd_min,
    cfg_cmd_max,
    cfg_cmd_rate_limit,
    cfg_interrupt_enable,
    response_accepted,
    response_rejected_stale,
    response_rejected_duplicate,
    response_rejected_malformed,
    response_timeout,
    vehicle_state_fault,
    accepted_seq_in,
    accepted_result_word_in,
    accepted_response_code_in,
    accepted_metadata_in,
    latest_seq_out,
    latest_result_word_out,
    latest_response_code_out,
    fault_latched_out,
    command_update_pulse,
    command_valid_gate,
    fallback_inhibit
);

input reg_clk;
input reg_rst_n;
input cfg_enable;
input [2:0] cfg_mode;
input [7:0] cfg_cmd_min;
input [7:0] cfg_cmd_max;
input [7:0] cfg_cmd_rate_limit;
input cfg_interrupt_enable;
input response_accepted;
input response_rejected_stale;
input response_rejected_duplicate;
input response_rejected_malformed;
input response_timeout;
input vehicle_state_fault;
input [15:0] accepted_seq_in;
input [15:0] accepted_result_word_in;
input [7:0] accepted_response_code_in;
input [7:0] accepted_metadata_in;
output reg [15:0] latest_seq_out;
output reg [15:0] latest_result_word_out;
output reg [7:0] latest_response_code_out;
output reg [7:0] fault_latched_out;
output reg command_update_pulse;
output reg command_valid_gate;
output reg fallback_inhibit;

reg [7:0] fault_reg;
reg [15:0] latest_seq_r;
reg [15:0] latest_result_r;
reg [7:0] latest_code_r;
reg update_latch;

always @(posedge reg_clk or negedge reg_rst_n) begin
    if (!reg_rst_n) begin
        latest_seq_out <= 16'h0000;
        latest_result_word_out <= 16'h0000;
        latest_response_code_out <= 8'h00;
        fault_latched_out <= 8'h00;
        command_update_pulse <= 1'b0;
        command_valid_gate <= 1'b0;
        fallback_inhibit <= 1'b1;
        fault_reg <= 8'h00;
        latest_seq_r <= 16'h0000;
        latest_result_r <= 16'h0000;
        latest_code_r <= 8'h00;
        update_latch <= 1'b0;
    end else begin
        command_update_pulse <= 1'b0;
        if (response_accepted) begin
            latest_seq_r <= accepted_seq_in;
            latest_result_r <= accepted_result_word_in;
            latest_code_r <= accepted_response_code_in;
            latest_seq_out <= accepted_seq_in;
            latest_result_word_out <= accepted_result_word_in;
            latest_response_code_out <= accepted_response_code_in;
            command_update_pulse <= 1'b1;
            command_valid_gate <= cfg_enable & ~vehicle_state_fault;
            fallback_inhibit <= vehicle_state_fault | ~cfg_enable;
        end
        if (response_rejected_stale) fault_reg[0] <= 1'b1;
        if (response_rejected_duplicate) fault_reg[1] <= 1'b1;
        if (response_rejected_malformed) fault_reg[2] <= 1'b1;
        if (response_timeout) fault_reg[3] <= 1'b1;
        if (vehicle_state_fault) fault_reg[4] <= 1'b1;
        if (!cfg_enable) begin
            command_valid_gate <= 1'b0;
            fallback_inhibit <= 1'b1;
        end else if (vehicle_state_fault) begin
            command_valid_gate <= 1'b0;
            fallback_inhibit <= 1'b1;
        end else if (response_accepted) begin
            command_valid_gate <= 1'b1;
            fallback_inhibit <= 1'b0;
        end
        if (response_rejected_stale || response_rejected_duplicate || response_rejected_malformed || response_timeout || vehicle_state_fault) begin
            update_latch <= 1'b1;
        end
        fault_latched_out <= fault_reg;
    end
end

endmodule
