module adaptive_aero_control_top (
    reg_clk,
    reg_rst_n,
    reg_addr,
    reg_wdata,
    reg_rdata,
    reg_we,
    reg_re,
    reg_valid,
    reg_ready,
    req_valid,
    req_ready,
    req_data,
    resp_valid,
    resp_ready,
    resp_data,
    stream_velocity_mps,
    vehicle_state_valid,
    vehicle_state_fault,
    actuator_cmd,
    actuator_cmd_valid,
    actuator_safe_fallback,
    irq_new_response,
    irq_stale_data,
    irq_timeout,
    irq_fallback
);

input reg_clk;
input reg_rst_n;
input [15:0] reg_addr;
input [63:0] reg_wdata;
output [63:0] reg_rdata;
input reg_we;
input reg_re;
input reg_valid;
output reg_ready;
output req_valid;
input req_ready;
output [63:0] req_data;
input resp_valid;
output resp_ready;
input [63:0] resp_data;
input [15:0] stream_velocity_mps;
input vehicle_state_valid;
input vehicle_state_fault;
output [7:0] actuator_cmd;
output actuator_cmd_valid;
output actuator_safe_fallback;
output irq_new_response;
output irq_stale_data;
output irq_timeout;
output irq_fallback;
wire cfg_enable;
wire [2:0] cfg_mode;
wire [15:0] cfg_velocity_setpoint_mps;
wire [15:0] cfg_timeout_cycles;
wire [15:0] cfg_freshness_threshold_cycles;
wire [7:0] cfg_cmd_min;
wire [7:0] cfg_cmd_max;
wire [7:0] cfg_cmd_rate_limit;
wire [15:0] cfg_sequence_seed;
wire cfg_interrupt_enable;
wire [15:0] request_seq_out;
wire [7:0] request_age_out;
wire request_frame_valid;
wire request_inflight;
wire response_accepted;
wire response_rejected_stale;
wire response_rejected_duplicate;
wire response_rejected_malformed;
wire response_timeout;
wire [15:0] accepted_seq_out;
wire [15:0] accepted_result_word;
wire [7:0] accepted_response_code;
wire [7:0] accepted_metadata;
wire [15:0] latest_seq_out;
wire [15:0] latest_result_word_out;
wire [7:0] latest_response_code_out;
wire [7:0] fault_latched_out;
wire command_update_pulse;
wire command_valid_gate;
wire fallback_inhibit;
wire actuator_clamped;
wire actuator_rate_limited;
wire actuator_safe_inhibit;
wire [7:0] event_latched_flags;

adaptive_aero_mmio_register_file u_mmio (
    .reg_clk(reg_clk),
    .reg_rst_n(reg_rst_n),
    .reg_addr(reg_addr),
    .reg_wdata(reg_wdata),
    .reg_rdata(reg_rdata),
    .reg_we(reg_we),
    .reg_re(reg_re),
    .reg_valid(reg_valid),
    .reg_ready(reg_ready),
    .cfg_enable(cfg_enable),
    .cfg_mode(cfg_mode),
    .cfg_velocity_setpoint_mps(cfg_velocity_setpoint_mps),
    .cfg_timeout_cycles(cfg_timeout_cycles),
    .cfg_freshness_threshold_cycles(cfg_freshness_threshold_cycles),
    .cfg_cmd_min(cfg_cmd_min),
    .cfg_cmd_max(cfg_cmd_max),
    .cfg_cmd_rate_limit(cfg_cmd_rate_limit),
    .cfg_sequence_seed(cfg_sequence_seed),
    .cfg_interrupt_enable(cfg_interrupt_enable),
    .status_seq_tx(request_seq_out),
    .status_seq_rx(latest_seq_out),
    .status_last_response_code(latest_response_code_out),
    .status_last_result_word(latest_result_word_out),
    .status_fault_flags(fault_latched_out),
    .status_actuator_cmd(actuator_cmd),
    .status_cmd_valid(actuator_cmd_valid),
    .status_safe_inhibit(actuator_safe_inhibit),
    .status_request_inflight(request_inflight),
    .status_clamp_event(actuator_clamped)
);

adaptive_aero_request_packager u_req (
    .reg_clk(reg_clk),
    .reg_rst_n(reg_rst_n),
    .cfg_enable(cfg_enable),
    .cfg_mode(cfg_mode),
    .cfg_velocity_setpoint_mps(cfg_velocity_setpoint_mps),
    .cfg_timeout_cycles(cfg_timeout_cycles),
    .cfg_freshness_threshold_cycles(cfg_freshness_threshold_cycles),
    .cfg_sequence_seed(cfg_sequence_seed),
    .stream_velocity_mps(stream_velocity_mps),
    .vehicle_state_valid(vehicle_state_valid),
    .vehicle_state_fault(vehicle_state_fault),
    .request_seq_out(request_seq_out),
    .request_age_out(request_age_out),
    .request_frame_valid(request_frame_valid),
    .req_ready(req_ready),
    .req_valid(req_valid),
    .req_data(req_data),
    .request_inflight(request_inflight)
);

adaptive_aero_response_monitor u_rsp (
    .reg_clk(reg_clk),
    .reg_rst_n(reg_rst_n),
    .resp_valid(resp_valid),
    .resp_ready(resp_ready),
    .resp_data(resp_data),
    .expected_seq_in(request_seq_out),
    .request_age_in(request_age_out),
    .cfg_freshness_threshold_cycles(cfg_freshness_threshold_cycles),
    .cfg_timeout_cycles(cfg_timeout_cycles),
    .response_accepted(response_accepted),
    .response_rejected_stale(response_rejected_stale),
    .response_rejected_duplicate(response_rejected_duplicate),
    .response_rejected_malformed(response_rejected_malformed),
    .response_timeout(response_timeout),
    .accepted_seq_out(accepted_seq_out),
    .accepted_result_word(accepted_result_word),
    .accepted_response_code(accepted_response_code),
    .accepted_metadata(accepted_metadata)
);

adaptive_aero_control_fsm u_fsm (
    .reg_clk(reg_clk),
    .reg_rst_n(reg_rst_n),
    .cfg_enable(cfg_enable),
    .cfg_mode(cfg_mode),
    .cfg_cmd_min(cfg_cmd_min),
    .cfg_cmd_max(cfg_cmd_max),
    .cfg_cmd_rate_limit(cfg_cmd_rate_limit),
    .cfg_interrupt_enable(cfg_interrupt_enable),
    .response_accepted(response_accepted),
    .response_rejected_stale(response_rejected_stale),
    .response_rejected_duplicate(response_rejected_duplicate),
    .response_rejected_malformed(response_rejected_malformed),
    .response_timeout(response_timeout),
    .vehicle_state_fault(vehicle_state_fault),
    .accepted_seq_in(accepted_seq_out),
    .accepted_result_word_in(accepted_result_word),
    .accepted_response_code_in(accepted_response_code),
    .accepted_metadata_in(accepted_metadata),
    .latest_seq_out(latest_seq_out),
    .latest_result_word_out(latest_result_word_out),
    .latest_response_code_out(latest_response_code_out),
    .fault_latched_out(fault_latched_out),
    .command_update_pulse(command_update_pulse),
    .command_valid_gate(command_valid_gate),
    .fallback_inhibit(fallback_inhibit)
);

adaptive_aero_command_shaper u_shaper (
    .reg_clk(reg_clk),
    .reg_rst_n(reg_rst_n),
    .cfg_cmd_min(cfg_cmd_min),
    .cfg_cmd_max(cfg_cmd_max),
    .cfg_cmd_rate_limit(cfg_cmd_rate_limit),
    .latest_result_word_in(latest_result_word_out),
    .latest_response_code_in(latest_response_code_out),
    .command_update_pulse_in(command_update_pulse),
    .command_valid_gate_in(command_valid_gate),
    .fallback_inhibit_in(fallback_inhibit),
    .actuator_cmd(actuator_cmd),
    .actuator_cmd_valid(actuator_cmd_valid),
    .actuator_clamped(actuator_clamped),
    .actuator_rate_limited(actuator_rate_limited),
    .actuator_safe_inhibit(actuator_safe_inhibit)
);

adaptive_aero_event_irq u_irq (
    .reg_clk(reg_clk),
    .reg_rst_n(reg_rst_n),
    .cfg_interrupt_enable(cfg_interrupt_enable),
    .response_accepted(response_accepted),
    .response_rejected_stale(response_rejected_stale),
    .response_timeout(response_timeout),
    .fallback_inhibit(fallback_inhibit),
    .irq_new_response(irq_new_response),
    .irq_stale_data(irq_stale_data),
    .irq_timeout(irq_timeout),
    .irq_fallback(irq_fallback),
    .event_latched_flags(event_latched_flags)
);

assign actuator_safe_fallback = actuator_safe_inhibit;

endmodule
