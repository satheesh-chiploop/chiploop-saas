# IP Packaging & Handoff Report

- Top: `motor_control_top`
- Package: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/94662c7b-f5fc-4681-b17e-848b5cd82ef3/cfac77a7-80c0-46df-9374-5b6b9c0e2365/digital/arch2tapeout/handoff/motor_control_top_ip_package`
- Zip: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/94662c7b-f5fc-4681-b17e-848b5cd82ef3/cfac77a7-80c0-46df-9374-5b6b9c0e2365/digital/arch2tapeout/handoff/motor_control_top_ip_package.zip`

## Bucket counts
- **rtl**: 8
- **spec**: 1
- **arch**: 0
- **microarch**: 0
- **regmap**: 1
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 2
