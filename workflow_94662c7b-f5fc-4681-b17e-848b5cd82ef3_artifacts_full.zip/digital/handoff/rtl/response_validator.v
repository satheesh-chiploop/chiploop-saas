module response_validator (
    input         clk,
    input         reset_n,
    input         rsp_out_valid,
    output        rsp_out_ready,
    input  [127:0] rsp_out_data,
    input         outstanding_valid,
    input  [15:0] outstanding_seq_id,
    input  [15:0] outstanding_age,
    input  [15:0] timeout_limit,
    input  [15:0] freshness_limit,
    input         model_available,
    output        rsp_validated,
    output        rsp_stale,
    output        rsp_seq_mismatch,
    output        rsp_timeout,
    output        rsp_invalid_frame,
    output        rsp_policy_violation,
    output [15:0] rsp_seq_id,
    output [31:0] rsp_act_cmd
);

reg rsp_out_ready_r;
reg rsp_validated_r;
reg rsp_stale_r;
reg rsp_seq_mismatch_r;
reg rsp_timeout_r;
reg rsp_invalid_frame_r;
reg rsp_policy_violation_r;
reg [15:0] rsp_seq_id_r;
reg [31:0] rsp_act_cmd_r;
wire [15:0] incoming_seq;
wire [31:0] incoming_cmd;
wire frame_valid;
wire timeout_hit;
wire freshness_hit;
wire seq_match;

assign incoming_seq = rsp_out_data[15:0];
assign incoming_cmd = rsp_out_data[63:32];
assign frame_valid = rsp_out_valid & rsp_out_data[127];
assign timeout_hit = outstanding_valid & (outstanding_age >= timeout_limit);
assign freshness_hit = outstanding_valid & (outstanding_age >= freshness_limit);
assign seq_match = outstanding_valid & (incoming_seq == outstanding_seq_id);

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        rsp_out_ready_r <= 1'b0;
        rsp_validated_r <= 1'b0;
        rsp_stale_r <= 1'b0;
        rsp_seq_mismatch_r <= 1'b0;
        rsp_timeout_r <= 1'b0;
        rsp_invalid_frame_r <= 1'b0;
        rsp_policy_violation_r <= 1'b0;
        rsp_seq_id_r <= 16'h0000;
        rsp_act_cmd_r <= 32'h00000000;
    end else begin
        rsp_out_ready_r <= 1'b1;
        rsp_validated_r <= 1'b0;
        rsp_stale_r <= 1'b0;
        rsp_seq_mismatch_r <= 1'b0;
        rsp_timeout_r <= 1'b0;
        rsp_invalid_frame_r <= 1'b0;
        rsp_policy_violation_r <= 1'b0;
        if (rsp_out_valid) begin
            rsp_seq_id_r <= incoming_seq;
            rsp_act_cmd_r <= incoming_cmd;
            if (!model_available) begin
                rsp_invalid_frame_r <= 1'b1;
            end else if (!frame_valid) begin
                rsp_invalid_frame_r <= 1'b1;
            end else if (timeout_hit) begin
                rsp_timeout_r <= 1'b1;
                rsp_stale_r <= 1'b1;
            end else if (freshness_hit) begin
                rsp_stale_r <= 1'b1;
            end else if (!seq_match) begin
                rsp_seq_mismatch_r <= 1'b1;
                rsp_stale_r <= 1'b1;
            end else begin
                rsp_validated_r <= 1'b1;
            end
            if (rsp_out_data[126]) begin
                rsp_policy_violation_r <= 1'b1;
            end
        end
    end
end

assign rsp_out_ready = rsp_out_ready_r;
assign rsp_validated = rsp_validated_r;
assign rsp_stale = rsp_stale_r;
assign rsp_seq_mismatch = rsp_seq_mismatch_r;
assign rsp_timeout = rsp_timeout_r;
assign rsp_invalid_frame = rsp_invalid_frame_r;
assign rsp_policy_violation = rsp_policy_violation_r;
assign rsp_seq_id = rsp_seq_id_r;
assign rsp_act_cmd = rsp_act_cmd_r;

endmodule
