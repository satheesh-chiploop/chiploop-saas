module actuator_clamp (
    input         clk,
    input         reset_n,
    input  [31:0] candidate_cmd,
    input  [31:0] clamp_min,
    input  [31:0] clamp_max,
    output [31:0] clamped_cmd,
    output        clamp_violation
);

reg [31:0] clamped_cmd_r;
reg clamp_violation_r;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        clamped_cmd_r <= 32'h00000000;
        clamp_violation_r <= 1'b0;
    end else begin
        if (candidate_cmd < clamp_min) begin
            clamped_cmd_r <= clamp_min;
            clamp_violation_r <= 1'b1;
        end else if (candidate_cmd > clamp_max) begin
            clamped_cmd_r <= clamp_max;
            clamp_violation_r <= 1'b1;
        end else begin
            clamped_cmd_r <= candidate_cmd;
            clamp_violation_r <= 1'b0;
        end
    end
end

assign clamped_cmd = clamped_cmd_r;
assign clamp_violation = clamp_violation_r;

endmodule
