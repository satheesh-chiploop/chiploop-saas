module safe_fallback_manager (
    input         clk,
    input         reset_n,
    input         fault_active,
    input         service_unavailable,
    input         timeout_active,
    input         invalid_response,
    input         stale_response,
    input  [31:0] candidate_cmd,
    input  [31:0] safe_fallback_cmd,
    output [31:0] selected_cmd,
    output        fallback_active
);

reg [31:0] selected_cmd_r;
reg fallback_active_r;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        selected_cmd_r <= safe_fallback_cmd;
        fallback_active_r <= 1'b1;
    end else begin
        if (fault_active | service_unavailable | timeout_active | invalid_response | stale_response) begin
            selected_cmd_r <= safe_fallback_cmd;
            fallback_active_r <= 1'b1;
        end else begin
            selected_cmd_r <= candidate_cmd;
            fallback_active_r <= 1'b0;
        end
    end
end

assign selected_cmd = selected_cmd_r;
assign fallback_active = fallback_active_r;

endmodule
