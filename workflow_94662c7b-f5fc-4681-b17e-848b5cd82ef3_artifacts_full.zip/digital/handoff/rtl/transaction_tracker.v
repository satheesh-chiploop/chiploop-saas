module transaction_tracker (
    input         clk,
    input         reset_n,
    input         req_accept,
    input  [15:0] req_seq_id_in,
    input  [15:0] req_timestamp_in,
    input  [31:0] req_payload_desc_in,
    output        busy,
    output        outstanding_valid,
    output [15:0] outstanding_seq_id,
    output [15:0] outstanding_timestamp,
    output [15:0] outstanding_age,
    output [7:0] outstanding_fault_reason,
    output [15:0] seq_counter,
    input         clear_outstanding
);

reg busy_r;
reg outstanding_valid_r;
reg [15:0] outstanding_seq_id_r;
reg [15:0] outstanding_timestamp_r;
reg [15:0] outstanding_age_r;
reg [7:0] outstanding_fault_reason_r;
reg [15:0] seq_counter_r;
reg [31:0] payload_shadow_r;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        busy_r <= 1'b0;
        outstanding_valid_r <= 1'b0;
        outstanding_seq_id_r <= 16'h0000;
        outstanding_timestamp_r <= 16'h0000;
        outstanding_age_r <= 16'h0000;
        outstanding_fault_reason_r <= 8'h00;
        seq_counter_r <= 16'h0001;
        payload_shadow_r <= 32'h00000000;
    end else begin
        if (clear_outstanding) begin
            busy_r <= 1'b0;
            outstanding_valid_r <= 1'b0;
            outstanding_seq_id_r <= 16'h0000;
            outstanding_timestamp_r <= 16'h0000;
            outstanding_age_r <= 16'h0000;
            outstanding_fault_reason_r <= 8'h00;
            payload_shadow_r <= 32'h00000000;
        end else begin
            if (req_accept && !busy_r) begin
                busy_r <= 1'b1;
                outstanding_valid_r <= 1'b1;
                outstanding_seq_id_r <= req_seq_id_in;
                outstanding_timestamp_r <= req_timestamp_in;
                outstanding_age_r <= 16'h0000;
                outstanding_fault_reason_r <= 8'h01;
                payload_shadow_r <= req_payload_desc_in;
                seq_counter_r <= seq_counter_r + 16'h0001;
            end else if (busy_r) begin
                outstanding_age_r <= outstanding_age_r + 16'h0001;
            end
        end
    end
end

assign busy = busy_r;
assign outstanding_valid = outstanding_valid_r;
assign outstanding_seq_id = outstanding_seq_id_r;
assign outstanding_timestamp = outstanding_timestamp_r;
assign outstanding_age = outstanding_age_r;
assign outstanding_fault_reason = outstanding_fault_reason_r;
assign seq_counter = seq_counter_r;

endmodule
