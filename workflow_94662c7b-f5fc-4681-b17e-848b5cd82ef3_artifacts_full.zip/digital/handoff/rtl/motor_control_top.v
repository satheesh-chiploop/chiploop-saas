module motor_control_top (
    input         clk,
    input         reset_n,
    input         cmd_in_valid,
    output        cmd_in_ready,
    input  [127:0] cmd_in_data,
    output        rsp_out_valid,
    input         rsp_out_ready,
    output [127:0] rsp_out_data,
    input         csr_valid,
    output        csr_ready,
    input         csr_write,
    input  [15:0] csr_addr,
    input  [31:0] csr_wdata,
    output [31:0] csr_rdata,
    output        csr_rvalid,
    output        act_cmd_valid,
    input         act_cmd_ready,
    output [31:0] act_cmd_data
);

wire req_accept;
wire req_malformed;
wire req_policy_violation;
wire [15:0] req_seq_id;
wire [15:0] req_timestamp;
wire [31:0] req_payload_desc;
wire [7:0] req_fault_reason;

wire busy;
wire outstanding_valid;
wire [15:0] outstanding_seq_id;
wire [15:0] outstanding_timestamp;
wire [15:0] outstanding_age;
wire [7:0] outstanding_fault_reason;
wire [15:0] seq_counter;

wire rsp_validated;
wire rsp_stale;
wire rsp_seq_mismatch;
wire rsp_timeout;
wire rsp_invalid_frame;
wire rsp_policy_violation;
wire [15:0] rsp_seq_id;
wire [31:0] rsp_act_cmd;

wire [31:0] clamped_cmd;
wire clamp_violation;

wire fault_active;
wire [31:0] sticky_fault_status;
wire [7:0] last_fault_code;
wire [15:0] last_rejected_seq_id;

wire control_enable;
wire fault_clear;
wire model_available;
wire [15:0] request_timeout;
wire [15:0] freshness_limit;
wire [31:0] actuator_min;
wire [31:0] actuator_max;
wire [31:0] safe_fallback_cmd;

wire fallback_active;
wire [31:0] selected_cmd;
wire [15:0] outstanding_seq_id_unused_from_u_csr_register_file_last_sequence_id;
wire rsp_out_ready_from_u_response_validator;
request_validator u_request_validator (
    .clk(clk),
    .reset_n(reset_n),
    .cmd_in_valid(cmd_in_valid),
    .cmd_in_ready(cmd_in_ready),
    .cmd_in_data(cmd_in_data),
    .req_accept(req_accept),
    .req_malformed(req_malformed),
    .req_policy_violation(req_policy_violation),
    .req_seq_id(req_seq_id),
    .req_timestamp(req_timestamp),
    .req_payload_desc(req_payload_desc),
    .req_fault_reason(req_fault_reason)
);

transaction_tracker u_transaction_tracker (
    .clk(clk),
    .reset_n(reset_n),
    .req_accept(req_accept),
    .req_seq_id_in(req_seq_id),
    .req_timestamp_in(req_timestamp),
    .req_payload_desc_in(req_payload_desc),
    .busy(busy),
    .outstanding_valid(outstanding_valid),
    .outstanding_seq_id(outstanding_seq_id),
    .outstanding_timestamp(outstanding_timestamp),
    .outstanding_age(outstanding_age),
    .outstanding_fault_reason(outstanding_fault_reason),
    .seq_counter(seq_counter),
    .clear_outstanding(fault_clear)
);

response_validator u_response_validator (
    .clk(clk),
    .reset_n(reset_n),
    .rsp_out_valid(rsp_out_valid),
    .rsp_out_ready(rsp_out_ready_from_u_response_validator),
    .rsp_out_data(rsp_out_data),
    .outstanding_valid(outstanding_valid),
    .outstanding_seq_id(outstanding_seq_id),
    .outstanding_age(outstanding_age),
    .timeout_limit(request_timeout),
    .freshness_limit(freshness_limit),
    .model_available(model_available),
    .rsp_validated(rsp_validated),
    .rsp_stale(rsp_stale),
    .rsp_seq_mismatch(rsp_seq_mismatch),
    .rsp_timeout(rsp_timeout),
    .rsp_invalid_frame(rsp_invalid_frame),
    .rsp_policy_violation(rsp_policy_violation),
    .rsp_seq_id(rsp_seq_id),
    .rsp_act_cmd(rsp_act_cmd)
);

actuator_clamp u_actuator_clamp (
    .clk(clk),
    .reset_n(reset_n),
    .candidate_cmd(rsp_act_cmd),
    .clamp_min(actuator_min),
    .clamp_max(actuator_max),
    .clamped_cmd(clamped_cmd),
    .clamp_violation(clamp_violation)
);

safe_fallback_manager u_safe_fallback_manager (
    .clk(clk),
    .reset_n(reset_n),
    .fault_active(fault_active),
    .service_unavailable(~control_enable | ~model_available),
    .timeout_active(rsp_timeout),
    .invalid_response(~rsp_validated | rsp_invalid_frame),
    .stale_response(rsp_stale),
    .candidate_cmd(clamped_cmd),
    .safe_fallback_cmd(safe_fallback_cmd),
    .selected_cmd(selected_cmd),
    .fallback_active(fallback_active)
);

csr_register_file u_csr_register_file (
    .clk(clk),
    .reset_n(reset_n),
    .csr_valid(csr_valid),
    .csr_ready(csr_ready),
    .csr_write(csr_write),
    .csr_addr(csr_addr),
    .csr_wdata(csr_wdata),
    .csr_rdata(csr_rdata),
    .csr_rvalid(csr_rvalid),
    .control_enable(control_enable),
    .fault_clear(fault_clear),
    .model_available(model_available),
    .request_timeout(request_timeout),
    .freshness_limit(freshness_limit),
    .actuator_min(actuator_min),
    .actuator_max(actuator_max),
    .safe_fallback_cmd(safe_fallback_cmd),
    .sticky_fault_status(sticky_fault_status),
    .last_sequence_id(outstanding_seq_id_unused_from_u_csr_register_file_last_sequence_id),
    .last_fault_code(last_fault_code),
    .transaction_busy(busy)
);

fault_manager u_fault_manager (
    .clk(clk),
    .reset_n(reset_n),
    .req_malformed(req_malformed),
    .req_policy_violation(req_policy_violation),
    .rsp_stale(rsp_stale),
    .rsp_seq_mismatch(rsp_seq_mismatch),
    .rsp_timeout(rsp_timeout),
    .rsp_policy_violation(rsp_policy_violation),
    .rsp_invalid_frame(rsp_invalid_frame),
    .service_unavailable(~control_enable | ~model_available),
    .clamp_violation(clamp_violation),
    .fault_clear(fault_clear),
    .sticky_fault_status(sticky_fault_status),
    .last_fault_code(last_fault_code),
    .last_rejected_seq_id(last_rejected_seq_id),
    .fault_active(fault_active)
);

assign act_cmd_valid = fallback_active;
assign act_cmd_data = selected_cmd;

endmodule
