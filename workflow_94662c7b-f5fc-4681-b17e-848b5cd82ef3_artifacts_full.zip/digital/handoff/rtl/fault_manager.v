module fault_manager (
    input         clk,
    input         reset_n,
    input         req_malformed,
    input         req_policy_violation,
    input         rsp_stale,
    input         rsp_seq_mismatch,
    input         rsp_timeout,
    input         rsp_policy_violation,
    input         rsp_invalid_frame,
    input         service_unavailable,
    input         clamp_violation,
    input         fault_clear,
    output [31:0] sticky_fault_status,
    output [7:0] last_fault_code,
    output [15:0] last_rejected_seq_id,
    output        fault_active
);

reg [31:0] sticky_fault_status_r;
reg [7:0] last_fault_code_r;
reg [15:0] last_rejected_seq_id_r;
reg fault_active_r;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        sticky_fault_status_r <= 32'h00000000;
        last_fault_code_r <= 8'h00;
        last_rejected_seq_id_r <= 16'h0000;
        fault_active_r <= 1'b0;
    end else begin
        if (fault_clear) begin
            sticky_fault_status_r <= 32'h00000000;
            last_fault_code_r <= 8'h00;
            last_rejected_seq_id_r <= 16'h0000;
            fault_active_r <= 1'b0;
        end else begin
            if (req_malformed) sticky_fault_status_r[0] <= 1'b1;
            if (req_policy_violation) sticky_fault_status_r[1] <= 1'b1;
            if (rsp_stale) sticky_fault_status_r[2] <= 1'b1;
            if (rsp_seq_mismatch) sticky_fault_status_r[3] <= 1'b1;
            if (rsp_timeout) sticky_fault_status_r[4] <= 1'b1;
            if (rsp_policy_violation) sticky_fault_status_r[5] <= 1'b1;
            if (rsp_invalid_frame) sticky_fault_status_r[6] <= 1'b1;
            if (service_unavailable) sticky_fault_status_r[7] <= 1'b1;
            if (clamp_violation) sticky_fault_status_r[8] <= 1'b1;
            fault_active_r <= req_malformed | req_policy_violation | rsp_stale | rsp_seq_mismatch | rsp_timeout | rsp_policy_violation | rsp_invalid_frame | service_unavailable | clamp_violation;
            if (req_malformed) last_fault_code_r <= 8'h01;
            else if (req_policy_violation) last_fault_code_r <= 8'h02;
            else if (rsp_stale) last_fault_code_r <= 8'h03;
            else if (rsp_seq_mismatch) last_fault_code_r <= 8'h04;
            else if (rsp_timeout) last_fault_code_r <= 8'h05;
            else if (rsp_policy_violation) last_fault_code_r <= 8'h06;
            else if (rsp_invalid_frame) last_fault_code_r <= 8'h07;
            else if (service_unavailable) last_fault_code_r <= 8'h08;
            else if (clamp_violation) last_fault_code_r <= 8'h09;
            if (req_malformed | req_policy_violation | rsp_stale | rsp_seq_mismatch | rsp_timeout | rsp_policy_violation | rsp_invalid_frame | service_unavailable | clamp_violation) begin
                last_rejected_seq_id_r <= last_rejected_seq_id_r + 16'h0001;
            end
        end
    end
end

assign sticky_fault_status = sticky_fault_status_r;
assign last_fault_code = last_fault_code_r;
assign last_rejected_seq_id = last_rejected_seq_id_r;
assign fault_active = fault_active_r;

endmodule
