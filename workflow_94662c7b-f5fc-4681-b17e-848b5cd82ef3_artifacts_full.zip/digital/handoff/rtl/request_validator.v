module request_validator (
    input         clk,
    input         reset_n,
    input         cmd_in_valid,
    output        cmd_in_ready,
    input  [127:0] cmd_in_data,
    output        req_accept,
    output        req_malformed,
    output        req_policy_violation,
    output [15:0] req_seq_id,
    output [15:0] req_timestamp,
    output [31:0] req_payload_desc,
    output [7:0] req_fault_reason
);

reg cmd_in_ready_r;
reg req_accept_r;
reg req_malformed_r;
reg req_policy_violation_r;
reg [15:0] req_seq_id_r;
reg [15:0] req_timestamp_r;
reg [31:0] req_payload_desc_r;
reg [7:0] req_fault_reason_r;
wire [15:0] seq_field;
wire [15:0] timestamp_field;
wire [31:0] payload_field;
wire [7:0] fault_reason_field;
wire malformed_field;
wire policy_field;
wire accept_field;

assign seq_field = cmd_in_data[15:0];
assign timestamp_field = cmd_in_data[31:16];
assign payload_field = cmd_in_data[63:32];
assign fault_reason_field = cmd_in_data[71:64];
assign malformed_field = cmd_in_valid & cmd_in_data[127];
assign policy_field = cmd_in_valid & cmd_in_data[126];
assign accept_field = cmd_in_valid & ~malformed_field & ~policy_field;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        cmd_in_ready_r <= 1'b1;
        req_accept_r <= 1'b0;
        req_malformed_r <= 1'b0;
        req_policy_violation_r <= 1'b0;
        req_seq_id_r <= 16'h0000;
        req_timestamp_r <= 16'h0000;
        req_payload_desc_r <= 32'h00000000;
        req_fault_reason_r <= 8'h00;
    end else begin
        cmd_in_ready_r <= 1'b1;
        req_accept_r <= accept_field;
        req_malformed_r <= malformed_field;
        req_policy_violation_r <= policy_field;
        if (accept_field) begin
            req_seq_id_r <= seq_field;
            req_timestamp_r <= timestamp_field;
            req_payload_desc_r <= payload_field;
            req_fault_reason_r <= fault_reason_field;
        end else if (cmd_in_valid) begin
            req_seq_id_r <= seq_field;
            req_timestamp_r <= timestamp_field;
            req_payload_desc_r <= payload_field;
            req_fault_reason_r <= fault_reason_field;
        end
    end
end

assign cmd_in_ready = cmd_in_ready_r;
assign req_accept = req_accept_r;
assign req_malformed = req_malformed_r;
assign req_policy_violation = req_policy_violation_r;
assign req_seq_id = req_seq_id_r;
assign req_timestamp = req_timestamp_r;
assign req_payload_desc = req_payload_desc_r;
assign req_fault_reason = req_fault_reason_r;

endmodule
