module csr_register_file (
    input         clk,
    input         reset_n,
    input         csr_valid,
    output        csr_ready,
    input         csr_write,
    input  [15:0] csr_addr,
    input  [31:0] csr_wdata,
    output [31:0] csr_rdata,
    output        csr_rvalid,
    output        control_enable,
    output        fault_clear,
    output        model_available,
    output [15:0] request_timeout,
    output [15:0] freshness_limit,
    output [31:0] actuator_min,
    output [31:0] actuator_max,
    output [31:0] safe_fallback_cmd,
    input  [31:0] sticky_fault_status,
    output [15:0] last_sequence_id,
    input  [7:0] last_fault_code,
    input         transaction_busy
);

reg csr_ready_r;
reg [31:0] csr_rdata_r;
reg csr_rvalid_r;
reg control_enable_r;
reg model_available_r;
reg [15:0] request_timeout_r;
reg [15:0] freshness_limit_r;
reg [31:0] actuator_min_r;
reg [31:0] actuator_max_r;
reg [31:0] safe_fallback_cmd_r;
reg [15:0] last_sequence_id_r;
reg fault_clear_r;
reg [7:0] fault_clear_pulse_hold;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        csr_ready_r <= 1'b1;
        csr_rdata_r <= 32'h00000000;
        csr_rvalid_r <= 1'b0;
        control_enable_r <= 1'b0;
        model_available_r <= 1'b0;
        request_timeout_r <= 16'h0020;
        freshness_limit_r <= 16'h0010;
        actuator_min_r <= 32'h00000000;
        actuator_max_r <= 32'h00FFFFFF;
        safe_fallback_cmd_r <= 32'h00000000;
        last_sequence_id_r <= 16'h0000;
        fault_clear_r <= 1'b0;
        fault_clear_pulse_hold <= 8'h00;
    end else begin
        csr_ready_r <= 1'b1;
        csr_rvalid_r <= csr_valid;
        fault_clear_r <= 1'b0;
        if (csr_valid) begin
            if (csr_write) begin
                case (csr_addr[7:0])
                    8'h00: begin
                        control_enable_r <= csr_wdata[0];
                        if (csr_wdata[1]) fault_clear_r <= 1'b1;
                        model_available_r <= csr_wdata[2];
                    end
                    8'h01: request_timeout_r[7:0] <= csr_wdata[7:0];
                    8'h02: request_timeout_r[15:8] <= csr_wdata[7:0];
                    8'h03: freshness_limit_r[7:0] <= csr_wdata[7:0];
                    8'h04: freshness_limit_r[15:8] <= csr_wdata[7:0];
                    8'h05: actuator_min_r[7:0] <= csr_wdata[7:0];
                    8'h06: actuator_min_r[15:8] <= csr_wdata[7:0];
                    8'h07: actuator_min_r[23:16] <= csr_wdata[7:0];
                    8'h08: actuator_min_r[31:24] <= csr_wdata[7:0];
                    8'h09: actuator_max_r[7:0] <= csr_wdata[7:0];
                    8'h0A: actuator_max_r[15:8] <= csr_wdata[7:0];
                    8'h0B: actuator_max_r[23:16] <= csr_wdata[7:0];
                    8'h0C: actuator_max_r[31:24] <= csr_wdata[7:0];
                    8'h0D: safe_fallback_cmd_r[7:0] <= csr_wdata[7:0];
                    8'h0E: safe_fallback_cmd_r[15:8] <= csr_wdata[7:0];
                    8'h0F: safe_fallback_cmd_r[23:16] <= csr_wdata[7:0];
                    8'h10: safe_fallback_cmd_r[31:24] <= csr_wdata[7:0];
                    8'h12: last_sequence_id_r[7:0] <= csr_wdata[7:0];
                    8'h13: last_sequence_id_r[15:8] <= csr_wdata[7:0];
                    default: begin
                    end
                endcase
            end
            case (csr_addr[7:0])
                8'h00: csr_rdata_r <= {29'h00000000, model_available_r, control_enable_r, 1'b0};
                8'h01: csr_rdata_r <= {24'h000000, request_timeout_r[7:0]};
                8'h02: csr_rdata_r <= {24'h000000, request_timeout_r[15:8]};
                8'h03: csr_rdata_r <= {24'h000000, freshness_limit_r[7:0]};
                8'h04: csr_rdata_r <= {24'h000000, freshness_limit_r[15:8]};
                8'h05: csr_rdata_r <= {24'h000000, actuator_min_r[7:0]};
                8'h06: csr_rdata_r <= {24'h000000, actuator_min_r[15:8]};
                8'h07: csr_rdata_r <= {24'h000000, actuator_min_r[23:16]};
                8'h08: csr_rdata_r <= {24'h000000, actuator_min_r[31:24]};
                8'h09: csr_rdata_r <= {24'h000000, actuator_max_r[7:0]};
                8'h0A: csr_rdata_r <= {24'h000000, actuator_max_r[15:8]};
                8'h0B: csr_rdata_r <= {24'h000000, actuator_max_r[23:16]};
                8'h0C: csr_rdata_r <= {24'h000000, actuator_max_r[31:24]};
                8'h0D: csr_rdata_r <= {24'h000000, safe_fallback_cmd_r[7:0]};
                8'h0E: csr_rdata_r <= {24'h000000, safe_fallback_cmd_r[15:8]};
                8'h0F: csr_rdata_r <= {24'h000000, safe_fallback_cmd_r[23:16]};
                8'h10: csr_rdata_r <= {24'h000000, safe_fallback_cmd_r[31:24]};
                8'h11: csr_rdata_r <= {24'h000000, transaction_busy, 1'b0, 1'b0, 1'b0, model_available_r, control_enable_r, 1'b0};
                8'h12: csr_rdata_r <= {24'h000000, last_sequence_id_r[7:0]};
                8'h13: csr_rdata_r <= {24'h000000, last_sequence_id_r[15:8]};
                8'h14: csr_rdata_r <= {24'h000000, last_fault_code};
                8'h15: csr_rdata_r <= {24'h000000, sticky_fault_status[7:0]};
                8'h16: csr_rdata_r <= {24'h000000, sticky_fault_status[15:8]};
                8'h17: csr_rdata_r <= {24'h000000, sticky_fault_status[23:16]};
                8'h18: csr_rdata_r <= {24'h000000, sticky_fault_status[31:24]};
                8'h19: csr_rdata_r <= {24'h000000, 8'h00};
                8'h1A: csr_rdata_r <= {24'h000000, 8'h00};
                8'h1B: csr_rdata_r <= {24'h000000, 8'h00};
                default: csr_rdata_r <= 32'h00000000;
            endcase
        end
        if (csr_valid && csr_write && csr_addr[7:0] == 8'h00 && csr_wdata[1]) begin
            fault_clear_r <= 1'b1;
        end
        if (fault_clear_r) begin
            fault_clear_pulse_hold <= 8'h01;
        end else begin
            fault_clear_pulse_hold <= 8'h00;
        end
    end
end

assign csr_ready = csr_ready_r;
assign csr_rdata = csr_rdata_r;
assign csr_rvalid = csr_rvalid_r;
assign control_enable = control_enable_r;
assign fault_clear = fault_clear_r;
assign model_available = model_available_r;
assign request_timeout = request_timeout_r;
assign freshness_limit = freshness_limit_r;
assign actuator_min = actuator_min_r;
assign actuator_max = actuator_max_r;
assign safe_fallback_cmd = safe_fallback_cmd_r;
assign last_sequence_id = last_sequence_id_r;

endmodule
