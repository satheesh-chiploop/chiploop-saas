/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/94662c7b-f5fc-4681-b17e-848b5cd82ef3/cfac77a7-80c0-46df-9374-5b6b9c0e2365/digital/arch2tapeout/handoff/rtl/fault_manager.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/94662c7b-f5fc-4681-b17e-848b5cd82ef3/cfac77a7-80c0-46df-9374-5b6b9c0e2365/digital/arch2tapeout/handoff/rtl/actuator_clamp.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/94662c7b-f5fc-4681-b17e-848b5cd82ef3/cfac77a7-80c0-46df-9374-5b6b9c0e2365/digital/arch2tapeout/handoff/rtl/csr_register_file.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/94662c7b-f5fc-4681-b17e-848b5cd82ef3/cfac77a7-80c0-46df-9374-5b6b9c0e2365/digital/arch2tapeout/handoff/rtl/motor_control_top.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/94662c7b-f5fc-4681-b17e-848b5cd82ef3/cfac77a7-80c0-46df-9374-5b6b9c0e2365/digital/arch2tapeout/handoff/rtl/request_validator.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/94662c7b-f5fc-4681-b17e-848b5cd82ef3/cfac77a7-80c0-46df-9374-5b6b9c0e2365/digital/arch2tapeout/handoff/rtl/response_validator.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/94662c7b-f5fc-4681-b17e-848b5cd82ef3/cfac77a7-80c0-46df-9374-5b6b9c0e2365/digital/arch2tapeout/handoff/rtl/transaction_tracker.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/94662c7b-f5fc-4681-b17e-848b5cd82ef3/cfac77a7-80c0-46df-9374-5b6b9c0e2365/digital/arch2tapeout/handoff/rtl/safe_fallback_manager.v
