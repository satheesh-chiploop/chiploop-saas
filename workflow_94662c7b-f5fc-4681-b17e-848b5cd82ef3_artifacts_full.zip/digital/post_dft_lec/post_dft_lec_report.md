# Digital Post-DFT Logic Equivalence Check

- Status: `inconclusive_unresolved_cells`
- Failure reason: `yosys_inconclusive_see_post_dft_lec_log`
- Top module: `motor_control_top`
- Synthesis netlist: `motor_control_top_synth.v`
- Post-DFT netlist: `scan_stitched_netlist.v`
- Unproven points: `0`
