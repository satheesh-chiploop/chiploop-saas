# Digital Synthesis Summary

- **Workflow**: 94662c7b-f5fc-4681-b17e-848b5cd82ef3
- **Status**: `failed` (rc=2)
- **Top module**: `motor_control_top`
- **Clock**: `clk` @ **10.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `not found`
- netlist candidates: 1 found
