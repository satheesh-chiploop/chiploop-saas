# IP Packaging & Handoff Report

- Top: `top`
- Package: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/440e3d62-bf3a-4c0b-a381-dda42b45d958/24b6c5d7-7c0c-4fad-ab10-04f856461f6f/digital/handoff/top_ip_package`
- Zip: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/440e3d62-bf3a-4c0b-a381-dda42b45d958/24b6c5d7-7c0c-4fad-ab10-04f856461f6f/digital/handoff/top_ip_package.zip`

## Bucket counts
- **rtl**: 0
- **spec**: 0
- **arch**: 0
- **microarch**: 0
- **regmap**: 0
- **constraints**: 0
- **power_intent**: 0
- **verification**: 0
- **reports**: 0
- **other**: 0
