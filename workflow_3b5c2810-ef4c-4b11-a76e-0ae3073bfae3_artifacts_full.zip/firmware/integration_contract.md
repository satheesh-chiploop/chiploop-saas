# firmware/integration_contract.md

## Contract overview
- This contract defines the host-side SPI device layer and portable driver service boundary for `intelligent_active_aerodynamics_controller` using the approved partition and existing RTL register collateral.
- Target refinement is **portable-only** on `ulx3s_ecp5_45f`; deployment architecture is **fpga_external_host**.
- The hardware-facing boundary is limited to compact control/status exchanges; bulk geometry remains outside RTL and is referenced only by `geometry_handle`.
- The device-layer scope is currently **empty** (`Device-layer jobs: []`); therefore this contract specifies interfaces, ownership, and validation hooks rather than implementation work.
- `portable_source_ready = true`; `deployable_binary_ready = false`. No deployable binary shall be claimed until the missing `host_transport_and_board_wrapper` gate is complete.
- The host transport is **not selected**; this contract keeps transport abstract and leaves board-specific SPI wrapping to the missing gate.
- Fault handling must be explicit: stale-data, timeout, fallback-active, clamp, and rejection conditions must be surfaced through the telemetry and fault/safety interfaces.
- Versioning and compatibility are governed by a strict additive policy for host-visible schema and register semantics.

## Contract version + compatibility policy
- **Contract schema**: `chiploop.application_intelligence.target_refinement.v1`
- **Contract version**: `1.0.0-portable`
- **Compatibility policy**:
  - **Backward compatible** within the same major version for additive fields and telemetry events.
  - **Breaking changes** require a major version bump and a new validation pass against RTL collateral.
  - Host software must tolerate unknown optional telemetry fields and status codes as long as required fields remain present.
  - FPGA-side register meanings derived from RTL collateral are immutable unless the register map revision is explicitly re-baselined.
  - No board-specific binary compatibility is promised until `host_transport_and_board_wrapper` is delivered and verified.

## Interfaces

### Interface summary

| Name | From | To | Description | Contract notes |
|---|---|---|---|---|
| `stl_geometry_ingest` | software | software | STL or conforming geometry input from DrivAerML-equivalent source into the geometry normalization pipeline. | Host-only; no RTL exposure. |
| `geometry_handle` | software | gpu_service | Compact reference to normalized geometry; avoids exposing bulk geometry to RTL. | Opaque handle only; lifetime managed by host/service. |
| `flow_condition_summary` | fpga | gpu_service | Compact operating-condition descriptor including stream velocity, sequence ID, and freshness metadata. | FPGA emits; must include freshness and sequence ID. |
| `surrogate_response_stream` | gpu_service | fpga | Bounded response carrying predicted aerodynamic summaries, status codes, and freshness tags. | Must be bounded; reject oversize/late responses. |
| `reference_validation_path` | cpu_software | gpu_service | Paired reference and surrogate outputs for error measurement and auditability. | Validation-only path; not part of runtime actuation loop. |
| `actuator_command_bus` | fpga | actuation | Clamped, validated actuator command with explicit min/max enforcement and fallback state support. | FPGA-owned command source; safety clamping mandatory. |
| `fault_and_safety_signals` | fpga | supervision | Sticky fault indications, stale-data flags, timeout flags, and fallback-active status. | Sticky until cleared by defined recovery policy. |
| `telemetry_stream` | fpga | software | Cycle timing, rejection events, clamp events, timeout events, and fallback activations for verification and logging. | Verification/logging sink; append-only semantics preferred. |

### Host-side SPI device layer and portable driver service contract

| Element | Direction | Required behavior | Ownership |
|---|---|---|---|
| SPI device layer | host ↔ FPGA | Provide register-accurate access to RTL collateral via the selected transport abstraction once chosen. No board wrapper assumptions before gate completion. | Host/System |
| Portable driver service | host | Expose a transport-neutral API over the device layer for geometry handle exchange, condition summary transfer, response polling, and telemetry collection. | Host/System |
| Register semantics | host ↔ FPGA | Preserve RTL-defined field meanings, reset behavior, sticky fault semantics, and freshness/sequence checks. | Shared by contract; RTL authoritative for hardware fields |
| Failure signaling | FPGA → host | Report stale, timeout, invalid-response, clamp, and fallback conditions through fault and telemetry paths. | FPGA source of truth for hardware-side fault state |
| Validation bridge | host ↔ GPU service | Carry `reference_validation_path` only in validation mode; not required for runtime actuation. | Validation/System |

### Operational behavior
- `stl_geometry_ingest` is normalized on the host side before a `geometry_handle` is created.
- `geometry_handle` must be opaque and compact; it may reference host-managed buffers, but must not expose raw geometry into RTL.
- `flow_condition_summary` must include at minimum:
  - stream velocity
  - sequence ID
  - freshness metadata
- `surrogate_response_stream` must include:
  - predicted aerodynamic summaries
  - status codes
  - freshness tags
- `actuator_command_bus` must enforce:
  - explicit min/max clamping
  - fallback state support
  - rejection of invalid or stale inputs
- `fault_and_safety_signals` must be sticky for fault classes that affect safety or correctness until cleared by the defined recovery policy.
- `telemetry_stream` must log:
  - cycle timing
  - rejection events
  - clamp events
  - timeout events
  - fallback activations

### Error code and status policy
- Host and FPGA-facing status values must distinguish:
  - success
  - stale data
  - timeout
  - invalid sequence
  - invalid bounds
  - fallback active
  - transport error
  - unsupported revision
- Error codes must be stable across portable targets within the same major version.
- Unknown status values observed by the host must be treated as non-success and logged verbatim.

## Ownership boundaries

| Area | FW / FPGA ownership | System / Host ownership | Validation ownership |
|---|---|---|---|
| Register map and sticky fault behavior | Defines and implements RTL-backed semantics | Reads, interprets, and logs | Verifies reset, fault stickiness, and recovery |
| Geometry normalization | None | Owns STL ingest and normalization pipeline | Supplies test geometries and golden handles |
| Geometry handle lifecycle | Consumes opaque handle only if needed by service path | Creates, validates, and retires handle | Checks lifetime, aliasing, and invalid-handle rejection |
| SPI transport selection | None until board wrapper gate is present | Chooses and implements transport wrapper | Confirms transport conformance on target board |
| Actuator command clamping | May consume clamped command and expose safety state | Must enforce pre-transport validation and service checks | Exercises min/max, fallback, and invalid input cases |
| Telemetry collection | Emits cycle/fault/event data | Collects, timestamps, and stores logs | Verifies completeness and ordering |
| Reference validation path | No runtime dependency | Provides paired reference/surrogate outputs in validation mode | Compares outputs and records error metrics |

## Assumptions
- `host_transport_and_board_wrapper` is not yet available and remains the gating item for a deployable binary.
- The selected board is `ulx3s_ecp5_45f`, but no board-specific transport binding is assumed in this contract.
- Existing RTL register collateral is the source of truth for hardware-visible field semantics.
- The GPU service is external to RTL and communicates only through the defined compact interfaces.
- No device-layer jobs are currently assigned; implementation work is pending host transport selection.
- Geometry bulk data stays in software-managed memory and is never directly exposed to RTL.
- Validation may use `reference_validation_path` independently of runtime actuation.
- This contract does not define interrupts, DMA, or power modes because they were not explicitly requested in the user spec.

## Validation hooks
- **Register conformance tests**: Read/write against RTL collateral to confirm field widths, reset values, sticky fault semantics, and unsupported-revision handling.
- **Transport abstraction tests**: Run the portable driver service against a mock transport before board wrapper integration.
- **Geometry ingest tests**: Feed valid and invalid STL/conforming inputs to confirm normalization, handle creation, and rejection paths.
- **Sequence/freshness tests**: Inject out-of-order, stale, and duplicated `flow_condition_summary` messages and verify rejection or fallback behavior.
- **Clamp tests**: Drive actuator requests beyond min/max limits and confirm bounded `actuator_command_bus` output plus telemetry logging.
- **Fault stickiness tests**: Trigger stale-data, timeout, and invalid-response conditions and confirm `fault_and_safety_signals` remain asserted until cleared by policy.
- **Telemetry completeness tests**: Verify that cycle timing, rejection, clamp, timeout, and fallback events are emitted and persisted.
- **Validation-path tests**: Provide paired reference and surrogate outputs via `reference_validation_path` and confirm error measurement and audit logging.
- **Gate readiness test**: Confirm that no deployable binary is claimed until `host_transport_and_board_wrapper` is implemented and validated on `ulx3s_ecp5_45f`.