<!-- ASSUMPTION: RTL_TOP, RTL_DIR, and FILELIST are supplied by the integration environment or by the approved build collateral. -->
<!-- ASSUMPTION: The co-simulation flow uses Verilator + cocotb + pytest, with optional JUnit and coverage artifacts enabled when supported by the environment. -->
<!-- ASSUMPTION: Host-side firmware/source build is only performed if source and a build manifest are available; no deployable binary is claimed here. -->
# Co-simulation run plan

## Prerequisites
- Verilator
- Python 3
- pytest
- cocotb
- A C/C++ toolchain required by Verilator-generated builds
- Optional: coverage tooling if enabled by the environment

## Environment variables
Set these before running the flow, or allow the defaults in the runner script to apply:
- `RTL_TOP`
- `RTL_DIR`
- `FILELIST`
- `COCOTB_TEST_MODULE`
- `COCOTB_TESTCASE`
- `PYTHON`
- `VERILATOR`
- `BUILD_DIR`
- `OUT_DIR`

## Build and run commands

### 1) Build RTL simulation
If `firmware/validate/verilator_build.md` exists, follow that document exactly for the build step.

Otherwise, the expected generic pattern is:
1. Export environment overrides:
   - `export RTL_TOP=<RTL_TOP>`
   - `export RTL_DIR=<RTL_DIR>`
   - `export FILELIST=<FILELIST>`
2. Create an output directory under `firmware/validate/`
3. Invoke the Verilator build using the approved filelist and top module
4. Preserve generated simulator artifacts under `firmware/validate/build/`

### 2) Build FW, if applicable
Only perform a firmware build if source and a manifest/build command are available in the repository collateral. For portable-only validation, this step may be a no-op.

Typical host-side source build pattern:
- `cargo build --target x86_64-unknown-linux-gnu`
- or an equivalent project-specific build command if provided by the repository

Do not claim a deployable binary unless the platform contract gate is ready.

### 3) Run cocotb
Run the Python test harness through pytest:
- `pytest -q <testpath> --junitxml=firmware/validate/junit.xml`

If cocotb requires simulator variables, ensure they are exported before invoking pytest.

## Expected outputs
The run should produce artifacts under `firmware/validate/`, such as:
- `firmware/validate/build/` or equivalent Verilator build directory
- `firmware/validate/logs/` containing simulator and test logs
- `firmware/validate/junit.xml` when JUnit output is enabled
- Optional coverage outputs, such as:
  - `firmware/validate/coverage.dat`
  - `firmware/validate/coverage.info`
  - Verilator coverage reports, if enabled

## Notes
- The runner script is designed to fail fast if required environment variables or files are missing.
- The flow intentionally remains portable-only and does not assume a board-specific transport or wrapper has been finalized.
