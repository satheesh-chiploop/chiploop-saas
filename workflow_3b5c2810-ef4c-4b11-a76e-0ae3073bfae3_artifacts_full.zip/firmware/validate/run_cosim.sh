#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
VALIDATE_DIR="${ROOT_DIR}/firmware/validate"

RTL_TOP=${RTL_TOP:-<RTL_TOP>}
RTL_DIR=${RTL_DIR:-<RTL_DIR>}
FILELIST=${FILELIST:-<FILELIST>}
COCOTB_TEST_MODULE=${COCOTB_TEST_MODULE:-<COCOTB_TEST_MODULE>}
COCOTB_TESTCASE=${COCOTB_TESTCASE:-}
PYTHON=${PYTHON:-python3}
VERILATOR=${VERILATOR:-verilator}
BUILD_DIR=${BUILD_DIR:-"${VALIDATE_DIR}/build"}
OUT_DIR=${OUT_DIR:-"${VALIDATE_DIR}/logs"}
JUNIT_XML=${JUNIT_XML:-"${VALIDATE_DIR}/junit.xml"}

mkdir -p "${BUILD_DIR}" "${OUT_DIR}"

for req in RTL_TOP RTL_DIR FILELIST COCOTB_TEST_MODULE; do
  if [[ -z "${!req}" || "${!req}" == "<${req}>" ]]; then
    echo "ERROR: environment variable ${req} must be set" >&2
    exit 1
  fi
done

if [[ ! -d "${RTL_DIR}" ]]; then
  echo "ERROR: RTL_DIR does not exist: ${RTL_DIR}" >&2
  exit 1
fi

if [[ ! -f "${FILELIST}" ]]; then
  echo "ERROR: FILELIST does not exist: ${FILELIST}" >&2
  exit 1
fi

VERILATOR_BUILD_MD="${VALIDATE_DIR}/verilator_build.md"
if [[ -f "${VERILATOR_BUILD_MD}" ]]; then
  echo "INFO: Refer to ${VERILATOR_BUILD_MD} for the preferred Verilator build procedure" | tee "${OUT_DIR}/build_hint.log"
fi

if [[ -n "${COCOTB_TESTCASE}" ]]; then
  COCOTB_TESTCASE_ARG=(-k "${COCOTB_TESTCASE}")
else
  COCOTB_TESTCASE_ARG=()
fi

export RTL_TOP RTL_DIR FILELIST BUILD_DIR OUT_DIR
export TOPLEVEL="${RTL_TOP}"
export MODULE="${COCOTB_TEST_MODULE}"
export PYTHONPATH="${ROOT_DIR}:${PYTHONPATH:-}"

BUILD_LOG="${OUT_DIR}/verilator_build.log"
RUN_LOG="${OUT_DIR}/pytest_cocotb.log"

if command -v "${VERILATOR}" >/dev/null 2>&1; then
  echo "INFO: Verilator found: ${VERILATOR}" | tee -a "${BUILD_LOG}"
else
  echo "ERROR: Verilator not found: ${VERILATOR}" >&2
  exit 1
fi

if command -v "${PYTHON}" >/dev/null 2>&1; then
  :
else
  echo "ERROR: Python not found: ${PYTHON}" >&2
  exit 1
fi

if [[ -f "${VERILATOR_BUILD_MD}" ]]; then
  echo "INFO: No automatic build command is executed here; follow ${VERILATOR_BUILD_MD}" | tee -a "${BUILD_LOG}"
else
  echo "INFO: Placeholder build step. Provide repository-specific Verilator build command here." | tee -a "${BUILD_LOG}"
fi

echo "INFO: Running cocotb tests via pytest" | tee "${RUN_LOG}"
"${PYTHON}" -m pytest -q \
  --junitxml="${JUNIT_XML}" \
  "${COCOTB_TESTCASE_ARG[@]}" \
  "${COCOTB_TEST_MODULE}" \
  2>&1 | tee -a "${RUN_LOG}"

echo "INFO: Co-simulation completed successfully"
