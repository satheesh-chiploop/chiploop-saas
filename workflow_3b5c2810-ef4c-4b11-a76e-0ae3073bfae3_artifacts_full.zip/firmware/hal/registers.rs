use core::ptr::{read_volatile, write_volatile};

pub const BASE_ADDRESS: usize = 0x00000000;

pub const CONTROL_OFFSET: usize = 0x00000000;
pub const CONTROL_ENABLE_SHIFT: u32 = 0;
pub const CONTROL_ENABLE_WIDTH: u32 = 1;
pub const CONTROL_ENABLE_MASK: u64 = 0x0000000000000001;
pub const CONTROL_BYPASS_SHIFT: u32 = 1;
pub const CONTROL_BYPASS_WIDTH: u32 = 1;
pub const CONTROL_BYPASS_MASK: u64 = 0x0000000000000002;
pub const CONTROL_FALLBACK_MODE_SHIFT: u32 = 3;
pub const CONTROL_FALLBACK_MODE_WIDTH: u32 = 1;
pub const CONTROL_FALLBACK_MODE_MASK: u64 = 0x0000000000000008;
pub const CONTROL_CLEAR_FAULTS_SHIFT: u32 = 4;
pub const CONTROL_CLEAR_FAULTS_WIDTH: u32 = 1;
pub const CONTROL_CLEAR_FAULTS_MASK: u64 = 0x0000000000000010;
pub const TIMING_0_OFFSET: usize = 0x00000001;
pub const TIMING_0_REQUEST_TIMEOUT_CYCLES_SHIFT: u32 = 0;
pub const TIMING_0_REQUEST_TIMEOUT_CYCLES_WIDTH: u32 = 16;
pub const TIMING_0_REQUEST_TIMEOUT_CYCLES_MASK: u64 = 0x000000000000FFFF;
pub const TIMING_0_STALE_TIMEOUT_CYCLES_SHIFT: u32 = 16;
pub const TIMING_0_STALE_TIMEOUT_CYCLES_WIDTH: u32 = 16;
pub const TIMING_0_STALE_TIMEOUT_CYCLES_MASK: u64 = 0x00000000FFFF0000;
pub const TIMING_0_RESPONSE_AGE_LIMIT_SHIFT: u32 = 32;
pub const TIMING_0_RESPONSE_AGE_LIMIT_WIDTH: u32 = 8;
pub const TIMING_0_RESPONSE_AGE_LIMIT_MASK: u64 = 0x000000FF00000000;
pub const SEQUENCE_OFFSET: usize = 0x00000002;
pub const SEQUENCE_TX_SEQ_SHIFT: u32 = 0;
pub const SEQUENCE_TX_SEQ_WIDTH: u32 = 8;
pub const SEQUENCE_TX_SEQ_MASK: u64 = 0x00000000000000FF;
pub const SEQUENCE_RX_SEQ_EXPECTED_SHIFT: u32 = 8;
pub const SEQUENCE_RX_SEQ_EXPECTED_WIDTH: u32 = 8;
pub const SEQUENCE_RX_SEQ_EXPECTED_MASK: u64 = 0x000000000000FF00;
pub const SEQUENCE_LAST_GOOD_SEQ_SHIFT: u32 = 16;
pub const SEQUENCE_LAST_GOOD_SEQ_WIDTH: u32 = 8;
pub const SEQUENCE_LAST_GOOD_SEQ_MASK: u64 = 0x0000000000FF0000;
pub const BOUNDS_0_OFFSET: usize = 0x00000003;
pub const BOUNDS_0_CMD_MIN_SHIFT: u32 = 0;
pub const BOUNDS_0_CMD_MIN_WIDTH: u32 = 32;
pub const BOUNDS_0_CMD_MIN_MASK: u64 = 0x00000000FFFFFFFF;
pub const BOUNDS_0_CMD_MAX_SHIFT: u32 = 32;
pub const BOUNDS_0_CMD_MAX_WIDTH: u32 = 32;
pub const BOUNDS_0_CMD_MAX_MASK: u64 = 0xFFFFFFFF00000000;
pub const BOUNDS_1_OFFSET: usize = 0x00000004;
pub const BOUNDS_1_SLEW_LIMIT_SHIFT: u32 = 0;
pub const BOUNDS_1_SLEW_LIMIT_WIDTH: u32 = 16;
pub const BOUNDS_1_SLEW_LIMIT_MASK: u64 = 0x000000000000FFFF;
pub const BOUNDS_1_STREAM_VELOCITY_MPS_REF_SHIFT: u32 = 16;
pub const BOUNDS_1_STREAM_VELOCITY_MPS_REF_WIDTH: u32 = 16;
pub const BOUNDS_1_STREAM_VELOCITY_MPS_REF_MASK: u64 = 0x00000000FFFF0000;
pub const BOUNDS_1_OPERATING_WINDOW_MIN_SHIFT: u32 = 32;
pub const BOUNDS_1_OPERATING_WINDOW_MIN_WIDTH: u32 = 16;
pub const BOUNDS_1_OPERATING_WINDOW_MIN_MASK: u64 = 0x0000FFFF00000000;
pub const BOUNDS_1_OPERATING_WINDOW_MAX_SHIFT: u32 = 48;
pub const BOUNDS_1_OPERATING_WINDOW_MAX_WIDTH: u32 = 16;
pub const BOUNDS_1_OPERATING_WINDOW_MAX_MASK: u64 = 0xFFFF000000000000;
pub const STATUS_OFFSET: usize = 0x00000005;
pub const STATUS_BUSY_SHIFT: u32 = 0;
pub const STATUS_BUSY_WIDTH: u32 = 1;
pub const STATUS_BUSY_MASK: u64 = 0x0000000000000001;
pub const STATUS_DATA_VALID_SHIFT: u32 = 1;
pub const STATUS_DATA_VALID_WIDTH: u32 = 1;
pub const STATUS_DATA_VALID_MASK: u64 = 0x0000000000000002;
pub const STATUS_STALE_DETECTED_SHIFT: u32 = 2;
pub const STATUS_STALE_DETECTED_WIDTH: u32 = 1;
pub const STATUS_STALE_DETECTED_MASK: u64 = 0x0000000000000004;
pub const STATUS_TIMEOUT_DETECTED_SHIFT: u32 = 3;
pub const STATUS_TIMEOUT_DETECTED_WIDTH: u32 = 1;
pub const STATUS_TIMEOUT_DETECTED_MASK: u64 = 0x0000000000000008;
pub const STATUS_RESPONSE_INVALID_SHIFT: u32 = 4;
pub const STATUS_RESPONSE_INVALID_WIDTH: u32 = 1;
pub const STATUS_RESPONSE_INVALID_MASK: u64 = 0x0000000000000010;
pub const STATUS_FALLBACK_ACTIVE_SHIFT: u32 = 5;
pub const STATUS_FALLBACK_ACTIVE_WIDTH: u32 = 1;
pub const STATUS_FALLBACK_ACTIVE_MASK: u64 = 0x0000000000000020;
pub const STATUS_LAST_FAULT_CODE_SHIFT: u32 = 8;
pub const STATUS_LAST_FAULT_CODE_WIDTH: u32 = 8;
pub const STATUS_LAST_FAULT_CODE_MASK: u64 = 0x000000000000FF00;
pub const REQUEST_DESCRIPTOR_OFFSET: usize = 0x00000006;
pub const REQUEST_DESCRIPTOR_MODEL_REQUEST_TYPE_SHIFT: u32 = 0;
pub const REQUEST_DESCRIPTOR_MODEL_REQUEST_TYPE_WIDTH: u32 = 4;
pub const REQUEST_DESCRIPTOR_MODEL_REQUEST_TYPE_MASK: u64 = 0x000000000000000F;
pub const REQUEST_DESCRIPTOR_MODEL_SELECTOR_SHIFT: u32 = 4;
pub const REQUEST_DESCRIPTOR_MODEL_SELECTOR_WIDTH: u32 = 4;
pub const REQUEST_DESCRIPTOR_MODEL_SELECTOR_MASK: u64 = 0x00000000000000F0;
pub const REQUEST_DESCRIPTOR_FLOW_CONDITION_SUMMARY_SHIFT: u32 = 8;
pub const REQUEST_DESCRIPTOR_FLOW_CONDITION_SUMMARY_WIDTH: u32 = 16;
pub const REQUEST_DESCRIPTOR_FLOW_CONDITION_SUMMARY_MASK: u64 = 0x0000000000FFFF00;
pub const REQUEST_DESCRIPTOR_GEOMETRY_HANDLE_SHIFT: u32 = 24;
pub const REQUEST_DESCRIPTOR_GEOMETRY_HANDLE_WIDTH: u32 = 16;
pub const REQUEST_DESCRIPTOR_GEOMETRY_HANDLE_MASK: u64 = 0x000000FFFF000000;
pub const REQUEST_DESCRIPTOR_RESERVED_SHIFT: u32 = 40;
pub const REQUEST_DESCRIPTOR_RESERVED_WIDTH: u32 = 24;
pub const REQUEST_DESCRIPTOR_RESERVED_MASK: u64 = 0xFFFFFF0000000000;
pub const RESPONSE_SUMMARY_OFFSET: usize = 0x00000007;
pub const RESPONSE_SUMMARY_RESPONSE_STATUS_SHIFT: u32 = 0;
pub const RESPONSE_SUMMARY_RESPONSE_STATUS_WIDTH: u32 = 4;
pub const RESPONSE_SUMMARY_RESPONSE_STATUS_MASK: u64 = 0x000000000000000F;
pub const RESPONSE_SUMMARY_RESPONSE_FRESHNESS_SHIFT: u32 = 4;
pub const RESPONSE_SUMMARY_RESPONSE_FRESHNESS_WIDTH: u32 = 8;
pub const RESPONSE_SUMMARY_RESPONSE_FRESHNESS_MASK: u64 = 0x0000000000000FF0;
pub const RESPONSE_SUMMARY_SURROGATE_DRAG_SUMMARY_SHIFT: u32 = 12;
pub const RESPONSE_SUMMARY_SURROGATE_DRAG_SUMMARY_WIDTH: u32 = 16;
pub const RESPONSE_SUMMARY_SURROGATE_DRAG_SUMMARY_MASK: u64 = 0x000000000FFFF000;
pub const RESPONSE_SUMMARY_SURROGATE_LIFT_SUMMARY_SHIFT: u32 = 28;
pub const RESPONSE_SUMMARY_SURROGATE_LIFT_SUMMARY_WIDTH: u32 = 16;
pub const RESPONSE_SUMMARY_SURROGATE_LIFT_SUMMARY_MASK: u64 = 0x00000FFFF0000000;
pub const RESPONSE_SUMMARY_SURROGATE_PRESSURE_SUMMARY_SHIFT: u32 = 44;
pub const RESPONSE_SUMMARY_SURROGATE_PRESSURE_SUMMARY_WIDTH: u32 = 16;
pub const RESPONSE_SUMMARY_SURROGATE_PRESSURE_SUMMARY_MASK: u64 = 0x0FFFF00000000000;

#[inline]
fn reg_ptr(offset: usize) -> *mut u64 {
    (BASE_ADDRESS + offset) as *mut u64
}

#[inline]
fn read_reg(offset: usize) -> u64 {
    unsafe { read_volatile(reg_ptr(offset) as *const u64) }
}

#[inline]
fn write_reg(offset: usize, value: u64) {
    unsafe { write_volatile(reg_ptr(offset), value) }
}

#[inline]
pub fn read_control() -> u64 {
    read_reg(CONTROL_OFFSET)
}

#[inline]
pub fn write_control(value: u64) {
    write_reg(CONTROL_OFFSET, value)
}

#[inline]
pub fn get_control_enable() -> u64 {
    (read_control() & CONTROL_ENABLE_MASK) >> CONTROL_ENABLE_SHIFT
}

#[inline]
pub fn set_control_enable(value: u64) {
    let current = read_control();
    let next = (current & !CONTROL_ENABLE_MASK) | ((value << CONTROL_ENABLE_SHIFT) & CONTROL_ENABLE_MASK);
    write_control(next);
}

#[inline]
pub fn get_control_bypass() -> u64 {
    (read_control() & CONTROL_BYPASS_MASK) >> CONTROL_BYPASS_SHIFT
}

#[inline]
pub fn set_control_bypass(value: u64) {
    let current = read_control();
    let next = (current & !CONTROL_BYPASS_MASK) | ((value << CONTROL_BYPASS_SHIFT) & CONTROL_BYPASS_MASK);
    write_control(next);
}

#[inline]
pub fn get_control_fallback_mode() -> u64 {
    (read_control() & CONTROL_FALLBACK_MODE_MASK) >> CONTROL_FALLBACK_MODE_SHIFT
}

#[inline]
pub fn set_control_fallback_mode(value: u64) {
    let current = read_control();
    let next = (current & !CONTROL_FALLBACK_MODE_MASK) | ((value << CONTROL_FALLBACK_MODE_SHIFT) & CONTROL_FALLBACK_MODE_MASK);
    write_control(next);
}

#[inline]
pub fn get_control_clear_faults() -> u64 {
    (read_control() & CONTROL_CLEAR_FAULTS_MASK) >> CONTROL_CLEAR_FAULTS_SHIFT
}

#[inline]
pub fn set_control_clear_faults(value: u64) {
    let current = read_control();
    let next = (current & !CONTROL_CLEAR_FAULTS_MASK) | ((value << CONTROL_CLEAR_FAULTS_SHIFT) & CONTROL_CLEAR_FAULTS_MASK);
    write_control(next);
}

#[inline]
pub fn read_timing_0() -> u64 {
    read_reg(TIMING_0_OFFSET)
}

#[inline]
pub fn write_timing_0(value: u64) {
    write_reg(TIMING_0_OFFSET, value)
}

#[inline]
pub fn get_timing_0_request_timeout_cycles() -> u64 {
    (read_timing_0() & TIMING_0_REQUEST_TIMEOUT_CYCLES_MASK) >> TIMING_0_REQUEST_TIMEOUT_CYCLES_SHIFT
}

#[inline]
pub fn set_timing_0_request_timeout_cycles(value: u64) {
    let current = read_timing_0();
    let next = (current & !TIMING_0_REQUEST_TIMEOUT_CYCLES_MASK) | ((value << TIMING_0_REQUEST_TIMEOUT_CYCLES_SHIFT) & TIMING_0_REQUEST_TIMEOUT_CYCLES_MASK);
    write_timing_0(next);
}

#[inline]
pub fn get_timing_0_stale_timeout_cycles() -> u64 {
    (read_timing_0() & TIMING_0_STALE_TIMEOUT_CYCLES_MASK) >> TIMING_0_STALE_TIMEOUT_CYCLES_SHIFT
}

#[inline]
pub fn set_timing_0_stale_timeout_cycles(value: u64) {
    let current = read_timing_0();
    let next = (current & !TIMING_0_STALE_TIMEOUT_CYCLES_MASK) | ((value << TIMING_0_STALE_TIMEOUT_CYCLES_SHIFT) & TIMING_0_STALE_TIMEOUT_CYCLES_MASK);
    write_timing_0(next);
}

#[inline]
pub fn get_timing_0_response_age_limit() -> u64 {
    (read_timing_0() & TIMING_0_RESPONSE_AGE_LIMIT_MASK) >> TIMING_0_RESPONSE_AGE_LIMIT_SHIFT
}

#[inline]
pub fn set_timing_0_response_age_limit(value: u64) {
    let current = read_timing_0();
    let next = (current & !TIMING_0_RESPONSE_AGE_LIMIT_MASK) | ((value << TIMING_0_RESPONSE_AGE_LIMIT_SHIFT) & TIMING_0_RESPONSE_AGE_LIMIT_MASK);
    write_timing_0(next);
}

#[inline]
pub fn read_sequence() -> u64 {
    read_reg(SEQUENCE_OFFSET)
}

#[inline]
pub fn write_sequence(value: u64) {
    write_reg(SEQUENCE_OFFSET, value)
}

#[inline]
pub fn get_sequence_tx_seq() -> u64 {
    (read_sequence() & SEQUENCE_TX_SEQ_MASK) >> SEQUENCE_TX_SEQ_SHIFT
}

#[inline]
pub fn set_sequence_tx_seq(value: u64) {
    let current = read_sequence();
    let next = (current & !SEQUENCE_TX_SEQ_MASK) | ((value << SEQUENCE_TX_SEQ_SHIFT) & SEQUENCE_TX_SEQ_MASK);
    write_sequence(next);
}

#[inline]
pub fn get_sequence_rx_seq_expected() -> u64 {
    (read_sequence() & SEQUENCE_RX_SEQ_EXPECTED_MASK) >> SEQUENCE_RX_SEQ_EXPECTED_SHIFT
}

#[inline]
pub fn get_sequence_last_good_seq() -> u64 {
    (read_sequence() & SEQUENCE_LAST_GOOD_SEQ_MASK) >> SEQUENCE_LAST_GOOD_SEQ_SHIFT
}

#[inline]
pub fn read_bounds_0() -> u64 {
    read_reg(BOUNDS_0_OFFSET)
}

#[inline]
pub fn write_bounds_0(value: u64) {
    write_reg(BOUNDS_0_OFFSET, value)
}

#[inline]
pub fn get_bounds_0_cmd_min() -> u64 {
    (read_bounds_0() & BOUNDS_0_CMD_MIN_MASK) >> BOUNDS_0_CMD_MIN_SHIFT
}

#[inline]
pub fn set_bounds_0_cmd_min(value: u64) {
    let current = read_bounds_0();
    let next = (current & !BOUNDS_0_CMD_MIN_MASK) | ((value << BOUNDS_0_CMD_MIN_SHIFT) & BOUNDS_0_CMD_MIN_MASK);
    write_bounds_0(next);
}

#[inline]
pub fn get_bounds_0_cmd_max() -> u64 {
    (read_bounds_0() & BOUNDS_0_CMD_MAX_MASK) >> BOUNDS_0_CMD_MAX_SHIFT
}

#[inline]
pub fn set_bounds_0_cmd_max(value: u64) {
    let current = read_bounds_0();
    let next = (current & !BOUNDS_0_CMD_MAX_MASK) | ((value << BOUNDS_0_CMD_MAX_SHIFT) & BOUNDS_0_CMD_MAX_MASK);
    write_bounds_0(next);
}

#[inline]
pub fn read_bounds_1() -> u64 {
    read_reg(BOUNDS_1_OFFSET)
}

#[inline]
pub fn write_bounds_1(value: u64) {
    write_reg(BOUNDS_1_OFFSET, value)
}

#[inline]
pub fn get_bounds_1_slew_limit() -> u64 {
    (read_bounds_1() & BOUNDS_1_SLEW_LIMIT_MASK) >> BOUNDS_1_SLEW_LIMIT_SHIFT
}

#[inline]
pub fn set_bounds_1_slew_limit(value: u64) {
    let current = read_bounds_1();
    let next = (current & !BOUNDS_1_SLEW_LIMIT_MASK) | ((value << BOUNDS_1_SLEW_LIMIT_SHIFT) & BOUNDS_1_SLEW_LIMIT_MASK);
    write_bounds_1(next);
}

#[inline]
pub fn get_bounds_1_stream_velocity_mps_ref() -> u64 {
    (read_bounds_1() & BOUNDS_1_STREAM_VELOCITY_MPS_REF_MASK) >> BOUNDS_1_STREAM_VELOCITY_MPS_REF_SHIFT
}

#[inline]
pub fn set_bounds_1_stream_velocity_mps_ref(value: u64) {
    let current = read_bounds_1();
    let next = (current & !BOUNDS_1_STREAM_VELOCITY_MPS_REF_MASK) | ((value << BOUNDS_1_STREAM_VELOCITY_MPS_REF_SHIFT) & BOUNDS_1_STREAM_VELOCITY_MPS_REF_MASK);
    write_bounds_1(next);
}

#[inline]
pub fn get_bounds_1_operating_window_min() -> u64 {
    (read_bounds_1() & BOUNDS_1_OPERATING_WINDOW_MIN_MASK) >> BOUNDS_1_OPERATING_WINDOW_MIN_SHIFT
}

#[inline]
pub fn set_bounds_1_operating_window_min(value: u64) {
    let current = read_bounds_1();
    let next = (current & !BOUNDS_1_OPERATING_WINDOW_MIN_MASK) | ((value << BOUNDS_1_OPERATING_WINDOW_MIN_SHIFT) & BOUNDS_1_OPERATING_WINDOW_MIN_MASK);
    write_bounds_1(next);
}

#[inline]
pub fn get_bounds_1_operating_window_max() -> u64 {
    (read_bounds_1() & BOUNDS_1_OPERATING_WINDOW_MAX_MASK) >> BOUNDS_1_OPERATING_WINDOW_MAX_SHIFT
}

#[inline]
pub fn set_bounds_1_operating_window_max(value: u64) {
    let current = read_bounds_1();
    let next = (current & !BOUNDS_1_OPERATING_WINDOW_MAX_MASK) | ((value << BOUNDS_1_OPERATING_WINDOW_MAX_SHIFT) & BOUNDS_1_OPERATING_WINDOW_MAX_MASK);
    write_bounds_1(next);
}

#[inline]
pub fn read_status() -> u64 {
    read_reg(STATUS_OFFSET)
}

#[inline]
pub fn get_status_busy() -> u64 {
    (read_status() & STATUS_BUSY_MASK) >> STATUS_BUSY_SHIFT
}

#[inline]
pub fn get_status_data_valid() -> u64 {
    (read_status() & STATUS_DATA_VALID_MASK) >> STATUS_DATA_VALID_SHIFT
}

#[inline]
pub fn get_status_stale_detected() -> u64 {
    (read_status() & STATUS_STALE_DETECTED_MASK) >> STATUS_STALE_DETECTED_SHIFT
}

#[inline]
pub fn get_status_timeout_detected() -> u64 {
    (read_status() & STATUS_TIMEOUT_DETECTED_MASK) >> STATUS_TIMEOUT_DETECTED_SHIFT
}

#[inline]
pub fn get_status_response_invalid() -> u64 {
    (read_status() & STATUS_RESPONSE_INVALID_MASK) >> STATUS_RESPONSE_INVALID_SHIFT
}

#[inline]
pub fn get_status_fallback_active() -> u64 {
    (read_status() & STATUS_FALLBACK_ACTIVE_MASK) >> STATUS_FALLBACK_ACTIVE_SHIFT
}

#[inline]
pub fn get_status_last_fault_code() -> u64 {
    (read_status() & STATUS_LAST_FAULT_CODE_MASK) >> STATUS_LAST_FAULT_CODE_SHIFT
}

#[inline]
pub fn read_request_descriptor() -> u64 {
    read_reg(REQUEST_DESCRIPTOR_OFFSET)
}

#[inline]
pub fn write_request_descriptor(value: u64) {
    write_reg(REQUEST_DESCRIPTOR_OFFSET, value)
}

#[inline]
pub fn get_request_descriptor_model_request_type() -> u64 {
    (read_request_descriptor() & REQUEST_DESCRIPTOR_MODEL_REQUEST_TYPE_MASK) >> REQUEST_DESCRIPTOR_MODEL_REQUEST_TYPE_SHIFT
}

#[inline]
pub fn set_request_descriptor_model_request_type(value: u64) {
    let current = read_request_descriptor();
    let next = (current & !REQUEST_DESCRIPTOR_MODEL_REQUEST_TYPE_MASK) | ((value << REQUEST_DESCRIPTOR_MODEL_REQUEST_TYPE_SHIFT) & REQUEST_DESCRIPTOR_MODEL_REQUEST_TYPE_MASK);
    write_request_descriptor(next);
}

#[inline]
pub fn get_request_descriptor_model_selector() -> u64 {
    (read_request_descriptor() & REQUEST_DESCRIPTOR_MODEL_SELECTOR_MASK) >> REQUEST_DESCRIPTOR_MODEL_SELECTOR_SHIFT
}

#[inline]
pub fn set_request_descriptor_model_selector(value: u64) {
    let current = read_request_descriptor();
    let next = (current & !REQUEST_DESCRIPTOR_MODEL_SELECTOR_MASK) | ((value << REQUEST_DESCRIPTOR_MODEL_SELECTOR_SHIFT) & REQUEST_DESCRIPTOR_MODEL_SELECTOR_MASK);
    write_request_descriptor(next);
}

#[inline]
pub fn get_request_descriptor_flow_condition_summary() -> u64 {
    (read_request_descriptor() & REQUEST_DESCRIPTOR_FLOW_CONDITION_SUMMARY_MASK) >> REQUEST_DESCRIPTOR_FLOW_CONDITION_SUMMARY_SHIFT
}

#[inline]
pub fn set_request_descriptor_flow_condition_summary(value: u64) {
    let current = read_request_descriptor();
    let next = (current & !REQUEST_DESCRIPTOR_FLOW_CONDITION_SUMMARY_MASK) | ((value << REQUEST_DESCRIPTOR_FLOW_CONDITION_SUMMARY_SHIFT) & REQUEST_DESCRIPTOR_FLOW_CONDITION_SUMMARY_MASK);
    write_request_descriptor(next);
}

#[inline]
pub fn get_request_descriptor_geometry_handle() -> u64 {
    (read_request_descriptor() & REQUEST_DESCRIPTOR_GEOMETRY_HANDLE_MASK) >> REQUEST_DESCRIPTOR_GEOMETRY_HANDLE_SHIFT
}

#[inline]
pub fn set_request_descriptor_geometry_handle(value: u64) {
    let current = read_request_descriptor();
    let next = (current & !REQUEST_DESCRIPTOR_GEOMETRY_HANDLE_MASK) | ((value << REQUEST_DESCRIPTOR_GEOMETRY_HANDLE_SHIFT) & REQUEST_DESCRIPTOR_GEOMETRY_HANDLE_MASK);
    write_request_descriptor(next);
}

#[inline]
pub fn get_request_descriptor_reserved() -> u64 {
    (read_request_descriptor() & REQUEST_DESCRIPTOR_RESERVED_MASK) >> REQUEST_DESCRIPTOR_RESERVED_SHIFT
}

#[inline]
pub fn read_response_summary() -> u64 {
    read_reg(RESPONSE_SUMMARY_OFFSET)
}

#[inline]
pub fn get_response_summary_response_status() -> u64 {
    (read_response_summary() & RESPONSE_SUMMARY_RESPONSE_STATUS_MASK) >> RESPONSE_SUMMARY_RESPONSE_STATUS_SHIFT
}

#[inline]
pub fn get_response_summary_response_freshness() -> u64 {
    (read_response_summary() & RESPONSE_SUMMARY_RESPONSE_FRESHNESS_MASK) >> RESPONSE_SUMMARY_RESPONSE_FRESHNESS_SHIFT
}

#[inline]
pub fn get_response_summary_surrogate_drag_summary() -> u64 {
    (read_response_summary() & RESPONSE_SUMMARY_SURROGATE_DRAG_SUMMARY_MASK) >> RESPONSE_SUMMARY_SURROGATE_DRAG_SUMMARY_SHIFT
}

#[inline]
pub fn get_response_summary_surrogate_lift_summary() -> u64 {
    (read_response_summary() & RESPONSE_SUMMARY_SURROGATE_LIFT_SUMMARY_MASK) >> RESPONSE_SUMMARY_SURROGATE_LIFT_SUMMARY_SHIFT
}

#[inline]
pub fn get_response_summary_surrogate_pressure_summary() -> u64 {
    (read_response_summary() & RESPONSE_SUMMARY_SURROGATE_PRESSURE_SUMMARY_MASK) >> RESPONSE_SUMMARY_SURROGATE_PRESSURE_SUMMARY_SHIFT
}

