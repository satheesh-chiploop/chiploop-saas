// ASSUMPTION: Interrupt decode is software-mediated using firmware-visible status/interrupt bits.
// ASSUMPTION: No MCU-style external vector table is generated unless the hardware contract explicitly requires one.

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum InterruptSource {
    ClearFaults,
    LastFaultCode,
}

#[inline]
pub fn interrupt_count() -> usize {
    2
}

pub const CLEAR_FAULTS_BIT: u32 = 0;
pub const LAST_FAULT_CODE_BIT: u32 = 1;

#[inline]
pub fn handle_clear_faults() {
    // Default ISR scaffold: replace with concrete firmware behavior as needed.
}

#[inline]
pub fn handle_last_fault_code() {
    // Default ISR scaffold: replace with concrete firmware behavior as needed.
}

#[inline]
pub fn dispatch_interrupt(bit_index: u32) -> bool {
    match bit_index {
        CLEAR_FAULTS_BIT => { handle_clear_faults(); true }
        LAST_FAULT_CODE_BIT => { handle_last_fault_code(); true }
        _ => false,
    }
}
