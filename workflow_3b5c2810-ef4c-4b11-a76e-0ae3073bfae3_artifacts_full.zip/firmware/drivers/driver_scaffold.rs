use crate::hal::registers::*;

pub struct DigitalSubsystemDriver;

impl DigitalSubsystemDriver {
    #[inline]
    pub const fn new() -> Self {
        Self
    }

    #[inline]
    pub fn read_control(&self) -> u32 {
        read_control()
    }

    #[inline]
    pub fn write_control(&self, value: u32) {
        write_control(value)
    }

    #[inline]
    pub fn get_control_enable(&self) -> bool {
        get_control_enable() != 0
    }

    #[inline]
    pub fn set_control_enable(&self, value: bool) {
        set_control_enable(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_control_bypass(&self) -> bool {
        get_control_bypass() != 0
    }

    #[inline]
    pub fn set_control_bypass(&self, value: bool) {
        set_control_bypass(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_control_fallback_mode(&self) -> bool {
        get_control_fallback_mode() != 0
    }

    #[inline]
    pub fn set_control_fallback_mode(&self, value: bool) {
        set_control_fallback_mode(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn get_control_clear_faults(&self) -> bool {
        get_control_clear_faults() != 0
    }

    #[inline]
    pub fn set_control_clear_faults(&self, value: bool) {
        set_control_clear_faults(if value { 1 } else { 0 })
    }

    #[inline]
    pub fn read_timing_0(&self) -> u32 {
        read_timing_0()
    }

    #[inline]
    pub fn write_timing_0(&self, value: u32) {
        write_timing_0(value)
    }

    #[inline]
    pub fn get_timing_0_request_timeout_cycles(&self) -> u16 {
        get_timing_0_request_timeout_cycles() as u16
    }

    #[inline]
    pub fn set_timing_0_request_timeout_cycles(&self, value: u16) {
        set_timing_0_request_timeout_cycles(value as u32)
    }

    #[inline]
    pub fn get_timing_0_stale_timeout_cycles(&self) -> u16 {
        get_timing_0_stale_timeout_cycles() as u16
    }

    #[inline]
    pub fn set_timing_0_stale_timeout_cycles(&self, value: u16) {
        set_timing_0_stale_timeout_cycles(value as u32)
    }

    #[inline]
    pub fn get_timing_0_response_age_limit(&self) -> u8 {
        get_timing_0_response_age_limit() as u8
    }

    #[inline]
    pub fn set_timing_0_response_age_limit(&self, value: u8) {
        set_timing_0_response_age_limit(value as u32)
    }

    #[inline]
    pub fn read_sequence(&self) -> u32 {
        read_sequence()
    }

    #[inline]
    pub fn write_sequence(&self, value: u32) {
        write_sequence(value)
    }

    #[inline]
    pub fn get_sequence_tx_seq(&self) -> u8 {
        get_sequence_tx_seq() as u8
    }

    #[inline]
    pub fn set_sequence_tx_seq(&self, value: u8) {
        set_sequence_tx_seq(value as u32)
    }

    #[inline]
    pub fn get_sequence_rx_seq_expected(&self) -> u8 {
        get_sequence_rx_seq_expected() as u8
    }

    #[inline]
    pub fn get_sequence_last_good_seq(&self) -> u8 {
        get_sequence_last_good_seq() as u8
    }

    #[inline]
    pub fn read_bounds_0(&self) -> u32 {
        read_bounds_0()
    }

    #[inline]
    pub fn write_bounds_0(&self, value: u32) {
        write_bounds_0(value)
    }

    #[inline]
    pub fn get_bounds_0_cmd_min(&self) -> u32 {
        get_bounds_0_cmd_min() as u32
    }

    #[inline]
    pub fn set_bounds_0_cmd_min(&self, value: u32) {
        set_bounds_0_cmd_min(value as u32)
    }

    #[inline]
    pub fn get_bounds_0_cmd_max(&self) -> u32 {
        get_bounds_0_cmd_max() as u32
    }

    #[inline]
    pub fn set_bounds_0_cmd_max(&self, value: u32) {
        set_bounds_0_cmd_max(value as u32)
    }

    #[inline]
    pub fn read_bounds_1(&self) -> u32 {
        read_bounds_1()
    }

    #[inline]
    pub fn write_bounds_1(&self, value: u32) {
        write_bounds_1(value)
    }

    #[inline]
    pub fn get_bounds_1_slew_limit(&self) -> u16 {
        get_bounds_1_slew_limit() as u16
    }

    #[inline]
    pub fn set_bounds_1_slew_limit(&self, value: u16) {
        set_bounds_1_slew_limit(value as u32)
    }

    #[inline]
    pub fn get_bounds_1_stream_velocity_mps_ref(&self) -> u16 {
        get_bounds_1_stream_velocity_mps_ref() as u16
    }

    #[inline]
    pub fn set_bounds_1_stream_velocity_mps_ref(&self, value: u16) {
        set_bounds_1_stream_velocity_mps_ref(value as u32)
    }

    #[inline]
    pub fn get_bounds_1_operating_window_min(&self) -> u16 {
        get_bounds_1_operating_window_min() as u16
    }

    #[inline]
    pub fn set_bounds_1_operating_window_min(&self, value: u16) {
        set_bounds_1_operating_window_min(value as u32)
    }

    #[inline]
    pub fn get_bounds_1_operating_window_max(&self) -> u16 {
        get_bounds_1_operating_window_max() as u16
    }

    #[inline]
    pub fn set_bounds_1_operating_window_max(&self, value: u16) {
        set_bounds_1_operating_window_max(value as u32)
    }

    #[inline]
    pub fn read_status(&self) -> u32 {
        read_status()
    }

    #[inline]
    pub fn get_status_busy(&self) -> bool {
        get_status_busy() != 0
    }

    #[inline]
    pub fn get_status_data_valid(&self) -> bool {
        get_status_data_valid() != 0
    }

    #[inline]
    pub fn get_status_stale_detected(&self) -> bool {
        get_status_stale_detected() != 0
    }

    #[inline]
    pub fn get_status_timeout_detected(&self) -> bool {
        get_status_timeout_detected() != 0
    }

    #[inline]
    pub fn get_status_response_invalid(&self) -> bool {
        get_status_response_invalid() != 0
    }

    #[inline]
    pub fn get_status_fallback_active(&self) -> bool {
        get_status_fallback_active() != 0
    }

    #[inline]
    pub fn get_status_last_fault_code(&self) -> u8 {
        get_status_last_fault_code() as u8
    }

    #[inline]
    pub fn read_request_descriptor(&self) -> u32 {
        read_request_descriptor()
    }

    #[inline]
    pub fn write_request_descriptor(&self, value: u32) {
        write_request_descriptor(value)
    }

    #[inline]
    pub fn get_request_descriptor_model_request_type(&self) -> u8 {
        get_request_descriptor_model_request_type() as u8
    }

    #[inline]
    pub fn set_request_descriptor_model_request_type(&self, value: u8) {
        set_request_descriptor_model_request_type(value as u32)
    }

    #[inline]
    pub fn get_request_descriptor_model_selector(&self) -> u8 {
        get_request_descriptor_model_selector() as u8
    }

    #[inline]
    pub fn set_request_descriptor_model_selector(&self, value: u8) {
        set_request_descriptor_model_selector(value as u32)
    }

    #[inline]
    pub fn get_request_descriptor_flow_condition_summary(&self) -> u16 {
        get_request_descriptor_flow_condition_summary() as u16
    }

    #[inline]
    pub fn set_request_descriptor_flow_condition_summary(&self, value: u16) {
        set_request_descriptor_flow_condition_summary(value as u32)
    }

    #[inline]
    pub fn get_request_descriptor_geometry_handle(&self) -> u16 {
        get_request_descriptor_geometry_handle() as u16
    }

    #[inline]
    pub fn set_request_descriptor_geometry_handle(&self, value: u16) {
        set_request_descriptor_geometry_handle(value as u32)
    }

    #[inline]
    pub fn get_request_descriptor_reserved(&self) -> u32 {
        get_request_descriptor_reserved() as u32
    }

    #[inline]
    pub fn read_response_summary(&self) -> u32 {
        read_response_summary()
    }

    #[inline]
    pub fn get_response_summary_response_status(&self) -> u8 {
        get_response_summary_response_status() as u8
    }

    #[inline]
    pub fn get_response_summary_response_freshness(&self) -> u8 {
        get_response_summary_response_freshness() as u8
    }

    #[inline]
    pub fn get_response_summary_surrogate_drag_summary(&self) -> u16 {
        get_response_summary_surrogate_drag_summary() as u16
    }

    #[inline]
    pub fn get_response_summary_surrogate_lift_summary(&self) -> u16 {
        get_response_summary_surrogate_lift_summary() as u16
    }

    #[inline]
    pub fn get_response_summary_surrogate_pressure_summary(&self) -> u16 {
        get_response_summary_surrogate_pressure_summary() as u16
    }

}
