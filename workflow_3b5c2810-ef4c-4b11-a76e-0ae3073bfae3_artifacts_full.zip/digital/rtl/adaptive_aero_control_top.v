module adaptive_aero_control_top (
    clk,
    rst_n,
    csr_addr,
    csr_wdata,
    csr_rdata,
    csr_we,
    csr_re,
    csr_valid,
    csr_ready,
    req_data,
    req_valid,
    req_ready,
    rsp_data,
    rsp_valid,
    rsp_ready,
    actuator_cmd_data,
    actuator_cmd_valid,
    actuator_cmd_ready,
    fault_irq,
    cfg_enable,
    cfg_bypass,
    cfg_fallback_mode,
    cfg_clear_faults,
    request_timeout_cycles,
    stale_timeout_cycles,
    response_age_limit,
    tx_seq,
    rx_seq_expected,
    last_good_seq,
    cmd_min,
    cmd_max,
    slew_limit,
    stream_velocity_mps_ref,
    operating_window_min,
    operating_window_max,
    model_request_type,
    model_selector,
    flow_condition_summary,
    geometry_handle,
    response_status,
    response_freshness,
    surrogate_drag_summary,
    surrogate_lift_summary,
    surrogate_pressure_summary,
    last_fault_code
);
input clk;
input rst_n;
input [7:0] csr_addr;
input [63:0] csr_wdata;
output [63:0] csr_rdata;
input csr_we;
input csr_re;
input csr_valid;
output csr_ready;
output [127:0] req_data;
output req_valid;
input req_ready;
input [127:0] rsp_data;
input rsp_valid;
output rsp_ready;
output [31:0] actuator_cmd_data;
output actuator_cmd_valid;
input actuator_cmd_ready;
output fault_irq;
output cfg_enable;
output cfg_bypass;
output cfg_fallback_mode;
output cfg_clear_faults;
output request_timeout_cycles;
output stale_timeout_cycles;
output response_age_limit;
output tx_seq;
output rx_seq_expected;
output last_good_seq;
output cmd_min;
output cmd_max;
output slew_limit;
output stream_velocity_mps_ref;
output operating_window_min;
output operating_window_max;
output model_request_type;
output model_selector;
output flow_condition_summary;
output geometry_handle;
output response_status;
output response_freshness;
output surrogate_drag_summary;
output surrogate_lift_summary;
output surrogate_pressure_summary;
output last_fault_code;

wire [127:0] req_data_w;
wire req_valid_w;
wire rsp_ready_w;
wire [31:0] actuator_cmd_data_w;
wire actuator_cmd_valid_w;
wire fault_irq_w;
wire csr_ready_w;
wire [63:0] csr_rdata_w;

reg enable_r;
reg bypass_r;
reg cfg_fallback_mode_r;
reg clear_faults_pulse_r;
reg request_timeout_cycles_r;
reg stale_timeout_cycles_r;
reg response_age_limit_r;
reg tx_seq_r;
reg rx_seq_expected_r;
reg last_good_seq_r;
reg cmd_min_r;
reg cmd_max_r;
reg slew_limit_r;
reg stream_velocity_mps_ref_r;
reg operating_window_min_r;
reg operating_window_max_r;
reg model_request_type_r;
reg model_selector_r;
reg flow_condition_summary_r;
reg geometry_handle_r;
reg response_status_r;
reg response_freshness_r;
reg surrogate_drag_summary_r;
reg surrogate_lift_summary_r;
reg surrogate_pressure_summary_r;
reg last_fault_code_r;
reg busy_r;
reg data_valid_r;
reg stale_detected_r;
reg timeout_detected_r;
reg response_invalid_r;
reg fallback_active_r;
reg request_age_cnt_r;
reg response_age_cnt_r;
reg outstanding_r;
reg last_cmd_r;
reg fallback_cmd_r;
reg computed_cmd_r;

reg [63:0] csr_rdata_r;
assign csr_ready = csr_ready_w;
assign csr_rdata = csr_rdata_r;
assign req_data = req_data_w;
assign req_valid = req_valid_w;
assign rsp_ready = rsp_ready_w;
assign actuator_cmd_data = actuator_cmd_data_w;
assign actuator_cmd_valid = actuator_cmd_valid_w;
assign fault_irq = fault_irq_w;
assign cfg_enable = enable_r;
assign cfg_bypass = bypass_r;
assign cfg_fallback_mode = cfg_fallback_mode_r;
assign cfg_clear_faults = clear_faults_pulse_r;
assign request_timeout_cycles = request_timeout_cycles_r;
assign stale_timeout_cycles = stale_timeout_cycles_r;
assign response_age_limit = response_age_limit_r;
assign tx_seq = tx_seq_r;
assign rx_seq_expected = rx_seq_expected_r;
assign last_good_seq = last_good_seq_r;
assign cmd_min = cmd_min_r;
assign cmd_max = cmd_max_r;
assign slew_limit = slew_limit_r;
assign stream_velocity_mps_ref = stream_velocity_mps_ref_r;
assign operating_window_min = operating_window_min_r;
assign operating_window_max = operating_window_max_r;
assign model_request_type = model_request_type_r;
assign model_selector = model_selector_r;
assign flow_condition_summary = flow_condition_summary_r;
assign geometry_handle = geometry_handle_r;
assign response_status = response_status_r;
assign response_freshness = response_freshness_r;
assign surrogate_drag_summary = surrogate_drag_summary_r;
assign surrogate_lift_summary = surrogate_lift_summary_r;
assign surrogate_pressure_summary = surrogate_pressure_summary_r;
assign last_fault_code = last_fault_code_r;

assign req_data_w = {126'd0, tx_seq_r, rx_seq_expected_r};
assign req_valid_w = outstanding_r & enable_r & ~bypass_r & ~fallback_active_r;
assign rsp_ready_w = outstanding_r & enable_r & ~bypass_r & ~fallback_active_r;
assign actuator_cmd_data_w = {31'd0, computed_cmd_r};
assign actuator_cmd_valid_w = (enable_r & ~bypass_r & ~fallback_active_r & data_valid_r & ~response_invalid_r & ~stale_detected_r & ~timeout_detected_r) | fallback_active_r;
assign fault_irq_w = stale_detected_r | timeout_detected_r | response_invalid_r | (last_fault_code_r != 1'b0);
assign csr_ready_w = csr_valid;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        enable_r <= 1'b0;
        bypass_r <= 1'b0;
        cfg_fallback_mode_r <= 1'b0;
        clear_faults_pulse_r <= 1'b0;
        request_timeout_cycles_r <= 1'b0;
        stale_timeout_cycles_r <= 1'b0;
        response_age_limit_r <= 1'b0;
        tx_seq_r <= 1'b0;
        rx_seq_expected_r <= 1'b0;
        last_good_seq_r <= 1'b0;
        cmd_min_r <= 1'b0;
        cmd_max_r <= 1'b0;
        slew_limit_r <= 1'b0;
        stream_velocity_mps_ref_r <= 1'b0;
        operating_window_min_r <= 1'b0;
        operating_window_max_r <= 1'b0;
        model_request_type_r <= 1'b0;
        model_selector_r <= 1'b0;
        flow_condition_summary_r <= 1'b0;
        geometry_handle_r <= 1'b0;
        response_status_r <= 1'b0;
        response_freshness_r <= 1'b0;
        surrogate_drag_summary_r <= 1'b0;
        surrogate_lift_summary_r <= 1'b0;
        surrogate_pressure_summary_r <= 1'b0;
        last_fault_code_r <= 1'b0;
        busy_r <= 1'b0;
        data_valid_r <= 1'b0;
        stale_detected_r <= 1'b0;
        timeout_detected_r <= 1'b0;
        response_invalid_r <= 1'b0;
        fallback_active_r <= 1'b1;
        request_age_cnt_r <= 1'b0;
        response_age_cnt_r <= 1'b0;
        outstanding_r <= 1'b0;
        last_cmd_r <= 1'b0;
        fallback_cmd_r <= 1'b0;
        computed_cmd_r <= 1'b0;
        csr_rdata_r <= 64'd0;
    end else begin
        clear_faults_pulse_r <= 1'b0;
        if (csr_valid && csr_we) begin
            case (csr_addr)
                8'h00: begin
                    enable_r <= csr_wdata[0];
                    bypass_r <= csr_wdata[1];
                    cfg_fallback_mode_r <= csr_wdata[2];
                    clear_faults_pulse_r <= csr_wdata[3];
                    if (csr_wdata[3]) begin
                        stale_detected_r <= 1'b0;
                        timeout_detected_r <= 1'b0;
                        response_invalid_r <= 1'b0;
                        last_fault_code_r <= 1'b0;
                    end
                end
                8'h01: begin
                    request_timeout_cycles_r <= csr_wdata[0];
                    stale_timeout_cycles_r <= csr_wdata[1];
                    response_age_limit_r <= csr_wdata[2];
                end
                8'h02: begin
                    tx_seq_r <= csr_wdata[0];
                end
                8'h03: begin
                    cmd_min_r <= csr_wdata[0];
                    cmd_max_r <= csr_wdata[1];
                end
                8'h04: begin
                    slew_limit_r <= csr_wdata[0];
                    stream_velocity_mps_ref_r <= csr_wdata[1];
                    operating_window_min_r <= csr_wdata[2];
                    operating_window_max_r <= csr_wdata[3];
                end
                8'h06: begin
                    model_request_type_r <= csr_wdata[0];
                    model_selector_r <= csr_wdata[1];
                    flow_condition_summary_r <= csr_wdata[2];
                    geometry_handle_r <= csr_wdata[3];
                end
                default: begin
                end
            endcase
        end
        if (outstanding_r && enable_r && ~bypass_r && ~fallback_active_r) begin
            request_age_cnt_r <= request_age_cnt_r + 1'b1;
            response_age_cnt_r <= response_age_cnt_r + 1'b1;
            busy_r <= 1'b1;
            if (request_age_cnt_r >= request_timeout_cycles_r) begin
                timeout_detected_r <= 1'b1;
                last_fault_code_r <= 1'b1;
                fallback_active_r <= 1'b1;
                outstanding_r <= 1'b0;
                busy_r <= 1'b0;
            end
            if (response_age_cnt_r >= response_age_limit_r) begin
                stale_detected_r <= 1'b1;
                last_fault_code_r <= 1'b1;
                fallback_active_r <= 1'b1;
            end
        end else begin
            busy_r <= 1'b0;
        end
        if (enable_r && ~bypass_r && ~fallback_active_r && ~outstanding_r) begin
            outstanding_r <= 1'b1;
            rx_seq_expected_r <= tx_seq_r;
            request_age_cnt_r <= 1'b0;
            response_age_cnt_r <= 1'b0;
        end
        if (rsp_valid && rsp_ready_w) begin
            response_status_r <= rsp_data[0];
            response_freshness_r <= rsp_data[1];
            surrogate_drag_summary_r <= rsp_data[2];
            surrogate_lift_summary_r <= rsp_data[3];
            surrogate_pressure_summary_r <= rsp_data[4];
            if ((rsp_data[0] == 1'b0) && (rx_seq_expected_r == tx_seq_r) && (rsp_data[1] <= response_age_limit_r)) begin
                data_valid_r <= 1'b1;
                last_good_seq_r <= rx_seq_expected_r;
                computed_cmd_r <= rsp_data[2];
                if (rsp_data[2] > cmd_max_r) begin
                    computed_cmd_r <= cmd_max_r;
                    last_fault_code_r <= 1'b1;
                end else if (rsp_data[2] < cmd_min_r) begin
                    computed_cmd_r <= cmd_min_r;
                    last_fault_code_r <= 1'b1;
                end else begin
                    last_fault_code_r <= 1'b0;
                end
                if (slew_limit_r != 1'b0) begin
                    if (computed_cmd_r > last_cmd_r) begin
                        if ((computed_cmd_r - last_cmd_r) > slew_limit_r) computed_cmd_r <= last_cmd_r + slew_limit_r;
                    end else begin
                        if ((last_cmd_r - computed_cmd_r) > slew_limit_r) computed_cmd_r <= last_cmd_r - slew_limit_r;
                    end
                end
                last_cmd_r <= computed_cmd_r;
                fallback_active_r <= 1'b0;
                outstanding_r <= 1'b0;
                busy_r <= 1'b0;
            end else begin
                response_invalid_r <= 1'b1;
                last_fault_code_r <= 1'b1;
                fallback_active_r <= 1'b1;
                outstanding_r <= 1'b0;
                busy_r <= 1'b0;
            end
        end
        if (bypass_r || ~enable_r) begin
            fallback_active_r <= 1'b1;
            busy_r <= 1'b0;
        end
        if (fallback_active_r) begin
            case (cfg_fallback_mode_r)
                1'b0: fallback_cmd_r <= cmd_min_r;
                default: fallback_cmd_r <= cmd_min_r;
            endcase
        end
        if (computed_cmd_r < cmd_min_r) computed_cmd_r <= cmd_min_r;
        if (computed_cmd_r > cmd_max_r) computed_cmd_r <= cmd_max_r;
        case (csr_addr)
            8'h00: csr_rdata_r <= {59'd0, clear_faults_pulse_r, cfg_fallback_mode_r, 1'b0, bypass_r, enable_r};
            8'h01: csr_rdata_r <= {61'd0, response_age_limit_r, stale_timeout_cycles_r, request_timeout_cycles_r};
            8'h02: csr_rdata_r <= {61'd0, last_good_seq_r, rx_seq_expected_r, tx_seq_r};
            8'h03: csr_rdata_r <= {62'b0, cmd_max_r, cmd_min_r};
            8'h04: csr_rdata_r <= {12'b0, 48'd0, operating_window_max_r, operating_window_min_r, stream_velocity_mps_ref_r, slew_limit_r};
            8'h05: csr_rdata_r <= {1'b0, 56'd0, last_fault_code_r, fallback_active_r, response_invalid_r, timeout_detected_r, stale_detected_r, data_valid_r, busy_r};
            8'h06: csr_rdata_r <= {60'd0, geometry_handle_r, flow_condition_summary_r, model_selector_r, model_request_type_r};
            8'h07: csr_rdata_r <= {11'b0, 48'd0, surrogate_pressure_summary_r, surrogate_lift_summary_r, surrogate_drag_summary_r, response_freshness_r, response_status_r};
            default: csr_rdata_r <= 64'd0;
        endcase
    end
end

endmodule
