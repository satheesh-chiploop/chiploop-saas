# System RTL Evidence Dashboard

## System
- Top module: soc_top_sim
- RTL files: 3
- Modules: 3
- Input bits: 9
- Output bits: 6
- Flip-flops: 16
- Latches: 0
- Full-cycle paths: 3
- Half-cycle paths: 0

## Soc
- Top module: soc_top_sim
- RTL files: 2
- Modules: 2
- Input bits: 9
- Output bits: 6
- Flip-flops: 0
- Latches: 0
- Full-cycle paths: 2
- Half-cycle paths: 0

## Digital
- Top module: temp_sensor_adc_model
- RTL files: 1
- Modules: 1
- Input bits: 19
- Output bits: 13
- Flip-flops: 16
- Latches: 0
- Full-cycle paths: 3
- Half-cycle paths: 0

## Analog
- Top module: analog_macro
- RTL files: 0
- Modules: 0
- Input bits: 0
- Output bits: 0
- Flip-flops: 0
- Latches: 0
- Full-cycle paths: 2
- Half-cycle paths: 0
