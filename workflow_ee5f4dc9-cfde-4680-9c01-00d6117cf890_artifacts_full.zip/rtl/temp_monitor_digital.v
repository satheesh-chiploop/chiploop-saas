module temp_monitor_digital (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    adc_code,
    adc_valid,
    rd_data,
    sample_req,
    alert_irq,
    temp_code,
    threshold_code,
    alert_status
);

input clk;
input reset_n;
input wr_en;
input [7:0] wr_addr;
input [15:0] wr_data;
input rd_en;
input [7:0] rd_addr;
input [11:0] adc_code;
input adc_valid;

output [15:0] rd_data;
output sample_req;
output alert_irq;
output [11:0] temp_code;
output [11:0] threshold_code;
output alert_status;

reg [15:0] rd_data;
reg sample_req;
reg alert_irq;
reg [11:0] temp_code;
reg [11:0] threshold_code;
reg alert_status;

reg [7:0] control_reg;
reg [3:0] status_reg;
reg [15:0] sample_count_reg;
reg [15:0] irq_status_reg;
reg [11:0] prev_adc_code;
reg prev_sample_valid;
reg [11:0] adc_sample_reg;
reg adc_valid_seen_reg;
reg busy_reg;
reg sample_start_req_reg;

wire enable_w;
wire irq_enable_w;
wire alert_clear_w;
wire sample_start_w;
wire do_sample_w;
wire [12:0] avg_sum_w;
wire [11:0] avg_code_w;
wire alert_event_w;
wire sample_done_event_w;

assign enable_w = control_reg[0];
assign sample_start_w = control_reg[1];
assign irq_enable_w = control_reg[2];
assign alert_clear_w = control_reg[3];
assign do_sample_w = enable_w | sample_start_req_reg | sample_start_w;
assign avg_sum_w = {1'b0, adc_sample_reg} + {1'b0, prev_adc_code};
assign avg_code_w = avg_sum_w[12:1];
assign alert_event_w = (temp_code > threshold_code);
assign sample_done_event_w = adc_valid;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        control_reg <= 8'h00;
        status_reg <= 4'h00;
        threshold_code <= 12'h000;
        temp_code <= 12'h000;
        sample_count_reg <= 16'h0000;
        irq_status_reg <= 16'h0000;
        prev_adc_code <= 12'h000;
        prev_sample_valid <= 1'b0;
        adc_sample_reg <= 12'h000;
        adc_valid_seen_reg <= 1'b0;
        busy_reg <= 1'b0;
        sample_start_req_reg <= 1'b0;
        rd_data <= 16'h0000;
        sample_req <= 1'b0;
        alert_irq <= 1'b0;
        alert_status <= 1'b0;
    end else begin
        if (wr_en) begin
            case (wr_addr)
                8'h00: begin
                    control_reg <= wr_data[7:0];
                    if (wr_data[1]) begin
                        sample_start_req_reg <= 1'b1;
                    end
                    if (wr_data[3]) begin
                        alert_status <= 1'b0;
                        irq_status_reg[0] <= 1'b0;
                    end
                end
                8'h08: begin
                    threshold_code <= wr_data[11:0];
                end
                8'h18: begin
                    if (wr_data[0]) begin
                        irq_status_reg[0] <= 1'b0;
                    end
                    if (wr_data[1]) begin
                        irq_status_reg[1] <= 1'b0;
                    end
                    if (wr_data[3]) begin
                        alert_status <= 1'b0;
                    end
                end
                default: begin
                end
            endcase
        end

        if (adc_valid) begin
            adc_sample_reg <= adc_code;
            prev_adc_code <= adc_code;
            prev_sample_valid <= 1'b1;
            adc_valid_seen_reg <= 1'b1;
            busy_reg <= 1'b0;
            sample_start_req_reg <= 1'b0;
            temp_code <= avg_code_w;
            sample_count_reg <= sample_count_reg + 16'h0001;
            status_reg[0] <= 1'b1;
            status_reg[2] <= 1'b1;
            if (avg_code_w > threshold_code) begin
                alert_status <= 1'b1;
                irq_status_reg[0] <= 1'b1;
            end
            irq_status_reg[1] <= 1'b1;
        end else begin
            status_reg[0] <= 1'b0;
        end

        status_reg[1] <= alert_status;
        status_reg[2] <= adc_valid_seen_reg;
        status_reg[3] <= busy_reg | do_sample_w;

        if (alert_clear_w) begin
            alert_status <= 1'b0;
        end

        if (rd_en) begin
            case (rd_addr)
                8'h00: rd_data <= {8'h00, control_reg};
                8'h04: rd_data <= {12'h000, status_reg};
                8'h08: rd_data <= {4'h0, threshold_code};
                8'h0C: rd_data <= {4'h0, temp_code};
                8'h10: rd_data <= sample_count_reg;
                8'h14: rd_data <= {14'h0000, irq_status_reg[1:0]};
                8'h18: rd_data <= {14'h0000, irq_status_reg[1:0]};
                default: rd_data <= 16'h0000;
            endcase
        end else begin
            rd_data <= 16'h0000;
        end

        sample_req <= do_sample_w;
        alert_irq <= irq_enable_w & (irq_status_reg[0] | irq_status_reg[1]);
    end
end

endmodule
