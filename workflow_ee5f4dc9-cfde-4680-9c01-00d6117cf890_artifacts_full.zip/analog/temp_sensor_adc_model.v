module temp_sensor_adc_model (
    input         sample_req,
    input  [15:0] sensor_temp_celsius,
    input         avdd,
    input         avss,
    output reg [11:0] adc_code,
    output reg        adc_valid
);

    parameter integer NOMINAL_SAMPLE_LATENCY = 2;
    parameter integer TEMP_TO_CODE_GAIN      = 16;
    parameter integer TEMP_CODE_OFFSET       = 0;
    parameter integer GAIN_ERROR_PPM         = 0;
    parameter integer OFFSET_ERROR_CODES     = 0;

    localparam [11:0] ADC_MIN = 12'd0;
    localparam [11:0] ADC_MAX = 12'd4095;

    reg sample_req_d;
    reg pending_sample;
    integer sample_timer;
    integer temp_i;
    integer gain_adjust_i;
    integer computed_i;
    reg [11:0] next_adc_code;

    always @(*) begin
        temp_i = {16'd0, sensor_temp_celsius};
        gain_adjust_i = TEMP_TO_CODE_GAIN + ((TEMP_TO_CODE_GAIN * GAIN_ERROR_PPM) / 1000000);
        computed_i = (temp_i * gain_adjust_i) + TEMP_CODE_OFFSET + OFFSET_ERROR_CODES;

        if (computed_i < 0)
            next_adc_code = ADC_MIN;
        else if (computed_i > 4095)
            next_adc_code = ADC_MAX;
        else
            next_adc_code = computed_i[11:0];
    end

    always @(posedge sample_req or posedge avdd or posedge avss) begin
        if (!avdd || !avss) begin
            sample_req_d <= 1'b0;
        end else begin
            sample_req_d <= 1'b1;
        end
    end

    always @(posedge sample_req or posedge avdd or posedge avss) begin
        if (!avdd || !avss) begin
            pending_sample <= 1'b0;
            sample_timer   <= 0;
            adc_code       <= 12'd0;
            adc_valid      <= 1'b0;
            sample_req_d   <= 1'b0;
        end else begin
            if (sample_req && !sample_req_d) begin
                pending_sample <= 1'b1;
                sample_timer   <= NOMINAL_SAMPLE_LATENCY;
                adc_valid      <= 1'b0;
            end else if (pending_sample) begin
                if (sample_timer <= 0) begin
                    adc_code       <= next_adc_code;
                    adc_valid      <= 1'b1;
                    pending_sample <= 1'b0;
                    sample_timer   <= 0;
                end else begin
                    sample_timer   <= sample_timer - 1;
                    adc_valid      <= 1'b0;
                end
            end else begin
                adc_valid <= 1'b0;
            end
            sample_req_d <= sample_req;
        end
    end

    initial begin
        adc_code       = 12'd0;
        adc_valid      = 1'b0;
        pending_sample = 1'b0;
        sample_timer   = 0;
        sample_req_d   = 1'b0;
    end

endmodule