# Analog Model Notes

- block_name: temp_sensor_adc_model
- module_name: temp_sensor_adc_model
- source: Analog Behavioral Model Agent
- model_file: temp_sensor_adc_model.v
- params_file: temp_sensor_adc_model_params.json
- compile_log: temp_sensor_adc_model_compile.log
- compile_summary: temp_sensor_adc_model_compile_summary.json
- verilator_log: temp_sensor_adc_model_verilator_lint.log
- repair_used: yes
- note: Module-scoped analog behavioral model artifact set
- compile_status: clean
