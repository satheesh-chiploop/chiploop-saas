# Spec-to-RTL Conformance Report

Status: **partial**

- Requirements checked: 34
- Matched: 29
- Partial: 0
- Missing: 4
- Inconclusive: 1
- Interface: pass
- Register map: pass
- Clock/reset: pass

## Missing Or Partial Requirements
- REQ-002 [missing]: Implement CONTROL, STATUS, THRESHOLD, LATEST_TEMP, SAMPLE_COUNT, IRQ_STATUS, and IRQ_CLEAR register behavior.
- REQ-009 [missing]: Support ALERT_CLEAR and IRQ_CLEAR semantics without clearing latest temperature.
- REQ-015 [missing]: Set STATUS.sample_done and IRQ_STATUS.sample_done when a sample completes, if that is the selected architectural policy, and retain until cleared by IRQ_CLEAR or equivalent documented clear path.
- REQ-020 [missing]: IRQ_CLEAR clears the corresponding IRQ_STATUS bits when written with ones.
