# IP Packaging & Handoff Report

- Top: `imported_from_arch2rtl`
- Package: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/1b885312-d63d-4149-ad36-c999faca0b0c/9095cc1a-5152-4a4b-aa0c-cc2a8b5ea2a3/digital/arch2synthesis/handoff/imported_from_arch2rtl_ip_package`
- Zip: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/1b885312-d63d-4149-ad36-c999faca0b0c/9095cc1a-5152-4a4b-aa0c-cc2a8b5ea2a3/digital/arch2synthesis/handoff/imported_from_arch2rtl_ip_package.zip`

## Bucket counts
- **rtl**: 5
- **spec**: 1
- **arch**: 0
- **microarch**: 0
- **regmap**: 1
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 2
