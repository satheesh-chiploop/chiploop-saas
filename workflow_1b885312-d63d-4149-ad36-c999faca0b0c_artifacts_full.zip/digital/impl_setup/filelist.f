/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/1b885312-d63d-4149-ad36-c999faca0b0c/9095cc1a-5152-4a4b-aa0c-cc2a8b5ea2a3/digital/arch2synthesis/handoff/rtl/uart_baud_tick_gen.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/1b885312-d63d-4149-ad36-c999faca0b0c/9095cc1a-5152-4a4b-aa0c-cc2a8b5ea2a3/digital/arch2synthesis/handoff/rtl/uart_packet_engine.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/1b885312-d63d-4149-ad36-c999faca0b0c/9095cc1a-5152-4a4b-aa0c-cc2a8b5ea2a3/digital/arch2synthesis/handoff/rtl/uart_packet_engine_mmio.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/1b885312-d63d-4149-ad36-c999faca0b0c/9095cc1a-5152-4a4b-aa0c-cc2a8b5ea2a3/digital/arch2synthesis/handoff/rtl/uart_rx_engine.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/1b885312-d63d-4149-ad36-c999faca0b0c/9095cc1a-5152-4a4b-aa0c-cc2a8b5ea2a3/digital/arch2synthesis/handoff/rtl/uart_tx_engine.v
