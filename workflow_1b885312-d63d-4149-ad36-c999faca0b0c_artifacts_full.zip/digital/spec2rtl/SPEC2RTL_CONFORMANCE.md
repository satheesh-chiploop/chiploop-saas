# Spec-to-RTL Conformance Report

Status: **partial**

- Requirements checked: 84
- Matched: 74
- Partial: 0
- Missing: 10
- Inconclusive: 0
- Interface: pass
- Register map: issues
- Clock/reset: pass

## Missing Or Partial Requirements
- REQ-002 [missing]: Expose the full MMIO register interface to firmware.
- REQ-006 [missing]: Own top-level external UART pin interface and externally visible status outputs.
- REQ-020 [missing]: All FIFO level outputs must track the exact number of occupied entries, saturated to the 6-bit output width.
- REQ-025 [missing]: Decode MMIO address space.
- REQ-026 [missing]: Latch control and configuration registers.
- REQ-032 [missing]: Provide semantic control outputs to datapath modules.
- REQ-044 [missing]: This module is the sole legal source of semantic control signals used by the rest of the design.
- REQ-072 [missing]: Implement programmable divider counter.
