# Logic Equivalence Check

- Status: `incomplete_stdcell_models`
- Tool: `yosys`
- Top module: `uart_packet_engine`
- RTL files: `5`
- Synth netlist: `uart_packet_engine_synth.v`
- Liberty files discovered: `1`
- Standard-cell Verilog models loaded: `1`
- Standard-cell model strategy: `generated_functional_wrappers_from_gate_netlist`
- Missing standard-cell models: `3`
- Unproven points: `0`
- Return code: `None`
- Failure reason: `standard_cell_verilog_models_incomplete`

If this is inconclusive, inspect `digital/lec/logs/yosys_lec.log` and `digital/lec/lec_summary.json` for unsupported cells, black boxes, or reset/initial-state assumptions.

## Missing Standard-Cell Models

- `sky130_fd_sc_hd__mux4_2`
- `sky130_fd_sc_hd__dfstp_2`
- `sky130_fd_sc_hd__conb_1`
