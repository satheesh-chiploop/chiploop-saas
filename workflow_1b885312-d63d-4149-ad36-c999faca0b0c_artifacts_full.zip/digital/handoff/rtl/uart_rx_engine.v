module uart_rx_engine (
    input clk,
    input reset_n,
    input control_enable,
    input control_rx_enable,
    input baud_tick,
    input uart_rx,
    input loopback_byte_valid,
    input [7:0] loopback_byte,
    input [7:0] packet_len,
    input rx_data_pop,
    output [5:0] rx_fifo_level,
    output rx_empty,
    output rx_full,
    output rx_busy,
    output rx_done_event,
    output rx_overflow_event,
    output framing_error_event,
    output packet_done_event,
    output [7:0] rx_data_byte,
    output rx_data_valid
);

reg [7:0] rx_fifo_mem [0:15];
reg [3:0] rx_wr_ptr;
reg [3:0] rx_rd_ptr;
reg [4:0] rx_count;
reg [7:0] rx_shift_reg;
reg [2:0] rx_bit_index;
reg [3:0] rx_state;
reg [7:0] rx_packet_count;
reg rx_busy_r;
reg rx_done_r;
reg rx_overflow_r;
reg framing_error_r;
reg packet_done_r;
reg [7:0] rx_data_byte_r;
reg rx_data_valid_r;
reg [5:0] rx_fifo_level_r;

integer j;

localparam RX_IDLE = 4'd0;
localparam RX_START = 4'd1;
localparam RX_DATA = 4'd2;
localparam RX_STOP = 4'd3;
localparam RX_LOOP = 4'd4;

assign rx_fifo_level = rx_fifo_level_r;
assign rx_empty = (rx_count == 5'd0);
assign rx_full = (rx_count == 5'd16);
assign rx_busy = rx_busy_r;
assign rx_done_event = rx_done_r;
assign rx_overflow_event = rx_overflow_r;
assign framing_error_event = framing_error_r;
assign packet_done_event = packet_done_r;
assign rx_data_byte = rx_data_byte_r;
assign rx_data_valid = rx_data_valid_r;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        rx_wr_ptr <= 4'h0;
        rx_rd_ptr <= 4'h0;
        rx_count <= 5'd0;
        rx_shift_reg <= 8'h00;
        rx_bit_index <= 3'd0;
        rx_state <= RX_IDLE;
        rx_packet_count <= 8'h00;
        rx_busy_r <= 1'b0;
        rx_done_r <= 1'b0;
        rx_overflow_r <= 1'b0;
        framing_error_r <= 1'b0;
        packet_done_r <= 1'b0;
        rx_data_byte_r <= 8'h00;
        rx_data_valid_r <= 1'b0;
        rx_fifo_level_r <= 6'd0;
        for (j = 0; j < 16; j = j + 1) begin
            rx_fifo_mem[j] <= 8'h00;
        end
    end else begin
        rx_done_r <= 1'b0;
        rx_overflow_r <= 1'b0;
        framing_error_r <= 1'b0;
        packet_done_r <= 1'b0;
        rx_data_valid_r <= 1'b0;
        if (rx_data_pop && !rx_empty) begin
            rx_rd_ptr <= rx_rd_ptr + 4'd1;
            rx_count <= rx_count - 5'd1;
            rx_data_byte_r <= rx_fifo_mem[rx_rd_ptr];
            rx_data_valid_r <= 1'b1;
        end
        if (control_enable && control_rx_enable) begin
            if (loopback_byte_valid) begin
                if (!rx_full) begin
                    rx_fifo_mem[rx_wr_ptr] <= loopback_byte;
                    rx_wr_ptr <= rx_wr_ptr + 4'd1;
                    rx_count <= rx_count + 5'd1;
                    rx_data_byte_r <= loopback_byte;
                    rx_data_valid_r <= 1'b1;
                    rx_packet_count <= rx_packet_count + 8'd1;
                    if (packet_len != 8'h00 && ((rx_packet_count + 8'd1) == packet_len)) begin
                        rx_done_r <= 1'b1;
                        packet_done_r <= 1'b1;
                        rx_packet_count <= 8'h00;
                    end
                end else begin
                    rx_overflow_r <= 1'b1;
                end
            end else if (baud_tick) begin
                case (rx_state)
                    RX_IDLE: begin
                        rx_busy_r <= 1'b0;
                        if (!uart_rx) begin
                            rx_busy_r <= 1'b1;
                            rx_state <= RX_START;
                        end
                    end
                    RX_START: begin
                        if (!uart_rx) begin
                            rx_state <= RX_DATA;
                            rx_bit_index <= 3'd0;
                            rx_shift_reg <= 8'h00;
                        end else begin
                            framing_error_r <= 1'b1;
                            rx_state <= RX_IDLE;
                            rx_busy_r <= 1'b0;
                        end
                    end
                    RX_DATA: begin
                        rx_shift_reg[rx_bit_index] <= uart_rx;
                        if (rx_bit_index == 3'd7) begin
                            rx_state <= RX_STOP;
                        end
                        rx_bit_index <= rx_bit_index + 3'd1;
                    end
                    RX_STOP: begin
                        if (uart_rx) begin
                            if (!rx_full) begin
                                rx_fifo_mem[rx_wr_ptr] <= rx_shift_reg;
                                rx_wr_ptr <= rx_wr_ptr + 4'd1;
                                rx_count <= rx_count + 5'd1;
                                rx_data_byte_r <= rx_shift_reg;
                                rx_data_valid_r <= 1'b1;
                                rx_packet_count <= rx_packet_count + 8'd1;
                                if (packet_len != 8'h00 && ((rx_packet_count + 8'd1) == packet_len)) begin
                                    rx_done_r <= 1'b1;
                                    packet_done_r <= 1'b1;
                                    rx_packet_count <= 8'h00;
                                end
                            end else begin
                                rx_overflow_r <= 1'b1;
                            end
                        end else begin
                            framing_error_r <= 1'b1;
                        end
                        rx_state <= RX_IDLE;
                        rx_busy_r <= 1'b0;
                    end
                    default: begin
                        rx_state <= RX_IDLE;
                        rx_busy_r <= 1'b0;
                    end
                endcase
            end
        end else begin
            rx_busy_r <= 1'b0;
            rx_state <= RX_IDLE;
        end
        rx_fifo_level_r <= {1'b0, rx_count};
    end
end

endmodule
