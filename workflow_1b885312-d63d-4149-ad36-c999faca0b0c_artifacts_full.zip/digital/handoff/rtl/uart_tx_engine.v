module uart_tx_engine (
    input clk,
    input reset_n,
    input control_enable,
    input control_tx_enable,
    input control_loopback,
    input baud_tick,
    input tx_data_push,
    input [7:0] tx_data_byte,
    input [7:0] packet_len,
    output [5:0] tx_fifo_level,
    output tx_empty,
    output tx_full,
    output tx_busy,
    output tx_underflow_event,
    output tx_done_event,
    output uart_tx,
    output loopback_byte_valid,
    output [7:0] loopback_byte
);

reg [7:0] tx_fifo_mem [0:15];
reg [3:0] tx_wr_ptr;
reg [3:0] tx_rd_ptr;
reg [4:0] tx_count;
reg [7:0] tx_shift_reg;
reg [2:0] tx_bit_index;
reg [7:0] tx_packet_count;
reg tx_busy_r;
reg tx_underflow_r;
reg tx_done_r;
reg uart_tx_r;
reg loopback_valid_r;
reg [7:0] loopback_byte_r;
reg [5:0] tx_fifo_level_r;

integer i;

assign tx_fifo_level = tx_fifo_level_r;
assign tx_empty = (tx_count == 5'd0);
assign tx_full = (tx_count == 5'd16);
assign tx_busy = tx_busy_r;
assign tx_underflow_event = tx_underflow_r;
assign tx_done_event = tx_done_r;
assign uart_tx = uart_tx_r;
assign loopback_byte_valid = loopback_valid_r;
assign loopback_byte = loopback_byte_r;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        tx_wr_ptr <= 4'h0;
        tx_rd_ptr <= 4'h0;
        tx_count <= 5'd0;
        tx_shift_reg <= 8'h00;
        tx_bit_index <= 3'd0;
        tx_packet_count <= 8'h00;
        tx_busy_r <= 1'b0;
        tx_underflow_r <= 1'b0;
        tx_done_r <= 1'b0;
        uart_tx_r <= 1'b1;
        loopback_valid_r <= 1'b0;
        loopback_byte_r <= 8'h00;
        tx_fifo_level_r <= 6'd0;
        for (i = 0; i < 16; i = i + 1) begin
            tx_fifo_mem[i] <= 8'h00;
        end
    end else begin
        tx_underflow_r <= 1'b0;
        tx_done_r <= 1'b0;
        loopback_valid_r <= 1'b0;
        if (tx_data_push && !tx_full) begin
            tx_fifo_mem[tx_wr_ptr] <= tx_data_byte;
            tx_wr_ptr <= tx_wr_ptr + 4'd1;
            tx_count <= tx_count + 5'd1;
        end
        if (tx_data_push && tx_full) begin
            tx_underflow_r <= 1'b1;
        end
        if (control_enable && control_tx_enable) begin
            if (!tx_busy_r && (tx_count != 5'd0) && baud_tick) begin
                tx_shift_reg <= tx_fifo_mem[tx_rd_ptr];
                tx_rd_ptr <= tx_rd_ptr + 4'd1;
                tx_count <= tx_count - 5'd1;
                tx_busy_r <= 1'b1;
                tx_bit_index <= 3'd0;
                uart_tx_r <= 1'b0;
                if (control_loopback) begin
                    loopback_valid_r <= 1'b1;
                    loopback_byte_r <= tx_fifo_mem[tx_rd_ptr];
                end
            end else if (tx_busy_r && baud_tick) begin
                if (tx_bit_index < 3'd7) begin
                    uart_tx_r <= tx_shift_reg[tx_bit_index];
                    tx_bit_index <= tx_bit_index + 3'd1;
                end else begin
                    uart_tx_r <= 1'b1;
                    tx_busy_r <= 1'b0;
                    tx_bit_index <= 3'd0;
                    if (packet_len != 8'h00) begin
                        tx_packet_count <= tx_packet_count + 8'd1;
                        if ((tx_packet_count + 8'd1) == packet_len) begin
                            tx_done_r <= 1'b1;
                            tx_packet_count <= 8'h00;
                        end
                    end
                end
            end
        end else begin
            uart_tx_r <= 1'b1;
            tx_busy_r <= 1'b0;
            tx_packet_count <= 8'h00;
        end
        tx_fifo_level_r <= {1'b0, tx_count};
    end
end

endmodule
