module uart_packet_engine_mmio (
    input clk,
    input reset_n,
    input wr_en,
    input [7:0] wr_addr,
    input [7:0] wr_data,
    input rd_en,
    input [7:0] rd_addr,
    output control_enable,
    output control_rx_enable,
    output control_tx_enable,
    output control_loopback,
    output control_irq_enable,
    output [15:0] baud_div,
    output [7:0] packet_len,
    output tx_data_push,
    output [7:0] tx_data_byte,
    output rx_data_pop,
    output [5:0] irq_clear,
    output [5:0] irq_status,
    input status_tx_empty,
    input status_tx_full,
    input status_rx_empty,
    input status_rx_full,
    input status_tx_busy,
    input status_rx_busy,
    input status_packet_active,
    input status_error,
    input [5:0] rx_fifo_level,
    input [5:0] tx_fifo_level,
    output [15:0] packet_count,
    input rx_done_event,
    input tx_done_event,
    input rx_overflow_event,
    input tx_underflow_event,
    input framing_error_event,
    input packet_done_event,
    output [7:0] rd_data
);

reg [7:0] control_reg;
reg [15:0] baud_div_reg;
reg [7:0] packet_len_reg;
reg [5:0] irq_status_reg;
reg [15:0] packet_count_reg;
reg [7:0] rd_data_r;
reg tx_data_push_r;
reg [7:0] tx_data_byte_r;
reg rx_data_pop_r;
reg [5:0] irq_clear_r;

assign control_enable = control_reg[0];
assign control_rx_enable = control_reg[1];
assign control_tx_enable = control_reg[2];
assign control_loopback = control_reg[3];
assign control_irq_enable = control_reg[4];
assign baud_div = baud_div_reg;
assign packet_len = packet_len_reg;
assign tx_data_push = tx_data_push_r;
assign tx_data_byte = tx_data_byte_r;
assign rx_data_pop = rx_data_pop_r;
assign irq_clear = irq_clear_r;
assign irq_status = irq_status_reg;
assign packet_count = packet_count_reg;
assign rd_data = rd_data_r;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        control_reg <= 8'h00;
        baud_div_reg <= 16'h0000;
        packet_len_reg <= 8'h00;
        irq_status_reg <= 6'h00;
        packet_count_reg <= 16'h0000;
        rd_data_r <= 8'h00;
        tx_data_push_r <= 1'b0;
        tx_data_byte_r <= 8'h00;
        rx_data_pop_r <= 1'b0;
        irq_clear_r <= 6'h00;
    end else begin
        tx_data_push_r <= 1'b0;
        rx_data_pop_r <= 1'b0;
        irq_clear_r <= 6'h00;
        if (wr_en) begin
            case (wr_addr)
                8'h00: control_reg <= {3'b000, wr_data[4:0]};
                8'h04: baud_div_reg[7:0] <= wr_data;
                8'h05: baud_div_reg[15:8] <= wr_data;
                8'h08: packet_len_reg <= wr_data;
                8'h0C: begin
                    tx_data_push_r <= 1'b1;
                    tx_data_byte_r <= wr_data;
                end
                8'h1C: irq_clear_r <= wr_data[5:0];
                default: begin
                end
            endcase
        end
        if (rd_en) begin
            case (rd_addr)
                8'h10: rx_data_pop_r <= 1'b1;
                default: begin
                end
            endcase
        end
        if (rx_done_event) irq_status_reg[0] <= 1'b1;
        if (tx_done_event) irq_status_reg[1] <= 1'b1;
        if (rx_overflow_event) irq_status_reg[2] <= 1'b1;
        if (tx_underflow_event) irq_status_reg[3] <= 1'b1;
        if (framing_error_event) irq_status_reg[4] <= 1'b1;
        if (packet_done_event) irq_status_reg[5] <= 1'b1;
        if (irq_clear_r[0]) irq_status_reg[0] <= 1'b0;
        if (irq_clear_r[1]) irq_status_reg[1] <= 1'b0;
        if (irq_clear_r[2]) irq_status_reg[2] <= 1'b0;
        if (irq_clear_r[3]) irq_status_reg[3] <= 1'b0;
        if (irq_clear_r[4]) irq_status_reg[4] <= 1'b0;
        if (irq_clear_r[5]) irq_status_reg[5] <= 1'b0;
        if (rx_done_event) packet_count_reg <= packet_count_reg + 16'd1;
        if (rd_en) begin
            case (rd_addr)
                8'h00: rd_data_r <= control_reg;
                8'h04: rd_data_r <= baud_div_reg[7:0];
                8'h05: rd_data_r <= baud_div_reg[15:8];
                8'h08: rd_data_r <= packet_len_reg;
                8'h10: rd_data_r <= 8'h00;
                8'h14: rd_data_r <= {status_error, status_packet_active, status_rx_busy, status_tx_busy, status_rx_full, status_rx_empty, status_tx_full, status_tx_empty};
                8'h18: rd_data_r <= {2'b00, irq_status_reg};
                8'h1C: rd_data_r <= {2'b00, irq_clear_r};
                8'h20: rd_data_r <= packet_count_reg[7:0];
                8'h21: rd_data_r <= packet_count_reg[15:8];
                default: rd_data_r <= 8'h00;
            endcase
        end else begin
            rd_data_r <= 8'h00;
        end
    end
end

endmodule
