module uart_packet_engine (
    input clk,
    input reset_n,
    input wr_en,
    input [7:0] wr_addr,
    input [7:0] wr_data,
    input rd_en,
    input [7:0] rd_addr,
    input uart_rx,
    output [7:0] rd_data,
    output uart_tx,
    input irq,
    output [5:0] rx_fifo_level,
    output [5:0] tx_fifo_level,
    output [15:0] packet_count
);

wire control_enable;
wire control_rx_enable;
wire control_tx_enable;
wire control_loopback;
wire control_irq_enable;
wire [15:0] baud_div;
wire [7:0] packet_len;
wire tx_data_push;
wire [7:0] tx_data_byte;
wire rx_data_pop;
wire [5:0] irq_clear;
wire [5:0] irq_status;
wire status_tx_empty;
wire status_tx_full;
wire status_rx_empty;
wire status_rx_full;
wire status_tx_busy;
wire status_rx_busy;
wire status_packet_active;
wire status_error;
wire [5:0] mmio_rx_fifo_level;
wire [5:0] mmio_tx_fifo_level;
wire [15:0] mmio_packet_count;
wire rx_done_event;
wire tx_done_event;
wire rx_overflow_event;
wire tx_underflow_event;
wire framing_error_event;
wire packet_done_event;
wire baud_tick;
wire loopback_byte_valid;
wire [7:0] loopback_byte;
wire rx_empty;
wire rx_full;
wire rx_busy;
wire rx_data_valid;
wire [7:0] rx_data_byte;
wire irq_unused;

assign irq_unused = irq;
assign rx_fifo_level = mmio_rx_fifo_level;
assign tx_fifo_level = mmio_tx_fifo_level;
assign packet_count = mmio_packet_count;

uart_packet_engine_mmio u_uart_packet_engine_mmio (
    .clk(clk),
    .reset_n(reset_n),
    .wr_en(wr_en),
    .wr_addr(wr_addr),
    .wr_data(wr_data),
    .rd_en(rd_en),
    .rd_addr(rd_addr),
    .control_enable(control_enable),
    .control_rx_enable(control_rx_enable),
    .control_tx_enable(control_tx_enable),
    .control_loopback(control_loopback),
    .control_irq_enable(control_irq_enable),
    .baud_div(baud_div),
    .packet_len(packet_len),
    .tx_data_push(tx_data_push),
    .tx_data_byte(tx_data_byte),
    .rx_data_pop(rx_data_pop),
    .irq_clear(irq_clear),
    .irq_status(irq_status),
    .status_tx_empty(status_tx_empty),
    .status_tx_full(status_tx_full),
    .status_rx_empty(status_rx_empty),
    .status_rx_full(status_rx_full),
    .status_tx_busy(status_tx_busy),
    .status_rx_busy(status_rx_busy),
    .status_packet_active(status_packet_active),
    .status_error(status_error),
    .rx_fifo_level(mmio_rx_fifo_level),
    .tx_fifo_level(mmio_tx_fifo_level),
    .packet_count(mmio_packet_count),
    .rx_done_event(rx_done_event),
    .tx_done_event(tx_done_event),
    .rx_overflow_event(rx_overflow_event),
    .tx_underflow_event(tx_underflow_event),
    .framing_error_event(framing_error_event),
    .packet_done_event(packet_done_event),
    .rd_data(rd_data)
);

uart_baud_tick_gen u_uart_baud_tick_gen (
    .clk(clk),
    .reset_n(reset_n),
    .enable(control_enable),
    .baud_div(baud_div),
    .baud_tick(baud_tick)
);

uart_tx_engine u_uart_tx_engine (
    .clk(clk),
    .reset_n(reset_n),
    .control_enable(control_enable),
    .control_tx_enable(control_tx_enable),
    .control_loopback(control_loopback),
    .baud_tick(baud_tick),
    .tx_data_push(tx_data_push),
    .tx_data_byte(tx_data_byte),
    .packet_len(packet_len),
    .tx_fifo_level(mmio_tx_fifo_level),
    .tx_empty(status_tx_empty),
    .tx_full(status_tx_full),
    .tx_busy(status_tx_busy),
    .tx_underflow_event(tx_underflow_event),
    .tx_done_event(tx_done_event),
    .uart_tx(uart_tx),
    .loopback_byte_valid(loopback_byte_valid),
    .loopback_byte(loopback_byte)
);

uart_rx_engine u_uart_rx_engine (
    .clk(clk),
    .reset_n(reset_n),
    .control_enable(control_enable),
    .control_rx_enable(control_rx_enable),
    .baud_tick(baud_tick),
    .uart_rx(uart_rx),
    .loopback_byte_valid(loopback_byte_valid),
    .loopback_byte(loopback_byte),
    .packet_len(packet_len),
    .rx_data_pop(rx_data_pop),
    .rx_fifo_level(mmio_rx_fifo_level),
    .rx_empty(status_rx_empty),
    .rx_full(status_rx_full),
    .rx_busy(status_rx_busy),
    .rx_done_event(rx_done_event),
    .rx_overflow_event(rx_overflow_event),
    .framing_error_event(framing_error_event),
    .packet_done_event(packet_done_event),
    .rx_data_byte(rx_data_byte),
    .rx_data_valid(rx_data_valid)
);

endmodule
