module uart_baud_tick_gen (
    input clk,
    input reset_n,
    input enable,
    input [15:0] baud_div,
    output baud_tick
);

reg [15:0] baud_cnt;
reg baud_tick_r;

assign baud_tick = baud_tick_r;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        baud_cnt <= 16'h0000;
        baud_tick_r <= 1'b0;
    end else begin
        baud_tick_r <= 1'b0;
        if (enable) begin
            if (baud_cnt >= baud_div) begin
                baud_cnt <= 16'h0000;
                baud_tick_r <= 1'b1;
            end else begin
                baud_cnt <= baud_cnt + 16'd1;
            end
        end else begin
            baud_cnt <= 16'h0000;
        end
    end
end

endmodule
