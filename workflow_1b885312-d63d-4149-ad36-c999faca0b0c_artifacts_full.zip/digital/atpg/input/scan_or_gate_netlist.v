module uart_packet_engine (clk,
    irq,
    rd_en,
    reset_n,
    scan_en,
    uart_rx,
    uart_tx,
    wr_en,
    packet_count,
    rd_addr,
    rd_data,
    rx_fifo_level,
    scan_in,
    scan_out,
    tx_fifo_level,
    wr_addr,
    wr_data);
 input clk;
 input irq;
 input rd_en;
 input reset_n;
 input scan_en;
 input uart_rx;
 output uart_tx;
 input wr_en;
 output [15:0] packet_count;
 input [7:0] rd_addr;
 output [7:0] rd_data;
 output [5:0] rx_fifo_level;
 input [3:0] scan_in;
 output [3:0] scan_out;
 output [5:0] tx_fifo_level;
 input [7:0] wr_addr;
 input [7:0] wr_data;

 wire _0000_;
 wire _0001_;
 wire _0002_;
 wire _0003_;
 wire _0004_;
 wire _0005_;
 wire _0006_;
 wire _0007_;
 wire _0008_;
 wire _0009_;
 wire _0010_;
 wire _0011_;
 wire _0012_;
 wire _0013_;
 wire _0014_;
 wire _0015_;
 wire _0016_;
 wire _0017_;
 wire _0018_;
 wire _0019_;
 wire _0020_;
 wire _0021_;
 wire _0022_;
 wire _0023_;
 wire _0024_;
 wire _0025_;
 wire _0026_;
 wire _0027_;
 wire _0028_;
 wire _0029_;
 wire _0030_;
 wire _0031_;
 wire _0032_;
 wire _0033_;
 wire _0034_;
 wire _0035_;
 wire _0036_;
 wire _0037_;
 wire _0038_;
 wire _0039_;
 wire _0040_;
 wire _0041_;
 wire _0042_;
 wire _0043_;
 wire _0044_;
 wire _0045_;
 wire _0046_;
 wire _0047_;
 wire _0048_;
 wire _0049_;
 wire _0050_;
 wire _0051_;
 wire _0052_;
 wire _0053_;
 wire _0054_;
 wire _0055_;
 wire _0056_;
 wire _0057_;
 wire _0058_;
 wire _0059_;
 wire _0060_;
 wire _0061_;
 wire _0062_;
 wire _0063_;
 wire _0064_;
 wire _0065_;
 wire _0066_;
 wire _0067_;
 wire _0068_;
 wire _0069_;
 wire _0070_;
 wire _0071_;
 wire _0072_;
 wire _0073_;
 wire _0074_;
 wire _0075_;
 wire _0076_;
 wire _0077_;
 wire _0078_;
 wire _0079_;
 wire _0080_;
 wire _0081_;
 wire _0082_;
 wire _0083_;
 wire _0084_;
 wire _0085_;
 wire _0086_;
 wire _0087_;
 wire _0088_;
 wire _0089_;
 wire _0090_;
 wire _0091_;
 wire _0092_;
 wire _0093_;
 wire _0094_;
 wire _0095_;
 wire _0096_;
 wire _0097_;
 wire _0098_;
 wire _0099_;
 wire _0100_;
 wire _0101_;
 wire _0102_;
 wire _0103_;
 wire _0104_;
 wire _0105_;
 wire _0106_;
 wire _0107_;
 wire _0108_;
 wire _0109_;
 wire _0110_;
 wire _0111_;
 wire _0112_;
 wire _0113_;
 wire _0114_;
 wire _0115_;
 wire _0116_;
 wire _0117_;
 wire _0118_;
 wire _0119_;
 wire _0120_;
 wire _0121_;
 wire _0122_;
 wire _0123_;
 wire _0124_;
 wire _0125_;
 wire _0126_;
 wire _0127_;
 wire _0128_;
 wire _0129_;
 wire _0130_;
 wire _0131_;
 wire _0132_;
 wire _0133_;
 wire _0134_;
 wire _0135_;
 wire _0136_;
 wire _0137_;
 wire _0138_;
 wire _0139_;
 wire _0140_;
 wire _0141_;
 wire _0142_;
 wire _0143_;
 wire _0144_;
 wire _0145_;
 wire _0146_;
 wire _0147_;
 wire _0148_;
 wire _0149_;
 wire _0150_;
 wire _0151_;
 wire _0152_;
 wire _0153_;
 wire _0154_;
 wire _0155_;
 wire _0156_;
 wire _0157_;
 wire _0158_;
 wire _0159_;
 wire _0160_;
 wire _0161_;
 wire _0162_;
 wire _0163_;
 wire _0164_;
 wire _0165_;
 wire _0166_;
 wire _0167_;
 wire _0168_;
 wire _0169_;
 wire _0170_;
 wire _0171_;
 wire _0172_;
 wire _0173_;
 wire _0174_;
 wire _0175_;
 wire _0176_;
 wire _0177_;
 wire _0178_;
 wire _0179_;
 wire _0180_;
 wire _0181_;
 wire _0182_;
 wire _0183_;
 wire _0184_;
 wire _0185_;
 wire _0186_;
 wire _0187_;
 wire _0188_;
 wire _0189_;
 wire _0190_;
 wire _0191_;
 wire _0192_;
 wire _0193_;
 wire _0194_;
 wire _0195_;
 wire _0196_;
 wire _0197_;
 wire _0198_;
 wire _0199_;
 wire _0200_;
 wire _0201_;
 wire _0202_;
 wire _0203_;
 wire _0204_;
 wire _0205_;
 wire _0206_;
 wire _0207_;
 wire _0208_;
 wire _0209_;
 wire _0210_;
 wire _0211_;
 wire _0212_;
 wire _0213_;
 wire _0214_;
 wire _0215_;
 wire _0216_;
 wire _0217_;
 wire _0218_;
 wire _0219_;
 wire _0220_;
 wire _0221_;
 wire _0222_;
 wire _0223_;
 wire _0224_;
 wire _0225_;
 wire _0226_;
 wire _0227_;
 wire _0228_;
 wire _0229_;
 wire _0230_;
 wire _0231_;
 wire _0232_;
 wire _0233_;
 wire _0234_;
 wire _0235_;
 wire _0236_;
 wire _0237_;
 wire _0238_;
 wire _0239_;
 wire _0240_;
 wire _0241_;
 wire _0242_;
 wire _0243_;
 wire _0244_;
 wire _0245_;
 wire _0246_;
 wire _0247_;
 wire _0248_;
 wire _0249_;
 wire _0250_;
 wire _0251_;
 wire _0252_;
 wire _0253_;
 wire _0254_;
 wire _0255_;
 wire _0256_;
 wire _0257_;
 wire _0258_;
 wire _0259_;
 wire _0260_;
 wire _0261_;
 wire _0262_;
 wire _0263_;
 wire _0264_;
 wire _0265_;
 wire _0266_;
 wire _0267_;
 wire _0268_;
 wire _0269_;
 wire _0270_;
 wire _0271_;
 wire _0272_;
 wire _0273_;
 wire _0274_;
 wire _0275_;
 wire _0276_;
 wire _0277_;
 wire _0278_;
 wire _0279_;
 wire _0280_;
 wire _0281_;
 wire _0282_;
 wire _0283_;
 wire _0284_;
 wire _0285_;
 wire _0286_;
 wire _0287_;
 wire _0288_;
 wire _0289_;
 wire _0290_;
 wire _0291_;
 wire _0292_;
 wire _0293_;
 wire _0294_;
 wire _0295_;
 wire _0296_;
 wire _0297_;
 wire _0298_;
 wire _0299_;
 wire _0300_;
 wire _0301_;
 wire _0302_;
 wire _0303_;
 wire _0304_;
 wire _0305_;
 wire _0306_;
 wire _0307_;
 wire _0308_;
 wire _0309_;
 wire _0310_;
 wire _0311_;
 wire _0312_;
 wire _0313_;
 wire _0314_;
 wire _0315_;
 wire _0316_;
 wire _0317_;
 wire _0318_;
 wire _0319_;
 wire _0320_;
 wire _0321_;
 wire _0322_;
 wire _0323_;
 wire _0324_;
 wire _0325_;
 wire _0326_;
 wire _0327_;
 wire _0328_;
 wire _0329_;
 wire _0330_;
 wire _0331_;
 wire _0332_;
 wire _0333_;
 wire _0334_;
 wire _0335_;
 wire _0336_;
 wire _0337_;
 wire _0338_;
 wire _0339_;
 wire _0340_;
 wire _0341_;
 wire _0342_;
 wire _0343_;
 wire _0344_;
 wire _0345_;
 wire _0346_;
 wire _0347_;
 wire _0348_;
 wire _0349_;
 wire _0350_;
 wire _0351_;
 wire _0352_;
 wire _0353_;
 wire _0354_;
 wire _0355_;
 wire _0356_;
 wire _0357_;
 wire _0358_;
 wire _0359_;
 wire _0360_;
 wire _0361_;
 wire _0362_;
 wire _0363_;
 wire _0364_;
 wire _0365_;
 wire _0366_;
 wire _0367_;
 wire _0368_;
 wire _0369_;
 wire _0370_;
 wire _0371_;
 wire _0372_;
 wire _0373_;
 wire _0374_;
 wire _0375_;
 wire _0376_;
 wire _0377_;
 wire _0378_;
 wire _0379_;
 wire _0380_;
 wire _0381_;
 wire _0382_;
 wire _0383_;
 wire _0384_;
 wire _0385_;
 wire _0386_;
 wire _0387_;
 wire _0388_;
 wire _0389_;
 wire _0390_;
 wire _0391_;
 wire _0392_;
 wire _0393_;
 wire _0394_;
 wire _0395_;
 wire _0396_;
 wire _0397_;
 wire _0398_;
 wire _0399_;
 wire _0400_;
 wire _0401_;
 wire _0402_;
 wire _0403_;
 wire _0404_;
 wire _0405_;
 wire _0406_;
 wire _0407_;
 wire _0408_;
 wire _0409_;
 wire _0410_;
 wire _0411_;
 wire _0412_;
 wire _0413_;
 wire _0414_;
 wire _0415_;
 wire _0416_;
 wire _0417_;
 wire _0418_;
 wire _0419_;
 wire _0420_;
 wire _0421_;
 wire _0422_;
 wire _0423_;
 wire _0424_;
 wire _0425_;
 wire _0426_;
 wire _0427_;
 wire _0428_;
 wire _0429_;
 wire _0430_;
 wire _0431_;
 wire _0432_;
 wire _0433_;
 wire _0434_;
 wire _0435_;
 wire _0436_;
 wire _0437_;
 wire _0438_;
 wire _0439_;
 wire _0440_;
 wire _0441_;
 wire _0442_;
 wire _0443_;
 wire _0444_;
 wire _0445_;
 wire _0446_;
 wire _0447_;
 wire _0448_;
 wire _0449_;
 wire _0450_;
 wire _0451_;
 wire _0452_;
 wire _0453_;
 wire _0454_;
 wire _0455_;
 wire _0456_;
 wire _0457_;
 wire _0458_;
 wire _0459_;
 wire _0460_;
 wire _0461_;
 wire _0462_;
 wire _0463_;
 wire _0464_;
 wire _0465_;
 wire _0466_;
 wire _0467_;
 wire _0468_;
 wire _0469_;
 wire _0470_;
 wire _0471_;
 wire _0472_;
 wire _0473_;
 wire _0474_;
 wire _0475_;
 wire _0476_;
 wire _0477_;
 wire _0478_;
 wire _0479_;
 wire _0480_;
 wire _0481_;
 wire _0482_;
 wire _0483_;
 wire _0484_;
 wire _0485_;
 wire _0486_;
 wire _0487_;
 wire _0488_;
 wire _0489_;
 wire _0490_;
 wire _0491_;
 wire _0492_;
 wire _0493_;
 wire _0494_;
 wire _0495_;
 wire _0496_;
 wire _0497_;
 wire _0498_;
 wire _0499_;
 wire _0500_;
 wire _0501_;
 wire _0502_;
 wire _0503_;
 wire _0504_;
 wire _0505_;
 wire _0506_;
 wire _0507_;
 wire _0508_;
 wire _0509_;
 wire _0510_;
 wire _0511_;
 wire _0512_;
 wire _0513_;
 wire _0514_;
 wire _0515_;
 wire _0516_;
 wire _0517_;
 wire _0518_;
 wire _0519_;
 wire _0520_;
 wire _0521_;
 wire _0522_;
 wire _0523_;
 wire _0524_;
 wire _0525_;
 wire _0526_;
 wire _0527_;
 wire _0528_;
 wire _0529_;
 wire _0530_;
 wire _0531_;
 wire _0532_;
 wire _0533_;
 wire _0534_;
 wire _0535_;
 wire _0536_;
 wire _0537_;
 wire _0538_;
 wire _0539_;
 wire _0540_;
 wire _0541_;
 wire _0542_;
 wire _0543_;
 wire _0544_;
 wire _0545_;
 wire _0546_;
 wire _0547_;
 wire _0548_;
 wire _0549_;
 wire _0550_;
 wire _0551_;
 wire _0552_;
 wire _0553_;
 wire _0554_;
 wire _0555_;
 wire _0556_;
 wire _0557_;
 wire _0558_;
 wire _0559_;
 wire _0560_;
 wire _0561_;
 wire _0562_;
 wire _0563_;
 wire _0564_;
 wire _0565_;
 wire _0566_;
 wire _0567_;
 wire _0568_;
 wire _0569_;
 wire _0570_;
 wire _0571_;
 wire _0572_;
 wire _0573_;
 wire _0574_;
 wire _0575_;
 wire _0576_;
 wire _0577_;
 wire _0578_;
 wire _0579_;
 wire _0580_;
 wire _0581_;
 wire _0582_;
 wire _0583_;
 wire _0584_;
 wire _0585_;
 wire _0586_;
 wire _0587_;
 wire _0588_;
 wire _0589_;
 wire _0590_;
 wire _0591_;
 wire _0592_;
 wire _0593_;
 wire _0594_;
 wire _0595_;
 wire _0596_;
 wire _0597_;
 wire _0598_;
 wire _0599_;
 wire _0600_;
 wire _0601_;
 wire _0602_;
 wire _0603_;
 wire _0604_;
 wire _0605_;
 wire _0606_;
 wire _0607_;
 wire _0608_;
 wire _0609_;
 wire _0610_;
 wire _0611_;
 wire _0612_;
 wire _0613_;
 wire _0614_;
 wire _0615_;
 wire _0616_;
 wire _0617_;
 wire _0618_;
 wire _0619_;
 wire _0620_;
 wire _0621_;
 wire _0622_;
 wire _0623_;
 wire _0624_;
 wire _0625_;
 wire _0626_;
 wire _0627_;
 wire _0628_;
 wire _0629_;
 wire _0630_;
 wire _0631_;
 wire _0632_;
 wire _0633_;
 wire _0634_;
 wire _0635_;
 wire _0636_;
 wire _0637_;
 wire _0638_;
 wire _0639_;
 wire _0640_;
 wire _0641_;
 wire _0642_;
 wire _0643_;
 wire _0644_;
 wire _0645_;
 wire _0646_;
 wire _0647_;
 wire _0648_;
 wire _0649_;
 wire _0650_;
 wire _0651_;
 wire _0652_;
 wire _0653_;
 wire _0654_;
 wire _0655_;
 wire _0656_;
 wire _0657_;
 wire _0658_;
 wire _0659_;
 wire _0660_;
 wire _0661_;
 wire _0662_;
 wire _0663_;
 wire _0664_;
 wire _0665_;
 wire _0666_;
 wire _0667_;
 wire _0668_;
 wire _0669_;
 wire _0670_;
 wire _0671_;
 wire _0672_;
 wire _0673_;
 wire _0674_;
 wire _0675_;
 wire _0676_;
 wire _0677_;
 wire _0678_;
 wire _0679_;
 wire _0680_;
 wire _0681_;
 wire _0682_;
 wire _0683_;
 wire _0684_;
 wire _0685_;
 wire _0686_;
 wire _0687_;
 wire _0688_;
 wire _0689_;
 wire _0690_;
 wire _0691_;
 wire _0692_;
 wire _0693_;
 wire _0694_;
 wire _0695_;
 wire _0696_;
 wire _0697_;
 wire _0698_;
 wire _0699_;
 wire _0700_;
 wire \baud_div[0] ;
 wire \baud_div[10] ;
 wire \baud_div[11] ;
 wire \baud_div[12] ;
 wire \baud_div[13] ;
 wire \baud_div[14] ;
 wire \baud_div[15] ;
 wire \baud_div[1] ;
 wire \baud_div[2] ;
 wire \baud_div[3] ;
 wire \baud_div[4] ;
 wire \baud_div[5] ;
 wire \baud_div[6] ;
 wire \baud_div[7] ;
 wire \baud_div[8] ;
 wire \baud_div[9] ;
 wire baud_tick;
 wire control_enable;
 wire control_irq_enable;
 wire control_loopback;
 wire control_rx_enable;
 wire control_tx_enable;
 wire framing_error_event;
 wire \irq_clear[0] ;
 wire \irq_clear[1] ;
 wire \irq_clear[2] ;
 wire \irq_clear[3] ;
 wire \irq_clear[4] ;
 wire \irq_clear[5] ;
 wire \irq_status[0] ;
 wire \irq_status[1] ;
 wire \irq_status[2] ;
 wire \irq_status[3] ;
 wire \irq_status[4] ;
 wire \irq_status[5] ;
 wire loopback_byte_valid;
 wire packet_done_event;
 wire \packet_len[0] ;
 wire \packet_len[1] ;
 wire \packet_len[2] ;
 wire \packet_len[3] ;
 wire \packet_len[4] ;
 wire \packet_len[5] ;
 wire \packet_len[6] ;
 wire \packet_len[7] ;
 wire rx_data_pop;
 wire rx_overflow_event;
 wire status_rx_busy;
 wire status_tx_busy;
 wire \tx_data_byte[0] ;
 wire \tx_data_byte[1] ;
 wire \tx_data_byte[2] ;
 wire \tx_data_byte[3] ;
 wire \tx_data_byte[4] ;
 wire \tx_data_byte[5] ;
 wire \tx_data_byte[6] ;
 wire tx_data_push;
 wire tx_done_event;
 wire tx_underflow_event;
 wire \u_uart_baud_tick_gen.baud_cnt[0] ;
 wire \u_uart_baud_tick_gen.baud_cnt[10] ;
 wire \u_uart_baud_tick_gen.baud_cnt[11] ;
 wire \u_uart_baud_tick_gen.baud_cnt[12] ;
 wire \u_uart_baud_tick_gen.baud_cnt[13] ;
 wire \u_uart_baud_tick_gen.baud_cnt[14] ;
 wire \u_uart_baud_tick_gen.baud_cnt[15] ;
 wire \u_uart_baud_tick_gen.baud_cnt[1] ;
 wire \u_uart_baud_tick_gen.baud_cnt[2] ;
 wire \u_uart_baud_tick_gen.baud_cnt[3] ;
 wire \u_uart_baud_tick_gen.baud_cnt[4] ;
 wire \u_uart_baud_tick_gen.baud_cnt[5] ;
 wire \u_uart_baud_tick_gen.baud_cnt[6] ;
 wire \u_uart_baud_tick_gen.baud_cnt[7] ;
 wire \u_uart_baud_tick_gen.baud_cnt[8] ;
 wire \u_uart_baud_tick_gen.baud_cnt[9] ;
 wire \u_uart_rx_engine.rx_bit_index[0] ;
 wire \u_uart_rx_engine.rx_bit_index[1] ;
 wire \u_uart_rx_engine.rx_bit_index[2] ;
 wire \u_uart_rx_engine.rx_count[0] ;
 wire \u_uart_rx_engine.rx_count[1] ;
 wire \u_uart_rx_engine.rx_count[2] ;
 wire \u_uart_rx_engine.rx_count[3] ;
 wire \u_uart_rx_engine.rx_count[4] ;
 wire \u_uart_rx_engine.rx_packet_count[0] ;
 wire \u_uart_rx_engine.rx_packet_count[1] ;
 wire \u_uart_rx_engine.rx_packet_count[2] ;
 wire \u_uart_rx_engine.rx_packet_count[3] ;
 wire \u_uart_rx_engine.rx_packet_count[4] ;
 wire \u_uart_rx_engine.rx_packet_count[5] ;
 wire \u_uart_rx_engine.rx_packet_count[6] ;
 wire \u_uart_rx_engine.rx_packet_count[7] ;
 wire \u_uart_rx_engine.rx_state[0] ;
 wire \u_uart_rx_engine.rx_state[1] ;
 wire \u_uart_rx_engine.rx_state[2] ;
 wire \u_uart_rx_engine.rx_state[3] ;
 wire \u_uart_tx_engine.tx_bit_index[0] ;
 wire \u_uart_tx_engine.tx_bit_index[1] ;
 wire \u_uart_tx_engine.tx_bit_index[2] ;
 wire \u_uart_tx_engine.tx_count[0] ;
 wire \u_uart_tx_engine.tx_count[1] ;
 wire \u_uart_tx_engine.tx_count[2] ;
 wire \u_uart_tx_engine.tx_count[3] ;
 wire \u_uart_tx_engine.tx_count[4] ;
 wire \u_uart_tx_engine.tx_fifo_mem[0][0] ;
 wire \u_uart_tx_engine.tx_fifo_mem[0][1] ;
 wire \u_uart_tx_engine.tx_fifo_mem[0][2] ;
 wire \u_uart_tx_engine.tx_fifo_mem[0][3] ;
 wire \u_uart_tx_engine.tx_fifo_mem[0][4] ;
 wire \u_uart_tx_engine.tx_fifo_mem[0][5] ;
 wire \u_uart_tx_engine.tx_fifo_mem[0][6] ;
 wire \u_uart_tx_engine.tx_fifo_mem[10][0] ;
 wire \u_uart_tx_engine.tx_fifo_mem[10][1] ;
 wire \u_uart_tx_engine.tx_fifo_mem[10][2] ;
 wire \u_uart_tx_engine.tx_fifo_mem[10][3] ;
 wire \u_uart_tx_engine.tx_fifo_mem[10][4] ;
 wire \u_uart_tx_engine.tx_fifo_mem[10][5] ;
 wire \u_uart_tx_engine.tx_fifo_mem[10][6] ;
 wire \u_uart_tx_engine.tx_fifo_mem[11][0] ;
 wire \u_uart_tx_engine.tx_fifo_mem[11][1] ;
 wire \u_uart_tx_engine.tx_fifo_mem[11][2] ;
 wire \u_uart_tx_engine.tx_fifo_mem[11][3] ;
 wire \u_uart_tx_engine.tx_fifo_mem[11][4] ;
 wire \u_uart_tx_engine.tx_fifo_mem[11][5] ;
 wire \u_uart_tx_engine.tx_fifo_mem[11][6] ;
 wire \u_uart_tx_engine.tx_fifo_mem[12][0] ;
 wire \u_uart_tx_engine.tx_fifo_mem[12][1] ;
 wire \u_uart_tx_engine.tx_fifo_mem[12][2] ;
 wire \u_uart_tx_engine.tx_fifo_mem[12][3] ;
 wire \u_uart_tx_engine.tx_fifo_mem[12][4] ;
 wire \u_uart_tx_engine.tx_fifo_mem[12][5] ;
 wire \u_uart_tx_engine.tx_fifo_mem[12][6] ;
 wire \u_uart_tx_engine.tx_fifo_mem[13][0] ;
 wire \u_uart_tx_engine.tx_fifo_mem[13][1] ;
 wire \u_uart_tx_engine.tx_fifo_mem[13][2] ;
 wire \u_uart_tx_engine.tx_fifo_mem[13][3] ;
 wire \u_uart_tx_engine.tx_fifo_mem[13][4] ;
 wire \u_uart_tx_engine.tx_fifo_mem[13][5] ;
 wire \u_uart_tx_engine.tx_fifo_mem[13][6] ;
 wire \u_uart_tx_engine.tx_fifo_mem[14][0] ;
 wire \u_uart_tx_engine.tx_fifo_mem[14][1] ;
 wire \u_uart_tx_engine.tx_fifo_mem[14][2] ;
 wire \u_uart_tx_engine.tx_fifo_mem[14][3] ;
 wire \u_uart_tx_engine.tx_fifo_mem[14][4] ;
 wire \u_uart_tx_engine.tx_fifo_mem[14][5] ;
 wire \u_uart_tx_engine.tx_fifo_mem[14][6] ;
 wire \u_uart_tx_engine.tx_fifo_mem[15][0] ;
 wire \u_uart_tx_engine.tx_fifo_mem[15][1] ;
 wire \u_uart_tx_engine.tx_fifo_mem[15][2] ;
 wire \u_uart_tx_engine.tx_fifo_mem[15][3] ;
 wire \u_uart_tx_engine.tx_fifo_mem[15][4] ;
 wire \u_uart_tx_engine.tx_fifo_mem[15][5] ;
 wire \u_uart_tx_engine.tx_fifo_mem[15][6] ;
 wire \u_uart_tx_engine.tx_fifo_mem[1][0] ;
 wire \u_uart_tx_engine.tx_fifo_mem[1][1] ;
 wire \u_uart_tx_engine.tx_fifo_mem[1][2] ;
 wire \u_uart_tx_engine.tx_fifo_mem[1][3] ;
 wire \u_uart_tx_engine.tx_fifo_mem[1][4] ;
 wire \u_uart_tx_engine.tx_fifo_mem[1][5] ;
 wire \u_uart_tx_engine.tx_fifo_mem[1][6] ;
 wire \u_uart_tx_engine.tx_fifo_mem[2][0] ;
 wire \u_uart_tx_engine.tx_fifo_mem[2][1] ;
 wire \u_uart_tx_engine.tx_fifo_mem[2][2] ;
 wire \u_uart_tx_engine.tx_fifo_mem[2][3] ;
 wire \u_uart_tx_engine.tx_fifo_mem[2][4] ;
 wire \u_uart_tx_engine.tx_fifo_mem[2][5] ;
 wire \u_uart_tx_engine.tx_fifo_mem[2][6] ;
 wire \u_uart_tx_engine.tx_fifo_mem[3][0] ;
 wire \u_uart_tx_engine.tx_fifo_mem[3][1] ;
 wire \u_uart_tx_engine.tx_fifo_mem[3][2] ;
 wire \u_uart_tx_engine.tx_fifo_mem[3][3] ;
 wire \u_uart_tx_engine.tx_fifo_mem[3][4] ;
 wire \u_uart_tx_engine.tx_fifo_mem[3][5] ;
 wire \u_uart_tx_engine.tx_fifo_mem[3][6] ;
 wire \u_uart_tx_engine.tx_fifo_mem[4][0] ;
 wire \u_uart_tx_engine.tx_fifo_mem[4][1] ;
 wire \u_uart_tx_engine.tx_fifo_mem[4][2] ;
 wire \u_uart_tx_engine.tx_fifo_mem[4][3] ;
 wire \u_uart_tx_engine.tx_fifo_mem[4][4] ;
 wire \u_uart_tx_engine.tx_fifo_mem[4][5] ;
 wire \u_uart_tx_engine.tx_fifo_mem[4][6] ;
 wire \u_uart_tx_engine.tx_fifo_mem[5][0] ;
 wire \u_uart_tx_engine.tx_fifo_mem[5][1] ;
 wire \u_uart_tx_engine.tx_fifo_mem[5][2] ;
 wire \u_uart_tx_engine.tx_fifo_mem[5][3] ;
 wire \u_uart_tx_engine.tx_fifo_mem[5][4] ;
 wire \u_uart_tx_engine.tx_fifo_mem[5][5] ;
 wire \u_uart_tx_engine.tx_fifo_mem[5][6] ;
 wire \u_uart_tx_engine.tx_fifo_mem[6][0] ;
 wire \u_uart_tx_engine.tx_fifo_mem[6][1] ;
 wire \u_uart_tx_engine.tx_fifo_mem[6][2] ;
 wire \u_uart_tx_engine.tx_fifo_mem[6][3] ;
 wire \u_uart_tx_engine.tx_fifo_mem[6][4] ;
 wire \u_uart_tx_engine.tx_fifo_mem[6][5] ;
 wire \u_uart_tx_engine.tx_fifo_mem[6][6] ;
 wire \u_uart_tx_engine.tx_fifo_mem[7][0] ;
 wire \u_uart_tx_engine.tx_fifo_mem[7][1] ;
 wire \u_uart_tx_engine.tx_fifo_mem[7][2] ;
 wire \u_uart_tx_engine.tx_fifo_mem[7][3] ;
 wire \u_uart_tx_engine.tx_fifo_mem[7][4] ;
 wire \u_uart_tx_engine.tx_fifo_mem[7][5] ;
 wire \u_uart_tx_engine.tx_fifo_mem[7][6] ;
 wire \u_uart_tx_engine.tx_fifo_mem[8][0] ;
 wire \u_uart_tx_engine.tx_fifo_mem[8][1] ;
 wire \u_uart_tx_engine.tx_fifo_mem[8][2] ;
 wire \u_uart_tx_engine.tx_fifo_mem[8][3] ;
 wire \u_uart_tx_engine.tx_fifo_mem[8][4] ;
 wire \u_uart_tx_engine.tx_fifo_mem[8][5] ;
 wire \u_uart_tx_engine.tx_fifo_mem[8][6] ;
 wire \u_uart_tx_engine.tx_fifo_mem[9][0] ;
 wire \u_uart_tx_engine.tx_fifo_mem[9][1] ;
 wire \u_uart_tx_engine.tx_fifo_mem[9][2] ;
 wire \u_uart_tx_engine.tx_fifo_mem[9][3] ;
 wire \u_uart_tx_engine.tx_fifo_mem[9][4] ;
 wire \u_uart_tx_engine.tx_fifo_mem[9][5] ;
 wire \u_uart_tx_engine.tx_fifo_mem[9][6] ;
 wire \u_uart_tx_engine.tx_packet_count[0] ;
 wire \u_uart_tx_engine.tx_packet_count[1] ;
 wire \u_uart_tx_engine.tx_packet_count[2] ;
 wire \u_uart_tx_engine.tx_packet_count[3] ;
 wire \u_uart_tx_engine.tx_packet_count[4] ;
 wire \u_uart_tx_engine.tx_packet_count[5] ;
 wire \u_uart_tx_engine.tx_packet_count[6] ;
 wire \u_uart_tx_engine.tx_packet_count[7] ;
 wire \u_uart_tx_engine.tx_rd_ptr[0] ;
 wire \u_uart_tx_engine.tx_rd_ptr[1] ;
 wire \u_uart_tx_engine.tx_rd_ptr[2] ;
 wire \u_uart_tx_engine.tx_rd_ptr[3] ;
 wire \u_uart_tx_engine.tx_shift_reg[0] ;
 wire \u_uart_tx_engine.tx_shift_reg[1] ;
 wire \u_uart_tx_engine.tx_shift_reg[2] ;
 wire \u_uart_tx_engine.tx_shift_reg[3] ;
 wire \u_uart_tx_engine.tx_shift_reg[4] ;
 wire \u_uart_tx_engine.tx_shift_reg[5] ;
 wire \u_uart_tx_engine.tx_shift_reg[6] ;
 wire \u_uart_tx_engine.tx_wr_ptr[0] ;
 wire \u_uart_tx_engine.tx_wr_ptr[1] ;
 wire \u_uart_tx_engine.tx_wr_ptr[2] ;
 wire \u_uart_tx_engine.tx_wr_ptr[3] ;

 sky130_fd_sc_hd__inv_2 _0701_ (.A(control_enable),
    .Y(_0399_));
 sky130_fd_sc_hd__inv_2 _0702_ (.A(\u_uart_tx_engine.tx_count[4] ),
    .Y(_0400_));
 sky130_fd_sc_hd__inv_2 _0703_ (.A(tx_data_push),
    .Y(_0401_));
 sky130_fd_sc_hd__inv_2 _0704_ (.A(status_tx_busy),
    .Y(_0402_));
 sky130_fd_sc_hd__inv_2 _0705_ (.A(\packet_len[6] ),
    .Y(_0403_));
 sky130_fd_sc_hd__inv_2 _0706_ (.A(\u_uart_rx_engine.rx_count[4] ),
    .Y(_0404_));
 sky130_fd_sc_hd__inv_2 _0707_ (.A(\baud_div[15] ),
    .Y(_0405_));
 sky130_fd_sc_hd__inv_2 _0708_ (.A(\baud_div[14] ),
    .Y(_0406_));
 sky130_fd_sc_hd__inv_2 _0709_ (.A(\baud_div[13] ),
    .Y(_0407_));
 sky130_fd_sc_hd__inv_2 _0710_ (.A(\baud_div[12] ),
    .Y(_0408_));
 sky130_fd_sc_hd__inv_2 _0711_ (.A(\baud_div[11] ),
    .Y(_0409_));
 sky130_fd_sc_hd__inv_2 _0712_ (.A(\baud_div[10] ),
    .Y(_0410_));
 sky130_fd_sc_hd__inv_2 _0713_ (.A(\baud_div[9] ),
    .Y(_0411_));
 sky130_fd_sc_hd__inv_2 _0714_ (.A(\u_uart_baud_tick_gen.baud_cnt[8] ),
    .Y(_0412_));
 sky130_fd_sc_hd__inv_2 _0715_ (.A(\u_uart_baud_tick_gen.baud_cnt[7] ),
    .Y(_0413_));
 sky130_fd_sc_hd__inv_2 _0716_ (.A(\u_uart_baud_tick_gen.baud_cnt[6] ),
    .Y(_0414_));
 sky130_fd_sc_hd__inv_2 _0717_ (.A(\u_uart_baud_tick_gen.baud_cnt[4] ),
    .Y(_0415_));
 sky130_fd_sc_hd__inv_2 _0718_ (.A(\u_uart_baud_tick_gen.baud_cnt[3] ),
    .Y(_0416_));
 sky130_fd_sc_hd__inv_2 _0719_ (.A(\u_uart_baud_tick_gen.baud_cnt[0] ),
    .Y(_0417_));
 sky130_fd_sc_hd__inv_2 _0720_ (.A(rd_en),
    .Y(_0418_));
 sky130_fd_sc_hd__and2b_2 _0721_ (.A_N(loopback_byte_valid),
    .B(baud_tick),
    .X(_0419_));
 sky130_fd_sc_hd__and2_2 _0722_ (.A(control_rx_enable),
    .B(control_enable),
    .X(_0420_));
 sky130_fd_sc_hd__nand2_2 _0723_ (.A(control_rx_enable),
    .B(control_enable),
    .Y(_0421_));
 sky130_fd_sc_hd__nor2_2 _0724_ (.A(_0419_),
    .B(_0421_),
    .Y(_0422_));
 sky130_fd_sc_hd__or2_2 _0725_ (.A(_0419_),
    .B(_0421_),
    .X(_0423_));
 sky130_fd_sc_hd__and2_2 _0726_ (.A(_0419_),
    .B(_0420_),
    .X(_0424_));
 sky130_fd_sc_hd__nand2_2 _0727_ (.A(_0419_),
    .B(_0420_),
    .Y(_0425_));
 sky130_fd_sc_hd__nand2_2 _0728_ (.A(uart_rx),
    .B(\u_uart_rx_engine.rx_state[2] ),
    .Y(_0426_));
 sky130_fd_sc_hd__o21a_2 _0729_ (.A1(\u_uart_rx_engine.rx_state[0] ),
    .A2(\u_uart_rx_engine.rx_state[2] ),
    .B1(uart_rx),
    .X(_0427_));
 sky130_fd_sc_hd__o32a_2 _0730_ (.A1(\u_uart_rx_engine.rx_state[3] ),
    .A2(_0425_),
    .A3(_0427_),
    .B1(_0423_),
    .B2(\u_uart_rx_engine.rx_state[0] ),
    .X(_0000_));
 sky130_fd_sc_hd__nor2_2 _0731_ (.A(uart_rx),
    .B(_0425_),
    .Y(_0428_));
 sky130_fd_sc_hd__nand2_2 _0732_ (.A(\u_uart_rx_engine.rx_state[2] ),
    .B(_0428_),
    .Y(_0429_));
 sky130_fd_sc_hd__nand2_2 _0733_ (.A(\u_uart_rx_engine.rx_bit_index[1] ),
    .B(\u_uart_rx_engine.rx_bit_index[0] ),
    .Y(_0430_));
 sky130_fd_sc_hd__and4_2 _0734_ (.A(\u_uart_rx_engine.rx_bit_index[2] ),
    .B(\u_uart_rx_engine.rx_bit_index[1] ),
    .C(\u_uart_rx_engine.rx_bit_index[0] ),
    .D(_0419_),
    .X(_0431_));
 sky130_fd_sc_hd__nand2_2 _0735_ (.A(\u_uart_rx_engine.rx_state[1] ),
    .B(_0420_),
    .Y(_0432_));
 sky130_fd_sc_hd__o21ai_2 _0736_ (.A1(_0431_),
    .A2(_0432_),
    .B1(_0429_),
    .Y(_0001_));
 sky130_fd_sc_hd__and2_2 _0737_ (.A(\u_uart_rx_engine.rx_state[0] ),
    .B(_0428_),
    .X(_0433_));
 sky130_fd_sc_hd__a21o_2 _0738_ (.A1(\u_uart_rx_engine.rx_state[2] ),
    .A2(_0422_),
    .B1(_0433_),
    .X(_0002_));
 sky130_fd_sc_hd__or4b_2 _0739_ (.A(wr_addr[5]),
    .B(wr_addr[7]),
    .C(wr_addr[6]),
    .D_N(wr_en),
    .X(_0434_));
 sky130_fd_sc_hd__nor3_2 _0740_ (.A(wr_addr[1]),
    .B(wr_addr[0]),
    .C(_0434_),
    .Y(_0435_));
 sky130_fd_sc_hd__or4_2 _0741_ (.A(wr_addr[1]),
    .B(wr_addr[0]),
    .C(wr_addr[4]),
    .D(_0434_),
    .X(_0436_));
 sky130_fd_sc_hd__nand2_2 _0742_ (.A(wr_addr[2]),
    .B(wr_addr[3]),
    .Y(_0437_));
 sky130_fd_sc_hd__or2_2 _0743_ (.A(_0436_),
    .B(_0437_),
    .X(_0438_));
 sky130_fd_sc_hd__inv_2 _0744_ (.A(_0438_),
    .Y(_0004_));
 sky130_fd_sc_hd__a32o_2 _0745_ (.A1(\u_uart_rx_engine.rx_state[1] ),
    .A2(_0420_),
    .A3(_0431_),
    .B1(_0422_),
    .B2(\u_uart_rx_engine.rx_state[3] ),
    .X(_0003_));
 sky130_fd_sc_hd__or4_2 _0746_ (.A(\u_uart_tx_engine.tx_count[1] ),
    .B(\u_uart_tx_engine.tx_count[0] ),
    .C(\u_uart_tx_engine.tx_count[3] ),
    .D(\u_uart_tx_engine.tx_count[2] ),
    .X(_0439_));
 sky130_fd_sc_hd__inv_2 _0747_ (.A(_0439_),
    .Y(_0440_));
 sky130_fd_sc_hd__or2_2 _0748_ (.A(_0400_),
    .B(_0439_),
    .X(_0441_));
 sky130_fd_sc_hd__nor2_2 _0749_ (.A(_0401_),
    .B(_0441_),
    .Y(_0052_));
 sky130_fd_sc_hd__nand2b_2 _0750_ (.A_N(\baud_div[5] ),
    .B(\u_uart_baud_tick_gen.baud_cnt[5] ),
    .Y(_0442_));
 sky130_fd_sc_hd__o22a_2 _0751_ (.A1(_0415_),
    .A2(\baud_div[4] ),
    .B1(_0416_),
    .B2(\baud_div[3] ),
    .X(_0443_));
 sky130_fd_sc_hd__nand2b_2 _0752_ (.A_N(\baud_div[2] ),
    .B(\u_uart_baud_tick_gen.baud_cnt[2] ),
    .Y(_0444_));
 sky130_fd_sc_hd__and2b_2 _0753_ (.A_N(\u_uart_baud_tick_gen.baud_cnt[1] ),
    .B(\baud_div[1] ),
    .X(_0445_));
 sky130_fd_sc_hd__nand2b_2 _0754_ (.A_N(\baud_div[1] ),
    .B(\u_uart_baud_tick_gen.baud_cnt[1] ),
    .Y(_0446_));
 sky130_fd_sc_hd__and2b_2 _0755_ (.A_N(\u_uart_baud_tick_gen.baud_cnt[2] ),
    .B(\baud_div[2] ),
    .X(_0447_));
 sky130_fd_sc_hd__a311o_2 _0756_ (.A1(\baud_div[0] ),
    .A2(_0417_),
    .A3(_0446_),
    .B1(_0447_),
    .C1(_0445_),
    .X(_0448_));
 sky130_fd_sc_hd__a22o_2 _0757_ (.A1(_0416_),
    .A2(\baud_div[3] ),
    .B1(_0444_),
    .B2(_0448_),
    .X(_0449_));
 sky130_fd_sc_hd__a22o_2 _0758_ (.A1(_0415_),
    .A2(\baud_div[4] ),
    .B1(_0443_),
    .B2(_0449_),
    .X(_0450_));
 sky130_fd_sc_hd__and2b_2 _0759_ (.A_N(\u_uart_baud_tick_gen.baud_cnt[5] ),
    .B(\baud_div[5] ),
    .X(_0451_));
 sky130_fd_sc_hd__a221o_2 _0760_ (.A1(_0414_),
    .A2(\baud_div[6] ),
    .B1(_0442_),
    .B2(_0450_),
    .C1(_0451_),
    .X(_0452_));
 sky130_fd_sc_hd__o221a_2 _0761_ (.A1(_0413_),
    .A2(\baud_div[7] ),
    .B1(_0414_),
    .B2(\baud_div[6] ),
    .C1(_0452_),
    .X(_0453_));
 sky130_fd_sc_hd__or2_2 _0762_ (.A(\u_uart_baud_tick_gen.baud_cnt[11] ),
    .B(_0409_),
    .X(_0454_));
 sky130_fd_sc_hd__a22o_2 _0763_ (.A1(_0412_),
    .A2(\baud_div[8] ),
    .B1(_0413_),
    .B2(\baud_div[7] ),
    .X(_0455_));
 sky130_fd_sc_hd__a22o_2 _0764_ (.A1(\u_uart_baud_tick_gen.baud_cnt[11] ),
    .A2(_0409_),
    .B1(\u_uart_baud_tick_gen.baud_cnt[10] ),
    .B2(_0410_),
    .X(_0456_));
 sky130_fd_sc_hd__o22a_2 _0765_ (.A1(\u_uart_baud_tick_gen.baud_cnt[10] ),
    .A2(_0410_),
    .B1(\u_uart_baud_tick_gen.baud_cnt[9] ),
    .B2(_0411_),
    .X(_0457_));
 sky130_fd_sc_hd__a2bb2o_2 _0766_ (.A1_N(\baud_div[8] ),
    .A2_N(_0412_),
    .B1(_0411_),
    .B2(\u_uart_baud_tick_gen.baud_cnt[9] ),
    .X(_0458_));
 sky130_fd_sc_hd__nand2_2 _0767_ (.A(_0454_),
    .B(_0457_),
    .Y(_0459_));
 sky130_fd_sc_hd__or4_2 _0768_ (.A(_0455_),
    .B(_0456_),
    .C(_0458_),
    .D(_0459_),
    .X(_0460_));
 sky130_fd_sc_hd__a21o_2 _0769_ (.A1(_0457_),
    .A2(_0458_),
    .B1(_0456_),
    .X(_0461_));
 sky130_fd_sc_hd__a2bb2o_2 _0770_ (.A1_N(_0453_),
    .A2_N(_0460_),
    .B1(_0461_),
    .B2(_0454_),
    .X(_0462_));
 sky130_fd_sc_hd__a22o_2 _0771_ (.A1(\u_uart_baud_tick_gen.baud_cnt[15] ),
    .A2(_0405_),
    .B1(\u_uart_baud_tick_gen.baud_cnt[14] ),
    .B2(_0406_),
    .X(_0463_));
 sky130_fd_sc_hd__inv_2 _0772_ (.A(_0463_),
    .Y(_0464_));
 sky130_fd_sc_hd__or2_2 _0773_ (.A(\u_uart_baud_tick_gen.baud_cnt[15] ),
    .B(_0405_),
    .X(_0465_));
 sky130_fd_sc_hd__o211a_2 _0774_ (.A1(\u_uart_baud_tick_gen.baud_cnt[14] ),
    .A2(_0406_),
    .B1(_0464_),
    .C1(_0465_),
    .X(_0466_));
 sky130_fd_sc_hd__a22o_2 _0775_ (.A1(\u_uart_baud_tick_gen.baud_cnt[13] ),
    .A2(_0407_),
    .B1(\u_uart_baud_tick_gen.baud_cnt[12] ),
    .B2(_0408_),
    .X(_0467_));
 sky130_fd_sc_hd__or2_2 _0776_ (.A(\u_uart_baud_tick_gen.baud_cnt[13] ),
    .B(_0407_),
    .X(_0468_));
 sky130_fd_sc_hd__nor2_2 _0777_ (.A(\u_uart_baud_tick_gen.baud_cnt[12] ),
    .B(_0408_),
    .Y(_0469_));
 sky130_fd_sc_hd__and4bb_2 _0778_ (.A_N(_0469_),
    .B_N(_0467_),
    .C(_0466_),
    .D(_0468_),
    .X(_0470_));
 sky130_fd_sc_hd__a32o_2 _0779_ (.A1(_0466_),
    .A2(_0467_),
    .A3(_0468_),
    .B1(_0465_),
    .B2(_0463_),
    .X(_0471_));
 sky130_fd_sc_hd__a21oi_2 _0780_ (.A1(_0462_),
    .A2(_0470_),
    .B1(_0471_),
    .Y(_0472_));
 sky130_fd_sc_hd__a211oi_2 _0781_ (.A1(_0462_),
    .A2(_0470_),
    .B1(_0471_),
    .C1(_0399_),
    .Y(_0473_));
 sky130_fd_sc_hd__and2_2 _0782_ (.A(_0417_),
    .B(_0473_),
    .X(_0005_));
 sky130_fd_sc_hd__nand2_2 _0783_ (.A(\u_uart_baud_tick_gen.baud_cnt[1] ),
    .B(\u_uart_baud_tick_gen.baud_cnt[0] ),
    .Y(_0474_));
 sky130_fd_sc_hd__or2_2 _0784_ (.A(\u_uart_baud_tick_gen.baud_cnt[1] ),
    .B(\u_uart_baud_tick_gen.baud_cnt[0] ),
    .X(_0475_));
 sky130_fd_sc_hd__and3_2 _0785_ (.A(_0473_),
    .B(_0474_),
    .C(_0475_),
    .X(_0012_));
 sky130_fd_sc_hd__nand3_2 _0786_ (.A(\u_uart_baud_tick_gen.baud_cnt[2] ),
    .B(\u_uart_baud_tick_gen.baud_cnt[1] ),
    .C(\u_uart_baud_tick_gen.baud_cnt[0] ),
    .Y(_0476_));
 sky130_fd_sc_hd__a21o_2 _0787_ (.A1(\u_uart_baud_tick_gen.baud_cnt[1] ),
    .A2(\u_uart_baud_tick_gen.baud_cnt[0] ),
    .B1(\u_uart_baud_tick_gen.baud_cnt[2] ),
    .X(_0477_));
 sky130_fd_sc_hd__and3_2 _0788_ (.A(_0473_),
    .B(_0476_),
    .C(_0477_),
    .X(_0013_));
 sky130_fd_sc_hd__and4_2 _0789_ (.A(\u_uart_baud_tick_gen.baud_cnt[3] ),
    .B(\u_uart_baud_tick_gen.baud_cnt[2] ),
    .C(\u_uart_baud_tick_gen.baud_cnt[1] ),
    .D(\u_uart_baud_tick_gen.baud_cnt[0] ),
    .X(_0478_));
 sky130_fd_sc_hd__nand2_2 _0790_ (.A(_0416_),
    .B(_0476_),
    .Y(_0479_));
 sky130_fd_sc_hd__and3b_2 _0791_ (.A_N(_0478_),
    .B(_0479_),
    .C(_0473_),
    .X(_0014_));
 sky130_fd_sc_hd__nand2_2 _0792_ (.A(\u_uart_baud_tick_gen.baud_cnt[4] ),
    .B(_0478_),
    .Y(_0480_));
 sky130_fd_sc_hd__or2_2 _0793_ (.A(\u_uart_baud_tick_gen.baud_cnt[4] ),
    .B(_0478_),
    .X(_0481_));
 sky130_fd_sc_hd__and3_2 _0794_ (.A(_0473_),
    .B(_0480_),
    .C(_0481_),
    .X(_0015_));
 sky130_fd_sc_hd__and3_2 _0795_ (.A(\u_uart_baud_tick_gen.baud_cnt[5] ),
    .B(\u_uart_baud_tick_gen.baud_cnt[4] ),
    .C(_0478_),
    .X(_0482_));
 sky130_fd_sc_hd__a21o_2 _0796_ (.A1(\u_uart_baud_tick_gen.baud_cnt[4] ),
    .A2(_0478_),
    .B1(\u_uart_baud_tick_gen.baud_cnt[5] ),
    .X(_0483_));
 sky130_fd_sc_hd__and3b_2 _0797_ (.A_N(_0482_),
    .B(_0483_),
    .C(_0473_),
    .X(_0016_));
 sky130_fd_sc_hd__and2_2 _0798_ (.A(\u_uart_baud_tick_gen.baud_cnt[6] ),
    .B(_0482_),
    .X(_0484_));
 sky130_fd_sc_hd__or2_2 _0799_ (.A(\u_uart_baud_tick_gen.baud_cnt[6] ),
    .B(_0482_),
    .X(_0485_));
 sky130_fd_sc_hd__and3b_2 _0800_ (.A_N(_0484_),
    .B(_0485_),
    .C(_0473_),
    .X(_0017_));
 sky130_fd_sc_hd__nand2_2 _0801_ (.A(\u_uart_baud_tick_gen.baud_cnt[7] ),
    .B(_0484_),
    .Y(_0486_));
 sky130_fd_sc_hd__or2_2 _0802_ (.A(\u_uart_baud_tick_gen.baud_cnt[7] ),
    .B(_0484_),
    .X(_0487_));
 sky130_fd_sc_hd__and3_2 _0803_ (.A(_0473_),
    .B(_0486_),
    .C(_0487_),
    .X(_0018_));
 sky130_fd_sc_hd__and3_2 _0804_ (.A(\u_uart_baud_tick_gen.baud_cnt[8] ),
    .B(\u_uart_baud_tick_gen.baud_cnt[7] ),
    .C(_0484_),
    .X(_0488_));
 sky130_fd_sc_hd__nand2_2 _0805_ (.A(_0412_),
    .B(_0486_),
    .Y(_0489_));
 sky130_fd_sc_hd__and3b_2 _0806_ (.A_N(_0488_),
    .B(_0489_),
    .C(_0473_),
    .X(_0019_));
 sky130_fd_sc_hd__and2_2 _0807_ (.A(\u_uart_baud_tick_gen.baud_cnt[9] ),
    .B(_0488_),
    .X(_0490_));
 sky130_fd_sc_hd__or2_2 _0808_ (.A(\u_uart_baud_tick_gen.baud_cnt[9] ),
    .B(_0488_),
    .X(_0491_));
 sky130_fd_sc_hd__and3b_2 _0809_ (.A_N(_0490_),
    .B(_0491_),
    .C(_0473_),
    .X(_0020_));
 sky130_fd_sc_hd__nand2_2 _0810_ (.A(\u_uart_baud_tick_gen.baud_cnt[10] ),
    .B(_0490_),
    .Y(_0492_));
 sky130_fd_sc_hd__or2_2 _0811_ (.A(\u_uart_baud_tick_gen.baud_cnt[10] ),
    .B(_0490_),
    .X(_0493_));
 sky130_fd_sc_hd__and3_2 _0812_ (.A(_0473_),
    .B(_0492_),
    .C(_0493_),
    .X(_0006_));
 sky130_fd_sc_hd__and3_2 _0813_ (.A(\u_uart_baud_tick_gen.baud_cnt[11] ),
    .B(\u_uart_baud_tick_gen.baud_cnt[10] ),
    .C(_0490_),
    .X(_0494_));
 sky130_fd_sc_hd__a31o_2 _0814_ (.A1(\u_uart_baud_tick_gen.baud_cnt[10] ),
    .A2(\u_uart_baud_tick_gen.baud_cnt[9] ),
    .A3(_0488_),
    .B1(\u_uart_baud_tick_gen.baud_cnt[11] ),
    .X(_0495_));
 sky130_fd_sc_hd__and3b_2 _0815_ (.A_N(_0494_),
    .B(_0495_),
    .C(_0473_),
    .X(_0007_));
 sky130_fd_sc_hd__and2_2 _0816_ (.A(\u_uart_baud_tick_gen.baud_cnt[12] ),
    .B(_0494_),
    .X(_0496_));
 sky130_fd_sc_hd__or2_2 _0817_ (.A(\u_uart_baud_tick_gen.baud_cnt[12] ),
    .B(_0494_),
    .X(_0497_));
 sky130_fd_sc_hd__and3b_2 _0818_ (.A_N(_0496_),
    .B(_0497_),
    .C(_0473_),
    .X(_0008_));
 sky130_fd_sc_hd__nand2_2 _0819_ (.A(\u_uart_baud_tick_gen.baud_cnt[13] ),
    .B(_0496_),
    .Y(_0498_));
 sky130_fd_sc_hd__or2_2 _0820_ (.A(\u_uart_baud_tick_gen.baud_cnt[13] ),
    .B(_0496_),
    .X(_0499_));
 sky130_fd_sc_hd__and3_2 _0821_ (.A(_0473_),
    .B(_0498_),
    .C(_0499_),
    .X(_0009_));
 sky130_fd_sc_hd__and3_2 _0822_ (.A(\u_uart_baud_tick_gen.baud_cnt[14] ),
    .B(\u_uart_baud_tick_gen.baud_cnt[13] ),
    .C(_0496_),
    .X(_0500_));
 sky130_fd_sc_hd__a31o_2 _0823_ (.A1(\u_uart_baud_tick_gen.baud_cnt[13] ),
    .A2(\u_uart_baud_tick_gen.baud_cnt[12] ),
    .A3(_0494_),
    .B1(\u_uart_baud_tick_gen.baud_cnt[14] ),
    .X(_0501_));
 sky130_fd_sc_hd__and3b_2 _0824_ (.A_N(_0500_),
    .B(_0501_),
    .C(_0473_),
    .X(_0010_));
 sky130_fd_sc_hd__o21a_2 _0825_ (.A1(\u_uart_baud_tick_gen.baud_cnt[15] ),
    .A2(_0500_),
    .B1(_0473_),
    .X(_0011_));
 sky130_fd_sc_hd__and4_2 _0826_ (.A(wr_addr[2]),
    .B(wr_addr[3]),
    .C(wr_addr[4]),
    .D(_0435_),
    .X(_0502_));
 sky130_fd_sc_hd__and2_2 _0827_ (.A(wr_data[0]),
    .B(_0502_),
    .X(_0022_));
 sky130_fd_sc_hd__and2_2 _0828_ (.A(wr_data[1]),
    .B(_0502_),
    .X(_0023_));
 sky130_fd_sc_hd__and2_2 _0829_ (.A(wr_data[2]),
    .B(_0502_),
    .X(_0024_));
 sky130_fd_sc_hd__and2_2 _0830_ (.A(wr_data[3]),
    .B(_0502_),
    .X(_0025_));
 sky130_fd_sc_hd__and2_2 _0831_ (.A(wr_data[4]),
    .B(_0502_),
    .X(_0026_));
 sky130_fd_sc_hd__and2_2 _0832_ (.A(wr_data[5]),
    .B(_0502_),
    .X(_0027_));
 sky130_fd_sc_hd__or4b_2 _0833_ (.A(rd_addr[4]),
    .B(rd_addr[7]),
    .C(rd_addr[6]),
    .D_N(rd_addr[5]),
    .X(_0503_));
 sky130_fd_sc_hd__or4_2 _0834_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .C(rd_addr[2]),
    .D(rd_addr[3]),
    .X(_0504_));
 sky130_fd_sc_hd__nor2_2 _0835_ (.A(_0503_),
    .B(_0504_),
    .Y(_0505_));
 sky130_fd_sc_hd__or4_2 _0836_ (.A(rd_addr[4]),
    .B(rd_addr[5]),
    .C(rd_addr[7]),
    .D(rd_addr[6]),
    .X(_0506_));
 sky130_fd_sc_hd__or4b_2 _0837_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .C(rd_addr[2]),
    .D_N(rd_addr[3]),
    .X(_0507_));
 sky130_fd_sc_hd__nor2_2 _0838_ (.A(_0506_),
    .B(_0507_),
    .Y(_0508_));
 sky130_fd_sc_hd__nor2_2 _0839_ (.A(_0504_),
    .B(_0506_),
    .Y(_0509_));
 sky130_fd_sc_hd__or4b_2 _0840_ (.A(rd_addr[1]),
    .B(rd_addr[2]),
    .C(rd_addr[3]),
    .D_N(rd_addr[0]),
    .X(_0510_));
 sky130_fd_sc_hd__nor2_2 _0841_ (.A(_0503_),
    .B(_0510_),
    .Y(_0511_));
 sky130_fd_sc_hd__or4b_2 _0842_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .C(rd_addr[3]),
    .D_N(rd_addr[2]),
    .X(_0512_));
 sky130_fd_sc_hd__or4b_2 _0843_ (.A(rd_addr[5]),
    .B(rd_addr[7]),
    .C(rd_addr[6]),
    .D_N(rd_addr[4]),
    .X(_0513_));
 sky130_fd_sc_hd__nor2_2 _0844_ (.A(_0512_),
    .B(_0513_),
    .Y(_0514_));
 sky130_fd_sc_hd__or2_2 _0845_ (.A(_0512_),
    .B(_0513_),
    .X(_0515_));
 sky130_fd_sc_hd__nor2_2 _0846_ (.A(_0506_),
    .B(_0512_),
    .Y(_0516_));
 sky130_fd_sc_hd__or4bb_2 _0847_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .C_N(rd_addr[2]),
    .D_N(rd_addr[3]),
    .X(_0517_));
 sky130_fd_sc_hd__nor2_2 _0848_ (.A(_0513_),
    .B(_0517_),
    .Y(_0518_));
 sky130_fd_sc_hd__or4bb_2 _0849_ (.A(rd_addr[1]),
    .B(rd_addr[3]),
    .C_N(rd_addr[2]),
    .D_N(rd_addr[0]),
    .X(_0519_));
 sky130_fd_sc_hd__nor2_2 _0850_ (.A(_0506_),
    .B(_0519_),
    .Y(_0520_));
 sky130_fd_sc_hd__nor2_2 _0851_ (.A(_0507_),
    .B(_0513_),
    .Y(_0521_));
 sky130_fd_sc_hd__a22o_2 _0852_ (.A1(packet_count[8]),
    .A2(_0511_),
    .B1(_0521_),
    .B2(\irq_status[0] ),
    .X(_0522_));
 sky130_fd_sc_hd__a21o_2 _0853_ (.A1(\packet_len[0] ),
    .A2(_0508_),
    .B1(_0522_),
    .X(_0523_));
 sky130_fd_sc_hd__a22o_2 _0854_ (.A1(\baud_div[0] ),
    .A2(_0516_),
    .B1(_0520_),
    .B2(\baud_div[8] ),
    .X(_0524_));
 sky130_fd_sc_hd__a32o_2 _0855_ (.A1(_0400_),
    .A2(_0440_),
    .A3(_0514_),
    .B1(_0509_),
    .B2(control_enable),
    .X(_0525_));
 sky130_fd_sc_hd__a221o_2 _0856_ (.A1(packet_count[0]),
    .A2(_0505_),
    .B1(_0518_),
    .B2(\irq_clear[0] ),
    .C1(_0525_),
    .X(_0526_));
 sky130_fd_sc_hd__o31a_2 _0857_ (.A1(_0523_),
    .A2(_0524_),
    .A3(_0526_),
    .B1(rd_en),
    .X(_0028_));
 sky130_fd_sc_hd__nor2_2 _0858_ (.A(_0441_),
    .B(_0515_),
    .Y(_0527_));
 sky130_fd_sc_hd__a22o_2 _0859_ (.A1(packet_count[9]),
    .A2(_0511_),
    .B1(_0520_),
    .B2(\baud_div[9] ),
    .X(_0528_));
 sky130_fd_sc_hd__a221o_2 _0860_ (.A1(packet_count[1]),
    .A2(_0505_),
    .B1(_0518_),
    .B2(\irq_clear[1] ),
    .C1(_0527_),
    .X(_0529_));
 sky130_fd_sc_hd__a22o_2 _0861_ (.A1(\packet_len[1] ),
    .A2(_0508_),
    .B1(_0521_),
    .B2(\irq_status[1] ),
    .X(_0530_));
 sky130_fd_sc_hd__a221o_2 _0862_ (.A1(control_rx_enable),
    .A2(_0509_),
    .B1(_0516_),
    .B2(\baud_div[1] ),
    .C1(_0530_),
    .X(_0531_));
 sky130_fd_sc_hd__o31a_2 _0863_ (.A1(_0528_),
    .A2(_0529_),
    .A3(_0531_),
    .B1(rd_en),
    .X(_0029_));
 sky130_fd_sc_hd__nor4_2 _0864_ (.A(\u_uart_rx_engine.rx_count[0] ),
    .B(\u_uart_rx_engine.rx_count[1] ),
    .C(\u_uart_rx_engine.rx_count[2] ),
    .D(\u_uart_rx_engine.rx_count[3] ),
    .Y(_0532_));
 sky130_fd_sc_hd__and3_2 _0865_ (.A(_0404_),
    .B(_0514_),
    .C(_0532_),
    .X(_0533_));
 sky130_fd_sc_hd__a22o_2 _0866_ (.A1(packet_count[2]),
    .A2(_0505_),
    .B1(_0509_),
    .B2(control_tx_enable),
    .X(_0534_));
 sky130_fd_sc_hd__a22o_2 _0867_ (.A1(\packet_len[2] ),
    .A2(_0508_),
    .B1(_0520_),
    .B2(\baud_div[10] ),
    .X(_0535_));
 sky130_fd_sc_hd__a221o_2 _0868_ (.A1(packet_count[10]),
    .A2(_0511_),
    .B1(_0518_),
    .B2(\irq_clear[2] ),
    .C1(_0533_),
    .X(_0536_));
 sky130_fd_sc_hd__a221o_2 _0869_ (.A1(\baud_div[2] ),
    .A2(_0516_),
    .B1(_0521_),
    .B2(\irq_status[2] ),
    .C1(_0534_),
    .X(_0537_));
 sky130_fd_sc_hd__o31a_2 _0870_ (.A1(_0535_),
    .A2(_0536_),
    .A3(_0537_),
    .B1(rd_en),
    .X(_0030_));
 sky130_fd_sc_hd__nand2_2 _0871_ (.A(\u_uart_rx_engine.rx_count[4] ),
    .B(_0532_),
    .Y(_0538_));
 sky130_fd_sc_hd__inv_2 _0872_ (.A(_0538_),
    .Y(_0539_));
 sky130_fd_sc_hd__nor2_2 _0873_ (.A(_0515_),
    .B(_0538_),
    .Y(_0540_));
 sky130_fd_sc_hd__a221o_2 _0874_ (.A1(\packet_len[3] ),
    .A2(_0508_),
    .B1(_0509_),
    .B2(control_loopback),
    .C1(_0540_),
    .X(_0541_));
 sky130_fd_sc_hd__a22o_2 _0875_ (.A1(\baud_div[11] ),
    .A2(_0520_),
    .B1(_0521_),
    .B2(\irq_status[3] ),
    .X(_0542_));
 sky130_fd_sc_hd__a22o_2 _0876_ (.A1(packet_count[3]),
    .A2(_0505_),
    .B1(_0511_),
    .B2(packet_count[11]),
    .X(_0543_));
 sky130_fd_sc_hd__a221o_2 _0877_ (.A1(\baud_div[3] ),
    .A2(_0516_),
    .B1(_0518_),
    .B2(\irq_clear[3] ),
    .C1(_0543_),
    .X(_0544_));
 sky130_fd_sc_hd__o31a_2 _0878_ (.A1(_0541_),
    .A2(_0542_),
    .A3(_0544_),
    .B1(rd_en),
    .X(_0031_));
 sky130_fd_sc_hd__nor2_2 _0879_ (.A(_0402_),
    .B(_0515_),
    .Y(_0545_));
 sky130_fd_sc_hd__a22o_2 _0880_ (.A1(\baud_div[4] ),
    .A2(_0516_),
    .B1(_0520_),
    .B2(\baud_div[12] ),
    .X(_0546_));
 sky130_fd_sc_hd__a221o_2 _0881_ (.A1(control_irq_enable),
    .A2(_0509_),
    .B1(_0518_),
    .B2(\irq_clear[4] ),
    .C1(_0545_),
    .X(_0547_));
 sky130_fd_sc_hd__a22o_2 _0882_ (.A1(packet_count[12]),
    .A2(_0511_),
    .B1(_0521_),
    .B2(\irq_status[4] ),
    .X(_0548_));
 sky130_fd_sc_hd__a221o_2 _0883_ (.A1(packet_count[4]),
    .A2(_0505_),
    .B1(_0508_),
    .B2(\packet_len[4] ),
    .C1(_0548_),
    .X(_0549_));
 sky130_fd_sc_hd__o31a_2 _0884_ (.A1(_0546_),
    .A2(_0547_),
    .A3(_0549_),
    .B1(rd_en),
    .X(_0032_));
 sky130_fd_sc_hd__a22o_2 _0885_ (.A1(\irq_clear[5] ),
    .A2(_0518_),
    .B1(_0520_),
    .B2(\baud_div[13] ),
    .X(_0550_));
 sky130_fd_sc_hd__a221o_2 _0886_ (.A1(\packet_len[5] ),
    .A2(_0508_),
    .B1(_0511_),
    .B2(packet_count[13]),
    .C1(_0550_),
    .X(_0551_));
 sky130_fd_sc_hd__a22o_2 _0887_ (.A1(\baud_div[5] ),
    .A2(_0516_),
    .B1(_0521_),
    .B2(\irq_status[5] ),
    .X(_0552_));
 sky130_fd_sc_hd__a221o_2 _0888_ (.A1(packet_count[5]),
    .A2(_0505_),
    .B1(_0514_),
    .B2(status_rx_busy),
    .C1(_0552_),
    .X(_0553_));
 sky130_fd_sc_hd__o21a_2 _0889_ (.A1(_0551_),
    .A2(_0553_),
    .B1(rd_en),
    .X(_0033_));
 sky130_fd_sc_hd__a22o_2 _0890_ (.A1(\packet_len[6] ),
    .A2(_0508_),
    .B1(_0520_),
    .B2(\baud_div[14] ),
    .X(_0554_));
 sky130_fd_sc_hd__and2_2 _0891_ (.A(packet_count[6]),
    .B(_0505_),
    .X(_0555_));
 sky130_fd_sc_hd__a22o_2 _0892_ (.A1(packet_count[14]),
    .A2(_0511_),
    .B1(_0516_),
    .B2(\baud_div[6] ),
    .X(_0556_));
 sky130_fd_sc_hd__o31a_2 _0893_ (.A1(_0554_),
    .A2(_0555_),
    .A3(_0556_),
    .B1(rd_en),
    .X(_0034_));
 sky130_fd_sc_hd__a22o_2 _0894_ (.A1(packet_count[7]),
    .A2(_0505_),
    .B1(_0520_),
    .B2(\baud_div[15] ),
    .X(_0557_));
 sky130_fd_sc_hd__and2_2 _0895_ (.A(\packet_len[7] ),
    .B(_0508_),
    .X(_0558_));
 sky130_fd_sc_hd__a22o_2 _0896_ (.A1(packet_count[15]),
    .A2(_0511_),
    .B1(_0516_),
    .B2(\baud_div[7] ),
    .X(_0559_));
 sky130_fd_sc_hd__o31a_2 _0897_ (.A1(_0557_),
    .A2(_0558_),
    .A3(_0559_),
    .B1(rd_en),
    .X(_0035_));
 sky130_fd_sc_hd__and2_2 _0898_ (.A(control_enable),
    .B(control_tx_enable),
    .X(_0560_));
 sky130_fd_sc_hd__nand2_2 _0899_ (.A(control_enable),
    .B(control_tx_enable),
    .Y(_0561_));
 sky130_fd_sc_hd__o21ai_2 _0900_ (.A1(\u_uart_tx_engine.tx_count[4] ),
    .A2(_0439_),
    .B1(baud_tick),
    .Y(_0562_));
 sky130_fd_sc_hd__nor2_2 _0901_ (.A(status_tx_busy),
    .B(_0562_),
    .Y(_0563_));
 sky130_fd_sc_hd__and2_2 _0902_ (.A(_0560_),
    .B(_0563_),
    .X(_0564_));
 sky130_fd_sc_hd__nand2_2 _0903_ (.A(_0560_),
    .B(_0563_),
    .Y(_0565_));
 sky130_fd_sc_hd__and2_2 _0904_ (.A(tx_data_push),
    .B(_0441_),
    .X(_0566_));
 sky130_fd_sc_hd__nand2_2 _0905_ (.A(tx_data_push),
    .B(_0441_),
    .Y(_0567_));
 sky130_fd_sc_hd__a21oi_2 _0906_ (.A1(_0565_),
    .A2(_0567_),
    .B1(\u_uart_tx_engine.tx_count[0] ),
    .Y(_0568_));
 sky130_fd_sc_hd__a31o_2 _0907_ (.A1(\u_uart_tx_engine.tx_count[0] ),
    .A2(_0401_),
    .A3(_0565_),
    .B1(_0568_),
    .X(_0046_));
 sky130_fd_sc_hd__and3_2 _0908_ (.A(\u_uart_tx_engine.tx_count[0] ),
    .B(tx_data_push),
    .C(_0565_),
    .X(_0569_));
 sky130_fd_sc_hd__o21ba_2 _0909_ (.A1(\u_uart_tx_engine.tx_count[0] ),
    .A2(_0565_),
    .B1_N(_0569_),
    .X(_0570_));
 sky130_fd_sc_hd__xnor2_2 _0910_ (.A(\u_uart_tx_engine.tx_count[1] ),
    .B(_0570_),
    .Y(_0047_));
 sky130_fd_sc_hd__and2_2 _0911_ (.A(\u_uart_tx_engine.tx_count[1] ),
    .B(_0569_),
    .X(_0571_));
 sky130_fd_sc_hd__or3_2 _0912_ (.A(\u_uart_tx_engine.tx_count[1] ),
    .B(\u_uart_tx_engine.tx_count[0] ),
    .C(_0565_),
    .X(_0572_));
 sky130_fd_sc_hd__nor2_2 _0913_ (.A(\u_uart_tx_engine.tx_count[2] ),
    .B(_0572_),
    .Y(_0573_));
 sky130_fd_sc_hd__and2b_2 _0914_ (.A_N(_0571_),
    .B(_0572_),
    .X(_0574_));
 sky130_fd_sc_hd__xnor2_2 _0915_ (.A(\u_uart_tx_engine.tx_count[2] ),
    .B(_0574_),
    .Y(_0048_));
 sky130_fd_sc_hd__a21o_2 _0916_ (.A1(\u_uart_tx_engine.tx_count[2] ),
    .A2(_0571_),
    .B1(_0573_),
    .X(_0575_));
 sky130_fd_sc_hd__xor2_2 _0917_ (.A(\u_uart_tx_engine.tx_count[3] ),
    .B(_0575_),
    .X(_0049_));
 sky130_fd_sc_hd__and3_2 _0918_ (.A(\u_uart_tx_engine.tx_count[3] ),
    .B(\u_uart_tx_engine.tx_count[2] ),
    .C(_0571_),
    .X(_0576_));
 sky130_fd_sc_hd__a21oi_2 _0919_ (.A1(_0440_),
    .A2(_0564_),
    .B1(_0400_),
    .Y(_0577_));
 sky130_fd_sc_hd__mux2_1 _0920_ (.A0(_0577_),
    .A1(_0400_),
    .S(_0576_),
    .X(_0050_));
 sky130_fd_sc_hd__a21boi_2 _0921_ (.A1(_0404_),
    .A2(_0532_),
    .B1_N(rx_data_pop),
    .Y(_0578_));
 sky130_fd_sc_hd__a21o_2 _0922_ (.A1(baud_tick),
    .A2(\u_uart_rx_engine.rx_state[3] ),
    .B1(loopback_byte_valid),
    .X(_0579_));
 sky130_fd_sc_hd__o211a_2 _0923_ (.A1(uart_rx),
    .A2(_0425_),
    .B1(_0579_),
    .C1(_0420_),
    .X(_0580_));
 sky130_fd_sc_hd__and2_2 _0924_ (.A(_0538_),
    .B(_0580_),
    .X(_0581_));
 sky130_fd_sc_hd__nand2_2 _0925_ (.A(_0538_),
    .B(_0580_),
    .Y(_0582_));
 sky130_fd_sc_hd__o21ai_2 _0926_ (.A1(_0578_),
    .A2(_0580_),
    .B1(\u_uart_rx_engine.rx_count[0] ),
    .Y(_0583_));
 sky130_fd_sc_hd__o31a_2 _0927_ (.A1(\u_uart_rx_engine.rx_count[0] ),
    .A2(_0578_),
    .A3(_0581_),
    .B1(_0583_),
    .X(_0039_));
 sky130_fd_sc_hd__and3b_2 _0928_ (.A_N(\u_uart_rx_engine.rx_count[0] ),
    .B(_0578_),
    .C(_0582_),
    .X(_0584_));
 sky130_fd_sc_hd__a21oi_2 _0929_ (.A1(\u_uart_rx_engine.rx_count[0] ),
    .A2(_0581_),
    .B1(_0584_),
    .Y(_0585_));
 sky130_fd_sc_hd__xnor2_2 _0930_ (.A(\u_uart_rx_engine.rx_count[1] ),
    .B(_0585_),
    .Y(_0040_));
 sky130_fd_sc_hd__and2b_2 _0931_ (.A_N(\u_uart_rx_engine.rx_count[1] ),
    .B(_0584_),
    .X(_0586_));
 sky130_fd_sc_hd__a31o_2 _0932_ (.A1(\u_uart_rx_engine.rx_count[0] ),
    .A2(\u_uart_rx_engine.rx_count[1] ),
    .A3(_0581_),
    .B1(_0586_),
    .X(_0587_));
 sky130_fd_sc_hd__xor2_2 _0933_ (.A(\u_uart_rx_engine.rx_count[2] ),
    .B(_0587_),
    .X(_0041_));
 sky130_fd_sc_hd__and3_2 _0934_ (.A(\u_uart_rx_engine.rx_count[0] ),
    .B(\u_uart_rx_engine.rx_count[1] ),
    .C(\u_uart_rx_engine.rx_count[2] ),
    .X(_0588_));
 sky130_fd_sc_hd__and3_2 _0935_ (.A(\u_uart_rx_engine.rx_count[3] ),
    .B(_0580_),
    .C(_0588_),
    .X(_0589_));
 sky130_fd_sc_hd__or4b_2 _0936_ (.A(\u_uart_rx_engine.rx_count[0] ),
    .B(\u_uart_rx_engine.rx_count[1] ),
    .C(\u_uart_rx_engine.rx_count[2] ),
    .D_N(rx_data_pop),
    .X(_0590_));
 sky130_fd_sc_hd__nand2_2 _0937_ (.A(\u_uart_rx_engine.rx_count[3] ),
    .B(_0590_),
    .Y(_0591_));
 sky130_fd_sc_hd__a2bb2o_2 _0938_ (.A1_N(\u_uart_rx_engine.rx_count[3] ),
    .A2_N(_0588_),
    .B1(_0591_),
    .B2(_0582_),
    .X(_0592_));
 sky130_fd_sc_hd__a2bb2o_2 _0939_ (.A1_N(_0589_),
    .A2_N(_0592_),
    .B1(rx_data_pop),
    .B2(_0539_),
    .X(_0042_));
 sky130_fd_sc_hd__a21bo_2 _0940_ (.A1(rx_data_pop),
    .A2(_0532_),
    .B1_N(\u_uart_rx_engine.rx_count[4] ),
    .X(_0593_));
 sky130_fd_sc_hd__xnor2_2 _0941_ (.A(_0589_),
    .B(_0593_),
    .Y(_0043_));
 sky130_fd_sc_hd__nor2_2 _0942_ (.A(_0399_),
    .B(_0472_),
    .Y(_0021_));
 sky130_fd_sc_hd__nor3_2 _0943_ (.A(_0418_),
    .B(_0504_),
    .C(_0513_),
    .Y(_0036_));
 sky130_fd_sc_hd__and3_2 _0944_ (.A(\u_uart_tx_engine.tx_packet_count[0] ),
    .B(\u_uart_tx_engine.tx_packet_count[1] ),
    .C(\u_uart_tx_engine.tx_packet_count[2] ),
    .X(_0594_));
 sky130_fd_sc_hd__and2_2 _0945_ (.A(\u_uart_tx_engine.tx_packet_count[3] ),
    .B(_0594_),
    .X(_0595_));
 sky130_fd_sc_hd__and3_2 _0946_ (.A(\u_uart_tx_engine.tx_packet_count[4] ),
    .B(\u_uart_tx_engine.tx_packet_count[5] ),
    .C(_0595_),
    .X(_0596_));
 sky130_fd_sc_hd__nand2_2 _0947_ (.A(\u_uart_tx_engine.tx_packet_count[6] ),
    .B(_0596_),
    .Y(_0597_));
 sky130_fd_sc_hd__or2_2 _0948_ (.A(\u_uart_tx_engine.tx_packet_count[6] ),
    .B(_0596_),
    .X(_0598_));
 sky130_fd_sc_hd__and2_2 _0949_ (.A(_0597_),
    .B(_0598_),
    .X(_0599_));
 sky130_fd_sc_hd__xor2_2 _0950_ (.A(\u_uart_tx_engine.tx_packet_count[4] ),
    .B(_0595_),
    .X(_0600_));
 sky130_fd_sc_hd__xnor2_2 _0951_ (.A(\packet_len[4] ),
    .B(_0600_),
    .Y(_0601_));
 sky130_fd_sc_hd__xnor2_2 _0952_ (.A(\u_uart_tx_engine.tx_packet_count[0] ),
    .B(\u_uart_tx_engine.tx_packet_count[1] ),
    .Y(_0602_));
 sky130_fd_sc_hd__inv_2 _0953_ (.A(_0602_),
    .Y(_0603_));
 sky130_fd_sc_hd__xnor2_2 _0954_ (.A(\packet_len[0] ),
    .B(\u_uart_tx_engine.tx_packet_count[0] ),
    .Y(_0604_));
 sky130_fd_sc_hd__a21oi_2 _0955_ (.A1(\packet_len[1] ),
    .A2(_0602_),
    .B1(_0604_),
    .Y(_0605_));
 sky130_fd_sc_hd__a21oi_2 _0956_ (.A1(\u_uart_tx_engine.tx_packet_count[0] ),
    .A2(\u_uart_tx_engine.tx_packet_count[1] ),
    .B1(\u_uart_tx_engine.tx_packet_count[2] ),
    .Y(_0606_));
 sky130_fd_sc_hd__nor2_2 _0957_ (.A(_0594_),
    .B(_0606_),
    .Y(_0607_));
 sky130_fd_sc_hd__xnor2_2 _0958_ (.A(\packet_len[2] ),
    .B(_0607_),
    .Y(_0608_));
 sky130_fd_sc_hd__o211a_2 _0959_ (.A1(\packet_len[1] ),
    .A2(_0602_),
    .B1(_0605_),
    .C1(_0608_),
    .X(_0609_));
 sky130_fd_sc_hd__nor2_2 _0960_ (.A(\u_uart_tx_engine.tx_packet_count[3] ),
    .B(_0594_),
    .Y(_0610_));
 sky130_fd_sc_hd__nor2_2 _0961_ (.A(_0595_),
    .B(_0610_),
    .Y(_0611_));
 sky130_fd_sc_hd__xnor2_2 _0962_ (.A(\packet_len[3] ),
    .B(_0611_),
    .Y(_0612_));
 sky130_fd_sc_hd__and3_2 _0963_ (.A(_0601_),
    .B(_0609_),
    .C(_0612_),
    .X(_0613_));
 sky130_fd_sc_hd__a21oi_2 _0964_ (.A1(\u_uart_tx_engine.tx_packet_count[4] ),
    .A2(_0595_),
    .B1(\u_uart_tx_engine.tx_packet_count[5] ),
    .Y(_0614_));
 sky130_fd_sc_hd__nor2_2 _0965_ (.A(_0596_),
    .B(_0614_),
    .Y(_0615_));
 sky130_fd_sc_hd__and2_2 _0966_ (.A(\packet_len[5] ),
    .B(_0615_),
    .X(_0616_));
 sky130_fd_sc_hd__nor2_2 _0967_ (.A(\packet_len[5] ),
    .B(_0615_),
    .Y(_0617_));
 sky130_fd_sc_hd__o2bb2a_2 _0968_ (.A1_N(_0403_),
    .A2_N(_0599_),
    .B1(_0616_),
    .B2(_0617_),
    .X(_0618_));
 sky130_fd_sc_hd__xnor2_2 _0969_ (.A(\u_uart_tx_engine.tx_packet_count[7] ),
    .B(_0597_),
    .Y(_0619_));
 sky130_fd_sc_hd__xnor2_2 _0970_ (.A(\packet_len[7] ),
    .B(_0619_),
    .Y(_0620_));
 sky130_fd_sc_hd__o2111ai_2 _0971_ (.A1(_0403_),
    .A2(_0599_),
    .B1(_0613_),
    .C1(_0618_),
    .D1(_0620_),
    .Y(_0621_));
 sky130_fd_sc_hd__or4_2 _0972_ (.A(\packet_len[5] ),
    .B(\packet_len[4] ),
    .C(\packet_len[7] ),
    .D(\packet_len[6] ),
    .X(_0622_));
 sky130_fd_sc_hd__or4_2 _0973_ (.A(\packet_len[1] ),
    .B(\packet_len[0] ),
    .C(\packet_len[3] ),
    .D(\packet_len[2] ),
    .X(_0623_));
 sky130_fd_sc_hd__or2_2 _0974_ (.A(_0622_),
    .B(_0623_),
    .X(_0624_));
 sky130_fd_sc_hd__and2_2 _0975_ (.A(baud_tick),
    .B(status_tx_busy),
    .X(_0625_));
 sky130_fd_sc_hd__nand2_2 _0976_ (.A(_0560_),
    .B(_0625_),
    .Y(_0626_));
 sky130_fd_sc_hd__and2_2 _0977_ (.A(\u_uart_tx_engine.tx_bit_index[1] ),
    .B(\u_uart_tx_engine.tx_bit_index[0] ),
    .X(_0627_));
 sky130_fd_sc_hd__a31o_2 _0978_ (.A1(\u_uart_tx_engine.tx_bit_index[2] ),
    .A2(_0625_),
    .A3(_0627_),
    .B1(_0561_),
    .X(_0628_));
 sky130_fd_sc_hd__o21ai_2 _0979_ (.A1(_0624_),
    .A2(_0626_),
    .B1(_0628_),
    .Y(_0629_));
 sky130_fd_sc_hd__or2_2 _0980_ (.A(_0561_),
    .B(_0629_),
    .X(_0630_));
 sky130_fd_sc_hd__nor2_2 _0981_ (.A(_0621_),
    .B(_0630_),
    .Y(_0051_));
 sky130_fd_sc_hd__and3_2 _0982_ (.A(control_loopback),
    .B(_0560_),
    .C(_0563_),
    .X(_0045_));
 sky130_fd_sc_hd__and2_2 _0983_ (.A(_0539_),
    .B(_0580_),
    .X(_0044_));
 sky130_fd_sc_hd__and3_2 _0984_ (.A(uart_rx),
    .B(\u_uart_rx_engine.rx_state[2] ),
    .C(_0424_),
    .X(_0631_));
 sky130_fd_sc_hd__a21o_2 _0985_ (.A1(\u_uart_rx_engine.rx_state[3] ),
    .A2(_0428_),
    .B1(_0631_),
    .X(_0037_));
 sky130_fd_sc_hd__and3_2 _0986_ (.A(\u_uart_rx_engine.rx_packet_count[0] ),
    .B(\u_uart_rx_engine.rx_packet_count[1] ),
    .C(\u_uart_rx_engine.rx_packet_count[2] ),
    .X(_0632_));
 sky130_fd_sc_hd__and2_2 _0987_ (.A(\u_uart_rx_engine.rx_packet_count[3] ),
    .B(_0632_),
    .X(_0633_));
 sky130_fd_sc_hd__and3_2 _0988_ (.A(\u_uart_rx_engine.rx_packet_count[4] ),
    .B(\u_uart_rx_engine.rx_packet_count[5] ),
    .C(_0633_),
    .X(_0634_));
 sky130_fd_sc_hd__nand2_2 _0989_ (.A(\u_uart_rx_engine.rx_packet_count[6] ),
    .B(_0634_),
    .Y(_0635_));
 sky130_fd_sc_hd__or2_2 _0990_ (.A(\u_uart_rx_engine.rx_packet_count[6] ),
    .B(_0634_),
    .X(_0636_));
 sky130_fd_sc_hd__and2_2 _0991_ (.A(_0635_),
    .B(_0636_),
    .X(_0637_));
 sky130_fd_sc_hd__xnor2_2 _0992_ (.A(\u_uart_rx_engine.rx_packet_count[4] ),
    .B(_0633_),
    .Y(_0638_));
 sky130_fd_sc_hd__or2_2 _0993_ (.A(\packet_len[4] ),
    .B(_0638_),
    .X(_0639_));
 sky130_fd_sc_hd__nand2_2 _0994_ (.A(\packet_len[4] ),
    .B(_0638_),
    .Y(_0640_));
 sky130_fd_sc_hd__xnor2_2 _0995_ (.A(\u_uart_rx_engine.rx_packet_count[0] ),
    .B(\u_uart_rx_engine.rx_packet_count[1] ),
    .Y(_0641_));
 sky130_fd_sc_hd__xnor2_2 _0996_ (.A(\packet_len[0] ),
    .B(\u_uart_rx_engine.rx_packet_count[0] ),
    .Y(_0642_));
 sky130_fd_sc_hd__a21oi_2 _0997_ (.A1(\packet_len[1] ),
    .A2(_0641_),
    .B1(_0642_),
    .Y(_0643_));
 sky130_fd_sc_hd__a21oi_2 _0998_ (.A1(\u_uart_rx_engine.rx_packet_count[0] ),
    .A2(\u_uart_rx_engine.rx_packet_count[1] ),
    .B1(\u_uart_rx_engine.rx_packet_count[2] ),
    .Y(_0644_));
 sky130_fd_sc_hd__or2_2 _0999_ (.A(_0632_),
    .B(_0644_),
    .X(_0645_));
 sky130_fd_sc_hd__nand2_2 _1000_ (.A(\packet_len[2] ),
    .B(_0645_),
    .Y(_0646_));
 sky130_fd_sc_hd__or2_2 _1001_ (.A(\packet_len[2] ),
    .B(_0645_),
    .X(_0647_));
 sky130_fd_sc_hd__o2111a_2 _1002_ (.A1(\packet_len[1] ),
    .A2(_0641_),
    .B1(_0643_),
    .C1(_0646_),
    .D1(_0647_),
    .X(_0648_));
 sky130_fd_sc_hd__nor2_2 _1003_ (.A(\u_uart_rx_engine.rx_packet_count[3] ),
    .B(_0632_),
    .Y(_0649_));
 sky130_fd_sc_hd__or2_2 _1004_ (.A(_0633_),
    .B(_0649_),
    .X(_0650_));
 sky130_fd_sc_hd__xor2_2 _1005_ (.A(\packet_len[3] ),
    .B(_0650_),
    .X(_0651_));
 sky130_fd_sc_hd__and4_2 _1006_ (.A(_0639_),
    .B(_0640_),
    .C(_0648_),
    .D(_0651_),
    .X(_0652_));
 sky130_fd_sc_hd__a21oi_2 _1007_ (.A1(\u_uart_rx_engine.rx_packet_count[4] ),
    .A2(_0633_),
    .B1(\u_uart_rx_engine.rx_packet_count[5] ),
    .Y(_0653_));
 sky130_fd_sc_hd__nor2_2 _1008_ (.A(_0634_),
    .B(_0653_),
    .Y(_0654_));
 sky130_fd_sc_hd__xnor2_2 _1009_ (.A(\packet_len[5] ),
    .B(_0654_),
    .Y(_0655_));
 sky130_fd_sc_hd__xnor2_2 _1010_ (.A(\packet_len[6] ),
    .B(_0637_),
    .Y(_0656_));
 sky130_fd_sc_hd__xor2_2 _1011_ (.A(\u_uart_rx_engine.rx_packet_count[7] ),
    .B(_0635_),
    .X(_0657_));
 sky130_fd_sc_hd__xor2_2 _1012_ (.A(\packet_len[7] ),
    .B(_0657_),
    .X(_0658_));
 sky130_fd_sc_hd__and4_2 _1013_ (.A(_0652_),
    .B(_0655_),
    .C(_0656_),
    .D(_0658_),
    .X(_0659_));
 sky130_fd_sc_hd__nand2_2 _1014_ (.A(_0624_),
    .B(_0659_),
    .Y(_0660_));
 sky130_fd_sc_hd__nor2_2 _1015_ (.A(_0582_),
    .B(_0660_),
    .Y(_0038_));
 sky130_fd_sc_hd__xor2_2 _1016_ (.A(packet_done_event),
    .B(packet_count[0]),
    .X(_0053_));
 sky130_fd_sc_hd__and3_2 _1017_ (.A(packet_done_event),
    .B(packet_count[0]),
    .C(packet_count[1]),
    .X(_0661_));
 sky130_fd_sc_hd__a21oi_2 _1018_ (.A1(packet_done_event),
    .A2(packet_count[0]),
    .B1(packet_count[1]),
    .Y(_0662_));
 sky130_fd_sc_hd__nor2_2 _1019_ (.A(_0661_),
    .B(_0662_),
    .Y(_0054_));
 sky130_fd_sc_hd__and4_2 _1020_ (.A(packet_done_event),
    .B(packet_count[0]),
    .C(packet_count[1]),
    .D(packet_count[2]),
    .X(_0663_));
 sky130_fd_sc_hd__nor2_2 _1021_ (.A(packet_count[2]),
    .B(_0661_),
    .Y(_0664_));
 sky130_fd_sc_hd__nor2_2 _1022_ (.A(_0663_),
    .B(_0664_),
    .Y(_0055_));
 sky130_fd_sc_hd__nand2_2 _1023_ (.A(packet_count[3]),
    .B(_0663_),
    .Y(_0665_));
 sky130_fd_sc_hd__or2_2 _1024_ (.A(packet_count[3]),
    .B(_0663_),
    .X(_0666_));
 sky130_fd_sc_hd__and2_2 _1025_ (.A(_0665_),
    .B(_0666_),
    .X(_0056_));
 sky130_fd_sc_hd__xnor2_2 _1026_ (.A(packet_count[4]),
    .B(_0665_),
    .Y(_0057_));
 sky130_fd_sc_hd__and4_2 _1027_ (.A(packet_count[3]),
    .B(packet_count[4]),
    .C(packet_count[5]),
    .D(_0663_),
    .X(_0667_));
 sky130_fd_sc_hd__a31o_2 _1028_ (.A1(packet_count[3]),
    .A2(packet_count[4]),
    .A3(_0663_),
    .B1(packet_count[5]),
    .X(_0668_));
 sky130_fd_sc_hd__and2b_2 _1029_ (.A_N(_0667_),
    .B(_0668_),
    .X(_0058_));
 sky130_fd_sc_hd__xor2_2 _1030_ (.A(packet_count[6]),
    .B(_0667_),
    .X(_0059_));
 sky130_fd_sc_hd__and3_2 _1031_ (.A(packet_count[6]),
    .B(packet_count[7]),
    .C(_0667_),
    .X(_0669_));
 sky130_fd_sc_hd__a21oi_2 _1032_ (.A1(packet_count[6]),
    .A2(_0667_),
    .B1(packet_count[7]),
    .Y(_0670_));
 sky130_fd_sc_hd__nor2_2 _1033_ (.A(_0669_),
    .B(_0670_),
    .Y(_0060_));
 sky130_fd_sc_hd__and2_2 _1034_ (.A(packet_count[8]),
    .B(_0669_),
    .X(_0671_));
 sky130_fd_sc_hd__nor2_2 _1035_ (.A(packet_count[8]),
    .B(_0669_),
    .Y(_0672_));
 sky130_fd_sc_hd__nor2_2 _1036_ (.A(_0671_),
    .B(_0672_),
    .Y(_0061_));
 sky130_fd_sc_hd__xor2_2 _1037_ (.A(packet_count[9]),
    .B(_0671_),
    .X(_0062_));
 sky130_fd_sc_hd__and3_2 _1038_ (.A(packet_count[9]),
    .B(packet_count[10]),
    .C(_0671_),
    .X(_0673_));
 sky130_fd_sc_hd__a21oi_2 _1039_ (.A1(packet_count[9]),
    .A2(_0671_),
    .B1(packet_count[10]),
    .Y(_0674_));
 sky130_fd_sc_hd__nor2_2 _1040_ (.A(_0673_),
    .B(_0674_),
    .Y(_0063_));
 sky130_fd_sc_hd__and2_2 _1041_ (.A(packet_count[11]),
    .B(_0673_),
    .X(_0675_));
 sky130_fd_sc_hd__nor2_2 _1042_ (.A(packet_count[11]),
    .B(_0673_),
    .Y(_0676_));
 sky130_fd_sc_hd__nor2_2 _1043_ (.A(_0675_),
    .B(_0676_),
    .Y(_0064_));
 sky130_fd_sc_hd__xor2_2 _1044_ (.A(packet_count[12]),
    .B(_0675_),
    .X(_0065_));
 sky130_fd_sc_hd__and3_2 _1045_ (.A(packet_count[12]),
    .B(packet_count[13]),
    .C(_0675_),
    .X(_0677_));
 sky130_fd_sc_hd__a31o_2 _1046_ (.A1(packet_count[11]),
    .A2(packet_count[12]),
    .A3(_0673_),
    .B1(packet_count[13]),
    .X(_0678_));
 sky130_fd_sc_hd__and2b_2 _1047_ (.A_N(_0677_),
    .B(_0678_),
    .X(_0066_));
 sky130_fd_sc_hd__nand2_2 _1048_ (.A(packet_count[14]),
    .B(_0677_),
    .Y(_0679_));
 sky130_fd_sc_hd__xor2_2 _1049_ (.A(packet_count[14]),
    .B(_0677_),
    .X(_0067_));
 sky130_fd_sc_hd__xnor2_2 _1050_ (.A(packet_count[15]),
    .B(_0679_),
    .Y(_0068_));
 sky130_fd_sc_hd__o21ba_2 _1051_ (.A1(packet_done_event),
    .A2(\irq_status[0] ),
    .B1_N(\irq_clear[0] ),
    .X(_0069_));
 sky130_fd_sc_hd__nor3b_2 _1052_ (.A(_0436_),
    .B(wr_addr[2]),
    .C_N(wr_addr[3]),
    .Y(_0680_));
 sky130_fd_sc_hd__mux2_1 _1053_ (.A0(\packet_len[0] ),
    .A1(wr_data[0]),
    .S(_0680_),
    .X(_0070_));
 sky130_fd_sc_hd__mux2_1 _1054_ (.A0(\packet_len[1] ),
    .A1(wr_data[1]),
    .S(_0680_),
    .X(_0071_));
 sky130_fd_sc_hd__mux2_1 _1055_ (.A0(\packet_len[2] ),
    .A1(wr_data[2]),
    .S(_0680_),
    .X(_0072_));
 sky130_fd_sc_hd__mux2_1 _1056_ (.A0(\packet_len[3] ),
    .A1(wr_data[3]),
    .S(_0680_),
    .X(_0073_));
 sky130_fd_sc_hd__mux2_1 _1057_ (.A0(\packet_len[4] ),
    .A1(wr_data[4]),
    .S(_0680_),
    .X(_0074_));
 sky130_fd_sc_hd__mux2_1 _1058_ (.A0(\packet_len[5] ),
    .A1(wr_data[5]),
    .S(_0680_),
    .X(_0075_));
 sky130_fd_sc_hd__mux2_1 _1059_ (.A0(\packet_len[6] ),
    .A1(wr_data[6]),
    .S(_0680_),
    .X(_0076_));
 sky130_fd_sc_hd__mux2_1 _1060_ (.A0(\packet_len[7] ),
    .A1(wr_data[7]),
    .S(_0680_),
    .X(_0077_));
 sky130_fd_sc_hd__or3b_2 _1061_ (.A(wr_addr[3]),
    .B(_0436_),
    .C_N(wr_addr[2]),
    .X(_0681_));
 sky130_fd_sc_hd__mux2_1 _1062_ (.A0(wr_data[0]),
    .A1(\baud_div[0] ),
    .S(_0681_),
    .X(_0078_));
 sky130_fd_sc_hd__mux2_1 _1063_ (.A0(wr_data[1]),
    .A1(\baud_div[1] ),
    .S(_0681_),
    .X(_0079_));
 sky130_fd_sc_hd__mux2_1 _1064_ (.A0(wr_data[2]),
    .A1(\baud_div[2] ),
    .S(_0681_),
    .X(_0080_));
 sky130_fd_sc_hd__mux2_1 _1065_ (.A0(wr_data[3]),
    .A1(\baud_div[3] ),
    .S(_0681_),
    .X(_0081_));
 sky130_fd_sc_hd__mux2_1 _1066_ (.A0(wr_data[4]),
    .A1(\baud_div[4] ),
    .S(_0681_),
    .X(_0082_));
 sky130_fd_sc_hd__mux2_1 _1067_ (.A0(wr_data[5]),
    .A1(\baud_div[5] ),
    .S(_0681_),
    .X(_0083_));
 sky130_fd_sc_hd__mux2_1 _1068_ (.A0(wr_data[6]),
    .A1(\baud_div[6] ),
    .S(_0681_),
    .X(_0084_));
 sky130_fd_sc_hd__mux2_1 _1069_ (.A0(wr_data[7]),
    .A1(\baud_div[7] ),
    .S(_0681_),
    .X(_0085_));
 sky130_fd_sc_hd__nor3_2 _1070_ (.A(wr_addr[2]),
    .B(wr_addr[3]),
    .C(_0436_),
    .Y(_0682_));
 sky130_fd_sc_hd__mux2_1 _1071_ (.A0(control_enable),
    .A1(wr_data[0]),
    .S(_0682_),
    .X(_0086_));
 sky130_fd_sc_hd__mux2_1 _1072_ (.A0(control_rx_enable),
    .A1(wr_data[1]),
    .S(_0682_),
    .X(_0087_));
 sky130_fd_sc_hd__mux2_1 _1073_ (.A0(control_tx_enable),
    .A1(wr_data[2]),
    .S(_0682_),
    .X(_0088_));
 sky130_fd_sc_hd__mux2_1 _1074_ (.A0(control_loopback),
    .A1(wr_data[3]),
    .S(_0682_),
    .X(_0089_));
 sky130_fd_sc_hd__mux2_1 _1075_ (.A0(control_irq_enable),
    .A1(wr_data[4]),
    .S(_0682_),
    .X(_0090_));
 sky130_fd_sc_hd__nor2_2 _1076_ (.A(_0582_),
    .B(_0659_),
    .Y(_0683_));
 sky130_fd_sc_hd__mux2_1 _1077_ (.A0(_0683_),
    .A1(_0582_),
    .S(\u_uart_rx_engine.rx_packet_count[0] ),
    .X(_0091_));
 sky130_fd_sc_hd__nor2_2 _1078_ (.A(_0582_),
    .B(_0641_),
    .Y(_0684_));
 sky130_fd_sc_hd__a22o_2 _1079_ (.A1(\u_uart_rx_engine.rx_packet_count[1] ),
    .A2(_0582_),
    .B1(_0660_),
    .B2(_0684_),
    .X(_0092_));
 sky130_fd_sc_hd__nor2_2 _1080_ (.A(_0582_),
    .B(_0645_),
    .Y(_0685_));
 sky130_fd_sc_hd__a22o_2 _1081_ (.A1(\u_uart_rx_engine.rx_packet_count[2] ),
    .A2(_0582_),
    .B1(_0660_),
    .B2(_0685_),
    .X(_0093_));
 sky130_fd_sc_hd__nor2_2 _1082_ (.A(_0582_),
    .B(_0650_),
    .Y(_0686_));
 sky130_fd_sc_hd__a22o_2 _1083_ (.A1(\u_uart_rx_engine.rx_packet_count[3] ),
    .A2(_0582_),
    .B1(_0660_),
    .B2(_0686_),
    .X(_0094_));
 sky130_fd_sc_hd__nor2_2 _1084_ (.A(_0582_),
    .B(_0638_),
    .Y(_0687_));
 sky130_fd_sc_hd__a22o_2 _1085_ (.A1(\u_uart_rx_engine.rx_packet_count[4] ),
    .A2(_0582_),
    .B1(_0660_),
    .B2(_0687_),
    .X(_0095_));
 sky130_fd_sc_hd__and2_2 _1086_ (.A(\u_uart_rx_engine.rx_packet_count[5] ),
    .B(_0582_),
    .X(_0688_));
 sky130_fd_sc_hd__a31o_2 _1087_ (.A1(_0581_),
    .A2(_0654_),
    .A3(_0660_),
    .B1(_0688_),
    .X(_0096_));
 sky130_fd_sc_hd__and2_2 _1088_ (.A(\u_uart_rx_engine.rx_packet_count[6] ),
    .B(_0582_),
    .X(_0689_));
 sky130_fd_sc_hd__a31o_2 _1089_ (.A1(_0581_),
    .A2(_0637_),
    .A3(_0660_),
    .B1(_0689_),
    .X(_0097_));
 sky130_fd_sc_hd__nor2_2 _1090_ (.A(_0582_),
    .B(_0657_),
    .Y(_0690_));
 sky130_fd_sc_hd__a22o_2 _1091_ (.A1(\u_uart_rx_engine.rx_packet_count[7] ),
    .A2(_0582_),
    .B1(_0660_),
    .B2(_0690_),
    .X(_0098_));
 sky130_fd_sc_hd__or3_2 _1092_ (.A(\u_uart_tx_engine.tx_wr_ptr[0] ),
    .B(\u_uart_tx_engine.tx_wr_ptr[1] ),
    .C(_0567_),
    .X(_0691_));
 sky130_fd_sc_hd__inv_2 _1093_ (.A(_0691_),
    .Y(_0692_));
 sky130_fd_sc_hd__and2b_2 _1094_ (.A_N(\u_uart_tx_engine.tx_wr_ptr[2] ),
    .B(\u_uart_tx_engine.tx_wr_ptr[3] ),
    .X(_0693_));
 sky130_fd_sc_hd__and2_2 _1095_ (.A(_0692_),
    .B(_0693_),
    .X(_0694_));
 sky130_fd_sc_hd__mux2_1 _1096_ (.A0(\u_uart_tx_engine.tx_fifo_mem[8][0] ),
    .A1(\tx_data_byte[0] ),
    .S(_0694_),
    .X(_0099_));
 sky130_fd_sc_hd__mux2_1 _1097_ (.A0(\u_uart_tx_engine.tx_fifo_mem[8][1] ),
    .A1(\tx_data_byte[1] ),
    .S(_0694_),
    .X(_0100_));
 sky130_fd_sc_hd__mux2_1 _1098_ (.A0(\u_uart_tx_engine.tx_fifo_mem[8][2] ),
    .A1(\tx_data_byte[2] ),
    .S(_0694_),
    .X(_0101_));
 sky130_fd_sc_hd__mux2_1 _1099_ (.A0(\u_uart_tx_engine.tx_fifo_mem[8][3] ),
    .A1(\tx_data_byte[3] ),
    .S(_0694_),
    .X(_0102_));
 sky130_fd_sc_hd__mux2_1 _1100_ (.A0(\u_uart_tx_engine.tx_fifo_mem[8][4] ),
    .A1(\tx_data_byte[4] ),
    .S(_0694_),
    .X(_0103_));
 sky130_fd_sc_hd__mux2_1 _1101_ (.A0(\u_uart_tx_engine.tx_fifo_mem[8][5] ),
    .A1(\tx_data_byte[5] ),
    .S(_0694_),
    .X(_0104_));
 sky130_fd_sc_hd__mux2_1 _1102_ (.A0(\u_uart_tx_engine.tx_fifo_mem[8][6] ),
    .A1(\tx_data_byte[6] ),
    .S(_0694_),
    .X(_0105_));
 sky130_fd_sc_hd__nand2_2 _1103_ (.A(\u_uart_tx_engine.tx_wr_ptr[0] ),
    .B(_0566_),
    .Y(_0695_));
 sky130_fd_sc_hd__and3_2 _1104_ (.A(\u_uart_tx_engine.tx_wr_ptr[0] ),
    .B(\u_uart_tx_engine.tx_wr_ptr[1] ),
    .C(_0566_),
    .X(_0696_));
 sky130_fd_sc_hd__nand2_2 _1105_ (.A(\u_uart_tx_engine.tx_wr_ptr[2] ),
    .B(_0696_),
    .Y(_0697_));
 sky130_fd_sc_hd__or2_2 _1106_ (.A(\u_uart_tx_engine.tx_wr_ptr[3] ),
    .B(_0697_),
    .X(_0698_));
 sky130_fd_sc_hd__mux2_1 _1107_ (.A0(\tx_data_byte[0] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[7][0] ),
    .S(_0698_),
    .X(_0106_));
 sky130_fd_sc_hd__mux2_1 _1108_ (.A0(\tx_data_byte[1] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[7][1] ),
    .S(_0698_),
    .X(_0107_));
 sky130_fd_sc_hd__mux2_1 _1109_ (.A0(\tx_data_byte[2] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[7][2] ),
    .S(_0698_),
    .X(_0108_));
 sky130_fd_sc_hd__mux2_1 _1110_ (.A0(\tx_data_byte[3] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[7][3] ),
    .S(_0698_),
    .X(_0109_));
 sky130_fd_sc_hd__mux2_1 _1111_ (.A0(\tx_data_byte[4] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[7][4] ),
    .S(_0698_),
    .X(_0110_));
 sky130_fd_sc_hd__mux2_1 _1112_ (.A0(\tx_data_byte[5] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[7][5] ),
    .S(_0698_),
    .X(_0111_));
 sky130_fd_sc_hd__mux2_1 _1113_ (.A0(\tx_data_byte[6] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[7][6] ),
    .S(_0698_),
    .X(_0112_));
 sky130_fd_sc_hd__and3b_2 _1114_ (.A_N(\u_uart_tx_engine.tx_wr_ptr[0] ),
    .B(\u_uart_tx_engine.tx_wr_ptr[1] ),
    .C(_0566_),
    .X(_0699_));
 sky130_fd_sc_hd__nand3b_2 _1115_ (.A_N(\u_uart_tx_engine.tx_wr_ptr[3] ),
    .B(\u_uart_tx_engine.tx_wr_ptr[2] ),
    .C(_0699_),
    .Y(_0700_));
 sky130_fd_sc_hd__mux2_1 _1116_ (.A0(\tx_data_byte[0] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[6][0] ),
    .S(_0700_),
    .X(_0113_));
 sky130_fd_sc_hd__mux2_1 _1117_ (.A0(\tx_data_byte[1] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[6][1] ),
    .S(_0700_),
    .X(_0114_));
 sky130_fd_sc_hd__mux2_1 _1118_ (.A0(\tx_data_byte[2] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[6][2] ),
    .S(_0700_),
    .X(_0115_));
 sky130_fd_sc_hd__mux2_1 _1119_ (.A0(\tx_data_byte[3] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[6][3] ),
    .S(_0700_),
    .X(_0116_));
 sky130_fd_sc_hd__mux2_1 _1120_ (.A0(\tx_data_byte[4] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[6][4] ),
    .S(_0700_),
    .X(_0117_));
 sky130_fd_sc_hd__mux2_1 _1121_ (.A0(\tx_data_byte[5] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[6][5] ),
    .S(_0700_),
    .X(_0118_));
 sky130_fd_sc_hd__mux2_1 _1122_ (.A0(\tx_data_byte[6] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[6][6] ),
    .S(_0700_),
    .X(_0119_));
 sky130_fd_sc_hd__nor2_2 _1123_ (.A(\u_uart_tx_engine.tx_wr_ptr[1] ),
    .B(_0695_),
    .Y(_0263_));
 sky130_fd_sc_hd__and3_2 _1124_ (.A(\u_uart_tx_engine.tx_wr_ptr[3] ),
    .B(\u_uart_tx_engine.tx_wr_ptr[2] ),
    .C(_0263_),
    .X(_0264_));
 sky130_fd_sc_hd__mux2_1 _1125_ (.A0(\u_uart_tx_engine.tx_fifo_mem[13][0] ),
    .A1(\tx_data_byte[0] ),
    .S(_0264_),
    .X(_0120_));
 sky130_fd_sc_hd__mux2_1 _1126_ (.A0(\u_uart_tx_engine.tx_fifo_mem[13][1] ),
    .A1(\tx_data_byte[1] ),
    .S(_0264_),
    .X(_0121_));
 sky130_fd_sc_hd__mux2_1 _1127_ (.A0(\u_uart_tx_engine.tx_fifo_mem[13][2] ),
    .A1(\tx_data_byte[2] ),
    .S(_0264_),
    .X(_0122_));
 sky130_fd_sc_hd__mux2_1 _1128_ (.A0(\u_uart_tx_engine.tx_fifo_mem[13][3] ),
    .A1(\tx_data_byte[3] ),
    .S(_0264_),
    .X(_0123_));
 sky130_fd_sc_hd__mux2_1 _1129_ (.A0(\u_uart_tx_engine.tx_fifo_mem[13][4] ),
    .A1(\tx_data_byte[4] ),
    .S(_0264_),
    .X(_0124_));
 sky130_fd_sc_hd__mux2_1 _1130_ (.A0(\u_uart_tx_engine.tx_fifo_mem[13][5] ),
    .A1(\tx_data_byte[5] ),
    .S(_0264_),
    .X(_0125_));
 sky130_fd_sc_hd__mux2_1 _1131_ (.A0(\u_uart_tx_engine.tx_fifo_mem[13][6] ),
    .A1(\tx_data_byte[6] ),
    .S(_0264_),
    .X(_0126_));
 sky130_fd_sc_hd__or4b_2 _1132_ (.A(\u_uart_tx_engine.tx_wr_ptr[1] ),
    .B(_0695_),
    .C(\u_uart_tx_engine.tx_wr_ptr[3] ),
    .D_N(\u_uart_tx_engine.tx_wr_ptr[2] ),
    .X(_0265_));
 sky130_fd_sc_hd__mux2_1 _1133_ (.A0(\tx_data_byte[0] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[5][0] ),
    .S(_0265_),
    .X(_0127_));
 sky130_fd_sc_hd__mux2_1 _1134_ (.A0(\tx_data_byte[1] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[5][1] ),
    .S(_0265_),
    .X(_0128_));
 sky130_fd_sc_hd__mux2_1 _1135_ (.A0(\tx_data_byte[2] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[5][2] ),
    .S(_0265_),
    .X(_0129_));
 sky130_fd_sc_hd__mux2_1 _1136_ (.A0(\tx_data_byte[3] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[5][3] ),
    .S(_0265_),
    .X(_0130_));
 sky130_fd_sc_hd__mux2_1 _1137_ (.A0(\tx_data_byte[4] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[5][4] ),
    .S(_0265_),
    .X(_0131_));
 sky130_fd_sc_hd__mux2_1 _1138_ (.A0(\tx_data_byte[5] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[5][5] ),
    .S(_0265_),
    .X(_0132_));
 sky130_fd_sc_hd__mux2_1 _1139_ (.A0(\tx_data_byte[6] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[5][6] ),
    .S(_0265_),
    .X(_0133_));
 sky130_fd_sc_hd__and3b_2 _1140_ (.A_N(\u_uart_tx_engine.tx_wr_ptr[3] ),
    .B(\u_uart_tx_engine.tx_wr_ptr[2] ),
    .C(_0692_),
    .X(_0266_));
 sky130_fd_sc_hd__mux2_1 _1141_ (.A0(\u_uart_tx_engine.tx_fifo_mem[4][0] ),
    .A1(\tx_data_byte[0] ),
    .S(_0266_),
    .X(_0134_));
 sky130_fd_sc_hd__mux2_1 _1142_ (.A0(\u_uart_tx_engine.tx_fifo_mem[4][1] ),
    .A1(\tx_data_byte[1] ),
    .S(_0266_),
    .X(_0135_));
 sky130_fd_sc_hd__mux2_1 _1143_ (.A0(\u_uart_tx_engine.tx_fifo_mem[4][2] ),
    .A1(\tx_data_byte[2] ),
    .S(_0266_),
    .X(_0136_));
 sky130_fd_sc_hd__mux2_1 _1144_ (.A0(\u_uart_tx_engine.tx_fifo_mem[4][3] ),
    .A1(\tx_data_byte[3] ),
    .S(_0266_),
    .X(_0137_));
 sky130_fd_sc_hd__mux2_1 _1145_ (.A0(\u_uart_tx_engine.tx_fifo_mem[4][4] ),
    .A1(\tx_data_byte[4] ),
    .S(_0266_),
    .X(_0138_));
 sky130_fd_sc_hd__mux2_1 _1146_ (.A0(\u_uart_tx_engine.tx_fifo_mem[4][5] ),
    .A1(\tx_data_byte[5] ),
    .S(_0266_),
    .X(_0139_));
 sky130_fd_sc_hd__mux2_1 _1147_ (.A0(\u_uart_tx_engine.tx_fifo_mem[4][6] ),
    .A1(\tx_data_byte[6] ),
    .S(_0266_),
    .X(_0140_));
 sky130_fd_sc_hd__or3b_2 _1148_ (.A(\u_uart_tx_engine.tx_wr_ptr[3] ),
    .B(\u_uart_tx_engine.tx_wr_ptr[2] ),
    .C_N(_0696_),
    .X(_0267_));
 sky130_fd_sc_hd__mux2_1 _1149_ (.A0(\tx_data_byte[0] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[3][0] ),
    .S(_0267_),
    .X(_0141_));
 sky130_fd_sc_hd__mux2_1 _1150_ (.A0(\tx_data_byte[1] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[3][1] ),
    .S(_0267_),
    .X(_0142_));
 sky130_fd_sc_hd__mux2_1 _1151_ (.A0(\tx_data_byte[2] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[3][2] ),
    .S(_0267_),
    .X(_0143_));
 sky130_fd_sc_hd__mux2_1 _1152_ (.A0(\tx_data_byte[3] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[3][3] ),
    .S(_0267_),
    .X(_0144_));
 sky130_fd_sc_hd__mux2_1 _1153_ (.A0(\tx_data_byte[4] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[3][4] ),
    .S(_0267_),
    .X(_0145_));
 sky130_fd_sc_hd__mux2_1 _1154_ (.A0(\tx_data_byte[5] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[3][5] ),
    .S(_0267_),
    .X(_0146_));
 sky130_fd_sc_hd__mux2_1 _1155_ (.A0(\tx_data_byte[6] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[3][6] ),
    .S(_0267_),
    .X(_0147_));
 sky130_fd_sc_hd__and3_2 _1156_ (.A(\u_uart_tx_engine.tx_wr_ptr[3] ),
    .B(\u_uart_tx_engine.tx_wr_ptr[2] ),
    .C(_0699_),
    .X(_0268_));
 sky130_fd_sc_hd__mux2_1 _1157_ (.A0(\u_uart_tx_engine.tx_fifo_mem[14][0] ),
    .A1(\tx_data_byte[0] ),
    .S(_0268_),
    .X(_0148_));
 sky130_fd_sc_hd__mux2_1 _1158_ (.A0(\u_uart_tx_engine.tx_fifo_mem[14][1] ),
    .A1(\tx_data_byte[1] ),
    .S(_0268_),
    .X(_0149_));
 sky130_fd_sc_hd__mux2_1 _1159_ (.A0(\u_uart_tx_engine.tx_fifo_mem[14][2] ),
    .A1(\tx_data_byte[2] ),
    .S(_0268_),
    .X(_0150_));
 sky130_fd_sc_hd__mux2_1 _1160_ (.A0(\u_uart_tx_engine.tx_fifo_mem[14][3] ),
    .A1(\tx_data_byte[3] ),
    .S(_0268_),
    .X(_0151_));
 sky130_fd_sc_hd__mux2_1 _1161_ (.A0(\u_uart_tx_engine.tx_fifo_mem[14][4] ),
    .A1(\tx_data_byte[4] ),
    .S(_0268_),
    .X(_0152_));
 sky130_fd_sc_hd__mux2_1 _1162_ (.A0(\u_uart_tx_engine.tx_fifo_mem[14][5] ),
    .A1(\tx_data_byte[5] ),
    .S(_0268_),
    .X(_0153_));
 sky130_fd_sc_hd__mux2_1 _1163_ (.A0(\u_uart_tx_engine.tx_fifo_mem[14][6] ),
    .A1(\tx_data_byte[6] ),
    .S(_0268_),
    .X(_0154_));
 sky130_fd_sc_hd__or3b_2 _1164_ (.A(\u_uart_tx_engine.tx_wr_ptr[3] ),
    .B(\u_uart_tx_engine.tx_wr_ptr[2] ),
    .C_N(_0699_),
    .X(_0269_));
 sky130_fd_sc_hd__mux2_1 _1165_ (.A0(\tx_data_byte[0] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[2][0] ),
    .S(_0269_),
    .X(_0155_));
 sky130_fd_sc_hd__mux2_1 _1166_ (.A0(\tx_data_byte[1] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[2][1] ),
    .S(_0269_),
    .X(_0156_));
 sky130_fd_sc_hd__mux2_1 _1167_ (.A0(\tx_data_byte[2] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[2][2] ),
    .S(_0269_),
    .X(_0157_));
 sky130_fd_sc_hd__mux2_1 _1168_ (.A0(\tx_data_byte[3] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[2][3] ),
    .S(_0269_),
    .X(_0158_));
 sky130_fd_sc_hd__mux2_1 _1169_ (.A0(\tx_data_byte[4] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[2][4] ),
    .S(_0269_),
    .X(_0159_));
 sky130_fd_sc_hd__mux2_1 _1170_ (.A0(\tx_data_byte[5] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[2][5] ),
    .S(_0269_),
    .X(_0160_));
 sky130_fd_sc_hd__mux2_1 _1171_ (.A0(\tx_data_byte[6] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[2][6] ),
    .S(_0269_),
    .X(_0161_));
 sky130_fd_sc_hd__or4_2 _1172_ (.A(\u_uart_tx_engine.tx_wr_ptr[1] ),
    .B(\u_uart_tx_engine.tx_wr_ptr[3] ),
    .C(\u_uart_tx_engine.tx_wr_ptr[2] ),
    .D(_0695_),
    .X(_0270_));
 sky130_fd_sc_hd__mux2_1 _1173_ (.A0(\tx_data_byte[0] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[1][0] ),
    .S(_0270_),
    .X(_0162_));
 sky130_fd_sc_hd__mux2_1 _1174_ (.A0(\tx_data_byte[1] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[1][1] ),
    .S(_0270_),
    .X(_0163_));
 sky130_fd_sc_hd__mux2_1 _1175_ (.A0(\tx_data_byte[2] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[1][2] ),
    .S(_0270_),
    .X(_0164_));
 sky130_fd_sc_hd__mux2_1 _1176_ (.A0(\tx_data_byte[3] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[1][3] ),
    .S(_0270_),
    .X(_0165_));
 sky130_fd_sc_hd__mux2_1 _1177_ (.A0(\tx_data_byte[4] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[1][4] ),
    .S(_0270_),
    .X(_0166_));
 sky130_fd_sc_hd__mux2_1 _1178_ (.A0(\tx_data_byte[5] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[1][5] ),
    .S(_0270_),
    .X(_0167_));
 sky130_fd_sc_hd__mux2_1 _1179_ (.A0(\tx_data_byte[6] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[1][6] ),
    .S(_0270_),
    .X(_0168_));
 sky130_fd_sc_hd__nand2_2 _1180_ (.A(_0693_),
    .B(_0699_),
    .Y(_0271_));
 sky130_fd_sc_hd__mux2_1 _1181_ (.A0(\tx_data_byte[0] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[10][0] ),
    .S(_0271_),
    .X(_0169_));
 sky130_fd_sc_hd__mux2_1 _1182_ (.A0(\tx_data_byte[1] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[10][1] ),
    .S(_0271_),
    .X(_0170_));
 sky130_fd_sc_hd__mux2_1 _1183_ (.A0(\tx_data_byte[2] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[10][2] ),
    .S(_0271_),
    .X(_0171_));
 sky130_fd_sc_hd__mux2_1 _1184_ (.A0(\tx_data_byte[3] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[10][3] ),
    .S(_0271_),
    .X(_0172_));
 sky130_fd_sc_hd__mux2_1 _1185_ (.A0(\tx_data_byte[4] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[10][4] ),
    .S(_0271_),
    .X(_0173_));
 sky130_fd_sc_hd__mux2_1 _1186_ (.A0(\tx_data_byte[5] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[10][5] ),
    .S(_0271_),
    .X(_0174_));
 sky130_fd_sc_hd__mux2_1 _1187_ (.A0(\tx_data_byte[6] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[10][6] ),
    .S(_0271_),
    .X(_0175_));
 sky130_fd_sc_hd__nor3_2 _1188_ (.A(\u_uart_tx_engine.tx_wr_ptr[3] ),
    .B(\u_uart_tx_engine.tx_wr_ptr[2] ),
    .C(_0691_),
    .Y(_0272_));
 sky130_fd_sc_hd__mux2_1 _1189_ (.A0(\u_uart_tx_engine.tx_fifo_mem[0][0] ),
    .A1(\tx_data_byte[0] ),
    .S(_0272_),
    .X(_0176_));
 sky130_fd_sc_hd__mux2_1 _1190_ (.A0(\u_uart_tx_engine.tx_fifo_mem[0][1] ),
    .A1(\tx_data_byte[1] ),
    .S(_0272_),
    .X(_0177_));
 sky130_fd_sc_hd__mux2_1 _1191_ (.A0(\u_uart_tx_engine.tx_fifo_mem[0][2] ),
    .A1(\tx_data_byte[2] ),
    .S(_0272_),
    .X(_0178_));
 sky130_fd_sc_hd__mux2_1 _1192_ (.A0(\u_uart_tx_engine.tx_fifo_mem[0][3] ),
    .A1(\tx_data_byte[3] ),
    .S(_0272_),
    .X(_0179_));
 sky130_fd_sc_hd__mux2_1 _1193_ (.A0(\u_uart_tx_engine.tx_fifo_mem[0][4] ),
    .A1(\tx_data_byte[4] ),
    .S(_0272_),
    .X(_0180_));
 sky130_fd_sc_hd__mux2_1 _1194_ (.A0(\u_uart_tx_engine.tx_fifo_mem[0][5] ),
    .A1(\tx_data_byte[5] ),
    .S(_0272_),
    .X(_0181_));
 sky130_fd_sc_hd__mux2_1 _1195_ (.A0(\u_uart_tx_engine.tx_fifo_mem[0][6] ),
    .A1(\tx_data_byte[6] ),
    .S(_0272_),
    .X(_0182_));
 sky130_fd_sc_hd__or3b_2 _1196_ (.A(\u_uart_tx_engine.tx_bit_index[1] ),
    .B(\u_uart_tx_engine.tx_shift_reg[5] ),
    .C_N(\u_uart_tx_engine.tx_bit_index[0] ),
    .X(_0273_));
 sky130_fd_sc_hd__mux2_1 _1197_ (.A0(\u_uart_tx_engine.tx_shift_reg[4] ),
    .A1(\u_uart_tx_engine.tx_shift_reg[6] ),
    .S(\u_uart_tx_engine.tx_bit_index[1] ),
    .X(_0274_));
 sky130_fd_sc_hd__o21ai_2 _1198_ (.A1(\u_uart_tx_engine.tx_bit_index[0] ),
    .A2(_0274_),
    .B1(_0273_),
    .Y(_0275_));
 sky130_fd_sc_hd__mux4_2 _1199_ (.A0(\u_uart_tx_engine.tx_shift_reg[0] ),
    .A1(\u_uart_tx_engine.tx_shift_reg[1] ),
    .A2(\u_uart_tx_engine.tx_shift_reg[2] ),
    .A3(\u_uart_tx_engine.tx_shift_reg[3] ),
    .S0(\u_uart_tx_engine.tx_bit_index[0] ),
    .S1(\u_uart_tx_engine.tx_bit_index[1] ),
    .X(_0276_));
 sky130_fd_sc_hd__o21ai_2 _1200_ (.A1(\u_uart_tx_engine.tx_bit_index[2] ),
    .A2(_0276_),
    .B1(_0625_),
    .Y(_0277_));
 sky130_fd_sc_hd__a21o_2 _1201_ (.A1(\u_uart_tx_engine.tx_bit_index[2] ),
    .A2(_0275_),
    .B1(_0277_),
    .X(_0278_));
 sky130_fd_sc_hd__nor2_2 _1202_ (.A(uart_tx),
    .B(_0561_),
    .Y(_0279_));
 sky130_fd_sc_hd__o311a_2 _1203_ (.A1(\u_uart_tx_engine.tx_count[4] ),
    .A2(status_tx_busy),
    .A3(_0439_),
    .B1(_0560_),
    .C1(baud_tick),
    .X(_0280_));
 sky130_fd_sc_hd__o21ai_2 _1204_ (.A1(_0279_),
    .A2(_0280_),
    .B1(_0278_),
    .Y(_0183_));
 sky130_fd_sc_hd__nand2_2 _1205_ (.A(_0693_),
    .B(_0696_),
    .Y(_0281_));
 sky130_fd_sc_hd__mux2_1 _1206_ (.A0(\tx_data_byte[0] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[11][0] ),
    .S(_0281_),
    .X(_0184_));
 sky130_fd_sc_hd__mux2_1 _1207_ (.A0(\tx_data_byte[1] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[11][1] ),
    .S(_0281_),
    .X(_0185_));
 sky130_fd_sc_hd__mux2_1 _1208_ (.A0(\tx_data_byte[2] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[11][2] ),
    .S(_0281_),
    .X(_0186_));
 sky130_fd_sc_hd__mux2_1 _1209_ (.A0(\tx_data_byte[3] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[11][3] ),
    .S(_0281_),
    .X(_0187_));
 sky130_fd_sc_hd__mux2_1 _1210_ (.A0(\tx_data_byte[4] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[11][4] ),
    .S(_0281_),
    .X(_0188_));
 sky130_fd_sc_hd__mux2_1 _1211_ (.A0(\tx_data_byte[5] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[11][5] ),
    .S(_0281_),
    .X(_0189_));
 sky130_fd_sc_hd__mux2_1 _1212_ (.A0(\tx_data_byte[6] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[11][6] ),
    .S(_0281_),
    .X(_0190_));
 sky130_fd_sc_hd__a21oi_2 _1213_ (.A1(_0402_),
    .A2(_0562_),
    .B1(_0628_),
    .Y(_0191_));
 sky130_fd_sc_hd__nand2_2 _1214_ (.A(_0693_),
    .B(_0263_),
    .Y(_0282_));
 sky130_fd_sc_hd__mux2_1 _1215_ (.A0(\tx_data_byte[0] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[9][0] ),
    .S(_0282_),
    .X(_0192_));
 sky130_fd_sc_hd__mux2_1 _1216_ (.A0(\tx_data_byte[1] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[9][1] ),
    .S(_0282_),
    .X(_0193_));
 sky130_fd_sc_hd__mux2_1 _1217_ (.A0(\tx_data_byte[2] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[9][2] ),
    .S(_0282_),
    .X(_0194_));
 sky130_fd_sc_hd__mux2_1 _1218_ (.A0(\tx_data_byte[3] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[9][3] ),
    .S(_0282_),
    .X(_0195_));
 sky130_fd_sc_hd__mux2_1 _1219_ (.A0(\tx_data_byte[4] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[9][4] ),
    .S(_0282_),
    .X(_0196_));
 sky130_fd_sc_hd__mux2_1 _1220_ (.A0(\tx_data_byte[5] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[9][5] ),
    .S(_0282_),
    .X(_0197_));
 sky130_fd_sc_hd__mux2_1 _1221_ (.A0(\tx_data_byte[6] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[9][6] ),
    .S(_0282_),
    .X(_0198_));
 sky130_fd_sc_hd__and2b_2 _1222_ (.A_N(_0630_),
    .B(_0621_),
    .X(_0283_));
 sky130_fd_sc_hd__mux2_1 _1223_ (.A0(_0283_),
    .A1(_0629_),
    .S(\u_uart_tx_engine.tx_packet_count[0] ),
    .X(_0199_));
 sky130_fd_sc_hd__a22o_2 _1224_ (.A1(\u_uart_tx_engine.tx_packet_count[1] ),
    .A2(_0629_),
    .B1(_0283_),
    .B2(_0603_),
    .X(_0200_));
 sky130_fd_sc_hd__a22o_2 _1225_ (.A1(\u_uart_tx_engine.tx_packet_count[2] ),
    .A2(_0629_),
    .B1(_0283_),
    .B2(_0607_),
    .X(_0201_));
 sky130_fd_sc_hd__a22o_2 _1226_ (.A1(\u_uart_tx_engine.tx_packet_count[3] ),
    .A2(_0629_),
    .B1(_0283_),
    .B2(_0611_),
    .X(_0202_));
 sky130_fd_sc_hd__a22o_2 _1227_ (.A1(\u_uart_tx_engine.tx_packet_count[4] ),
    .A2(_0629_),
    .B1(_0283_),
    .B2(_0600_),
    .X(_0203_));
 sky130_fd_sc_hd__a22o_2 _1228_ (.A1(\u_uart_tx_engine.tx_packet_count[5] ),
    .A2(_0629_),
    .B1(_0283_),
    .B2(_0615_),
    .X(_0204_));
 sky130_fd_sc_hd__a22o_2 _1229_ (.A1(\u_uart_tx_engine.tx_packet_count[6] ),
    .A2(_0629_),
    .B1(_0283_),
    .B2(_0599_),
    .X(_0205_));
 sky130_fd_sc_hd__a22o_2 _1230_ (.A1(\u_uart_tx_engine.tx_packet_count[7] ),
    .A2(_0629_),
    .B1(_0283_),
    .B2(_0619_),
    .X(_0206_));
 sky130_fd_sc_hd__a21oi_2 _1231_ (.A1(_0560_),
    .A2(_0625_),
    .B1(\u_uart_tx_engine.tx_bit_index[0] ),
    .Y(_0284_));
 sky130_fd_sc_hd__a21oi_2 _1232_ (.A1(\u_uart_tx_engine.tx_bit_index[0] ),
    .A2(_0280_),
    .B1(_0284_),
    .Y(_0207_));
 sky130_fd_sc_hd__o21ai_2 _1233_ (.A1(_0563_),
    .A2(_0627_),
    .B1(_0280_),
    .Y(_0285_));
 sky130_fd_sc_hd__a21o_2 _1234_ (.A1(\u_uart_tx_engine.tx_bit_index[0] ),
    .A2(_0280_),
    .B1(\u_uart_tx_engine.tx_bit_index[1] ),
    .X(_0286_));
 sky130_fd_sc_hd__and2_2 _1235_ (.A(_0285_),
    .B(_0286_),
    .X(_0208_));
 sky130_fd_sc_hd__and4bb_2 _1236_ (.A_N(\u_uart_tx_engine.tx_bit_index[2] ),
    .B_N(_0563_),
    .C(_0627_),
    .D(_0280_),
    .X(_0287_));
 sky130_fd_sc_hd__a21o_2 _1237_ (.A1(\u_uart_tx_engine.tx_bit_index[2] ),
    .A2(_0285_),
    .B1(_0287_),
    .X(_0209_));
 sky130_fd_sc_hd__nand2b_2 _1238_ (.A_N(\u_uart_tx_engine.tx_rd_ptr[1] ),
    .B(\u_uart_tx_engine.tx_rd_ptr[0] ),
    .Y(_0288_));
 sky130_fd_sc_hd__or2_2 _1239_ (.A(\u_uart_tx_engine.tx_rd_ptr[3] ),
    .B(\u_uart_tx_engine.tx_rd_ptr[2] ),
    .X(_0289_));
 sky130_fd_sc_hd__nor2_2 _1240_ (.A(_0288_),
    .B(_0289_),
    .Y(_0290_));
 sky130_fd_sc_hd__nand2b_2 _1241_ (.A_N(\u_uart_tx_engine.tx_rd_ptr[0] ),
    .B(\u_uart_tx_engine.tx_rd_ptr[1] ),
    .Y(_0291_));
 sky130_fd_sc_hd__nand2_2 _1242_ (.A(\u_uart_tx_engine.tx_rd_ptr[3] ),
    .B(\u_uart_tx_engine.tx_rd_ptr[2] ),
    .Y(_0292_));
 sky130_fd_sc_hd__nor2_2 _1243_ (.A(_0291_),
    .B(_0292_),
    .Y(_0293_));
 sky130_fd_sc_hd__nand2_2 _1244_ (.A(\u_uart_tx_engine.tx_rd_ptr[0] ),
    .B(\u_uart_tx_engine.tx_rd_ptr[1] ),
    .Y(_0294_));
 sky130_fd_sc_hd__nor2_2 _1245_ (.A(_0292_),
    .B(_0294_),
    .Y(_0295_));
 sky130_fd_sc_hd__nand2b_2 _1246_ (.A_N(\u_uart_tx_engine.tx_rd_ptr[2] ),
    .B(\u_uart_tx_engine.tx_rd_ptr[3] ),
    .Y(_0296_));
 sky130_fd_sc_hd__nor2_2 _1247_ (.A(_0294_),
    .B(_0296_),
    .Y(_0297_));
 sky130_fd_sc_hd__nand2b_2 _1248_ (.A_N(\u_uart_tx_engine.tx_rd_ptr[3] ),
    .B(\u_uart_tx_engine.tx_rd_ptr[2] ),
    .Y(_0298_));
 sky130_fd_sc_hd__nor2_2 _1249_ (.A(_0288_),
    .B(_0298_),
    .Y(_0299_));
 sky130_fd_sc_hd__or2_2 _1250_ (.A(\u_uart_tx_engine.tx_rd_ptr[0] ),
    .B(\u_uart_tx_engine.tx_rd_ptr[1] ),
    .X(_0300_));
 sky130_fd_sc_hd__nor2_2 _1251_ (.A(_0289_),
    .B(_0300_),
    .Y(_0301_));
 sky130_fd_sc_hd__or2_2 _1252_ (.A(_0289_),
    .B(_0300_),
    .X(_0302_));
 sky130_fd_sc_hd__nor2_2 _1253_ (.A(_0289_),
    .B(_0291_),
    .Y(_0303_));
 sky130_fd_sc_hd__nor2_2 _1254_ (.A(_0288_),
    .B(_0292_),
    .Y(_0304_));
 sky130_fd_sc_hd__nor2_2 _1255_ (.A(_0289_),
    .B(_0294_),
    .Y(_0305_));
 sky130_fd_sc_hd__nor2_2 _1256_ (.A(_0291_),
    .B(_0298_),
    .Y(_0306_));
 sky130_fd_sc_hd__nor2_2 _1257_ (.A(_0292_),
    .B(_0300_),
    .Y(_0307_));
 sky130_fd_sc_hd__nor2_2 _1258_ (.A(_0291_),
    .B(_0296_),
    .Y(_0308_));
 sky130_fd_sc_hd__nor2_2 _1259_ (.A(_0288_),
    .B(_0296_),
    .Y(_0309_));
 sky130_fd_sc_hd__nor2_2 _1260_ (.A(_0296_),
    .B(_0300_),
    .Y(_0310_));
 sky130_fd_sc_hd__nor2_2 _1261_ (.A(_0294_),
    .B(_0298_),
    .Y(_0311_));
 sky130_fd_sc_hd__nor2_2 _1262_ (.A(_0298_),
    .B(_0300_),
    .Y(_0312_));
 sky130_fd_sc_hd__a22o_2 _1263_ (.A1(\u_uart_tx_engine.tx_fifo_mem[8][0] ),
    .A2(_0310_),
    .B1(_0312_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[4][0] ),
    .X(_0313_));
 sky130_fd_sc_hd__a22o_2 _1264_ (.A1(\u_uart_tx_engine.tx_fifo_mem[11][0] ),
    .A2(_0297_),
    .B1(_0308_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[10][0] ),
    .X(_0314_));
 sky130_fd_sc_hd__a22o_2 _1265_ (.A1(\u_uart_tx_engine.tx_fifo_mem[1][0] ),
    .A2(_0290_),
    .B1(_0303_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[2][0] ),
    .X(_0315_));
 sky130_fd_sc_hd__a221o_2 _1266_ (.A1(\u_uart_tx_engine.tx_fifo_mem[5][0] ),
    .A2(_0299_),
    .B1(_0311_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[7][0] ),
    .C1(_0315_),
    .X(_0316_));
 sky130_fd_sc_hd__a22o_2 _1267_ (.A1(\u_uart_tx_engine.tx_fifo_mem[3][0] ),
    .A2(_0305_),
    .B1(_0309_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[9][0] ),
    .X(_0317_));
 sky130_fd_sc_hd__a221o_2 _1268_ (.A1(\u_uart_tx_engine.tx_fifo_mem[14][0] ),
    .A2(_0293_),
    .B1(_0295_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[15][0] ),
    .C1(_0317_),
    .X(_0318_));
 sky130_fd_sc_hd__a221o_2 _1269_ (.A1(\u_uart_tx_engine.tx_fifo_mem[13][0] ),
    .A2(_0304_),
    .B1(_0306_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[6][0] ),
    .C1(_0313_),
    .X(_0319_));
 sky130_fd_sc_hd__a211o_2 _1270_ (.A1(\u_uart_tx_engine.tx_fifo_mem[12][0] ),
    .A2(_0307_),
    .B1(_0314_),
    .C1(_0301_),
    .X(_0320_));
 sky130_fd_sc_hd__or3_2 _1271_ (.A(_0318_),
    .B(_0319_),
    .C(_0320_),
    .X(_0321_));
 sky130_fd_sc_hd__o22a_2 _1272_ (.A1(\u_uart_tx_engine.tx_fifo_mem[0][0] ),
    .A2(_0302_),
    .B1(_0316_),
    .B2(_0321_),
    .X(_0322_));
 sky130_fd_sc_hd__mux2_1 _1273_ (.A0(\u_uart_tx_engine.tx_shift_reg[0] ),
    .A1(_0322_),
    .S(_0564_),
    .X(_0210_));
 sky130_fd_sc_hd__a22o_2 _1274_ (.A1(\u_uart_tx_engine.tx_fifo_mem[15][1] ),
    .A2(_0295_),
    .B1(_0299_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[5][1] ),
    .X(_0323_));
 sky130_fd_sc_hd__a22o_2 _1275_ (.A1(\u_uart_tx_engine.tx_fifo_mem[1][1] ),
    .A2(_0290_),
    .B1(_0303_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[2][1] ),
    .X(_0324_));
 sky130_fd_sc_hd__a221o_2 _1276_ (.A1(\u_uart_tx_engine.tx_fifo_mem[10][1] ),
    .A2(_0308_),
    .B1(_0311_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[7][1] ),
    .C1(_0324_),
    .X(_0325_));
 sky130_fd_sc_hd__a22o_2 _1277_ (.A1(\u_uart_tx_engine.tx_fifo_mem[12][1] ),
    .A2(_0307_),
    .B1(_0309_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[9][1] ),
    .X(_0326_));
 sky130_fd_sc_hd__a221o_2 _1278_ (.A1(\u_uart_tx_engine.tx_fifo_mem[13][1] ),
    .A2(_0304_),
    .B1(_0312_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[4][1] ),
    .C1(_0326_),
    .X(_0327_));
 sky130_fd_sc_hd__a221o_2 _1279_ (.A1(\u_uart_tx_engine.tx_fifo_mem[14][1] ),
    .A2(_0293_),
    .B1(_0310_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[8][1] ),
    .C1(_0323_),
    .X(_0328_));
 sky130_fd_sc_hd__a22o_2 _1280_ (.A1(\u_uart_tx_engine.tx_fifo_mem[3][1] ),
    .A2(_0305_),
    .B1(_0306_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[6][1] ),
    .X(_0329_));
 sky130_fd_sc_hd__a211o_2 _1281_ (.A1(\u_uart_tx_engine.tx_fifo_mem[11][1] ),
    .A2(_0297_),
    .B1(_0301_),
    .C1(_0329_),
    .X(_0330_));
 sky130_fd_sc_hd__or3_2 _1282_ (.A(_0327_),
    .B(_0328_),
    .C(_0330_),
    .X(_0331_));
 sky130_fd_sc_hd__o22a_2 _1283_ (.A1(\u_uart_tx_engine.tx_fifo_mem[0][1] ),
    .A2(_0302_),
    .B1(_0325_),
    .B2(_0331_),
    .X(_0332_));
 sky130_fd_sc_hd__mux2_1 _1284_ (.A0(\u_uart_tx_engine.tx_shift_reg[1] ),
    .A1(_0332_),
    .S(_0564_),
    .X(_0211_));
 sky130_fd_sc_hd__a22o_2 _1285_ (.A1(\u_uart_tx_engine.tx_fifo_mem[15][2] ),
    .A2(_0295_),
    .B1(_0305_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[3][2] ),
    .X(_0333_));
 sky130_fd_sc_hd__a22o_2 _1286_ (.A1(\u_uart_tx_engine.tx_fifo_mem[5][2] ),
    .A2(_0299_),
    .B1(_0308_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[10][2] ),
    .X(_0334_));
 sky130_fd_sc_hd__a22o_2 _1287_ (.A1(\u_uart_tx_engine.tx_fifo_mem[1][2] ),
    .A2(_0290_),
    .B1(_0310_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[8][2] ),
    .X(_0335_));
 sky130_fd_sc_hd__a221o_2 _1288_ (.A1(\u_uart_tx_engine.tx_fifo_mem[13][2] ),
    .A2(_0304_),
    .B1(_0311_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[7][2] ),
    .C1(_0335_),
    .X(_0336_));
 sky130_fd_sc_hd__a221o_2 _1289_ (.A1(\u_uart_tx_engine.tx_fifo_mem[6][2] ),
    .A2(_0306_),
    .B1(_0312_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[4][2] ),
    .C1(_0334_),
    .X(_0337_));
 sky130_fd_sc_hd__a22o_2 _1290_ (.A1(\u_uart_tx_engine.tx_fifo_mem[14][2] ),
    .A2(_0293_),
    .B1(_0309_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[9][2] ),
    .X(_0338_));
 sky130_fd_sc_hd__a221o_2 _1291_ (.A1(\u_uart_tx_engine.tx_fifo_mem[11][2] ),
    .A2(_0297_),
    .B1(_0303_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[2][2] ),
    .C1(_0338_),
    .X(_0339_));
 sky130_fd_sc_hd__a211o_2 _1292_ (.A1(\u_uart_tx_engine.tx_fifo_mem[12][2] ),
    .A2(_0307_),
    .B1(_0333_),
    .C1(_0301_),
    .X(_0340_));
 sky130_fd_sc_hd__or3_2 _1293_ (.A(_0337_),
    .B(_0339_),
    .C(_0340_),
    .X(_0341_));
 sky130_fd_sc_hd__o22a_2 _1294_ (.A1(\u_uart_tx_engine.tx_fifo_mem[0][2] ),
    .A2(_0302_),
    .B1(_0336_),
    .B2(_0341_),
    .X(_0342_));
 sky130_fd_sc_hd__mux2_1 _1295_ (.A0(\u_uart_tx_engine.tx_shift_reg[2] ),
    .A1(_0342_),
    .S(_0564_),
    .X(_0212_));
 sky130_fd_sc_hd__a22o_2 _1296_ (.A1(\u_uart_tx_engine.tx_fifo_mem[1][3] ),
    .A2(_0290_),
    .B1(_0295_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[15][3] ),
    .X(_0343_));
 sky130_fd_sc_hd__a221o_2 _1297_ (.A1(\u_uart_tx_engine.tx_fifo_mem[14][3] ),
    .A2(_0293_),
    .B1(_0304_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[13][3] ),
    .C1(_0343_),
    .X(_0344_));
 sky130_fd_sc_hd__a22o_2 _1298_ (.A1(\u_uart_tx_engine.tx_fifo_mem[3][3] ),
    .A2(_0305_),
    .B1(_0312_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[4][3] ),
    .X(_0345_));
 sky130_fd_sc_hd__a221o_2 _1299_ (.A1(\u_uart_tx_engine.tx_fifo_mem[6][3] ),
    .A2(_0306_),
    .B1(_0311_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[7][3] ),
    .C1(_0345_),
    .X(_0346_));
 sky130_fd_sc_hd__a22o_2 _1300_ (.A1(\u_uart_tx_engine.tx_fifo_mem[5][3] ),
    .A2(_0299_),
    .B1(_0307_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[12][3] ),
    .X(_0347_));
 sky130_fd_sc_hd__a221o_2 _1301_ (.A1(\u_uart_tx_engine.tx_fifo_mem[2][3] ),
    .A2(_0303_),
    .B1(_0309_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[9][3] ),
    .C1(_0347_),
    .X(_0348_));
 sky130_fd_sc_hd__a22o_2 _1302_ (.A1(\u_uart_tx_engine.tx_fifo_mem[10][3] ),
    .A2(_0308_),
    .B1(_0310_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[8][3] ),
    .X(_0349_));
 sky130_fd_sc_hd__a211o_2 _1303_ (.A1(\u_uart_tx_engine.tx_fifo_mem[11][3] ),
    .A2(_0297_),
    .B1(_0301_),
    .C1(_0349_),
    .X(_0350_));
 sky130_fd_sc_hd__or3_2 _1304_ (.A(_0344_),
    .B(_0348_),
    .C(_0350_),
    .X(_0351_));
 sky130_fd_sc_hd__o22a_2 _1305_ (.A1(\u_uart_tx_engine.tx_fifo_mem[0][3] ),
    .A2(_0302_),
    .B1(_0346_),
    .B2(_0351_),
    .X(_0352_));
 sky130_fd_sc_hd__mux2_1 _1306_ (.A0(\u_uart_tx_engine.tx_shift_reg[3] ),
    .A1(_0352_),
    .S(_0564_),
    .X(_0213_));
 sky130_fd_sc_hd__a22o_2 _1307_ (.A1(\u_uart_tx_engine.tx_fifo_mem[14][4] ),
    .A2(_0293_),
    .B1(_0306_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[6][4] ),
    .X(_0353_));
 sky130_fd_sc_hd__a221o_2 _1308_ (.A1(\u_uart_tx_engine.tx_fifo_mem[15][4] ),
    .A2(_0295_),
    .B1(_0303_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[2][4] ),
    .C1(_0353_),
    .X(_0354_));
 sky130_fd_sc_hd__a22o_2 _1309_ (.A1(\u_uart_tx_engine.tx_fifo_mem[11][4] ),
    .A2(_0297_),
    .B1(_0307_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[12][4] ),
    .X(_0355_));
 sky130_fd_sc_hd__a2111o_2 _1310_ (.A1(\u_uart_tx_engine.tx_fifo_mem[8][4] ),
    .A2(_0310_),
    .B1(_0354_),
    .C1(_0355_),
    .D1(_0301_),
    .X(_0356_));
 sky130_fd_sc_hd__a22o_2 _1311_ (.A1(\u_uart_tx_engine.tx_fifo_mem[5][4] ),
    .A2(_0299_),
    .B1(_0309_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[9][4] ),
    .X(_0357_));
 sky130_fd_sc_hd__a22o_2 _1312_ (.A1(\u_uart_tx_engine.tx_fifo_mem[7][4] ),
    .A2(_0311_),
    .B1(_0312_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[4][4] ),
    .X(_0358_));
 sky130_fd_sc_hd__a22o_2 _1313_ (.A1(\u_uart_tx_engine.tx_fifo_mem[1][4] ),
    .A2(_0290_),
    .B1(_0304_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[13][4] ),
    .X(_0359_));
 sky130_fd_sc_hd__a221o_2 _1314_ (.A1(\u_uart_tx_engine.tx_fifo_mem[3][4] ),
    .A2(_0305_),
    .B1(_0308_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[10][4] ),
    .C1(_0359_),
    .X(_0360_));
 sky130_fd_sc_hd__or3_2 _1315_ (.A(_0357_),
    .B(_0358_),
    .C(_0360_),
    .X(_0361_));
 sky130_fd_sc_hd__o22a_2 _1316_ (.A1(\u_uart_tx_engine.tx_fifo_mem[0][4] ),
    .A2(_0302_),
    .B1(_0356_),
    .B2(_0361_),
    .X(_0362_));
 sky130_fd_sc_hd__mux2_1 _1317_ (.A0(\u_uart_tx_engine.tx_shift_reg[4] ),
    .A1(_0362_),
    .S(_0564_),
    .X(_0214_));
 sky130_fd_sc_hd__a22o_2 _1318_ (.A1(\u_uart_tx_engine.tx_fifo_mem[9][5] ),
    .A2(_0309_),
    .B1(_0311_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[7][5] ),
    .X(_0363_));
 sky130_fd_sc_hd__a221o_2 _1319_ (.A1(\u_uart_tx_engine.tx_fifo_mem[10][5] ),
    .A2(_0308_),
    .B1(_0310_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[8][5] ),
    .C1(_0363_),
    .X(_0364_));
 sky130_fd_sc_hd__a22o_2 _1320_ (.A1(\u_uart_tx_engine.tx_fifo_mem[14][5] ),
    .A2(_0293_),
    .B1(_0295_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[15][5] ),
    .X(_0365_));
 sky130_fd_sc_hd__a22o_2 _1321_ (.A1(\u_uart_tx_engine.tx_fifo_mem[11][5] ),
    .A2(_0297_),
    .B1(_0312_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[4][5] ),
    .X(_0366_));
 sky130_fd_sc_hd__a221o_2 _1322_ (.A1(\u_uart_tx_engine.tx_fifo_mem[13][5] ),
    .A2(_0304_),
    .B1(_0305_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[3][5] ),
    .C1(_0365_),
    .X(_0367_));
 sky130_fd_sc_hd__a221o_2 _1323_ (.A1(\u_uart_tx_engine.tx_fifo_mem[5][5] ),
    .A2(_0299_),
    .B1(_0303_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[2][5] ),
    .C1(_0366_),
    .X(_0368_));
 sky130_fd_sc_hd__a22o_2 _1324_ (.A1(\u_uart_tx_engine.tx_fifo_mem[1][5] ),
    .A2(_0290_),
    .B1(_0307_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[12][5] ),
    .X(_0369_));
 sky130_fd_sc_hd__a211o_2 _1325_ (.A1(\u_uart_tx_engine.tx_fifo_mem[6][5] ),
    .A2(_0306_),
    .B1(_0369_),
    .C1(_0301_),
    .X(_0370_));
 sky130_fd_sc_hd__or3_2 _1326_ (.A(_0364_),
    .B(_0368_),
    .C(_0370_),
    .X(_0371_));
 sky130_fd_sc_hd__o221a_2 _1327_ (.A1(\u_uart_tx_engine.tx_fifo_mem[0][5] ),
    .A2(_0302_),
    .B1(_0367_),
    .B2(_0371_),
    .C1(_0564_),
    .X(_0372_));
 sky130_fd_sc_hd__a21o_2 _1328_ (.A1(\u_uart_tx_engine.tx_shift_reg[5] ),
    .A2(_0565_),
    .B1(_0372_),
    .X(_0215_));
 sky130_fd_sc_hd__a22o_2 _1329_ (.A1(\u_uart_tx_engine.tx_fifo_mem[10][6] ),
    .A2(_0308_),
    .B1(_0311_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[7][6] ),
    .X(_0373_));
 sky130_fd_sc_hd__a22o_2 _1330_ (.A1(\u_uart_tx_engine.tx_fifo_mem[5][6] ),
    .A2(_0299_),
    .B1(_0304_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[13][6] ),
    .X(_0374_));
 sky130_fd_sc_hd__a221o_2 _1331_ (.A1(\u_uart_tx_engine.tx_fifo_mem[14][6] ),
    .A2(_0293_),
    .B1(_0297_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[11][6] ),
    .C1(_0373_),
    .X(_0375_));
 sky130_fd_sc_hd__a22o_2 _1332_ (.A1(\u_uart_tx_engine.tx_fifo_mem[9][6] ),
    .A2(_0309_),
    .B1(_0310_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[8][6] ),
    .X(_0376_));
 sky130_fd_sc_hd__a221o_2 _1333_ (.A1(\u_uart_tx_engine.tx_fifo_mem[3][6] ),
    .A2(_0305_),
    .B1(_0306_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[6][6] ),
    .C1(_0376_),
    .X(_0377_));
 sky130_fd_sc_hd__a221o_2 _1334_ (.A1(\u_uart_tx_engine.tx_fifo_mem[1][6] ),
    .A2(_0290_),
    .B1(_0303_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[2][6] ),
    .C1(_0374_),
    .X(_0378_));
 sky130_fd_sc_hd__a22o_2 _1335_ (.A1(\u_uart_tx_engine.tx_fifo_mem[12][6] ),
    .A2(_0307_),
    .B1(_0312_),
    .B2(\u_uart_tx_engine.tx_fifo_mem[4][6] ),
    .X(_0379_));
 sky130_fd_sc_hd__a211o_2 _1336_ (.A1(\u_uart_tx_engine.tx_fifo_mem[15][6] ),
    .A2(_0295_),
    .B1(_0301_),
    .C1(_0379_),
    .X(_0380_));
 sky130_fd_sc_hd__or3_2 _1337_ (.A(_0377_),
    .B(_0378_),
    .C(_0380_),
    .X(_0381_));
 sky130_fd_sc_hd__o22a_2 _1338_ (.A1(\u_uart_tx_engine.tx_fifo_mem[0][6] ),
    .A2(_0302_),
    .B1(_0375_),
    .B2(_0381_),
    .X(_0382_));
 sky130_fd_sc_hd__mux2_1 _1339_ (.A0(\u_uart_tx_engine.tx_shift_reg[6] ),
    .A1(_0382_),
    .S(_0564_),
    .X(_0216_));
 sky130_fd_sc_hd__and3_2 _1340_ (.A(\u_uart_tx_engine.tx_wr_ptr[3] ),
    .B(\u_uart_tx_engine.tx_wr_ptr[2] ),
    .C(_0692_),
    .X(_0383_));
 sky130_fd_sc_hd__mux2_1 _1341_ (.A0(\u_uart_tx_engine.tx_fifo_mem[12][0] ),
    .A1(\tx_data_byte[0] ),
    .S(_0383_),
    .X(_0217_));
 sky130_fd_sc_hd__mux2_1 _1342_ (.A0(\u_uart_tx_engine.tx_fifo_mem[12][1] ),
    .A1(\tx_data_byte[1] ),
    .S(_0383_),
    .X(_0218_));
 sky130_fd_sc_hd__mux2_1 _1343_ (.A0(\u_uart_tx_engine.tx_fifo_mem[12][2] ),
    .A1(\tx_data_byte[2] ),
    .S(_0383_),
    .X(_0219_));
 sky130_fd_sc_hd__mux2_1 _1344_ (.A0(\u_uart_tx_engine.tx_fifo_mem[12][3] ),
    .A1(\tx_data_byte[3] ),
    .S(_0383_),
    .X(_0220_));
 sky130_fd_sc_hd__mux2_1 _1345_ (.A0(\u_uart_tx_engine.tx_fifo_mem[12][4] ),
    .A1(\tx_data_byte[4] ),
    .S(_0383_),
    .X(_0221_));
 sky130_fd_sc_hd__mux2_1 _1346_ (.A0(\u_uart_tx_engine.tx_fifo_mem[12][5] ),
    .A1(\tx_data_byte[5] ),
    .S(_0383_),
    .X(_0222_));
 sky130_fd_sc_hd__mux2_1 _1347_ (.A0(\u_uart_tx_engine.tx_fifo_mem[12][6] ),
    .A1(\tx_data_byte[6] ),
    .S(_0383_),
    .X(_0223_));
 sky130_fd_sc_hd__nand2_2 _1348_ (.A(\u_uart_tx_engine.tx_rd_ptr[0] ),
    .B(_0564_),
    .Y(_0384_));
 sky130_fd_sc_hd__or2_2 _1349_ (.A(\u_uart_tx_engine.tx_rd_ptr[0] ),
    .B(_0564_),
    .X(_0385_));
 sky130_fd_sc_hd__and2_2 _1350_ (.A(_0384_),
    .B(_0385_),
    .X(_0224_));
 sky130_fd_sc_hd__a2bb2o_2 _1351_ (.A1_N(_0565_),
    .A2_N(_0288_),
    .B1(_0384_),
    .B2(\u_uart_tx_engine.tx_rd_ptr[1] ),
    .X(_0225_));
 sky130_fd_sc_hd__and4_2 _1352_ (.A(\u_uart_tx_engine.tx_rd_ptr[0] ),
    .B(\u_uart_tx_engine.tx_rd_ptr[2] ),
    .C(\u_uart_tx_engine.tx_rd_ptr[1] ),
    .D(_0564_),
    .X(_0386_));
 sky130_fd_sc_hd__o21ba_2 _1353_ (.A1(_0565_),
    .A2(_0294_),
    .B1_N(\u_uart_tx_engine.tx_rd_ptr[2] ),
    .X(_0387_));
 sky130_fd_sc_hd__nor2_2 _1354_ (.A(_0386_),
    .B(_0387_),
    .Y(_0226_));
 sky130_fd_sc_hd__xor2_2 _1355_ (.A(\u_uart_tx_engine.tx_rd_ptr[3] ),
    .B(_0386_),
    .X(_0227_));
 sky130_fd_sc_hd__xnor2_2 _1356_ (.A(\u_uart_tx_engine.tx_wr_ptr[0] ),
    .B(_0567_),
    .Y(_0228_));
 sky130_fd_sc_hd__and2_2 _1357_ (.A(\u_uart_tx_engine.tx_wr_ptr[1] ),
    .B(_0695_),
    .X(_0388_));
 sky130_fd_sc_hd__or2_2 _1358_ (.A(_0263_),
    .B(_0388_),
    .X(_0229_));
 sky130_fd_sc_hd__or2_2 _1359_ (.A(\u_uart_tx_engine.tx_wr_ptr[2] ),
    .B(_0696_),
    .X(_0389_));
 sky130_fd_sc_hd__and2_2 _1360_ (.A(_0697_),
    .B(_0389_),
    .X(_0230_));
 sky130_fd_sc_hd__nand2_2 _1361_ (.A(\u_uart_tx_engine.tx_wr_ptr[3] ),
    .B(_0697_),
    .Y(_0390_));
 sky130_fd_sc_hd__nand3_2 _1362_ (.A(\u_uart_tx_engine.tx_wr_ptr[3] ),
    .B(\u_uart_tx_engine.tx_wr_ptr[2] ),
    .C(_0696_),
    .Y(_0391_));
 sky130_fd_sc_hd__nand2_2 _1363_ (.A(_0698_),
    .B(_0390_),
    .Y(_0231_));
 sky130_fd_sc_hd__and3_2 _1364_ (.A(_0423_),
    .B(_0429_),
    .C(_0432_),
    .X(_0392_));
 sky130_fd_sc_hd__mux2_1 _1365_ (.A0(status_rx_busy),
    .A1(_0433_),
    .S(_0392_),
    .X(_0232_));
 sky130_fd_sc_hd__or3b_2 _1366_ (.A(wr_addr[1]),
    .B(wr_addr[4]),
    .C_N(wr_addr[0]),
    .X(_0393_));
 sky130_fd_sc_hd__or4b_2 _1367_ (.A(wr_addr[3]),
    .B(_0434_),
    .C(_0393_),
    .D_N(wr_addr[2]),
    .X(_0394_));
 sky130_fd_sc_hd__mux2_1 _1368_ (.A0(wr_data[0]),
    .A1(\baud_div[8] ),
    .S(_0394_),
    .X(_0233_));
 sky130_fd_sc_hd__mux2_1 _1369_ (.A0(wr_data[1]),
    .A1(\baud_div[9] ),
    .S(_0394_),
    .X(_0234_));
 sky130_fd_sc_hd__mux2_1 _1370_ (.A0(wr_data[2]),
    .A1(\baud_div[10] ),
    .S(_0394_),
    .X(_0235_));
 sky130_fd_sc_hd__mux2_1 _1371_ (.A0(wr_data[3]),
    .A1(\baud_div[11] ),
    .S(_0394_),
    .X(_0236_));
 sky130_fd_sc_hd__mux2_1 _1372_ (.A0(wr_data[4]),
    .A1(\baud_div[12] ),
    .S(_0394_),
    .X(_0237_));
 sky130_fd_sc_hd__mux2_1 _1373_ (.A0(wr_data[5]),
    .A1(\baud_div[13] ),
    .S(_0394_),
    .X(_0238_));
 sky130_fd_sc_hd__mux2_1 _1374_ (.A0(wr_data[6]),
    .A1(\baud_div[14] ),
    .S(_0394_),
    .X(_0239_));
 sky130_fd_sc_hd__mux2_1 _1375_ (.A0(wr_data[7]),
    .A1(\baud_div[15] ),
    .S(_0394_),
    .X(_0240_));
 sky130_fd_sc_hd__o21ba_2 _1376_ (.A1(packet_done_event),
    .A2(\irq_status[5] ),
    .B1_N(\irq_clear[5] ),
    .X(_0241_));
 sky130_fd_sc_hd__o21ba_2 _1377_ (.A1(framing_error_event),
    .A2(\irq_status[4] ),
    .B1_N(\irq_clear[4] ),
    .X(_0242_));
 sky130_fd_sc_hd__o21ba_2 _1378_ (.A1(tx_underflow_event),
    .A2(\irq_status[3] ),
    .B1_N(\irq_clear[3] ),
    .X(_0243_));
 sky130_fd_sc_hd__o21ba_2 _1379_ (.A1(rx_overflow_event),
    .A2(\irq_status[2] ),
    .B1_N(\irq_clear[2] ),
    .X(_0244_));
 sky130_fd_sc_hd__o21ba_2 _1380_ (.A1(tx_done_event),
    .A2(\irq_status[1] ),
    .B1_N(\irq_clear[1] ),
    .X(_0245_));
 sky130_fd_sc_hd__and3_2 _1381_ (.A(\u_uart_rx_engine.rx_state[1] ),
    .B(_0424_),
    .C(_0426_),
    .X(_0395_));
 sky130_fd_sc_hd__a21oi_2 _1382_ (.A1(\u_uart_rx_engine.rx_state[2] ),
    .A2(_0428_),
    .B1(_0395_),
    .Y(_0396_));
 sky130_fd_sc_hd__mux2_1 _1383_ (.A0(_0395_),
    .A1(_0396_),
    .S(\u_uart_rx_engine.rx_bit_index[0] ),
    .X(_0246_));
 sky130_fd_sc_hd__or2_2 _1384_ (.A(\u_uart_rx_engine.rx_bit_index[1] ),
    .B(\u_uart_rx_engine.rx_bit_index[0] ),
    .X(_0397_));
 sky130_fd_sc_hd__a32o_2 _1385_ (.A1(_0430_),
    .A2(_0395_),
    .A3(_0397_),
    .B1(_0396_),
    .B2(\u_uart_rx_engine.rx_bit_index[1] ),
    .X(_0247_));
 sky130_fd_sc_hd__xnor2_2 _1386_ (.A(\u_uart_rx_engine.rx_bit_index[2] ),
    .B(_0430_),
    .Y(_0398_));
 sky130_fd_sc_hd__a22o_2 _1387_ (.A1(\u_uart_rx_engine.rx_bit_index[2] ),
    .A2(_0396_),
    .B1(_0398_),
    .B2(_0395_),
    .X(_0248_));
 sky130_fd_sc_hd__mux2_1 _1388_ (.A0(wr_data[0]),
    .A1(\tx_data_byte[0] ),
    .S(_0438_),
    .X(_0249_));
 sky130_fd_sc_hd__mux2_1 _1389_ (.A0(wr_data[1]),
    .A1(\tx_data_byte[1] ),
    .S(_0438_),
    .X(_0250_));
 sky130_fd_sc_hd__mux2_1 _1390_ (.A0(wr_data[2]),
    .A1(\tx_data_byte[2] ),
    .S(_0438_),
    .X(_0251_));
 sky130_fd_sc_hd__mux2_1 _1391_ (.A0(wr_data[3]),
    .A1(\tx_data_byte[3] ),
    .S(_0438_),
    .X(_0252_));
 sky130_fd_sc_hd__mux2_1 _1392_ (.A0(wr_data[4]),
    .A1(\tx_data_byte[4] ),
    .S(_0438_),
    .X(_0253_));
 sky130_fd_sc_hd__mux2_1 _1393_ (.A0(wr_data[5]),
    .A1(\tx_data_byte[5] ),
    .S(_0438_),
    .X(_0254_));
 sky130_fd_sc_hd__mux2_1 _1394_ (.A0(wr_data[6]),
    .A1(\tx_data_byte[6] ),
    .S(_0438_),
    .X(_0255_));
 sky130_fd_sc_hd__mux2_1 _1395_ (.A0(\tx_data_byte[0] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[15][0] ),
    .S(_0391_),
    .X(_0256_));
 sky130_fd_sc_hd__mux2_1 _1396_ (.A0(\tx_data_byte[1] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[15][1] ),
    .S(_0391_),
    .X(_0257_));
 sky130_fd_sc_hd__mux2_1 _1397_ (.A0(\tx_data_byte[2] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[15][2] ),
    .S(_0391_),
    .X(_0258_));
 sky130_fd_sc_hd__mux2_1 _1398_ (.A0(\tx_data_byte[3] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[15][3] ),
    .S(_0391_),
    .X(_0259_));
 sky130_fd_sc_hd__mux2_1 _1399_ (.A0(\tx_data_byte[4] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[15][4] ),
    .S(_0391_),
    .X(_0260_));
 sky130_fd_sc_hd__mux2_1 _1400_ (.A0(\tx_data_byte[5] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[15][5] ),
    .S(_0391_),
    .X(_0261_));
 sky130_fd_sc_hd__mux2_1 _1401_ (.A0(\tx_data_byte[6] ),
    .A1(\u_uart_tx_engine.tx_fifo_mem[15][6] ),
    .S(_0391_),
    .X(_0262_));
 sky130_fd_sc_hd__sdfrtp_2 _1402_ (.CLK(clk),
    .D(_0021_),
    .RESET_B(reset_n),
    .SCD(scan_in[0]),
    .SCE(scan_en),
    .Q(baud_tick));
 sky130_fd_sc_hd__sdfrtp_2 _1403_ (.CLK(clk),
    .D(_0005_),
    .RESET_B(reset_n),
    .SCD(scan_in[1]),
    .SCE(scan_en),
    .Q(\u_uart_baud_tick_gen.baud_cnt[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1404_ (.CLK(clk),
    .D(_0012_),
    .RESET_B(reset_n),
    .SCD(scan_in[2]),
    .SCE(scan_en),
    .Q(\u_uart_baud_tick_gen.baud_cnt[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1405_ (.CLK(clk),
    .D(_0013_),
    .RESET_B(reset_n),
    .SCD(scan_in[3]),
    .SCE(scan_en),
    .Q(\u_uart_baud_tick_gen.baud_cnt[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1406_ (.CLK(clk),
    .D(_0014_),
    .RESET_B(reset_n),
    .SCD(baud_tick),
    .SCE(scan_en),
    .Q(\u_uart_baud_tick_gen.baud_cnt[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1407_ (.CLK(clk),
    .D(_0015_),
    .RESET_B(reset_n),
    .SCD(\u_uart_baud_tick_gen.baud_cnt[0] ),
    .SCE(scan_en),
    .Q(\u_uart_baud_tick_gen.baud_cnt[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1408_ (.CLK(clk),
    .D(_0016_),
    .RESET_B(reset_n),
    .SCD(\u_uart_baud_tick_gen.baud_cnt[1] ),
    .SCE(scan_en),
    .Q(\u_uart_baud_tick_gen.baud_cnt[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1409_ (.CLK(clk),
    .D(_0017_),
    .RESET_B(reset_n),
    .SCD(\u_uart_baud_tick_gen.baud_cnt[2] ),
    .SCE(scan_en),
    .Q(\u_uart_baud_tick_gen.baud_cnt[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1410_ (.CLK(clk),
    .D(_0018_),
    .RESET_B(reset_n),
    .SCD(\u_uart_baud_tick_gen.baud_cnt[3] ),
    .SCE(scan_en),
    .Q(\u_uart_baud_tick_gen.baud_cnt[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _1411_ (.CLK(clk),
    .D(_0019_),
    .RESET_B(reset_n),
    .SCD(\u_uart_baud_tick_gen.baud_cnt[4] ),
    .SCE(scan_en),
    .Q(\u_uart_baud_tick_gen.baud_cnt[8] ));
 sky130_fd_sc_hd__sdfrtp_2 _1412_ (.CLK(clk),
    .D(_0020_),
    .RESET_B(reset_n),
    .SCD(\u_uart_baud_tick_gen.baud_cnt[5] ),
    .SCE(scan_en),
    .Q(\u_uart_baud_tick_gen.baud_cnt[9] ));
 sky130_fd_sc_hd__sdfrtp_2 _1413_ (.CLK(clk),
    .D(_0006_),
    .RESET_B(reset_n),
    .SCD(\u_uart_baud_tick_gen.baud_cnt[6] ),
    .SCE(scan_en),
    .Q(\u_uart_baud_tick_gen.baud_cnt[10] ));
 sky130_fd_sc_hd__sdfrtp_2 _1414_ (.CLK(clk),
    .D(_0007_),
    .RESET_B(reset_n),
    .SCD(\u_uart_baud_tick_gen.baud_cnt[7] ),
    .SCE(scan_en),
    .Q(\u_uart_baud_tick_gen.baud_cnt[11] ));
 sky130_fd_sc_hd__sdfrtp_2 _1415_ (.CLK(clk),
    .D(_0008_),
    .RESET_B(reset_n),
    .SCD(\u_uart_baud_tick_gen.baud_cnt[8] ),
    .SCE(scan_en),
    .Q(\u_uart_baud_tick_gen.baud_cnt[12] ));
 sky130_fd_sc_hd__sdfrtp_2 _1416_ (.CLK(clk),
    .D(_0009_),
    .RESET_B(reset_n),
    .SCD(\u_uart_baud_tick_gen.baud_cnt[9] ),
    .SCE(scan_en),
    .Q(\u_uart_baud_tick_gen.baud_cnt[13] ));
 sky130_fd_sc_hd__sdfrtp_2 _1417_ (.CLK(clk),
    .D(_0010_),
    .RESET_B(reset_n),
    .SCD(\u_uart_baud_tick_gen.baud_cnt[10] ),
    .SCE(scan_en),
    .Q(\u_uart_baud_tick_gen.baud_cnt[14] ));
 sky130_fd_sc_hd__sdfrtp_2 _1418_ (.CLK(clk),
    .D(_0011_),
    .RESET_B(reset_n),
    .SCD(\u_uart_baud_tick_gen.baud_cnt[11] ),
    .SCE(scan_en),
    .Q(\u_uart_baud_tick_gen.baud_cnt[15] ));
 sky130_fd_sc_hd__sdfrtp_2 _1419_ (.CLK(clk),
    .D(_0053_),
    .RESET_B(reset_n),
    .SCD(\u_uart_baud_tick_gen.baud_cnt[12] ),
    .SCE(scan_en),
    .Q(packet_count[0]));
 sky130_fd_sc_hd__sdfrtp_2 _1420_ (.CLK(clk),
    .D(_0054_),
    .RESET_B(reset_n),
    .SCD(\u_uart_baud_tick_gen.baud_cnt[13] ),
    .SCE(scan_en),
    .Q(packet_count[1]));
 sky130_fd_sc_hd__sdfrtp_2 _1421_ (.CLK(clk),
    .D(_0055_),
    .RESET_B(reset_n),
    .SCD(\u_uart_baud_tick_gen.baud_cnt[14] ),
    .SCE(scan_en),
    .Q(packet_count[2]));
 sky130_fd_sc_hd__sdfrtp_2 _1422_ (.CLK(clk),
    .D(_0056_),
    .RESET_B(reset_n),
    .SCD(\u_uart_baud_tick_gen.baud_cnt[15] ),
    .SCE(scan_en),
    .Q(packet_count[3]));
 sky130_fd_sc_hd__sdfrtp_2 _1423_ (.CLK(clk),
    .D(_0057_),
    .RESET_B(reset_n),
    .SCD(packet_count[0]),
    .SCE(scan_en),
    .Q(packet_count[4]));
 sky130_fd_sc_hd__sdfrtp_2 _1424_ (.CLK(clk),
    .D(_0058_),
    .RESET_B(reset_n),
    .SCD(packet_count[1]),
    .SCE(scan_en),
    .Q(packet_count[5]));
 sky130_fd_sc_hd__sdfrtp_2 _1425_ (.CLK(clk),
    .D(_0059_),
    .RESET_B(reset_n),
    .SCD(packet_count[2]),
    .SCE(scan_en),
    .Q(packet_count[6]));
 sky130_fd_sc_hd__sdfrtp_2 _1426_ (.CLK(clk),
    .D(_0060_),
    .RESET_B(reset_n),
    .SCD(packet_count[3]),
    .SCE(scan_en),
    .Q(packet_count[7]));
 sky130_fd_sc_hd__sdfrtp_2 _1427_ (.CLK(clk),
    .D(_0061_),
    .RESET_B(reset_n),
    .SCD(packet_count[4]),
    .SCE(scan_en),
    .Q(packet_count[8]));
 sky130_fd_sc_hd__sdfrtp_2 _1428_ (.CLK(clk),
    .D(_0062_),
    .RESET_B(reset_n),
    .SCD(packet_count[5]),
    .SCE(scan_en),
    .Q(packet_count[9]));
 sky130_fd_sc_hd__sdfrtp_2 _1429_ (.CLK(clk),
    .D(_0063_),
    .RESET_B(reset_n),
    .SCD(packet_count[6]),
    .SCE(scan_en),
    .Q(packet_count[10]));
 sky130_fd_sc_hd__sdfrtp_2 _1430_ (.CLK(clk),
    .D(_0064_),
    .RESET_B(reset_n),
    .SCD(packet_count[7]),
    .SCE(scan_en),
    .Q(packet_count[11]));
 sky130_fd_sc_hd__sdfrtp_2 _1431_ (.CLK(clk),
    .D(_0065_),
    .RESET_B(reset_n),
    .SCD(packet_count[8]),
    .SCE(scan_en),
    .Q(packet_count[12]));
 sky130_fd_sc_hd__sdfrtp_2 _1432_ (.CLK(clk),
    .D(_0066_),
    .RESET_B(reset_n),
    .SCD(packet_count[9]),
    .SCE(scan_en),
    .Q(packet_count[13]));
 sky130_fd_sc_hd__sdfrtp_2 _1433_ (.CLK(clk),
    .D(_0067_),
    .RESET_B(reset_n),
    .SCD(packet_count[10]),
    .SCE(scan_en),
    .Q(packet_count[14]));
 sky130_fd_sc_hd__sdfrtp_2 _1434_ (.CLK(clk),
    .D(_0068_),
    .RESET_B(reset_n),
    .SCD(packet_count[11]),
    .SCE(scan_en),
    .Q(packet_count[15]));
 sky130_fd_sc_hd__sdfrtp_2 _1435_ (.CLK(clk),
    .D(_0028_),
    .RESET_B(reset_n),
    .SCD(packet_count[12]),
    .SCE(scan_en),
    .Q(rd_data[0]));
 sky130_fd_sc_hd__sdfrtp_2 _1436_ (.CLK(clk),
    .D(_0029_),
    .RESET_B(reset_n),
    .SCD(packet_count[13]),
    .SCE(scan_en),
    .Q(rd_data[1]));
 sky130_fd_sc_hd__sdfrtp_2 _1437_ (.CLK(clk),
    .D(_0030_),
    .RESET_B(reset_n),
    .SCD(packet_count[14]),
    .SCE(scan_en),
    .Q(rd_data[2]));
 sky130_fd_sc_hd__sdfrtp_2 _1438_ (.CLK(clk),
    .D(_0031_),
    .RESET_B(reset_n),
    .SCD(packet_count[15]),
    .SCE(scan_en),
    .Q(rd_data[3]));
 sky130_fd_sc_hd__sdfrtp_2 _1439_ (.CLK(clk),
    .D(_0032_),
    .RESET_B(reset_n),
    .SCD(rd_data[0]),
    .SCE(scan_en),
    .Q(rd_data[4]));
 sky130_fd_sc_hd__sdfrtp_2 _1440_ (.CLK(clk),
    .D(_0033_),
    .RESET_B(reset_n),
    .SCD(rd_data[1]),
    .SCE(scan_en),
    .Q(rd_data[5]));
 sky130_fd_sc_hd__sdfrtp_2 _1441_ (.CLK(clk),
    .D(_0034_),
    .RESET_B(reset_n),
    .SCD(rd_data[2]),
    .SCE(scan_en),
    .Q(rd_data[6]));
 sky130_fd_sc_hd__sdfrtp_2 _1442_ (.CLK(clk),
    .D(_0035_),
    .RESET_B(reset_n),
    .SCD(rd_data[3]),
    .SCE(scan_en),
    .Q(rd_data[7]));
 sky130_fd_sc_hd__sdfrtp_2 _1443_ (.CLK(clk),
    .D(_0069_),
    .RESET_B(reset_n),
    .SCD(rd_data[4]),
    .SCE(scan_en),
    .Q(\irq_status[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1444_ (.CLK(clk),
    .D(_0070_),
    .RESET_B(reset_n),
    .SCD(rd_data[5]),
    .SCE(scan_en),
    .Q(\packet_len[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1445_ (.CLK(clk),
    .D(_0071_),
    .RESET_B(reset_n),
    .SCD(rd_data[6]),
    .SCE(scan_en),
    .Q(\packet_len[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1446_ (.CLK(clk),
    .D(_0072_),
    .RESET_B(reset_n),
    .SCD(rd_data[7]),
    .SCE(scan_en),
    .Q(\packet_len[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1447_ (.CLK(clk),
    .D(_0073_),
    .RESET_B(reset_n),
    .SCD(\irq_status[0] ),
    .SCE(scan_en),
    .Q(\packet_len[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1448_ (.CLK(clk),
    .D(_0074_),
    .RESET_B(reset_n),
    .SCD(\packet_len[0] ),
    .SCE(scan_en),
    .Q(\packet_len[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1449_ (.CLK(clk),
    .D(_0075_),
    .RESET_B(reset_n),
    .SCD(\packet_len[1] ),
    .SCE(scan_en),
    .Q(\packet_len[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1450_ (.CLK(clk),
    .D(_0076_),
    .RESET_B(reset_n),
    .SCD(\packet_len[2] ),
    .SCE(scan_en),
    .Q(\packet_len[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1451_ (.CLK(clk),
    .D(_0077_),
    .RESET_B(reset_n),
    .SCD(\packet_len[3] ),
    .SCE(scan_en),
    .Q(\packet_len[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _1452_ (.CLK(clk),
    .D(_0036_),
    .RESET_B(reset_n),
    .SCD(\packet_len[4] ),
    .SCE(scan_en),
    .Q(rx_data_pop));
 sky130_fd_sc_hd__sdfrtp_2 _1453_ (.CLK(clk),
    .D(_0078_),
    .RESET_B(reset_n),
    .SCD(\packet_len[5] ),
    .SCE(scan_en),
    .Q(\baud_div[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1454_ (.CLK(clk),
    .D(_0079_),
    .RESET_B(reset_n),
    .SCD(\packet_len[6] ),
    .SCE(scan_en),
    .Q(\baud_div[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1455_ (.CLK(clk),
    .D(_0080_),
    .RESET_B(reset_n),
    .SCD(\packet_len[7] ),
    .SCE(scan_en),
    .Q(\baud_div[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1456_ (.CLK(clk),
    .D(_0081_),
    .RESET_B(reset_n),
    .SCD(rx_data_pop),
    .SCE(scan_en),
    .Q(\baud_div[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1457_ (.CLK(clk),
    .D(_0082_),
    .RESET_B(reset_n),
    .SCD(\baud_div[0] ),
    .SCE(scan_en),
    .Q(\baud_div[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1458_ (.CLK(clk),
    .D(_0083_),
    .RESET_B(reset_n),
    .SCD(\baud_div[1] ),
    .SCE(scan_en),
    .Q(\baud_div[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1459_ (.CLK(clk),
    .D(_0084_),
    .RESET_B(reset_n),
    .SCD(\baud_div[2] ),
    .SCE(scan_en),
    .Q(\baud_div[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1460_ (.CLK(clk),
    .D(_0085_),
    .RESET_B(reset_n),
    .SCD(\baud_div[3] ),
    .SCE(scan_en),
    .Q(\baud_div[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _1461_ (.CLK(clk),
    .D(_0004_),
    .RESET_B(reset_n),
    .SCD(\baud_div[4] ),
    .SCE(scan_en),
    .Q(tx_data_push));
 sky130_fd_sc_hd__sdfrtp_2 _1462_ (.CLK(clk),
    .D(_0086_),
    .RESET_B(reset_n),
    .SCD(\baud_div[5] ),
    .SCE(scan_en),
    .Q(control_enable));
 sky130_fd_sc_hd__sdfrtp_2 _1463_ (.CLK(clk),
    .D(_0087_),
    .RESET_B(reset_n),
    .SCD(\baud_div[6] ),
    .SCE(scan_en),
    .Q(control_rx_enable));
 sky130_fd_sc_hd__sdfrtp_2 _1464_ (.CLK(clk),
    .D(_0088_),
    .RESET_B(reset_n),
    .SCD(\baud_div[7] ),
    .SCE(scan_en),
    .Q(control_tx_enable));
 sky130_fd_sc_hd__sdfrtp_2 _1465_ (.CLK(clk),
    .D(_0089_),
    .RESET_B(reset_n),
    .SCD(tx_data_push),
    .SCE(scan_en),
    .Q(control_loopback));
 sky130_fd_sc_hd__sdfrtp_2 _1466_ (.CLK(clk),
    .D(_0090_),
    .RESET_B(reset_n),
    .SCD(control_enable),
    .SCE(scan_en),
    .Q(control_irq_enable));
 sky130_fd_sc_hd__sdfrtp_2 _1467_ (.CLK(clk),
    .D(_0022_),
    .RESET_B(reset_n),
    .SCD(control_rx_enable),
    .SCE(scan_en),
    .Q(\irq_clear[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1468_ (.CLK(clk),
    .D(_0023_),
    .RESET_B(reset_n),
    .SCD(control_tx_enable),
    .SCE(scan_en),
    .Q(\irq_clear[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1469_ (.CLK(clk),
    .D(_0024_),
    .RESET_B(reset_n),
    .SCD(control_loopback),
    .SCE(scan_en),
    .Q(\irq_clear[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1470_ (.CLK(clk),
    .D(_0025_),
    .RESET_B(reset_n),
    .SCD(control_irq_enable),
    .SCE(scan_en),
    .Q(\irq_clear[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1471_ (.CLK(clk),
    .D(_0026_),
    .RESET_B(reset_n),
    .SCD(\irq_clear[0] ),
    .SCE(scan_en),
    .Q(\irq_clear[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1472_ (.CLK(clk),
    .D(_0027_),
    .RESET_B(reset_n),
    .SCD(\irq_clear[1] ),
    .SCE(scan_en),
    .Q(\irq_clear[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1473_ (.CLK(clk),
    .D(_0091_),
    .RESET_B(reset_n),
    .SCD(\irq_clear[2] ),
    .SCE(scan_en),
    .Q(\u_uart_rx_engine.rx_packet_count[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1474_ (.CLK(clk),
    .D(_0092_),
    .RESET_B(reset_n),
    .SCD(\irq_clear[3] ),
    .SCE(scan_en),
    .Q(\u_uart_rx_engine.rx_packet_count[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1475_ (.CLK(clk),
    .D(_0093_),
    .RESET_B(reset_n),
    .SCD(\irq_clear[4] ),
    .SCE(scan_en),
    .Q(\u_uart_rx_engine.rx_packet_count[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1476_ (.CLK(clk),
    .D(_0094_),
    .RESET_B(reset_n),
    .SCD(\irq_clear[5] ),
    .SCE(scan_en),
    .Q(\u_uart_rx_engine.rx_packet_count[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1477_ (.CLK(clk),
    .D(_0095_),
    .RESET_B(reset_n),
    .SCD(\u_uart_rx_engine.rx_packet_count[0] ),
    .SCE(scan_en),
    .Q(\u_uart_rx_engine.rx_packet_count[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1478_ (.CLK(clk),
    .D(_0096_),
    .RESET_B(reset_n),
    .SCD(\u_uart_rx_engine.rx_packet_count[1] ),
    .SCE(scan_en),
    .Q(\u_uart_rx_engine.rx_packet_count[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1479_ (.CLK(clk),
    .D(_0097_),
    .RESET_B(reset_n),
    .SCD(\u_uart_rx_engine.rx_packet_count[2] ),
    .SCE(scan_en),
    .Q(\u_uart_rx_engine.rx_packet_count[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1480_ (.CLK(clk),
    .D(_0098_),
    .RESET_B(reset_n),
    .SCD(\u_uart_rx_engine.rx_packet_count[3] ),
    .SCE(scan_en),
    .Q(\u_uart_rx_engine.rx_packet_count[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _1481_ (.CLK(clk),
    .D(_0099_),
    .RESET_B(reset_n),
    .SCD(\u_uart_rx_engine.rx_packet_count[4] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[8][0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1482_ (.CLK(clk),
    .D(_0100_),
    .RESET_B(reset_n),
    .SCD(\u_uart_rx_engine.rx_packet_count[5] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[8][1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1483_ (.CLK(clk),
    .D(_0101_),
    .RESET_B(reset_n),
    .SCD(\u_uart_rx_engine.rx_packet_count[6] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[8][2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1484_ (.CLK(clk),
    .D(_0102_),
    .RESET_B(reset_n),
    .SCD(\u_uart_rx_engine.rx_packet_count[7] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[8][3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1485_ (.CLK(clk),
    .D(_0103_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[8][0] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[8][4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1486_ (.CLK(clk),
    .D(_0104_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[8][1] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[8][5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1487_ (.CLK(clk),
    .D(_0105_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[8][2] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[8][6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1488_ (.CLK(clk),
    .D(_0106_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[8][3] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[7][0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1489_ (.CLK(clk),
    .D(_0107_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[8][4] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[7][1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1490_ (.CLK(clk),
    .D(_0108_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[8][5] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[7][2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1491_ (.CLK(clk),
    .D(_0109_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[8][6] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[7][3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1492_ (.CLK(clk),
    .D(_0110_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[7][0] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[7][4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1493_ (.CLK(clk),
    .D(_0111_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[7][1] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[7][5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1494_ (.CLK(clk),
    .D(_0112_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[7][2] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[7][6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1495_ (.CLK(clk),
    .D(_0113_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[7][3] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[6][0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1496_ (.CLK(clk),
    .D(_0114_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[7][4] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[6][1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1497_ (.CLK(clk),
    .D(_0115_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[7][5] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[6][2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1498_ (.CLK(clk),
    .D(_0116_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[7][6] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[6][3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1499_ (.CLK(clk),
    .D(_0117_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[6][0] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[6][4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1500_ (.CLK(clk),
    .D(_0118_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[6][1] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[6][5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1501_ (.CLK(clk),
    .D(_0119_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[6][2] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[6][6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1502_ (.CLK(clk),
    .D(_0120_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[6][3] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[13][0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1503_ (.CLK(clk),
    .D(_0121_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[6][4] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[13][1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1504_ (.CLK(clk),
    .D(_0122_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[6][5] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[13][2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1505_ (.CLK(clk),
    .D(_0123_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[6][6] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[13][3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1506_ (.CLK(clk),
    .D(_0124_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[13][0] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[13][4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1507_ (.CLK(clk),
    .D(_0125_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[13][1] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[13][5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1508_ (.CLK(clk),
    .D(_0126_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[13][2] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[13][6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1509_ (.CLK(clk),
    .D(_0127_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[13][3] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[5][0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1510_ (.CLK(clk),
    .D(_0128_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[13][4] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[5][1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1511_ (.CLK(clk),
    .D(_0129_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[13][5] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[5][2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1512_ (.CLK(clk),
    .D(_0130_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[13][6] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[5][3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1513_ (.CLK(clk),
    .D(_0131_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[5][0] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[5][4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1514_ (.CLK(clk),
    .D(_0132_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[5][1] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[5][5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1515_ (.CLK(clk),
    .D(_0133_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[5][2] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[5][6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1516_ (.CLK(clk),
    .D(_0134_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[5][3] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[4][0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1517_ (.CLK(clk),
    .D(_0135_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[5][4] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[4][1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1518_ (.CLK(clk),
    .D(_0136_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[5][5] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[4][2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1519_ (.CLK(clk),
    .D(_0137_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[5][6] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[4][3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1520_ (.CLK(clk),
    .D(_0138_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[4][0] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[4][4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1521_ (.CLK(clk),
    .D(_0139_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[4][1] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[4][5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1522_ (.CLK(clk),
    .D(_0140_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[4][2] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[4][6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1523_ (.CLK(clk),
    .D(_0141_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[4][3] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[3][0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1524_ (.CLK(clk),
    .D(_0142_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[4][4] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[3][1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1525_ (.CLK(clk),
    .D(_0143_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[4][5] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[3][2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1526_ (.CLK(clk),
    .D(_0144_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[4][6] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[3][3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1527_ (.CLK(clk),
    .D(_0145_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[3][0] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[3][4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1528_ (.CLK(clk),
    .D(_0146_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[3][1] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[3][5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1529_ (.CLK(clk),
    .D(_0147_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[3][2] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[3][6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1530_ (.CLK(clk),
    .D(_0148_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[3][3] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[14][0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1531_ (.CLK(clk),
    .D(_0149_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[3][4] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[14][1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1532_ (.CLK(clk),
    .D(_0150_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[3][5] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[14][2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1533_ (.CLK(clk),
    .D(_0151_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[3][6] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[14][3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1534_ (.CLK(clk),
    .D(_0152_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[14][0] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[14][4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1535_ (.CLK(clk),
    .D(_0153_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[14][1] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[14][5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1536_ (.CLK(clk),
    .D(_0154_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[14][2] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[14][6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1537_ (.CLK(clk),
    .D(_0155_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[14][3] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[2][0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1538_ (.CLK(clk),
    .D(_0156_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[14][4] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[2][1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1539_ (.CLK(clk),
    .D(_0157_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[14][5] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[2][2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1540_ (.CLK(clk),
    .D(_0158_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[14][6] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[2][3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1541_ (.CLK(clk),
    .D(_0159_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[2][0] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[2][4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1542_ (.CLK(clk),
    .D(_0160_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[2][1] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[2][5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1543_ (.CLK(clk),
    .D(_0161_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[2][2] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[2][6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1544_ (.CLK(clk),
    .D(_0162_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[2][3] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[1][0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1545_ (.CLK(clk),
    .D(_0163_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[2][4] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[1][1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1546_ (.CLK(clk),
    .D(_0164_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[2][5] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[1][2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1547_ (.CLK(clk),
    .D(_0165_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[2][6] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[1][3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1548_ (.CLK(clk),
    .D(_0166_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[1][0] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[1][4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1549_ (.CLK(clk),
    .D(_0167_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[1][1] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[1][5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1550_ (.CLK(clk),
    .D(_0168_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[1][2] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[1][6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1551_ (.CLK(clk),
    .D(_0169_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[1][3] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[10][0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1552_ (.CLK(clk),
    .D(_0170_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[1][4] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[10][1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1553_ (.CLK(clk),
    .D(_0171_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[1][5] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[10][2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1554_ (.CLK(clk),
    .D(_0172_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[1][6] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[10][3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1555_ (.CLK(clk),
    .D(_0173_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[10][0] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[10][4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1556_ (.CLK(clk),
    .D(_0174_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[10][1] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[10][5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1557_ (.CLK(clk),
    .D(_0175_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[10][2] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[10][6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1558_ (.CLK(clk),
    .D(_0176_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[10][3] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[0][0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1559_ (.CLK(clk),
    .D(_0177_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[10][4] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[0][1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1560_ (.CLK(clk),
    .D(_0178_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[10][5] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[0][2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1561_ (.CLK(clk),
    .D(_0179_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[10][6] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[0][3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1562_ (.CLK(clk),
    .D(_0180_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[0][0] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[0][4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1563_ (.CLK(clk),
    .D(_0181_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[0][1] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[0][5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1564_ (.CLK(clk),
    .D(_0182_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[0][2] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[0][6] ));
 sky130_fd_sc_hd__sdfsbp_2 _1636_ (.CLK(clk),
    .D(_0000_),
    .SET_B(reset_n),
    .Q(\u_uart_rx_engine.rx_state[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1566_ (.CLK(clk),
    .D(_0184_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[0][3] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[11][0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1567_ (.CLK(clk),
    .D(_0185_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[0][4] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[11][1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1568_ (.CLK(clk),
    .D(_0186_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[0][5] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[11][2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1569_ (.CLK(clk),
    .D(_0187_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[0][6] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[11][3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1570_ (.CLK(clk),
    .D(_0188_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[11][0] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[11][4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1571_ (.CLK(clk),
    .D(_0189_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[11][1] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[11][5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1572_ (.CLK(clk),
    .D(_0190_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[11][2] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[11][6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1573_ (.CLK(clk),
    .D(_0045_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[11][3] ),
    .SCE(scan_en),
    .Q(loopback_byte_valid));
 sky130_fd_sc_hd__sdfrtp_2 _1574_ (.CLK(clk),
    .D(_0191_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[11][4] ),
    .SCE(scan_en),
    .Q(status_tx_busy));
 sky130_fd_sc_hd__sdfrtp_2 _1575_ (.CLK(clk),
    .D(_0051_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[11][5] ),
    .SCE(scan_en),
    .Q(tx_done_event));
 sky130_fd_sc_hd__sdfrtp_2 _1576_ (.CLK(clk),
    .D(_0052_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[11][6] ),
    .SCE(scan_en),
    .Q(tx_underflow_event));
 sky130_fd_sc_hd__sdfrtp_2 _1577_ (.CLK(clk),
    .D(_0192_),
    .RESET_B(reset_n),
    .SCD(loopback_byte_valid),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[9][0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1578_ (.CLK(clk),
    .D(_0193_),
    .RESET_B(reset_n),
    .SCD(status_tx_busy),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[9][1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1579_ (.CLK(clk),
    .D(_0194_),
    .RESET_B(reset_n),
    .SCD(tx_done_event),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[9][2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1580_ (.CLK(clk),
    .D(_0195_),
    .RESET_B(reset_n),
    .SCD(tx_underflow_event),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[9][3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1581_ (.CLK(clk),
    .D(_0196_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[9][0] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[9][4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1582_ (.CLK(clk),
    .D(_0197_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[9][1] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[9][5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1583_ (.CLK(clk),
    .D(_0198_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[9][2] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[9][6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1584_ (.CLK(clk),
    .D(_0199_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[9][3] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_packet_count[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1585_ (.CLK(clk),
    .D(_0200_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[9][4] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_packet_count[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1586_ (.CLK(clk),
    .D(_0201_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[9][5] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_packet_count[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1587_ (.CLK(clk),
    .D(_0202_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[9][6] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_packet_count[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1588_ (.CLK(clk),
    .D(_0203_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_packet_count[0] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_packet_count[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1589_ (.CLK(clk),
    .D(_0204_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_packet_count[1] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_packet_count[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1590_ (.CLK(clk),
    .D(_0205_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_packet_count[2] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_packet_count[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1591_ (.CLK(clk),
    .D(_0206_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_packet_count[3] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_packet_count[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _1592_ (.CLK(clk),
    .D(_0207_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_packet_count[4] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_bit_index[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1593_ (.CLK(clk),
    .D(_0208_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_packet_count[5] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_bit_index[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1594_ (.CLK(clk),
    .D(_0209_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_packet_count[6] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_bit_index[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1595_ (.CLK(clk),
    .D(_0210_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_packet_count[7] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_shift_reg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1596_ (.CLK(clk),
    .D(_0211_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_bit_index[0] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_shift_reg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1597_ (.CLK(clk),
    .D(_0212_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_bit_index[1] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_shift_reg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1598_ (.CLK(clk),
    .D(_0213_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_bit_index[2] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_shift_reg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1599_ (.CLK(clk),
    .D(_0214_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_shift_reg[0] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_shift_reg[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1600_ (.CLK(clk),
    .D(_0215_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_shift_reg[1] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_shift_reg[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1601_ (.CLK(clk),
    .D(_0216_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_shift_reg[2] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_shift_reg[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1602_ (.CLK(clk),
    .D(_0217_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_shift_reg[3] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[12][0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1603_ (.CLK(clk),
    .D(_0218_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_shift_reg[4] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[12][1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1604_ (.CLK(clk),
    .D(_0219_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_shift_reg[5] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[12][2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1605_ (.CLK(clk),
    .D(_0220_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_shift_reg[6] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[12][3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1606_ (.CLK(clk),
    .D(_0221_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[12][0] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[12][4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1607_ (.CLK(clk),
    .D(_0222_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[12][1] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[12][5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1608_ (.CLK(clk),
    .D(_0223_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[12][2] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[12][6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1609_ (.CLK(clk),
    .D(_0224_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[12][3] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_rd_ptr[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1610_ (.CLK(clk),
    .D(_0225_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[12][4] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_rd_ptr[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1611_ (.CLK(clk),
    .D(_0226_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[12][5] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_rd_ptr[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1612_ (.CLK(clk),
    .D(_0227_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[12][6] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_rd_ptr[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1613_ (.CLK(clk),
    .D(_0046_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_rd_ptr[0] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_count[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1614_ (.CLK(clk),
    .D(_0047_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_rd_ptr[1] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_count[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1615_ (.CLK(clk),
    .D(_0048_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_rd_ptr[2] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_count[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1616_ (.CLK(clk),
    .D(_0049_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_rd_ptr[3] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_count[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1617_ (.CLK(clk),
    .D(_0050_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_count[0] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_count[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1618_ (.CLK(clk),
    .D(_0228_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_count[1] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_wr_ptr[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1619_ (.CLK(clk),
    .D(_0229_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_count[2] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_wr_ptr[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1620_ (.CLK(clk),
    .D(_0230_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_count[3] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_wr_ptr[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1621_ (.CLK(clk),
    .D(_0231_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_count[4] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_wr_ptr[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1622_ (.CLK(clk),
    .D(_0232_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_wr_ptr[0] ),
    .SCE(scan_en),
    .Q(status_rx_busy));
 sky130_fd_sc_hd__sdfrtp_2 _1623_ (.CLK(clk),
    .D(_0233_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_wr_ptr[1] ),
    .SCE(scan_en),
    .Q(\baud_div[8] ));
 sky130_fd_sc_hd__sdfrtp_2 _1624_ (.CLK(clk),
    .D(_0234_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_wr_ptr[2] ),
    .SCE(scan_en),
    .Q(\baud_div[9] ));
 sky130_fd_sc_hd__sdfrtp_2 _1625_ (.CLK(clk),
    .D(_0235_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_wr_ptr[3] ),
    .SCE(scan_en),
    .Q(\baud_div[10] ));
 sky130_fd_sc_hd__sdfrtp_2 _1626_ (.CLK(clk),
    .D(_0236_),
    .RESET_B(reset_n),
    .SCD(status_rx_busy),
    .SCE(scan_en),
    .Q(\baud_div[11] ));
 sky130_fd_sc_hd__sdfrtp_2 _1627_ (.CLK(clk),
    .D(_0237_),
    .RESET_B(reset_n),
    .SCD(\baud_div[8] ),
    .SCE(scan_en),
    .Q(\baud_div[12] ));
 sky130_fd_sc_hd__sdfrtp_2 _1628_ (.CLK(clk),
    .D(_0238_),
    .RESET_B(reset_n),
    .SCD(\baud_div[9] ),
    .SCE(scan_en),
    .Q(\baud_div[13] ));
 sky130_fd_sc_hd__sdfrtp_2 _1629_ (.CLK(clk),
    .D(_0239_),
    .RESET_B(reset_n),
    .SCD(\baud_div[10] ),
    .SCE(scan_en),
    .Q(\baud_div[14] ));
 sky130_fd_sc_hd__sdfrtp_2 _1630_ (.CLK(clk),
    .D(_0240_),
    .RESET_B(reset_n),
    .SCD(\baud_div[11] ),
    .SCE(scan_en),
    .Q(\baud_div[15] ));
 sky130_fd_sc_hd__sdfrtp_2 _1631_ (.CLK(clk),
    .D(_0241_),
    .RESET_B(reset_n),
    .SCD(\baud_div[12] ),
    .SCE(scan_en),
    .Q(\irq_status[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1632_ (.CLK(clk),
    .D(_0242_),
    .RESET_B(reset_n),
    .SCD(\baud_div[13] ),
    .SCE(scan_en),
    .Q(\irq_status[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1633_ (.CLK(clk),
    .D(_0243_),
    .RESET_B(reset_n),
    .SCD(\baud_div[14] ),
    .SCE(scan_en),
    .Q(\irq_status[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1634_ (.CLK(clk),
    .D(_0244_),
    .RESET_B(reset_n),
    .SCD(\baud_div[15] ),
    .SCE(scan_en),
    .Q(\irq_status[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1635_ (.CLK(clk),
    .D(_0245_),
    .RESET_B(reset_n),
    .SCD(\irq_status[5] ),
    .SCE(scan_en),
    .Q(\irq_status[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1637_ (.CLK(clk),
    .D(_0001_),
    .RESET_B(reset_n),
    .SCD(\irq_status[4] ),
    .SCE(scan_en),
    .Q(\u_uart_rx_engine.rx_state[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1638_ (.CLK(clk),
    .D(_0002_),
    .RESET_B(reset_n),
    .SCD(\irq_status[3] ),
    .SCE(scan_en),
    .Q(\u_uart_rx_engine.rx_state[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1639_ (.CLK(clk),
    .D(_0003_),
    .RESET_B(reset_n),
    .SCD(\irq_status[2] ),
    .SCE(scan_en),
    .Q(\u_uart_rx_engine.rx_state[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1640_ (.CLK(clk),
    .D(\u_uart_tx_engine.tx_count[0] ),
    .RESET_B(reset_n),
    .SCD(\irq_status[1] ),
    .SCE(scan_en),
    .Q(tx_fifo_level[0]));
 sky130_fd_sc_hd__sdfrtp_2 _1641_ (.CLK(clk),
    .D(\u_uart_tx_engine.tx_count[1] ),
    .RESET_B(reset_n),
    .SCD(\u_uart_rx_engine.rx_state[1] ),
    .SCE(scan_en),
    .Q(tx_fifo_level[1]));
 sky130_fd_sc_hd__sdfrtp_2 _1642_ (.CLK(clk),
    .D(\u_uart_tx_engine.tx_count[2] ),
    .RESET_B(reset_n),
    .SCD(\u_uart_rx_engine.rx_state[2] ),
    .SCE(scan_en),
    .Q(tx_fifo_level[2]));
 sky130_fd_sc_hd__sdfrtp_2 _1643_ (.CLK(clk),
    .D(\u_uart_tx_engine.tx_count[3] ),
    .RESET_B(reset_n),
    .SCD(\u_uart_rx_engine.rx_state[3] ),
    .SCE(scan_en),
    .Q(tx_fifo_level[3]));
 sky130_fd_sc_hd__sdfrtp_2 _1644_ (.CLK(clk),
    .D(\u_uart_tx_engine.tx_count[4] ),
    .RESET_B(reset_n),
    .SCD(tx_fifo_level[0]),
    .SCE(scan_en),
    .Q(tx_fifo_level[4]));
 sky130_fd_sc_hd__sdfrtp_2 _1645_ (.CLK(clk),
    .D(\u_uart_rx_engine.rx_count[0] ),
    .RESET_B(reset_n),
    .SCD(tx_fifo_level[1]),
    .SCE(scan_en),
    .Q(rx_fifo_level[0]));
 sky130_fd_sc_hd__sdfrtp_2 _1646_ (.CLK(clk),
    .D(\u_uart_rx_engine.rx_count[1] ),
    .RESET_B(reset_n),
    .SCD(tx_fifo_level[2]),
    .SCE(scan_en),
    .Q(rx_fifo_level[1]));
 sky130_fd_sc_hd__sdfrtp_2 _1647_ (.CLK(clk),
    .D(\u_uart_rx_engine.rx_count[2] ),
    .RESET_B(reset_n),
    .SCD(tx_fifo_level[3]),
    .SCE(scan_en),
    .Q(rx_fifo_level[2]));
 sky130_fd_sc_hd__sdfrtp_2 _1648_ (.CLK(clk),
    .D(\u_uart_rx_engine.rx_count[3] ),
    .RESET_B(reset_n),
    .SCD(tx_fifo_level[4]),
    .SCE(scan_en),
    .Q(rx_fifo_level[3]));
 sky130_fd_sc_hd__sdfrtp_2 _1649_ (.CLK(clk),
    .D(\u_uart_rx_engine.rx_count[4] ),
    .RESET_B(reset_n),
    .SCD(rx_fifo_level[0]),
    .SCE(scan_en),
    .Q(rx_fifo_level[4]));
 sky130_fd_sc_hd__sdfrtp_2 _1650_ (.CLK(clk),
    .D(_0037_),
    .RESET_B(reset_n),
    .SCD(rx_fifo_level[1]),
    .SCE(scan_en),
    .Q(framing_error_event));
 sky130_fd_sc_hd__sdfrtp_2 _1651_ (.CLK(clk),
    .D(_0044_),
    .RESET_B(reset_n),
    .SCD(rx_fifo_level[2]),
    .SCE(scan_en),
    .Q(rx_overflow_event));
 sky130_fd_sc_hd__sdfrtp_2 _1652_ (.CLK(clk),
    .D(_0038_),
    .RESET_B(reset_n),
    .SCD(rx_fifo_level[3]),
    .SCE(scan_en),
    .Q(packet_done_event));
 sky130_fd_sc_hd__sdfrtp_2 _1653_ (.CLK(clk),
    .D(_0246_),
    .RESET_B(reset_n),
    .SCD(rx_fifo_level[4]),
    .SCE(scan_en),
    .Q(\u_uart_rx_engine.rx_bit_index[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1654_ (.CLK(clk),
    .D(_0247_),
    .RESET_B(reset_n),
    .SCD(framing_error_event),
    .SCE(scan_en),
    .Q(\u_uart_rx_engine.rx_bit_index[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1655_ (.CLK(clk),
    .D(_0248_),
    .RESET_B(reset_n),
    .SCD(rx_overflow_event),
    .SCE(scan_en),
    .Q(\u_uart_rx_engine.rx_bit_index[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1656_ (.CLK(clk),
    .D(_0249_),
    .RESET_B(reset_n),
    .SCD(packet_done_event),
    .SCE(scan_en),
    .Q(\tx_data_byte[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1657_ (.CLK(clk),
    .D(_0250_),
    .RESET_B(reset_n),
    .SCD(\u_uart_rx_engine.rx_bit_index[0] ),
    .SCE(scan_en),
    .Q(\tx_data_byte[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1658_ (.CLK(clk),
    .D(_0251_),
    .RESET_B(reset_n),
    .SCD(\u_uart_rx_engine.rx_bit_index[1] ),
    .SCE(scan_en),
    .Q(\tx_data_byte[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1659_ (.CLK(clk),
    .D(_0252_),
    .RESET_B(reset_n),
    .SCD(\u_uart_rx_engine.rx_bit_index[2] ),
    .SCE(scan_en),
    .Q(\tx_data_byte[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1660_ (.CLK(clk),
    .D(_0253_),
    .RESET_B(reset_n),
    .SCD(\tx_data_byte[0] ),
    .SCE(scan_en),
    .Q(\tx_data_byte[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1661_ (.CLK(clk),
    .D(_0254_),
    .RESET_B(reset_n),
    .SCD(\tx_data_byte[1] ),
    .SCE(scan_en),
    .Q(\tx_data_byte[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1662_ (.CLK(clk),
    .D(_0255_),
    .RESET_B(reset_n),
    .SCD(\tx_data_byte[2] ),
    .SCE(scan_en),
    .Q(\tx_data_byte[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _1663_ (.CLK(clk),
    .D(_0039_),
    .RESET_B(reset_n),
    .SCD(\tx_data_byte[3] ),
    .SCE(scan_en),
    .Q(\u_uart_rx_engine.rx_count[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1664_ (.CLK(clk),
    .D(_0040_),
    .RESET_B(reset_n),
    .SCD(\tx_data_byte[4] ),
    .SCE(scan_en),
    .Q(\u_uart_rx_engine.rx_count[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1665_ (.CLK(clk),
    .D(_0041_),
    .RESET_B(reset_n),
    .SCD(\tx_data_byte[5] ),
    .SCE(scan_en),
    .Q(\u_uart_rx_engine.rx_count[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1666_ (.CLK(clk),
    .D(_0042_),
    .RESET_B(reset_n),
    .SCD(\tx_data_byte[6] ),
    .SCE(scan_en),
    .Q(\u_uart_rx_engine.rx_count[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1667_ (.CLK(clk),
    .D(_0043_),
    .RESET_B(reset_n),
    .SCD(\u_uart_rx_engine.rx_count[0] ),
    .SCE(scan_en),
    .Q(\u_uart_rx_engine.rx_count[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1668_ (.CLK(clk),
    .D(_0256_),
    .RESET_B(reset_n),
    .SCD(\u_uart_rx_engine.rx_count[1] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[15][0] ));
 sky130_fd_sc_hd__sdfrtp_2 _1669_ (.CLK(clk),
    .D(_0257_),
    .RESET_B(reset_n),
    .SCD(\u_uart_rx_engine.rx_count[2] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[15][1] ));
 sky130_fd_sc_hd__sdfrtp_2 _1670_ (.CLK(clk),
    .D(_0258_),
    .RESET_B(reset_n),
    .SCD(\u_uart_rx_engine.rx_count[3] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[15][2] ));
 sky130_fd_sc_hd__sdfrtp_2 _1671_ (.CLK(clk),
    .D(_0259_),
    .RESET_B(reset_n),
    .SCD(\u_uart_rx_engine.rx_count[4] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[15][3] ));
 sky130_fd_sc_hd__sdfrtp_2 _1672_ (.CLK(clk),
    .D(_0260_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[15][0] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[15][4] ));
 sky130_fd_sc_hd__sdfrtp_2 _1673_ (.CLK(clk),
    .D(_0261_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[15][1] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[15][5] ));
 sky130_fd_sc_hd__sdfrtp_2 _1674_ (.CLK(clk),
    .D(_0262_),
    .RESET_B(reset_n),
    .SCD(\u_uart_tx_engine.tx_fifo_mem[15][2] ),
    .SCE(scan_en),
    .Q(\u_uart_tx_engine.tx_fifo_mem[15][6] ));
 sky130_fd_sc_hd__conb_1 _1675_ (.LO(rx_fifo_level[5]));
 sky130_fd_sc_hd__conb_1 _1676_ (.LO(tx_fifo_level[5]));
 sky130_fd_sc_hd__sdfsbp_2 _1565_ (.CLK(clk),
    .D(_0183_),
    .SET_B(reset_n),
    .Q(uart_tx));
 assign scan_out[3] = \u_uart_tx_engine.tx_fifo_mem[15][3] ;
 assign scan_out[0] = \u_uart_tx_engine.tx_fifo_mem[15][4] ;
 assign scan_out[1] = \u_uart_tx_engine.tx_fifo_mem[15][5] ;
 assign scan_out[2] = \u_uart_tx_engine.tx_fifo_mem[15][6] ;
endmodule
