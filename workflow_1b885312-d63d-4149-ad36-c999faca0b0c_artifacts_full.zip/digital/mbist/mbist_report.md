# Limited MBIST Collateral

- Status: `autombist_adapter_ready`
- Top module: `uart_packet_engine`
- Detected memories: `2`
- Estimated memory bits: `256`
- Algorithm: `March C-`
- OpenRAM available: `False`
- autombist available: `True`
- Demo scratchpad generated: `False`

For PWM and other memoryless designs, ChipLoop does not claim MBIST was inserted into the design. MBIST is reported as not applicable unless design memories are detected or an explicit MBIST demo mode is requested.
For production MBIST/LBIST, connect this agent to customer DFT tools through a private adapter.
