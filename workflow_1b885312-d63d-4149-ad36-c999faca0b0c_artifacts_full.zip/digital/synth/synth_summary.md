# Digital Synthesis Summary

- **Workflow**: 1b885312-d63d-4149-ad36-c999faca0b0c
- **Status**: `failed` (rc=2)
- **Top module**: `uart_packet_engine`
- **Clock**: `clk` @ **10.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `not found`
- netlist candidates: 1 found
