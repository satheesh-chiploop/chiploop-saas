# IP Packaging & Handoff Report

- Top: `pwm_controller`
- Package: `backend/workflows/2352aa8a-d70f-4c08-ac70-852b2c1ba45d/handoff/pwm_controller_ip_package`
- Zip: `backend/workflows/2352aa8a-d70f-4c08-ac70-852b2c1ba45d/handoff/pwm_controller_ip_package.zip`

## Bucket counts
- **rtl**: 1
- **spec**: 3
- **arch**: 1
- **microarch**: 1
- **regmap**: 2
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 7
