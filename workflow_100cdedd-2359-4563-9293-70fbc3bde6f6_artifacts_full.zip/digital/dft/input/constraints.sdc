# Auto-generated from ChipLoop clock intent
create_clock -name clk -period 2.000 [get_ports {clk}]
