/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/100cdedd-2359-4563-9293-70fbc3bde6f6/3e8a8f3f-afee-44d8-bba6-a4606ab52f26/digital/arch2synthesis/handoff/rtl/pwm_controller.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/100cdedd-2359-4563-9293-70fbc3bde6f6/3e8a8f3f-afee-44d8-bba6-a4606ab52f26/digital/arch2synthesis/handoff/rtl/pwm_controller_regs.v
