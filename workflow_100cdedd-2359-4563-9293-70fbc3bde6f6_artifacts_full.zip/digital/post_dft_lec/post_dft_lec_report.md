# Digital Post-DFT Logic Equivalence Check

- Status: `inconclusive_unresolved_cells`
- Failure reason: `yosys_inconclusive_see_post_dft_lec_log`
- Top module: `pwm_controller`
- Synthesis netlist: `pwm_controller_synth.v`
- Post-DFT netlist: `scan_stitched_netlist.v`
- Unproven points: `0`
