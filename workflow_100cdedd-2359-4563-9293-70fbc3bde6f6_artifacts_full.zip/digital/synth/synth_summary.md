# Digital Synthesis Summary

- **Workflow**: 100cdedd-2359-4563-9293-70fbc3bde6f6
- **Status**: `ok` (rc=0)
- **Top module**: `pwm_controller`
- **Clock**: `clk` @ **10.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/100cdedd-2359-4563-9293-70fbc3bde6f6/3e8a8f3f-afee-44d8-bba6-a4606ab52f26/digital/arch2synthesis/digital/synth/runs/Digital_Arch2Synthesis_100cdedd-2359-4563-9293-70fbc3bde6f6/final/metrics.json`
- netlist candidates: 1 found
