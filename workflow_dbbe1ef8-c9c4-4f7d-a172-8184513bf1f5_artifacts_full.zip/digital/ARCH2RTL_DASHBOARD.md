# Arch2RTL Evidence Dashboard

- Lint: warnings
- Flip-flops: 50
- Latches: 0
- Full-cycle paths: 3
- Half-cycle paths: 2
- Input bits: 439
- Output bits: 342
- Input ports: 34
- Output ports: 29
- Clock: clk
- Reset: reset_n
- Modules: 4
- RTL files: 4
