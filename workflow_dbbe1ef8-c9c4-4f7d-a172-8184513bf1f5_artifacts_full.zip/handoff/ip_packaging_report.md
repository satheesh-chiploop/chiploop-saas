# IP Packaging & Handoff Report

- Top: `motor_control_top`
- Package: `backend/workflows/dbbe1ef8-c9c4-4f7d-a172-8184513bf1f5/handoff/motor_control_top_ip_package`
- Zip: `backend/workflows/dbbe1ef8-c9c4-4f7d-a172-8184513bf1f5/handoff/motor_control_top_ip_package.zip`

## Bucket counts
- **rtl**: 12
- **spec**: 3
- **arch**: 1
- **microarch**: 1
- **regmap**: 2
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 6
