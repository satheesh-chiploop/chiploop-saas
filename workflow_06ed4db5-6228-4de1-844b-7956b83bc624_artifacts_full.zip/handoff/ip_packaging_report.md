# IP Packaging & Handoff Report

- Top: `pwm_controller`
- Package: `backend/workflows/06ed4db5-6228-4de1-844b-7956b83bc624/handoff/pwm_controller_ip_package`
- Zip: `backend/workflows/06ed4db5-6228-4de1-844b-7956b83bc624/handoff/pwm_controller_ip_package.zip`

## Bucket counts
- **rtl**: 3
- **spec**: 3
- **arch**: 1
- **microarch**: 1
- **regmap**: 2
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 7
