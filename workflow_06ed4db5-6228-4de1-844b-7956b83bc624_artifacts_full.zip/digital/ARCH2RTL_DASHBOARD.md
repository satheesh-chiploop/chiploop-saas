# Arch2RTL Evidence Dashboard

- Lint: clean
- Flip-flops: 34
- Latches: 0
- Full-cycle paths: 3
- Half-cycle paths: 2
- Input bits: 28
- Output bits: 17
- Input ports: 7
- Output ports: 3
- Clock: clk
- Reset: reset_n
- Modules: 3
- RTL files: 3
