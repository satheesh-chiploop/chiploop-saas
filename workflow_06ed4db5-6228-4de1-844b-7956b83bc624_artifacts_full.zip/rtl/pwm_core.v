module pwm_core (
    input        clk,
    input        reset_n,
    input        enable,
    input  [7:0] duty_cycle,
    input  [7:0] period,
    output [7:0] counter_value,
    output       pwm_out
);

reg [7:0] counter_value_r;
reg       pwm_out_r;

assign counter_value = counter_value_r;
assign pwm_out = pwm_out_r;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        counter_value_r <= 8'h00;
        pwm_out_r <= 1'b0;
    end else begin
        if (!enable) begin
            counter_value_r <= 8'h00;
            pwm_out_r <= 1'b0;
        end else if (period == 8'h00) begin
            counter_value_r <= 8'h00;
            pwm_out_r <= 1'b0;
        end else begin
            if (counter_value_r >= period) begin
                counter_value_r <= 8'h00;
            end else begin
                counter_value_r <= counter_value_r + 8'h01;
            end
            pwm_out_r <= (counter_value_r < duty_cycle);
        end
    end
end

endmodule
