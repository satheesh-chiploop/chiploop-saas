module pwm_register_map (
    input        clk,
    input        reset_n,
    input        wr_en,
    input  [7:0] wr_addr,
    input  [7:0] wr_data,
    input        rd_en,
    input  [7:0] rd_addr,
    input  [7:0] counter_value_in,
    output       enable,
    output [7:0] duty_cycle,
    output [7:0] period,
    output [7:0] rd_data
);

reg        enable_r;
reg [7:0]  duty_cycle_r;
reg [7:0]  period_r;
reg [7:0]  rd_data_r;

assign enable = enable_r;
assign duty_cycle = duty_cycle_r;
assign period = period_r;
assign rd_data = rd_data_r;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        enable_r <= 1'b0;
        duty_cycle_r <= 8'h00;
        period_r <= 8'h00;
        rd_data_r <= 8'h00;
    end else begin
        if (wr_en) begin
            case (wr_addr)
                8'h00: enable_r <= wr_data[0];
                8'h04: duty_cycle_r <= wr_data;
                8'h08: period_r <= wr_data;
                default: begin
                    enable_r <= enable_r;
                    duty_cycle_r <= duty_cycle_r;
                    period_r <= period_r;
                end
            endcase
        end
        if (rd_en) begin
            case (rd_addr)
                8'h00: rd_data_r <= {7'b0000000, enable_r};
                8'h04: rd_data_r <= duty_cycle_r;
                8'h08: rd_data_r <= period_r;
                8'h0C: rd_data_r <= counter_value_in;
                default: rd_data_r <= 8'h00;
            endcase
        end else begin
            rd_data_r <= rd_data_r;
        end
    end
end

endmodule
