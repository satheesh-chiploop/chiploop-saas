module pwm_controller (
    input        clk,
    input        reset_n,
    input        wr_en,
    input  [7:0] wr_addr,
    input  [7:0] wr_data,
    input        rd_en,
    input  [7:0] rd_addr,
    output [7:0] rd_data,
    output       pwm_out,
    output [7:0] counter_value
);

wire        enable;
wire [7:0]  duty_cycle;
wire [7:0]  period;
wire [7:0]  reg_rd_data;

assign rd_data = reg_rd_data;

pwm_register_map u_pwm_register_map (
    .clk(clk),
    .reset_n(reset_n),
    .wr_en(wr_en),
    .wr_addr(wr_addr),
    .wr_data(wr_data),
    .rd_en(rd_en),
    .rd_addr(rd_addr),
    .counter_value_in(counter_value),
    .enable(enable),
    .duty_cycle(duty_cycle),
    .period(period),
    .rd_data(reg_rd_data)
);

pwm_core u_pwm_core (
    .clk(clk),
    .reset_n(reset_n),
    .enable(enable),
    .duty_cycle(duty_cycle),
    .period(period),
    .counter_value(counter_value),
    .pwm_out(pwm_out)
);

endmodule
