# System Software Validation Ingest Summary

- Generated at: 2026-08-11T20:06:05.796986+00:00
- Source workflow id: `a010ba32-8ec4-46ac-bf22-8fbc9b349354`
- Validation scope: `software_only`
- Co-sim enabled: `False`
- Overall ingest status: `ready`

## Discovered assets

- `software_package_manifest` → exists=`True` | source=`supabase` | resolved=`backend/workflows/a010ba32-8ec4-46ac-bf22-8fbc9b349354/system/software/package/system_software_package.json`
- `build_manifest` → exists=`True` | source=`supabase` | resolved=`backend/workflows/a010ba32-8ec4-46ac-bf22-8fbc9b349354/system/software/system_software_build_manifest.json`
- `test_manifest` → exists=`False` | source=`missing` | resolved=``
- `mock_manifest` → exists=`False` | source=`missing` | resolved=``
- `sdk_manifest` → exists=`True` | source=`supabase` | resolved=`backend/workflows/a010ba32-8ec4-46ac-bf22-8fbc9b349354/system/software/sdk/system_software_sdk_manifest.json`
- `application_manifest` → exists=`True` | source=`supabase` | resolved=`backend/workflows/a010ba32-8ec4-46ac-bf22-8fbc9b349354/system/software/apps/system_software_application_manifest.json`
- `tools_manifest` → exists=`False` | source=`missing` | resolved=``
- `adapter_manifest` → exists=`True` | source=`supabase` | resolved=`backend/workflows/a010ba32-8ec4-46ac-bf22-8fbc9b349354/system/software/adapter/system_software_adapter_manifest.json`
- `services_manifest` → exists=`True` | source=`supabase` | resolved=`backend/workflows/a010ba32-8ec4-46ac-bf22-8fbc9b349354/system/software/services/system_software_core_services_manifest.json`
- `input_contract` → exists=`True` | source=`supabase` | resolved=`backend/workflows/a010ba32-8ec4-46ac-bf22-8fbc9b349354/system/software/input/system_software_input_contract.json`
- `api_contract` → exists=`True` | source=`supabase` | resolved=`backend/workflows/a010ba32-8ec4-46ac-bf22-8fbc9b349354/system/software/sdk/system_software_api_contract.json`
- `executive_summary` → exists=`False` | source=`missing` | resolved=``

## Workspace members

- `sdk/adaptive_aero_control`
- `services`
- `adapter/adaptive_aero_control_adapter`
- `apps/control_service`
- `apps/diagnostics`
- `apps/demo_cli`

## Missing required assets

- none
