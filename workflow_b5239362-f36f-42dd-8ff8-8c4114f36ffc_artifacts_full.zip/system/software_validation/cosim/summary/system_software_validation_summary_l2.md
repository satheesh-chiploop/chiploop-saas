# System Software Validation Summary (L2)

- Generated at: `2026-08-11T20:06:41.421558+00:00`
- L1 ready: `False`
- Harness status: `ready`
- Execution status: `partial_pass`
- Trace validation status: `pass`
- Final correctness verdict: **pass**

## Scenario totals

- Scenario count: `9`
- Passed: `6`
- Failed: `0`
- Not applicable: `3`
- Blocked: `0`

## Mismatch categories
- none
