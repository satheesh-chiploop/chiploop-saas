# System Software CoSim Harness Summary

- Generated at: `2026-08-11T20:06:12.947889+00:00`
- L1 ready: `None`
- Harness status: `ready`
- Scenario count: `9`

## Blocked dependencies
- none

## Resolved commands
- `control_service_boot_smoke` → `cargo run -p ss_app_control_service -- --scenario control_service_boot_smoke`
- `control_service_register_rw_basic` → `cargo run -p ss_app_control_service -- --scenario control_service_register_rw_basic`
- `diagnostics_boot_smoke` → `cargo run -p ss_app_diagnostics -- --scenario diagnostics_boot_smoke`
- `diagnostics_register_rw_basic` → `cargo run -p ss_app_diagnostics -- --scenario diagnostics_register_rw_basic`
- `demo_cli_boot_smoke` → `cargo run -p ss_app_demo_cli -- --scenario demo_cli_boot_smoke`
- `demo_cli_register_rw_basic` → `cargo run -p ss_app_demo_cli -- --scenario demo_cli_register_rw_basic`
