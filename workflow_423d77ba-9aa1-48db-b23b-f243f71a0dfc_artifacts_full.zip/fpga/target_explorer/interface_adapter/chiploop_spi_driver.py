"""Generated ChipLoop SPI Mode-0 host transport.

Command N is committed when chip-select rises.  The response visible during
that exchange is the previous core snapshot, so callers should pipeline or
perform a second exchange when they need the response to command N.
"""
from typing import Callable, Mapping

INPUT_BITS = 203
OUTPUT_BITS = 250
FRAME_BITS = 250
FRAME_BYTES = (FRAME_BITS + 7) // 8
INPUT_MAP = [{'port': 'cfg_valid', 'width': 1, 'lsb': 0}, {'port': 'cfg_we', 'width': 1, 'lsb': 1}, {'port': 'cfg_addr', 'width': 6, 'lsb': 2}, {'port': 'cfg_wdata', 'width': 64, 'lsb': 8}, {'port': 'req_ready', 'width': 1, 'lsb': 72}, {'port': 'rsp_valid', 'width': 1, 'lsb': 73}, {'port': 'rsp_data', 'width': 128, 'lsb': 74}, {'port': 'actuator_cmd_ready', 'width': 1, 'lsb': 202}]
OUTPUT_MAP = [{'port': 'cfg_rdata', 'width': 64, 'lsb': 186}, {'port': 'req_valid', 'width': 1, 'lsb': 185}, {'port': 'req_data', 'width': 128, 'lsb': 57}, {'port': 'rsp_ready', 'width': 1, 'lsb': 56}, {'port': 'actuator_cmd_valid', 'width': 1, 'lsb': 55}, {'port': 'actuator_cmd', 'width': 32, 'lsb': 23}, {'port': 'fault_irq', 'width': 1, 'lsb': 22}, {'port': 'busy', 'width': 1, 'lsb': 21}, {'port': 'timeout_fault', 'width': 1, 'lsb': 20}, {'port': 'stale_fault', 'width': 1, 'lsb': 19}, {'port': 'invalid_rsp_fault', 'width': 1, 'lsb': 18}, {'port': 'clamp_ovr', 'width': 1, 'lsb': 17}, {'port': 'fallback_active', 'width': 1, 'lsb': 16}, {'port': 'last_seq', 'width': 8, 'lsb': 8}, {'port': 'last_req_id', 'width': 8, 'lsb': 0}]

def _mask(width: int) -> int:
    return (1 << width) - 1

def pack_command(values: Mapping[str, int]) -> bytes:
    frame = 0
    for field in INPUT_MAP:
        value = int(values.get(field["port"], 0))
        if value < 0 or value > _mask(field["width"]):
            raise ValueError(f'{field["port"]} exceeds {field["width"]} bits')
        frame |= value << field["lsb"]
    return frame.to_bytes(FRAME_BYTES, "big")

def unpack_response(raw: bytes) -> dict[str, int]:
    if len(raw) != FRAME_BYTES:
        raise ValueError(f"expected {FRAME_BYTES} response bytes, got {len(raw)}")
    # Response bits leave the FPGA first and are followed by zero padding when
    # the command side determines a longer full-duplex frame.
    value = int.from_bytes(raw, "big") >> (FRAME_BYTES * 8 - OUTPUT_BITS)
    return {field["port"]: (value >> field["lsb"]) & _mask(field["width"]) for field in OUTPUT_MAP}

class ChipLoopSpiDevice:
    def __init__(self, transfer: Callable[[bytes], bytes]):
        self._transfer = transfer

    def exchange(self, values: Mapping[str, int]) -> dict[str, int]:
        response = self._transfer(pack_command(values))
        return unpack_response(response)
