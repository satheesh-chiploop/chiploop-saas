module adaptive_aero_control_top (
    clk,
    reset_n,
    cfg_valid,
    cfg_we,
    cfg_addr,
    cfg_wdata,
    cfg_rdata,
    req_valid,
    req_ready,
    req_data,
    rsp_valid,
    rsp_ready,
    rsp_data,
    actuator_cmd_valid,
    actuator_cmd_ready,
    actuator_cmd,
    fault_irq,
    busy,
    timeout_fault,
    stale_fault,
    invalid_rsp_fault,
    clamp_ovr,
    fallback_active,
    last_seq,
    last_req_id
);

input clk;
input reset_n;
input cfg_valid;
input cfg_we;
input [5:0] cfg_addr;
input [63:0] cfg_wdata;
output [63:0] cfg_rdata;
output req_valid;
input req_ready;
output [127:0] req_data;
input rsp_valid;
output rsp_ready;
input [127:0] rsp_data;
output actuator_cmd_valid;
input actuator_cmd_ready;
output [31:0] actuator_cmd;
output fault_irq;
output busy;
output timeout_fault;
output stale_fault;
output invalid_rsp_fault;
output clamp_ovr;
output fallback_active;
output [7:0] last_seq;
output [7:0] last_req_id;
wire ctrl_enable;
wire [2:0] ctrl_mode;
wire ctrl_clear_faults;
wire [11:0] ctrl_timeout_ticks;
wire [11:0] ctrl_stale_ticks;
wire [31:0] ctrl_clamp_min;
wire [31:0] ctrl_clamp_max;
wire [31:0] ctrl_fallback_cmd;
wire [15:0] ctrl_slew_limit;
wire [7:0] ctrl_seq_seed;
wire adaptive_aero_control_csr_ctrl_enable;
wire [2:0] adaptive_aero_control_csr_ctrl_mode;
wire adaptive_aero_control_csr_ctrl_clear_faults;
wire [11:0] adaptive_aero_control_csr_ctrl_timeout_ticks;
wire [11:0] adaptive_aero_control_csr_ctrl_stale_ticks;
wire [31:0] adaptive_aero_control_csr_ctrl_clamp_min;
wire [31:0] adaptive_aero_control_csr_ctrl_clamp_max;
wire [31:0] adaptive_aero_control_csr_ctrl_fallback_cmd;
wire [15:0] adaptive_aero_control_csr_ctrl_slew_limit;
wire [7:0] adaptive_aero_control_csr_ctrl_seq_seed;
wire req_ready_from_u_transport;
wire [127:0] rsp_data_from_u_transport;
wire rsp_valid_from_u_transport;
assign adaptive_aero_control_csr_ctrl_enable = ctrl_enable;
assign adaptive_aero_control_csr_ctrl_mode = ctrl_mode;
assign adaptive_aero_control_csr_ctrl_clear_faults = ctrl_clear_faults;
assign adaptive_aero_control_csr_ctrl_timeout_ticks = ctrl_timeout_ticks;
assign adaptive_aero_control_csr_ctrl_stale_ticks = ctrl_stale_ticks;
assign adaptive_aero_control_csr_ctrl_clamp_min = ctrl_clamp_min;
assign adaptive_aero_control_csr_ctrl_clamp_max = ctrl_clamp_max;
assign adaptive_aero_control_csr_ctrl_fallback_cmd = ctrl_fallback_cmd;
assign adaptive_aero_control_csr_ctrl_slew_limit = ctrl_slew_limit;
assign adaptive_aero_control_csr_ctrl_seq_seed = ctrl_seq_seed;

adaptive_aero_control_csr u_csr (
    .clk(clk),
    .reset_n(reset_n),
    .cfg_valid(cfg_valid),
    .cfg_we(cfg_we),
    .cfg_addr(cfg_addr),
    .cfg_wdata(cfg_wdata),
    .cfg_rdata(cfg_rdata),
    .ctrl_enable(ctrl_enable),
    .ctrl_mode(ctrl_mode),
    .ctrl_clear_faults(ctrl_clear_faults),
    .ctrl_timeout_ticks(ctrl_timeout_ticks),
    .ctrl_stale_ticks(ctrl_stale_ticks),
    .ctrl_clamp_min(ctrl_clamp_min),
    .ctrl_clamp_max(ctrl_clamp_max),
    .ctrl_fallback_cmd(ctrl_fallback_cmd),
    .ctrl_slew_limit(ctrl_slew_limit),
    .ctrl_seq_seed(ctrl_seq_seed),
    .status_busy(busy),
    .status_timeout_fault(timeout_fault),
    .status_stale_fault(stale_fault),
    .status_invalid_rsp_fault(invalid_rsp_fault),
    .status_clamp_ovr(clamp_ovr),
    .status_fallback_active(fallback_active),
    .status_last_seq(last_seq),
    .status_last_req_id(last_req_id)
);

adaptive_aero_control_transport u_transport (
    .clk(clk),
    .reset_n(reset_n),
    .req_valid(req_valid),
    .req_ready(req_ready_from_u_transport),
    .req_data(req_data),
    .rsp_valid(rsp_valid_from_u_transport),
    .rsp_ready(rsp_ready),
    .rsp_data(rsp_data_from_u_transport),
    .req_hold(),
    .rsp_hold()
);

adaptive_aero_control_safety u_safety (
    .clk(clk),
    .reset_n(reset_n),
    .ctrl_enable(ctrl_enable),
    .ctrl_mode(ctrl_mode),
    .ctrl_clear_faults(ctrl_clear_faults),
    .ctrl_timeout_ticks(ctrl_timeout_ticks),
    .ctrl_stale_ticks(ctrl_stale_ticks),
    .ctrl_clamp_min(ctrl_clamp_min),
    .ctrl_clamp_max(ctrl_clamp_max),
    .ctrl_fallback_cmd(ctrl_fallback_cmd),
    .ctrl_slew_limit(ctrl_slew_limit),
    .ctrl_seq_seed(ctrl_seq_seed),
    .req_ready(req_ready),
    .rsp_valid(rsp_valid),
    .rsp_data(rsp_data),
    .req_valid(req_valid),
    .req_data(req_data),
    .rsp_ready(rsp_ready),
    .busy(busy),
    .timeout_fault(timeout_fault),
    .stale_fault(stale_fault),
    .invalid_rsp_fault(invalid_rsp_fault),
    .clamp_ovr(clamp_ovr),
    .fallback_active(fallback_active),
    .fault_irq(fault_irq),
    .last_seq(last_seq),
    .last_req_id(last_req_id),
    .actuator_cmd_valid(actuator_cmd_valid),
    .actuator_cmd_ready(actuator_cmd_ready),
    .actuator_cmd(actuator_cmd)
);

endmodule
