module adaptive_aero_control_safety (
    clk,
    reset_n,
    ctrl_enable,
    ctrl_mode,
    ctrl_clear_faults,
    ctrl_timeout_ticks,
    ctrl_stale_ticks,
    ctrl_clamp_min,
    ctrl_clamp_max,
    ctrl_fallback_cmd,
    ctrl_slew_limit,
    ctrl_seq_seed,
    req_ready,
    rsp_valid,
    rsp_data,
    req_valid,
    req_data,
    rsp_ready,
    busy,
    timeout_fault,
    stale_fault,
    invalid_rsp_fault,
    clamp_ovr,
    fallback_active,
    fault_irq,
    last_seq,
    last_req_id,
    actuator_cmd_valid,
    actuator_cmd_ready,
    actuator_cmd
);

input clk;
input reset_n;
input ctrl_enable;
input [2:0] ctrl_mode;
input ctrl_clear_faults;
input [11:0] ctrl_timeout_ticks;
input [11:0] ctrl_stale_ticks;
input [31:0] ctrl_clamp_min;
input [31:0] ctrl_clamp_max;
input [31:0] ctrl_fallback_cmd;
input [15:0] ctrl_slew_limit;
input [7:0] ctrl_seq_seed;
input req_ready;
input rsp_valid;
input [127:0] rsp_data;
output reg req_valid;
output reg [127:0] req_data;
output reg rsp_ready;
output reg busy;
output reg timeout_fault;
output reg stale_fault;
output reg invalid_rsp_fault;
output reg clamp_ovr;
output reg fallback_active;
output reg fault_irq;
output reg [7:0] last_seq;
output reg [7:0] last_req_id;
output reg actuator_cmd_valid;
input actuator_cmd_ready;
output reg [31:0] actuator_cmd;
reg outstanding;
reg [11:0] watchdog_cnt;
reg [11:0] age_cnt;
reg [7:0] next_seq;
reg [7:0] pending_req_id;
reg [31:0] pending_cmd;
reg [31:0] clamped_cmd;
reg [31:0] slewed_cmd;
reg [31:0] chosen_cmd;
reg [31:0] upper_bound;
reg [31:0] lower_bound;
reg [31:0] rsp_cmd;
reg [7:0] rsp_req_id;
reg [7:0] rsp_seq;
reg rsp_cmd_valid;
reg rsp_req_id_match;
reg rsp_seq_match;
reg rsp_age_valid;
reg timeout_event;
reg stale_event;
reg invalid_event;
reg fault_active;
reg [31:0] fallback_cmd_int;
reg [31:0] prev_cmd;

always @(*) begin
    lower_bound = ctrl_clamp_min;
    upper_bound = ctrl_clamp_max;
    fallback_cmd_int = ctrl_fallback_cmd;
    rsp_req_id = rsp_data[7:0];
    rsp_seq = rsp_data[15:8];
    rsp_cmd = rsp_data[47:16];
    rsp_cmd_valid = rsp_data[48];
    rsp_req_id_match = (rsp_req_id == pending_req_id);
    rsp_seq_match = (rsp_seq == last_seq);
    rsp_age_valid = (age_cnt <= ctrl_stale_ticks);
    timeout_event = outstanding && (watchdog_cnt >= ctrl_timeout_ticks) && (ctrl_timeout_ticks != 12'd0);
    stale_event = outstanding && (age_cnt > ctrl_stale_ticks) && (ctrl_stale_ticks != 12'd0);
    invalid_event = rsp_valid && outstanding && !(rsp_cmd_valid && rsp_req_id_match && rsp_seq_match && rsp_age_valid);
    fault_active = timeout_fault | stale_fault | invalid_rsp_fault;
    chosen_cmd = fallback_cmd_int;
    if (rsp_valid && outstanding && rsp_cmd_valid && rsp_req_id_match && rsp_seq_match && rsp_age_valid) begin
        chosen_cmd = rsp_cmd;
    end
    if (chosen_cmd < lower_bound) begin
        clamped_cmd = lower_bound;
    end else if (chosen_cmd > upper_bound) begin
        clamped_cmd = upper_bound;
    end else begin
        clamped_cmd = chosen_cmd;
    end
    if (ctrl_slew_limit != 16'd0) begin
        if (clamped_cmd > prev_cmd) begin
            if ((clamped_cmd - prev_cmd) > {16'd0, ctrl_slew_limit}) begin
                slewed_cmd = prev_cmd + {16'd0, ctrl_slew_limit};
            end else begin
                slewed_cmd = clamped_cmd;
            end
        end else begin
            if ((prev_cmd - clamped_cmd) > {16'd0, ctrl_slew_limit}) begin
                slewed_cmd = prev_cmd - {16'd0, ctrl_slew_limit};
            end else begin
                slewed_cmd = clamped_cmd;
            end
        end
    end else begin
        slewed_cmd = clamped_cmd;
    end
end

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        req_valid <= 1'b0;
        req_data <= 128'd0;
        rsp_ready <= 1'b0;
        busy <= 1'b0;
        timeout_fault <= 1'b0;
        stale_fault <= 1'b0;
        invalid_rsp_fault <= 1'b0;
        clamp_ovr <= 1'b0;
        fallback_active <= 1'b1;
        fault_irq <= 1'b0;
        last_seq <= 8'd0;
        last_req_id <= 8'd0;
        actuator_cmd_valid <= 1'b0;
        actuator_cmd <= 32'd0;
        outstanding <= 1'b0;
        watchdog_cnt <= 12'd0;
        age_cnt <= 12'd0;
        next_seq <= 8'd1;
        pending_req_id <= 8'd0;
        pending_cmd <= 32'd0;
        prev_cmd <= 32'd0;
    end else begin
        rsp_ready <= outstanding;
        fault_irq <= timeout_fault | stale_fault | invalid_rsp_fault;
        if (ctrl_enable && !outstanding && !timeout_fault && !stale_fault && !invalid_rsp_fault) begin
            req_valid <= 1'b1;
            req_data <= {32'd0, ctrl_mode, ctrl_seq_seed, next_seq, 77'b0};
            pending_req_id <= next_seq;
            last_req_id <= next_seq;
            last_seq <= next_seq;
            outstanding <= 1'b1;
            busy <= 1'b1;
            watchdog_cnt <= 12'd0;
            age_cnt <= 12'd0;
            next_seq <= next_seq + 8'd1;
        end else begin
            req_valid <= 1'b0;
            if (outstanding) begin
                watchdog_cnt <= watchdog_cnt + 12'd1;
                age_cnt <= age_cnt + 12'd1;
            end
            busy <= outstanding;
        end
        if (rsp_valid && outstanding && rsp_cmd_valid && rsp_req_id_match && rsp_seq_match && rsp_age_valid) begin
            actuator_cmd_valid <= 1'b1;
            actuator_cmd <= slewed_cmd;
            prev_cmd <= slewed_cmd;
            pending_cmd <= slewed_cmd;
            fallback_active <= 1'b0;
            outstanding <= 1'b0;
            busy <= 1'b0;
            watchdog_cnt <= 12'd0;
            age_cnt <= 12'd0;
        end else begin
            actuator_cmd_valid <= 1'b1;
            actuator_cmd <= fallback_cmd_int;
            prev_cmd <= fallback_cmd_int;
            fallback_active <= (~ctrl_enable) | timeout_fault | stale_fault | invalid_rsp_fault | !outstanding;
        end
        if (timeout_event) begin
            timeout_fault <= 1'b1;
            outstanding <= 1'b0;
            busy <= 1'b0;
            fallback_active <= 1'b1;
        end
        if (stale_event) begin
            stale_fault <= 1'b1;
            outstanding <= 1'b0;
            busy <= 1'b0;
            fallback_active <= 1'b1;
        end
        if (invalid_event) begin
            invalid_rsp_fault <= 1'b1;
            outstanding <= 1'b0;
            busy <= 1'b0;
            fallback_active <= 1'b1;
        end
        if (ctrl_clear_faults && !timeout_event && !stale_event && !invalid_event) begin
            timeout_fault <= 1'b0;
            stale_fault <= 1'b0;
            invalid_rsp_fault <= 1'b0;
        end
    end
end

endmodule
