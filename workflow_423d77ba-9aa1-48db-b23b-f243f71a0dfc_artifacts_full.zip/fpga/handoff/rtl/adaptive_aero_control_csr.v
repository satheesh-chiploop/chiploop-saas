module adaptive_aero_control_csr (
    clk,
    reset_n,
    cfg_valid,
    cfg_we,
    cfg_addr,
    cfg_wdata,
    cfg_rdata,
    ctrl_enable,
    ctrl_mode,
    ctrl_clear_faults,
    ctrl_timeout_ticks,
    ctrl_stale_ticks,
    ctrl_clamp_min,
    ctrl_clamp_max,
    ctrl_fallback_cmd,
    ctrl_slew_limit,
    ctrl_seq_seed,
    status_busy,
    status_timeout_fault,
    status_stale_fault,
    status_invalid_rsp_fault,
    status_clamp_ovr,
    status_fallback_active,
    status_last_seq,
    status_last_req_id
);

input clk;
input reset_n;
input cfg_valid;
input cfg_we;
input [5:0] cfg_addr;
input [63:0] cfg_wdata;
output [63:0] cfg_rdata;
output reg ctrl_enable;
output reg [2:0] ctrl_mode;
output reg ctrl_clear_faults;
output reg [11:0] ctrl_timeout_ticks;
output reg [11:0] ctrl_stale_ticks;
output reg [31:0] ctrl_clamp_min;
output reg [31:0] ctrl_clamp_max;
output reg [31:0] ctrl_fallback_cmd;
output reg [15:0] ctrl_slew_limit;
output reg [7:0] ctrl_seq_seed;
input status_busy;
input status_timeout_fault;
input status_stale_fault;
input status_invalid_rsp_fault;
input status_clamp_ovr;
input status_fallback_active;
input [7:0] status_last_seq;
input [7:0] status_last_req_id;
reg [63:0] cfg_rdata_r;
assign cfg_rdata = cfg_rdata_r;

localparam [5:0] ADDR_CTRL_CFG        = 6'h00;
localparam [5:0] ADDR_CLAMP_CFG       = 6'h01;
localparam [5:0] ADDR_FALLBACK_CFG    = 6'h02;
localparam [5:0] ADDR_REQ_DESC        = 6'h03;
localparam [5:0] ADDR_REQ_CTRL        = 6'h04;
localparam [5:0] ADDR_RESP_STATUS     = 6'h05;
localparam [5:0] ADDR_CMD_STATUS      = 6'h06;
localparam [5:0] ADDR_FAULT_CLEAR     = 6'h07;
localparam [5:0] ADDR_DESCRIPTOR_STAT = 6'h08;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        ctrl_enable <= 1'b0;
        ctrl_mode <= 3'b000;
        ctrl_clear_faults <= 1'b0;
        ctrl_timeout_ticks <= 12'd128;
        ctrl_stale_ticks <= 12'd64;
        ctrl_clamp_min <= 32'd0;
        ctrl_clamp_max <= 32'h7fffffff;
        ctrl_fallback_cmd <= 32'd0;
        ctrl_slew_limit <= 16'd0;
        ctrl_seq_seed <= 8'd1;
        cfg_rdata_r <= 64'd0;
    end else begin
        ctrl_clear_faults <= 1'b0;
        if (cfg_valid && cfg_we) begin
            case (cfg_addr)
                ADDR_CTRL_CFG: begin
                    ctrl_enable <= cfg_wdata[0];
                    ctrl_mode <= cfg_wdata[3:1];
                    ctrl_clear_faults <= cfg_wdata[4];
                    ctrl_timeout_ticks <= cfg_wdata[16:5];
                    ctrl_stale_ticks <= cfg_wdata[28:17];
                    ctrl_seq_seed <= cfg_wdata[36:29];
                    ctrl_slew_limit <= cfg_wdata[52:37];
                end
                ADDR_CLAMP_CFG: begin
                    ctrl_clamp_min <= cfg_wdata[31:0];
                    ctrl_clamp_max <= cfg_wdata[63:32];
                end
                ADDR_FALLBACK_CFG: begin
                    ctrl_fallback_cmd <= cfg_wdata[31:0];
                end
                ADDR_FAULT_CLEAR: begin
                    ctrl_clear_faults <= cfg_wdata[0];
                end
                default: begin
                end
            endcase
        end
        if (cfg_valid && !cfg_we) begin
            case (cfg_addr)
                ADDR_CTRL_CFG: begin
                    cfg_rdata_r <= {11'b0, ctrl_slew_limit, ctrl_seq_seed, ctrl_stale_ticks, ctrl_timeout_ticks, ctrl_clear_faults, ctrl_mode, ctrl_enable};
                end
                ADDR_CLAMP_CFG: begin
                    cfg_rdata_r <= {ctrl_clamp_max, ctrl_clamp_min};
                end
                ADDR_FALLBACK_CFG: begin
                    cfg_rdata_r <= {32'd0, ctrl_fallback_cmd};
                end
                ADDR_REQ_DESC: begin
                    cfg_rdata_r <= 64'd0;
                end
                ADDR_REQ_CTRL: begin
                    cfg_rdata_r <= {48'd0, ctrl_seq_seed, 7'd0, 1'b0};
                end
                ADDR_RESP_STATUS: begin
                    cfg_rdata_r <= {3'b0, 39'd0, status_last_req_id, status_last_seq, status_fallback_active, status_clamp_ovr, status_invalid_rsp_fault, status_stale_fault, status_timeout_fault, status_busy};
                end
                ADDR_CMD_STATUS: begin
                    cfg_rdata_r <= {32'd0, ctrl_fallback_cmd};
                end
                ADDR_FAULT_CLEAR: begin
                    cfg_rdata_r <= {63'd0, ctrl_clear_faults};
                end
                ADDR_DESCRIPTOR_STAT: begin
                    cfg_rdata_r <= {15'b0, 16'd0, 16'd0, status_last_req_id, status_last_seq, status_busy};
                end
                default: begin
                    cfg_rdata_r <= 64'd0;
                end
            endcase
        end
    end
end

endmodule
