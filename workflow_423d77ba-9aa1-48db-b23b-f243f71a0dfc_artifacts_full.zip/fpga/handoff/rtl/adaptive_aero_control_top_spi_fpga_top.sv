// Auto-generated FPGA-only serialized transport shell.
// The verified core RTL remains unchanged; ASIC flows continue to use the core top.
module adaptive_aero_control_top_spi_fpga_top (
  input  logic clk,
  input  logic reset_n,
  input  logic spi_sclk,
  input  logic spi_cs_n,
  input  logic spi_mosi,
  output logic spi_miso,
  output logic fault_indicator
);
  localparam integer INPUT_BITS = 203;
  localparam integer OUTPUT_BITS = 250;
  logic [INPUT_BITS-1:0] rx_shift, rx_active;
  logic [OUTPUT_BITS-1:0] tx_shift, tx_snapshot;
  logic spi_active;
  logic spi_cs_meta, spi_cs_sync, spi_cs_prev;
  logic core_cfg_valid;
  logic core_cfg_we;
  logic [5:0] core_cfg_addr;
  logic [63:0] core_cfg_wdata;
  logic core_req_ready;
  logic core_rsp_valid;
  logic [127:0] core_rsp_data;
  logic core_actuator_cmd_ready;
  wire [63:0] core_cfg_rdata;
  wire core_req_valid;
  wire [127:0] core_req_data;
  wire core_rsp_ready;
  wire core_actuator_cmd_valid;
  wire [31:0] core_actuator_cmd;
  wire core_fault_irq;
  wire core_busy;
  wire core_timeout_fault;
  wire core_stale_fault;
  wire core_invalid_rsp_fault;
  wire core_clamp_ovr;
  wire core_fallback_active;
  wire [7:0] core_last_seq;
  wire [7:0] core_last_req_id;
  assign core_cfg_valid = rx_active[0 +: 1];
  assign core_cfg_we = rx_active[1 +: 1];
  assign core_cfg_addr = rx_active[2 +: 6];
  assign core_cfg_wdata = rx_active[8 +: 64];
  assign core_req_ready = rx_active[72 +: 1];
  assign core_rsp_valid = rx_active[73 +: 1];
  assign core_rsp_data = rx_active[74 +: 128];
  assign core_actuator_cmd_ready = rx_active[202 +: 1];
  wire [OUTPUT_BITS-1:0] core_response = {core_cfg_rdata, core_req_valid, core_req_data, core_rsp_ready, core_actuator_cmd_valid, core_actuator_cmd, core_fault_irq, core_busy, core_timeout_fault, core_stale_fault, core_invalid_rsp_fault, core_clamp_ovr, core_fallback_active, core_last_seq, core_last_req_id};
  assign fault_indicator = 1'b0;
  // Chip select asynchronously clears only the frame-state bit. Data
  // registers use SPI clock alone, which is legal in ECP5 fabric.
  always_ff @(posedge spi_sclk or posedge spi_cs_n) begin
    if (spi_cs_n) spi_active <= 1'b0;
    else spi_active <= 1'b1;
  end
  always_ff @(posedge spi_sclk) begin
    if (!spi_cs_n) begin
      rx_shift <= {rx_shift[201:0], spi_mosi};
      if (!spi_active) tx_shift <= {tx_snapshot[248:0], 1'b0};
      else tx_shift <= {tx_shift[248:0], 1'b0};
    end
  end
  // Synchronize frame completion into the core clock domain. The host
  // keeps MOSI stable around CS rising as required by the protocol.
  always_ff @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
      spi_cs_meta <= 1'b1; spi_cs_sync <= 1'b1; spi_cs_prev <= 1'b1;
      rx_active <= '0; tx_snapshot <= '0;
    end else begin
      spi_cs_meta <= spi_cs_n; spi_cs_sync <= spi_cs_meta; spi_cs_prev <= spi_cs_sync;
      if (spi_cs_sync && !spi_cs_prev) rx_active <= rx_shift;
      tx_snapshot <= core_response;
    end
  end
  always_comb spi_miso = spi_active ? tx_shift[OUTPUT_BITS-1] : tx_snapshot[OUTPUT_BITS-1];
  adaptive_aero_control_top u_core (
    .clk(clk),
    .reset_n(reset_n),
    .cfg_valid(core_cfg_valid),
    .cfg_we(core_cfg_we),
    .cfg_addr(core_cfg_addr),
    .cfg_wdata(core_cfg_wdata),
    .cfg_rdata(core_cfg_rdata),
    .req_valid(core_req_valid),
    .req_ready(core_req_ready),
    .req_data(core_req_data),
    .rsp_valid(core_rsp_valid),
    .rsp_ready(core_rsp_ready),
    .rsp_data(core_rsp_data),
    .actuator_cmd_valid(core_actuator_cmd_valid),
    .actuator_cmd_ready(core_actuator_cmd_ready),
    .actuator_cmd(core_actuator_cmd),
    .fault_irq(core_fault_irq),
    .busy(core_busy),
    .timeout_fault(core_timeout_fault),
    .stale_fault(core_stale_fault),
    .invalid_rsp_fault(core_invalid_rsp_fault),
    .clamp_ovr(core_clamp_ovr),
    .fallback_active(core_fallback_active),
    .last_seq(core_last_seq),
    .last_req_id(core_last_req_id)
  );
endmodule
