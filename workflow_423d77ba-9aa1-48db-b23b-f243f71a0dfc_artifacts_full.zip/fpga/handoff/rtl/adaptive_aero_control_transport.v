module adaptive_aero_control_transport (
    clk,
    reset_n,
    req_valid,
    req_ready,
    req_data,
    rsp_valid,
    rsp_ready,
    rsp_data,
    req_hold,
    rsp_hold
);

input clk;
input reset_n;
input req_valid;
output req_ready;
input [127:0] req_data;
output reg rsp_valid;
input rsp_ready;
output reg [127:0] rsp_data;
output reg req_hold;
output reg rsp_hold;

reg req_ready_r;
assign req_ready = req_ready_r;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        req_ready_r <= 1'b1;
        rsp_valid <= 1'b0;
        rsp_data <= 128'd0;
        req_hold <= 1'b0;
        rsp_hold <= 1'b0;
    end else begin
        req_ready_r <= 1'b1;
        req_hold <= req_valid && !req_ready_r;
        rsp_hold <= rsp_valid && !rsp_ready;
        if (rsp_valid && rsp_ready) begin
            rsp_valid <= 1'b0;
            rsp_data <= 128'd0;
        end
    end
end

endmodule
