# System Simulation Execution Report

- Top: `temp_monitor_soc_sim`
- Tests run: 6
- Passed: 0
- Failed: 6
- Total runtime (s): 13.45
- Coverage JSON present: False
- Coverage MD present: False

## Run Matrix
- `system_smoke_test` / seed `1` → FAIL (rc=2, 6.339s)
- `system_smoke_test` / seed `2` → FAIL (rc=2, 1.476s)
- `system_smoke_test` / seed `7` → FAIL (rc=2, 1.482s)
- `integrated_input_sanity` / seed `1` → FAIL (rc=2, 1.43s)
- `integrated_input_sanity` / seed `2` → FAIL (rc=2, 1.356s)
- `integrated_input_sanity` / seed `7` → FAIL (rc=2, 1.367s)
