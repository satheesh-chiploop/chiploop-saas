# System Simulation Summary + Coverage

- Top module: temp_monitor_soc_sim
- Status: failed
- Total simulation runs: 6
- Simulation pass count: 0
- Simulation fail count: 6
- Total runtime (s): 13.45
- Coverage status: ok
- Functional coverage %: None
- Coverage bins hit: None
- Coverage total bins: None
- Code line coverage %: None
- Code branch coverage %: None
- Code condition coverage %: None
- Code toggle coverage %: None
- Assertions total: 8
- Assertion failures: 0
- Formal status: pass
- Golden model status: not_enabled
