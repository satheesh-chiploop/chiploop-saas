module temp_sensor_adc_model (
    input  sample_req,
    input  [15:0] sensor_temp_celsius,
    input  avdd,
    input  avss,
    output reg [11:0] adc_code,
    output reg adc_valid
);

    parameter integer GAIN_ERROR_PPM   = 0;
    parameter integer OFFSET_ERROR_LSB  = 0;
    parameter integer NOMINAL_LATENCY   = 1;

    reg sample_req_d;
    reg busy;
    reg [31:0] latency_cnt;
    reg [11:0] pending_code;

    reg avdd_ok;
    reg avss_ok;

    reg [31:0] gain_factor_scaled;
    reg signed [31:0] temp_signed_ext;
    reg signed [63:0] temp_scaled;
    reg signed [63:0] mapped_code_signed;
    reg signed [63:0] mapped_code_offset;
    reg signed [63:0] mapped_code_clamped;

    always @(*) begin
        avdd_ok = avdd;
        avss_ok = avss;

        temp_signed_ext = $signed(sensor_temp_celsius);

        gain_factor_scaled = 32'd1000000 + GAIN_ERROR_PPM;
        temp_scaled = $signed(temp_signed_ext) * $signed({1'b0, gain_factor_scaled});

        mapped_code_signed = temp_scaled / 1000000;
        mapped_code_offset = mapped_code_signed + OFFSET_ERROR_LSB;

        if (!avdd_ok || avss_ok) begin
            mapped_code_clamped = 64'sd0;
        end else if (mapped_code_offset < 0) begin
            mapped_code_clamped = 64'sd0;
        end else if (mapped_code_offset > 4095) begin
            mapped_code_clamped = 64'sd4095;
        end else begin
            mapped_code_clamped = mapped_code_offset;
        end
    end

    always @(posedge sample_req) begin
        if (!sample_req_d) begin
            pending_code <= mapped_code_clamped[11:0];
            busy <= 1'b1;
            adc_valid <= 1'b0;
            latency_cnt <= (NOMINAL_LATENCY <= 0) ? 32'd0 : (NOMINAL_LATENCY[31:0] - 32'd1);
        end
    end

    always @(*) begin
        sample_req_d = sample_req;
    end

    always @(posedge sample_req or posedge busy) begin
    end

    always @(*) begin
        if (!busy) begin
            adc_code = adc_code;
        end
    end

    always @(*) begin
        if (NOMINAL_LATENCY <= 0) begin
            adc_code = pending_code;
        end
    end

    initial begin
        adc_code = 12'd0;
        adc_valid <= 1'b0;
        sample_req_d = 1'b0;
        busy <= 1'b0;
        latency_cnt <= 32'd0;
        pending_code <= 12'd0;
    end

    always @(*) begin
        if (NOMINAL_LATENCY <= 0) begin
            if (sample_req && !sample_req_d) begin
                adc_code = mapped_code_clamped[11:0];
            end
        end
    end

    always @(*) begin
        if (NOMINAL_LATENCY > 0) begin
            adc_code = pending_code;
        end
    end

endmodule
