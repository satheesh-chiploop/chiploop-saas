module temp_monitor_digital (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    adc_code,
    adc_valid,
    rd_data,
    sample_req,
    alert_irq,
    temp_code,
    threshold_code,
    alert_status
);

input clk;
input reset_n;
input wr_en;
input [7:0] wr_addr;
input [15:0] wr_data;
input rd_en;
input [7:0] rd_addr;
input [11:0] adc_code;
input adc_valid;
output [15:0] rd_data;
output sample_req;
output alert_irq;
output [11:0] temp_code;
output [11:0] threshold_code;
output alert_status;

reg [15:0] rd_data_r;
reg sample_req_r;
reg alert_irq_r;
reg [11:0] temp_code_r;
reg [11:0] threshold_code_r;
reg alert_status_r;

reg [15:0] control_reg;
reg [11:0] threshold_reg;
reg [11:0] latest_temp;
reg [15:0] sample_count;
reg irq_status_alert;
reg irq_status_sample_done;
reg status_sample_done;
reg status_alert_pending;
reg status_adc_valid_seen;
reg status_busy;

reg [11:0] adc_sample_prev;
reg adc_sample_prev_valid;

reg [11:0] moving_avg_result;
reg [12:0] avg_sum;

reg sample_req_pulse;
reg sample_req_next;
reg [11:0] filtered_temp_next;
reg [11:0] latest_temp_next;
reg [15:0] sample_count_next;
reg irq_status_alert_next;
reg irq_status_sample_done_next;
reg status_sample_done_next;
reg status_alert_pending_next;
reg status_adc_valid_seen_next;
reg status_busy_next;
reg alert_status_next;
reg [15:0] control_reg_next;
reg [11:0] threshold_reg_next;
reg [11:0] adc_sample_prev_next;
reg adc_sample_prev_valid_next;

wire control_enable;
wire control_sample_start;
wire control_irq_enable;
wire control_alert_clear;
wire irq_any;
wire sample_done_clear;
wire alert_clear;
wire [15:0] read_data_mux;
wire [15:0] status_readback;
wire [15:0] threshold_readback;
wire [15:0] latest_temp_readback;
wire [15:0] sample_count_readback;
wire [15:0] irq_status_readback;

assign control_enable = control_reg[0];
assign control_sample_start = control_reg[1];
assign control_irq_enable = control_reg[2];
assign control_alert_clear = control_reg[3];
assign irq_any = irq_status_alert | irq_status_sample_done;
assign sample_done_clear = wr_en & (wr_addr == 8'h18) & wr_data[1];
assign alert_clear = (wr_en & (wr_addr == 8'h18) & wr_data[0]) | (wr_en & (wr_addr == 8'h00) & wr_data[3]);

assign rd_data = rd_data_r;
assign sample_req = sample_req_r;
assign alert_irq = alert_irq_r;
assign temp_code = temp_code_r;
assign threshold_code = threshold_code_r;
assign alert_status = alert_status_r;

assign status_readback = {12'b000000000000, status_busy, status_adc_valid_seen, status_alert_pending, status_sample_done};
assign threshold_readback = {4'b0000, threshold_reg};
assign latest_temp_readback = {4'b0000, latest_temp};
assign sample_count_readback = sample_count;
assign irq_status_readback = {14'b00000000000000, irq_status_sample_done, irq_status_alert};
assign read_data_mux = (rd_addr == 8'h00) ? {12'b000000000000, control_reg[3:0]} :
                       (rd_addr == 8'h04) ? status_readback :
                       (rd_addr == 8'h08) ? threshold_readback :
                       (rd_addr == 8'h0C) ? latest_temp_readback :
                       (rd_addr == 8'h10) ? sample_count_readback :
                       (rd_addr == 8'h14) ? irq_status_readback :
                       (rd_addr == 8'h18) ? 16'h0000 :
                       16'h0000;

always @(*) begin
    sample_req_pulse = 1'b0;
    sample_req_next = 1'b0;
    filtered_temp_next = latest_temp;
    latest_temp_next = latest_temp;
    sample_count_next = sample_count;
    irq_status_alert_next = irq_status_alert;
    irq_status_sample_done_next = irq_status_sample_done;
    status_sample_done_next = status_sample_done;
    status_alert_pending_next = status_alert_pending;
    status_adc_valid_seen_next = status_adc_valid_seen;
    status_busy_next = status_busy;
    alert_status_next = alert_status_r;
    control_reg_next = control_reg;
    threshold_reg_next = threshold_reg;
    adc_sample_prev_next = adc_sample_prev;
    adc_sample_prev_valid_next = adc_sample_prev_valid;

    if (wr_en && (wr_addr == 8'h00)) begin
        control_reg_next[0] = wr_data[0];
        control_reg_next[2] = wr_data[2];
        control_reg_next[1] = 1'b0;
        control_reg_next[3] = 1'b0;
    end

    if (wr_en && (wr_addr == 8'h08)) begin
        threshold_reg_next = wr_data[11:0];
    end

    if (wr_en && (wr_addr == 8'h00) && wr_data[1]) begin
        sample_req_pulse = 1'b1;
        status_busy_next = 1'b1;
    end

    if (wr_en && (wr_addr == 8'h00) && wr_data[3]) begin
        alert_status_next = 1'b0;
        status_alert_pending_next = 1'b0;
    end

    if (wr_en && (wr_addr == 8'h18)) begin
        if (wr_data[0]) begin
            irq_status_alert_next = 1'b0;
            alert_status_next = 1'b0;
            status_alert_pending_next = 1'b0;
        end
        if (wr_data[1]) begin
            irq_status_sample_done_next = 1'b0;
            status_sample_done_next = 1'b0;
        end
    end

    if (control_enable && !status_busy && !sample_req_pulse) begin
        sample_req_pulse = 1'b1;
        status_busy_next = 1'b1;
    end

    if (adc_valid) begin
        status_adc_valid_seen_next = 1'b1;
        status_sample_done_next = 1'b1;
        irq_status_sample_done_next = 1'b1;
        status_busy_next = 1'b0;
        sample_count_next = sample_count + 16'd1;

        avg_sum = {1'b0, adc_code} + {1'b0, adc_sample_prev};
        moving_avg_result = avg_sum[12:1];
        latest_temp_next = moving_avg_result;
        filtered_temp_next = moving_avg_result;

        if (moving_avg_result > threshold_reg) begin
            alert_status_next = 1'b1;
            status_alert_pending_next = 1'b1;
            irq_status_alert_next = 1'b1;
        end
    end

    if (wr_en && (wr_addr == 8'h18) && wr_data[0]) begin
        alert_status_next = 1'b0;
        status_alert_pending_next = 1'b0;
    end

    if (wr_en && (wr_addr == 8'h18) && wr_data[1]) begin
        status_sample_done_next = 1'b0;
    end

    adc_sample_prev_next = adc_code;
    adc_sample_prev_valid_next = adc_valid;
end

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        rd_data_r <= 16'h0000;
        sample_req_r <= 1'b0;
        alert_irq_r <= 1'b0;
        temp_code_r <= 12'h000;
        threshold_code_r <= 12'h000;
        alert_status_r <= 1'b0;
        control_reg <= 16'h0000;
        threshold_reg <= 12'h000;
        latest_temp <= 12'h000;
        sample_count <= 16'h0000;
        irq_status_alert <= 1'b0;
        irq_status_sample_done <= 1'b0;
        status_sample_done <= 1'b0;
        status_alert_pending <= 1'b0;
        status_adc_valid_seen <= 1'b0;
        status_busy <= 1'b0;
        adc_sample_prev <= 12'h000;
        adc_sample_prev_valid <= 1'b0;
    end else begin
        rd_data_r <= rd_en ? read_data_mux : rd_data_r;
        sample_req_r <= sample_req_pulse;
        alert_irq_r <= control_irq_enable & irq_any;
        temp_code_r <= latest_temp_next;
        threshold_code_r <= threshold_reg_next;
        alert_status_r <= alert_status_next;
        control_reg <= control_reg_next;
        threshold_reg <= threshold_reg_next;
        latest_temp <= latest_temp_next;
        sample_count <= sample_count_next;
        irq_status_alert <= irq_status_alert_next;
        irq_status_sample_done <= irq_status_sample_done_next;
        status_sample_done <= status_sample_done_next;
        status_alert_pending <= status_alert_pending_next;
        status_adc_valid_seen <= status_adc_valid_seen_next;
        status_busy <= status_busy_next;
        adc_sample_prev <= adc_sample_prev_next;
        adc_sample_prev_valid <= adc_sample_prev_valid_next;
    end
end

endmodule
