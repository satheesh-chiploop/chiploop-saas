# Digital Synthesis Summary

- **Workflow**: 8a132fe1-fcae-4fbb-b6f5-02fbf7bd8734
- **Status**: `ok` (rc=0)
- **Top module**: `temp_monitor_soc_phys`
- **Clock**: `clk` @ **10.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/8a132fe1-fcae-4fbb-b6f5-02fbf7bd8734/ca619f8a-4333-4761-8bdd-e413d818f3c5/digital/digital/synth/runs/System_PD_8a132fe1-fcae-4fbb-b6f5-02fbf7bd8734/final/metrics.json`
- netlist candidates: 1 found
