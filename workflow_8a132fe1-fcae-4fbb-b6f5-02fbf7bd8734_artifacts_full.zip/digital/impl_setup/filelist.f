/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/8a132fe1-fcae-4fbb-b6f5-02fbf7bd8734/ca619f8a-4333-4761-8bdd-e413d818f3c5/digital/system/imported_rtl/temp_sensor_adc_model.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/8a132fe1-fcae-4fbb-b6f5-02fbf7bd8734/ca619f8a-4333-4761-8bdd-e413d818f3c5/digital/system/imported_rtl/temp_monitor_digital.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/8a132fe1-fcae-4fbb-b6f5-02fbf7bd8734/ca619f8a-4333-4761-8bdd-e413d818f3c5/digital/system/imported_rtl/temp_monitor_soc_phys.sv
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/8a132fe1-fcae-4fbb-b6f5-02fbf7bd8734/ca619f8a-4333-4761-8bdd-e413d818f3c5/digital/system/imported_rtl/temp_monitor_soc_sim.sv
