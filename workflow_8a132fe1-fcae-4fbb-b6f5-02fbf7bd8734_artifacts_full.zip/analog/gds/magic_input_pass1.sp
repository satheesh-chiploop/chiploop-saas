.lib "$PDK_ROOT/sky130A/libs.tech/ngspice/sky130.lib.spice" tt
.subckt temp_sensor_adc_model VGND VPWR adc_code[0] adc_code[10] adc_code[11] adc_code[1] adc_code[2] adc_code[3] adc_code[4] adc_code[5] adc_code[6] adc_code[7] adc_code[8] adc_code[9] adc_valid avdd avss sample_req sensor_temp_celsius[0] sensor_temp_celsius[10] sensor_temp_celsius[11] sensor_temp_celsius[12] sensor_temp_celsius[13] sensor_temp_celsius[14] sensor_temp_celsius[15] sensor_temp_celsius[1] sensor_temp_celsius[2] sensor_temp_celsius[3] sensor_temp_celsius[4] sensor_temp_celsius[5] sensor_temp_celsius[6] sensor_temp_celsius[7] sensor_temp_celsius[8] sensor_temp_celsius[9]
Mtail n1 sample_req avss avss sky130_fd_pr__nfet_01v8 W=1 L=0.15
Mrefp n1 avdd avdd avdd sky130_fd_pr__pfet_01v8 W=1 L=0.15
Mn0 adc_valid n1 VGND VGND sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
Mp0 adc_valid n1 VPWR VPWR sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
Mcode0 adc_code[0] sensor_temp_celsius[0] VGND VGND sky130_fd_pr__nfet_01v8 W=0.42 L=0.15
Mcode1 adc_code[1] sensor_temp_celsius[1] VGND VGND sky130_fd_pr__nfet_01v8 W=0.42 L=0.15
Mcode2 adc_code[2] sensor_temp_celsius[2] VGND VGND sky130_fd_pr__nfet_01v8 W=0.42 L=0.15
Mcode3 adc_code[3] sensor_temp_celsius[3] VGND VGND sky130_fd_pr__nfet_01v8 W=0.42 L=0.15
Mcode4 adc_code[4] sensor_temp_celsius[4] VGND VGND sky130_fd_pr__nfet_01v8 W=0.42 L=0.15
Mcode5 adc_code[5] sensor_temp_celsius[5] VGND VGND sky130_fd_pr__nfet_01v8 W=0.42 L=0.15
Mcode6 adc_code[6] sensor_temp_celsius[6] VGND VGND sky130_fd_pr__nfet_01v8 W=0.42 L=0.15
Mcode7 adc_code[7] sensor_temp_celsius[7] VGND VGND sky130_fd_pr__nfet_01v8 W=0.42 L=0.15
Mcode8 adc_code[8] sensor_temp_celsius[8] VGND VGND sky130_fd_pr__nfet_01v8 W=0.42 L=0.15
Mcode9 adc_code[9] sensor_temp_celsius[9] VGND VGND sky130_fd_pr__nfet_01v8 W=0.42 L=0.15
Mcode10 adc_code[10] sensor_temp_celsius[10] VGND VGND sky130_fd_pr__nfet_01v8 W=0.42 L=0.15
Mcode11 adc_code[11] sensor_temp_celsius[11] VGND VGND sky130_fd_pr__nfet_01v8 W=0.42 L=0.15
.ends temp_sensor_adc_model
.end
