# Simulation Summary + Coverage

- Total simulation runs: 4
- Simulation pass count: 0
- Simulation fail count: 4
- Coverage status: missing
- Functional coverage %: None
- Coverage bins hit: None
- Coverage total bins: None
- Functional bin gaps: 0
- Code line coverage: missing_data
- Code branch coverage: missing_data
- Code condition coverage: unavailable
- Code toggle coverage: not_reported_by_verilator_lcov
- SVA/assertion status: failed
- SVA/assertion pass %: 0.0%
- Formal status: fail
- Golden model status: generated
- Simulator tool: verilator
- Code coverage tool: verilator_coverage
- Formal tool: symbiyosys
- Golden model tool: chiploop_python_scoreboard

## Functional Coverage Not Met
