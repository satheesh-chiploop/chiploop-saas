# Simulation Execution Summary

- Total runs: 4
- Pass count: 0
- Fail count: 4

## Results
- smoke_test / seed 1: FAIL (rc=2)
- smoke_test / seed 2: FAIL (rc=2)
- smoke_test / seed 3: FAIL (rc=2)
- smoke_test / seed 4: FAIL (rc=2)
