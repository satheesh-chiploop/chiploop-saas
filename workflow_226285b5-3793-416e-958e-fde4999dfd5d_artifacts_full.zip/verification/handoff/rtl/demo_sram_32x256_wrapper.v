module demo_sram_32x256_wrapper (
    clk,
    csb,
    web,
    addr,
    din,
    dout
);
    input clk;
    input csb;
    input web;
    input [7:0] addr;
    input [31:0] din;
    output [31:0] dout;
    sky130_sram_1kbyte_1rw1r_32x256_8 u_sram (
        .clk0(clk),
        .csb0(csb),
        .web0(web),
        .wmask0(4'b0000),
        .addr0(addr),
        .din0(din),
        .dout0(dout),
        .clk1(clk),
        .csb1(1'b1),
        .addr1(8'h00),
        .dout1()
    );
endmodule
