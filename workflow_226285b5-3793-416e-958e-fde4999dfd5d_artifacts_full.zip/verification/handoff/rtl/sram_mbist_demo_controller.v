module sram_mbist_demo_controller (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    bist_start,
    rd_data,
    ready,
    bist_done,
    bist_fail,
    irq
);
    input clk;
    input reset_n;
    input wr_en;
    input [7:0] wr_addr;
    input [31:0] wr_data;
    input rd_en;
    input [7:0] rd_addr;
    input bist_start;
    output [31:0] rd_data;
    output ready;
    output bist_done;
    output bist_fail;
    output irq;

    wire sram_csb;
    wire sram_web;
    wire [7:0] sram_addr;
    wire [31:0] sram_din;
    wire [31:0] sram_dout;

    reg [31:0] rd_data_r;
    reg ready_r;
    reg bist_done_r;
    reg bist_fail_r;
    reg irq_r;

    reg ctrl_enable;
    reg ctrl_soft_reset;
    reg ctrl_irq_enable;

    reg [7:0] mem_addr_reg;
    reg [31:0] mem_wdata_reg;
    reg mem_write_req;
    reg mem_read_req;

    reg bist_start_reg;
    reg bist_clear_result;
    reg bist_running;
    reg [7:0] bist_last_fail_addr;

    reg [7:0] wr_addr_d;
    reg [31:0] wr_data_d;
    reg wr_en_d;
    reg [7:0] rd_addr_d;
    reg rd_en_d;
    reg bist_start_d;

    wire wr_en_pulse;
    wire rd_en_pulse;
    wire bist_start_pulse;

    assign wr_en_pulse = wr_en & ~wr_en_d;
    assign rd_en_pulse = rd_en & ~rd_en_d;
    assign bist_start_pulse = bist_start & ~bist_start_d;

    assign rd_data = rd_data_r;
    assign ready = ready_r;
    assign bist_done = bist_done_r;
    assign bist_fail = bist_fail_r;
    assign irq = irq_r;

    assign sram_csb = ~(ctrl_enable & (mem_write_req | mem_read_req | wr_en_pulse | rd_en_pulse | bist_running));
    assign sram_web = ~(mem_write_req | wr_en_pulse);
    assign sram_addr = mem_write_req ? mem_addr_reg :
                       mem_read_req  ? mem_addr_reg :
                       wr_en_pulse   ? wr_addr_d   :
                       rd_en_pulse   ? rd_addr_d   :
                                       bist_last_fail_addr;
    assign sram_din = mem_write_req ? mem_wdata_reg :
                      wr_en_pulse   ? wr_data_d     :
                                       32'h00000000;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            rd_data_r <= 32'h00000000;
            ready_r <= 1'b0;
            bist_done_r <= 1'b0;
            bist_fail_r <= 1'b0;
            irq_r <= 1'b0;
            ctrl_enable <= 1'b0;
            ctrl_soft_reset <= 1'b0;
            ctrl_irq_enable <= 1'b0;
            mem_addr_reg <= 8'h00;
            mem_wdata_reg <= 32'h00000000;
            mem_write_req <= 1'b0;
            mem_read_req <= 1'b0;
            bist_start_reg <= 1'b0;
            bist_clear_result <= 1'b0;
            bist_running <= 1'b0;
            bist_last_fail_addr <= 8'h00;
            wr_addr_d <= 8'h00;
            wr_data_d <= 32'h00000000;
            wr_en_d <= 1'b0;
            rd_addr_d <= 8'h00;
            rd_en_d <= 1'b0;
            bist_start_d <= 1'b0;
        end else begin
            wr_addr_d <= wr_addr;
            wr_data_d <= wr_data;
            wr_en_d <= wr_en;
            rd_addr_d <= rd_addr;
            rd_en_d <= rd_en;
            bist_start_d <= bist_start;

            if (ctrl_soft_reset) begin
                rd_data_r <= 32'h00000000;
                ready_r <= 1'b0;
                bist_done_r <= 1'b0;
                bist_fail_r <= 1'b0;
                irq_r <= 1'b0;
                ctrl_soft_reset <= 1'b0;
                mem_write_req <= 1'b0;
                mem_read_req <= 1'b0;
                bist_start_reg <= 1'b0;
                bist_clear_result <= 1'b0;
                bist_running <= 1'b0;
                bist_last_fail_addr <= 8'h00;
            end else begin
                if (wr_en_pulse && (wr_addr == 8'h00)) begin
                    ctrl_enable <= wr_data[0];
                    ctrl_soft_reset <= wr_data[1];
                    ctrl_irq_enable <= wr_data[2];
                end
                if (wr_en_pulse && (wr_addr == 8'h08)) begin
                    mem_addr_reg <= wr_data[7:0];
                end
                if (wr_en_pulse && (wr_addr == 8'h0C)) begin
                    mem_wdata_reg <= wr_data;
                end
                if (wr_en_pulse && (wr_addr == 8'h14)) begin
                    mem_write_req <= wr_data[0];
                    mem_read_req <= wr_data[1];
                end else begin
                    mem_write_req <= 1'b0;
                    mem_read_req <= 1'b0;
                end
                if (wr_en_pulse && (wr_addr == 8'h18)) begin
                    bist_start_reg <= wr_data[0];
                    bist_clear_result <= wr_data[1];
                end else begin
                    bist_start_reg <= 1'b0;
                    bist_clear_result <= 1'b0;
                end
                if (bist_start_pulse || bist_start_reg) begin
                    bist_running <= 1'b1;
                end else if (bist_running) begin
                    bist_running <= 1'b0;
                    bist_done_r <= 1'b1;
                    bist_fail_r <= 1'b0;
                    bist_last_fail_addr <= 8'h00;
                end
                if (bist_clear_result) begin
                    bist_done_r <= 1'b0;
                    bist_fail_r <= 1'b0;
                    bist_last_fail_addr <= 8'h00;
                    irq_r <= 1'b0;
                end
                if (wr_en_pulse && (wr_addr == 8'h24) && wr_data[0]) begin
                    bist_done_r <= 1'b0;
                end
                if (wr_en_pulse && (wr_addr == 8'h24) && wr_data[1]) begin
                    bist_fail_r <= 1'b0;
                end
                if (rd_en_pulse) begin
                    rd_data_r <= sram_dout;
                end
                ready_r <= ctrl_enable & ~bist_running;
                irq_r <= ctrl_irq_enable & (bist_done_r | bist_fail_r);
            end
        end
    end

    demo_sram_32x256_wrapper u_sram (
        .clk(clk),
        .csb(sram_csb),
        .web(sram_web),
        .addr(sram_addr),
        .din(sram_din),
        .dout(sram_dout)
    );
endmodule
