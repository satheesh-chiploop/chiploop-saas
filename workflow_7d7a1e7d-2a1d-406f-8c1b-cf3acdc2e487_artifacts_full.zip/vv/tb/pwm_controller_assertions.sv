module pwm_controller_assertions (
  input logic clk,
  input logic [7:0] counter_value,
  input logic [7:0] duty_cycle,
  input logic enable,
  input logic [7:0] period,
  input logic pwm_out,
  input logic reset_n
);

  property p_reset_known;
    @(posedge clk)
      !$isunknown(reset_n);
  endproperty

  a_reset_known: assert property(p_reset_known)
    else $error("Reset signal has X/Z state.");

  property p_pwm_out_known_after_reset;
    @(posedge clk) disable iff (!reset_n)
      !$isunknown(pwm_out);
  endproperty

  a_pwm_out_known_after_reset: assert property(p_pwm_out_known_after_reset)
    else $error("Signal pwm_out has X/Z after reset release.");

  property p_counter_value_known_after_reset;
    @(posedge clk) disable iff (!reset_n)
      !$isunknown(counter_value);
  endproperty

  a_counter_value_known_after_reset: assert property(p_counter_value_known_after_reset)
    else $error("Signal counter_value has X/Z after reset release.");

  // REQ-001
  property p_req_001;
    @(posedge clk) disable iff (!reset_n)
      enable |-> (pwm_out == (counter_value < duty_cycle));
  endproperty

  a_req_001: assert property(p_req_001)
    else $error("REQ-001 failed: PWM output does not match counter_value < duty_cycle.");

  c_req_001: cover property (@(posedge clk) disable iff (!reset_n) enable);

  // REQ-002
  property p_req_002;
    @(posedge clk) disable iff (!reset_n)
      (enable && (counter_value == period)) |=> (counter_value == 8'd0);
  endproperty

  a_req_002: assert property(p_req_002)
    else $error("REQ-002 failed: counter_value did not wrap to 0 at the period boundary.");

  c_req_002: cover property (@(posedge clk) disable iff (!reset_n) (enable && (counter_value == period)));

  // REQ-003
  property p_req_003;
    @(posedge clk) disable iff (!reset_n)
      1'b1 |-> (counter_value == counter_value);
  endproperty

  a_req_003: assert property(p_req_003)
    else $error("REQ-003 failed: counter_value is not observable.");

  c_req_003: cover property (@(posedge clk) disable iff (!reset_n) 1'b1);

  // REQ-004
  property p_req_004;
    @(posedge clk)
      (!reset_n) |=> ((counter_value == 8'd0) && (pwm_out == 1'b0));
  endproperty

  a_req_004: assert property(p_req_004)
    else $error("REQ-004 failed: synchronous reset did not establish known zero state.");

  c_req_004: cover property (@(posedge clk) (!reset_n));

  // REQ-006
  property p_req_006;
    @(posedge clk) disable iff (!reset_n)
      enable |=> (counter_value == ($past(counter_value) + 8'd1));
  endproperty

  a_req_006: assert property(p_req_006)
    else $error("REQ-006 failed: counter_value did not increment by 1 when enabled.");

  c_req_006: cover property (@(posedge clk) disable iff (!reset_n) enable);

  // REQ-008
  property p_req_008;
    @(posedge clk) disable iff (!reset_n)
      (!enable) |=> (counter_value == $past(counter_value));
  endproperty

  a_req_008: assert property(p_req_008)
    else $error("REQ-008 failed: counter_value did not hold when enable was low.");

  c_req_008: cover property (@(posedge clk) disable iff (!reset_n) (!enable));

  // REQ-009
  property p_req_009;
    @(posedge clk) disable iff (!reset_n)
      1'b1 |-> (pwm_out == (counter_value < duty_cycle));
  endproperty

  a_req_009: assert property(p_req_009)
    else $error("REQ-009 failed: pwm_out does not match comparator relationship.");

  c_req_009: cover property (@(posedge clk) disable iff (!reset_n) 1'b1);

  // REQ-010
  property p_req_010;
    @(posedge clk)
      (!reset_n) |=> ((counter_value == 8'd0) && (pwm_out == 1'b0));
  endproperty

  a_req_010: assert property(p_req_010)
    else $error("REQ-010 failed: sequential state was not cleared under synchronous reset.");

  c_req_010: cover property (@(posedge clk) (!reset_n));

  // REQ-011
  property p_req_011;
    @(posedge clk) disable iff (!reset_n)
      ((enable && (period == 8'd0))) |=> (counter_value == 8'd0);
  endproperty

  a_req_011: assert property(p_req_011)
    else $error("REQ-011 failed: counter_value advanced when period was 0.");

  c_req_011: cover property (@(posedge clk) disable iff (!reset_n) (enable && (period == 8'd0)));

  // REQ-015
  property p_req_015;
    @(posedge clk)
      (!reset_n) |=> ((counter_value == 8'd0) && (pwm_out == 1'b0));
  endproperty

  a_req_015: assert property(p_req_015)
    else $error("REQ-015 failed: reset did not clear counter_value and pwm_out.");

  c_req_015: cover property (@(posedge clk) (!reset_n));

endmodule