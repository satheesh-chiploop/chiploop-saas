module adaptive_aero_control_top (
    input         clk,
    input         reset_n,
    input         reg_valid,
    input         reg_we,
    input  [7:0] reg_addr,
    input  [31:0] reg_wdata,
    output [31:0] reg_rdata,
    output        reg_ready,
    output        model_req_valid,
    output [63:0] model_req_data,
    input         model_req_ready,
    input         model_rsp_valid,
    input  [63:0] model_rsp_data,
    output        model_rsp_ready,
    output        actuator_cmd_valid,
    output [31:0] actuator_cmd
);
wire cfg_enable;
wire cfg_soft_reset;
wire cfg_request_start;
wire cfg_fault_clear;
wire [1:0] cfg_fallback_select;
wire [3:0] cfg_operating_mode;
wire [7:0] cfg_descriptor_select;
wire [31:0] cfg_stream_velocity_mps;
wire [31:0] cfg_command_min;
wire [31:0] cfg_command_max;
wire [31:0] cfg_timeout_limit;
wire [31:0] cfg_stale_limit;
wire [31:0] cfg_request_id;
wire status_busy;
wire status_valid_rsp;
wire status_timeout_fault;
wire status_stale_fault;
wire status_clamp_event;
wire status_fault_latched;
wire status_model_alive;
wire [31:0] status_last_command;
wire [31:0] status_last_response_id;
wire [31:0] status_accepted_requests;
wire [31:0] status_valid_responses;
wire [31:0] status_rejected_stale;
wire [31:0] status_timeout_events;
wire [31:0] status_clamp_events;
wire [31:0] status_fallback_events;
reg_contract u_reg_contract (
    .clk(clk),
    .reset_n(reset_n),
    .reg_valid(reg_valid),
    .reg_we(reg_we),
    .reg_addr(reg_addr),
    .reg_wdata(reg_wdata),
    .reg_rdata(reg_rdata),
    .reg_ready(reg_ready),
    .cfg_enable(cfg_enable),
    .cfg_soft_reset(cfg_soft_reset),
    .cfg_request_start(cfg_request_start),
    .cfg_fault_clear(cfg_fault_clear),
    .cfg_fallback_select(cfg_fallback_select),
    .cfg_operating_mode(cfg_operating_mode),
    .cfg_descriptor_select(cfg_descriptor_select),
    .cfg_stream_velocity_mps(cfg_stream_velocity_mps),
    .cfg_command_min(cfg_command_min),
    .cfg_command_max(cfg_command_max),
    .cfg_timeout_limit(cfg_timeout_limit),
    .cfg_stale_limit(cfg_stale_limit),
    .cfg_request_id(cfg_request_id),
    .status_busy(status_busy),
    .status_valid_rsp(status_valid_rsp),
    .status_timeout_fault(status_timeout_fault),
    .status_stale_fault(status_stale_fault),
    .status_clamp_event(status_clamp_event),
    .status_fault_latched(status_fault_latched),
    .status_model_alive(status_model_alive),
    .status_last_command(status_last_command),
    .status_last_response_id(status_last_response_id),
    .status_accepted_requests(status_accepted_requests),
    .status_valid_responses(status_valid_responses),
    .status_rejected_stale(status_rejected_stale),
    .status_timeout_events(status_timeout_events),
    .status_clamp_events(status_clamp_events),
    .status_fallback_events(status_fallback_events)
);

adaptive_aero_control_core u_adaptive_aero_control_core (
    .clk(clk),
    .reset_n(reset_n),
    .cfg_enable(cfg_enable),
    .cfg_soft_reset(cfg_soft_reset),
    .cfg_request_start(cfg_request_start),
    .cfg_operating_mode(cfg_operating_mode),
    .cfg_timeout_limit(cfg_timeout_limit),
    .cfg_command_min(cfg_command_min),
    .cfg_command_max(cfg_command_max),
    .cfg_stale_limit(cfg_stale_limit),
    .cfg_request_id(cfg_request_id),
    .cfg_fault_clear(cfg_fault_clear),
    .cfg_fallback_select(cfg_fallback_select),
    .cfg_stream_velocity_mps(cfg_stream_velocity_mps),
    .cfg_descriptor_select(cfg_descriptor_select),
    .model_req_valid(model_req_valid),
    .model_req_data(model_req_data),
    .model_req_ready(model_req_ready),
    .model_rsp_valid(model_rsp_valid),
    .model_rsp_data(model_rsp_data),
    .model_rsp_ready(model_rsp_ready),
    .actuator_cmd_valid(actuator_cmd_valid),
    .actuator_cmd(actuator_cmd),
    .model_alive(status_model_alive),
    .busy(status_busy),
    .valid_rsp(status_valid_rsp),
    .timeout_fault(status_timeout_fault),
    .stale_fault(status_stale_fault),
    .clamp_event(status_clamp_event),
    .fault_latched(status_fault_latched),
    .last_command(status_last_command),
    .last_response_id(status_last_response_id),
    .accepted_requests(status_accepted_requests),
    .valid_responses(status_valid_responses),
    .rejected_stale(status_rejected_stale),
    .timeout_events(status_timeout_events),
    .clamp_events(status_clamp_events),
    .fallback_events(status_fallback_events),
    .fault_status(),
    .health_status()
);

endmodule
