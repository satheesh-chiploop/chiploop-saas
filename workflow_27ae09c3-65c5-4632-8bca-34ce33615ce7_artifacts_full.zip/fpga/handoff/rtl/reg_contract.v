module reg_contract (
    input         clk,
    input         reset_n,
    input         reg_valid,
    input         reg_we,
    input  [7:0] reg_addr,
    input  [31:0] reg_wdata,
    output [31:0] reg_rdata,
    output        reg_ready,
    output        cfg_enable,
    output        cfg_soft_reset,
    output        cfg_request_start,
    output        cfg_fault_clear,
    output [1:0] cfg_fallback_select,
    output [3:0] cfg_operating_mode,
    output [7:0] cfg_descriptor_select,
    output [31:0] cfg_stream_velocity_mps,
    output [31:0] cfg_command_min,
    output [31:0] cfg_command_max,
    output [31:0] cfg_timeout_limit,
    output [31:0] cfg_stale_limit,
    output [31:0] cfg_request_id,
    input         status_busy,
    input         status_valid_rsp,
    input         status_timeout_fault,
    input         status_stale_fault,
    input         status_clamp_event,
    input         status_fault_latched,
    input         status_model_alive,
    input  [31:0] status_last_command,
    input  [31:0] status_last_response_id,
    input  [31:0] status_accepted_requests,
    input  [31:0] status_valid_responses,
    input  [31:0] status_rejected_stale,
    input  [31:0] status_timeout_events,
    input  [31:0] status_clamp_events,
    input  [31:0] status_fallback_events
);

reg [31:0] control_reg;
reg [31:0] mode_reg;
reg [31:0] vel_reg;
reg [31:0] cmd_min_reg;
reg [31:0] cmd_max_reg;
reg [31:0] timeout_reg;
reg [31:0] stale_reg;
reg [31:0] reqid_reg;
reg [31:0] reg_rdata_r;
reg        reg_ready_r;
reg        cfg_soft_reset_r;
reg        cfg_request_start_r;
reg        cfg_fault_clear_r;
reg [7:0]  addr_d;

assign reg_rdata = reg_rdata_r;
assign reg_ready = reg_ready_r;
assign cfg_enable = control_reg[0];
assign cfg_soft_reset = cfg_soft_reset_r;
assign cfg_request_start = cfg_request_start_r;
assign cfg_fault_clear = cfg_fault_clear_r;
assign cfg_fallback_select = control_reg[5:4];
assign cfg_operating_mode = mode_reg[3:0];
assign cfg_descriptor_select = mode_reg[11:4];
assign cfg_stream_velocity_mps = vel_reg;
assign cfg_command_min = cmd_min_reg;
assign cfg_command_max = cmd_max_reg;
assign cfg_timeout_limit = timeout_reg;
assign cfg_stale_limit = stale_reg;
assign cfg_request_id = reqid_reg;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        control_reg <= 32'd0;
        mode_reg <= 32'd0;
        vel_reg <= 32'd0;
        cmd_min_reg <= 32'd0;
        cmd_max_reg <= 32'd0;
        timeout_reg <= 32'd0;
        stale_reg <= 32'd0;
        reqid_reg <= 32'd0;
        reg_rdata_r <= 32'd0;
        reg_ready_r <= 1'b0;
        cfg_soft_reset_r <= 1'b0;
        cfg_request_start_r <= 1'b0;
        cfg_fault_clear_r <= 1'b0;
        addr_d <= 8'd0;
    end else begin
        reg_ready_r <= reg_valid;
        cfg_soft_reset_r <= 1'b0;
        cfg_request_start_r <= 1'b0;
        cfg_fault_clear_r <= 1'b0;
        addr_d <= reg_addr;

        if (reg_valid && reg_we) begin
            case (reg_addr)
                8'h00: control_reg <= {26'd0, reg_wdata[5:4], reg_wdata[3], reg_wdata[2], reg_wdata[1], reg_wdata[0]};
                8'h04: mode_reg <= {20'd0, reg_wdata[11:0]};
                8'h08: vel_reg <= reg_wdata;
                8'h0C: cmd_min_reg <= reg_wdata;
                8'h10: cmd_max_reg <= reg_wdata;
                8'h14: timeout_reg <= reg_wdata;
                8'h18: stale_reg <= reg_wdata;
                8'h1C: reqid_reg <= reg_wdata;
                default: begin
                end
            endcase

            if (reg_addr == 8'h00) begin
                cfg_soft_reset_r <= reg_wdata[1];
                cfg_request_start_r <= reg_wdata[2];
                cfg_fault_clear_r <= reg_wdata[3];
            end
        end

        if (reg_valid && !reg_we) begin
            case (reg_addr)
                8'h00: reg_rdata_r <= {26'd0, control_reg[5:4], control_reg[3], control_reg[2], control_reg[1], control_reg[0]};
                8'h04: reg_rdata_r <= {20'd0, mode_reg[11:0]};
                8'h08: reg_rdata_r <= vel_reg;
                8'h0C: reg_rdata_r <= cmd_min_reg;
                8'h10: reg_rdata_r <= cmd_max_reg;
                8'h14: reg_rdata_r <= timeout_reg;
                8'h18: reg_rdata_r <= stale_reg;
                8'h1C: reg_rdata_r <= reqid_reg;
                8'h20: reg_rdata_r <= status_last_response_id;
                8'h24: reg_rdata_r <= {25'd0, status_model_alive, status_fault_latched, status_clamp_event, status_stale_fault, status_timeout_fault, status_valid_rsp, status_busy};
                8'h28: reg_rdata_r <= status_last_command;
                8'h2C: reg_rdata_r <= status_accepted_requests;
                8'h30: reg_rdata_r <= status_valid_responses;
                8'h34: reg_rdata_r <= status_rejected_stale;
                8'h38: reg_rdata_r <= status_timeout_events;
                8'h3C: reg_rdata_r <= status_clamp_events;
                8'h40: reg_rdata_r <= status_fallback_events;
                default: reg_rdata_r <= 32'd0;
            endcase
        end else if (!reg_valid) begin
            reg_rdata_r <= reg_rdata_r;
        end
    end
end

endmodule
