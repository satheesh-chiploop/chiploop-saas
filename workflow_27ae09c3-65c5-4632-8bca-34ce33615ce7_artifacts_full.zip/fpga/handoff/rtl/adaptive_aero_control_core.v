module adaptive_aero_control_core (
    input         clk,
    input         reset_n,
    input         cfg_enable,
    input         cfg_soft_reset,
    input         cfg_request_start,
    input  [3:0] cfg_operating_mode,
    input  [31:0] cfg_timeout_limit,
    input  [31:0] cfg_command_min,
    input  [31:0] cfg_command_max,
    input  [31:0] cfg_stale_limit,
    input  [31:0] cfg_request_id,
    input         cfg_fault_clear,
    input  [1:0] cfg_fallback_select,
    input  [31:0] cfg_stream_velocity_mps,
    input  [7:0] cfg_descriptor_select,
    output        model_req_valid,
    output [63:0] model_req_data,
    input         model_req_ready,
    input         model_rsp_valid,
    input  [63:0] model_rsp_data,
    output        model_rsp_ready,
    output        actuator_cmd_valid,
    output [31:0] actuator_cmd,
    output        model_alive,
    output        busy,
    output        valid_rsp,
    output        timeout_fault,
    output        stale_fault,
    output        clamp_event,
    output        fault_latched,
    output [31:0] last_command,
    output [31:0] last_response_id,
    output [31:0] accepted_requests,
    output [31:0] valid_responses,
    output [31:0] rejected_stale,
    output [31:0] timeout_events,
    output [31:0] clamp_events,
    output [31:0] fallback_events,
    output [31:0] fault_status,
    output [31:0] health_status
);

localparam S_IDLE = 2'd0;
localparam S_WAIT_REQ = 2'd1;
localparam S_WAIT_RSP = 2'd2;

reg [1:0]  state;
reg [31:0] outstanding_id;
reg [31:0] age_count;
reg        req_valid_r;
reg [63:0] req_data_r;
reg        rsp_ready_r;
reg        act_valid_r;
reg [31:0] act_cmd_r;
reg        model_alive_r;
reg        busy_r;
reg        valid_rsp_r;
reg        timeout_fault_r;
reg        stale_fault_r;
reg        clamp_event_r;
reg        fault_latched_r;
reg [31:0] last_command_r;
reg [31:0] last_response_id_r;
reg [31:0] accepted_requests_r;
reg [31:0] valid_responses_r;
reg [31:0] rejected_stale_r;
reg [31:0] timeout_events_r;
reg [31:0] clamp_events_r;
reg [31:0] fallback_events_r;
reg [31:0] fault_status_r;
reg [31:0] health_status_r;

wire [31:0] rsp_id;
wire [31:0] rsp_cmd;
wire [31:0] cmd_clamped;
wire rsp_id_match;
wire timeout_limit_hit;
wire stale_limit_hit;
wire clamp_needed;
wire [31:0] min_bound;
wire [31:0] max_bound;

assign rsp_id = model_rsp_data[63:32];
assign rsp_cmd = model_rsp_data[31:0];
assign min_bound = (cfg_command_min <= cfg_command_max) ? cfg_command_min : cfg_command_max;
assign max_bound = (cfg_command_min <= cfg_command_max) ? cfg_command_max : cfg_command_min;
assign rsp_id_match = (rsp_id == outstanding_id);
assign timeout_limit_hit = (cfg_timeout_limit != 32'd0) && (age_count >= cfg_timeout_limit);
assign stale_limit_hit = (cfg_stale_limit != 32'd0) && (age_count >= cfg_stale_limit);
assign clamp_needed = (rsp_cmd < min_bound) || (rsp_cmd > max_bound);
assign cmd_clamped = (rsp_cmd < min_bound) ? min_bound : ((rsp_cmd > max_bound) ? max_bound : rsp_cmd);

assign model_req_valid = req_valid_r;
assign model_req_data = req_data_r;
assign model_rsp_ready = (state == S_WAIT_RSP) && cfg_enable && !fault_latched_r;
assign actuator_cmd_valid = act_valid_r && !fault_latched_r;
assign actuator_cmd = act_cmd_r;
assign model_alive = model_alive_r;
assign busy = busy_r;
assign valid_rsp = valid_rsp_r;
assign timeout_fault = timeout_fault_r;
assign stale_fault = stale_fault_r;
assign clamp_event = clamp_event_r;
assign fault_latched = fault_latched_r;
assign last_command = last_command_r;
assign last_response_id = last_response_id_r;
assign accepted_requests = accepted_requests_r;
assign valid_responses = valid_responses_r;
assign rejected_stale = rejected_stale_r;
assign timeout_events = timeout_events_r;
assign clamp_events = clamp_events_r;
assign fallback_events = fallback_events_r;
assign fault_status = {31'd0, fault_latched_r};
assign health_status = {30'd0, model_alive_r, busy_r};

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        state <= S_IDLE;
        outstanding_id <= 32'd0;
        age_count <= 32'd0;
        req_valid_r <= 1'b0;
        req_data_r <= 64'd0;
        rsp_ready_r <= 1'b1;
        act_valid_r <= 1'b0;
        act_cmd_r <= 32'd0;
        model_alive_r <= 1'b0;
        busy_r <= 1'b0;
        valid_rsp_r <= 1'b0;
        timeout_fault_r <= 1'b0;
        stale_fault_r <= 1'b0;
        clamp_event_r <= 1'b0;
        fault_latched_r <= 1'b0;
        last_command_r <= 32'd0;
        last_response_id_r <= 32'd0;
        accepted_requests_r <= 32'd0;
        valid_responses_r <= 32'd0;
        rejected_stale_r <= 32'd0;
        timeout_events_r <= 32'd0;
        clamp_events_r <= 32'd0;
        fallback_events_r <= 32'd0;
        fault_status_r <= 32'd0;
        health_status_r <= 32'd0;
    end else begin
        req_valid_r <= 1'b0;
        valid_rsp_r <= 1'b0;
        timeout_fault_r <= 1'b0;
        stale_fault_r <= 1'b0;
        clamp_event_r <= 1'b0;
        act_valid_r <= 1'b0;

        if (cfg_soft_reset || cfg_fault_clear) begin
            state <= S_IDLE;
            outstanding_id <= cfg_request_id;
            age_count <= 32'd0;
            req_valid_r <= 1'b0;
            rsp_ready_r <= 1'b1;
            busy_r <= 1'b0;
            model_alive_r <= 1'b0;
            fault_latched_r <= 1'b0;
        end else begin
            case (state)
                S_IDLE: begin
                    rsp_ready_r <= 1'b1;
                    busy_r <= 1'b0;
                    model_alive_r <= 1'b0;
                    age_count <= 32'd0;
                    if (cfg_enable && cfg_request_start && !fault_latched_r) begin
                        outstanding_id <= cfg_request_id;
                        req_data_r <= {cfg_request_id, cfg_operating_mode, cfg_descriptor_select, cfg_stream_velocity_mps[15:0], cfg_fallback_select, 2'b00};
                        req_valid_r <= 1'b1;
                        accepted_requests_r <= accepted_requests_r + 1'b1;
                        state <= S_WAIT_REQ;
                        busy_r <= 1'b1;
                    end
                end
                S_WAIT_REQ: begin
                    busy_r <= 1'b1;
                    model_alive_r <= 1'b1;
                    rsp_ready_r <= 1'b0;
                    if (model_req_ready) begin
                        state <= S_WAIT_RSP;
                        age_count <= 32'd0;
                    end
                end
                S_WAIT_RSP: begin
                    busy_r <= 1'b1;
                    rsp_ready_r <= 1'b1;
                    model_alive_r <= !timeout_limit_hit;
                    if (age_count != 32'hFFFF_FFFF) begin
                        age_count <= age_count + 1'b1;
                    end
                    if (timeout_limit_hit) begin
                        timeout_fault_r <= 1'b1;
                        timeout_events_r <= timeout_events_r + 1'b1;
                        fallback_events_r <= fallback_events_r + 1'b1;
                        fault_latched_r <= 1'b1;
                        state <= S_IDLE;
                        busy_r <= 1'b0;
                        model_alive_r <= 1'b0;
                    end else if (model_rsp_valid) begin
                        if (rsp_id_match && !stale_limit_hit) begin
                            valid_rsp_r <= 1'b1;
                            valid_responses_r <= valid_responses_r + 1'b1;
                            last_response_id_r <= rsp_id;
                            act_cmd_r <= cmd_clamped;
                            last_command_r <= cmd_clamped;
                            if (clamp_needed) begin
                                clamp_event_r <= 1'b1;
                                clamp_events_r <= clamp_events_r + 1'b1;
                            end
                            act_valid_r <= cfg_enable && !fault_latched_r;
                            state <= S_IDLE;
                            busy_r <= 1'b0;
                            model_alive_r <= 1'b0;
                        end else begin
                            stale_fault_r <= 1'b1;
                            rejected_stale_r <= rejected_stale_r + 1'b1;
                            fallback_events_r <= fallback_events_r + 1'b1;
                            fault_latched_r <= 1'b1;
                            state <= S_IDLE;
                            busy_r <= 1'b0;
                            model_alive_r <= 1'b0;
                        end
                    end
                end
                default: begin
                    state <= S_IDLE;
                    busy_r <= 1'b0;
                    model_alive_r <= 1'b0;
                    rsp_ready_r <= 1'b1;
                end
            endcase
        end
        fault_status_r <= {31'd0, fault_latched_r};
        health_status_r <= {30'd0, model_alive_r, busy_r};
    end
end

endmodule
