module demo_sram_32x256_model (
    clk,
    csb,
    web,
    addr,
    din,
    dout
);
    input clk;
    input csb;
    input web;
    input [7:0] addr;
    input [31:0] din;
    output [31:0] dout;
    reg [31:0] mem [0:255];
    reg [31:0] dout_r;
    reg [31:0] read_data;

    integer i;

    assign dout = dout_r;

    always @(posedge clk) begin
        if (!csb) begin
            if (!web) begin
                mem[addr] <= din;
            end
            read_data <= mem[addr];
            dout_r <= read_data;
        end else begin
            dout_r <= dout_r;
        end
    end

    initial begin
        dout_r = 32'h00000000;
        read_data = 32'h00000000;
        for (i = 0; i < 256; i = i + 1) begin
            mem[i] = 32'h00000000;
        end
    end
endmodule
