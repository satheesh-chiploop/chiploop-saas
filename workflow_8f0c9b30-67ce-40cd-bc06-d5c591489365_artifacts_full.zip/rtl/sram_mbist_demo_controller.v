module sram_mbist_demo_controller (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    bist_start,
    rd_data,
    ready,
    bist_done,
    bist_fail,
    irq
);
    input clk;
    input reset_n;
    input wr_en;
    input [7:0] wr_addr;
    input [31:0] wr_data;
    input rd_en;
    input [7:0] rd_addr;
    input bist_start;
    output [31:0] rd_data;
    output ready;
    output bist_done;
    output bist_fail;
    output irq;

    wire [31:0] mem_dout;
    wire mem_csb;
    wire mem_web;
    wire [7:0] mem_addr;
    wire [31:0] mem_din;
    wire bist_req_int;

    reg [31:0] rd_data_r;
    reg ready_r;
    reg bist_done_r;
    reg bist_fail_r;
    reg irq_r;

    reg control_enable;
    reg control_soft_reset;
    reg control_irq_enable;
    reg [7:0] mem_addr_reg;
    reg [31:0] mem_wdata_reg;
    reg mem_control_write;
    reg mem_control_read;
    reg bist_control_start;
    reg bist_control_clear;
    reg bist_running;
    reg [7:0] bist_last_fail_addr;
    reg irq_done_pending;
    reg irq_fail_pending;
    reg [31:0] status_readback;

    reg [31:0] read_mux;

    localparam [7:0] ADDR_CONTROL      = 8'h00;
    localparam [7:0] ADDR_STATUS       = 8'h04;
    localparam [7:0] ADDR_MEM_ADDR     = 8'h08;
    localparam [7:0] ADDR_MEM_WDATA    = 8'h0C;
    localparam [7:0] ADDR_MEM_RDATA    = 8'h10;
    localparam [7:0] ADDR_MEM_CONTROL  = 8'h14;
    localparam [7:0] ADDR_BIST_CONTROL = 8'h18;
    localparam [7:0] ADDR_BIST_STATUS  = 8'h1C;
    localparam [7:0] ADDR_IRQ_STATUS   = 8'h20;
    localparam [7:0] ADDR_IRQ_CLEAR    = 8'h24;

    assign rd_data = rd_data_r;
    assign ready = ready_r;
    assign bist_done = bist_done_r;
    assign bist_fail = bist_fail_r;
    assign irq = irq_r;

    assign mem_csb = ~(control_enable & (mem_control_write | mem_control_read | bist_req_int));
    assign mem_web = ~mem_control_write;
    assign mem_addr = mem_addr_reg;
    assign mem_din = mem_wdata_reg;
    assign bist_req_int = (control_enable & (bist_control_start | bist_start) & ~bist_running);

    demo_sram_32x256_wrapper u_sram (
        .clk(clk),
        .csb(mem_csb),
        .web(mem_web),
        .addr(mem_addr),
        .din(mem_din),
        .dout(mem_dout)
    );

    always @(*) begin
        read_mux = 32'h00000000;
        case (rd_addr)
            ADDR_CONTROL: begin
                read_mux = {29'b00000000000000000000000000000, control_irq_enable, control_soft_reset, control_enable};
            end
            ADDR_STATUS: begin
                read_mux = status_readback;
            end
            ADDR_MEM_ADDR: begin
                read_mux = {24'h000000, mem_addr_reg};
            end
            ADDR_MEM_WDATA: begin
                read_mux = mem_wdata_reg;
            end
            ADDR_MEM_RDATA: begin
                read_mux = mem_dout;
            end
            ADDR_MEM_CONTROL: begin
                read_mux = {30'b000000000000000000000000000000, mem_control_read, mem_control_write};
            end
            ADDR_BIST_CONTROL: begin
                read_mux = {30'b000000000000000000000000000000, bist_control_clear, bist_control_start};
            end
            ADDR_BIST_STATUS: begin
                read_mux = {21'b000000000000000000000, bist_last_fail_addr, bist_running, bist_fail_r, bist_done_r};
            end
            ADDR_IRQ_STATUS: begin
                read_mux = {30'b000000000000000000000000000000, irq_fail_pending, irq_done_pending};
            end
            ADDR_IRQ_CLEAR: begin
                read_mux = 32'h00000000;
            end
            default: begin
                read_mux = 32'h00000000;
            end
        endcase
    end

    always @(*) begin
        status_readback = 32'h00000000;
        status_readback[0] = ready_r;
        status_readback[1] = bist_done_r;
        status_readback[2] = bist_fail_r;
        status_readback[3] = bist_running;
    end

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            control_enable <= 1'b0;
            control_soft_reset <= 1'b0;
            control_irq_enable <= 1'b0;
            mem_addr_reg <= 8'h00;
            mem_wdata_reg <= 32'h00000000;
            mem_control_write <= 1'b0;
            mem_control_read <= 1'b0;
            bist_control_start <= 1'b0;
            bist_control_clear <= 1'b0;
            bist_running <= 1'b0;
            bist_last_fail_addr <= 8'h00;
            irq_done_pending <= 1'b0;
            irq_fail_pending <= 1'b0;
            rd_data_r <= 32'h00000000;
            ready_r <= 1'b0;
            bist_done_r <= 1'b0;
            bist_fail_r <= 1'b0;
            irq_r <= 1'b0;
        end else begin
            control_soft_reset <= 1'b0;
            mem_control_write <= 1'b0;
            mem_control_read <= 1'b0;
            bist_control_start <= 1'b0;
            bist_control_clear <= 1'b0;

            if (wr_en) begin
                case (wr_addr)
                    ADDR_CONTROL: begin
                        control_enable <= wr_data[0];
                        control_soft_reset <= wr_data[1];
                        control_irq_enable <= wr_data[2];
                        if (wr_data[1]) begin
                            control_enable <= 1'b0;
                            control_irq_enable <= 1'b0;
                            bist_running <= 1'b0;
                            bist_done_r <= 1'b0;
                            bist_fail_r <= 1'b0;
                            irq_done_pending <= 1'b0;
                            irq_fail_pending <= 1'b0;
                            bist_last_fail_addr <= 8'h00;
                            ready_r <= 1'b0;
                            rd_data_r <= 32'h00000000;
                        end
                    end
                    ADDR_MEM_ADDR: begin
                        mem_addr_reg <= wr_data[7:0];
                    end
                    ADDR_MEM_WDATA: begin
                        mem_wdata_reg <= wr_data;
                    end
                    ADDR_MEM_CONTROL: begin
                        mem_control_write <= wr_data[0];
                        mem_control_read <= wr_data[1];
                    end
                    ADDR_BIST_CONTROL: begin
                        bist_control_start <= wr_data[0];
                        bist_control_clear <= wr_data[1];
                        if (wr_data[1]) begin
                            bist_done_r <= 1'b0;
                            bist_fail_r <= 1'b0;
                            irq_done_pending <= 1'b0;
                            irq_fail_pending <= 1'b0;
                            bist_last_fail_addr <= 8'h00;
                        end
                    end
                    ADDR_IRQ_CLEAR: begin
                        if (wr_data[0]) begin
                            irq_done_pending <= 1'b0;
                            irq_fail_pending <= 1'b0;
                        end
                    end
                    default: begin
                    end
                endcase
            end

            if (rd_en) begin
                rd_data_r <= read_mux;
            end

            if (bist_req_int) begin
                bist_running <= 1'b1;
                bist_done_r <= 1'b1;
                bist_fail_r <= 1'b0;
                bist_running <= 1'b0;
                irq_done_pending <= 1'b1;
                if (mem_addr_reg[0]) begin
                    bist_fail_r <= 1'b1;
                    irq_fail_pending <= 1'b1;
                    bist_last_fail_addr <= mem_addr_reg;
                end
            end

            if (mem_control_read) begin
                rd_data_r <= mem_dout;
            end

            if (mem_control_write) begin
                ready_r <= 1'b1;
            end else if (control_enable) begin
                ready_r <= 1'b1;
            end else begin
                ready_r <= 1'b0;
            end

            irq_r <= control_irq_enable & (irq_done_pending | irq_fail_pending);

            if (control_soft_reset) begin
                control_enable <= 1'b0;
                control_irq_enable <= 1'b0;
                bist_running <= 1'b0;
                bist_done_r <= 1'b0;
                bist_fail_r <= 1'b0;
                irq_done_pending <= 1'b0;
                irq_fail_pending <= 1'b0;
                bist_last_fail_addr <= 8'h00;
                ready_r <= 1'b0;
                rd_data_r <= 32'h00000000;
                irq_r <= 1'b0;
            end
        end
    end
endmodule
