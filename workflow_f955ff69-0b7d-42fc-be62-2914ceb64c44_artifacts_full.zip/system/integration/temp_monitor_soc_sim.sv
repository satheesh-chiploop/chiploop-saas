module temp_monitor_soc_sim (
  output logic alert_irq,
  output logic alert_status,
  input  logic avdd,
  input  logic avss,
  input  logic clk,
  input  logic [7:0] rd_addr,
  output logic [15:0] rd_data,
  input  logic rd_en,
  input  logic reset_n,
  input  logic [15:0] sensor_temp_celsius,
  output logic [11:0] temp_code,
  output logic [11:0] threshold_code,
  input  logic [7:0] wr_addr,
  input  logic [15:0] wr_data,
  input  logic wr_en
);

  // Interconnect wires
  logic w_sample_req;
  logic [11:0] w_adc_code;
  logic w_adc_valid;

  temp_sensor_adc_model u_analog (
    .sample_req(w_sample_req),
    .adc_code(w_adc_code),
    .adc_valid(w_adc_valid),
    .sensor_temp_celsius(sensor_temp_celsius),
    .avdd(avdd),
    .avss(avss)
  );

  temp_monitor_digital u_digital (
    .clk(clk),
    .reset_n(reset_n),
    .wr_en(wr_en),
    .wr_addr(wr_addr),
    .wr_data(wr_data),
    .rd_en(rd_en),
    .rd_addr(rd_addr),
    .rd_data(rd_data),
    .sample_req(w_sample_req),
    .adc_code(w_adc_code),
    .adc_valid(w_adc_valid),
    .alert_irq(alert_irq),
    .temp_code(temp_code),
    .threshold_code(threshold_code),
    .alert_status(alert_status)
  );

endmodule