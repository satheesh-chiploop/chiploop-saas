# Spec-to-RTL Conformance Report

Status: **partial**

- Requirements checked: 84
- Matched: 80
- Partial: 1
- Missing: 3
- Inconclusive: 0
- Interface: pass
- Register map: pass
- Clock/reset: pass

## Missing Or Partial Requirements
- REQ-004 [missing]: Latch sticky status and interrupt indicators according to the specification.
- REQ-005 [missing]: Expose latest filtered temperature and threshold on dedicated outputs.
- REQ-010 [missing]: CONTROL bit 2 IRQ_ENABLE is stored.
- REQ-037 [partial]: Maintain stored enable and irq_enable state.
