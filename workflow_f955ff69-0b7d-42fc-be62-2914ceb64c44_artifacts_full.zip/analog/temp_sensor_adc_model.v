module temp_sensor_adc_model (
    input  wire        sample_req,
    input  wire [15:0] sensor_temp_celsius,
    input  wire        avdd,
    input  wire        avss,
    output reg  [11:0] adc_code,
    output reg         adc_valid
);

    localparam integer TEMP_SCALE_NUM   = 10;
    localparam integer TEMP_SCALE_DEN   = 1;
    localparam integer ADC_OFFSET_CODE   = 2048;
    localparam integer GAIN_ERROR_PPM    = 0;
    localparam integer OFFSET_ERROR_CODE = 0;
    localparam integer NOMINAL_LATENCY   = 2;

    reg [31:0] latency_cnt;
    reg        pending_conv;
    reg        sample_req_d;

    reg signed [31:0] temp_sxt;
    reg signed [31:0] gain_adj;
    reg signed [31:0] scaled_code;
    reg signed [31:0] biased_code;
    reg signed [31:0] clamped_code;

    always @(*) begin
        temp_sxt = $signed({{16{sensor_temp_celsius[15]}}, sensor_temp_celsius});
        gain_adj = (temp_sxt * (1000000 + GAIN_ERROR_PPM)) / 1000000;
        scaled_code = (gain_adj * TEMP_SCALE_NUM) / TEMP_SCALE_DEN;
        biased_code = scaled_code + ADC_OFFSET_CODE + OFFSET_ERROR_CODE;

        if (biased_code < 0)
            clamped_code = 0;
        else if (biased_code > 4095)
            clamped_code = 4095;
        else
            clamped_code = biased_code;
    end

    always @(posedge sample_req or negedge avdd or negedge avss) begin
        if (!avdd || !avss) begin
            pending_conv <= 1'b0;
            latency_cnt   <= 32'd0;
            sample_req_d  <= 1'b0;
        end else begin
            pending_conv <= 1'b1;
            latency_cnt   <= NOMINAL_LATENCY[31:0];
            sample_req_d  <= 1'b1;
        end
    end

    always @(posedge sample_req) begin
        if (avdd && avss) begin
            pending_conv <= 1'b1;
            latency_cnt  <= NOMINAL_LATENCY[31:0];
            sample_req_d <= 1'b1;
        end
    end

    always @(posedge sample_req or negedge sample_req) begin
        if (!(avdd && avss)) begin
            adc_code  <= 12'd0;
            adc_valid <= 1'b0;
        end else if (sample_req) begin
            adc_valid <= 1'b0;
        end else begin
            adc_valid <= 1'b0;
        end
    end


endmodule
