module temp_monitor_digital_sample_ctrl(
    clk,
    reset_n,
    control_enable,
    control_sample_start_pulse,
    adc_valid,
    sample_req,
    status_busy
);
    input clk;
    input reset_n;
    input control_enable;
    input control_sample_start_pulse;
    input adc_valid;
    output sample_req;
    output status_busy;

    reg sample_req_r;
    reg status_busy_r;
    reg pending_r;
    reg [3:0] periodic_cnt_r;

    assign sample_req = sample_req_r;
    assign status_busy = status_busy_r;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            sample_req_r <= 1'b0;
            status_busy_r <= 1'b0;
            pending_r <= 1'b0;
            periodic_cnt_r <= 4'h0;
        end else begin
            sample_req_r <= 1'b0;
            if (control_sample_start_pulse) begin
                sample_req_r <= 1'b1;
                pending_r <= 1'b1;
            end else if (control_enable && !pending_r && (periodic_cnt_r == 4'h0)) begin
                sample_req_r <= 1'b1;
                pending_r <= 1'b1;
            end
            if (control_enable) begin
                periodic_cnt_r <= periodic_cnt_r + 4'h1;
            end else begin
                periodic_cnt_r <= 4'h0;
            end
            if (adc_valid) begin
                pending_r <= 1'b0;
            end
            status_busy_r <= pending_r;
        end
    end

endmodule
