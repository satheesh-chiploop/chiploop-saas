module temp_monitor_digital_alert_irq(
    clk,
    reset_n,
    temp_code,
    threshold_code,
    control_irq_enable,
    control_alert_clear_pulse,
    irq_clear_alert_pulse,
    irq_status_alert,
    irq_status_sample_done,
    status_alert_pending,
    alert_status,
    alert_irq
);
    input clk;
    input reset_n;
    input [11:0] temp_code;
    input [11:0] threshold_code;
    input control_irq_enable;
    input control_alert_clear_pulse;
    input irq_clear_alert_pulse;
    output irq_status_alert;
    input irq_status_sample_done;
    output status_alert_pending;
    output alert_status;
    output alert_irq;

    reg irq_status_alert_r;
    reg status_alert_pending_r;
    reg alert_status_r;
    reg alert_irq_r;

    assign irq_status_alert = irq_status_alert_r;
    assign status_alert_pending = status_alert_pending_r;
    assign alert_status = alert_status_r;
    assign alert_irq = alert_irq_r;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            irq_status_alert_r <= 1'b0;
            status_alert_pending_r <= 1'b0;
            alert_status_r <= 1'b0;
            alert_irq_r <= 1'b0;
        end else begin
            if (temp_code > threshold_code) begin
                irq_status_alert_r <= 1'b1;
                status_alert_pending_r <= 1'b1;
                alert_status_r <= 1'b1;
            end
            if (control_alert_clear_pulse) begin
                status_alert_pending_r <= 1'b0;
                alert_status_r <= 1'b0;
            end
            if (irq_clear_alert_pulse) begin
                irq_status_alert_r <= 1'b0;
                status_alert_pending_r <= 1'b0;
                alert_status_r <= 1'b0;
            end
            alert_irq_r <= control_irq_enable & (irq_status_alert_r | irq_status_sample_done);
        end
    end

endmodule
