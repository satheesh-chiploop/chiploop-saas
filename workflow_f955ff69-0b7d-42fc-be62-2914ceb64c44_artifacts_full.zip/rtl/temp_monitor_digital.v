module temp_monitor_digital(
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    adc_code,
    adc_valid,
    rd_data,
    sample_req,
    alert_irq,
    temp_code,
    threshold_code,
    alert_status
);
    input clk;
    input reset_n;
    input wr_en;
    input [7:0] wr_addr;
    input [15:0] wr_data;
    input rd_en;
    input [7:0] rd_addr;
    input [11:0] adc_code;
    input adc_valid;
    output [15:0] rd_data;
    output sample_req;
    output alert_irq;
    output [11:0] temp_code;
    output [11:0] threshold_code;
    output alert_status;

    wire temp_monitor_digital_mmio_control_enable;
    wire temp_monitor_digital_mmio_control_sample_start_pulse;
    wire temp_monitor_digital_mmio_control_irq_enable;
    wire temp_monitor_digital_mmio_control_alert_clear_pulse;
    wire temp_monitor_digital_mmio_status_sample_done;
    wire temp_monitor_digital_mmio_status_alert_pending;
    wire temp_monitor_digital_mmio_status_adc_valid_seen;
    wire temp_monitor_digital_mmio_status_busy;
    wire [15:0] temp_monitor_digital_mmio_sample_count;
    wire temp_monitor_digital_mmio_irq_status_alert;
    wire temp_monitor_digital_mmio_irq_status_sample_done;
    wire temp_monitor_digital_mmio_irq_clear_alert_pulse;
    wire temp_monitor_digital_mmio_irq_clear_sample_done_pulse;

    wire temp_monitor_digital_sample_ctrl_control_enable;
    wire temp_monitor_digital_sample_ctrl_control_sample_start_pulse;
    wire temp_monitor_digital_sample_ctrl_status_busy;

    wire temp_monitor_digital_temp_filter_status_sample_done;
    wire temp_monitor_digital_temp_filter_status_adc_valid_seen;
    wire [15:0] temp_monitor_digital_temp_filter_sample_count;

    wire [11:0] temp_monitor_digital_alert_irq_temp_code;
    wire [11:0] temp_monitor_digital_alert_irq_threshold_code;
    wire temp_monitor_digital_alert_irq_control_irq_enable;
    wire temp_monitor_digital_alert_irq_control_alert_clear_pulse;
    wire temp_monitor_digital_alert_irq_irq_clear_alert_pulse;
    wire temp_monitor_digital_alert_irq_irq_status_alert;
    wire temp_monitor_digital_alert_irq_irq_status_sample_done;
    wire temp_monitor_digital_alert_irq_status_alert_pending;

    wire [11:0] temp_monitor_digital_mmio_temp_code;
    assign temp_monitor_digital_mmio_temp_code = temp_code;
    assign temp_monitor_digital_sample_ctrl_control_enable = temp_monitor_digital_mmio_control_enable;
    assign temp_monitor_digital_sample_ctrl_control_sample_start_pulse = temp_monitor_digital_mmio_control_sample_start_pulse;
    assign temp_monitor_digital_alert_irq_temp_code = temp_monitor_digital_mmio_temp_code;
    assign temp_monitor_digital_alert_irq_threshold_code = threshold_code;
    assign temp_monitor_digital_alert_irq_control_irq_enable = temp_monitor_digital_mmio_control_irq_enable;
    assign temp_monitor_digital_alert_irq_control_alert_clear_pulse = temp_monitor_digital_mmio_control_alert_clear_pulse;
    assign temp_monitor_digital_alert_irq_irq_clear_alert_pulse = temp_monitor_digital_mmio_irq_clear_alert_pulse;
    assign temp_monitor_digital_alert_irq_irq_status_sample_done = temp_monitor_digital_mmio_irq_status_sample_done;
    assign temp_monitor_digital_mmio_status_busy = temp_monitor_digital_sample_ctrl_status_busy;

    temp_monitor_digital_mmio u_temp_monitor_digital_mmio (
        .clk(clk),
        .reset_n(reset_n),
        .wr_en(wr_en),
        .wr_addr(wr_addr),
        .wr_data(wr_data),
        .rd_en(rd_en),
        .rd_addr(rd_addr),
        .adc_valid(adc_valid),
        .sample_req(sample_req),
        .alert_irq(alert_irq),
        .temp_code(temp_monitor_digital_mmio_temp_code),
        .threshold_code(threshold_code),
        .alert_status(alert_status),
        .rd_data(rd_data),
        .control_enable(temp_monitor_digital_mmio_control_enable),
        .control_sample_start_pulse(temp_monitor_digital_mmio_control_sample_start_pulse),
        .control_irq_enable(temp_monitor_digital_mmio_control_irq_enable),
        .control_alert_clear_pulse(temp_monitor_digital_mmio_control_alert_clear_pulse),
        .status_sample_done(temp_monitor_digital_mmio_status_sample_done),
        .status_alert_pending(temp_monitor_digital_mmio_status_alert_pending),
        .status_adc_valid_seen(temp_monitor_digital_mmio_status_adc_valid_seen),
        .status_busy(temp_monitor_digital_mmio_status_busy),
        .sample_count(temp_monitor_digital_mmio_sample_count),
        .irq_status_alert(temp_monitor_digital_mmio_irq_status_alert),
        .irq_status_sample_done(temp_monitor_digital_mmio_irq_status_sample_done),
        .irq_clear_alert_pulse(temp_monitor_digital_mmio_irq_clear_alert_pulse),
        .irq_clear_sample_done_pulse(temp_monitor_digital_mmio_irq_clear_sample_done_pulse)
    );

    temp_monitor_digital_sample_ctrl u_temp_monitor_digital_sample_ctrl (
        .clk(clk),
        .reset_n(reset_n),
        .control_enable(temp_monitor_digital_sample_ctrl_control_enable),
        .control_sample_start_pulse(temp_monitor_digital_sample_ctrl_control_sample_start_pulse),
        .adc_valid(adc_valid),
        .sample_req(sample_req),
        .status_busy(temp_monitor_digital_sample_ctrl_status_busy)
    );

    temp_monitor_digital_temp_filter u_temp_monitor_digital_temp_filter (
        .clk(clk),
        .reset_n(reset_n),
        .adc_code(adc_code),
        .adc_valid(adc_valid),
        .status_sample_done(temp_monitor_digital_temp_filter_status_sample_done),
        .status_adc_valid_seen(temp_monitor_digital_temp_filter_status_adc_valid_seen),
        .sample_count(temp_monitor_digital_temp_filter_sample_count),
        .temp_code(temp_code)
    );

    temp_monitor_digital_alert_irq u_temp_monitor_digital_alert_irq (
        .clk(clk),
        .reset_n(reset_n),
        .temp_code(temp_monitor_digital_alert_irq_temp_code),
        .threshold_code(temp_monitor_digital_alert_irq_threshold_code),
        .control_irq_enable(temp_monitor_digital_alert_irq_control_irq_enable),
        .control_alert_clear_pulse(temp_monitor_digital_alert_irq_control_alert_clear_pulse),
        .irq_clear_alert_pulse(temp_monitor_digital_alert_irq_irq_clear_alert_pulse),
        .irq_status_alert(temp_monitor_digital_alert_irq_irq_status_alert),
        .irq_status_sample_done(temp_monitor_digital_alert_irq_irq_status_sample_done),
        .status_alert_pending(temp_monitor_digital_alert_irq_status_alert_pending),
        .alert_status(alert_status),
        .alert_irq(alert_irq)
    );

endmodule
