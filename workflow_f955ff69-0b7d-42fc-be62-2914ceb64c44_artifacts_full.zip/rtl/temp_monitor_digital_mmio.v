module temp_monitor_digital_mmio(
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    adc_valid,
    sample_req,
    alert_irq,
    temp_code,
    threshold_code,
    alert_status,
    rd_data,
    control_enable,
    control_sample_start_pulse,
    control_irq_enable,
    control_alert_clear_pulse,
    status_sample_done,
    status_alert_pending,
    status_adc_valid_seen,
    status_busy,
    sample_count,
    irq_status_alert,
    irq_status_sample_done,
    irq_clear_alert_pulse,
    irq_clear_sample_done_pulse
);
    input clk;
    input reset_n;
    input wr_en;
    input [7:0] wr_addr;
    input [15:0] wr_data;
    input rd_en;
    input [7:0] rd_addr;
    input adc_valid;
    output sample_req;
    output alert_irq;
    input [11:0] temp_code;
    output [11:0] threshold_code;
    output alert_status;
    output [15:0] rd_data;
    output control_enable;
    output control_sample_start_pulse;
    output control_irq_enable;
    output control_alert_clear_pulse;
    output status_sample_done;
    output status_alert_pending;
    output status_adc_valid_seen;
    output status_busy;
    output [15:0] sample_count;
    output irq_status_alert;
    output irq_status_sample_done;
    output irq_clear_alert_pulse;
    output irq_clear_sample_done_pulse;

    reg control_enable_r;
    reg control_irq_enable_r;
    reg [11:0] threshold_code_r;
    reg status_sample_done_r;
    reg status_alert_pending_r;
    reg status_adc_valid_seen_r;
    reg status_busy_r;
    reg [15:0] sample_count_r;
    reg irq_status_alert_r;
    reg irq_status_sample_done_r;
    reg sample_req_r;
    reg alert_irq_r;
    reg alert_status_r;
    reg control_sample_start_pulse_r;
    reg control_alert_clear_pulse_r;
    reg irq_clear_alert_pulse_r;
    reg irq_clear_sample_done_pulse_r;
    reg [15:0] rd_data_r;
    assign control_enable = control_enable_r;
    assign control_irq_enable = control_irq_enable_r;
    assign threshold_code = threshold_code_r;
    assign status_sample_done = status_sample_done_r;
    assign status_alert_pending = status_alert_pending_r;
    assign status_adc_valid_seen = status_adc_valid_seen_r;
    assign status_busy = status_busy_r;
    assign sample_count = sample_count_r;
    assign irq_status_alert = irq_status_alert_r;
    assign irq_status_sample_done = irq_status_sample_done_r;
    assign sample_req = sample_req_r;
    assign alert_irq = alert_irq_r;
    assign alert_status = alert_status_r;
    assign control_sample_start_pulse = control_sample_start_pulse_r;
    assign control_alert_clear_pulse = control_alert_clear_pulse_r;
    assign irq_clear_alert_pulse = irq_clear_alert_pulse_r;
    assign irq_clear_sample_done_pulse = irq_clear_sample_done_pulse_r;
    assign rd_data = rd_data_r;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            control_enable_r <= 1'b0;
            control_irq_enable_r <= 1'b0;
            threshold_code_r <= 12'h000;
            status_sample_done_r <= 1'b0;
            status_alert_pending_r <= 1'b0;
            status_adc_valid_seen_r <= 1'b0;
            status_busy_r <= 1'b0;
            sample_count_r <= 16'h0000;
            irq_status_alert_r <= 1'b0;
            irq_status_sample_done_r <= 1'b0;
            sample_req_r <= 1'b0;
            alert_irq_r <= 1'b0;
            alert_status_r <= 1'b0;
            control_sample_start_pulse_r <= 1'b0;
            control_alert_clear_pulse_r <= 1'b0;
            irq_clear_alert_pulse_r <= 1'b0;
            irq_clear_sample_done_pulse_r <= 1'b0;
            rd_data_r <= 16'h0000;
        end else begin
            control_sample_start_pulse_r <= 1'b0;
            control_alert_clear_pulse_r <= 1'b0;
            irq_clear_alert_pulse_r <= 1'b0;
            irq_clear_sample_done_pulse_r <= 1'b0;
            sample_req_r <= 1'b0;
            if (wr_en && (wr_addr == 8'h00)) begin
                control_enable_r <= wr_data[0];
                control_irq_enable_r <= wr_data[2];
                if (wr_data[1]) begin
                    control_sample_start_pulse_r <= 1'b1;
                    sample_req_r <= 1'b1;
                    status_busy_r <= 1'b1;
                end
                if (wr_data[3]) begin
                    control_alert_clear_pulse_r <= 1'b1;
                    status_alert_pending_r <= 1'b0;
                    alert_status_r <= 1'b0;
                    irq_status_alert_r <= 1'b0;
                end
            end else if (wr_en && (wr_addr == 8'h08)) begin
                threshold_code_r <= wr_data[11:0];
            end else if (wr_en && (wr_addr == 8'h18)) begin
                if (wr_data[0]) begin
                    irq_clear_alert_pulse_r <= 1'b1;
                    irq_status_alert_r <= 1'b0;
                    alert_status_r <= 1'b0;
                    status_alert_pending_r <= 1'b0;
                end
                if (wr_data[1]) begin
                    irq_clear_sample_done_pulse_r <= 1'b1;
                    irq_status_sample_done_r <= 1'b0;
                    status_sample_done_r <= 1'b0;
                end
            end

            if (adc_valid) begin
                status_sample_done_r <= 1'b1;
                status_adc_valid_seen_r <= 1'b1;
                sample_count_r <= sample_count_r + 16'h0001;
                irq_status_sample_done_r <= 1'b1;
            end

            status_busy_r <= sample_req_r & ~adc_valid;

            if (rd_en) begin
                case (rd_addr)
                    8'h00: rd_data_r <= {12'h000, control_irq_enable_r, 1'b0, control_enable_r, 1'b0};
                    8'h04: rd_data_r <= {12'h000, status_busy_r, status_adc_valid_seen_r, status_alert_pending_r, status_sample_done_r};
                    8'h08: rd_data_r <= {4'h0, threshold_code_r};
                    8'h0C: rd_data_r <= {4'h0, temp_code};
                    8'h10: rd_data_r <= sample_count_r;
                    8'h14: rd_data_r <= {14'h0000, irq_status_sample_done_r, irq_status_alert_r};
                    8'h18: rd_data_r <= 16'h0000;
                    default: rd_data_r <= 16'h0000;
                endcase
            end
        end
    end

endmodule
