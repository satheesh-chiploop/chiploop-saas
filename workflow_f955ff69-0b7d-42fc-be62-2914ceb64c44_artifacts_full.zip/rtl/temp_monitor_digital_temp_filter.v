module temp_monitor_digital_temp_filter(
    clk,
    reset_n,
    adc_code,
    adc_valid,
    status_sample_done,
    status_adc_valid_seen,
    sample_count,
    temp_code
);
    input clk;
    input reset_n;
    input [11:0] adc_code;
    input adc_valid;
    output status_sample_done;
    output status_adc_valid_seen;
    output [15:0] sample_count;
    output [11:0] temp_code;
    reg status_sample_done_r;
    reg status_adc_valid_seen_r;
    reg [15:0] sample_count_r;
    reg [11:0] temp_code_r;
    reg [11:0] prev_sample_r;
    reg prev_valid_r;

    assign status_sample_done = status_sample_done_r;
    assign status_adc_valid_seen = status_adc_valid_seen_r;
    assign sample_count = sample_count_r;
    assign temp_code = temp_code_r;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            status_sample_done_r <= 1'b0;
            status_adc_valid_seen_r <= 1'b0;
            sample_count_r <= 16'h0000;
            temp_code_r <= 12'h000;
            prev_sample_r <= 12'h000;
            prev_valid_r <= 1'b0;
        end else begin
            if (adc_valid) begin
                if (prev_valid_r) begin
                    temp_code_r <= (adc_code + prev_sample_r) >> 1;
                end else begin
                    temp_code_r <= adc_code;
                end
                prev_sample_r <= adc_code;
                prev_valid_r <= 1'b1;
                status_sample_done_r <= 1'b1;
                status_adc_valid_seen_r <= 1'b1;
                sample_count_r <= sample_count_r + 16'h0001;
            end
        end
    end

endmodule
