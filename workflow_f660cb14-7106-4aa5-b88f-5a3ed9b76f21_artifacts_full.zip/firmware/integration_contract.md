# Firmware Integration Contract

## 1) Contract Overview
- Defines the **global firmware integration contract** for `Embedded_Run` and the full execution chain between Firmware, System Software, and Host Software.
- Specifies the **public APIs**, expected behaviors, error codes, logging schema, and versioning rules.
- Establishes the contract for **power mode entry/exit**, readiness signaling, and failure handling.
- Defines the **ownership boundaries** between Firmware, System/Host software, and Validation.
- Covers **interrupt and DMA behavior** only as part of the full-chain integration contract when applicable to exposed interfaces and system behavior.
- Requires Firmware to remain **backward compatible within a compatible major version** unless explicitly version-bumped.
- Treats validation as an explicit contract consumer: compliance must be testable via logs, status APIs, and deterministic state transitions.

## 2) Contract Version + Compatibility Policy
- **Contract version:** `1.0.0`
- **Versioning scheme:** `MAJOR.MINOR.PATCH`
  - **MAJOR**: breaking change to API, state machine, error codes, log schema, or ownership boundaries.
  - **MINOR**: backward-compatible additive change.
  - **PATCH**: backward-compatible bug fix or clarification with no contract surface change.
- **Compatibility policy**
  - Firmware must accept any System/Host client targeting the same **MAJOR** version.
  - Firmware may add new optional fields or status values in a backward-compatible way under **MINOR** increments.
  - Removal or semantic change of any published API, log field, or error code requires a **MAJOR** bump.
  - System/Host software must treat unknown optional fields as ignorable and unknown non-fatal status codes as version-extension events, not immediate failures.
- **Version reporting**
  - Firmware shall expose the contract version in a queryable status interface and in boot/runtime logs.

## 3) Interfaces

### 3.1 Public Firmware Interfaces

| Interface | Type | Inputs | Outputs | Expected Behavior | Error Codes |
|---|---|---|---|---|---|
| `fw_init()` | API | Platform configuration, runtime context | Init status | Initializes firmware-owned subsystems and enters a defined post-init state | `FW_OK`, `FW_ERR_INVALID_ARG`, `FW_ERR_HW_INIT`, `FW_ERR_STATE` |
| `fw_start()` | API | None or prevalidated context | Run status | Transitions firmware into `Embedded_Run` operational state | `FW_OK`, `FW_ERR_STATE`, `FW_ERR_DEPENDENCY` |
| `fw_get_status()` | API | None | Status struct | Returns current state, version, and health indicators | `FW_OK`, `FW_ERR_UNAVAILABLE` |
| `fw_get_error()` | API | None | Last error record | Returns last latched error and context | `FW_OK`, `FW_ERR_EMPTY` |
| `fw_enter_power_mode(mode)` | API | Requested power mode | Transition status | Requests firmware-controlled transition to supported power mode | `FW_OK`, `FW_ERR_UNSUPPORTED`, `FW_ERR_STATE` |
| `fw_request_shutdown(reason)` | API | Shutdown reason | Shutdown status | Initiates orderly shutdown sequence and log flush if supported | `FW_OK`, `FW_ERR_STATE` |
| `fw_read_log(cursor, out)` | API | Log cursor | Log records | Returns ordered log records without altering runtime behavior | `FW_OK`, `FW_ERR_INVALID_ARG`, `FW_ERR_EMPTY` |
| `fw_get_version()` | API | None | Version struct | Returns firmware image version and contract version | `FW_OK` |

### 3.2 Status and State Model

| State | Meaning | Allowed Transitions |
|---|---|---|
| `RESET` | Core not yet initialized | `INIT` |
| `INIT` | Firmware initialization in progress | `READY`, `FAULT` |
| `READY` | Firmware initialized and able to accept runtime requests | `RUN`, `POWER_SAVE`, `FAULT` |
| `RUN` | Normal operational state under `Embedded_Run` | `READY`, `POWER_SAVE`, `SHUTDOWN`, `FAULT` |
| `POWER_SAVE` | Reduced-activity power mode | `RUN`, `READY`, `FAULT` |
| `SHUTDOWN` | Controlled shutdown in progress | `RESET` or terminal halt per platform policy |
| `FAULT` | Non-recoverable or latched failure state | `SHUTDOWN`, `RESET` |

### 3.3 Error Code Contract

| Error Code | Meaning | Recovery Expectation |
|---|---|---|
| `FW_OK` | Operation succeeded | None |
| `FW_ERR_INVALID_ARG` | Input parameter invalid | Fix caller input |
| `FW_ERR_STATE` | Operation not permitted in current state | Retry only after correct state transition |
| `FW_ERR_UNSUPPORTED` | Requested feature/mode not supported by this build/platform | Use supported alternative |
| `FW_ERR_HW_INIT` | Underlying hardware initialization failed | Platform/service action required |
| `FW_ERR_DEPENDENCY` | Required dependency not ready | Retry after dependency becomes ready |
| `FW_ERR_UNAVAILABLE` | Requested information not currently available | Retry later |
| `FW_ERR_EMPTY` | No data available | No action required |
| `FW_ERR_INTERNAL` | Unspecified internal firmware fault | Enter fault handling path |

### 3.4 Logging Schema

| Field | Type | Required | Description |
|---|---|---:|---|
| `ts_us` | uint64 | Yes | Monotonic timestamp in microseconds |
| `seq` | uint32 | Yes | Monotonic log sequence number |
| `level` | enum | Yes | Severity: `DEBUG`, `INFO`, `WARN`, `ERROR`, `FATAL` |
| `module` | string | Yes | Firmware module or subsystem name |
| `event_id` | string | Yes | Stable event identifier |
| `code` | string/int | Yes | Error or status code associated with the event |
| `message` | string | Yes | Human-readable summary |
| `context` | object/map | No | Structured key-value details, versioned additively |

**Logging rules**
- Logs must be **monotonic in sequence order**.
- Error and fault events must include a stable `event_id` and a contract-defined `code`.
- Log schema changes must be backward compatible within the same major version.
- Validation must be able to correlate boot and runtime events using `seq` and `event_id`.

### 3.5 Power Mode Contract

| Power Mode | Entry Condition | Exit Condition | Firmware Responsibility | Host/System Responsibility |
|---|---|---|---|---|
| `ACTIVE` | Normal runtime state | External request or policy | Maintain full services | Avoid conflicting power requests |
| `LOW_POWER` | Supported request and safe state | Wake event or request | Quiesce nonessential activity | Respect entry/exit acknowledgments |
| `SLEEP` | Platform supports sleep and firmware is ready | Wake event | Save minimal state required for resume | Preserve wake source configuration |
| `OFF/DEEP_OFF` | Platform-defined terminal low-power state | Cold boot/reset | Flush state if supported before entry | Do not assume runtime services remain available |

### 3.6 Boot and Ready Signaling

| Signal | Source | Meaning | Consumer Expectation |
|---|---|---|---|
| `BootLog` | Firmware | Early boot status and failure points | Host/System uses for bring-up and diagnostics |
| `ReadySignal` | Firmware | Firmware has reached a contract-defined ready state | Host/System may begin runtime interactions |
| `FaultSignal` | Firmware | Firmware entered fault state | Host/System must stop normal requests and collect diagnostics |

### 3.7 Versioning Interfaces

| Interface | Output | Notes |
|---|---|---|
| `fw_get_version()` | Firmware image version, build ID, contract version | Must be callable once firmware is queryable |
| Boot log version field | Contract version and image version | Required for validation and field support |

## 4) Ownership Boundaries

| Area | Firmware Ownership | System/Host Ownership | Validation Ownership |
|---|---|---|---|
| Initialization sequencing | Implements init state machine and readiness | Waits for ready signal before runtime calls | Verifies state transitions and timing |
| Error reporting | Produces error codes and logs | Interprets and reacts to published codes | Confirms codes, severity, and recovery paths |
| Power mode transitions | Executes supported transitions and reports status | Requests supported modes only | Tests supported/unsupported requests |
| Runtime APIs | Defines and services contract APIs | Calls only documented interfaces | Exercises API correctness and invalid-input handling |
| Version reporting | Publishes version/compatibility info | Checks compatibility before use | Confirms version parsing and policy compliance |
| Failure handling | Enters fault/shutdown policy | Stops normal interaction on fault | Injects failures and validates behavior |
| Logs | Owns schema, ordering, and content | Consumes logs for diagnostics | Verifies schema, ordering, and required events |

## 5) Assumptions
- Firmware exposes a deterministic state machine visible to System/Host software.
- The platform provides a monotonic time source for log timestamps.
- `Embedded_Run` is the normal operational mode unless a power or fault transition occurs.
- System/Host software is responsible for respecting readiness and state preconditions before invoking runtime APIs.
- Validation has access to firmware logs, status queries, and a means to observe state transitions.
- Unsupported modes or APIs are rejected with explicit error codes; silent fallback is not allowed for contract-visible behavior.

## 6) Validation Hooks
- Verify `fw_get_version()` reports the expected contract major version before any runtime use.
- Confirm boot sequence produces ordered `BootLog` entries with required fields and no sequence regressions.
- Validate `ReadySignal` is asserted only after initialization completes and required dependencies are ready.
- Exercise each API with valid and invalid inputs and confirm documented error codes.
- Confirm power mode requests transition only through permitted states and reject unsupported modes with `FW_ERR_UNSUPPORTED`.
- Induce a firmware fault and verify `FaultSignal`, latched error reporting, and shutdown/fault policy behavior.
- Check that log schema fields are present, parseable, and backward compatible with the declared contract version.
- Validate that System/Host software refrains from runtime calls before readiness and stops calls after fault indication.
- Confirm validation can correlate boot, runtime, and failure events using `seq`, `event_id`, and version fields.