/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/f660cb14-7106-4aa5-b88f-5a3ed9b76f21/887cf17f-8fcd-46ad-bcb0-5fcf244cce4c/digital/system/imported_rtl/temp_sensor_adc_model.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/f660cb14-7106-4aa5-b88f-5a3ed9b76f21/887cf17f-8fcd-46ad-bcb0-5fcf244cce4c/digital/system/imported_rtl/control_fsm.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/f660cb14-7106-4aa5-b88f-5a3ed9b76f21/887cf17f-8fcd-46ad-bcb0-5fcf244cce4c/digital/system/imported_rtl/sample_capture_filter.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/f660cb14-7106-4aa5-b88f-5a3ed9b76f21/887cf17f-8fcd-46ad-bcb0-5fcf244cce4c/digital/system/imported_rtl/temp_monitor_digital.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/f660cb14-7106-4aa5-b88f-5a3ed9b76f21/887cf17f-8fcd-46ad-bcb0-5fcf244cce4c/digital/system/imported_rtl/temp_monitor_soc_phys.sv
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/f660cb14-7106-4aa5-b88f-5a3ed9b76f21/887cf17f-8fcd-46ad-bcb0-5fcf244cce4c/digital/system/imported_rtl/temp_monitor_soc_sim.sv
