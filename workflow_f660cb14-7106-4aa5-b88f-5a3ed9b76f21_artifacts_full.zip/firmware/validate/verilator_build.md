<!-- ASSUMPTION: Replace placeholders with concrete file paths before execution. -->
<!-- ASSUMPTION: Cocotb integration is driven externally through pytest/cocotb makefile flow. -->

# Verilator Build Plan

## Inputs
- RTL top module: temp_monitor_soc_sim
- RTL filelist: /root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/f660cb14-7106-4aa5-b88f-5a3ed9b76f21/887cf17f-8fcd-46ad-bcb0-5fcf244cce4c/digital/firmware/validate/verilator_rtl_filelist.f
- Optional include flags: <OPTIONAL_INCLUDE_FLAGS>
- Optional define flags: <OPTIONAL_DEFINE_FLAGS>
- Cocotb Python test/harness: firmware/validate/cocotb_harness.py

## Deterministic command template

verilator -cc --build --trace --top-module temp_monitor_soc_sim \
  -f /root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/f660cb14-7106-4aa5-b88f-5a3ed9b76f21/887cf17f-8fcd-46ad-bcb0-5fcf244cce4c/digital/firmware/validate/verilator_rtl_filelist.f \
  <OPTIONAL_INCLUDE_FLAGS> \
  <OPTIONAL_DEFINE_FLAGS> \
  

## Expected outputs
- Build directory: obj_dir/
- Generated make/build products under: obj_dir/
- Runnable binary name: obj_dir/Vtemp_monitor_soc_sim

## Notes
- Python cocotb tests are executed via pytest or cocotb makefile flow.
- Do not pass Python files to --exe.
- If firmware/ELF integration is needed, handle it via simulator memory preload or cocotb hooks.
