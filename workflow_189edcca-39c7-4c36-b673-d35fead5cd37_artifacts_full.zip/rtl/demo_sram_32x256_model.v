module demo_sram_32x256_model (
    clk,
    csb,
    web,
    addr,
    din,
    dout
);
input clk;
input csb;
input web;
input [7:0] addr;
input [31:0] din;
output reg [31:0] dout;

reg [31:0] mem [0:255];
reg [31:0] read_data;

integer i;

always @(posedge clk) begin
    if (csb == 1'b0) begin
        if (web == 1'b0) begin
            mem[addr] <= din;
        end
        read_data <= mem[addr];
    end
end

always @(*) begin
    dout = read_data;
end

initial begin
    for (i = 0; i < 256; i = i + 1) begin
        mem[i] = 32'h00000000;
    end
    read_data = 32'h00000000;
    dout = 32'h00000000;
end

endmodule
