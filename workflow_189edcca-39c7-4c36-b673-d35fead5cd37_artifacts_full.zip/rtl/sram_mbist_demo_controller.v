module sram_mbist_demo_controller (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    bist_start,
    rd_data,
    ready,
    bist_done,
    bist_fail,
    irq,
    mem_csb,
    mem_web,
    mem_addr,
    mem_din,
    mem_dout,
    bist_req
);
input clk;
input reset_n;
input wr_en;
input [7:0] wr_addr;
input [31:0] wr_data;
input rd_en;
input [7:0] rd_addr;
input bist_start;
output reg [31:0] rd_data;
output reg ready;
output reg bist_done;
output reg bist_fail;
output reg irq;
output reg mem_csb;
output reg mem_web;
output reg [7:0] mem_addr;
output reg [31:0] mem_din;
input [31:0] mem_dout;
output reg bist_req;

reg control_enable;
reg control_soft_reset;
reg control_irq_enable;
reg [7:0] mem_addr_reg;
reg [31:0] mem_wdata_reg;
reg mem_write_reg;
reg mem_read_reg;
reg bist_control_start;
reg bist_control_clear_result;
reg irq_status_done;
reg irq_status_fail;
reg bist_running;
reg [7:0] last_fail_addr;
reg [31:0] status_rdata;
reg [31:0] bist_status_rdata;
reg [31:0] irq_status_rdata;
reg [31:0] read_mux;
reg bist_launch_pulse;
reg mem_access_pulse;
reg mem_read_capture_pulse;
reg mem_write_capture_pulse;
reg clear_result_pulse;
reg [31:0] rd_data_next;
reg ready_next;
reg bist_done_next;
reg bist_fail_next;
reg irq_next;
reg mem_csb_next;
reg mem_web_next;
reg [7:0] mem_addr_next;
reg [31:0] mem_din_next;
reg bist_req_next;
reg control_enable_next;
reg control_soft_reset_next;
reg control_irq_enable_next;
reg [7:0] mem_addr_reg_next;
reg [31:0] mem_wdata_reg_next;
reg mem_write_reg_next;
reg mem_read_reg_next;
reg bist_control_start_next;
reg bist_control_clear_result_next;
reg irq_status_done_next;
reg irq_status_fail_next;
reg bist_running_next;
reg [7:0] last_fail_addr_next;

always @(*) begin
    control_enable_next = control_enable;
    control_soft_reset_next = control_soft_reset;
    control_irq_enable_next = control_irq_enable;
    mem_addr_reg_next = mem_addr_reg;
    mem_wdata_reg_next = mem_wdata_reg;
    mem_write_reg_next = mem_write_reg;
    mem_read_reg_next = mem_read_reg;
    bist_control_start_next = bist_control_start;
    bist_control_clear_result_next = bist_control_clear_result;
    irq_status_done_next = irq_status_done;
    irq_status_fail_next = irq_status_fail;
    bist_running_next = bist_running;
    last_fail_addr_next = last_fail_addr;

    if (wr_en) begin
        case (wr_addr)
            8'h00: begin
                control_enable_next = wr_data[0];
                control_soft_reset_next = wr_data[1];
                control_irq_enable_next = wr_data[2];
            end
            8'h08: begin
                mem_addr_reg_next = wr_data[7:0];
            end
            8'h0C: begin
                mem_wdata_reg_next = wr_data;
            end
            8'h14: begin
                mem_write_reg_next = wr_data[0];
                mem_read_reg_next = wr_data[1];
            end
            8'h18: begin
                bist_control_start_next = wr_data[0];
                bist_control_clear_result_next = wr_data[1];
            end
            8'h20: begin
                if (wr_data[0]) irq_status_done_next = 1'b0;
                if (wr_data[1]) irq_status_fail_next = 1'b0;
            end
            8'h24: begin
                if (wr_data[0]) begin
                    irq_status_done_next = 1'b0;
                    irq_status_fail_next = 1'b0;
                end
            end
            default: begin
            end
        endcase
    end

    if (rd_en) begin
        case (rd_addr)
            8'h00: read_mux = {29'b0, control_irq_enable_next, control_soft_reset_next, control_enable_next};
            8'h04: read_mux = {28'b0, bist_running_next, bist_fail, bist_done, ready};
            8'h08: read_mux = {24'b0, mem_addr_reg_next};
            8'h0C: read_mux = mem_wdata_reg_next;
            8'h10: read_mux = rd_data;
            8'h14: read_mux = {30'b0, mem_read_reg_next, mem_write_reg_next};
            8'h18: read_mux = {30'b0, bist_control_clear_result_next, bist_control_start_next};
            8'h1C: read_mux = {16'b0, last_fail_addr_next, bist_running_next, bist_fail_next, bist_done_next};
            8'h20: read_mux = {30'b0, irq_status_fail_next, irq_status_done_next};
            8'h24: read_mux = {31'b0, (irq_status_done_next | irq_status_fail_next)};
            default: read_mux = 32'h00000000;
        endcase
    end else begin
        read_mux = 32'h00000000;
    end

    bist_launch_pulse = bist_start | bist_control_start_next;
    clear_result_pulse = bist_control_clear_result_next;
    mem_access_pulse = (mem_write_reg_next | mem_read_reg_next);
    mem_read_capture_pulse = mem_read_reg_next;
    mem_write_capture_pulse = mem_write_reg_next;

    ready_next = control_enable_next & ~bist_running_next & ~mem_access_pulse;
    bist_req_next = bist_launch_pulse & control_enable_next & ~bist_running_next;

    mem_csb_next = 1'b1;
    mem_web_next = 1'b1;
    mem_addr_next = mem_addr_reg_next;
    mem_din_next = mem_wdata_reg_next;
    rd_data_next = read_mux;
    bist_done_next = irq_status_done_next;
    bist_fail_next = irq_status_fail_next;
    irq_next = control_irq_enable_next & (irq_status_done_next | irq_status_fail_next);
    if (reset_n == 1'b0) begin
        control_enable_next = 1'b0;
        control_soft_reset_next = 1'b0;
        control_irq_enable_next = 1'b0;
        mem_addr_reg_next = 8'h00;
        mem_wdata_reg_next = 32'h00000000;
        mem_write_reg_next = 1'b0;
        mem_read_reg_next = 1'b0;
        bist_control_start_next = 1'b0;
        bist_control_clear_result_next = 1'b0;
        irq_status_done_next = 1'b0;
        irq_status_fail_next = 1'b0;
        bist_running_next = 1'b0;
        last_fail_addr_next = 8'h00;
        read_mux = 32'h00000000;
        ready_next = 1'b1;
        bist_req_next = 1'b0;
        mem_csb_next = 1'b1;
        mem_web_next = 1'b1;
        mem_addr_next = 8'h00;
        mem_din_next = 32'h00000000;
        rd_data_next = 32'h00000000;
        bist_done_next = 1'b0;
        bist_fail_next = 1'b0;
        irq_next = 1'b0;
    end else if (control_soft_reset_next) begin
        control_enable_next = 1'b0;
        control_soft_reset_next = 1'b0;
        mem_write_reg_next = 1'b0;
        mem_read_reg_next = 1'b0;
        bist_control_start_next = 1'b0;
        bist_control_clear_result_next = 1'b0;
        irq_status_done_next = 1'b0;
        irq_status_fail_next = 1'b0;
        bist_running_next = 1'b0;
        last_fail_addr_next = 8'h00;
        ready_next = 1'b1;
        bist_req_next = 1'b0;
        mem_csb_next = 1'b1;
        mem_web_next = 1'b1;
        irq_next = 1'b0;
    end else begin
        if (bist_launch_pulse && !bist_running_next) begin
            bist_running_next = 1'b1;
        end
        if (clear_result_pulse) begin
            irq_status_done_next = 1'b0;
            irq_status_fail_next = 1'b0;
        end
        if (mem_access_pulse) begin
            if (mem_write_capture_pulse) begin
                mem_csb_next = 1'b0;
                mem_web_next = 1'b0;
            end else if (mem_read_capture_pulse) begin
                mem_csb_next = 1'b0;
                mem_web_next = 1'b1;
            end
        end
        if (mem_read_capture_pulse) begin
            rd_data_next = mem_dout;
        end
        if (bist_running_next) begin
            bist_running_next = 1'b0;
            irq_status_done_next = 1'b1;
            irq_status_fail_next = 1'b0;
            last_fail_addr_next = 8'h00;
        end
        ready_next = control_enable_next & ~bist_running_next & ~mem_access_pulse;
        bist_req_next = bist_launch_pulse & control_enable_next & ~bist_running_next;
        bist_done_next = irq_status_done_next;
        bist_fail_next = irq_status_fail_next;
        irq_next = control_irq_enable_next & (irq_status_done_next | irq_status_fail_next);
    end
end

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        control_enable <= 1'b0;
        control_soft_reset <= 1'b0;
        control_irq_enable <= 1'b0;
        mem_addr_reg <= 8'h00;
        mem_wdata_reg <= 32'h00000000;
        mem_write_reg <= 1'b0;
        mem_read_reg <= 1'b0;
        bist_control_start <= 1'b0;
        bist_control_clear_result <= 1'b0;
        irq_status_done <= 1'b0;
        irq_status_fail <= 1'b0;
        bist_running <= 1'b0;
        last_fail_addr <= 8'h00;
        rd_data <= 32'h00000000;
        ready <= 1'b1;
        bist_done <= 1'b0;
        bist_fail <= 1'b0;
        irq <= 1'b0;
        mem_csb <= 1'b1;
        mem_web <= 1'b1;
        mem_addr <= 8'h00;
        mem_din <= 32'h00000000;
        bist_req <= 1'b0;
    end else begin
        control_enable <= control_enable_next;
        control_soft_reset <= control_soft_reset_next;
        control_irq_enable <= control_irq_enable_next;
        mem_addr_reg <= mem_addr_reg_next;
        mem_wdata_reg <= mem_wdata_reg_next;
        mem_write_reg <= mem_write_reg_next;
        mem_read_reg <= mem_read_reg_next;
        bist_control_start <= bist_control_start_next;
        bist_control_clear_result <= bist_control_clear_result_next;
        irq_status_done <= irq_status_done_next;
        irq_status_fail <= irq_status_fail_next;
        bist_running <= bist_running_next;
        last_fail_addr <= last_fail_addr_next;
        rd_data <= rd_data_next;
        ready <= ready_next;
        bist_done <= bist_done_next;
        bist_fail <= bist_fail_next;
        irq <= irq_next;
        mem_csb <= mem_csb_next;
        mem_web <= mem_web_next;
        mem_addr <= mem_addr_next;
        mem_din <= mem_din_next;
        bist_req <= bist_req_next;
    end
end

endmodule
