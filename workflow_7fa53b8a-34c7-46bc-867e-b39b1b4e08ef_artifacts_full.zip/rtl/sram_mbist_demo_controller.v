module sram_mbist_demo_controller (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    bist_start,
    rd_data,
    ready,
    bist_done,
    bist_fail,
    irq,
    mem_clk,
    mem_csb,
    mem_web,
    mem_addr,
    mem_din,
    mem_dout,
    bist_req,
    bist_running,
    bist_latch_done,
    bist_latch_fail,
    irq_latched
);
    input clk;
    input reset_n;
    input wr_en;
    input [7:0] wr_addr;
    input [31:0] wr_data;
    input rd_en;
    input [7:0] rd_addr;
    input bist_start;
    output [31:0] rd_data;
    output ready;
    output bist_done;
    output bist_fail;
    output irq;
    output mem_clk;
    output mem_csb;
    output mem_web;
    output [7:0] mem_addr;
    output [31:0] mem_din;
    input [31:0] mem_dout;
    output bist_req;
    output bist_running;
    output bist_latch_done;
    output bist_latch_fail;
    output irq_latched;

    reg [31:0] rd_data_r;
    reg ready_r;
    reg bist_done_r;
    reg bist_fail_r;
    reg irq_r;
    reg mem_clk_r;
    reg mem_csb_r;
    reg mem_web_r;
    reg [7:0] mem_addr_r;
    reg [31:0] mem_din_r;
    reg bist_req_r;
    reg bist_running_r;
    reg bist_latch_done_r;
    reg bist_latch_fail_r;
    reg irq_latched_r;

    reg [7:0] control_reg;
    reg [7:0] mem_ctrl_reg;
    reg [7:0] bist_ctrl_reg;
    reg [7:0] mem_addr_reg;
    reg [31:0] mem_wdata_reg;
    reg [31:0] mem_rdata_reg;
    reg [7:0] bist_status_last_fail_addr_reg;
    reg [7:0] irq_status_reg;

    reg [31:0] read_mux;

    wire mem_write_req;
    wire mem_read_req;
    wire bist_start_req;
    wire clear_result_req;
    wire irq_clear_req;

    assign rd_data = rd_data_r;
    assign ready = ready_r;
    assign bist_done = bist_done_r;
    assign bist_fail = bist_fail_r;
    assign irq = irq_r;
    assign mem_clk = mem_clk_r;
    assign mem_csb = mem_csb_r;
    assign mem_web = mem_web_r;
    assign mem_addr = mem_addr_r;
    assign mem_din = mem_din_r;
    assign bist_req = bist_req_r;
    assign bist_running = bist_running_r;
    assign bist_latch_done = bist_latch_done_r;
    assign bist_latch_fail = bist_latch_fail_r;
    assign irq_latched = irq_latched_r;

    assign mem_write_req = mem_ctrl_reg[0];
    assign mem_read_req = mem_ctrl_reg[1];
    assign bist_start_req = bist_ctrl_reg[0];
    assign clear_result_req = bist_ctrl_reg[1];
    assign irq_clear_req = (wr_en && (wr_addr == 8'h24) && wr_data[0]);

    always @(*) begin
        read_mux = 32'h00000000;
        case (rd_addr)
            8'h00: read_mux = {29'h00000000, control_reg[2:0]};
            8'h04: read_mux = {28'h0000000, bist_running_r, bist_fail_r, bist_done_r, ready_r};
            8'h08: read_mux = {24'h000000, mem_addr_reg};
            8'h0C: read_mux = mem_wdata_reg;
            8'h10: read_mux = mem_rdata_reg;
            8'h14: read_mux = {30'h00000000, mem_read_req, mem_write_req};
            8'h18: read_mux = {30'h00000000, clear_result_req, bist_start_req};
            8'h1C: read_mux = {24'h000000, bist_status_last_fail_addr_reg, bist_running_r, bist_fail_r, bist_done_r};
            8'h20: read_mux = {30'h00000000, irq_status_reg[1], irq_status_reg[0]};
            8'h24: read_mux = 32'h00000000;
            default: read_mux = 32'h00000000;
        endcase
    end

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            rd_data_r <= 32'h00000000;
            ready_r <= 1'b0;
            bist_done_r <= 1'b0;
            bist_fail_r <= 1'b0;
            irq_r <= 1'b0;
            mem_clk_r <= 1'b0;
            mem_csb_r <= 1'b1;
            mem_web_r <= 1'b1;
            mem_addr_r <= 8'h00;
            mem_din_r <= 32'h00000000;
            bist_req_r <= 1'b0;
            bist_running_r <= 1'b0;
            bist_latch_done_r <= 1'b0;
            bist_latch_fail_r <= 1'b0;
            irq_latched_r <= 1'b0;
            control_reg <= 8'h00;
            mem_ctrl_reg <= 8'h00;
            bist_ctrl_reg <= 8'h00;
            mem_addr_reg <= 8'h00;
            mem_wdata_reg <= 32'h00000000;
            mem_rdata_reg <= 32'h00000000;
            bist_status_last_fail_addr_reg <= 8'h00;
            irq_status_reg <= 8'h00;
        end else begin
            mem_clk_r <= clk;
            if (wr_en) begin
                case (wr_addr)
                    8'h00: control_reg <= {5'b00000, wr_data[2:0]};
                    8'h08: mem_addr_reg <= wr_data[7:0];
                    8'h0C: mem_wdata_reg <= wr_data;
                    8'h14: mem_ctrl_reg <= {6'b000000, wr_data[1:0]};
                    8'h18: bist_ctrl_reg <= {6'b000000, wr_data[1:0]};
                    8'h24: begin
                        if (wr_data[0]) begin
                            irq_status_reg <= 8'h00;
                            irq_latched_r <= 1'b0;
                        end
                    end
                    default: begin
                    end
                endcase
            end

            if (control_reg[1]) begin
                control_reg[1] <= 1'b0;
            end

            if (clear_result_req) begin
                bist_done_r <= 1'b0;
                bist_fail_r <= 1'b0;
                bist_latch_done_r <= 1'b0;
                bist_latch_fail_r <= 1'b0;
                irq_status_reg <= 8'h00;
                irq_latched_r <= 1'b0;
            end

            if (bist_start || bist_start_req) begin
                bist_req_r <= 1'b1;
                bist_running_r <= 1'b1;
                bist_done_r <= 1'b0;
                bist_fail_r <= 1'b0;
            end else begin
                bist_req_r <= 1'b0;
            end

            if (bist_running_r) begin
                bist_running_r <= 1'b0;
                bist_done_r <= 1'b1;
                bist_latch_done_r <= 1'b1;
                irq_status_reg[0] <= 1'b1;
                irq_latched_r <= control_reg[2];
            end

            if (bist_done_r) begin
                bist_latch_done_r <= 1'b1;
            end

            if (bist_fail_r) begin
                bist_latch_fail_r <= 1'b1;
                irq_status_reg[1] <= 1'b1;
                irq_latched_r <= control_reg[2];
            end

            if (wr_en && (wr_addr == 8'h14) && wr_data[0] && control_reg[0]) begin
                mem_csb_r <= 1'b0;
                mem_web_r <= 1'b0;
                mem_addr_r <= mem_addr_reg;
                mem_din_r <= mem_wdata_reg;
            end else if (wr_en && (wr_addr == 8'h14) && wr_data[1] && control_reg[0]) begin
                mem_csb_r <= 1'b0;
                mem_web_r <= 1'b1;
                mem_addr_r <= mem_addr_reg;
                mem_din_r <= mem_wdata_reg;
                mem_rdata_reg <= mem_dout;
            end else begin
                mem_csb_r <= 1'b1;
                mem_web_r <= 1'b1;
            end

            if (rd_en) begin
                rd_data_r <= read_mux;
                if (rd_addr == 8'h10) begin
                    mem_rdata_reg <= mem_dout;
                end
            end else begin
                rd_data_r <= read_mux;
            end

            ready_r <= control_reg[0] & ~bist_running_r;
            bist_fail_r <= bist_fail_r;
            irq_r <= control_reg[2] & (irq_status_reg[0] | irq_status_reg[1]);
        end
    end
endmodule
