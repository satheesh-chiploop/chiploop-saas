# Digital Post-DFT Logic Equivalence Check

- Status: `inconclusive`
- Failure reason: `missing_synthesis_netlist`
- Top module: `sram_mbist_demo_controller`
- Synthesis netlist: `missing`
- Post-DFT netlist: `missing`
- Unproven points: `0`
