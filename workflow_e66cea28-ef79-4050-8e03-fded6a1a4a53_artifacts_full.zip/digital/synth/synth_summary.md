# Digital Synthesis Summary

- **Workflow**: e66cea28-ef79-4050-8e03-fded6a1a4a53
- **Status**: `failed` (rc=2)
- **Top module**: `sram_mbist_demo_controller`
- **Clock**: `clk` @ **9.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `not found`
- netlist candidates: 0 found
