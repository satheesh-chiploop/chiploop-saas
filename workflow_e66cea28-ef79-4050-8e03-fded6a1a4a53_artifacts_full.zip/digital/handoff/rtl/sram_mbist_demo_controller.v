module sram_mbist_demo_controller (
    input        clk,
    input        reset_n,
    input        wr_en,
    input  [7:0] wr_addr,
    input  [31:0] wr_data,
    input        rd_en,
    input  [7:0] rd_addr,
    input        bist_start,
    output reg [31:0] rd_data,
    output reg       ready,
    output reg       bist_done,
    output reg       bist_fail,
    output reg       irq
);

reg        control_enable;
reg        control_soft_reset;
reg        control_irq_enable;
reg [7:0]  mem_addr_reg;
reg [31:0] mem_wdata_reg;
reg [31:0] mem_rdata_reg;
reg        mem_write_req;
reg        mem_read_req;
reg        bist_control_start;
reg        bist_control_clear;
reg        irq_status_done;
reg        irq_status_fail;
reg        bist_running;
reg [7:0]  last_fail_addr;
reg [31:0] sram_dout_hold;
reg        sram_csb;
reg        sram_web;
reg [7:0]  sram_addr;
reg [31:0] sram_din;

wire [31:0] sram_dout;
wire [31:0] read_mux_data;
wire [31:0] status_word;
wire [31:0] bist_status_word;
wire [31:0] irq_status_word;
wire [31:0] control_word;
wire [31:0] mem_addr_word;
wire [31:0] mem_wdata_word;
wire [31:0] mem_rdata_word;
wire [31:0] mem_control_word;
wire [31:0] bist_control_word;
wire [31:0] irq_clear_word;

assign control_word     = {29'b0, control_irq_enable, control_soft_reset, control_enable};
assign status_word      = {28'b0, bist_running, bist_fail, bist_done, ready};
assign mem_addr_word    = {24'b0, mem_addr_reg};
assign mem_wdata_word   = mem_wdata_reg;
assign mem_rdata_word   = mem_rdata_reg;
assign mem_control_word = {30'b0, mem_read_req, mem_write_req};
assign bist_control_word = {30'b0, bist_control_clear, bist_control_start};
assign bist_status_word  = {16'b0, last_fail_addr, 5'b0, bist_running, bist_fail, bist_done};
assign irq_status_word   = {30'b0, irq_status_fail, irq_status_done};
assign irq_clear_word    = 32'b0;
assign read_mux_data = (rd_addr == 8'h00) ? control_word :
                       (rd_addr == 8'h04) ? status_word :
                       (rd_addr == 8'h08) ? mem_addr_word :
                       (rd_addr == 8'h0C) ? mem_wdata_word :
                       (rd_addr == 8'h10) ? mem_rdata_word :
                       (rd_addr == 8'h14) ? mem_control_word :
                       (rd_addr == 8'h18) ? bist_control_word :
                       (rd_addr == 8'h1C) ? bist_status_word :
                       (rd_addr == 8'h20) ? irq_status_word :
                       (rd_addr == 8'h24) ? irq_clear_word :
                       32'b0;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        control_enable    <= 1'b0;
        control_soft_reset <= 1'b0;
        control_irq_enable <= 1'b0;
        ready             <= 1'b0;
        bist_done         <= 1'b0;
        bist_fail         <= 1'b0;
        irq               <= 1'b0;
        mem_addr_reg      <= 8'b0;
        mem_wdata_reg     <= 32'b0;
        mem_rdata_reg     <= 32'b0;
        mem_write_req     <= 1'b0;
        mem_read_req      <= 1'b0;
        bist_control_start <= 1'b0;
        bist_control_clear <= 1'b0;
        irq_status_done   <= 1'b0;
        irq_status_fail   <= 1'b0;
        bist_running      <= 1'b0;
        last_fail_addr    <= 8'b0;
        sram_dout_hold    <= 32'b0;
        rd_data           <= 32'b0;
        sram_csb          <= 1'b1;
        sram_web          <= 1'b1;
        sram_addr         <= 8'b0;
        sram_din          <= 32'b0;
    end else begin
        ready <= control_enable;
        control_soft_reset <= 1'b0;
        mem_write_req <= 1'b0;
        mem_read_req <= 1'b0;
        bist_control_start <= 1'b0;
        bist_control_clear <= 1'b0;

        if (wr_en) begin
            case (wr_addr)
                8'h00: begin
                    control_enable     <= wr_data[0];
                    control_soft_reset <= wr_data[1];
                    control_irq_enable <= wr_data[2];
                end
                8'h08: begin
                    mem_addr_reg <= wr_data[7:0];
                end
                8'h0C: begin
                    mem_wdata_reg <= wr_data;
                end
                8'h14: begin
                    mem_write_req <= wr_data[0];
                    mem_read_req  <= wr_data[1];
                end
                8'h18: begin
                    bist_control_start <= wr_data[0] | bist_start;
                    bist_control_clear <= wr_data[1];
                end
                8'h20: begin
                    irq_status_done <= irq_status_done & ~wr_data[0];
                    irq_status_fail <= irq_status_fail & ~wr_data[1];
                end
                8'h24: begin
                    irq_status_done <= irq_status_done & ~wr_data[0];
                    irq_status_fail <= irq_status_fail & ~wr_data[1];
                end
                default: begin
                end
            endcase
        end else begin
            bist_control_start <= bist_start;
        end

        if (control_soft_reset || bist_control_clear) begin
            control_enable    <= 1'b0;
            control_irq_enable <= 1'b0;
            ready             <= 1'b0;
            bist_done         <= 1'b0;
            bist_fail         <= 1'b0;
            irq               <= 1'b0;
            mem_addr_reg      <= 8'b0;
            mem_wdata_reg     <= 32'b0;
            mem_rdata_reg     <= 32'b0;
            mem_write_req     <= 1'b0;
            mem_read_req      <= 1'b0;
            irq_status_done   <= 1'b0;
            irq_status_fail   <= 1'b0;
            bist_running      <= 1'b0;
            last_fail_addr    <= 8'b0;
            sram_dout_hold    <= 32'b0;
        end

        sram_csb <= 1'b1;
        sram_web <= 1'b1;
        sram_addr <= mem_addr_reg;
        sram_din <= mem_wdata_reg;

        if (control_enable && mem_write_req) begin
            sram_csb <= 1'b0;
            sram_web <= 1'b0;
            sram_addr <= mem_addr_reg;
            sram_din <= mem_wdata_reg;
        end else if (control_enable && mem_read_req) begin
            sram_csb <= 1'b0;
            sram_web <= 1'b1;
            sram_addr <= mem_addr_reg;
        end

        if (control_enable && mem_read_req) begin
            mem_rdata_reg <= sram_dout;
            sram_dout_hold <= sram_dout;
            rd_data <= sram_dout;
        end else if (rd_en) begin
            case (rd_addr)
                8'h00: rd_data <= control_word;
                8'h04: rd_data <= status_word;
                8'h08: rd_data <= mem_addr_word;
                8'h0C: rd_data <= mem_wdata_word;
                8'h10: rd_data <= mem_rdata_word;
                8'h14: rd_data <= mem_control_word;
                8'h18: rd_data <= bist_control_word;
                8'h1C: rd_data <= bist_status_word;
                8'h20: rd_data <= irq_status_word;
                8'h24: rd_data <= irq_clear_word;
                default: rd_data <= 32'b0;
            endcase
        end

        if (bist_control_start) begin
            bist_running <= 1'b1;
        end

        if (bist_running) begin
            bist_running <= 1'b0;
            bist_done <= 1'b1;
            bist_fail <= 1'b0;
            irq_status_done <= 1'b1;
            irq_status_fail <= 1'b0;
            last_fail_addr <= mem_addr_reg;
        end

        if (irq_status_done || irq_status_fail) begin
            irq <= control_irq_enable;
        end else begin
            irq <= 1'b0;
        end

        bist_done <= irq_status_done;
        bist_fail <= irq_status_fail;
    end
end

demo_sram_32x256_wrapper u_sram (
    .clk(clk),
    .csb(sram_csb),
    .web(sram_web),
    .addr(sram_addr),
    .din(sram_din),
    .dout(sram_dout)
);

endmodule
