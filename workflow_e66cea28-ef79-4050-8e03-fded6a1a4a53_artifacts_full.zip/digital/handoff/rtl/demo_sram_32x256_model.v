module demo_sram_32x256_model (
    input        clk,
    input        csb,
    input        web,
    input  [7:0] addr,
    input  [31:0] din,
    output reg [31:0] dout
);

reg [31:0] mem [0:255];
reg [31:0] read_data;

always @(posedge clk) begin
    if (!csb) begin
        if (!web) begin
            mem[addr] <= din;
        end
        read_data <= mem[addr];
        dout <= mem[addr];
    end
end

endmodule
