# Digital Post-DFT Logic Equivalence Check

- Status: `inconclusive`
- Failure reason: `missing_synthesis_netlist`
- Top module: `top`
- Synthesis netlist: `missing`
- Post-DFT netlist: `missing`
- Unproven points: `0`
