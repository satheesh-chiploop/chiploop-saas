# IP Packaging & Handoff Report

- Top: `PWM_Controller`
- Package: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/7356f8b1-4a0f-4de9-9fa3-d2d4c2513e4c/handoff/PWM_Controller_ip_package`
- Zip: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/7356f8b1-4a0f-4de9-9fa3-d2d4c2513e4c/handoff/PWM_Controller_ip_package.zip`

## Bucket counts
- **rtl**: 0
- **spec**: 1
- **arch**: 0
- **microarch**: 0
- **regmap**: 0
- **constraints**: 0
- **power_intent**: 0
- **verification**: 0
- **reports**: 0
- **other**: 3
