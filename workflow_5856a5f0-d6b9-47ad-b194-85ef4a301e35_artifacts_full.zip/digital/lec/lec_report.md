# Logic Equivalence Check

- Status: `incomplete_inputs`
- Tool: `yosys`
- Top module: `top`
- RTL files: `4`
- Synth netlist: `missing`
- Liberty files discovered: `1`
- Standard-cell Verilog models loaded: `1`
- Standard-cell model strategy: `pdk_stdcell_verilog`
- Missing standard-cell models: `0`
- Unproven points: `0`
- Return code: `None`
- Failure reason: `missing_synthesized_netlist`

If this is inconclusive, inspect `digital/lec/logs/yosys_lec.log` and `digital/lec/lec_summary.json` for unsupported cells, black boxes, or reset/initial-state assumptions.
