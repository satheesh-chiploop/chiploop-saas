/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/5856a5f0-d6b9-47ad-b194-85ef4a301e35/e6259456-fb72-4a88-aafb-7186176ee193/digital/system/imported_rtl/temp_sensor_adc_model.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/5856a5f0-d6b9-47ad-b194-85ef4a301e35/e6259456-fb72-4a88-aafb-7186176ee193/digital/system/imported_rtl/temp_monitor_digital.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/5856a5f0-d6b9-47ad-b194-85ef4a301e35/e6259456-fb72-4a88-aafb-7186176ee193/digital/system/imported_rtl/temp_monitor_soc_phys.sv
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/5856a5f0-d6b9-47ad-b194-85ef4a301e35/e6259456-fb72-4a88-aafb-7186176ee193/digital/system/imported_rtl/temp_monitor_soc_sim.sv
