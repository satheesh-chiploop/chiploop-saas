/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/3915d52f-9905-451b-8f7a-096a9d8c847b/bdc36276-6bf0-4c1e-a459-0d5989bd7510/digital/arch2synthesis/handoff/rtl/pwm_controller.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/3915d52f-9905-451b-8f7a-096a9d8c847b/bdc36276-6bf0-4c1e-a459-0d5989bd7510/digital/arch2synthesis/handoff/rtl/pwm_controller_regs.v
