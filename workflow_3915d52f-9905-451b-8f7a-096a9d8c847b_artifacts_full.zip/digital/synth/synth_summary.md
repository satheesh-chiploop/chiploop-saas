# Digital Synthesis Summary

- **Workflow**: 3915d52f-9905-451b-8f7a-096a9d8c847b
- **Status**: `ok` (rc=0)
- **Top module**: `pwm_controller`
- **Clock**: `clk` @ **10.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/3915d52f-9905-451b-8f7a-096a9d8c847b/bdc36276-6bf0-4c1e-a459-0d5989bd7510/digital/arch2synthesis/digital/synth/runs/Digital_Arch2Synthesis_3915d52f-9905-451b-8f7a-096a9d8c847b/final/metrics.json`
- netlist candidates: 1 found
