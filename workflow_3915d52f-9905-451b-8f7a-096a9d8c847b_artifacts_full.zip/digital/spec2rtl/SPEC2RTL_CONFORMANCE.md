# Spec-to-RTL Conformance Report

Status: **partial**

- Requirements checked: 42
- Matched: 41
- Partial: 1
- Missing: 0
- Inconclusive: 0
- Interface: pass
- Register map: pass
- Clock/reset: pass

## Missing Or Partial Requirements
- REQ-021 [partial]: Store and update CONTROL.ENABLE as a 1-bit semantic output.
