# IP Packaging & Handoff Report

- Top: `pwm_controller`
- Package: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/3915d52f-9905-451b-8f7a-096a9d8c847b/bdc36276-6bf0-4c1e-a459-0d5989bd7510/digital/arch2synthesis/handoff/pwm_controller_ip_package`
- Zip: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/3915d52f-9905-451b-8f7a-096a9d8c847b/bdc36276-6bf0-4c1e-a459-0d5989bd7510/digital/arch2synthesis/handoff/pwm_controller_ip_package.zip`

## Bucket counts
- **rtl**: 2
- **spec**: 1
- **arch**: 0
- **microarch**: 0
- **regmap**: 1
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 0
