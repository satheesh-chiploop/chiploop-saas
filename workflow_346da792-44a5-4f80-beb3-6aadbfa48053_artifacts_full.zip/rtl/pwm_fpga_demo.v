module pwm_fpga_demo (
    clk,
    led
);
    input clk;
    output led;

    reg [7:0] pwm_counter = 8'h00;
    reg [7:0] duty_cycle   = 8'h00;
    reg       direction    = 1'b1;
    reg [15:0] slow_counter = 16'h0000;

    assign led = (pwm_counter < duty_cycle);

    always @(posedge clk) begin
        pwm_counter <= pwm_counter + 8'h01;
        slow_counter <= slow_counter + 16'h01;

        if (slow_counter == 16'hFFFF) begin
            if (direction) begin
                if (duty_cycle == 8'hFF) begin
                    direction <= 1'b0;
                    duty_cycle <= 8'hFE;
                end else begin
                    duty_cycle <= duty_cycle + 8'h01;
                end
            end else begin
                if (duty_cycle == 8'h00) begin
                    direction <= 1'b1;
                    duty_cycle <= 8'h01;
                end else begin
                    duty_cycle <= duty_cycle - 8'h01;
                end
            end
        end
    end
endmodule
