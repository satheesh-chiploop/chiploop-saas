# Coverage Gap Analysis

- Functional coverage: unavailable / target 90.0%
- Code line coverage: unavailable / target 90.0%
- Code branch coverage: unavailable / target 80.0%
- Code condition coverage: unavailable / target 80.0%
- Code toggle coverage: unavailable / target 80.0%
- Gap count: 4
- Functional bin gaps: 0

## Functional Coverage Gaps

## Recommended Actions
- high: add_directed_tests - Coverage holes should first be mapped to explicit scenarios so closure is explainable.
- medium: increase_random_seeds - More seeds may close random-observable bins after directed gaps are handled.
- medium: review_coverage_model - Unreachable or incorrectly specified bins should be waived or corrected, not chased indefinitely.
