# Testcase And Seed Update

- Iteration: 1
- Testcase intents added: 4
- Executable tests for rerun: constrained_random_sanity
- Seeds: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10

## Testcase Intents
- `closure_cov_001_001` -> `constrained_random_sanity` (coverage_directed_intent)
- `closure_cov_001_002` -> `constrained_random_sanity` (code_coverage_intent)
- `closure_cov_001_003` -> `constrained_random_sanity` (code_coverage_intent)
- `closure_cov_001_004` -> `constrained_random_sanity` (code_coverage_intent)
