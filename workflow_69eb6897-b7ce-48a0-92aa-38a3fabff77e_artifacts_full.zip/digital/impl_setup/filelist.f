/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/69eb6897-b7ce-48a0-92aa-38a3fabff77e/e0736028-8fb0-4cbf-9daf-290e11e70d68/digital/system/imported_rtl/temp_sensor_adc_model.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/69eb6897-b7ce-48a0-92aa-38a3fabff77e/e0736028-8fb0-4cbf-9daf-290e11e70d68/digital/system/imported_rtl/temp_monitor_control.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/69eb6897-b7ce-48a0-92aa-38a3fabff77e/e0736028-8fb0-4cbf-9daf-290e11e70d68/digital/system/imported_rtl/temp_monitor_digital.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/69eb6897-b7ce-48a0-92aa-38a3fabff77e/e0736028-8fb0-4cbf-9daf-290e11e70d68/digital/system/imported_rtl/temp_monitor_registers.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/69eb6897-b7ce-48a0-92aa-38a3fabff77e/e0736028-8fb0-4cbf-9daf-290e11e70d68/digital/system/imported_rtl/temp_monitor_soc_phys.sv
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/69eb6897-b7ce-48a0-92aa-38a3fabff77e/e0736028-8fb0-4cbf-9daf-290e11e70d68/digital/system/imported_rtl/temp_monitor_soc_sim.sv
