module temp_monitor_soc_phys (alert_irq,
    alert_status,
    avdd,
    avss,
    clk,
    rd_en,
    reset_n,
    scan_en,
    wr_en,
    rd_addr,
    rd_data,
    scan_in,
    scan_out,
    sensor_temp_celsius,
    temp_code,
    threshold_code,
    wr_addr,
    wr_data);
 output alert_irq;
 output alert_status;
 input avdd;
 input avss;
 input clk;
 input rd_en;
 input reset_n;
 input scan_en;
 input wr_en;
 input [7:0] rd_addr;
 output [15:0] rd_data;
 input [3:0] scan_in;
 output [3:0] scan_out;
 input [15:0] sensor_temp_celsius;
 output [11:0] temp_code;
 output [11:0] threshold_code;
 input [7:0] wr_addr;
 input [15:0] wr_data;

 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire _086_;
 wire _087_;
 wire _088_;
 wire _089_;
 wire _090_;
 wire _091_;
 wire _092_;
 wire _093_;
 wire _094_;
 wire _095_;
 wire _096_;
 wire _097_;
 wire _098_;
 wire _099_;
 wire _100_;
 wire _101_;
 wire _102_;
 wire _103_;
 wire _104_;
 wire _105_;
 wire _106_;
 wire _107_;
 wire _108_;
 wire _109_;
 wire _110_;
 wire _111_;
 wire _112_;
 wire _113_;
 wire _114_;
 wire _115_;
 wire _116_;
 wire _117_;
 wire _118_;
 wire _119_;
 wire _120_;
 wire _121_;
 wire _122_;
 wire _123_;
 wire _124_;
 wire _125_;
 wire _126_;
 wire _127_;
 wire _128_;
 wire _129_;
 wire _130_;
 wire _131_;
 wire _132_;
 wire _133_;
 wire _134_;
 wire _135_;
 wire _136_;
 wire _137_;
 wire _138_;
 wire _139_;
 wire _140_;
 wire _141_;
 wire _142_;
 wire _143_;
 wire _144_;
 wire _145_;
 wire _146_;
 wire _147_;
 wire _148_;
 wire _149_;
 wire _150_;
 wire _151_;
 wire _152_;
 wire _153_;
 wire _154_;
 wire _155_;
 wire _156_;
 wire _157_;
 wire _158_;
 wire _159_;
 wire _160_;
 wire _161_;
 wire _162_;
 wire _163_;
 wire _164_;
 wire _165_;
 wire _166_;
 wire _167_;
 wire _168_;
 wire _169_;
 wire _170_;
 wire _171_;
 wire _172_;
 wire _173_;
 wire _174_;
 wire _175_;
 wire _176_;
 wire _177_;
 wire _178_;
 wire _179_;
 wire _180_;
 wire _181_;
 wire _182_;
 wire _183_;
 wire _184_;
 wire _185_;
 wire _186_;
 wire _187_;
 wire _188_;
 wire _189_;
 wire _190_;
 wire _191_;
 wire _192_;
 wire _193_;
 wire _194_;
 wire _195_;
 wire _196_;
 wire _197_;
 wire _198_;
 wire _199_;
 wire _200_;
 wire _201_;
 wire _202_;
 wire _203_;
 wire _204_;
 wire _205_;
 wire _206_;
 wire _207_;
 wire _208_;
 wire _209_;
 wire _210_;
 wire _211_;
 wire _212_;
 wire _213_;
 wire _214_;
 wire _215_;
 wire _216_;
 wire _217_;
 wire _218_;
 wire _219_;
 wire _220_;
 wire _221_;
 wire _222_;
 wire _223_;
 wire _224_;
 wire _225_;
 wire _226_;
 wire _227_;
 wire _228_;
 wire _229_;
 wire _230_;
 wire _231_;
 wire _232_;
 wire _233_;
 wire _234_;
 wire _235_;
 wire _236_;
 wire _237_;
 wire _238_;
 wire _239_;
 wire _240_;
 wire _241_;
 wire _242_;
 wire _243_;
 wire _244_;
 wire _245_;
 wire _246_;
 wire _247_;
 wire _248_;
 wire _249_;
 wire _250_;
 wire _251_;
 wire _252_;
 wire _253_;
 wire _254_;
 wire _255_;
 wire _256_;
 wire _257_;
 wire _258_;
 wire _259_;
 wire _260_;
 wire _261_;
 wire _262_;
 wire _263_;
 wire _264_;
 wire _265_;
 wire _266_;
 wire _267_;
 wire _268_;
 wire _269_;
 wire \u_digital.adc_code[0] ;
 wire \u_digital.adc_code[10] ;
 wire \u_digital.adc_code[11] ;
 wire \u_digital.adc_code[1] ;
 wire \u_digital.adc_code[2] ;
 wire \u_digital.adc_code[3] ;
 wire \u_digital.adc_code[4] ;
 wire \u_digital.adc_code[5] ;
 wire \u_digital.adc_code[6] ;
 wire \u_digital.adc_code[7] ;
 wire \u_digital.adc_code[8] ;
 wire \u_digital.adc_code[9] ;
 wire \u_digital.adc_valid ;
 wire \u_digital.sample_req ;
 wire \u_digital.temp_monitor_control_adc_valid_seen_o ;
 wire \u_digital.temp_monitor_control_alert_clear_pulse_i ;
 wire \u_digital.temp_monitor_control_busy_o ;
 wire \u_digital.temp_monitor_control_enable_i ;
 wire \u_digital.temp_monitor_control_irq_clear_alert_pulse_i ;
 wire \u_digital.temp_monitor_control_irq_clear_sample_done_pulse_i ;
 wire \u_digital.temp_monitor_control_irq_enable_i ;
 wire \u_digital.temp_monitor_control_irq_status_sample_done_o ;
 wire \u_digital.temp_monitor_control_sample_count_o[0] ;
 wire \u_digital.temp_monitor_control_sample_count_o[10] ;
 wire \u_digital.temp_monitor_control_sample_count_o[11] ;
 wire \u_digital.temp_monitor_control_sample_count_o[12] ;
 wire \u_digital.temp_monitor_control_sample_count_o[13] ;
 wire \u_digital.temp_monitor_control_sample_count_o[14] ;
 wire \u_digital.temp_monitor_control_sample_count_o[15] ;
 wire \u_digital.temp_monitor_control_sample_count_o[1] ;
 wire \u_digital.temp_monitor_control_sample_count_o[2] ;
 wire \u_digital.temp_monitor_control_sample_count_o[3] ;
 wire \u_digital.temp_monitor_control_sample_count_o[4] ;
 wire \u_digital.temp_monitor_control_sample_count_o[5] ;
 wire \u_digital.temp_monitor_control_sample_count_o[6] ;
 wire \u_digital.temp_monitor_control_sample_count_o[7] ;
 wire \u_digital.temp_monitor_control_sample_count_o[8] ;
 wire \u_digital.temp_monitor_control_sample_count_o[9] ;
 wire \u_digital.temp_monitor_control_sample_start_pulse_i ;
 wire \u_digital.temp_monitor_control_status_alert_pending_o ;
 wire \u_digital.u_temp_monitor_control.filtered_code[0] ;
 wire \u_digital.u_temp_monitor_control.filtered_code[10] ;
 wire \u_digital.u_temp_monitor_control.filtered_code[11] ;
 wire \u_digital.u_temp_monitor_control.filtered_code[1] ;
 wire \u_digital.u_temp_monitor_control.filtered_code[2] ;
 wire \u_digital.u_temp_monitor_control.filtered_code[3] ;
 wire \u_digital.u_temp_monitor_control.filtered_code[4] ;
 wire \u_digital.u_temp_monitor_control.filtered_code[5] ;
 wire \u_digital.u_temp_monitor_control.filtered_code[6] ;
 wire \u_digital.u_temp_monitor_control.filtered_code[7] ;
 wire \u_digital.u_temp_monitor_control.filtered_code[8] ;
 wire \u_digital.u_temp_monitor_control.filtered_code[9] ;
 wire \u_digital.u_temp_monitor_control.prev_adc_code[0] ;
 wire \u_digital.u_temp_monitor_control.prev_adc_code[10] ;
 wire \u_digital.u_temp_monitor_control.prev_adc_code[11] ;
 wire \u_digital.u_temp_monitor_control.prev_adc_code[1] ;
 wire \u_digital.u_temp_monitor_control.prev_adc_code[2] ;
 wire \u_digital.u_temp_monitor_control.prev_adc_code[3] ;
 wire \u_digital.u_temp_monitor_control.prev_adc_code[4] ;
 wire \u_digital.u_temp_monitor_control.prev_adc_code[5] ;
 wire \u_digital.u_temp_monitor_control.prev_adc_code[6] ;
 wire \u_digital.u_temp_monitor_control.prev_adc_code[7] ;
 wire \u_digital.u_temp_monitor_control.prev_adc_code[8] ;
 wire \u_digital.u_temp_monitor_control.prev_adc_code[9] ;
 wire \u_digital.u_temp_monitor_registers.control_reg[0] ;
 wire \u_digital.u_temp_monitor_registers.control_reg[2] ;
 wire \u_digital.u_temp_monitor_registers.status_reg[0] ;
 wire \u_digital.u_temp_monitor_registers.status_reg[1] ;
 wire \u_digital.u_temp_monitor_registers.status_reg[2] ;
 wire \u_digital.u_temp_monitor_registers.status_reg[3] ;
 wire \u_digital.u_temp_monitor_registers.threshold_reg[0] ;
 wire \u_digital.u_temp_monitor_registers.threshold_reg[10] ;
 wire \u_digital.u_temp_monitor_registers.threshold_reg[11] ;
 wire \u_digital.u_temp_monitor_registers.threshold_reg[1] ;
 wire \u_digital.u_temp_monitor_registers.threshold_reg[2] ;
 wire \u_digital.u_temp_monitor_registers.threshold_reg[3] ;
 wire \u_digital.u_temp_monitor_registers.threshold_reg[4] ;
 wire \u_digital.u_temp_monitor_registers.threshold_reg[5] ;
 wire \u_digital.u_temp_monitor_registers.threshold_reg[6] ;
 wire \u_digital.u_temp_monitor_registers.threshold_reg[7] ;
 wire \u_digital.u_temp_monitor_registers.threshold_reg[8] ;
 wire \u_digital.u_temp_monitor_registers.threshold_reg[9] ;

 sky130_fd_sc_hd__inv_2 _270_ (.A(\u_digital.adc_valid ),
    .Y(_093_));
 sky130_fd_sc_hd__inv_2 _271_ (.A(\u_digital.u_temp_monitor_control.filtered_code[9] ),
    .Y(_094_));
 sky130_fd_sc_hd__inv_2 _272_ (.A(threshold_code[8]),
    .Y(_095_));
 sky130_fd_sc_hd__inv_2 _273_ (.A(threshold_code[7]),
    .Y(_096_));
 sky130_fd_sc_hd__inv_2 _274_ (.A(threshold_code[6]),
    .Y(_097_));
 sky130_fd_sc_hd__inv_2 _275_ (.A(\u_digital.u_temp_monitor_control.filtered_code[5] ),
    .Y(_098_));
 sky130_fd_sc_hd__inv_2 _276_ (.A(\u_digital.u_temp_monitor_control.filtered_code[4] ),
    .Y(_099_));
 sky130_fd_sc_hd__inv_2 _277_ (.A(threshold_code[1]),
    .Y(_100_));
 sky130_fd_sc_hd__inv_2 _278_ (.A(\u_digital.u_temp_monitor_control.filtered_code[0] ),
    .Y(_101_));
 sky130_fd_sc_hd__inv_2 _279_ (.A(\u_digital.temp_monitor_control_busy_o ),
    .Y(_102_));
 sky130_fd_sc_hd__inv_2 _280_ (.A(wr_addr[3]),
    .Y(_103_));
 sky130_fd_sc_hd__inv_2 _281_ (.A(\u_digital.adc_code[1] ),
    .Y(_104_));
 sky130_fd_sc_hd__inv_2 _282_ (.A(rd_en),
    .Y(_105_));
 sky130_fd_sc_hd__o21a_2 _283_ (.A1(\u_digital.temp_monitor_control_irq_status_sample_done_o ),
    .A2(alert_status),
    .B1(\u_digital.temp_monitor_control_irq_enable_i ),
    .X(_000_));
 sky130_fd_sc_hd__a21o_2 _284_ (.A1(\u_digital.temp_monitor_control_enable_i ),
    .A2(_102_),
    .B1(\u_digital.temp_monitor_control_sample_start_pulse_i ),
    .X(_001_));
 sky130_fd_sc_hd__nor3_2 _285_ (.A(wr_addr[5]),
    .B(wr_addr[7]),
    .C(wr_addr[6]),
    .Y(_106_));
 sky130_fd_sc_hd__or4b_2 _286_ (.A(wr_addr[1]),
    .B(wr_addr[0]),
    .C(wr_addr[2]),
    .D_N(wr_en),
    .X(_107_));
 sky130_fd_sc_hd__nor2_2 _287_ (.A(_103_),
    .B(_107_),
    .Y(_108_));
 sky130_fd_sc_hd__and4_2 _288_ (.A(wr_addr[4]),
    .B(wr_data[1]),
    .C(_106_),
    .D(_108_),
    .X(_005_));
 sky130_fd_sc_hd__and4_2 _289_ (.A(wr_addr[4]),
    .B(wr_data[0]),
    .C(_106_),
    .D(_108_),
    .X(_004_));
 sky130_fd_sc_hd__and4bb_2 _290_ (.A_N(_107_),
    .B_N(wr_addr[4]),
    .C(_103_),
    .D(_106_),
    .X(_109_));
 sky130_fd_sc_hd__and2_2 _291_ (.A(wr_data[3]),
    .B(_109_),
    .X(_002_));
 sky130_fd_sc_hd__and2_2 _292_ (.A(wr_data[1]),
    .B(_109_),
    .X(_003_));
 sky130_fd_sc_hd__or2_2 _293_ (.A(\u_digital.adc_valid ),
    .B(\u_digital.temp_monitor_control_adc_valid_seen_o ),
    .X(_006_));
 sky130_fd_sc_hd__a2bb2o_2 _294_ (.A1_N(_097_),
    .A2_N(\u_digital.u_temp_monitor_control.filtered_code[6] ),
    .B1(threshold_code[5]),
    .B2(_098_),
    .X(_110_));
 sky130_fd_sc_hd__o22a_2 _295_ (.A1(threshold_code[5]),
    .A2(_098_),
    .B1(_099_),
    .B2(threshold_code[4]),
    .X(_111_));
 sky130_fd_sc_hd__and2_2 _296_ (.A(_099_),
    .B(threshold_code[4]),
    .X(_112_));
 sky130_fd_sc_hd__nand2b_2 _297_ (.A_N(\u_digital.u_temp_monitor_control.filtered_code[3] ),
    .B(threshold_code[3]),
    .Y(_113_));
 sky130_fd_sc_hd__xnor2_2 _298_ (.A(threshold_code[2]),
    .B(\u_digital.u_temp_monitor_control.filtered_code[2] ),
    .Y(_114_));
 sky130_fd_sc_hd__and2_2 _299_ (.A(_100_),
    .B(\u_digital.u_temp_monitor_control.filtered_code[1] ),
    .X(_115_));
 sky130_fd_sc_hd__o2bb2a_2 _300_ (.A1_N(_101_),
    .A2_N(threshold_code[0]),
    .B1(_100_),
    .B2(\u_digital.u_temp_monitor_control.filtered_code[1] ),
    .X(_116_));
 sky130_fd_sc_hd__o211ai_2 _301_ (.A1(_115_),
    .A2(_116_),
    .B1(_113_),
    .C1(_114_),
    .Y(_117_));
 sky130_fd_sc_hd__nand2b_2 _302_ (.A_N(threshold_code[3]),
    .B(\u_digital.u_temp_monitor_control.filtered_code[3] ),
    .Y(_118_));
 sky130_fd_sc_hd__nand3b_2 _303_ (.A_N(threshold_code[2]),
    .B(\u_digital.u_temp_monitor_control.filtered_code[2] ),
    .C(_113_),
    .Y(_119_));
 sky130_fd_sc_hd__a31o_2 _304_ (.A1(_117_),
    .A2(_118_),
    .A3(_119_),
    .B1(_112_),
    .X(_120_));
 sky130_fd_sc_hd__a21oi_2 _305_ (.A1(_111_),
    .A2(_120_),
    .B1(_110_),
    .Y(_121_));
 sky130_fd_sc_hd__a2bb2o_2 _306_ (.A1_N(threshold_code[9]),
    .A2_N(_094_),
    .B1(\u_digital.u_temp_monitor_control.filtered_code[8] ),
    .B2(_095_),
    .X(_122_));
 sky130_fd_sc_hd__a221o_2 _307_ (.A1(_096_),
    .A2(\u_digital.u_temp_monitor_control.filtered_code[7] ),
    .B1(_097_),
    .B2(\u_digital.u_temp_monitor_control.filtered_code[6] ),
    .C1(_122_),
    .X(_123_));
 sky130_fd_sc_hd__and2b_2 _308_ (.A_N(threshold_code[11]),
    .B(\u_digital.u_temp_monitor_control.filtered_code[11] ),
    .X(_124_));
 sky130_fd_sc_hd__and2b_2 _309_ (.A_N(\u_digital.u_temp_monitor_control.filtered_code[11] ),
    .B(threshold_code[11]),
    .X(_125_));
 sky130_fd_sc_hd__xor2_2 _310_ (.A(threshold_code[10]),
    .B(\u_digital.u_temp_monitor_control.filtered_code[10] ),
    .X(_126_));
 sky130_fd_sc_hd__a2111oi_2 _311_ (.A1(threshold_code[9]),
    .A2(_094_),
    .B1(_124_),
    .C1(_125_),
    .D1(_126_),
    .Y(_127_));
 sky130_fd_sc_hd__a2111o_2 _312_ (.A1(threshold_code[9]),
    .A2(_094_),
    .B1(_124_),
    .C1(_125_),
    .D1(_126_),
    .X(_128_));
 sky130_fd_sc_hd__o22a_2 _313_ (.A1(\u_digital.u_temp_monitor_control.filtered_code[8] ),
    .A2(_095_),
    .B1(_096_),
    .B2(\u_digital.u_temp_monitor_control.filtered_code[7] ),
    .X(_129_));
 sky130_fd_sc_hd__o221a_2 _314_ (.A1(_121_),
    .A2(_123_),
    .B1(_129_),
    .B2(_122_),
    .C1(_127_),
    .X(_130_));
 sky130_fd_sc_hd__nor3b_2 _315_ (.A(threshold_code[10]),
    .B(_125_),
    .C_N(\u_digital.u_temp_monitor_control.filtered_code[10] ),
    .Y(_131_));
 sky130_fd_sc_hd__nor2_2 _316_ (.A(_112_),
    .B(_115_),
    .Y(_132_));
 sky130_fd_sc_hd__o211a_2 _317_ (.A1(_101_),
    .A2(threshold_code[0]),
    .B1(_118_),
    .C1(_132_),
    .X(_133_));
 sky130_fd_sc_hd__nand4b_2 _318_ (.A_N(_123_),
    .B(_113_),
    .C(_114_),
    .D(_133_),
    .Y(_134_));
 sky130_fd_sc_hd__and4b_2 _319_ (.A_N(_110_),
    .B(_111_),
    .C(_116_),
    .D(_129_),
    .X(_135_));
 sky130_fd_sc_hd__or3b_2 _320_ (.A(_128_),
    .B(_134_),
    .C_N(_135_),
    .X(_136_));
 sky130_fd_sc_hd__o311a_2 _321_ (.A1(_124_),
    .A2(_130_),
    .A3(_131_),
    .B1(_136_),
    .C1(\u_digital.adc_valid ),
    .X(_137_));
 sky130_fd_sc_hd__nor2_2 _322_ (.A(\u_digital.temp_monitor_control_alert_clear_pulse_i ),
    .B(\u_digital.temp_monitor_control_irq_clear_alert_pulse_i ),
    .Y(_138_));
 sky130_fd_sc_hd__o21a_2 _323_ (.A1(alert_status),
    .A2(_137_),
    .B1(_138_),
    .X(_007_));
 sky130_fd_sc_hd__mux2_1 _324_ (.A0(\u_digital.u_temp_monitor_control.prev_adc_code[0] ),
    .A1(\u_digital.adc_code[0] ),
    .S(\u_digital.adc_valid ),
    .X(_008_));
 sky130_fd_sc_hd__mux2_1 _325_ (.A0(\u_digital.u_temp_monitor_control.prev_adc_code[1] ),
    .A1(\u_digital.adc_code[1] ),
    .S(\u_digital.adc_valid ),
    .X(_009_));
 sky130_fd_sc_hd__mux2_1 _326_ (.A0(\u_digital.u_temp_monitor_control.prev_adc_code[2] ),
    .A1(\u_digital.adc_code[2] ),
    .S(\u_digital.adc_valid ),
    .X(_010_));
 sky130_fd_sc_hd__mux2_1 _327_ (.A0(\u_digital.u_temp_monitor_control.prev_adc_code[3] ),
    .A1(\u_digital.adc_code[3] ),
    .S(\u_digital.adc_valid ),
    .X(_011_));
 sky130_fd_sc_hd__mux2_1 _328_ (.A0(\u_digital.u_temp_monitor_control.prev_adc_code[4] ),
    .A1(\u_digital.adc_code[4] ),
    .S(\u_digital.adc_valid ),
    .X(_012_));
 sky130_fd_sc_hd__mux2_1 _329_ (.A0(\u_digital.u_temp_monitor_control.prev_adc_code[5] ),
    .A1(\u_digital.adc_code[5] ),
    .S(\u_digital.adc_valid ),
    .X(_013_));
 sky130_fd_sc_hd__mux2_1 _330_ (.A0(\u_digital.u_temp_monitor_control.prev_adc_code[6] ),
    .A1(\u_digital.adc_code[6] ),
    .S(\u_digital.adc_valid ),
    .X(_014_));
 sky130_fd_sc_hd__mux2_1 _331_ (.A0(\u_digital.u_temp_monitor_control.prev_adc_code[7] ),
    .A1(\u_digital.adc_code[7] ),
    .S(\u_digital.adc_valid ),
    .X(_015_));
 sky130_fd_sc_hd__mux2_1 _332_ (.A0(\u_digital.u_temp_monitor_control.prev_adc_code[8] ),
    .A1(\u_digital.adc_code[8] ),
    .S(\u_digital.adc_valid ),
    .X(_016_));
 sky130_fd_sc_hd__mux2_1 _333_ (.A0(\u_digital.u_temp_monitor_control.prev_adc_code[9] ),
    .A1(\u_digital.adc_code[9] ),
    .S(\u_digital.adc_valid ),
    .X(_017_));
 sky130_fd_sc_hd__mux2_1 _334_ (.A0(\u_digital.u_temp_monitor_control.prev_adc_code[10] ),
    .A1(\u_digital.adc_code[10] ),
    .S(\u_digital.adc_valid ),
    .X(_018_));
 sky130_fd_sc_hd__nand2_2 _335_ (.A(\u_digital.adc_valid ),
    .B(\u_digital.adc_code[11] ),
    .Y(_139_));
 sky130_fd_sc_hd__a21bo_2 _336_ (.A1(_093_),
    .A2(\u_digital.u_temp_monitor_control.prev_adc_code[11] ),
    .B1_N(_139_),
    .X(_019_));
 sky130_fd_sc_hd__o21ba_2 _337_ (.A1(\u_digital.adc_valid ),
    .A2(\u_digital.temp_monitor_control_irq_status_sample_done_o ),
    .B1_N(\u_digital.temp_monitor_control_irq_clear_sample_done_pulse_i ),
    .X(_020_));
 sky130_fd_sc_hd__o21ba_2 _338_ (.A1(\u_digital.temp_monitor_control_status_alert_pending_o ),
    .A2(_137_),
    .B1_N(\u_digital.temp_monitor_control_alert_clear_pulse_i ),
    .X(_021_));
 sky130_fd_sc_hd__mux2_1 _339_ (.A0(temp_code[0]),
    .A1(\u_digital.u_temp_monitor_control.filtered_code[0] ),
    .S(\u_digital.adc_valid ),
    .X(_022_));
 sky130_fd_sc_hd__mux2_1 _340_ (.A0(temp_code[1]),
    .A1(\u_digital.u_temp_monitor_control.filtered_code[1] ),
    .S(\u_digital.adc_valid ),
    .X(_023_));
 sky130_fd_sc_hd__mux2_1 _341_ (.A0(temp_code[2]),
    .A1(\u_digital.u_temp_monitor_control.filtered_code[2] ),
    .S(\u_digital.adc_valid ),
    .X(_024_));
 sky130_fd_sc_hd__mux2_1 _342_ (.A0(temp_code[3]),
    .A1(\u_digital.u_temp_monitor_control.filtered_code[3] ),
    .S(\u_digital.adc_valid ),
    .X(_025_));
 sky130_fd_sc_hd__mux2_1 _343_ (.A0(temp_code[4]),
    .A1(\u_digital.u_temp_monitor_control.filtered_code[4] ),
    .S(\u_digital.adc_valid ),
    .X(_026_));
 sky130_fd_sc_hd__mux2_1 _344_ (.A0(temp_code[5]),
    .A1(\u_digital.u_temp_monitor_control.filtered_code[5] ),
    .S(\u_digital.adc_valid ),
    .X(_027_));
 sky130_fd_sc_hd__mux2_1 _345_ (.A0(temp_code[6]),
    .A1(\u_digital.u_temp_monitor_control.filtered_code[6] ),
    .S(\u_digital.adc_valid ),
    .X(_028_));
 sky130_fd_sc_hd__mux2_1 _346_ (.A0(temp_code[7]),
    .A1(\u_digital.u_temp_monitor_control.filtered_code[7] ),
    .S(\u_digital.adc_valid ),
    .X(_029_));
 sky130_fd_sc_hd__mux2_1 _347_ (.A0(temp_code[8]),
    .A1(\u_digital.u_temp_monitor_control.filtered_code[8] ),
    .S(\u_digital.adc_valid ),
    .X(_030_));
 sky130_fd_sc_hd__mux2_1 _348_ (.A0(temp_code[9]),
    .A1(\u_digital.u_temp_monitor_control.filtered_code[9] ),
    .S(\u_digital.adc_valid ),
    .X(_031_));
 sky130_fd_sc_hd__mux2_1 _349_ (.A0(temp_code[10]),
    .A1(\u_digital.u_temp_monitor_control.filtered_code[10] ),
    .S(\u_digital.adc_valid ),
    .X(_032_));
 sky130_fd_sc_hd__mux2_1 _350_ (.A0(temp_code[11]),
    .A1(\u_digital.u_temp_monitor_control.filtered_code[11] ),
    .S(\u_digital.adc_valid ),
    .X(_033_));
 sky130_fd_sc_hd__xor2_2 _351_ (.A(\u_digital.adc_valid ),
    .B(\u_digital.temp_monitor_control_sample_count_o[0] ),
    .X(_034_));
 sky130_fd_sc_hd__and3_2 _352_ (.A(\u_digital.adc_valid ),
    .B(\u_digital.temp_monitor_control_sample_count_o[0] ),
    .C(\u_digital.temp_monitor_control_sample_count_o[1] ),
    .X(_140_));
 sky130_fd_sc_hd__a21oi_2 _353_ (.A1(\u_digital.adc_valid ),
    .A2(\u_digital.temp_monitor_control_sample_count_o[0] ),
    .B1(\u_digital.temp_monitor_control_sample_count_o[1] ),
    .Y(_141_));
 sky130_fd_sc_hd__nor2_2 _354_ (.A(_140_),
    .B(_141_),
    .Y(_035_));
 sky130_fd_sc_hd__and4_2 _355_ (.A(\u_digital.adc_valid ),
    .B(\u_digital.temp_monitor_control_sample_count_o[0] ),
    .C(\u_digital.temp_monitor_control_sample_count_o[1] ),
    .D(\u_digital.temp_monitor_control_sample_count_o[2] ),
    .X(_142_));
 sky130_fd_sc_hd__nor2_2 _356_ (.A(\u_digital.temp_monitor_control_sample_count_o[2] ),
    .B(_140_),
    .Y(_143_));
 sky130_fd_sc_hd__nor2_2 _357_ (.A(_142_),
    .B(_143_),
    .Y(_036_));
 sky130_fd_sc_hd__nand2_2 _358_ (.A(\u_digital.temp_monitor_control_sample_count_o[3] ),
    .B(_142_),
    .Y(_144_));
 sky130_fd_sc_hd__or2_2 _359_ (.A(\u_digital.temp_monitor_control_sample_count_o[3] ),
    .B(_142_),
    .X(_145_));
 sky130_fd_sc_hd__and2_2 _360_ (.A(_144_),
    .B(_145_),
    .X(_037_));
 sky130_fd_sc_hd__xnor2_2 _361_ (.A(\u_digital.temp_monitor_control_sample_count_o[4] ),
    .B(_144_),
    .Y(_038_));
 sky130_fd_sc_hd__and4_2 _362_ (.A(\u_digital.temp_monitor_control_sample_count_o[3] ),
    .B(\u_digital.temp_monitor_control_sample_count_o[4] ),
    .C(\u_digital.temp_monitor_control_sample_count_o[5] ),
    .D(_142_),
    .X(_146_));
 sky130_fd_sc_hd__a31o_2 _363_ (.A1(\u_digital.temp_monitor_control_sample_count_o[3] ),
    .A2(\u_digital.temp_monitor_control_sample_count_o[4] ),
    .A3(_142_),
    .B1(\u_digital.temp_monitor_control_sample_count_o[5] ),
    .X(_147_));
 sky130_fd_sc_hd__and2b_2 _364_ (.A_N(_146_),
    .B(_147_),
    .X(_039_));
 sky130_fd_sc_hd__xor2_2 _365_ (.A(\u_digital.temp_monitor_control_sample_count_o[6] ),
    .B(_146_),
    .X(_040_));
 sky130_fd_sc_hd__and3_2 _366_ (.A(\u_digital.temp_monitor_control_sample_count_o[6] ),
    .B(\u_digital.temp_monitor_control_sample_count_o[7] ),
    .C(_146_),
    .X(_148_));
 sky130_fd_sc_hd__a21oi_2 _367_ (.A1(\u_digital.temp_monitor_control_sample_count_o[6] ),
    .A2(_146_),
    .B1(\u_digital.temp_monitor_control_sample_count_o[7] ),
    .Y(_149_));
 sky130_fd_sc_hd__nor2_2 _368_ (.A(_148_),
    .B(_149_),
    .Y(_041_));
 sky130_fd_sc_hd__and2_2 _369_ (.A(\u_digital.temp_monitor_control_sample_count_o[8] ),
    .B(_148_),
    .X(_150_));
 sky130_fd_sc_hd__nor2_2 _370_ (.A(\u_digital.temp_monitor_control_sample_count_o[8] ),
    .B(_148_),
    .Y(_151_));
 sky130_fd_sc_hd__nor2_2 _371_ (.A(_150_),
    .B(_151_),
    .Y(_042_));
 sky130_fd_sc_hd__xor2_2 _372_ (.A(\u_digital.temp_monitor_control_sample_count_o[9] ),
    .B(_150_),
    .X(_043_));
 sky130_fd_sc_hd__and3_2 _373_ (.A(\u_digital.temp_monitor_control_sample_count_o[9] ),
    .B(\u_digital.temp_monitor_control_sample_count_o[10] ),
    .C(_150_),
    .X(_152_));
 sky130_fd_sc_hd__a21oi_2 _374_ (.A1(\u_digital.temp_monitor_control_sample_count_o[9] ),
    .A2(_150_),
    .B1(\u_digital.temp_monitor_control_sample_count_o[10] ),
    .Y(_153_));
 sky130_fd_sc_hd__nor2_2 _375_ (.A(_152_),
    .B(_153_),
    .Y(_044_));
 sky130_fd_sc_hd__and2_2 _376_ (.A(\u_digital.temp_monitor_control_sample_count_o[11] ),
    .B(_152_),
    .X(_154_));
 sky130_fd_sc_hd__nor2_2 _377_ (.A(\u_digital.temp_monitor_control_sample_count_o[11] ),
    .B(_152_),
    .Y(_155_));
 sky130_fd_sc_hd__nor2_2 _378_ (.A(_154_),
    .B(_155_),
    .Y(_045_));
 sky130_fd_sc_hd__xor2_2 _379_ (.A(\u_digital.temp_monitor_control_sample_count_o[12] ),
    .B(_154_),
    .X(_046_));
 sky130_fd_sc_hd__and3_2 _380_ (.A(\u_digital.temp_monitor_control_sample_count_o[12] ),
    .B(\u_digital.temp_monitor_control_sample_count_o[13] ),
    .C(_154_),
    .X(_156_));
 sky130_fd_sc_hd__a31o_2 _381_ (.A1(\u_digital.temp_monitor_control_sample_count_o[11] ),
    .A2(\u_digital.temp_monitor_control_sample_count_o[12] ),
    .A3(_152_),
    .B1(\u_digital.temp_monitor_control_sample_count_o[13] ),
    .X(_157_));
 sky130_fd_sc_hd__and2b_2 _382_ (.A_N(_156_),
    .B(_157_),
    .X(_047_));
 sky130_fd_sc_hd__nand2_2 _383_ (.A(\u_digital.temp_monitor_control_sample_count_o[14] ),
    .B(_156_),
    .Y(_158_));
 sky130_fd_sc_hd__xor2_2 _384_ (.A(\u_digital.temp_monitor_control_sample_count_o[14] ),
    .B(_156_),
    .X(_048_));
 sky130_fd_sc_hd__xnor2_2 _385_ (.A(\u_digital.temp_monitor_control_sample_count_o[15] ),
    .B(_158_),
    .Y(_049_));
 sky130_fd_sc_hd__o21a_2 _386_ (.A1(\u_digital.temp_monitor_control_busy_o ),
    .A2(_001_),
    .B1(_093_),
    .X(_050_));
 sky130_fd_sc_hd__and2_2 _387_ (.A(\u_digital.u_temp_monitor_control.prev_adc_code[1] ),
    .B(\u_digital.adc_code[1] ),
    .X(_159_));
 sky130_fd_sc_hd__xor2_2 _388_ (.A(\u_digital.u_temp_monitor_control.prev_adc_code[1] ),
    .B(\u_digital.adc_code[1] ),
    .X(_160_));
 sky130_fd_sc_hd__nand3_2 _389_ (.A(\u_digital.u_temp_monitor_control.prev_adc_code[0] ),
    .B(\u_digital.adc_code[0] ),
    .C(_160_),
    .Y(_161_));
 sky130_fd_sc_hd__a21o_2 _390_ (.A1(\u_digital.u_temp_monitor_control.prev_adc_code[0] ),
    .A2(\u_digital.adc_code[0] ),
    .B1(_160_),
    .X(_162_));
 sky130_fd_sc_hd__and2b_2 _391_ (.A_N(\u_digital.temp_monitor_control_adc_valid_seen_o ),
    .B(\u_digital.adc_code[0] ),
    .X(_163_));
 sky130_fd_sc_hd__a31o_2 _392_ (.A1(\u_digital.temp_monitor_control_adc_valid_seen_o ),
    .A2(_161_),
    .A3(_162_),
    .B1(_093_),
    .X(_164_));
 sky130_fd_sc_hd__o22a_2 _393_ (.A1(\u_digital.adc_valid ),
    .A2(\u_digital.u_temp_monitor_control.filtered_code[0] ),
    .B1(_163_),
    .B2(_164_),
    .X(_051_));
 sky130_fd_sc_hd__a31oi_2 _394_ (.A1(\u_digital.u_temp_monitor_control.prev_adc_code[0] ),
    .A2(\u_digital.adc_code[0] ),
    .A3(_160_),
    .B1(_159_),
    .Y(_165_));
 sky130_fd_sc_hd__or2_2 _395_ (.A(\u_digital.u_temp_monitor_control.prev_adc_code[2] ),
    .B(\u_digital.adc_code[2] ),
    .X(_166_));
 sky130_fd_sc_hd__nand2_2 _396_ (.A(\u_digital.u_temp_monitor_control.prev_adc_code[2] ),
    .B(\u_digital.adc_code[2] ),
    .Y(_167_));
 sky130_fd_sc_hd__nand2_2 _397_ (.A(_166_),
    .B(_167_),
    .Y(_168_));
 sky130_fd_sc_hd__xnor2_2 _398_ (.A(_165_),
    .B(_168_),
    .Y(_169_));
 sky130_fd_sc_hd__mux2_1 _399_ (.A0(_104_),
    .A1(_169_),
    .S(\u_digital.temp_monitor_control_adc_valid_seen_o ),
    .X(_170_));
 sky130_fd_sc_hd__inv_2 _400_ (.A(_170_),
    .Y(_171_));
 sky130_fd_sc_hd__mux2_1 _401_ (.A0(\u_digital.u_temp_monitor_control.filtered_code[1] ),
    .A1(_171_),
    .S(\u_digital.adc_valid ),
    .X(_052_));
 sky130_fd_sc_hd__xnor2_2 _402_ (.A(\u_digital.u_temp_monitor_control.prev_adc_code[3] ),
    .B(\u_digital.adc_code[3] ),
    .Y(_172_));
 sky130_fd_sc_hd__o21ai_2 _403_ (.A1(_165_),
    .A2(_168_),
    .B1(_167_),
    .Y(_173_));
 sky130_fd_sc_hd__xnor2_2 _404_ (.A(_172_),
    .B(_173_),
    .Y(_174_));
 sky130_fd_sc_hd__mux2_1 _405_ (.A0(\u_digital.adc_code[2] ),
    .A1(_174_),
    .S(\u_digital.temp_monitor_control_adc_valid_seen_o ),
    .X(_175_));
 sky130_fd_sc_hd__mux2_1 _406_ (.A0(\u_digital.u_temp_monitor_control.filtered_code[2] ),
    .A1(_175_),
    .S(\u_digital.adc_valid ),
    .X(_053_));
 sky130_fd_sc_hd__or2_2 _407_ (.A(\u_digital.u_temp_monitor_control.prev_adc_code[4] ),
    .B(\u_digital.adc_code[4] ),
    .X(_176_));
 sky130_fd_sc_hd__nand2_2 _408_ (.A(\u_digital.u_temp_monitor_control.prev_adc_code[4] ),
    .B(\u_digital.adc_code[4] ),
    .Y(_177_));
 sky130_fd_sc_hd__nand2_2 _409_ (.A(_176_),
    .B(_177_),
    .Y(_178_));
 sky130_fd_sc_hd__o211a_2 _410_ (.A1(\u_digital.u_temp_monitor_control.prev_adc_code[3] ),
    .A2(\u_digital.adc_code[3] ),
    .B1(\u_digital.u_temp_monitor_control.prev_adc_code[2] ),
    .C1(\u_digital.adc_code[2] ),
    .X(_179_));
 sky130_fd_sc_hd__a21oi_2 _411_ (.A1(\u_digital.u_temp_monitor_control.prev_adc_code[3] ),
    .A2(\u_digital.adc_code[3] ),
    .B1(_179_),
    .Y(_180_));
 sky130_fd_sc_hd__o31a_2 _412_ (.A1(_165_),
    .A2(_168_),
    .A3(_172_),
    .B1(_180_),
    .X(_181_));
 sky130_fd_sc_hd__xor2_2 _413_ (.A(_178_),
    .B(_181_),
    .X(_182_));
 sky130_fd_sc_hd__mux2_1 _414_ (.A0(\u_digital.adc_code[3] ),
    .A1(_182_),
    .S(\u_digital.temp_monitor_control_adc_valid_seen_o ),
    .X(_183_));
 sky130_fd_sc_hd__mux2_1 _415_ (.A0(\u_digital.u_temp_monitor_control.filtered_code[3] ),
    .A1(_183_),
    .S(\u_digital.adc_valid ),
    .X(_054_));
 sky130_fd_sc_hd__xor2_2 _416_ (.A(\u_digital.u_temp_monitor_control.prev_adc_code[5] ),
    .B(\u_digital.adc_code[5] ),
    .X(_184_));
 sky130_fd_sc_hd__o21a_2 _417_ (.A1(_178_),
    .A2(_181_),
    .B1(_177_),
    .X(_185_));
 sky130_fd_sc_hd__xnor2_2 _418_ (.A(_184_),
    .B(_185_),
    .Y(_186_));
 sky130_fd_sc_hd__mux2_1 _419_ (.A0(\u_digital.adc_code[4] ),
    .A1(_186_),
    .S(\u_digital.temp_monitor_control_adc_valid_seen_o ),
    .X(_187_));
 sky130_fd_sc_hd__mux2_1 _420_ (.A0(\u_digital.u_temp_monitor_control.filtered_code[4] ),
    .A1(_187_),
    .S(\u_digital.adc_valid ),
    .X(_055_));
 sky130_fd_sc_hd__xnor2_2 _421_ (.A(\u_digital.u_temp_monitor_control.prev_adc_code[6] ),
    .B(\u_digital.adc_code[6] ),
    .Y(_188_));
 sky130_fd_sc_hd__a22o_2 _422_ (.A1(\u_digital.u_temp_monitor_control.prev_adc_code[4] ),
    .A2(\u_digital.adc_code[4] ),
    .B1(\u_digital.u_temp_monitor_control.prev_adc_code[5] ),
    .B2(\u_digital.adc_code[5] ),
    .X(_189_));
 sky130_fd_sc_hd__o21ai_2 _423_ (.A1(\u_digital.u_temp_monitor_control.prev_adc_code[5] ),
    .A2(\u_digital.adc_code[5] ),
    .B1(_189_),
    .Y(_190_));
 sky130_fd_sc_hd__nand2b_2 _424_ (.A_N(_178_),
    .B(_184_),
    .Y(_191_));
 sky130_fd_sc_hd__or2_2 _425_ (.A(_181_),
    .B(_191_),
    .X(_192_));
 sky130_fd_sc_hd__a21oi_2 _426_ (.A1(_190_),
    .A2(_192_),
    .B1(_188_),
    .Y(_193_));
 sky130_fd_sc_hd__and3_2 _427_ (.A(_188_),
    .B(_190_),
    .C(_192_),
    .X(_194_));
 sky130_fd_sc_hd__o21a_2 _428_ (.A1(_193_),
    .A2(_194_),
    .B1(\u_digital.temp_monitor_control_adc_valid_seen_o ),
    .X(_195_));
 sky130_fd_sc_hd__o21ai_2 _429_ (.A1(\u_digital.temp_monitor_control_adc_valid_seen_o ),
    .A2(\u_digital.adc_code[5] ),
    .B1(\u_digital.adc_valid ),
    .Y(_196_));
 sky130_fd_sc_hd__a2bb2o_2 _430_ (.A1_N(_195_),
    .A2_N(_196_),
    .B1(_093_),
    .B2(\u_digital.u_temp_monitor_control.filtered_code[5] ),
    .X(_056_));
 sky130_fd_sc_hd__xnor2_2 _431_ (.A(\u_digital.u_temp_monitor_control.prev_adc_code[7] ),
    .B(\u_digital.adc_code[7] ),
    .Y(_197_));
 sky130_fd_sc_hd__a21o_2 _432_ (.A1(\u_digital.u_temp_monitor_control.prev_adc_code[6] ),
    .A2(\u_digital.adc_code[6] ),
    .B1(_193_),
    .X(_198_));
 sky130_fd_sc_hd__nor2_2 _433_ (.A(_197_),
    .B(_198_),
    .Y(_199_));
 sky130_fd_sc_hd__a21bo_2 _434_ (.A1(_197_),
    .A2(_198_),
    .B1_N(\u_digital.temp_monitor_control_adc_valid_seen_o ),
    .X(_200_));
 sky130_fd_sc_hd__o22a_2 _435_ (.A1(\u_digital.temp_monitor_control_adc_valid_seen_o ),
    .A2(\u_digital.adc_code[6] ),
    .B1(_199_),
    .B2(_200_),
    .X(_201_));
 sky130_fd_sc_hd__mux2_1 _436_ (.A0(\u_digital.u_temp_monitor_control.filtered_code[6] ),
    .A1(_201_),
    .S(\u_digital.adc_valid ),
    .X(_057_));
 sky130_fd_sc_hd__or2_2 _437_ (.A(_188_),
    .B(_197_),
    .X(_202_));
 sky130_fd_sc_hd__o211a_2 _438_ (.A1(\u_digital.u_temp_monitor_control.prev_adc_code[7] ),
    .A2(\u_digital.adc_code[7] ),
    .B1(\u_digital.u_temp_monitor_control.prev_adc_code[6] ),
    .C1(\u_digital.adc_code[6] ),
    .X(_203_));
 sky130_fd_sc_hd__a21oi_2 _439_ (.A1(\u_digital.u_temp_monitor_control.prev_adc_code[7] ),
    .A2(\u_digital.adc_code[7] ),
    .B1(_203_),
    .Y(_204_));
 sky130_fd_sc_hd__o21a_2 _440_ (.A1(_190_),
    .A2(_202_),
    .B1(_204_),
    .X(_205_));
 sky130_fd_sc_hd__o31ai_2 _441_ (.A1(_181_),
    .A2(_191_),
    .A3(_202_),
    .B1(_205_),
    .Y(_206_));
 sky130_fd_sc_hd__or2_2 _442_ (.A(\u_digital.u_temp_monitor_control.prev_adc_code[8] ),
    .B(\u_digital.adc_code[8] ),
    .X(_207_));
 sky130_fd_sc_hd__nand2_2 _443_ (.A(\u_digital.u_temp_monitor_control.prev_adc_code[8] ),
    .B(\u_digital.adc_code[8] ),
    .Y(_208_));
 sky130_fd_sc_hd__and2_2 _444_ (.A(_207_),
    .B(_208_),
    .X(_209_));
 sky130_fd_sc_hd__nand2_2 _445_ (.A(_206_),
    .B(_209_),
    .Y(_210_));
 sky130_fd_sc_hd__or2_2 _446_ (.A(_206_),
    .B(_209_),
    .X(_211_));
 sky130_fd_sc_hd__and2_2 _447_ (.A(_210_),
    .B(_211_),
    .X(_212_));
 sky130_fd_sc_hd__mux2_1 _448_ (.A0(\u_digital.adc_code[7] ),
    .A1(_212_),
    .S(\u_digital.temp_monitor_control_adc_valid_seen_o ),
    .X(_213_));
 sky130_fd_sc_hd__mux2_1 _449_ (.A0(\u_digital.u_temp_monitor_control.filtered_code[7] ),
    .A1(_213_),
    .S(\u_digital.adc_valid ),
    .X(_058_));
 sky130_fd_sc_hd__nor2_2 _450_ (.A(\u_digital.u_temp_monitor_control.prev_adc_code[9] ),
    .B(\u_digital.adc_code[9] ),
    .Y(_214_));
 sky130_fd_sc_hd__nand2_2 _451_ (.A(\u_digital.u_temp_monitor_control.prev_adc_code[9] ),
    .B(\u_digital.adc_code[9] ),
    .Y(_215_));
 sky130_fd_sc_hd__nand2b_2 _452_ (.A_N(_214_),
    .B(_215_),
    .Y(_216_));
 sky130_fd_sc_hd__nand2_2 _453_ (.A(_208_),
    .B(_210_),
    .Y(_217_));
 sky130_fd_sc_hd__xnor2_2 _454_ (.A(_216_),
    .B(_217_),
    .Y(_218_));
 sky130_fd_sc_hd__mux2_1 _455_ (.A0(\u_digital.adc_code[8] ),
    .A1(_218_),
    .S(\u_digital.temp_monitor_control_adc_valid_seen_o ),
    .X(_219_));
 sky130_fd_sc_hd__mux2_1 _456_ (.A0(\u_digital.u_temp_monitor_control.filtered_code[8] ),
    .A1(_219_),
    .S(\u_digital.adc_valid ),
    .X(_059_));
 sky130_fd_sc_hd__nand2_2 _457_ (.A(\u_digital.u_temp_monitor_control.prev_adc_code[10] ),
    .B(\u_digital.adc_code[10] ),
    .Y(_220_));
 sky130_fd_sc_hd__or2_2 _458_ (.A(\u_digital.u_temp_monitor_control.prev_adc_code[10] ),
    .B(\u_digital.adc_code[10] ),
    .X(_221_));
 sky130_fd_sc_hd__nand2_2 _459_ (.A(_220_),
    .B(_221_),
    .Y(_222_));
 sky130_fd_sc_hd__a31o_2 _460_ (.A1(_208_),
    .A2(_210_),
    .A3(_215_),
    .B1(_214_),
    .X(_223_));
 sky130_fd_sc_hd__a311o_2 _461_ (.A1(_208_),
    .A2(_210_),
    .A3(_215_),
    .B1(_222_),
    .C1(_214_),
    .X(_224_));
 sky130_fd_sc_hd__xor2_2 _462_ (.A(_222_),
    .B(_223_),
    .X(_225_));
 sky130_fd_sc_hd__mux2_1 _463_ (.A0(\u_digital.adc_code[9] ),
    .A1(_225_),
    .S(\u_digital.temp_monitor_control_adc_valid_seen_o ),
    .X(_226_));
 sky130_fd_sc_hd__mux2_1 _464_ (.A0(\u_digital.u_temp_monitor_control.filtered_code[9] ),
    .A1(_226_),
    .S(\u_digital.adc_valid ),
    .X(_060_));
 sky130_fd_sc_hd__xor2_2 _465_ (.A(\u_digital.u_temp_monitor_control.prev_adc_code[11] ),
    .B(\u_digital.adc_code[11] ),
    .X(_227_));
 sky130_fd_sc_hd__and3_2 _466_ (.A(_220_),
    .B(_224_),
    .C(_227_),
    .X(_228_));
 sky130_fd_sc_hd__a21oi_2 _467_ (.A1(_220_),
    .A2(_224_),
    .B1(_227_),
    .Y(_229_));
 sky130_fd_sc_hd__or3b_2 _468_ (.A(_228_),
    .B(_229_),
    .C_N(\u_digital.temp_monitor_control_adc_valid_seen_o ),
    .X(_230_));
 sky130_fd_sc_hd__o21a_2 _469_ (.A1(\u_digital.temp_monitor_control_adc_valid_seen_o ),
    .A2(\u_digital.adc_code[10] ),
    .B1(\u_digital.adc_valid ),
    .X(_231_));
 sky130_fd_sc_hd__a22o_2 _470_ (.A1(_093_),
    .A2(\u_digital.u_temp_monitor_control.filtered_code[10] ),
    .B1(_230_),
    .B2(_231_),
    .X(_061_));
 sky130_fd_sc_hd__a2bb2o_2 _471_ (.A1_N(_139_),
    .A2_N(\u_digital.temp_monitor_control_adc_valid_seen_o ),
    .B1(\u_digital.u_temp_monitor_control.filtered_code[11] ),
    .B2(_093_),
    .X(_062_));
 sky130_fd_sc_hd__and3b_2 _472_ (.A_N(wr_addr[4]),
    .B(_106_),
    .C(_108_),
    .X(_232_));
 sky130_fd_sc_hd__mux2_1 _473_ (.A0(\u_digital.u_temp_monitor_registers.threshold_reg[0] ),
    .A1(wr_data[0]),
    .S(_232_),
    .X(_063_));
 sky130_fd_sc_hd__mux2_1 _474_ (.A0(\u_digital.u_temp_monitor_registers.threshold_reg[1] ),
    .A1(wr_data[1]),
    .S(_232_),
    .X(_064_));
 sky130_fd_sc_hd__mux2_1 _475_ (.A0(\u_digital.u_temp_monitor_registers.threshold_reg[2] ),
    .A1(wr_data[2]),
    .S(_232_),
    .X(_065_));
 sky130_fd_sc_hd__mux2_1 _476_ (.A0(\u_digital.u_temp_monitor_registers.threshold_reg[3] ),
    .A1(wr_data[3]),
    .S(_232_),
    .X(_066_));
 sky130_fd_sc_hd__mux2_1 _477_ (.A0(\u_digital.u_temp_monitor_registers.threshold_reg[4] ),
    .A1(wr_data[4]),
    .S(_232_),
    .X(_067_));
 sky130_fd_sc_hd__mux2_1 _478_ (.A0(\u_digital.u_temp_monitor_registers.threshold_reg[5] ),
    .A1(wr_data[5]),
    .S(_232_),
    .X(_068_));
 sky130_fd_sc_hd__mux2_1 _479_ (.A0(\u_digital.u_temp_monitor_registers.threshold_reg[6] ),
    .A1(wr_data[6]),
    .S(_232_),
    .X(_069_));
 sky130_fd_sc_hd__mux2_1 _480_ (.A0(\u_digital.u_temp_monitor_registers.threshold_reg[7] ),
    .A1(wr_data[7]),
    .S(_232_),
    .X(_070_));
 sky130_fd_sc_hd__mux2_1 _481_ (.A0(\u_digital.u_temp_monitor_registers.threshold_reg[8] ),
    .A1(wr_data[8]),
    .S(_232_),
    .X(_071_));
 sky130_fd_sc_hd__mux2_1 _482_ (.A0(\u_digital.u_temp_monitor_registers.threshold_reg[9] ),
    .A1(wr_data[9]),
    .S(_232_),
    .X(_072_));
 sky130_fd_sc_hd__mux2_1 _483_ (.A0(\u_digital.u_temp_monitor_registers.threshold_reg[10] ),
    .A1(wr_data[10]),
    .S(_232_),
    .X(_073_));
 sky130_fd_sc_hd__mux2_1 _484_ (.A0(\u_digital.u_temp_monitor_registers.threshold_reg[11] ),
    .A1(wr_data[11]),
    .S(_232_),
    .X(_074_));
 sky130_fd_sc_hd__mux2_1 _485_ (.A0(\u_digital.u_temp_monitor_registers.control_reg[0] ),
    .A1(wr_data[0]),
    .S(_109_),
    .X(_075_));
 sky130_fd_sc_hd__mux2_1 _486_ (.A0(\u_digital.u_temp_monitor_registers.control_reg[2] ),
    .A1(wr_data[2]),
    .S(_109_),
    .X(_076_));
 sky130_fd_sc_hd__or3b_2 _487_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .C_N(rd_addr[2]),
    .X(_233_));
 sky130_fd_sc_hd__or3_2 _488_ (.A(rd_addr[5]),
    .B(rd_addr[7]),
    .C(rd_addr[6]),
    .X(_234_));
 sky130_fd_sc_hd__nor3_2 _489_ (.A(rd_addr[3]),
    .B(rd_addr[4]),
    .C(_234_),
    .Y(_235_));
 sky130_fd_sc_hd__and2b_2 _490_ (.A_N(_233_),
    .B(_235_),
    .X(_236_));
 sky130_fd_sc_hd__nor3_2 _491_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .C(rd_addr[2]),
    .Y(_237_));
 sky130_fd_sc_hd__a32o_2 _492_ (.A1(\u_digital.u_temp_monitor_registers.control_reg[0] ),
    .A2(_235_),
    .A3(_237_),
    .B1(_236_),
    .B2(\u_digital.u_temp_monitor_registers.status_reg[0] ),
    .X(_238_));
 sky130_fd_sc_hd__and4bb_2 _493_ (.A_N(rd_addr[4]),
    .B_N(_234_),
    .C(_237_),
    .D(rd_addr[3]),
    .X(_239_));
 sky130_fd_sc_hd__and4bb_2 _494_ (.A_N(_234_),
    .B_N(rd_addr[3]),
    .C(rd_addr[4]),
    .D(_237_),
    .X(_240_));
 sky130_fd_sc_hd__nor4b_2 _495_ (.A(rd_addr[4]),
    .B(_233_),
    .C(_234_),
    .D_N(rd_addr[3]),
    .Y(_241_));
 sky130_fd_sc_hd__a21o_2 _496_ (.A1(\u_digital.temp_monitor_control_sample_count_o[0] ),
    .A2(_240_),
    .B1(_105_),
    .X(_242_));
 sky130_fd_sc_hd__a22o_2 _497_ (.A1(\u_digital.u_temp_monitor_registers.threshold_reg[0] ),
    .A2(_239_),
    .B1(_241_),
    .B2(temp_code[0]),
    .X(_243_));
 sky130_fd_sc_hd__o32a_2 _498_ (.A1(_238_),
    .A2(_242_),
    .A3(_243_),
    .B1(rd_en),
    .B2(rd_data[0]),
    .X(_077_));
 sky130_fd_sc_hd__a22o_2 _499_ (.A1(\u_digital.u_temp_monitor_registers.threshold_reg[1] ),
    .A2(_239_),
    .B1(_240_),
    .B2(\u_digital.temp_monitor_control_sample_count_o[1] ),
    .X(_244_));
 sky130_fd_sc_hd__and2_2 _500_ (.A(temp_code[1]),
    .B(_241_),
    .X(_245_));
 sky130_fd_sc_hd__a211o_2 _501_ (.A1(\u_digital.u_temp_monitor_registers.status_reg[1] ),
    .A2(_236_),
    .B1(_244_),
    .C1(_105_),
    .X(_246_));
 sky130_fd_sc_hd__o22a_2 _502_ (.A1(rd_en),
    .A2(rd_data[1]),
    .B1(_245_),
    .B2(_246_),
    .X(_078_));
 sky130_fd_sc_hd__a32o_2 _503_ (.A1(\u_digital.u_temp_monitor_registers.control_reg[2] ),
    .A2(_235_),
    .A3(_237_),
    .B1(_236_),
    .B2(\u_digital.u_temp_monitor_registers.status_reg[2] ),
    .X(_247_));
 sky130_fd_sc_hd__a21o_2 _504_ (.A1(\u_digital.temp_monitor_control_sample_count_o[2] ),
    .A2(_240_),
    .B1(_105_),
    .X(_248_));
 sky130_fd_sc_hd__a22o_2 _505_ (.A1(\u_digital.u_temp_monitor_registers.threshold_reg[2] ),
    .A2(_239_),
    .B1(_241_),
    .B2(temp_code[2]),
    .X(_249_));
 sky130_fd_sc_hd__o32a_2 _506_ (.A1(_247_),
    .A2(_248_),
    .A3(_249_),
    .B1(rd_data[2]),
    .B2(rd_en),
    .X(_079_));
 sky130_fd_sc_hd__and2_2 _507_ (.A(\u_digital.u_temp_monitor_registers.status_reg[3] ),
    .B(_236_),
    .X(_250_));
 sky130_fd_sc_hd__a22o_2 _508_ (.A1(\u_digital.u_temp_monitor_registers.threshold_reg[3] ),
    .A2(_239_),
    .B1(_241_),
    .B2(temp_code[3]),
    .X(_251_));
 sky130_fd_sc_hd__a21o_2 _509_ (.A1(\u_digital.temp_monitor_control_sample_count_o[3] ),
    .A2(_240_),
    .B1(_105_),
    .X(_252_));
 sky130_fd_sc_hd__o32a_2 _510_ (.A1(_250_),
    .A2(_251_),
    .A3(_252_),
    .B1(rd_data[3]),
    .B2(rd_en),
    .X(_080_));
 sky130_fd_sc_hd__and2_2 _511_ (.A(\u_digital.temp_monitor_control_sample_count_o[4] ),
    .B(_240_),
    .X(_253_));
 sky130_fd_sc_hd__a221o_2 _512_ (.A1(\u_digital.u_temp_monitor_registers.threshold_reg[4] ),
    .A2(_239_),
    .B1(_241_),
    .B2(temp_code[4]),
    .C1(_105_),
    .X(_254_));
 sky130_fd_sc_hd__o22a_2 _513_ (.A1(rd_en),
    .A2(rd_data[4]),
    .B1(_253_),
    .B2(_254_),
    .X(_081_));
 sky130_fd_sc_hd__and2_2 _514_ (.A(\u_digital.u_temp_monitor_registers.threshold_reg[5] ),
    .B(_239_),
    .X(_255_));
 sky130_fd_sc_hd__a221o_2 _515_ (.A1(\u_digital.temp_monitor_control_sample_count_o[5] ),
    .A2(_240_),
    .B1(_241_),
    .B2(temp_code[5]),
    .C1(_105_),
    .X(_256_));
 sky130_fd_sc_hd__o22a_2 _516_ (.A1(rd_en),
    .A2(rd_data[5]),
    .B1(_255_),
    .B2(_256_),
    .X(_082_));
 sky130_fd_sc_hd__and2_2 _517_ (.A(\u_digital.temp_monitor_control_sample_count_o[6] ),
    .B(_240_),
    .X(_257_));
 sky130_fd_sc_hd__a221o_2 _518_ (.A1(\u_digital.u_temp_monitor_registers.threshold_reg[6] ),
    .A2(_239_),
    .B1(_241_),
    .B2(temp_code[6]),
    .C1(_105_),
    .X(_258_));
 sky130_fd_sc_hd__o22a_2 _519_ (.A1(rd_en),
    .A2(rd_data[6]),
    .B1(_257_),
    .B2(_258_),
    .X(_083_));
 sky130_fd_sc_hd__and2_2 _520_ (.A(\u_digital.temp_monitor_control_sample_count_o[7] ),
    .B(_240_),
    .X(_259_));
 sky130_fd_sc_hd__a221o_2 _521_ (.A1(\u_digital.u_temp_monitor_registers.threshold_reg[7] ),
    .A2(_239_),
    .B1(_241_),
    .B2(temp_code[7]),
    .C1(_105_),
    .X(_260_));
 sky130_fd_sc_hd__o22a_2 _522_ (.A1(rd_en),
    .A2(rd_data[7]),
    .B1(_259_),
    .B2(_260_),
    .X(_084_));
 sky130_fd_sc_hd__and2_2 _523_ (.A(\u_digital.temp_monitor_control_sample_count_o[8] ),
    .B(_240_),
    .X(_261_));
 sky130_fd_sc_hd__a221o_2 _524_ (.A1(\u_digital.u_temp_monitor_registers.threshold_reg[8] ),
    .A2(_239_),
    .B1(_241_),
    .B2(temp_code[8]),
    .C1(_105_),
    .X(_262_));
 sky130_fd_sc_hd__o22a_2 _525_ (.A1(rd_en),
    .A2(rd_data[8]),
    .B1(_261_),
    .B2(_262_),
    .X(_085_));
 sky130_fd_sc_hd__and2_2 _526_ (.A(\u_digital.temp_monitor_control_sample_count_o[9] ),
    .B(_240_),
    .X(_263_));
 sky130_fd_sc_hd__a221o_2 _527_ (.A1(\u_digital.u_temp_monitor_registers.threshold_reg[9] ),
    .A2(_239_),
    .B1(_241_),
    .B2(temp_code[9]),
    .C1(_105_),
    .X(_264_));
 sky130_fd_sc_hd__o22a_2 _528_ (.A1(rd_en),
    .A2(rd_data[9]),
    .B1(_263_),
    .B2(_264_),
    .X(_086_));
 sky130_fd_sc_hd__and2_2 _529_ (.A(\u_digital.temp_monitor_control_sample_count_o[10] ),
    .B(_240_),
    .X(_265_));
 sky130_fd_sc_hd__a221o_2 _530_ (.A1(\u_digital.u_temp_monitor_registers.threshold_reg[10] ),
    .A2(_239_),
    .B1(_241_),
    .B2(temp_code[10]),
    .C1(_105_),
    .X(_266_));
 sky130_fd_sc_hd__o22a_2 _531_ (.A1(rd_en),
    .A2(rd_data[10]),
    .B1(_265_),
    .B2(_266_),
    .X(_087_));
 sky130_fd_sc_hd__and2_2 _532_ (.A(\u_digital.temp_monitor_control_sample_count_o[11] ),
    .B(_240_),
    .X(_267_));
 sky130_fd_sc_hd__a221o_2 _533_ (.A1(\u_digital.u_temp_monitor_registers.threshold_reg[11] ),
    .A2(_239_),
    .B1(_241_),
    .B2(temp_code[11]),
    .C1(_105_),
    .X(_268_));
 sky130_fd_sc_hd__o22a_2 _534_ (.A1(rd_en),
    .A2(rd_data[11]),
    .B1(_267_),
    .B2(_268_),
    .X(_088_));
 sky130_fd_sc_hd__and2_2 _535_ (.A(rd_en),
    .B(_240_),
    .X(_269_));
 sky130_fd_sc_hd__a22o_2 _536_ (.A1(_105_),
    .A2(rd_data[12]),
    .B1(_269_),
    .B2(\u_digital.temp_monitor_control_sample_count_o[12] ),
    .X(_089_));
 sky130_fd_sc_hd__a22o_2 _537_ (.A1(_105_),
    .A2(rd_data[13]),
    .B1(_269_),
    .B2(\u_digital.temp_monitor_control_sample_count_o[13] ),
    .X(_090_));
 sky130_fd_sc_hd__a22o_2 _538_ (.A1(_105_),
    .A2(rd_data[14]),
    .B1(_269_),
    .B2(\u_digital.temp_monitor_control_sample_count_o[14] ),
    .X(_091_));
 sky130_fd_sc_hd__a22o_2 _539_ (.A1(_105_),
    .A2(rd_data[15]),
    .B1(_269_),
    .B2(\u_digital.temp_monitor_control_sample_count_o[15] ),
    .X(_092_));
 sky130_fd_sc_hd__sdfrtp_2 _540_ (.CLK(clk),
    .D(\u_digital.temp_monitor_control_irq_status_sample_done_o ),
    .RESET_B(reset_n),
    .SCD(scan_in[0]),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_registers.status_reg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _541_ (.CLK(clk),
    .D(\u_digital.temp_monitor_control_status_alert_pending_o ),
    .RESET_B(reset_n),
    .SCD(scan_in[1]),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_registers.status_reg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _542_ (.CLK(clk),
    .D(\u_digital.temp_monitor_control_adc_valid_seen_o ),
    .RESET_B(reset_n),
    .SCD(scan_in[2]),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_registers.status_reg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _543_ (.CLK(clk),
    .D(\u_digital.temp_monitor_control_busy_o ),
    .RESET_B(reset_n),
    .SCD(scan_in[3]),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_registers.status_reg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _544_ (.CLK(clk),
    .D(_001_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_registers.status_reg[0] ),
    .SCE(scan_en),
    .Q(\u_digital.sample_req ));
 sky130_fd_sc_hd__sdfrtp_2 _545_ (.CLK(clk),
    .D(_000_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_registers.status_reg[1] ),
    .SCE(scan_en),
    .Q(alert_irq));
 sky130_fd_sc_hd__sdfrtp_2 _546_ (.CLK(clk),
    .D(_006_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_registers.status_reg[2] ),
    .SCE(scan_en),
    .Q(\u_digital.temp_monitor_control_adc_valid_seen_o ));
 sky130_fd_sc_hd__sdfrtp_2 _547_ (.CLK(clk),
    .D(_007_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_registers.status_reg[3] ),
    .SCE(scan_en),
    .Q(alert_status));
 sky130_fd_sc_hd__sdfrtp_2 _548_ (.CLK(clk),
    .D(_008_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_req ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_control.prev_adc_code[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _549_ (.CLK(clk),
    .D(_009_),
    .RESET_B(reset_n),
    .SCD(alert_irq),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_control.prev_adc_code[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _550_ (.CLK(clk),
    .D(_010_),
    .RESET_B(reset_n),
    .SCD(\u_digital.temp_monitor_control_adc_valid_seen_o ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_control.prev_adc_code[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _551_ (.CLK(clk),
    .D(_011_),
    .RESET_B(reset_n),
    .SCD(alert_status),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_control.prev_adc_code[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _552_ (.CLK(clk),
    .D(_012_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_control.prev_adc_code[0] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_control.prev_adc_code[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _553_ (.CLK(clk),
    .D(_013_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_control.prev_adc_code[1] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_control.prev_adc_code[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _554_ (.CLK(clk),
    .D(_014_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_control.prev_adc_code[2] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_control.prev_adc_code[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _555_ (.CLK(clk),
    .D(_015_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_control.prev_adc_code[3] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_control.prev_adc_code[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _556_ (.CLK(clk),
    .D(_016_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_control.prev_adc_code[4] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_control.prev_adc_code[8] ));
 sky130_fd_sc_hd__sdfrtp_2 _557_ (.CLK(clk),
    .D(_017_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_control.prev_adc_code[5] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_control.prev_adc_code[9] ));
 sky130_fd_sc_hd__sdfrtp_2 _558_ (.CLK(clk),
    .D(_018_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_control.prev_adc_code[6] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_control.prev_adc_code[10] ));
 sky130_fd_sc_hd__sdfrtp_2 _559_ (.CLK(clk),
    .D(_019_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_control.prev_adc_code[7] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_control.prev_adc_code[11] ));
 sky130_fd_sc_hd__sdfrtp_2 _560_ (.CLK(clk),
    .D(_020_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_control.prev_adc_code[8] ),
    .SCE(scan_en),
    .Q(\u_digital.temp_monitor_control_irq_status_sample_done_o ));
 sky130_fd_sc_hd__sdfrtp_2 _561_ (.CLK(clk),
    .D(_021_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_control.prev_adc_code[9] ),
    .SCE(scan_en),
    .Q(\u_digital.temp_monitor_control_status_alert_pending_o ));
 sky130_fd_sc_hd__sdfrtp_2 _562_ (.CLK(clk),
    .D(_022_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_control.prev_adc_code[10] ),
    .SCE(scan_en),
    .Q(temp_code[0]));
 sky130_fd_sc_hd__sdfrtp_2 _563_ (.CLK(clk),
    .D(_023_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_control.prev_adc_code[11] ),
    .SCE(scan_en),
    .Q(temp_code[1]));
 sky130_fd_sc_hd__sdfrtp_2 _564_ (.CLK(clk),
    .D(_024_),
    .RESET_B(reset_n),
    .SCD(\u_digital.temp_monitor_control_irq_status_sample_done_o ),
    .SCE(scan_en),
    .Q(temp_code[2]));
 sky130_fd_sc_hd__sdfrtp_2 _565_ (.CLK(clk),
    .D(_025_),
    .RESET_B(reset_n),
    .SCD(\u_digital.temp_monitor_control_status_alert_pending_o ),
    .SCE(scan_en),
    .Q(temp_code[3]));
 sky130_fd_sc_hd__sdfrtp_2 _566_ (.CLK(clk),
    .D(_026_),
    .RESET_B(reset_n),
    .SCD(temp_code[0]),
    .SCE(scan_en),
    .Q(temp_code[4]));
 sky130_fd_sc_hd__sdfrtp_2 _567_ (.CLK(clk),
    .D(_027_),
    .RESET_B(reset_n),
    .SCD(temp_code[1]),
    .SCE(scan_en),
    .Q(temp_code[5]));
 sky130_fd_sc_hd__sdfrtp_2 _568_ (.CLK(clk),
    .D(_028_),
    .RESET_B(reset_n),
    .SCD(temp_code[2]),
    .SCE(scan_en),
    .Q(temp_code[6]));
 sky130_fd_sc_hd__sdfrtp_2 _569_ (.CLK(clk),
    .D(_029_),
    .RESET_B(reset_n),
    .SCD(temp_code[3]),
    .SCE(scan_en),
    .Q(temp_code[7]));
 sky130_fd_sc_hd__sdfrtp_2 _570_ (.CLK(clk),
    .D(_030_),
    .RESET_B(reset_n),
    .SCD(temp_code[4]),
    .SCE(scan_en),
    .Q(temp_code[8]));
 sky130_fd_sc_hd__sdfrtp_2 _571_ (.CLK(clk),
    .D(_031_),
    .RESET_B(reset_n),
    .SCD(temp_code[5]),
    .SCE(scan_en),
    .Q(temp_code[9]));
 sky130_fd_sc_hd__sdfrtp_2 _572_ (.CLK(clk),
    .D(_032_),
    .RESET_B(reset_n),
    .SCD(temp_code[6]),
    .SCE(scan_en),
    .Q(temp_code[10]));
 sky130_fd_sc_hd__sdfrtp_2 _573_ (.CLK(clk),
    .D(_033_),
    .RESET_B(reset_n),
    .SCD(temp_code[7]),
    .SCE(scan_en),
    .Q(temp_code[11]));
 sky130_fd_sc_hd__sdfrtp_2 _574_ (.CLK(clk),
    .D(_034_),
    .RESET_B(reset_n),
    .SCD(temp_code[8]),
    .SCE(scan_en),
    .Q(\u_digital.temp_monitor_control_sample_count_o[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _575_ (.CLK(clk),
    .D(_035_),
    .RESET_B(reset_n),
    .SCD(temp_code[9]),
    .SCE(scan_en),
    .Q(\u_digital.temp_monitor_control_sample_count_o[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _576_ (.CLK(clk),
    .D(_036_),
    .RESET_B(reset_n),
    .SCD(temp_code[10]),
    .SCE(scan_en),
    .Q(\u_digital.temp_monitor_control_sample_count_o[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _577_ (.CLK(clk),
    .D(_037_),
    .RESET_B(reset_n),
    .SCD(temp_code[11]),
    .SCE(scan_en),
    .Q(\u_digital.temp_monitor_control_sample_count_o[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _578_ (.CLK(clk),
    .D(_038_),
    .RESET_B(reset_n),
    .SCD(\u_digital.temp_monitor_control_sample_count_o[0] ),
    .SCE(scan_en),
    .Q(\u_digital.temp_monitor_control_sample_count_o[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _579_ (.CLK(clk),
    .D(_039_),
    .RESET_B(reset_n),
    .SCD(\u_digital.temp_monitor_control_sample_count_o[1] ),
    .SCE(scan_en),
    .Q(\u_digital.temp_monitor_control_sample_count_o[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _580_ (.CLK(clk),
    .D(_040_),
    .RESET_B(reset_n),
    .SCD(\u_digital.temp_monitor_control_sample_count_o[2] ),
    .SCE(scan_en),
    .Q(\u_digital.temp_monitor_control_sample_count_o[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _581_ (.CLK(clk),
    .D(_041_),
    .RESET_B(reset_n),
    .SCD(\u_digital.temp_monitor_control_sample_count_o[3] ),
    .SCE(scan_en),
    .Q(\u_digital.temp_monitor_control_sample_count_o[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _582_ (.CLK(clk),
    .D(_042_),
    .RESET_B(reset_n),
    .SCD(\u_digital.temp_monitor_control_sample_count_o[4] ),
    .SCE(scan_en),
    .Q(\u_digital.temp_monitor_control_sample_count_o[8] ));
 sky130_fd_sc_hd__sdfrtp_2 _583_ (.CLK(clk),
    .D(_043_),
    .RESET_B(reset_n),
    .SCD(\u_digital.temp_monitor_control_sample_count_o[5] ),
    .SCE(scan_en),
    .Q(\u_digital.temp_monitor_control_sample_count_o[9] ));
 sky130_fd_sc_hd__sdfrtp_2 _584_ (.CLK(clk),
    .D(_044_),
    .RESET_B(reset_n),
    .SCD(\u_digital.temp_monitor_control_sample_count_o[6] ),
    .SCE(scan_en),
    .Q(\u_digital.temp_monitor_control_sample_count_o[10] ));
 sky130_fd_sc_hd__sdfrtp_2 _585_ (.CLK(clk),
    .D(_045_),
    .RESET_B(reset_n),
    .SCD(\u_digital.temp_monitor_control_sample_count_o[7] ),
    .SCE(scan_en),
    .Q(\u_digital.temp_monitor_control_sample_count_o[11] ));
 sky130_fd_sc_hd__sdfrtp_2 _586_ (.CLK(clk),
    .D(_046_),
    .RESET_B(reset_n),
    .SCD(\u_digital.temp_monitor_control_sample_count_o[8] ),
    .SCE(scan_en),
    .Q(\u_digital.temp_monitor_control_sample_count_o[12] ));
 sky130_fd_sc_hd__sdfrtp_2 _587_ (.CLK(clk),
    .D(_047_),
    .RESET_B(reset_n),
    .SCD(\u_digital.temp_monitor_control_sample_count_o[9] ),
    .SCE(scan_en),
    .Q(\u_digital.temp_monitor_control_sample_count_o[13] ));
 sky130_fd_sc_hd__sdfrtp_2 _588_ (.CLK(clk),
    .D(_048_),
    .RESET_B(reset_n),
    .SCD(\u_digital.temp_monitor_control_sample_count_o[10] ),
    .SCE(scan_en),
    .Q(\u_digital.temp_monitor_control_sample_count_o[14] ));
 sky130_fd_sc_hd__sdfrtp_2 _589_ (.CLK(clk),
    .D(_049_),
    .RESET_B(reset_n),
    .SCD(\u_digital.temp_monitor_control_sample_count_o[11] ),
    .SCE(scan_en),
    .Q(\u_digital.temp_monitor_control_sample_count_o[15] ));
 sky130_fd_sc_hd__sdfrtp_2 _590_ (.CLK(clk),
    .D(_050_),
    .RESET_B(reset_n),
    .SCD(\u_digital.temp_monitor_control_sample_count_o[12] ),
    .SCE(scan_en),
    .Q(\u_digital.temp_monitor_control_busy_o ));
 sky130_fd_sc_hd__sdfrtp_2 _591_ (.CLK(clk),
    .D(_051_),
    .RESET_B(reset_n),
    .SCD(\u_digital.temp_monitor_control_sample_count_o[13] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_control.filtered_code[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _592_ (.CLK(clk),
    .D(_052_),
    .RESET_B(reset_n),
    .SCD(\u_digital.temp_monitor_control_sample_count_o[14] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_control.filtered_code[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _593_ (.CLK(clk),
    .D(_053_),
    .RESET_B(reset_n),
    .SCD(\u_digital.temp_monitor_control_sample_count_o[15] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_control.filtered_code[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _594_ (.CLK(clk),
    .D(_054_),
    .RESET_B(reset_n),
    .SCD(\u_digital.temp_monitor_control_busy_o ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_control.filtered_code[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _595_ (.CLK(clk),
    .D(_055_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_control.filtered_code[0] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_control.filtered_code[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _596_ (.CLK(clk),
    .D(_056_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_control.filtered_code[1] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_control.filtered_code[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _597_ (.CLK(clk),
    .D(_057_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_control.filtered_code[2] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_control.filtered_code[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _598_ (.CLK(clk),
    .D(_058_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_control.filtered_code[3] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_control.filtered_code[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _599_ (.CLK(clk),
    .D(_059_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_control.filtered_code[4] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_control.filtered_code[8] ));
 sky130_fd_sc_hd__sdfrtp_2 _600_ (.CLK(clk),
    .D(_060_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_control.filtered_code[5] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_control.filtered_code[9] ));
 sky130_fd_sc_hd__sdfrtp_2 _601_ (.CLK(clk),
    .D(_061_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_control.filtered_code[6] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_control.filtered_code[10] ));
 sky130_fd_sc_hd__sdfrtp_2 _602_ (.CLK(clk),
    .D(_062_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_control.filtered_code[7] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_control.filtered_code[11] ));
 sky130_fd_sc_hd__sdfrtp_2 _603_ (.CLK(clk),
    .D(\u_digital.u_temp_monitor_registers.control_reg[0] ),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_control.filtered_code[8] ),
    .SCE(scan_en),
    .Q(\u_digital.temp_monitor_control_enable_i ));
 sky130_fd_sc_hd__sdfrtp_2 _604_ (.CLK(clk),
    .D(_003_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_control.filtered_code[9] ),
    .SCE(scan_en),
    .Q(\u_digital.temp_monitor_control_sample_start_pulse_i ));
 sky130_fd_sc_hd__sdfrtp_2 _605_ (.CLK(clk),
    .D(_063_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_control.filtered_code[10] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_registers.threshold_reg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _606_ (.CLK(clk),
    .D(_064_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_control.filtered_code[11] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_registers.threshold_reg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _607_ (.CLK(clk),
    .D(_065_),
    .RESET_B(reset_n),
    .SCD(\u_digital.temp_monitor_control_enable_i ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_registers.threshold_reg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _608_ (.CLK(clk),
    .D(_066_),
    .RESET_B(reset_n),
    .SCD(\u_digital.temp_monitor_control_sample_start_pulse_i ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_registers.threshold_reg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _609_ (.CLK(clk),
    .D(_067_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_registers.threshold_reg[0] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_registers.threshold_reg[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _610_ (.CLK(clk),
    .D(_068_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_registers.threshold_reg[1] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_registers.threshold_reg[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _611_ (.CLK(clk),
    .D(_069_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_registers.threshold_reg[2] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_registers.threshold_reg[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _612_ (.CLK(clk),
    .D(_070_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_registers.threshold_reg[3] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_registers.threshold_reg[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _613_ (.CLK(clk),
    .D(_071_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_registers.threshold_reg[4] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_registers.threshold_reg[8] ));
 sky130_fd_sc_hd__sdfrtp_2 _614_ (.CLK(clk),
    .D(_072_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_registers.threshold_reg[5] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_registers.threshold_reg[9] ));
 sky130_fd_sc_hd__sdfrtp_2 _615_ (.CLK(clk),
    .D(_073_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_registers.threshold_reg[6] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_registers.threshold_reg[10] ));
 sky130_fd_sc_hd__sdfrtp_2 _616_ (.CLK(clk),
    .D(_074_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_registers.threshold_reg[7] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_registers.threshold_reg[11] ));
 sky130_fd_sc_hd__sdfrtp_2 _617_ (.CLK(clk),
    .D(\u_digital.u_temp_monitor_registers.control_reg[2] ),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_registers.threshold_reg[8] ),
    .SCE(scan_en),
    .Q(\u_digital.temp_monitor_control_irq_enable_i ));
 sky130_fd_sc_hd__sdfrtp_2 _618_ (.CLK(clk),
    .D(_005_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_registers.threshold_reg[9] ),
    .SCE(scan_en),
    .Q(\u_digital.temp_monitor_control_irq_clear_sample_done_pulse_i ));
 sky130_fd_sc_hd__sdfrtp_2 _619_ (.CLK(clk),
    .D(_002_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_registers.threshold_reg[10] ),
    .SCE(scan_en),
    .Q(\u_digital.temp_monitor_control_alert_clear_pulse_i ));
 sky130_fd_sc_hd__sdfrtp_2 _620_ (.CLK(clk),
    .D(_075_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_registers.threshold_reg[11] ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_registers.control_reg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _621_ (.CLK(clk),
    .D(_076_),
    .RESET_B(reset_n),
    .SCD(\u_digital.temp_monitor_control_irq_enable_i ),
    .SCE(scan_en),
    .Q(\u_digital.u_temp_monitor_registers.control_reg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _622_ (.CLK(clk),
    .D(_004_),
    .RESET_B(reset_n),
    .SCD(\u_digital.temp_monitor_control_irq_clear_sample_done_pulse_i ),
    .SCE(scan_en),
    .Q(\u_digital.temp_monitor_control_irq_clear_alert_pulse_i ));
 sky130_fd_sc_hd__sdfrtp_2 _623_ (.CLK(clk),
    .D(_077_),
    .RESET_B(reset_n),
    .SCD(\u_digital.temp_monitor_control_alert_clear_pulse_i ),
    .SCE(scan_en),
    .Q(rd_data[0]));
 sky130_fd_sc_hd__sdfrtp_2 _624_ (.CLK(clk),
    .D(_078_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_registers.control_reg[0] ),
    .SCE(scan_en),
    .Q(rd_data[1]));
 sky130_fd_sc_hd__sdfrtp_2 _625_ (.CLK(clk),
    .D(_079_),
    .RESET_B(reset_n),
    .SCD(\u_digital.u_temp_monitor_registers.control_reg[2] ),
    .SCE(scan_en),
    .Q(rd_data[2]));
 sky130_fd_sc_hd__sdfrtp_2 _626_ (.CLK(clk),
    .D(_080_),
    .RESET_B(reset_n),
    .SCD(\u_digital.temp_monitor_control_irq_clear_alert_pulse_i ),
    .SCE(scan_en),
    .Q(rd_data[3]));
 sky130_fd_sc_hd__sdfrtp_2 _627_ (.CLK(clk),
    .D(_081_),
    .RESET_B(reset_n),
    .SCD(rd_data[0]),
    .SCE(scan_en),
    .Q(rd_data[4]));
 sky130_fd_sc_hd__sdfrtp_2 _628_ (.CLK(clk),
    .D(_082_),
    .RESET_B(reset_n),
    .SCD(rd_data[1]),
    .SCE(scan_en),
    .Q(rd_data[5]));
 sky130_fd_sc_hd__sdfrtp_2 _629_ (.CLK(clk),
    .D(_083_),
    .RESET_B(reset_n),
    .SCD(rd_data[2]),
    .SCE(scan_en),
    .Q(rd_data[6]));
 sky130_fd_sc_hd__sdfrtp_2 _630_ (.CLK(clk),
    .D(_084_),
    .RESET_B(reset_n),
    .SCD(rd_data[3]),
    .SCE(scan_en),
    .Q(rd_data[7]));
 sky130_fd_sc_hd__sdfrtp_2 _631_ (.CLK(clk),
    .D(_085_),
    .RESET_B(reset_n),
    .SCD(rd_data[4]),
    .SCE(scan_en),
    .Q(rd_data[8]));
 sky130_fd_sc_hd__sdfrtp_2 _632_ (.CLK(clk),
    .D(_086_),
    .RESET_B(reset_n),
    .SCD(rd_data[5]),
    .SCE(scan_en),
    .Q(rd_data[9]));
 sky130_fd_sc_hd__sdfrtp_2 _633_ (.CLK(clk),
    .D(_087_),
    .RESET_B(reset_n),
    .SCD(rd_data[6]),
    .SCE(scan_en),
    .Q(rd_data[10]));
 sky130_fd_sc_hd__sdfrtp_2 _634_ (.CLK(clk),
    .D(_088_),
    .RESET_B(reset_n),
    .SCD(rd_data[7]),
    .SCE(scan_en),
    .Q(rd_data[11]));
 sky130_fd_sc_hd__sdfrtp_2 _635_ (.CLK(clk),
    .D(_089_),
    .RESET_B(reset_n),
    .SCD(rd_data[8]),
    .SCE(scan_en),
    .Q(rd_data[12]));
 sky130_fd_sc_hd__sdfrtp_2 _636_ (.CLK(clk),
    .D(_090_),
    .RESET_B(reset_n),
    .SCD(rd_data[9]),
    .SCE(scan_en),
    .Q(rd_data[13]));
 sky130_fd_sc_hd__sdfrtp_2 _637_ (.CLK(clk),
    .D(_091_),
    .RESET_B(reset_n),
    .SCD(rd_data[10]),
    .SCE(scan_en),
    .Q(rd_data[14]));
 sky130_fd_sc_hd__sdfrtp_2 _638_ (.CLK(clk),
    .D(_092_),
    .RESET_B(reset_n),
    .SCD(rd_data[11]),
    .SCE(scan_en),
    .Q(rd_data[15]));
 sky130_fd_sc_hd__sdfrtp_2 _639_ (.CLK(clk),
    .D(\u_digital.u_temp_monitor_registers.threshold_reg[0] ),
    .RESET_B(reset_n),
    .SCD(rd_data[12]),
    .SCE(scan_en),
    .Q(threshold_code[0]));
 sky130_fd_sc_hd__sdfrtp_2 _640_ (.CLK(clk),
    .D(\u_digital.u_temp_monitor_registers.threshold_reg[1] ),
    .RESET_B(reset_n),
    .SCD(rd_data[13]),
    .SCE(scan_en),
    .Q(threshold_code[1]));
 sky130_fd_sc_hd__sdfrtp_2 _641_ (.CLK(clk),
    .D(\u_digital.u_temp_monitor_registers.threshold_reg[2] ),
    .RESET_B(reset_n),
    .SCD(rd_data[14]),
    .SCE(scan_en),
    .Q(threshold_code[2]));
 sky130_fd_sc_hd__sdfrtp_2 _642_ (.CLK(clk),
    .D(\u_digital.u_temp_monitor_registers.threshold_reg[3] ),
    .RESET_B(reset_n),
    .SCD(rd_data[15]),
    .SCE(scan_en),
    .Q(threshold_code[3]));
 sky130_fd_sc_hd__sdfrtp_2 _643_ (.CLK(clk),
    .D(\u_digital.u_temp_monitor_registers.threshold_reg[4] ),
    .RESET_B(reset_n),
    .SCD(threshold_code[0]),
    .SCE(scan_en),
    .Q(threshold_code[4]));
 sky130_fd_sc_hd__sdfrtp_2 _644_ (.CLK(clk),
    .D(\u_digital.u_temp_monitor_registers.threshold_reg[5] ),
    .RESET_B(reset_n),
    .SCD(threshold_code[1]),
    .SCE(scan_en),
    .Q(threshold_code[5]));
 sky130_fd_sc_hd__sdfrtp_2 _645_ (.CLK(clk),
    .D(\u_digital.u_temp_monitor_registers.threshold_reg[6] ),
    .RESET_B(reset_n),
    .SCD(threshold_code[2]),
    .SCE(scan_en),
    .Q(threshold_code[6]));
 sky130_fd_sc_hd__sdfrtp_2 _646_ (.CLK(clk),
    .D(\u_digital.u_temp_monitor_registers.threshold_reg[7] ),
    .RESET_B(reset_n),
    .SCD(threshold_code[3]),
    .SCE(scan_en),
    .Q(threshold_code[7]));
 sky130_fd_sc_hd__sdfrtp_2 _647_ (.CLK(clk),
    .D(\u_digital.u_temp_monitor_registers.threshold_reg[8] ),
    .RESET_B(reset_n),
    .SCD(threshold_code[4]),
    .SCE(scan_en),
    .Q(threshold_code[8]));
 sky130_fd_sc_hd__sdfrtp_2 _648_ (.CLK(clk),
    .D(\u_digital.u_temp_monitor_registers.threshold_reg[9] ),
    .RESET_B(reset_n),
    .SCD(threshold_code[5]),
    .SCE(scan_en),
    .Q(threshold_code[9]));
 sky130_fd_sc_hd__sdfrtp_2 _649_ (.CLK(clk),
    .D(\u_digital.u_temp_monitor_registers.threshold_reg[10] ),
    .RESET_B(reset_n),
    .SCD(threshold_code[6]),
    .SCE(scan_en),
    .Q(threshold_code[10]));
 sky130_fd_sc_hd__sdfrtp_2 _650_ (.CLK(clk),
    .D(\u_digital.u_temp_monitor_registers.threshold_reg[11] ),
    .RESET_B(reset_n),
    .SCD(threshold_code[7]),
    .SCE(scan_en),
    .Q(threshold_code[11]));
 assign scan_out[1] = threshold_code[10];
 assign scan_out[2] = threshold_code[11];
 assign scan_out[3] = threshold_code[8];
 assign scan_out[0] = threshold_code[9];
  // Preserved non-stdcell macro instances omitted by DFT write_verilog.
  temp_sensor_adc_model u_analog (
    .adc_code({ \u_digital.adc_code[11] , \u_digital.adc_code[10] , \u_digital.adc_code[9] , \u_digital.adc_code[8] , \u_digital.adc_code[7] , \u_digital.adc_code[6] , \u_digital.adc_code[5] , \u_digital.adc_code[4] , \u_digital.adc_code[3] , \u_digital.adc_code[2] , \u_digital.adc_code[1] , \u_digital.adc_code[0]  }),
    .adc_valid(\u_digital.adc_valid ),
    .avdd(avdd),
    .avss(avss),
    .sample_req(\u_digital.sample_req ),
    .sensor_temp_celsius(sensor_temp_celsius)
  );
endmodule
