# Logic Equivalence Check

- Status: `inconclusive_missing_sat_models`
- Tool: `yosys`
- Top module: `temp_monitor_soc_phys`
- RTL files: `6`
- Synth netlist: `temp_monitor_soc_phys_synth.v`
- Liberty files discovered: `1`
- Standard-cell Verilog models loaded: `1`
- Standard-cell model strategy: `generated_functional_wrappers_from_gate_netlist`
- Missing standard-cell models: `0`
- Unproven points: `15`
- Unproven signal names: `rd_data[0], rd_data[1]`
- Primary LEC status: `inconclusive_missing_sat_models`
- Primary unproven signal names: `rd_data[0], rd_data[1]`
- Reset-sequence repair: `not_run`
- Return code: `1`
- Failure reason: `equivalence_points_unproven`

If this is inconclusive, inspect `digital/lec/logs/yosys_lec.log` and `digital/lec/lec_summary.json` for unsupported cells, black boxes, reset/initial-state assumptions, or bounded sequential proof limits.
