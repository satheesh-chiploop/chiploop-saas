# Synthesis Readiness Report

- Top: `adaptive_aero_control_top_spi_fpga_top`
- RTL files: `2`
- Score (heuristic): **84/100**

## Timing/Area Intent Checks
- (info) No clocks found in spec. If synchronous, include clock intent (name + freq/period).
- (info) No performance/timing intent section found (latency/throughput/constraints).
- (info) No area/gatecount intent found. Provide rough bounds if needed.

## Synthesizable Subset Red Flags
Found **1** potential issues (showing up to 30):

- `backend/workflows/85fcaab5-7864-447f-9850-9711f4f19e95/fpga/src/handoff/rtl/adaptive_aero_control_top_spi_fpga_top.sv:46` — force/release are not synthesizable.  
  `...// Asynchronous assertion, synchronous release into the core domain....`

## Yosys Synthesis Check
- Return code: `0`
- No Yosys ERROR lines detected.
