# Digital DQA Summary
- workflow_id: `85fcaab5-7864-447f-9850-9711f4f19e95`
- status: `pass`
- rtl files: `2`
- warning count: `0`

## Stage Status
- rtl_lint: `warn`
- cdc: `pass`
- reset_integrity: `pass`
- synthesis_readiness: `pass`
