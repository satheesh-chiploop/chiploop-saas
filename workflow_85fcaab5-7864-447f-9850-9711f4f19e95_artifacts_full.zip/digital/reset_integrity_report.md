{
  "type": "reset_integrity_report",
  "version": "1.0",
  "rtl_file_count": 2,
  "detected_reset_signals": [
    "clk_rst_n",
    "reset_n",
    "reset_sync"
  ],
  "async_reset_blocks": [
    {
      "file": "backend/workflows/85fcaab5-7864-447f-9850-9711f4f19e95/fpga/src/handoff/rtl/adaptive_aero_control_top.v",
      "reset": "clk_rst_n",
      "edge": "negedge"
    }
  ],
  "reset_usage_locations": [
    {
      "file": "backend/workflows/85fcaab5-7864-447f-9850-9711f4f19e95/fpga/src/handoff/rtl/adaptive_aero_control_top.v",
      "reset": "clk_rst_n",
      "context": "if_condition"
    },
    {
      "file": "backend/workflows/85fcaab5-7864-447f-9850-9711f4f19e95/fpga/src/handoff/rtl/adaptive_aero_control_top_spi_fpga_top.sv",
      "reset": "reset_n",
      "context": "if_condition"
    },
    {
      "file": "backend/workflows/85fcaab5-7864-447f-9850-9711f4f19e95/fpga/src/handoff/rtl/adaptive_aero_control_top_spi_fpga_top.sv",
      "reset": "reset_sync",
      "context": "if_condition"
    }
  ],
  "findings": [],
  "recommendations": [
    "Prefer async-assert / sync-deassert reset strategy in multi-clock designs.",
    "Ensure reset deassertion is synchronized per clock domain.",
    "Avoid mixing async and sync reset styles without clear intent.",
    "Add reset-specific assertions: no X after reset release; stable reset sequencing."
  ],
  "note": "Heuristic scan only; use signoff reset/CDC checks in enterprise flows when available."
}