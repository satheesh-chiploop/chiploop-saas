# IP Packaging & Handoff Report

- Top: `status_telemetry`
- Package: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/47eb1f7e-0bd7-4a55-8969-39dfea902902/0b694ed8-8d6f-4980-860e-37b71ddca8b0/digital/arch2tapeout/handoff/status_telemetry_ip_package`
- Zip: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/47eb1f7e-0bd7-4a55-8969-39dfea902902/0b694ed8-8d6f-4980-860e-37b71ddca8b0/digital/arch2tapeout/handoff/status_telemetry_ip_package.zip`

## Bucket counts
- **rtl**: 1
- **spec**: 1
- **arch**: 0
- **microarch**: 0
- **regmap**: 1
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 2
