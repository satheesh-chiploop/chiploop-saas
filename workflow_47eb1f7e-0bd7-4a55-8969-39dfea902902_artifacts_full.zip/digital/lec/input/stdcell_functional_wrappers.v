// Auto-generated functional SKY130 cell wrappers for Yosys LEC.
// Generated from the synthesized netlist's referenced cell/pin set.
module sky130_fd_sc_hd__buf_2(A, X);
  input A;
  output X;
  assign X = A;
endmodule

