# Digital Post-DFT Logic Equivalence Check

- Status: `inconclusive`
- Failure reason: `missing_post_dft_netlist`
- Top module: `status_telemetry`
- Synthesis netlist: `status_telemetry_synth.v`
- Post-DFT netlist: `missing`
- Unproven points: `0`
