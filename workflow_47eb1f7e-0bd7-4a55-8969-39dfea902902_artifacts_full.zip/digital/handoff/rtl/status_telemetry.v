module status_telemetry (
    input clk,
    input reset_n,
    input [2:0] cfg_mode,
    input [15:0] accepted_seq,
    input [7:0] last_fault_code,
    input timeout_active,
    input freshness_fault,
    input sticky_fault,
    input fallback_active,
    input busy,
    output reg [2:0] status_mode,
    output reg [15:0] status_last_seq,
    output reg [7:0] status_last_fault_code,
    output reg status_timeout_status,
    output reg status_freshness_status,
    output reg status_sticky_fault,
    output reg status_fallback_active,
    output reg status_busy
);

reg [511:0] status_store;
reg [511:0] status_store_next;
reg [15:0] seq_shadow;
reg [15:0] seq_shadow_next;
reg [7:0] fault_shadow;
reg [7:0] fault_shadow_next;
reg [2:0] mode_shadow;
reg [2:0] mode_shadow_next;
reg [63:0] seq_history0;
reg [63:0] seq_history1;
reg [63:0] seq_history2;
reg [63:0] seq_history3;
reg [63:0] seq_history4;
reg [63:0] seq_history5;
reg [63:0] seq_history6;
reg [63:0] seq_history7;
reg [63:0] seq_history8;
reg [63:0] seq_history9;
reg [63:0] seq_history10;
reg [63:0] seq_history11;
reg [63:0] seq_history12;
reg [63:0] seq_history13;
reg [63:0] seq_history14;
reg [63:0] seq_history15;
reg [63:0] seq_history16;
reg [63:0] seq_history17;
reg [63:0] seq_history18;
reg [63:0] seq_history19;
reg [63:0] seq_history20;
reg [63:0] seq_history21;
reg [63:0] seq_history22;
reg [63:0] seq_history23;
reg [63:0] seq_history24;
reg [63:0] seq_history25;
reg [63:0] seq_history26;
reg [63:0] seq_history27;
reg [63:0] seq_history28;
reg [63:0] seq_history29;
reg [63:0] seq_history30;
reg [63:0] seq_history31;
reg [63:0] fault_history0;
reg [63:0] fault_history1;
reg [63:0] fault_history2;
reg [63:0] fault_history3;
reg [63:0] fault_history4;
reg [63:0] fault_history5;
reg [63:0] fault_history6;
reg [63:0] fault_history7;

always @(*) begin
    status_store_next = status_store;
    seq_shadow_next = seq_shadow;
    fault_shadow_next = fault_shadow;
    mode_shadow_next = mode_shadow;
    status_mode = mode_shadow;
    status_last_seq = seq_shadow;
    status_last_fault_code = fault_shadow;
    status_timeout_status = timeout_active;
    status_freshness_status = freshness_fault;
    status_sticky_fault = sticky_fault;
    status_fallback_active = fallback_active;
    status_busy = busy;
    status_store_next[2:0] = cfg_mode;
    status_store_next[18:3] = accepted_seq;
    status_store_next[26:19] = last_fault_code;
    status_store_next[27] = timeout_active;
    status_store_next[28] = freshness_fault;
    status_store_next[29] = sticky_fault;
    status_store_next[30] = fallback_active;
    status_store_next[31] = busy;
    mode_shadow_next = cfg_mode;
    seq_shadow_next = accepted_seq;
    fault_shadow_next = last_fault_code;
    status_mode = mode_shadow_next;
    status_last_seq = seq_shadow_next;
    status_last_fault_code = fault_shadow_next;
end

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        status_store <= {512{1'b0}};
        seq_shadow <= 16'h0000;
        fault_shadow <= 8'h00;
        mode_shadow <= 3'b000;
        seq_history0 <= 64'h0000000000000000;
        seq_history1 <= 64'h0000000000000000;
        seq_history2 <= 64'h0000000000000000;
        seq_history3 <= 64'h0000000000000000;
        seq_history4 <= 64'h0000000000000000;
        seq_history5 <= 64'h0000000000000000;
        seq_history6 <= 64'h0000000000000000;
        seq_history7 <= 64'h0000000000000000;
        seq_history8 <= 64'h0000000000000000;
        seq_history9 <= 64'h0000000000000000;
        seq_history10 <= 64'h0000000000000000;
        seq_history11 <= 64'h0000000000000000;
        seq_history12 <= 64'h0000000000000000;
        seq_history13 <= 64'h0000000000000000;
        seq_history14 <= 64'h0000000000000000;
        seq_history15 <= 64'h0000000000000000;
        seq_history16 <= 64'h0000000000000000;
        seq_history17 <= 64'h0000000000000000;
        seq_history18 <= 64'h0000000000000000;
        seq_history19 <= 64'h0000000000000000;
        seq_history20 <= 64'h0000000000000000;
        seq_history21 <= 64'h0000000000000000;
        seq_history22 <= 64'h0000000000000000;
        seq_history23 <= 64'h0000000000000000;
        seq_history24 <= 64'h0000000000000000;
        seq_history25 <= 64'h0000000000000000;
        seq_history26 <= 64'h0000000000000000;
        seq_history27 <= 64'h0000000000000000;
        seq_history28 <= 64'h0000000000000000;
        seq_history29 <= 64'h0000000000000000;
        seq_history30 <= 64'h0000000000000000;
        seq_history31 <= 64'h0000000000000000;
        fault_history0 <= 64'h0000000000000000;
        fault_history1 <= 64'h0000000000000000;
        fault_history2 <= 64'h0000000000000000;
        fault_history3 <= 64'h0000000000000000;
        fault_history4 <= 64'h0000000000000000;
        fault_history5 <= 64'h0000000000000000;
        fault_history6 <= 64'h0000000000000000;
        fault_history7 <= 64'h0000000000000000;
    end else begin
        status_store <= status_store_next;
        seq_shadow <= seq_shadow_next;
        fault_shadow <= fault_shadow_next;
        mode_shadow <= mode_shadow_next;
        seq_history0 <= {48'h000000000000, accepted_seq};
        seq_history1 <= seq_history0;
        seq_history2 <= seq_history1;
        seq_history3 <= seq_history2;
        seq_history4 <= seq_history3;
        seq_history5 <= seq_history4;
        seq_history6 <= seq_history5;
        seq_history7 <= seq_history6;
        seq_history8 <= seq_history7;
        seq_history9 <= seq_history8;
        seq_history10 <= seq_history9;
        seq_history11 <= seq_history10;
        seq_history12 <= seq_history11;
        seq_history13 <= seq_history12;
        seq_history14 <= seq_history13;
        seq_history15 <= seq_history14;
        seq_history16 <= seq_history15;
        seq_history17 <= seq_history16;
        seq_history18 <= seq_history17;
        seq_history19 <= seq_history18;
        seq_history20 <= seq_history19;
        seq_history21 <= seq_history20;
        seq_history22 <= seq_history21;
        seq_history23 <= seq_history22;
        seq_history24 <= seq_history23;
        seq_history25 <= seq_history24;
        seq_history26 <= seq_history25;
        seq_history27 <= seq_history26;
        seq_history28 <= seq_history27;
        seq_history29 <= seq_history28;
        seq_history30 <= seq_history29;
        seq_history31 <= seq_history30;
        fault_history0 <= {56'h00000000000000, last_fault_code};
        fault_history1 <= fault_history0;
        fault_history2 <= fault_history1;
        fault_history3 <= fault_history2;
        fault_history4 <= fault_history3;
        fault_history5 <= fault_history4;
        fault_history6 <= fault_history5;
        fault_history7 <= fault_history6;
    end
end

endmodule
