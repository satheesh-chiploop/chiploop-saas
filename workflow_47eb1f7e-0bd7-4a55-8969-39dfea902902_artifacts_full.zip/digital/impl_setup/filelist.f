/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/47eb1f7e-0bd7-4a55-8969-39dfea902902/0b694ed8-8d6f-4980-860e-37b71ddca8b0/digital/arch2tapeout/handoff/rtl/status_telemetry.v
