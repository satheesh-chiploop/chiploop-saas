# Digital Synthesis Summary

- **Workflow**: 47eb1f7e-0bd7-4a55-8969-39dfea902902
- **Status**: `ok` (rc=0)
- **Top module**: `status_telemetry`
- **Clock**: `clk` @ **10.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/47eb1f7e-0bd7-4a55-8969-39dfea902902/0b694ed8-8d6f-4980-860e-37b71ddca8b0/digital/arch2tapeout/digital/synth/runs/Digital_Arch2Tapeout_47eb1f7e-0bd7-4a55-8969-39dfea902902/final/metrics.json`
- netlist candidates: 1 found
