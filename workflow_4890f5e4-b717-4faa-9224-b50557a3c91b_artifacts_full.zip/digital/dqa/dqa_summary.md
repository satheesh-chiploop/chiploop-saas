# Digital DQA Summary
- workflow_id: `4890f5e4-b717-4faa-9224-b50557a3c91b`
- status: `pass`
- rtl files: `2`
- warning count: `0`

## Stage Status
- rtl_lint: `warn`
- cdc: `pass`
- reset_integrity: `pass`
- synthesis_readiness: `pass`
