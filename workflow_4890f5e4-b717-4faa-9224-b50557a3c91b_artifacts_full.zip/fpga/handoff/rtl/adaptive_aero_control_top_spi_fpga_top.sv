// Auto-generated FPGA-only serialized transport shell.
// The verified core RTL remains unchanged; ASIC flows continue to use the core top.
module adaptive_aero_control_top_spi_fpga_top (
  input  logic clk,
  input  logic reset_n,
  input  logic spi_sclk,
  input  logic spi_cs_n,
  input  logic spi_mosi,
  output logic spi_miso,
  output logic fault_indicator
);
  localparam integer INPUT_BITS = 206;
  localparam integer OUTPUT_BITS = 255;
  logic [INPUT_BITS-1:0] rx_shift, rx_active;
  logic [OUTPUT_BITS-1:0] tx_shift, tx_snapshot;
  logic spi_active;
  logic spi_cs_meta, spi_cs_sync, spi_cs_prev;
  logic [7:0] core_csr_addr;
  logic [63:0] core_csr_wdata;
  logic core_csr_we;
  logic core_csr_re;
  logic core_csr_valid;
  logic core_req_ready;
  logic [127:0] core_rsp_data;
  logic core_rsp_valid;
  logic core_actuator_cmd_ready;
  wire [63:0] core_csr_rdata;
  wire core_csr_ready;
  wire [127:0] core_req_data;
  wire core_req_valid;
  wire core_rsp_ready;
  wire [31:0] core_actuator_cmd_data;
  wire core_actuator_cmd_valid;
  wire core_fault_irq;
  wire core_cfg_enable;
  wire core_cfg_bypass;
  wire core_cfg_fallback_mode;
  wire core_cfg_clear_faults;
  wire core_request_timeout_cycles;
  wire core_stale_timeout_cycles;
  wire core_response_age_limit;
  wire core_tx_seq;
  wire core_rx_seq_expected;
  wire core_last_good_seq;
  wire core_cmd_min;
  wire core_cmd_max;
  wire core_slew_limit;
  wire core_stream_velocity_mps_ref;
  wire core_operating_window_min;
  wire core_operating_window_max;
  wire core_model_request_type;
  wire core_model_selector;
  wire core_flow_condition_summary;
  wire core_geometry_handle;
  wire core_response_status;
  wire core_response_freshness;
  wire core_surrogate_drag_summary;
  wire core_surrogate_lift_summary;
  wire core_surrogate_pressure_summary;
  wire core_last_fault_code;
  assign core_csr_addr = rx_active[0 +: 8];
  assign core_csr_wdata = rx_active[8 +: 64];
  assign core_csr_we = rx_active[72 +: 1];
  assign core_csr_re = rx_active[73 +: 1];
  assign core_csr_valid = rx_active[74 +: 1];
  assign core_req_ready = rx_active[75 +: 1];
  assign core_rsp_data = rx_active[76 +: 128];
  assign core_rsp_valid = rx_active[204 +: 1];
  assign core_actuator_cmd_ready = rx_active[205 +: 1];
  wire [OUTPUT_BITS-1:0] core_response = {core_csr_rdata, core_csr_ready, core_req_data, core_req_valid, core_rsp_ready, core_actuator_cmd_data, core_actuator_cmd_valid, core_fault_irq, core_cfg_enable, core_cfg_bypass, core_cfg_fallback_mode, core_cfg_clear_faults, core_request_timeout_cycles, core_stale_timeout_cycles, core_response_age_limit, core_tx_seq, core_rx_seq_expected, core_last_good_seq, core_cmd_min, core_cmd_max, core_slew_limit, core_stream_velocity_mps_ref, core_operating_window_min, core_operating_window_max, core_model_request_type, core_model_selector, core_flow_condition_summary, core_geometry_handle, core_response_status, core_response_freshness, core_surrogate_drag_summary, core_surrogate_lift_summary, core_surrogate_pressure_summary, core_last_fault_code};
  assign fault_indicator = 1'b0;
  // Chip select asynchronously clears only the frame-state bit. Data
  // registers use SPI clock alone, which is legal in ECP5 fabric.
  always_ff @(posedge spi_sclk or posedge spi_cs_n) begin
    if (spi_cs_n) spi_active <= 1'b0;
    else spi_active <= 1'b1;
  end
  always_ff @(posedge spi_sclk) begin
    if (!spi_cs_n) begin
      rx_shift <= {rx_shift[204:0], spi_mosi};
      if (!spi_active) tx_shift <= {tx_snapshot[253:0], 1'b0};
      else tx_shift <= {tx_shift[253:0], 1'b0};
    end
  end
  // Synchronize frame completion into the core clock domain. The host
  // keeps MOSI stable around CS rising as required by the protocol.
  always_ff @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
      spi_cs_meta <= 1'b1; spi_cs_sync <= 1'b1; spi_cs_prev <= 1'b1;
      rx_active <= '0; tx_snapshot <= '0;
    end else begin
      spi_cs_meta <= spi_cs_n; spi_cs_sync <= spi_cs_meta; spi_cs_prev <= spi_cs_sync;
      if (spi_cs_sync && !spi_cs_prev) rx_active <= rx_shift;
      tx_snapshot <= core_response;
    end
  end
  always_comb spi_miso = spi_active ? tx_shift[OUTPUT_BITS-1] : tx_snapshot[OUTPUT_BITS-1];
  adaptive_aero_control_top u_core (
    .clk(clk),
    .rst_n(reset_n),
    .csr_addr(core_csr_addr),
    .csr_wdata(core_csr_wdata),
    .csr_rdata(core_csr_rdata),
    .csr_we(core_csr_we),
    .csr_re(core_csr_re),
    .csr_valid(core_csr_valid),
    .csr_ready(core_csr_ready),
    .req_data(core_req_data),
    .req_valid(core_req_valid),
    .req_ready(core_req_ready),
    .rsp_data(core_rsp_data),
    .rsp_valid(core_rsp_valid),
    .rsp_ready(core_rsp_ready),
    .actuator_cmd_data(core_actuator_cmd_data),
    .actuator_cmd_valid(core_actuator_cmd_valid),
    .actuator_cmd_ready(core_actuator_cmd_ready),
    .fault_irq(core_fault_irq),
    .cfg_enable(core_cfg_enable),
    .cfg_bypass(core_cfg_bypass),
    .cfg_fallback_mode(core_cfg_fallback_mode),
    .cfg_clear_faults(core_cfg_clear_faults),
    .request_timeout_cycles(core_request_timeout_cycles),
    .stale_timeout_cycles(core_stale_timeout_cycles),
    .response_age_limit(core_response_age_limit),
    .tx_seq(core_tx_seq),
    .rx_seq_expected(core_rx_seq_expected),
    .last_good_seq(core_last_good_seq),
    .cmd_min(core_cmd_min),
    .cmd_max(core_cmd_max),
    .slew_limit(core_slew_limit),
    .stream_velocity_mps_ref(core_stream_velocity_mps_ref),
    .operating_window_min(core_operating_window_min),
    .operating_window_max(core_operating_window_max),
    .model_request_type(core_model_request_type),
    .model_selector(core_model_selector),
    .flow_condition_summary(core_flow_condition_summary),
    .geometry_handle(core_geometry_handle),
    .response_status(core_response_status),
    .response_freshness(core_response_freshness),
    .surrogate_drag_summary(core_surrogate_drag_summary),
    .surrogate_lift_summary(core_surrogate_lift_summary),
    .surrogate_pressure_summary(core_surrogate_pressure_summary),
    .last_fault_code(core_last_fault_code)
  );
endmodule
