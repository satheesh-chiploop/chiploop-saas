# IP Packaging & Handoff Report

- Top: `imported_from_arch2rtl`
- Package: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/7f185974-4d77-40cf-bfbd-fffe81ed4643/dbaa3987-c404-4201-8bfa-c210a88255ed/digital/arch2synthesis/handoff/imported_from_arch2rtl_ip_package`
- Zip: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/7f185974-4d77-40cf-bfbd-fffe81ed4643/dbaa3987-c404-4201-8bfa-c210a88255ed/digital/arch2synthesis/handoff/imported_from_arch2rtl_ip_package.zip`

## Bucket counts
- **rtl**: 3
- **spec**: 1
- **arch**: 0
- **microarch**: 0
- **regmap**: 1
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 2
