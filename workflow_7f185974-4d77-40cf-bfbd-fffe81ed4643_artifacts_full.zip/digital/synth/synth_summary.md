# Digital Synthesis Summary

- **Workflow**: 7f185974-4d77-40cf-bfbd-fffe81ed4643
- **Status**: `ok` (rc=0)
- **Top module**: `sram_mbist_demo_controller`
- **Clock**: `clk` @ **9.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/7f185974-4d77-40cf-bfbd-fffe81ed4643/dbaa3987-c404-4201-8bfa-c210a88255ed/digital/arch2synthesis/digital/synth/runs/Digital_Arch2Synthesis_7f185974-4d77-40cf-bfbd-fffe81ed4643/final/metrics.json`
- netlist candidates: 2 found
