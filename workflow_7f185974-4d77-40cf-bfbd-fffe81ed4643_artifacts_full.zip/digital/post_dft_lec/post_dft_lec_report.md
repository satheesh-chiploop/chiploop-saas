# Digital Post-DFT Logic Equivalence Check

- Status: `inconclusive`
- Failure reason: `missing_stdcell_models_for_post_dft_lec`
- Top module: `sram_mbist_demo_controller`
- Synthesis netlist: `sram_mbist_demo_controller_synth.v`
- Post-DFT netlist: `scan_stitched_netlist.v`
- Unproven points: `0`
