# Simulation Summary + Coverage

- Total simulation runs: 12
- Simulation pass count: 8
- Simulation fail count: 4
- Root failure class: behavioral_assertion
- Coverage status: ok
- Functional coverage %: 85.71
- Coverage bins hit: 12
- Coverage total bins: 14
- Functional bin gaps: 2
- Code line coverage: 46.99%
- Code branch coverage: 100.0%
- Code condition coverage: unavailable_from_verilator_lcov
- Code toggle coverage: 73.08%
- SVA/assertion status: failed
- SVA/assertion pass %: 76.92%
- Formal status: not_enabled
- Golden model status: not_enabled
- Simulator tool: verilator
- Code coverage tool: verilator_coverage
- Formal tool: none
- Golden model tool: none

## Functional Coverage Not Met
- inputs.clk: bins 1/2, missing zero, seen values [1]
- inputs.reset_n: bins 1/2, missing zero, seen values [1]
