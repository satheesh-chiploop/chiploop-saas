# System Simulation Execution Report

- Top: `temp_monitor_soc_sim`
- Tests run: 6
- Passed: 0
- Failed: 6
- Total runtime (s): 12.636
- Coverage JSON present: False
- Coverage MD present: False

## Run Matrix
- `system_smoke_test` / seed `1` → FAIL (rc=2, 5.699s)
- `system_smoke_test` / seed `2` → FAIL (rc=2, 1.379s)
- `system_smoke_test` / seed `7` → FAIL (rc=2, 1.402s)
- `integrated_input_sanity` / seed `1` → FAIL (rc=2, 1.432s)
- `integrated_input_sanity` / seed `2` → FAIL (rc=2, 1.316s)
- `integrated_input_sanity` / seed `7` → FAIL (rc=2, 1.408s)
