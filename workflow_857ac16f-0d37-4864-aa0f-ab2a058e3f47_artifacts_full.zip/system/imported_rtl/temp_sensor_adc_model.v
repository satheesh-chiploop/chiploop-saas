module temp_sensor_adc_model (
    input  sample_req,
    input  [15:0] sensor_temp_celsius,
    input  avdd,
    input  avss,
    output reg [11:0] adc_code,
    output reg adc_valid
);

    parameter integer SAMPLE_LATENCY_P  = 2;
    parameter integer GAIN_ERROR_PPM    = 1000000;
    parameter integer OFFSET_ERROR_CODE = 0;
    parameter integer DEFAULT_CODE       = 0;

    localparam integer NOMINAL_OFFSET = 2048;
    localparam integer GAIN_PPM_BASE   = 1000000;
    localparam integer MIN_CODE        = 0;
    localparam integer MAX_CODE        = 4095;

    reg sample_in_progress;
    reg [3:0] sample_timer;
    reg [11:0] latched_adc_code;
    reg latched_valid;

    reg [31:0] temp_unsigned;
    reg signed [31:0] temp_centered;
    reg signed [63:0] scaled_value;
    reg signed [63:0] gain_adjusted;
    reg signed [63:0] offset_adjusted;
    reg signed [63:0] computed_code;
    reg [11:0] clamped_code;
    reg [3:0] latency_cfg;

    always @(*) begin
        latency_cfg = 4'd0;
        if (SAMPLE_LATENCY_P <= 0)
            latency_cfg = 4'd0;
        else if (SAMPLE_LATENCY_P > 15)
            latency_cfg = 4'd15;
        else
            latency_cfg = SAMPLE_LATENCY_P[3:0];
    end

    always @(*) begin
        temp_unsigned   = {16'd0, sensor_temp_celsius};
        temp_centered   = $signed({1'b0, temp_unsigned[15:0]}) - 32'sd32768;
        scaled_value    = temp_centered;
        gain_adjusted   = (scaled_value * GAIN_ERROR_PPM) / GAIN_PPM_BASE;
        offset_adjusted = gain_adjusted + OFFSET_ERROR_CODE;
        computed_code   = offset_adjusted + NOMINAL_OFFSET;

        if (computed_code < MIN_CODE)
            clamped_code = 12'd0;
        else if (computed_code > MAX_CODE)
            clamped_code = 12'd4095;
        else
            clamped_code = computed_code[11:0];
    end

    always @(posedge sample_req or posedge avdd or posedge avss) begin
        if (sample_req) begin
            sample_in_progress <= 1'b1;
        end
        else begin
            sample_in_progress <= sample_in_progress;
        end
    end

    always @(posedge sample_req) begin
        if (sample_req) begin
            sample_timer <= latency_cfg;
        end
    end

    always @(posedge sample_req) begin
        if (sample_req) begin
            latched_adc_code <= clamped_code;
        end
    end

    always @(posedge sample_req) begin
        if (sample_req) begin
            latched_valid <= 1'b0;
        end
    end

    always @(*) begin
        adc_code  = DEFAULT_CODE[11:0];
        adc_valid = 1'b0;

        if (sample_in_progress) begin
            adc_code = latched_adc_code;
            if (latched_valid)
                adc_valid = 1'b1;
            else
                adc_valid = 1'b0;
        end
        else begin
            adc_code = DEFAULT_CODE[11:0];
            adc_valid = 1'b0;
        end
    end

endmodule
