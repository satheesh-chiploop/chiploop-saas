module temp_monitor_digital (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    adc_code,
    adc_valid,
    rd_data,
    sample_req,
    alert_irq,
    temp_code,
    threshold_code,
    alert_status
);

input clk;
input reset_n;
input wr_en;
input [7:0] wr_addr;
input [15:0] wr_data;
input rd_en;
input [7:0] rd_addr;
input [11:0] adc_code;
input adc_valid;

output [15:0] rd_data;
output sample_req;
output alert_irq;
output [11:0] temp_code;
output [11:0] threshold_code;
output alert_status;

reg [15:0] rd_data_r;
reg sample_req_r;
reg alert_irq_r;
reg [11:0] temp_code_r;
reg [11:0] threshold_code_r;
reg alert_status_r;

reg control_enable;
reg control_irq_enable;

reg status_sample_done;
reg status_alert_pending;
reg status_adc_valid_seen;
reg status_busy;

reg irq_status_alert;
reg irq_status_sample_done;

reg [15:0] sample_count;
reg [11:0] adc_sample_prev;
reg [12:0] avg_sum;
reg [11:0] adc_filtered;
reg requested_sample_pending;

wire sample_start_pulse;
wire alert_clear_pulse;
wire irq_clear_alert_pulse;
wire irq_clear_sample_done_pulse;
wire any_status_irq;
wire [15:0] control_readback;
wire [15:0] status_readback;
wire [15:0] threshold_readback;
wire [15:0] latest_temp_readback;
wire [15:0] sample_count_readback;
wire [15:0] irq_status_readback;

assign sample_req = sample_req_r;
assign alert_irq = alert_irq_r;
assign temp_code = temp_code_r;
assign threshold_code = threshold_code_r;
assign alert_status = alert_status_r;
assign rd_data = rd_data_r;

assign sample_start_pulse = wr_en & (wr_addr == 8'h00) & wr_data[1];
assign alert_clear_pulse = wr_en & (wr_addr == 8'h00) & wr_data[3];
assign irq_clear_alert_pulse = wr_en & (wr_addr == 8'h18) & wr_data[0];
assign irq_clear_sample_done_pulse = wr_en & (wr_addr == 8'h18) & wr_data[1];

assign any_status_irq = irq_status_alert | irq_status_sample_done;

assign control_readback = {12'h000, control_irq_enable, 1'b0, control_enable, 1'b0};
assign status_readback = {12'h000, status_busy, status_adc_valid_seen, status_alert_pending, status_sample_done};
assign threshold_readback = {4'h0, threshold_code_r};
assign latest_temp_readback = {4'h0, temp_code_r};
assign sample_count_readback = sample_count;
assign irq_status_readback = {14'h0000, irq_status_sample_done, irq_status_alert};

always @(*) begin
    rd_data_r = 16'h0000;
    alert_irq_r = 1'b0;
    if (rd_en) begin
        case (rd_addr)
            8'h00: rd_data_r = control_readback;
            8'h04: rd_data_r = status_readback;
            8'h08: rd_data_r = threshold_readback;
            8'h0C: rd_data_r = latest_temp_readback;
            8'h10: rd_data_r = sample_count_readback;
            8'h14: rd_data_r = irq_status_readback;
            8'h18: rd_data_r = 16'h0000;
            default: rd_data_r = 16'h0000;
        endcase
    end
    if (control_enable) begin
    end
    if (sample_start_pulse) begin
    end
    if (control_irq_enable && any_status_irq) begin
        alert_irq_r = 1'b1;
    end
end

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        control_enable <= 1'b0;
        control_irq_enable <= 1'b0;
        status_sample_done <= 1'b0;
        status_alert_pending <= 1'b0;
        status_adc_valid_seen <= 1'b0;
        status_busy <= 1'b0;
        irq_status_alert <= 1'b0;
        irq_status_sample_done <= 1'b0;
        sample_count <= 16'h0000;
        adc_sample_prev <= 12'h000;
        avg_sum <= 13'h0000;
        adc_filtered <= 12'h000;
        requested_sample_pending <= 1'b0;
        temp_code_r <= 12'h000;
        threshold_code_r <= 12'h000;
        alert_status_r <= 1'b0;
    end else begin
        sample_req_r <= sample_req_r;
        if (wr_en) begin
            case (wr_addr)
                8'h00: begin
                    control_enable <= wr_data[0];
                    control_irq_enable <= wr_data[2];
                    if (wr_data[3]) begin
                        alert_status_r <= 1'b0;
                        status_alert_pending <= 1'b0;
                        irq_status_alert <= 1'b0;
                    end
                    if (wr_data[1]) begin
                        requested_sample_pending <= 1'b1;
                    end
                end
                8'h08: begin
                    threshold_code_r <= wr_data[11:0];
                end
                8'h18: begin
                    if (wr_data[0]) begin
                        irq_status_alert <= 1'b0;
                        alert_status_r <= 1'b0;
                        status_alert_pending <= 1'b0;
                    end
                    if (wr_data[1]) begin
                        irq_status_sample_done <= 1'b0;
                        status_sample_done <= 1'b0;
                    end
                end
                default: begin
                end
            endcase
        end

        if (alert_clear_pulse) begin
            alert_status_r <= 1'b0;
            status_alert_pending <= 1'b0;
            irq_status_alert <= 1'b0;
        end

        if (irq_clear_alert_pulse) begin
            irq_status_alert <= 1'b0;
            alert_status_r <= 1'b0;
            status_alert_pending <= 1'b0;
        end

        if (irq_clear_sample_done_pulse) begin
            irq_status_sample_done <= 1'b0;
            status_sample_done <= 1'b0;
        end

        if (sample_start_pulse) begin
            requested_sample_pending <= 1'b1;
        end

        if (adc_valid) begin
            status_adc_valid_seen <= 1'b1;
            status_sample_done <= 1'b1;
            irq_status_sample_done <= 1'b1;
            sample_count <= sample_count + 16'h0001;
            if (requested_sample_pending) begin
                requested_sample_pending <= 1'b0;
            end
            avg_sum <= {1'b0, adc_sample_prev} + {1'b0, adc_code};
            adc_filtered <= (adc_sample_prev + adc_code) >> 1;
            adc_sample_prev <= adc_code;
            temp_code_r <= (adc_sample_prev + adc_code) >> 1;
            if (((adc_sample_prev + adc_code) >> 1) > threshold_code_r) begin
                alert_status_r <= 1'b1;
                status_alert_pending <= 1'b1;
                irq_status_alert <= 1'b1;
            end
        end

        if (control_enable && !requested_sample_pending) begin
            requested_sample_pending <= 1'b1;
        end

        status_busy <= requested_sample_pending;
    end
end

endmodule
