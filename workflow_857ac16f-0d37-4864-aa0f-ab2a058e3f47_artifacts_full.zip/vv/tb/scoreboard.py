"""Auto-generated system-level scoreboard for temp_monitor_soc_sim.

This is intentionally conservative: it records DUT observations and compares only
signals that a generated or user-authored golden model returns. The default
golden_model() returns an empty expectation set, so enabling golden model support
never invents pass/fail claims.
"""

import json
import os
from dataclasses import dataclass
from typing import Any, Dict, List

import cocotb
from cocotb.triggers import RisingEdge, Timer

TOP = "temp_monitor_soc_sim"
CLK = "clk"
INPUT_PORTS = [
  "avdd",
  "avss",
  "clk",
  "rd_addr",
  "rd_en",
  "rst_n",
  "wr_addr",
  "wr_data",
  "wr_en"
]
OUTPUT_PORTS = [
  "alert_irq",
  "alert_status",
  "rd_data",
  "sample_req",
  "temp_code",
  "threshold_code"
]


@dataclass
class Txn:
    inputs: Dict[str, int]
    outputs: Dict[str, int]
    time_ns: int


def golden_model(txn: Txn) -> Dict[str, int]:
    """Return expected output values keyed by output port name."""
    return {}


class Scoreboard:
    def __init__(self, dut):
        self.dut = dut
        self.enabled = False
        self.samples = 0
        self.mismatches: List[Dict[str, Any]] = []

    def start(self):
        self.enabled = True
        cocotb.start_soon(self._run())

    def stop(self):
        self.enabled = False
        self._write_report()

    async def _run(self):
        while self.enabled:
            if CLK and hasattr(self.dut, CLK):
                await RisingEdge(getattr(self.dut, CLK))
            else:
                await Timer(10, units="ns")
            self.observe()

    def _read_int(self, name: str):
        try:
            return int(getattr(self.dut, name).value)
        except Exception:
            return None

    def _snapshot(self) -> Txn:
        inputs = {name: value for name in INPUT_PORTS if (value := self._read_int(name)) is not None}
        outputs = {name: value for name in OUTPUT_PORTS if (value := self._read_int(name)) is not None}
        return Txn(inputs=inputs, outputs=outputs, time_ns=0)

    def observe(self):
        if not self.enabled:
            return
        txn = self._snapshot()
        self.samples += 1
        expected = golden_model(txn)
        if not isinstance(expected, dict):
            return
        for name, exp in expected.items():
            obs = txn.outputs.get(name)
            if obs is None:
                continue
            try:
                exp_i = int(exp)
                obs_i = int(obs)
            except Exception:
                continue
            if exp_i != obs_i:
                self.mismatches.append({
                    "signal": name,
                    "expected": exp_i,
                    "observed": obs_i,
                    "inputs": txn.inputs,
                })

    def _write_report(self):
        reports_dir = os.path.join(os.path.dirname(__file__), "reports")
        os.makedirs(reports_dir, exist_ok=True)
        report = {
            "type": "system_golden_model_scoreboard",
            "top_module": TOP,
            "status": "pass" if not self.mismatches else "fail",
            "samples": self.samples,
            "mismatch_count": len(self.mismatches),
            "mismatches": self.mismatches[:200],
            "model": "chiploop_python_scoreboard",
        }
        with open(os.path.join(reports_dir, "scoreboard_report.json"), "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2)
