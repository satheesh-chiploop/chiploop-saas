module sram_mbist_demo_controller (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    bist_start,
    rd_data,
    ready,
    bist_done,
    bist_fail,
    irq,
    sram_csb,
    sram_web,
    sram_addr,
    sram_din,
    sram_dout
);
input clk;
input reset_n;
input wr_en;
input [7:0] wr_addr;
input [31:0] wr_data;
input rd_en;
input [7:0] rd_addr;
input bist_start;
output [31:0] rd_data;
output ready;
output bist_done;
output bist_fail;
output irq;
output sram_csb;
output sram_web;
output [7:0] sram_addr;
output [31:0] sram_din;
input [31:0] sram_dout;
reg [31:0] control_reg;
reg [31:0] mem_addr_reg;
reg [31:0] mem_wdata_reg;
reg [31:0] mem_rdata_reg;
reg [31:0] mem_control_reg;
reg [31:0] bist_control_reg;
reg [31:0] bist_status_reg;
reg [31:0] irq_status_reg;
reg [31:0] rd_data_r;
reg ready_r;
reg bist_done_r;
reg bist_fail_r;
reg irq_r;
reg [7:0] last_fail_addr_r;
reg bist_running_r;

reg sram_csb_r;
reg sram_web_r;
reg [7:0] sram_addr_r;
reg [31:0] sram_din_r;
wire mem_access_en;
wire mem_write_req;
wire mem_read_req;
wire bist_start_req;
wire bist_clear_req;
wire irq_enable;
wire global_enable;
wire soft_reset_req;
wire [31:0] status_reg;
wire [31:0] bist_status_view;
wire [31:0] irq_status_view;
wire [31:0] rd_mux;

assign rd_data = rd_data_r;
assign ready = ready_r;
assign bist_done = bist_done_r;
assign bist_fail = bist_fail_r;
assign irq = irq_r;
assign sram_csb = sram_csb_r;
assign sram_web = sram_web_r;
assign sram_addr = sram_addr_r;
assign sram_din = sram_din_r;

assign global_enable = control_reg[0];
assign soft_reset_req = control_reg[1];
assign irq_enable = control_reg[2];
assign mem_write_req = mem_control_reg[0];
assign mem_read_req = mem_control_reg[1];
assign bist_start_req = bist_control_reg[0] | bist_start;
assign bist_clear_req = bist_control_reg[1];
assign mem_access_en = global_enable & ~bist_running_r;

assign status_reg = {28'b0000000000000000000000000000, bist_running_r, bist_fail_r, bist_done_r, ready_r};
assign bist_status_view = {16'b0000000000000000, last_fail_addr_r, 5'b00000, bist_running_r, bist_fail_r, bist_done_r, 8'b00000000};
assign irq_status_view = {30'b000000000000000000000000000000, irq_status_reg[1:0]};

assign rd_mux =
    (rd_addr == 8'h00) ? control_reg :
    (rd_addr == 8'h04) ? status_reg :
    (rd_addr == 8'h08) ? mem_addr_reg :
    (rd_addr == 8'h0C) ? mem_wdata_reg :
    (rd_addr == 8'h10) ? mem_rdata_reg :
    (rd_addr == 8'h14) ? mem_control_reg :
    (rd_addr == 8'h18) ? bist_control_reg :
    (rd_addr == 8'h1C) ? bist_status_view :
    (rd_addr == 8'h20) ? irq_status_view :
    32'h00000000;

always @(posedge clk) begin
    if (!reset_n) begin
        control_reg <= 32'h00000000;
        mem_addr_reg <= 32'h00000000;
        mem_wdata_reg <= 32'h00000000;
        mem_rdata_reg <= 32'h00000000;
        mem_control_reg <= 32'h00000000;
        bist_control_reg <= 32'h00000000;
        bist_status_reg <= 32'h00000000;
        irq_status_reg <= 32'h00000000;
        rd_data_r <= 32'h00000000;
        ready_r <= 1'b0;
        bist_done_r <= 1'b0;
        bist_fail_r <= 1'b0;
        irq_r <= 1'b0;
        last_fail_addr_r <= 8'h00;
        bist_running_r <= 1'b0;
        sram_csb_r <= 1'b1;
        sram_web_r <= 1'b1;
        sram_addr_r <= 8'h00;
        sram_din_r <= 32'h00000000;
    end else begin
        if (soft_reset_req) begin
            control_reg <= 32'h00000000;
            mem_control_reg <= 32'h00000000;
            bist_control_reg <= 32'h00000000;
            irq_status_reg <= 32'h00000000;
            bist_done_r <= 1'b0;
            bist_fail_r <= 1'b0;
            irq_r <= 1'b0;
            bist_running_r <= 1'b0;
            last_fail_addr_r <= 8'h00;
        end

        if (wr_en) begin
            if (wr_addr == 8'h00) control_reg <= wr_data;
            else if (wr_addr == 8'h08) mem_addr_reg <= wr_data;
            else if (wr_addr == 8'h0C) mem_wdata_reg <= wr_data;
            else if (wr_addr == 8'h14) mem_control_reg <= wr_data;
            else if (wr_addr == 8'h18) bist_control_reg <= wr_data;
            else if (wr_addr == 8'h20) irq_status_reg <= (irq_status_reg & ~wr_data[1:0]) | (wr_data[1:0] & wr_data[1:0]);
            else if (wr_addr == 8'h24) irq_status_reg <= irq_status_reg & ~wr_data[1:0];
        end

        if (bist_clear_req) begin
            bist_done_r <= 1'b0;
            bist_fail_r <= 1'b0;
            irq_status_reg <= 32'h00000000;
            irq_r <= 1'b0;
        end

        if (bist_start_req && global_enable && !bist_running_r) begin
            bist_running_r <= 1'b1;
            ready_r <= 1'b0;
            bist_done_r <= 1'b0;
            bist_fail_r <= 1'b0;
            irq_r <= 1'b0;
            last_fail_addr_r <= 8'h00;
        end

        if (mem_access_en) begin
            if (mem_write_req) begin
                sram_csb_r <= 1'b0;
                sram_web_r <= 1'b0;
                sram_addr_r <= mem_addr_reg[7:0];
                sram_din_r <= mem_wdata_reg;
                mem_rdata_reg <= sram_dout;
            end else if (mem_read_req) begin
                sram_csb_r <= 1'b0;
                sram_web_r <= 1'b1;
                sram_addr_r <= mem_addr_reg[7:0];
                sram_din_r <= mem_wdata_reg;
                mem_rdata_reg <= sram_dout;
            end else begin
                sram_csb_r <= 1'b1;
                sram_web_r <= 1'b1;
                sram_addr_r <= mem_addr_reg[7:0];
                sram_din_r <= mem_wdata_reg;
            end
        end else begin
            sram_csb_r <= 1'b1;
            sram_web_r <= 1'b1;
            sram_addr_r <= mem_addr_reg[7:0];
            sram_din_r <= mem_wdata_reg;
        end

        if (bist_running_r) begin
            bist_running_r <= 1'b0;
            bist_done_r <= 1'b1;
            bist_fail_r <= 1'b0;
            ready_r <= 1'b1;
            irq_status_reg[0] <= 1'b1;
            if (irq_enable) begin
                irq_r <= 1'b1;
            end
        end

        if (bist_done_r | bist_fail_r) begin
            ready_r <= 1'b1;
        end

        rd_data_r <= rd_mux;
        bist_status_reg <= {16'b0000000000000000, last_fail_addr_r, 5'b00000, bist_running_r, bist_fail_r, bist_done_r, 8'b00000000};
    end
end

endmodule
