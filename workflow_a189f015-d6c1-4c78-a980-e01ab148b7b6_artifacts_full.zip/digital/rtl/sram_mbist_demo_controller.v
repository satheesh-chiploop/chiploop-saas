module demo_sram_32x256_wrapper (
    clk,
    csb,
    web,
    addr,
    din,
    dout
);
input clk;
input csb;
input web;
input [7:0] addr;
input [31:0] din;
output [31:0] dout;

reg [31:0] dout_r;

assign dout = dout_r;

always @(posedge clk) begin
    if (!csb) begin
        if (!web) begin
            dout_r <= din;
        end else begin
            dout_r <= {addr, din[23:0]};
        end
    end
end

endmodule

module sram_mbist_demo_controller (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    bist_start,
    rd_data,
    ready,
    bist_done,
    bist_fail,
    irq
);
input clk;
input reset_n;
input wr_en;
input [7:0] wr_addr;
input [31:0] wr_data;
input rd_en;
input [7:0] rd_addr;
input bist_start;
output [31:0] rd_data;
output ready;
output bist_done;
output bist_fail;
output irq;

reg [31:0] rd_data_r;
reg ready_r;
reg bist_done_r;
reg bist_fail_r;
reg irq_r;
reg [2:0] control_reg;
reg [31:0] mem_wdata_reg;
reg [7:0] mem_addr_reg;
reg [31:0] mem_rdata_reg;
reg [1:0] mem_control_reg;
reg [1:0] bist_control_reg;
reg [1:0] irq_status_reg;
reg [7:0] last_fail_addr_reg;
reg [3:0] status_reg;
reg [31:0] read_mux;
reg sram_csb;
reg sram_web;
reg [7:0] sram_addr;
reg [31:0] sram_din;
reg bist_pending;
reg bist_running;

wire mem_write_req;
wire mem_read_req;
wire bist_clear_req;
wire irq_clear_done_req;
wire irq_clear_fail_req;
wire soft_reset_req;
wire enable_req;
wire irq_enable_req;
wire bist_start_req;
wire [31:0] sram_dout_wire;

assign rd_data = rd_data_r;
assign ready = ready_r;
assign bist_done = bist_done_r;
assign bist_fail = bist_fail_r;
assign irq = irq_r;

assign mem_write_req = wr_en && (wr_addr == 8'h14) && wr_data[0];
assign mem_read_req = wr_en && (wr_addr == 8'h14) && wr_data[1];
assign bist_clear_req = wr_en && (wr_addr == 8'h18) && wr_data[1];
assign irq_clear_done_req = wr_en && (wr_addr == 8'h24) && wr_data[0];
assign irq_clear_fail_req = wr_en && (wr_addr == 8'h24) && wr_data[1];
assign soft_reset_req = wr_en && (wr_addr == 8'h00) && wr_data[1];
assign enable_req = control_reg[0];
assign irq_enable_req = control_reg[2];
assign bist_start_req = bist_start || ((wr_en && (wr_addr == 8'h18)) && wr_data[0]);

always @(*) begin
    read_mux = 32'h00000000;
    case (rd_addr)
        8'h00: read_mux = {29'b00000000000000000000000000000, control_reg};
        8'h04: read_mux = {28'b0000000000000000000000000000, status_reg};
        8'h08: read_mux = {24'b000000000000000000000000, mem_addr_reg};
        8'h0C: read_mux = mem_wdata_reg;
        8'h10: read_mux = mem_rdata_reg;
        8'h14: read_mux = {30'b000000000000000000000000000000, mem_control_reg};
        8'h18: read_mux = {30'b000000000000000000000000000000, bist_control_reg};
        8'h1C: read_mux = {16'b0000000000000000, last_fail_addr_reg, 8'b00000000};
        8'h20: read_mux = {30'b000000000000000000000000000000, irq_status_reg};
        8'h24: read_mux = 32'h00000000;
        default: read_mux = 32'h00000000;
    endcase
end

always @(*) begin
    sram_csb = 1'b1;
    sram_web = 1'b1;
    sram_addr = mem_addr_reg;
    sram_din = mem_wdata_reg;
    if (enable_req) begin
        if (mem_write_req) begin
            sram_csb = 1'b0;
            sram_web = 1'b0;
            sram_addr = mem_addr_reg;
            sram_din = mem_wdata_reg;
        end else if (mem_read_req) begin
            sram_csb = 1'b0;
            sram_web = 1'b1;
            sram_addr = mem_addr_reg;
            sram_din = 32'h00000000;
        end
    end
end

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        control_reg <= 3'b000;
        ready_r <= 1'b0;
        bist_done_r <= 1'b0;
        bist_fail_r <= 1'b0;
        irq_r <= 1'b0;
        mem_addr_reg <= 8'h00;
        mem_wdata_reg <= 32'h00000000;
        mem_rdata_reg <= 32'h00000000;
        mem_control_reg <= 2'b00;
        bist_control_reg <= 2'b00;
        irq_status_reg <= 2'b00;
        last_fail_addr_reg <= 8'h00;
        status_reg <= 4'b0000;
        rd_data_r <= 32'h00000000;
        bist_pending <= 1'b0;
        bist_running <= 1'b0;
    end else begin
        if (wr_en) begin
            case (wr_addr)
                8'h00: begin
                    control_reg[0] <= wr_data[0];
                    control_reg[1] <= wr_data[1];
                    control_reg[2] <= wr_data[2];
                end
                8'h08: mem_addr_reg <= wr_data[7:0];
                8'h0C: mem_wdata_reg <= wr_data;
                8'h14: mem_control_reg <= wr_data[1:0];
                8'h18: begin
                    bist_control_reg[0] <= wr_data[0];
                    bist_control_reg[1] <= wr_data[1];
                end
                8'h24: begin
                    if (wr_data[0]) irq_status_reg[0] <= 1'b0;
                    if (wr_data[1]) irq_status_reg[1] <= 1'b0;
                end
                default: begin
                end
            endcase
        end
        if (soft_reset_req) begin
            control_reg <= 3'b000;
            mem_control_reg <= 2'b00;
            bist_control_reg <= 2'b00;
            irq_status_reg <= 2'b00;
            bist_done_r <= 1'b0;
            bist_fail_r <= 1'b0;
            irq_r <= 1'b0;
            bist_pending <= 1'b0;
            bist_running <= 1'b0;
            last_fail_addr_reg <= 8'h00;
            mem_rdata_reg <= 32'h00000000;
            rd_data_r <= 32'h00000000;
        end
        if (mem_write_req) begin
            mem_control_reg <= 2'b01;
        end else if (mem_read_req) begin
            mem_control_reg <= 2'b10;
            mem_rdata_reg <= sram_dout_wire;
            rd_data_r <= sram_dout_wire;
        end
        if (bist_start_req) begin
            bist_pending <= 1'b1;
            bist_running <= 1'b1;
            bist_control_reg[0] <= 1'b1;
        end
        if (bist_clear_req) begin
            bist_done_r <= 1'b0;
            bist_fail_r <= 1'b0;
            irq_status_reg <= 2'b00;
            last_fail_addr_reg <= 8'h00;
        end
        if (bist_pending) begin
            bist_pending <= 1'b0;
            bist_running <= 1'b0;
            bist_done_r <= 1'b1;
            bist_fail_r <= 1'b0;
            irq_status_reg[0] <= 1'b1;
            if (irq_enable_req) irq_r <= 1'b1;
        end
        if (irq_clear_done_req) begin
            irq_status_reg[0] <= 1'b0;
        end
        if (irq_clear_fail_req) begin
            irq_status_reg[1] <= 1'b0;
        end
        ready_r <= enable_req && !bist_running;
        status_reg[0] <= ready_r;
        status_reg[1] <= bist_done_r;
        status_reg[2] <= bist_fail_r;
        status_reg[3] <= bist_running;
        if (!(irq_status_reg[0] || irq_status_reg[1] || (irq_enable_req && (bist_done_r || bist_fail_r)))) begin
            irq_r <= 1'b0;
        end else if (irq_enable_req && (irq_status_reg[0] || irq_status_reg[1])) begin
            irq_r <= 1'b1;
        end
        if (rd_en) begin
            rd_data_r <= read_mux;
        end
    end
end

demo_sram_32x256_wrapper u_sram (
    .clk(clk),
    .csb(sram_csb),
    .web(sram_web),
    .addr(sram_addr),
    .din(sram_din),
    .dout(sram_dout_wire)
);

endmodule
