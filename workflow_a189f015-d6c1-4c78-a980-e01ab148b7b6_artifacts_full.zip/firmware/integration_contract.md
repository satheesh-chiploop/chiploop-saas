# Firmware Integration Contract

## 1) Contract overview

- This contract defines the firmware-facing integration surface for the imported Arch2RTL RTL block and its generated register map.
- Firmware owns register programming, initialization sequencing, status polling, error handling, and log emission for the block.
- System/Host software owns feature enablement policy, run-time orchestration above the firmware API, and consumption of firmware status/results.
- Validation owns contract compliance checks against the generated RTL interface, register map, and firmware behavior.
- The contract is based on the actual imported RTL package outputs: register map, generated interface definitions, and source workflow artifacts.
- The implementation must remain versioned and backward-compatible within a declared compatibility window.
- Any RTL or register map change that affects firmware-visible semantics requires a contract version bump and validation refresh.
- Co-simulation and coverage are enabled and must be reflected in the validation collateral.

## 2) Contract version + compatibility policy

| Field | Value |
|---|---|
| Contract name | Arch2RTL Firmware Integration Contract |
| Contract version | 1.0.0 |
| Compatibility scope | Generated RTL interface + generated register map + firmware driver scaffold |
| Compatibility policy | Backward-compatible changes allowed within minor/patch versions if register addresses, field meanings, reset values, and required init sequence remain stable |
| Breaking changes | Any register relocation, field repurposing, semantic change to status/error bits, or init/ready behavior change |
| Version bump rule | Major bump for breaking RTL/register semantics; minor for additive, backward-compatible fields; patch for documentation or validation-only updates |
| Source of truth | Generated RTL interface and register map from the source workflow |
| Required review gate | Firmware, RTL, and Validation signoff before release |

## 3) Interfaces

### 3.1 Register layer interface

The register layer must be generated directly from the imported RTL register map. It provides typed accessors and field-level constants for firmware use.

| Interface | Direction | Description | Contract expectation |
|---|---|---|---|
| Register definitions | FW -> RTL | Address, reset value, access type, bit fields | Must match generated register map exactly |
| Read accessors | FW -> RTL | Status, configuration, and capability reads | Must honor access permissions and reserved bits |
| Write accessors | FW -> RTL | Control and configuration writes | Must preserve reserved bits and only write documented fields |
| Field masks/shifts | FW -> RTL | Encoded field helpers | Must be generated from the source workflow, not hand-coded |
| Reset defaults | RTL -> FW | Post-reset observable values | Firmware may rely on these only if listed in generated map |

### 3.2 Firmware driver scaffold interface

The driver scaffold provides a minimal, hardware-specific programming model for the imported block.

| API | Input | Output | Expected behavior |
|---|---|---|---|
| `init()` | Device context, register base | Status code | Programs required control registers and validates readiness |
| `deinit()` | Device context | Status code | Returns hardware to safe idle state if supported |
| `configure()` | Configuration struct | Status code | Applies supported RTL-exposed settings |
| `start()` | None or context | Status code | Arms the block for operation after init/configuration |
| `stop()` | None or context | Status code | Quiesces the block and clears active control state |
| `poll_status()` | Device context | Status snapshot | Returns current RTL-visible state and error flags |
| `get_version()` | None or context | Version struct | Returns firmware contract version and hardware revision info |
| `get_last_error()` | Device context | Error code | Returns last sticky firmware-level error |

### 3.3 Error model

| Error code | Meaning | Ownership |
|---|---|---|
| `FW_OK` | Operation completed successfully | Firmware |
| `FW_ERR_INVALID_ARG` | Invalid input parameter or null context | Firmware |
| `FW_ERR_UNSUPPORTED` | Requested operation not supported by RTL contract | Firmware |
| `FW_ERR_TIMEOUT` | Expected ready/status condition not observed in time | Firmware/Validation |
| `FW_ERR_HW_STATE` | RTL reported invalid state or sticky error | Firmware |
| `FW_ERR_VERSION_MISMATCH` | Driver contract and RTL interface mismatch | Firmware/System integration |
| `FW_ERR_BUS` | Register access failure | Platform integration |

### 3.4 Logging schema

| Field | Type | Description |
|---|---|---|
| `ts` | u64 | Monotonic timestamp |
| `sev` | enum | Debug / Info / Warn / Error |
| `mod` | string | Module name, e.g. imported RTL block driver |
| `evt` | string | Event name |
| `rc` | int | Return or error code |
| `reg` | string | Optional register name |
| `addr` | u32 | Optional register address |
| `val` | u32/u64 | Optional value read/written |

Required firmware log events:
- `INIT_BEGIN`
- `INIT_DONE`
- `CFG_APPLY`
- `START`
- `STOP`
- `STATUS_POLL`
- `ERROR_DETECTED`
- `VERSION_CHECK`

### 3.5 Power mode interface

| Power mode | Firmware action | RTL expectation |
|---|---|---|
| Active | Full operation enabled | Clocked and responsive |
| Idle | No active transaction, configuration retained if supported | Quiescent but readable |
| Reset | Reinitialize from defaults | All registers at reset state |
| Low-power entry/exit | Only if exposed by register map | Firmware shall not invent unsupported power states |

## 4) Ownership boundaries

| Area | FW | System/Host | Validation |
|---|---|---|---|
| Register programming | Owns | Consumes APIs | Verifies correctness |
| Feature policy | Implements hardware-required sequencing only | Owns runtime policy | Checks contract adherence |
| Error recovery | Owns hardware-visible recovery actions | Owns higher-level fallback | Injects faults and checks outcomes |
| Versioning | Publishes contract and driver version | Consumes and gates deployment | Confirms version matching |
| Logging | Emits structured logs | Collects and forwards | Validates schema and coverage |
| Functional acceptance | Implements required behaviors | Observes results | Owns pass/fail criteria |

## 5) Assumptions

- The imported RTL package includes a generated register map with stable field names, addresses, access types, and reset values.
- The source workflow provides sufficient metadata to generate the register layer and driver scaffold without manual reverse engineering.
- No undocumented sideband controls are required for basic initialization and operation.
- Any interrupt or DMA behavior is outside this contract unless present in the generated RTL interface and explicitly added later.
- The hardware exposes a readable status path sufficient for init completion and error reporting.
- Co-simulation can exercise the driver scaffold against the generated RTL model.
- Coverage instrumentation is available for the validation environment.

## 6) Validation hooks

### 6.1 Contract compliance tests

- **Register map conformance**
  - Compare generated driver register definitions against the source-generated RTL register map.
  - Verify address, bitfield, reset value, access mode, and reserved bit handling.
- **Reset state validation**
  - Reset RTL and confirm all documented reset values match.
  - Confirm firmware init writes only documented fields.
- **Init/ready sequence**
  - Run `init()` and verify the ready condition is observed within timeout.
  - Confirm correct status progression in logs and returned codes.
- **Read/write legality**
  - Attempt writes to read-only or reserved fields and confirm they are blocked or masked.
  - Attempt reads from documented status fields and confirm expected values are returned.
- **Error handling**
  - Inject bus failure, invalid parameter, and hardware error conditions.
  - Confirm the correct error codes and log events are emitted.
- **Version compatibility**
  - Confirm firmware rejects incompatible RTL interface revisions with `FW_ERR_VERSION_MISMATCH`.
- **Power transition checks**
  - If low-power or idle states are supported, validate entry/exit sequencing and retained state behavior.
- **Co-simulation**
  - Run the driver scaffold against the generated RTL model in cosim-enabled regression.
  - Check register accesses, status transitions, and error handling against the golden expectations.
- **Coverage**
  - Measure register access coverage, init-path coverage, error-path coverage, and reset-path coverage.
  - Require closure on all contract-critical registers and control flows.

### 6.2 Required validation artifacts

- Generated register-layer headers/source
- Driver scaffold source
- Co-simulation testbench and run scripts
- Coverage report
- Validation summary report with pass/fail status
- Software-facing handoff package containing:
  - contract version
  - register map summary
  - API summary
  - error codes
  - logging schema
  - ownership boundaries
  - integration notes

## 7) Software-facing handoff package

The handoff package for `firmware/integration_contract.md` shall contain:
- This contract document
- Generated register-layer API references
- Driver scaffold interface summary
- Validation hooks and expected outcomes
- Version and compatibility statement
- Ownership boundary table
- Assumptions and limitations
- Co-simulation and coverage enablement notes

## 8) Delivery notes

- The contract must be regenerated whenever the imported RTL package changes.
- Firmware shall not hardcode register details outside the generated register layer.
- Validation must use the generated RTL interface and register map as the authoritative reference.