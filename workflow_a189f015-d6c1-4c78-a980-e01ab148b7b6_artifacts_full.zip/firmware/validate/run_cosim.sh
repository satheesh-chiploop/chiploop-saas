#!/usr/bin/env bash
set -euo pipefail

RTL_TOP="${RTL_TOP:-<RTL_TOP>}"
RTL_DIR="${RTL_DIR:-<RTL_DIR>}"
FILELIST="${FILELIST:-<FILELIST>}"
FW_DIR="${FW_DIR:-}"
SIM_BUILD_DIR="${SIM_BUILD_DIR:-firmware/validate/build}"
OUT_DIR="${OUT_DIR:-firmware/validate}"
LOG_DIR="${LOG_DIR:-${OUT_DIR}/logs}"
RESULTS_DIR="${RESULTS_DIR:-${OUT_DIR}/results}"
COVERAGE_DIR="${COVERAGE_DIR:-${OUT_DIR}/coverage}"

mkdir -p "${SIM_BUILD_DIR}" "${LOG_DIR}" "${RESULTS_DIR}" "${COVERAGE_DIR}"

if [[ -f "${OUT_DIR}/verilator_build.sh" ]]; then
  bash "${OUT_DIR}/verilator_build.sh"
elif [[ -f "${OUT_DIR}/verilator_build.md" ]]; then
  echo "Found firmware/validate/verilator_build.md; please follow its documented build commands."
  if command -v verilator >/dev/null 2>&1; then
    echo "Using generic Verilator fallback build."
    verilator --cc --exe --build -j 0 -Wall --top-module "${RTL_TOP}" -Mdir "${SIM_BUILD_DIR}" -f "${FILELIST}" 2>&1 | tee "${LOG_DIR}/verilator_build.log"
  else
    echo "ERROR: verilator not found on PATH" >&2
    exit 1
  fi
else
  if command -v verilator >/dev/null 2>&1; then
    verilator --cc --exe --build -j 0 -Wall --top-module "${RTL_TOP}" -Mdir "${SIM_BUILD_DIR}" -f "${FILELIST}" 2>&1 | tee "${LOG_DIR}/verilator_build.log"
  else
    echo "ERROR: verilator not found on PATH" >&2
    exit 1
  fi
fi

if [[ -n "${FW_DIR}" ]]; then
  if [[ -f "${FW_DIR}/Cargo.toml" ]]; then
    (cd "${FW_DIR}" && cargo build 2>&1 | tee "${PWD}/${LOG_DIR}/cargo_build.log")
  fi
fi

cd "${OUT_DIR}"

PYTEST_ARGS=(-q)
if [[ -n "${COVERAGE}" ]]; then
  PYTEST_ARGS+=("${COVERAGE}")
fi

pytest -q 2>&1 | tee "${LOG_DIR}/pytest.log"

if [[ -d "${OUT_DIR}/coverage" ]]; then
  find "${OUT_DIR}/coverage" -maxdepth 2 -type f | sort > "${LOG_DIR}/coverage_files.txt"
fi
