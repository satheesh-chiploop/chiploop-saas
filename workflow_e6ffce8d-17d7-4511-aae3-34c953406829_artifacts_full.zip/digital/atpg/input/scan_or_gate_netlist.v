module temp_monitor_soc_phys (alert_irq,
    alert_status,
    avdd,
    avss,
    clk,
    rd_en,
    reset_n,
    scan_en,
    wr_en,
    rd_addr,
    rd_data,
    scan_in,
    scan_out,
    sensor_temp_celsius,
    temp_code,
    threshold_code,
    wr_addr,
    wr_data);
 output alert_irq;
 output alert_status;
 input avdd;
 input avss;
 input clk;
 input rd_en;
 input reset_n;
 input scan_en;
 input wr_en;
 input [7:0] rd_addr;
 output [15:0] rd_data;
 input [3:0] scan_in;
 output [3:0] scan_out;
 input [15:0] sensor_temp_celsius;
 output [11:0] temp_code;
 output [11:0] threshold_code;
 input [7:0] wr_addr;
 input [15:0] wr_data;

 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire _086_;
 wire _087_;
 wire _088_;
 wire _089_;
 wire _090_;
 wire _091_;
 wire _092_;
 wire _093_;
 wire _094_;
 wire _095_;
 wire _096_;
 wire _097_;
 wire _098_;
 wire _099_;
 wire _100_;
 wire _101_;
 wire _102_;
 wire _103_;
 wire _104_;
 wire _105_;
 wire _106_;
 wire _107_;
 wire _108_;
 wire _109_;
 wire _110_;
 wire _111_;
 wire _112_;
 wire _113_;
 wire _114_;
 wire _115_;
 wire _116_;
 wire _117_;
 wire _118_;
 wire _119_;
 wire _120_;
 wire _121_;
 wire _122_;
 wire _123_;
 wire _124_;
 wire _125_;
 wire _126_;
 wire _127_;
 wire _128_;
 wire _129_;
 wire _130_;
 wire _131_;
 wire _132_;
 wire _133_;
 wire _134_;
 wire _135_;
 wire _136_;
 wire _137_;
 wire _138_;
 wire _139_;
 wire _140_;
 wire _141_;
 wire _142_;
 wire _143_;
 wire _144_;
 wire _145_;
 wire _146_;
 wire _147_;
 wire _148_;
 wire _149_;
 wire _150_;
 wire _151_;
 wire _152_;
 wire _153_;
 wire _154_;
 wire _155_;
 wire _156_;
 wire _157_;
 wire _158_;
 wire _159_;
 wire _160_;
 wire _161_;
 wire _162_;
 wire _163_;
 wire _164_;
 wire _165_;
 wire _166_;
 wire _167_;
 wire _168_;
 wire \u_digital.adc_code[0] ;
 wire \u_digital.adc_code[10] ;
 wire \u_digital.adc_code[11] ;
 wire \u_digital.adc_code[1] ;
 wire \u_digital.adc_code[2] ;
 wire \u_digital.adc_code[3] ;
 wire \u_digital.adc_code[4] ;
 wire \u_digital.adc_code[5] ;
 wire \u_digital.adc_code[6] ;
 wire \u_digital.adc_code[7] ;
 wire \u_digital.adc_code[8] ;
 wire \u_digital.adc_code[9] ;
 wire \u_digital.adc_code_reg[0] ;
 wire \u_digital.adc_code_reg[10] ;
 wire \u_digital.adc_code_reg[11] ;
 wire \u_digital.adc_code_reg[1] ;
 wire \u_digital.adc_code_reg[2] ;
 wire \u_digital.adc_code_reg[3] ;
 wire \u_digital.adc_code_reg[4] ;
 wire \u_digital.adc_code_reg[5] ;
 wire \u_digital.adc_code_reg[6] ;
 wire \u_digital.adc_code_reg[7] ;
 wire \u_digital.adc_code_reg[8] ;
 wire \u_digital.adc_code_reg[9] ;
 wire \u_digital.adc_valid ;
 wire \u_digital.adc_valid_seen ;
 wire \u_digital.busy_reg ;
 wire \u_digital.enable_reg ;
 wire \u_digital.irq_enable_reg ;
 wire \u_digital.irq_status_alert ;
 wire \u_digital.irq_status_sample_done ;
 wire \u_digital.periodic_count[0] ;
 wire \u_digital.periodic_count[1] ;
 wire \u_digital.sample_count[0] ;
 wire \u_digital.sample_count[10] ;
 wire \u_digital.sample_count[11] ;
 wire \u_digital.sample_count[12] ;
 wire \u_digital.sample_count[13] ;
 wire \u_digital.sample_count[14] ;
 wire \u_digital.sample_count[15] ;
 wire \u_digital.sample_count[1] ;
 wire \u_digital.sample_count[2] ;
 wire \u_digital.sample_count[3] ;
 wire \u_digital.sample_count[4] ;
 wire \u_digital.sample_count[5] ;
 wire \u_digital.sample_count[6] ;
 wire \u_digital.sample_count[7] ;
 wire \u_digital.sample_count[8] ;
 wire \u_digital.sample_count[9] ;
 wire \u_digital.sample_req ;
 wire \u_digital.sample_req_pending ;
 wire \u_digital.sample_req_periodic_pending ;
 wire \u_digital.status_alert_pending ;
 wire \u_digital.status_sample_done ;

 sky130_fd_sc_hd__inv_2 _169_ (.A(threshold_code[10]),
    .Y(_065_));
 sky130_fd_sc_hd__inv_2 _170_ (.A(threshold_code[9]),
    .Y(_066_));
 sky130_fd_sc_hd__inv_2 _171_ (.A(threshold_code[8]),
    .Y(_067_));
 sky130_fd_sc_hd__inv_2 _172_ (.A(threshold_code[5]),
    .Y(_068_));
 sky130_fd_sc_hd__inv_2 _173_ (.A(threshold_code[4]),
    .Y(_069_));
 sky130_fd_sc_hd__inv_2 _174_ (.A(threshold_code[2]),
    .Y(_070_));
 sky130_fd_sc_hd__inv_2 _175_ (.A(rd_addr[3]),
    .Y(_071_));
 sky130_fd_sc_hd__or2_2 _176_ (.A(\u_digital.sample_req_periodic_pending ),
    .B(\u_digital.sample_req_pending ),
    .X(\u_digital.sample_req ));
 sky130_fd_sc_hd__nand2b_2 _177_ (.A_N(\u_digital.adc_valid_seen ),
    .B(\u_digital.adc_code_reg[11] ),
    .Y(_072_));
 sky130_fd_sc_hd__inv_2 _178_ (.A(_072_),
    .Y(_073_));
 sky130_fd_sc_hd__nor2_2 _179_ (.A(threshold_code[11]),
    .B(_072_),
    .Y(_074_));
 sky130_fd_sc_hd__o2bb2a_2 _180_ (.A1_N(threshold_code[11]),
    .A2_N(_072_),
    .B1(_065_),
    .B2(\u_digital.adc_code_reg[10] ),
    .X(_075_));
 sky130_fd_sc_hd__or2_2 _181_ (.A(_074_),
    .B(_075_),
    .X(_076_));
 sky130_fd_sc_hd__and2_2 _182_ (.A(\u_digital.adc_code_reg[9] ),
    .B(_066_),
    .X(_077_));
 sky130_fd_sc_hd__and2_2 _183_ (.A(\u_digital.adc_code_reg[10] ),
    .B(_065_),
    .X(_078_));
 sky130_fd_sc_hd__or3b_2 _184_ (.A(_074_),
    .B(_078_),
    .C_N(_075_),
    .X(_079_));
 sky130_fd_sc_hd__o22a_2 _185_ (.A1(\u_digital.adc_code_reg[9] ),
    .A2(_066_),
    .B1(_067_),
    .B2(\u_digital.adc_code_reg[8] ),
    .X(_080_));
 sky130_fd_sc_hd__and2b_2 _186_ (.A_N(\u_digital.adc_code_reg[6] ),
    .B(threshold_code[6]),
    .X(_081_));
 sky130_fd_sc_hd__and2b_2 _187_ (.A_N(\u_digital.adc_code_reg[7] ),
    .B(threshold_code[7]),
    .X(_082_));
 sky130_fd_sc_hd__o22a_2 _188_ (.A1(\u_digital.adc_code_reg[5] ),
    .A2(_068_),
    .B1(_069_),
    .B2(\u_digital.adc_code_reg[4] ),
    .X(_083_));
 sky130_fd_sc_hd__nand2b_2 _189_ (.A_N(\u_digital.adc_code_reg[3] ),
    .B(threshold_code[3]),
    .Y(_084_));
 sky130_fd_sc_hd__nand2b_2 _190_ (.A_N(\u_digital.adc_code_reg[2] ),
    .B(threshold_code[2]),
    .Y(_085_));
 sky130_fd_sc_hd__nand2_2 _191_ (.A(_084_),
    .B(_085_),
    .Y(_086_));
 sky130_fd_sc_hd__and2b_2 _192_ (.A_N(\u_digital.adc_code_reg[1] ),
    .B(threshold_code[1]),
    .X(_087_));
 sky130_fd_sc_hd__nand2b_2 _193_ (.A_N(threshold_code[0]),
    .B(\u_digital.adc_code_reg[0] ),
    .Y(_088_));
 sky130_fd_sc_hd__nand2b_2 _194_ (.A_N(threshold_code[1]),
    .B(\u_digital.adc_code_reg[1] ),
    .Y(_089_));
 sky130_fd_sc_hd__and2_2 _195_ (.A(_069_),
    .B(\u_digital.adc_code_reg[4] ),
    .X(_090_));
 sky130_fd_sc_hd__and2b_2 _196_ (.A_N(threshold_code[3]),
    .B(\u_digital.adc_code_reg[3] ),
    .X(_091_));
 sky130_fd_sc_hd__and2_2 _197_ (.A(\u_digital.adc_code_reg[5] ),
    .B(_068_),
    .X(_092_));
 sky130_fd_sc_hd__and2b_2 _198_ (.A_N(threshold_code[6]),
    .B(\u_digital.adc_code_reg[6] ),
    .X(_093_));
 sky130_fd_sc_hd__and2_2 _199_ (.A(_067_),
    .B(\u_digital.adc_code_reg[8] ),
    .X(_094_));
 sky130_fd_sc_hd__and2b_2 _200_ (.A_N(threshold_code[7]),
    .B(\u_digital.adc_code_reg[7] ),
    .X(_095_));
 sky130_fd_sc_hd__or3b_2 _201_ (.A(_077_),
    .B(_094_),
    .C_N(_080_),
    .X(_096_));
 sky130_fd_sc_hd__o21bai_2 _202_ (.A1(_081_),
    .A2(_082_),
    .B1_N(_095_),
    .Y(_097_));
 sky130_fd_sc_hd__or4_2 _203_ (.A(_081_),
    .B(_082_),
    .C(_093_),
    .D(_095_),
    .X(_098_));
 sky130_fd_sc_hd__or3_2 _204_ (.A(_083_),
    .B(_092_),
    .C(_098_),
    .X(_099_));
 sky130_fd_sc_hd__or3b_2 _205_ (.A(_090_),
    .B(_092_),
    .C_N(_083_),
    .X(_100_));
 sky130_fd_sc_hd__a21o_2 _206_ (.A1(\u_digital.adc_code_reg[2] ),
    .A2(_070_),
    .B1(_091_),
    .X(_101_));
 sky130_fd_sc_hd__a21oi_2 _207_ (.A1(_088_),
    .A2(_089_),
    .B1(_087_),
    .Y(_102_));
 sky130_fd_sc_hd__a21o_2 _208_ (.A1(_084_),
    .A2(_085_),
    .B1(_091_),
    .X(_103_));
 sky130_fd_sc_hd__o31a_2 _209_ (.A1(_086_),
    .A2(_101_),
    .A3(_102_),
    .B1(_103_),
    .X(_104_));
 sky130_fd_sc_hd__o311a_2 _210_ (.A1(_098_),
    .A2(_100_),
    .A3(_104_),
    .B1(_099_),
    .C1(_097_),
    .X(_105_));
 sky130_fd_sc_hd__or3_2 _211_ (.A(_079_),
    .B(_096_),
    .C(_105_),
    .X(_106_));
 sky130_fd_sc_hd__o311a_2 _212_ (.A1(_077_),
    .A2(_079_),
    .A3(_080_),
    .B1(_076_),
    .C1(\u_digital.adc_valid ),
    .X(_107_));
 sky130_fd_sc_hd__nor3_2 _213_ (.A(wr_addr[1]),
    .B(wr_addr[0]),
    .C(wr_addr[2]),
    .Y(_108_));
 sky130_fd_sc_hd__and3_2 _214_ (.A(wr_en),
    .B(wr_addr[3]),
    .C(_108_),
    .X(_109_));
 sky130_fd_sc_hd__nor3_2 _215_ (.A(wr_addr[5]),
    .B(wr_addr[7]),
    .C(wr_addr[6]),
    .Y(_110_));
 sky130_fd_sc_hd__nand4_2 _216_ (.A(wr_addr[4]),
    .B(wr_data[0]),
    .C(_109_),
    .D(_110_),
    .Y(_111_));
 sky130_fd_sc_hd__a22o_2 _217_ (.A1(_106_),
    .A2(_107_),
    .B1(_111_),
    .B2(\u_digital.irq_status_alert ),
    .X(_000_));
 sky130_fd_sc_hd__and2b_2 _218_ (.A_N(\u_digital.periodic_count[0] ),
    .B(\u_digital.enable_reg ),
    .X(_001_));
 sky130_fd_sc_hd__o21ai_2 _219_ (.A1(\u_digital.periodic_count[0] ),
    .A2(\u_digital.periodic_count[1] ),
    .B1(\u_digital.enable_reg ),
    .Y(_112_));
 sky130_fd_sc_hd__a21oi_2 _220_ (.A1(\u_digital.periodic_count[0] ),
    .A2(\u_digital.periodic_count[1] ),
    .B1(_112_),
    .Y(_002_));
 sky130_fd_sc_hd__or4b_2 _221_ (.A(rd_addr[5]),
    .B(rd_addr[7]),
    .C(rd_addr[6]),
    .D_N(rd_addr[4]),
    .X(_113_));
 sky130_fd_sc_hd__or4_2 _222_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .C(rd_addr[3]),
    .D(rd_addr[2]),
    .X(_114_));
 sky130_fd_sc_hd__nor2_2 _223_ (.A(_113_),
    .B(_114_),
    .Y(_115_));
 sky130_fd_sc_hd__or4b_2 _224_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .C(rd_addr[3]),
    .D_N(rd_addr[2]),
    .X(_116_));
 sky130_fd_sc_hd__nor2_2 _225_ (.A(_113_),
    .B(_116_),
    .Y(_117_));
 sky130_fd_sc_hd__or4_2 _226_ (.A(rd_addr[5]),
    .B(rd_addr[4]),
    .C(rd_addr[7]),
    .D(rd_addr[6]),
    .X(_118_));
 sky130_fd_sc_hd__nor2_2 _227_ (.A(_116_),
    .B(_118_),
    .Y(_119_));
 sky130_fd_sc_hd__a22o_2 _228_ (.A1(\u_digital.irq_status_alert ),
    .A2(_117_),
    .B1(_119_),
    .B2(\u_digital.status_sample_done ),
    .X(_120_));
 sky130_fd_sc_hd__or2_2 _229_ (.A(_071_),
    .B(_118_),
    .X(_121_));
 sky130_fd_sc_hd__nor4b_2 _230_ (.A(rd_addr[1]),
    .B(_121_),
    .C(rd_addr[0]),
    .D_N(rd_addr[2]),
    .Y(_122_));
 sky130_fd_sc_hd__nor4_2 _231_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .C(rd_addr[2]),
    .D(_121_),
    .Y(_123_));
 sky130_fd_sc_hd__a221o_2 _232_ (.A1(\u_digital.sample_count[0] ),
    .A2(_115_),
    .B1(_123_),
    .B2(threshold_code[0]),
    .C1(_120_),
    .X(_124_));
 sky130_fd_sc_hd__a21o_2 _233_ (.A1(temp_code[0]),
    .A2(_122_),
    .B1(_124_),
    .X(rd_data[0]));
 sky130_fd_sc_hd__a22o_2 _234_ (.A1(\u_digital.sample_count[1] ),
    .A2(_115_),
    .B1(_119_),
    .B2(\u_digital.status_alert_pending ),
    .X(_125_));
 sky130_fd_sc_hd__nor2_2 _235_ (.A(_114_),
    .B(_118_),
    .Y(_126_));
 sky130_fd_sc_hd__a22o_2 _236_ (.A1(\u_digital.irq_status_sample_done ),
    .A2(_117_),
    .B1(_126_),
    .B2(\u_digital.enable_reg ),
    .X(_127_));
 sky130_fd_sc_hd__or2_2 _237_ (.A(_125_),
    .B(_127_),
    .X(_128_));
 sky130_fd_sc_hd__a221o_2 _238_ (.A1(temp_code[1]),
    .A2(_122_),
    .B1(_123_),
    .B2(threshold_code[1]),
    .C1(_128_),
    .X(rd_data[1]));
 sky130_fd_sc_hd__a22o_2 _239_ (.A1(\u_digital.sample_count[2] ),
    .A2(_115_),
    .B1(_119_),
    .B2(\u_digital.adc_valid_seen ),
    .X(_129_));
 sky130_fd_sc_hd__a221o_2 _240_ (.A1(temp_code[2]),
    .A2(_122_),
    .B1(_123_),
    .B2(threshold_code[2]),
    .C1(_129_),
    .X(rd_data[2]));
 sky130_fd_sc_hd__a22o_2 _241_ (.A1(\u_digital.busy_reg ),
    .A2(_119_),
    .B1(_126_),
    .B2(\u_digital.irq_enable_reg ),
    .X(_130_));
 sky130_fd_sc_hd__a221o_2 _242_ (.A1(\u_digital.sample_count[3] ),
    .A2(_115_),
    .B1(_123_),
    .B2(threshold_code[3]),
    .C1(_130_),
    .X(_131_));
 sky130_fd_sc_hd__a21o_2 _243_ (.A1(temp_code[3]),
    .A2(_122_),
    .B1(_131_),
    .X(rd_data[3]));
 sky130_fd_sc_hd__and2_2 _244_ (.A(\u_digital.sample_count[4] ),
    .B(_115_),
    .X(_132_));
 sky130_fd_sc_hd__a221o_2 _245_ (.A1(temp_code[4]),
    .A2(_122_),
    .B1(_123_),
    .B2(threshold_code[4]),
    .C1(_132_),
    .X(rd_data[4]));
 sky130_fd_sc_hd__and2_2 _246_ (.A(\u_digital.sample_count[5] ),
    .B(_115_),
    .X(_133_));
 sky130_fd_sc_hd__a221o_2 _247_ (.A1(temp_code[5]),
    .A2(_122_),
    .B1(_123_),
    .B2(threshold_code[5]),
    .C1(_133_),
    .X(rd_data[5]));
 sky130_fd_sc_hd__and2_2 _248_ (.A(\u_digital.sample_count[6] ),
    .B(_115_),
    .X(_134_));
 sky130_fd_sc_hd__a221o_2 _249_ (.A1(temp_code[6]),
    .A2(_122_),
    .B1(_123_),
    .B2(threshold_code[6]),
    .C1(_134_),
    .X(rd_data[6]));
 sky130_fd_sc_hd__and2_2 _250_ (.A(\u_digital.sample_count[7] ),
    .B(_115_),
    .X(_135_));
 sky130_fd_sc_hd__a221o_2 _251_ (.A1(temp_code[7]),
    .A2(_122_),
    .B1(_123_),
    .B2(threshold_code[7]),
    .C1(_135_),
    .X(rd_data[7]));
 sky130_fd_sc_hd__and2_2 _252_ (.A(\u_digital.sample_count[8] ),
    .B(_115_),
    .X(_136_));
 sky130_fd_sc_hd__a221o_2 _253_ (.A1(temp_code[8]),
    .A2(_122_),
    .B1(_123_),
    .B2(threshold_code[8]),
    .C1(_136_),
    .X(rd_data[8]));
 sky130_fd_sc_hd__and2_2 _254_ (.A(\u_digital.sample_count[9] ),
    .B(_115_),
    .X(_137_));
 sky130_fd_sc_hd__a221o_2 _255_ (.A1(temp_code[9]),
    .A2(_122_),
    .B1(_123_),
    .B2(threshold_code[9]),
    .C1(_137_),
    .X(rd_data[9]));
 sky130_fd_sc_hd__and2_2 _256_ (.A(\u_digital.sample_count[10] ),
    .B(_115_),
    .X(_138_));
 sky130_fd_sc_hd__a221o_2 _257_ (.A1(temp_code[10]),
    .A2(_122_),
    .B1(_123_),
    .B2(threshold_code[10]),
    .C1(_138_),
    .X(rd_data[10]));
 sky130_fd_sc_hd__and2_2 _258_ (.A(\u_digital.sample_count[11] ),
    .B(_115_),
    .X(_139_));
 sky130_fd_sc_hd__a221o_2 _259_ (.A1(temp_code[11]),
    .A2(_122_),
    .B1(_123_),
    .B2(threshold_code[11]),
    .C1(_139_),
    .X(rd_data[11]));
 sky130_fd_sc_hd__and2_2 _260_ (.A(\u_digital.sample_count[12] ),
    .B(_115_),
    .X(rd_data[12]));
 sky130_fd_sc_hd__and2_2 _261_ (.A(\u_digital.sample_count[13] ),
    .B(_115_),
    .X(rd_data[13]));
 sky130_fd_sc_hd__and2_2 _262_ (.A(\u_digital.sample_count[14] ),
    .B(_115_),
    .X(rd_data[14]));
 sky130_fd_sc_hd__and2_2 _263_ (.A(\u_digital.sample_count[15] ),
    .B(_115_),
    .X(rd_data[15]));
 sky130_fd_sc_hd__or4_2 _264_ (.A(wr_addr[5]),
    .B(wr_addr[4]),
    .C(wr_addr[7]),
    .D(wr_addr[6]),
    .X(_140_));
 sky130_fd_sc_hd__inv_2 _265_ (.A(_140_),
    .Y(_141_));
 sky130_fd_sc_hd__and4b_2 _266_ (.A_N(wr_addr[3]),
    .B(_108_),
    .C(_141_),
    .D(wr_en),
    .X(_142_));
 sky130_fd_sc_hd__and2_2 _267_ (.A(wr_data[1]),
    .B(_142_),
    .X(_003_));
 sky130_fd_sc_hd__and3_2 _268_ (.A(\u_digital.periodic_count[0] ),
    .B(\u_digital.periodic_count[1] ),
    .C(\u_digital.enable_reg ),
    .X(_004_));
 sky130_fd_sc_hd__o21a_2 _269_ (.A1(\u_digital.irq_status_alert ),
    .A2(\u_digital.irq_status_sample_done ),
    .B1(\u_digital.irq_enable_reg ),
    .X(alert_irq));
 sky130_fd_sc_hd__mux2_1 _270_ (.A0(\u_digital.adc_code_reg[0] ),
    .A1(\u_digital.adc_code[0] ),
    .S(\u_digital.adc_valid ),
    .X(_005_));
 sky130_fd_sc_hd__mux2_1 _271_ (.A0(\u_digital.adc_code_reg[1] ),
    .A1(\u_digital.adc_code[1] ),
    .S(\u_digital.adc_valid ),
    .X(_006_));
 sky130_fd_sc_hd__mux2_1 _272_ (.A0(\u_digital.adc_code_reg[2] ),
    .A1(\u_digital.adc_code[2] ),
    .S(\u_digital.adc_valid ),
    .X(_007_));
 sky130_fd_sc_hd__mux2_1 _273_ (.A0(\u_digital.adc_code_reg[3] ),
    .A1(\u_digital.adc_code[3] ),
    .S(\u_digital.adc_valid ),
    .X(_008_));
 sky130_fd_sc_hd__mux2_1 _274_ (.A0(\u_digital.adc_code_reg[4] ),
    .A1(\u_digital.adc_code[4] ),
    .S(\u_digital.adc_valid ),
    .X(_009_));
 sky130_fd_sc_hd__mux2_1 _275_ (.A0(\u_digital.adc_code_reg[5] ),
    .A1(\u_digital.adc_code[5] ),
    .S(\u_digital.adc_valid ),
    .X(_010_));
 sky130_fd_sc_hd__mux2_1 _276_ (.A0(\u_digital.adc_code_reg[6] ),
    .A1(\u_digital.adc_code[6] ),
    .S(\u_digital.adc_valid ),
    .X(_011_));
 sky130_fd_sc_hd__mux2_1 _277_ (.A0(\u_digital.adc_code_reg[7] ),
    .A1(\u_digital.adc_code[7] ),
    .S(\u_digital.adc_valid ),
    .X(_012_));
 sky130_fd_sc_hd__mux2_1 _278_ (.A0(\u_digital.adc_code_reg[8] ),
    .A1(\u_digital.adc_code[8] ),
    .S(\u_digital.adc_valid ),
    .X(_013_));
 sky130_fd_sc_hd__mux2_1 _279_ (.A0(\u_digital.adc_code_reg[9] ),
    .A1(\u_digital.adc_code[9] ),
    .S(\u_digital.adc_valid ),
    .X(_014_));
 sky130_fd_sc_hd__mux2_1 _280_ (.A0(\u_digital.adc_code_reg[10] ),
    .A1(\u_digital.adc_code[10] ),
    .S(\u_digital.adc_valid ),
    .X(_015_));
 sky130_fd_sc_hd__mux2_1 _281_ (.A0(\u_digital.adc_code_reg[11] ),
    .A1(\u_digital.adc_code[11] ),
    .S(\u_digital.adc_valid ),
    .X(_016_));
 sky130_fd_sc_hd__mux2_1 _282_ (.A0(\u_digital.irq_enable_reg ),
    .A1(wr_data[2]),
    .S(_142_),
    .X(_017_));
 sky130_fd_sc_hd__o21ba_2 _283_ (.A1(\u_digital.busy_reg ),
    .A2(\u_digital.sample_req ),
    .B1_N(\u_digital.adc_valid ),
    .X(_018_));
 sky130_fd_sc_hd__mux2_1 _284_ (.A0(\u_digital.enable_reg ),
    .A1(wr_data[0]),
    .S(_142_),
    .X(_019_));
 sky130_fd_sc_hd__a31o_2 _285_ (.A1(reset_n),
    .A2(_106_),
    .A3(_107_),
    .B1(alert_status),
    .X(_143_));
 sky130_fd_sc_hd__nand2_2 _286_ (.A(wr_data[3]),
    .B(_142_),
    .Y(_144_));
 sky130_fd_sc_hd__a21bo_2 _287_ (.A1(_111_),
    .A2(_144_),
    .B1_N(reset_n),
    .X(_145_));
 sky130_fd_sc_hd__o21a_2 _288_ (.A1(\u_digital.adc_valid ),
    .A2(_145_),
    .B1(_143_),
    .X(_020_));
 sky130_fd_sc_hd__nand2_2 _289_ (.A(_109_),
    .B(_141_),
    .Y(_146_));
 sky130_fd_sc_hd__mux2_1 _290_ (.A0(wr_data[0]),
    .A1(threshold_code[0]),
    .S(_146_),
    .X(_021_));
 sky130_fd_sc_hd__mux2_1 _291_ (.A0(wr_data[1]),
    .A1(threshold_code[1]),
    .S(_146_),
    .X(_022_));
 sky130_fd_sc_hd__mux2_1 _292_ (.A0(wr_data[2]),
    .A1(threshold_code[2]),
    .S(_146_),
    .X(_023_));
 sky130_fd_sc_hd__mux2_1 _293_ (.A0(wr_data[3]),
    .A1(threshold_code[3]),
    .S(_146_),
    .X(_024_));
 sky130_fd_sc_hd__mux2_1 _294_ (.A0(wr_data[4]),
    .A1(threshold_code[4]),
    .S(_146_),
    .X(_025_));
 sky130_fd_sc_hd__mux2_1 _295_ (.A0(wr_data[5]),
    .A1(threshold_code[5]),
    .S(_146_),
    .X(_026_));
 sky130_fd_sc_hd__mux2_1 _296_ (.A0(wr_data[6]),
    .A1(threshold_code[6]),
    .S(_146_),
    .X(_027_));
 sky130_fd_sc_hd__mux2_1 _297_ (.A0(wr_data[7]),
    .A1(threshold_code[7]),
    .S(_146_),
    .X(_028_));
 sky130_fd_sc_hd__mux2_1 _298_ (.A0(wr_data[8]),
    .A1(threshold_code[8]),
    .S(_146_),
    .X(_029_));
 sky130_fd_sc_hd__mux2_1 _299_ (.A0(wr_data[9]),
    .A1(threshold_code[9]),
    .S(_146_),
    .X(_030_));
 sky130_fd_sc_hd__mux2_1 _300_ (.A0(wr_data[10]),
    .A1(threshold_code[10]),
    .S(_146_),
    .X(_031_));
 sky130_fd_sc_hd__mux2_1 _301_ (.A0(wr_data[11]),
    .A1(threshold_code[11]),
    .S(_146_),
    .X(_032_));
 sky130_fd_sc_hd__nand4_2 _302_ (.A(wr_addr[4]),
    .B(wr_data[1]),
    .C(_109_),
    .D(_110_),
    .Y(_147_));
 sky130_fd_sc_hd__a21o_2 _303_ (.A1(\u_digital.irq_status_sample_done ),
    .A2(_147_),
    .B1(\u_digital.adc_valid ),
    .X(_033_));
 sky130_fd_sc_hd__mux2_1 _304_ (.A0(temp_code[0]),
    .A1(\u_digital.adc_code_reg[0] ),
    .S(\u_digital.adc_valid ),
    .X(_034_));
 sky130_fd_sc_hd__mux2_1 _305_ (.A0(temp_code[1]),
    .A1(\u_digital.adc_code_reg[1] ),
    .S(\u_digital.adc_valid ),
    .X(_035_));
 sky130_fd_sc_hd__mux2_1 _306_ (.A0(temp_code[2]),
    .A1(\u_digital.adc_code_reg[2] ),
    .S(\u_digital.adc_valid ),
    .X(_036_));
 sky130_fd_sc_hd__mux2_1 _307_ (.A0(temp_code[3]),
    .A1(\u_digital.adc_code_reg[3] ),
    .S(\u_digital.adc_valid ),
    .X(_037_));
 sky130_fd_sc_hd__mux2_1 _308_ (.A0(temp_code[4]),
    .A1(\u_digital.adc_code_reg[4] ),
    .S(\u_digital.adc_valid ),
    .X(_038_));
 sky130_fd_sc_hd__mux2_1 _309_ (.A0(temp_code[5]),
    .A1(\u_digital.adc_code_reg[5] ),
    .S(\u_digital.adc_valid ),
    .X(_039_));
 sky130_fd_sc_hd__mux2_1 _310_ (.A0(temp_code[6]),
    .A1(\u_digital.adc_code_reg[6] ),
    .S(\u_digital.adc_valid ),
    .X(_040_));
 sky130_fd_sc_hd__mux2_1 _311_ (.A0(temp_code[7]),
    .A1(\u_digital.adc_code_reg[7] ),
    .S(\u_digital.adc_valid ),
    .X(_041_));
 sky130_fd_sc_hd__mux2_1 _312_ (.A0(temp_code[8]),
    .A1(\u_digital.adc_code_reg[8] ),
    .S(\u_digital.adc_valid ),
    .X(_042_));
 sky130_fd_sc_hd__mux2_1 _313_ (.A0(temp_code[9]),
    .A1(\u_digital.adc_code_reg[9] ),
    .S(\u_digital.adc_valid ),
    .X(_043_));
 sky130_fd_sc_hd__mux2_1 _314_ (.A0(temp_code[10]),
    .A1(\u_digital.adc_code_reg[10] ),
    .S(\u_digital.adc_valid ),
    .X(_044_));
 sky130_fd_sc_hd__mux2_1 _315_ (.A0(temp_code[11]),
    .A1(_073_),
    .S(\u_digital.adc_valid ),
    .X(_045_));
 sky130_fd_sc_hd__xor2_2 _316_ (.A(\u_digital.sample_count[0] ),
    .B(\u_digital.adc_valid ),
    .X(_046_));
 sky130_fd_sc_hd__and3_2 _317_ (.A(\u_digital.sample_count[0] ),
    .B(\u_digital.adc_valid ),
    .C(\u_digital.sample_count[1] ),
    .X(_148_));
 sky130_fd_sc_hd__a21oi_2 _318_ (.A1(\u_digital.sample_count[0] ),
    .A2(\u_digital.adc_valid ),
    .B1(\u_digital.sample_count[1] ),
    .Y(_149_));
 sky130_fd_sc_hd__nor2_2 _319_ (.A(_148_),
    .B(_149_),
    .Y(_047_));
 sky130_fd_sc_hd__and4_2 _320_ (.A(\u_digital.sample_count[0] ),
    .B(\u_digital.adc_valid ),
    .C(\u_digital.sample_count[1] ),
    .D(\u_digital.sample_count[2] ),
    .X(_150_));
 sky130_fd_sc_hd__nor2_2 _321_ (.A(\u_digital.sample_count[2] ),
    .B(_148_),
    .Y(_151_));
 sky130_fd_sc_hd__nor2_2 _322_ (.A(_150_),
    .B(_151_),
    .Y(_048_));
 sky130_fd_sc_hd__nand2_2 _323_ (.A(\u_digital.sample_count[3] ),
    .B(_150_),
    .Y(_152_));
 sky130_fd_sc_hd__or2_2 _324_ (.A(\u_digital.sample_count[3] ),
    .B(_150_),
    .X(_153_));
 sky130_fd_sc_hd__and2_2 _325_ (.A(_152_),
    .B(_153_),
    .X(_049_));
 sky130_fd_sc_hd__xnor2_2 _326_ (.A(\u_digital.sample_count[4] ),
    .B(_152_),
    .Y(_050_));
 sky130_fd_sc_hd__and4_2 _327_ (.A(\u_digital.sample_count[3] ),
    .B(\u_digital.sample_count[4] ),
    .C(\u_digital.sample_count[5] ),
    .D(_150_),
    .X(_154_));
 sky130_fd_sc_hd__a31o_2 _328_ (.A1(\u_digital.sample_count[3] ),
    .A2(\u_digital.sample_count[4] ),
    .A3(_150_),
    .B1(\u_digital.sample_count[5] ),
    .X(_155_));
 sky130_fd_sc_hd__and2b_2 _329_ (.A_N(_154_),
    .B(_155_),
    .X(_051_));
 sky130_fd_sc_hd__xor2_2 _330_ (.A(\u_digital.sample_count[6] ),
    .B(_154_),
    .X(_052_));
 sky130_fd_sc_hd__and3_2 _331_ (.A(\u_digital.sample_count[6] ),
    .B(\u_digital.sample_count[7] ),
    .C(_154_),
    .X(_156_));
 sky130_fd_sc_hd__a21oi_2 _332_ (.A1(\u_digital.sample_count[6] ),
    .A2(_154_),
    .B1(\u_digital.sample_count[7] ),
    .Y(_157_));
 sky130_fd_sc_hd__nor2_2 _333_ (.A(_156_),
    .B(_157_),
    .Y(_053_));
 sky130_fd_sc_hd__nand2_2 _334_ (.A(\u_digital.sample_count[8] ),
    .B(_156_),
    .Y(_158_));
 sky130_fd_sc_hd__xor2_2 _335_ (.A(\u_digital.sample_count[8] ),
    .B(_156_),
    .X(_054_));
 sky130_fd_sc_hd__xnor2_2 _336_ (.A(\u_digital.sample_count[9] ),
    .B(_158_),
    .Y(_055_));
 sky130_fd_sc_hd__and3_2 _337_ (.A(\u_digital.sample_count[7] ),
    .B(\u_digital.sample_count[8] ),
    .C(\u_digital.sample_count[9] ),
    .X(_159_));
 sky130_fd_sc_hd__a31oi_2 _338_ (.A1(\u_digital.sample_count[6] ),
    .A2(_154_),
    .A3(_159_),
    .B1(\u_digital.sample_count[10] ),
    .Y(_160_));
 sky130_fd_sc_hd__and4_2 _339_ (.A(\u_digital.sample_count[6] ),
    .B(\u_digital.sample_count[10] ),
    .C(_154_),
    .D(_159_),
    .X(_161_));
 sky130_fd_sc_hd__nor2_2 _340_ (.A(_160_),
    .B(_161_),
    .Y(_056_));
 sky130_fd_sc_hd__xor2_2 _341_ (.A(\u_digital.sample_count[11] ),
    .B(_161_),
    .X(_057_));
 sky130_fd_sc_hd__a21oi_2 _342_ (.A1(\u_digital.sample_count[11] ),
    .A2(_161_),
    .B1(\u_digital.sample_count[12] ),
    .Y(_162_));
 sky130_fd_sc_hd__and3_2 _343_ (.A(\u_digital.sample_count[11] ),
    .B(\u_digital.sample_count[12] ),
    .C(_161_),
    .X(_163_));
 sky130_fd_sc_hd__nor2_2 _344_ (.A(_162_),
    .B(_163_),
    .Y(_058_));
 sky130_fd_sc_hd__nor2_2 _345_ (.A(\u_digital.sample_count[13] ),
    .B(_163_),
    .Y(_164_));
 sky130_fd_sc_hd__and2_2 _346_ (.A(\u_digital.sample_count[13] ),
    .B(_163_),
    .X(_165_));
 sky130_fd_sc_hd__nor2_2 _347_ (.A(_164_),
    .B(_165_),
    .Y(_059_));
 sky130_fd_sc_hd__or2_2 _348_ (.A(\u_digital.sample_count[14] ),
    .B(_165_),
    .X(_166_));
 sky130_fd_sc_hd__nand2_2 _349_ (.A(\u_digital.sample_count[14] ),
    .B(_165_),
    .Y(_167_));
 sky130_fd_sc_hd__and2_2 _350_ (.A(_166_),
    .B(_167_),
    .X(_060_));
 sky130_fd_sc_hd__xnor2_2 _351_ (.A(\u_digital.sample_count[15] ),
    .B(_167_),
    .Y(_061_));
 sky130_fd_sc_hd__a21o_2 _352_ (.A1(_106_),
    .A2(_107_),
    .B1(\u_digital.status_alert_pending ),
    .X(_168_));
 sky130_fd_sc_hd__o211a_2 _353_ (.A1(\u_digital.adc_valid ),
    .A2(_111_),
    .B1(_144_),
    .C1(_168_),
    .X(_062_));
 sky130_fd_sc_hd__or2_2 _354_ (.A(\u_digital.adc_valid ),
    .B(\u_digital.adc_valid_seen ),
    .X(_063_));
 sky130_fd_sc_hd__o21a_2 _355_ (.A1(\u_digital.adc_valid ),
    .A2(\u_digital.status_sample_done ),
    .B1(_147_),
    .X(_064_));
 sky130_fd_sc_hd__sdfrtp_2 _356_ (.CLK(clk),
    .D(_005_),
    .RESET_B(reset_n),
    .SCD(scan_in[0]),
    .SCE(scan_en),
    .Q(\u_digital.adc_code_reg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _357_ (.CLK(clk),
    .D(_006_),
    .RESET_B(reset_n),
    .SCD(scan_in[1]),
    .SCE(scan_en),
    .Q(\u_digital.adc_code_reg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _358_ (.CLK(clk),
    .D(_007_),
    .RESET_B(reset_n),
    .SCD(scan_in[2]),
    .SCE(scan_en),
    .Q(\u_digital.adc_code_reg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _359_ (.CLK(clk),
    .D(_008_),
    .RESET_B(reset_n),
    .SCD(scan_in[3]),
    .SCE(scan_en),
    .Q(\u_digital.adc_code_reg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _360_ (.CLK(clk),
    .D(_009_),
    .RESET_B(reset_n),
    .SCD(\u_digital.adc_code_reg[0] ),
    .SCE(scan_en),
    .Q(\u_digital.adc_code_reg[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _361_ (.CLK(clk),
    .D(_010_),
    .RESET_B(reset_n),
    .SCD(\u_digital.adc_code_reg[1] ),
    .SCE(scan_en),
    .Q(\u_digital.adc_code_reg[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _362_ (.CLK(clk),
    .D(_011_),
    .RESET_B(reset_n),
    .SCD(\u_digital.adc_code_reg[2] ),
    .SCE(scan_en),
    .Q(\u_digital.adc_code_reg[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _363_ (.CLK(clk),
    .D(_012_),
    .RESET_B(reset_n),
    .SCD(\u_digital.adc_code_reg[3] ),
    .SCE(scan_en),
    .Q(\u_digital.adc_code_reg[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _364_ (.CLK(clk),
    .D(_013_),
    .RESET_B(reset_n),
    .SCD(\u_digital.adc_code_reg[4] ),
    .SCE(scan_en),
    .Q(\u_digital.adc_code_reg[8] ));
 sky130_fd_sc_hd__sdfrtp_2 _365_ (.CLK(clk),
    .D(_014_),
    .RESET_B(reset_n),
    .SCD(\u_digital.adc_code_reg[5] ),
    .SCE(scan_en),
    .Q(\u_digital.adc_code_reg[9] ));
 sky130_fd_sc_hd__sdfrtp_2 _366_ (.CLK(clk),
    .D(_015_),
    .RESET_B(reset_n),
    .SCD(\u_digital.adc_code_reg[6] ),
    .SCE(scan_en),
    .Q(\u_digital.adc_code_reg[10] ));
 sky130_fd_sc_hd__sdfrtp_2 _367_ (.CLK(clk),
    .D(_016_),
    .RESET_B(reset_n),
    .SCD(\u_digital.adc_code_reg[7] ),
    .SCE(scan_en),
    .Q(\u_digital.adc_code_reg[11] ));
 sky130_fd_sc_hd__sdfrtp_2 _368_ (.CLK(clk),
    .D(_017_),
    .RESET_B(reset_n),
    .SCD(\u_digital.adc_code_reg[8] ),
    .SCE(scan_en),
    .Q(\u_digital.irq_enable_reg ));
 sky130_fd_sc_hd__sdfrtp_2 _369_ (.CLK(clk),
    .D(_018_),
    .RESET_B(reset_n),
    .SCD(\u_digital.adc_code_reg[9] ),
    .SCE(scan_en),
    .Q(\u_digital.busy_reg ));
 sky130_fd_sc_hd__sdfrtp_2 _370_ (.CLK(clk),
    .D(_019_),
    .RESET_B(reset_n),
    .SCD(\u_digital.adc_code_reg[10] ),
    .SCE(scan_en),
    .Q(\u_digital.enable_reg ));
 sky130_fd_sc_hd__sdfrtp_2 _372_ (.CLK(clk),
    .D(_021_),
    .RESET_B(reset_n),
    .SCD(\u_digital.adc_code_reg[11] ),
    .SCE(scan_en),
    .Q(threshold_code[0]));
 sky130_fd_sc_hd__sdfrtp_2 _373_ (.CLK(clk),
    .D(_022_),
    .RESET_B(reset_n),
    .SCD(\u_digital.irq_enable_reg ),
    .SCE(scan_en),
    .Q(threshold_code[1]));
 sky130_fd_sc_hd__sdfrtp_2 _374_ (.CLK(clk),
    .D(_023_),
    .RESET_B(reset_n),
    .SCD(\u_digital.busy_reg ),
    .SCE(scan_en),
    .Q(threshold_code[2]));
 sky130_fd_sc_hd__sdfrtp_2 _375_ (.CLK(clk),
    .D(_024_),
    .RESET_B(reset_n),
    .SCD(\u_digital.enable_reg ),
    .SCE(scan_en),
    .Q(threshold_code[3]));
 sky130_fd_sc_hd__sdfrtp_2 _376_ (.CLK(clk),
    .D(_025_),
    .RESET_B(reset_n),
    .SCD(threshold_code[0]),
    .SCE(scan_en),
    .Q(threshold_code[4]));
 sky130_fd_sc_hd__sdfrtp_2 _377_ (.CLK(clk),
    .D(_026_),
    .RESET_B(reset_n),
    .SCD(threshold_code[1]),
    .SCE(scan_en),
    .Q(threshold_code[5]));
 sky130_fd_sc_hd__sdfrtp_2 _378_ (.CLK(clk),
    .D(_027_),
    .RESET_B(reset_n),
    .SCD(threshold_code[2]),
    .SCE(scan_en),
    .Q(threshold_code[6]));
 sky130_fd_sc_hd__sdfrtp_2 _379_ (.CLK(clk),
    .D(_028_),
    .RESET_B(reset_n),
    .SCD(threshold_code[3]),
    .SCE(scan_en),
    .Q(threshold_code[7]));
 sky130_fd_sc_hd__sdfrtp_2 _380_ (.CLK(clk),
    .D(_029_),
    .RESET_B(reset_n),
    .SCD(threshold_code[4]),
    .SCE(scan_en),
    .Q(threshold_code[8]));
 sky130_fd_sc_hd__sdfrtp_2 _381_ (.CLK(clk),
    .D(_030_),
    .RESET_B(reset_n),
    .SCD(threshold_code[5]),
    .SCE(scan_en),
    .Q(threshold_code[9]));
 sky130_fd_sc_hd__sdfrtp_2 _382_ (.CLK(clk),
    .D(_031_),
    .RESET_B(reset_n),
    .SCD(threshold_code[6]),
    .SCE(scan_en),
    .Q(threshold_code[10]));
 sky130_fd_sc_hd__sdfrtp_2 _383_ (.CLK(clk),
    .D(_032_),
    .RESET_B(reset_n),
    .SCD(threshold_code[7]),
    .SCE(scan_en),
    .Q(threshold_code[11]));
 sky130_fd_sc_hd__sdfrtp_2 _384_ (.CLK(clk),
    .D(_033_),
    .RESET_B(reset_n),
    .SCD(threshold_code[8]),
    .SCE(scan_en),
    .Q(\u_digital.irq_status_sample_done ));
 sky130_fd_sc_hd__sdfrtp_2 _385_ (.CLK(clk),
    .D(_000_),
    .RESET_B(reset_n),
    .SCD(threshold_code[9]),
    .SCE(scan_en),
    .Q(\u_digital.irq_status_alert ));
 sky130_fd_sc_hd__sdfrtp_2 _386_ (.CLK(clk),
    .D(_034_),
    .RESET_B(reset_n),
    .SCD(threshold_code[10]),
    .SCE(scan_en),
    .Q(temp_code[0]));
 sky130_fd_sc_hd__sdfrtp_2 _387_ (.CLK(clk),
    .D(_035_),
    .RESET_B(reset_n),
    .SCD(threshold_code[11]),
    .SCE(scan_en),
    .Q(temp_code[1]));
 sky130_fd_sc_hd__sdfrtp_2 _388_ (.CLK(clk),
    .D(_036_),
    .RESET_B(reset_n),
    .SCD(\u_digital.irq_status_sample_done ),
    .SCE(scan_en),
    .Q(temp_code[2]));
 sky130_fd_sc_hd__sdfrtp_2 _389_ (.CLK(clk),
    .D(_037_),
    .RESET_B(reset_n),
    .SCD(\u_digital.irq_status_alert ),
    .SCE(scan_en),
    .Q(temp_code[3]));
 sky130_fd_sc_hd__sdfrtp_2 _390_ (.CLK(clk),
    .D(_038_),
    .RESET_B(reset_n),
    .SCD(temp_code[0]),
    .SCE(scan_en),
    .Q(temp_code[4]));
 sky130_fd_sc_hd__sdfrtp_2 _391_ (.CLK(clk),
    .D(_039_),
    .RESET_B(reset_n),
    .SCD(temp_code[1]),
    .SCE(scan_en),
    .Q(temp_code[5]));
 sky130_fd_sc_hd__sdfrtp_2 _392_ (.CLK(clk),
    .D(_040_),
    .RESET_B(reset_n),
    .SCD(temp_code[2]),
    .SCE(scan_en),
    .Q(temp_code[6]));
 sky130_fd_sc_hd__sdfrtp_2 _393_ (.CLK(clk),
    .D(_041_),
    .RESET_B(reset_n),
    .SCD(temp_code[3]),
    .SCE(scan_en),
    .Q(temp_code[7]));
 sky130_fd_sc_hd__sdfrtp_2 _394_ (.CLK(clk),
    .D(_042_),
    .RESET_B(reset_n),
    .SCD(temp_code[4]),
    .SCE(scan_en),
    .Q(temp_code[8]));
 sky130_fd_sc_hd__sdfrtp_2 _395_ (.CLK(clk),
    .D(_043_),
    .RESET_B(reset_n),
    .SCD(temp_code[5]),
    .SCE(scan_en),
    .Q(temp_code[9]));
 sky130_fd_sc_hd__sdfrtp_2 _396_ (.CLK(clk),
    .D(_044_),
    .RESET_B(reset_n),
    .SCD(temp_code[6]),
    .SCE(scan_en),
    .Q(temp_code[10]));
 sky130_fd_sc_hd__sdfrtp_2 _397_ (.CLK(clk),
    .D(_045_),
    .RESET_B(reset_n),
    .SCD(temp_code[7]),
    .SCE(scan_en),
    .Q(temp_code[11]));
 sky130_fd_sc_hd__sdfrtp_2 _398_ (.CLK(clk),
    .D(_046_),
    .RESET_B(reset_n),
    .SCD(temp_code[8]),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _399_ (.CLK(clk),
    .D(_047_),
    .RESET_B(reset_n),
    .SCD(temp_code[9]),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _400_ (.CLK(clk),
    .D(_048_),
    .RESET_B(reset_n),
    .SCD(temp_code[10]),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _401_ (.CLK(clk),
    .D(_049_),
    .RESET_B(reset_n),
    .SCD(temp_code[11]),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _402_ (.CLK(clk),
    .D(_050_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[0] ),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _403_ (.CLK(clk),
    .D(_051_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[1] ),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _404_ (.CLK(clk),
    .D(_052_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[2] ),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _405_ (.CLK(clk),
    .D(_053_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[3] ),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _406_ (.CLK(clk),
    .D(_054_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[4] ),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[8] ));
 sky130_fd_sc_hd__sdfrtp_2 _407_ (.CLK(clk),
    .D(_055_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[5] ),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[9] ));
 sky130_fd_sc_hd__sdfrtp_2 _408_ (.CLK(clk),
    .D(_056_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[6] ),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[10] ));
 sky130_fd_sc_hd__sdfrtp_2 _409_ (.CLK(clk),
    .D(_057_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[7] ),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[11] ));
 sky130_fd_sc_hd__sdfrtp_2 _410_ (.CLK(clk),
    .D(_058_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[8] ),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[12] ));
 sky130_fd_sc_hd__sdfrtp_2 _411_ (.CLK(clk),
    .D(_059_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[9] ),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[13] ));
 sky130_fd_sc_hd__sdfrtp_2 _412_ (.CLK(clk),
    .D(_060_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[10] ),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[14] ));
 sky130_fd_sc_hd__sdfrtp_2 _413_ (.CLK(clk),
    .D(_061_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[11] ),
    .SCE(scan_en),
    .Q(\u_digital.sample_count[15] ));
 sky130_fd_sc_hd__sdfrtp_2 _414_ (.CLK(clk),
    .D(_062_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[12] ),
    .SCE(scan_en),
    .Q(\u_digital.status_alert_pending ));
 sky130_fd_sc_hd__sdfrtp_2 _415_ (.CLK(clk),
    .D(_003_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[13] ),
    .SCE(scan_en),
    .Q(\u_digital.sample_req_pending ));
 sky130_fd_sc_hd__sdfrtp_2 _416_ (.CLK(clk),
    .D(_063_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[14] ),
    .SCE(scan_en),
    .Q(\u_digital.adc_valid_seen ));
 sky130_fd_sc_hd__sdfrtp_2 _417_ (.CLK(clk),
    .D(_004_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_count[15] ),
    .SCE(scan_en),
    .Q(\u_digital.sample_req_periodic_pending ));
 sky130_fd_sc_hd__sdfrtp_2 _418_ (.CLK(clk),
    .D(_064_),
    .RESET_B(reset_n),
    .SCD(\u_digital.status_alert_pending ),
    .SCE(scan_en),
    .Q(\u_digital.status_sample_done ));
 sky130_fd_sc_hd__sdfrtp_2 _419_ (.CLK(clk),
    .D(_001_),
    .RESET_B(reset_n),
    .SCD(\u_digital.sample_req_pending ),
    .SCE(scan_en),
    .Q(\u_digital.periodic_count[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _420_ (.CLK(clk),
    .D(_002_),
    .RESET_B(reset_n),
    .SCD(\u_digital.adc_valid_seen ),
    .SCE(scan_en),
    .Q(\u_digital.periodic_count[1] ));
 sky130_fd_sc_hd__sdfxtp_2 _371_ (.CLK(clk),
    .D(_020_),
    .Q(alert_status));
 assign scan_out[2] = \u_digital.periodic_count[0] ;
 assign scan_out[3] = \u_digital.periodic_count[1] ;
 assign scan_out[0] = \u_digital.sample_req_periodic_pending ;
 assign scan_out[1] = \u_digital.status_sample_done ;
  // Preserved non-stdcell macro instances omitted by DFT write_verilog.
  temp_sensor_adc_model u_analog (
    .adc_code({ \u_digital.adc_code[11] , \u_digital.adc_code[10] , \u_digital.adc_code[9] , \u_digital.adc_code[8] , \u_digital.adc_code[7] , \u_digital.adc_code[6] , \u_digital.adc_code[5] , \u_digital.adc_code[4] , \u_digital.adc_code[3] , \u_digital.adc_code[2] , \u_digital.adc_code[1] , \u_digital.adc_code[0]  }),
    .adc_valid(\u_digital.adc_valid ),
    .avdd(avdd),
    .avss(avss),
    .sample_req(\u_digital.sample_req ),
    .sensor_temp_celsius(sensor_temp_celsius)
  );
endmodule
