module adaptive_aero_control_top (
    clk,
    reset_n,
    mmio_wr_en,
    mmio_rd_en,
    mmio_addr,
    mmio_wdata,
    mmio_rdata,
    mmio_ready,
    mmio_valid,
    arm_req,
    disarm_req,
    mode_sel,
    seq_num_in,
    velocity_setpoint,
    timeout_cfg,
    fallback_enable,
    allow_pipelining,
    reserved_ctrl_bits,
    request_valid,
    request_ready,
    request_data,
    response_valid,
    response_ready,
    response_data,
    actuator_cmd_valid,
    actuator_cmd_ready,
    actuator_target,
    actuator_value,
    status_armed,
    status_fault,
    status_fallback_active,
    status_timeout_active,
    status_stale_response,
    status_cmd_clamp,
    status_illegal_ctrl,
    status_response_error,
    status_outstanding
);

input clk;
input reset_n;
input mmio_wr_en;
input mmio_rd_en;
input [2:0] mmio_addr;
input [63:0] mmio_wdata;
output [63:0] mmio_rdata;
output mmio_ready;
output mmio_valid;
input arm_req;
input disarm_req;
input [1:0] mode_sel;
input [7:0] seq_num_in;
input [7:0] velocity_setpoint;
input [7:0] timeout_cfg;
input fallback_enable;
input allow_pipelining;
input [38:0] reserved_ctrl_bits;
output request_valid;
input request_ready;
output [63:0] request_data;
input response_valid;
output response_ready;
input [63:0] response_data;
output actuator_cmd_valid;
input actuator_cmd_ready;
output [3:0] actuator_target;
output [11:0] actuator_value;
output status_armed;
output status_fault;
output status_fallback_active;
output status_timeout_active;
output status_stale_response;
output status_cmd_clamp;
output status_illegal_ctrl;
output status_response_error;
output status_outstanding;

reg [2:0] state_q;
reg [2:0] state_d;

reg arm_req_q;
reg disarm_req_q;
reg [1:0] mode_sel_q;
reg [7:0] seq_num_in_q;
reg [7:0] velocity_setpoint_q;
reg [7:0] timeout_cfg_q;
reg fallback_enable_q;
reg allow_pipelining_q;
reg [38:0] reserved_ctrl_bits_q;

reg armed_q;
reg fault_q;
reg fallback_active_q;
reg timeout_active_q;
reg stale_response_q;
reg cmd_clamp_q;
reg illegal_ctrl_q;
reg response_error_q;
reg outstanding_q;

reg [7:0] outstanding_seq_q;
reg [7:0] timeout_cnt_q;
reg [11:0] actuator_value_q;
reg [3:0] actuator_target_q;
reg request_valid_q;
reg [63:0] request_data_q;
reg response_ready_q;
reg actuator_cmd_valid_q;
reg mmio_ready_q;
reg mmio_valid_q;
reg [63:0] mmio_rdata_q;
reg [63:0] ctrl_status_reg_q;

reg [63:0] req_pack;
reg [63:0] resp_meta;
reg [11:0] safe_actuator_value;
reg [3:0] safe_actuator_target;
reg [11:0] validated_actuator_value;
reg [3:0] validated_actuator_target;
reg [11:0] clamped_actuator_value;
reg [11:0] response_cmd_value;
reg [3:0] response_cmd_target;
reg response_seq_match;
reg response_protocol_ok;
reg control_illegal;
reg velocity_illegal;
reg reserved_illegal;
reg request_fire;
reg response_fire;
reg issue_request;
reg accept_response;
reg timeout_expired;
reg [63:0] ctrl_readback;

localparam ST_IDLE = 3'd0;
localparam ST_ISSUE = 3'd1;
localparam ST_WAIT = 3'd2;
localparam ST_VALIDATE = 3'd3;
localparam ST_APPLY = 3'd4;
localparam ST_FALLBACK = 3'd5;

assign mmio_rdata = mmio_rdata_q;
assign mmio_ready = mmio_ready_q;
assign mmio_valid = mmio_valid_q;
assign request_valid = request_valid_q;
assign request_data = request_data_q;
assign response_ready = response_ready_q;
assign actuator_cmd_valid = actuator_cmd_valid_q;
assign actuator_target = actuator_target_q;
assign actuator_value = actuator_value_q;
assign status_armed = armed_q;
assign status_fault = fault_q;
assign status_fallback_active = fallback_active_q;
assign status_timeout_active = timeout_active_q;
assign status_stale_response = stale_response_q;
assign status_cmd_clamp = cmd_clamp_q;
assign status_illegal_ctrl = illegal_ctrl_q;
assign status_response_error = response_error_q;
assign status_outstanding = outstanding_q;

always @(*) begin
    state_d = state_q;
    arm_req_q = arm_req;
    disarm_req_q = disarm_req;
    mode_sel_q = mode_sel;
    seq_num_in_q = seq_num_in;
    velocity_setpoint_q = velocity_setpoint;
    timeout_cfg_q = timeout_cfg;
    fallback_enable_q = fallback_enable;
    allow_pipelining_q = allow_pipelining;
    reserved_ctrl_bits_q = reserved_ctrl_bits;

    safe_actuator_value = 12'd0;
    safe_actuator_target = 4'd0;
    validated_actuator_value = 12'd0;
    validated_actuator_target = 4'd0;
    clamped_actuator_value = 12'd0;
    response_cmd_value = 12'd0;
    response_cmd_target = 4'd0;
    response_seq_match = 1'b0;
    response_protocol_ok = 1'b0;
    control_illegal = 1'b0;
    velocity_illegal = 1'b0;
    reserved_illegal = 1'b0;
    request_fire = 1'b0;
    response_fire = 1'b0;
    issue_request = 1'b0;
    accept_response = 1'b0;
    timeout_expired = 1'b0;
    req_pack = 64'd0;
    resp_meta = response_data;

    safe_actuator_value = 12'd0;
    safe_actuator_target = 4'd0;

    if (reserved_ctrl_bits_q != 39'd0)
        reserved_illegal = 1'b1;
    if ((mode_sel_q != 2'b00) && (mode_sel_q != 2'b01) && (mode_sel_q != 2'b10) && (mode_sel_q != 2'b11))
        control_illegal = 1'b1;
    if ((velocity_setpoint_q < 8'd20) || (velocity_setpoint_q > 8'd55))
        velocity_illegal = 1'b1;
    if (reserved_illegal || control_illegal || velocity_illegal)
        issue_request = 1'b0;

    request_fire = request_valid_q && request_ready;
    response_fire = response_valid && response_ready_q;
    response_seq_match = (resp_meta[15:8] == outstanding_seq_q);
    response_protocol_ok = (resp_meta[63] == 1'b0) && (resp_meta[62] == 1'b1);
    response_cmd_value = resp_meta[11:0];
    response_cmd_target = resp_meta[19:16];
    validated_actuator_value = response_cmd_value;
    validated_actuator_target = response_cmd_target;

    if (validated_actuator_value > 12'd4095)
        clamped_actuator_value = 12'd4095;
    else
        clamped_actuator_value = validated_actuator_value;

    if (timeout_cfg_q == 8'd0)
        timeout_expired = outstanding_q;
    else if (timeout_cnt_q >= timeout_cfg_q)
        timeout_expired = outstanding_q;

    req_pack[7:0] = seq_num_in_q;
    req_pack[11:8] = mode_sel_q;
    req_pack[19:12] = velocity_setpoint_q;
    req_pack[27:20] = timeout_cfg_q;
    req_pack[28] = fallback_enable_q;
    req_pack[29] = allow_pipelining_q;
    req_pack[63:30] = {34{1'b0}};

    ctrl_readback = ctrl_status_reg_q;

    case (mmio_addr)
        3'd0: begin
            ctrl_readback[0]  = arm_req_q;
            ctrl_readback[1]  = disarm_req_q;
            ctrl_readback[3:2] = mode_sel_q;
            ctrl_readback[11:4] = seq_num_in_q;
            ctrl_readback[19:12] = velocity_setpoint_q;
            ctrl_readback[27:20] = timeout_cfg_q;
            ctrl_readback[28] = fallback_enable_q;
            ctrl_readback[29] = allow_pipelining_q;
            ctrl_readback[68-1:30] = reserved_ctrl_bits_q[38:0];
            ctrl_readback[69] = armed_q;
            ctrl_readback[70] = fault_q;
            ctrl_readback[71] = fallback_active_q;
            ctrl_readback[72] = timeout_active_q;
            ctrl_readback[73] = stale_response_q;
            ctrl_readback[74] = cmd_clamp_q;
            ctrl_readback[75] = illegal_ctrl_q;
            ctrl_readback[76] = response_error_q;
            ctrl_readback[77] = outstanding_q;
            ctrl_readback[78] = mmio_ready_q;
            ctrl_readback[79] = mmio_valid_q;
        end
        default: begin
        end
    endcase

    if (fallback_active_q || fault_q || timeout_expired || stale_response_q || illegal_ctrl_q || response_error_q)
        state_d = ST_FALLBACK;
    else if (armed_q && !outstanding_q && !request_valid_q && !reserved_illegal && !control_illegal && !velocity_illegal)
        state_d = ST_ISSUE;
    else if (armed_q && outstanding_q)
        state_d = ST_WAIT;
    else
        state_d = ST_IDLE;

    if (disarm_req_q)
        state_d = ST_FALLBACK;
end

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        state_q <= ST_FALLBACK;
        armed_q <= 1'b0;
        fault_q <= 1'b0;
        fallback_active_q <= 1'b1;
        timeout_active_q <= 1'b0;
        stale_response_q <= 1'b0;
        cmd_clamp_q <= 1'b0;
        illegal_ctrl_q <= 1'b0;
        response_error_q <= 1'b0;
        outstanding_q <= 1'b0;
        outstanding_seq_q <= 8'd0;
        timeout_cnt_q <= 8'd0;
        actuator_value_q <= 12'd0;
        actuator_target_q <= 4'd0;
        request_valid_q <= 1'b0;
        request_data_q <= 64'd0;
        response_ready_q <= 1'b1;
        actuator_cmd_valid_q <= 1'b0;
        mmio_ready_q <= 1'b1;
        mmio_valid_q <= 1'b0;
        mmio_rdata_q <= 64'd0;
        ctrl_status_reg_q <= 64'd0;
    end else begin
        state_q <= state_d;
        if (disarm_req_q) begin
            armed_q <= 1'b0;
            fallback_active_q <= 1'b1;
            outstanding_q <= 1'b0;
            timeout_cnt_q <= 8'd0;
            request_valid_q <= 1'b0;
            actuator_cmd_valid_q <= 1'b0;
        end else if (arm_req_q && !reserved_illegal && !control_illegal && !velocity_illegal) begin
            armed_q <= 1'b1;
            fallback_active_q <= 1'b0;
        end

        illegal_ctrl_q <= reserved_illegal | control_illegal | velocity_illegal;
        fault_q <= fault_q | reserved_illegal | control_illegal | velocity_illegal | response_error_q | stale_response_q | timeout_expired;
        timeout_active_q <= timeout_expired;
        stale_response_q <= stale_response_q | (response_valid & outstanding_q & !response_seq_match) | (response_valid & outstanding_q & !response_protocol_ok);
        response_error_q <= response_error_q | (response_valid & outstanding_q & !response_protocol_ok);

        if ((state_q == ST_ISSUE) && request_ready) begin
            request_valid_q <= 1'b1;
            request_data_q <= req_pack;
            outstanding_q <= 1'b1;
            outstanding_seq_q <= seq_num_in_q;
            timeout_cnt_q <= 8'd0;
        end else begin
            request_valid_q <= 1'b0;
            if (outstanding_q && !timeout_expired)
                timeout_cnt_q <= timeout_cnt_q + 8'd1;
        end

        if (response_valid && response_ready_q && outstanding_q && response_seq_match && response_protocol_ok) begin
            response_error_q <= response_error_q;
            actuator_value_q <= clamped_actuator_value;
            actuator_target_q <= response_cmd_target;
            actuator_cmd_valid_q <= 1'b1;
            outstanding_q <= 1'b0;
            timeout_cnt_q <= 8'd0;
        end else begin
            actuator_cmd_valid_q <= 1'b0;
        end

        if (timeout_expired) begin
            fallback_active_q <= 1'b1;
            timeout_active_q <= 1'b1;
            fault_q <= 1'b1;
            outstanding_q <= 1'b0;
            request_valid_q <= 1'b0;
            actuator_value_q <= safe_actuator_value;
            actuator_target_q <= safe_actuator_target;
        end

        if (fallback_active_q || fault_q || timeout_expired || stale_response_q || illegal_ctrl_q || response_error_q) begin
            actuator_value_q <= safe_actuator_value;
            actuator_target_q <= safe_actuator_target;
            actuator_cmd_valid_q <= 1'b1;
        end

        ctrl_status_reg_q[0] <= arm_req_q;
        ctrl_status_reg_q[1] <= disarm_req_q;
        ctrl_status_reg_q[3:2] <= mode_sel_q;
        ctrl_status_reg_q[11:4] <= seq_num_in_q;
        ctrl_status_reg_q[19:12] <= velocity_setpoint_q;
        ctrl_status_reg_q[27:20] <= timeout_cfg_q;
        ctrl_status_reg_q[28] <= fallback_enable_q;
        ctrl_status_reg_q[29] <= allow_pipelining_q;
        ctrl_status_reg_q[68-1:30] <= reserved_ctrl_bits_q[38:0];
        ctrl_status_reg_q[69] <= armed_q;
        ctrl_status_reg_q[70] <= fault_q;
        ctrl_status_reg_q[71] <= fallback_active_q;
        ctrl_status_reg_q[72] <= timeout_active_q;
        ctrl_status_reg_q[73] <= stale_response_q;
        ctrl_status_reg_q[74] <= cmd_clamp_q;
        ctrl_status_reg_q[75] <= illegal_ctrl_q;
        ctrl_status_reg_q[76] <= response_error_q;
        ctrl_status_reg_q[77] <= outstanding_q;
        ctrl_status_reg_q[78] <= mmio_ready_q;
        ctrl_status_reg_q[79] <= mmio_valid_q;
    end
end

endmodule
