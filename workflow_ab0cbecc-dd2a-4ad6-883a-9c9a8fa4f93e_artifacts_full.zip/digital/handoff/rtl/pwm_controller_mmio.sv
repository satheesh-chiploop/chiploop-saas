module pwm_controller_mmio (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    rd_data,
    pwm_out,
    counter_value
);

input clk;
input reset_n;
input wr_en;
input [7:0] wr_addr;
input [7:0] wr_data;
input rd_en;
input [7:0] rd_addr;
output reg [7:0] rd_data;
output reg pwm_out;
output reg [7:0] counter_value;

reg enable_reg;
reg [7:0] duty_cycle_reg;
reg [7:0] period_reg;
reg [7:0] counter_reg;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        enable_reg <= 1'b0;
        duty_cycle_reg <= 8'h00;
        period_reg <= 8'h00;
        counter_reg <= 8'h00;
        rd_data <= 8'h00;
        pwm_out <= 1'b0;
        counter_value <= 8'h00;
    end else begin
        if (wr_en) begin
            case (wr_addr)
                8'h00: enable_reg <= wr_data[0];
                8'h04: duty_cycle_reg <= wr_data;
                8'h08: period_reg <= wr_data;
                8'h0C: begin
                    enable_reg <= enable_reg;
                    duty_cycle_reg <= duty_cycle_reg;
                    period_reg <= period_reg;
                    counter_reg <= counter_reg;
                end
                default: begin
                    enable_reg <= enable_reg;
                    duty_cycle_reg <= duty_cycle_reg;
                    period_reg <= period_reg;
                    counter_reg <= counter_reg;
                end
            endcase
        end

        if (enable_reg && (period_reg != 8'h00)) begin
            if (counter_reg >= period_reg)
                counter_reg <= 8'h00;
            else
                counter_reg <= counter_reg + 8'h01;
        end else begin
            counter_reg <= 8'h00;
        end

        case (rd_addr)
            8'h00: rd_data <= {7'b0000000, enable_reg};
            8'h04: rd_data <= duty_cycle_reg;
            8'h08: rd_data <= period_reg;
            8'h0C: rd_data <= counter_reg;
            default: rd_data <= 8'h00;
        endcase

        if (enable_reg && (counter_reg < duty_cycle_reg))
            pwm_out <= 1'b1;
        else
            pwm_out <= 1'b0;

        counter_value <= counter_reg;
    end
end

endmodule
