# Digital Synthesis Summary

- **Workflow**: ab0cbecc-dd2a-4ad6-883a-9c9a8fa4f93e
- **Status**: `ok` (rc=0)
- **Top module**: `pwm_controller_mmio`
- **Clock**: `clk` @ **10.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/ab0cbecc-dd2a-4ad6-883a-9c9a8fa4f93e/39d04ddb-be50-4def-85f8-415fea1d11d0/digital/arch2tapeout/digital/synth/runs/digital_ab0cbecc-dd2a-4ad6-883a-9c9a8fa4f93e/final/metrics.json`
- netlist candidates: 1 found
