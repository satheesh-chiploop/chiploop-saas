module pwm_controller_mmio (clk,
    pwm_out,
    rd_en,
    reset_n,
    scan_en,
    wr_en,
    counter_value,
    rd_addr,
    rd_data,
    scan_in,
    scan_out,
    wr_addr,
    wr_data);
 input clk;
 output pwm_out;
 input rd_en;
 input reset_n;
 input scan_en;
 input wr_en;
 output [7:0] counter_value;
 input [7:0] rd_addr;
 output [7:0] rd_data;
 input [3:0] scan_in;
 output [3:0] scan_out;
 input [7:0] wr_addr;
 input [7:0] wr_data;

 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire _086_;
 wire _087_;
 wire _088_;
 wire _089_;
 wire _090_;
 wire _091_;
 wire _092_;
 wire _093_;
 wire _094_;
 wire _095_;
 wire _096_;
 wire _097_;
 wire _098_;
 wire _099_;
 wire _100_;
 wire _101_;
 wire _102_;
 wire _103_;
 wire _104_;
 wire \counter_reg[0] ;
 wire \counter_reg[1] ;
 wire \counter_reg[2] ;
 wire \counter_reg[3] ;
 wire \counter_reg[4] ;
 wire \counter_reg[5] ;
 wire \counter_reg[6] ;
 wire \counter_reg[7] ;
 wire \duty_cycle_reg[0] ;
 wire \duty_cycle_reg[1] ;
 wire \duty_cycle_reg[2] ;
 wire \duty_cycle_reg[3] ;
 wire \duty_cycle_reg[4] ;
 wire \duty_cycle_reg[5] ;
 wire \duty_cycle_reg[6] ;
 wire \duty_cycle_reg[7] ;
 wire enable_reg;
 wire \period_reg[0] ;
 wire \period_reg[1] ;
 wire \period_reg[2] ;
 wire \period_reg[3] ;
 wire \period_reg[4] ;
 wire \period_reg[5] ;
 wire \period_reg[6] ;
 wire \period_reg[7] ;

 sky130_fd_sc_hd__inv_2 _105_ (.A(\duty_cycle_reg[7] ),
    .Y(_082_));
 sky130_fd_sc_hd__inv_2 _106_ (.A(\duty_cycle_reg[6] ),
    .Y(_083_));
 sky130_fd_sc_hd__inv_2 _107_ (.A(\counter_reg[5] ),
    .Y(_084_));
 sky130_fd_sc_hd__inv_2 _108_ (.A(\counter_reg[4] ),
    .Y(_085_));
 sky130_fd_sc_hd__inv_2 _109_ (.A(\duty_cycle_reg[3] ),
    .Y(_086_));
 sky130_fd_sc_hd__inv_2 _110_ (.A(\counter_reg[3] ),
    .Y(_087_));
 sky130_fd_sc_hd__inv_2 _111_ (.A(\counter_reg[2] ),
    .Y(_088_));
 sky130_fd_sc_hd__inv_2 _112_ (.A(\counter_reg[1] ),
    .Y(_089_));
 sky130_fd_sc_hd__inv_2 _113_ (.A(\counter_reg[0] ),
    .Y(_090_));
 sky130_fd_sc_hd__nor2_2 _114_ (.A(\counter_reg[7] ),
    .B(_082_),
    .Y(_091_));
 sky130_fd_sc_hd__a22o_2 _115_ (.A1(\counter_reg[7] ),
    .A2(_082_),
    .B1(_083_),
    .B2(\counter_reg[6] ),
    .X(_092_));
 sky130_fd_sc_hd__o22a_2 _116_ (.A1(\duty_cycle_reg[5] ),
    .A2(_084_),
    .B1(_085_),
    .B2(\duty_cycle_reg[4] ),
    .X(_093_));
 sky130_fd_sc_hd__o211a_2 _117_ (.A1(\duty_cycle_reg[1] ),
    .A2(_089_),
    .B1(\duty_cycle_reg[0] ),
    .C1(_090_),
    .X(_094_));
 sky130_fd_sc_hd__a22o_2 _118_ (.A1(\duty_cycle_reg[2] ),
    .A2(_088_),
    .B1(\duty_cycle_reg[1] ),
    .B2(_089_),
    .X(_095_));
 sky130_fd_sc_hd__o22a_2 _119_ (.A1(\duty_cycle_reg[3] ),
    .A2(_087_),
    .B1(\duty_cycle_reg[2] ),
    .B2(_088_),
    .X(_096_));
 sky130_fd_sc_hd__o21ai_2 _120_ (.A1(_094_),
    .A2(_095_),
    .B1(_096_),
    .Y(_026_));
 sky130_fd_sc_hd__o2bb2a_2 _121_ (.A1_N(_085_),
    .A2_N(\duty_cycle_reg[4] ),
    .B1(_086_),
    .B2(\counter_reg[3] ),
    .X(_027_));
 sky130_fd_sc_hd__a21bo_2 _122_ (.A1(_026_),
    .A2(_027_),
    .B1_N(_093_),
    .X(_028_));
 sky130_fd_sc_hd__o2bb2a_2 _123_ (.A1_N(_084_),
    .A2_N(\duty_cycle_reg[5] ),
    .B1(\counter_reg[6] ),
    .B2(_083_),
    .X(_029_));
 sky130_fd_sc_hd__a21oi_2 _124_ (.A1(_028_),
    .A2(_029_),
    .B1(_092_),
    .Y(_030_));
 sky130_fd_sc_hd__o21a_2 _125_ (.A1(_091_),
    .A2(_030_),
    .B1(enable_reg),
    .X(_008_));
 sky130_fd_sc_hd__o22a_2 _126_ (.A1(_084_),
    .A2(\period_reg[5] ),
    .B1(\period_reg[4] ),
    .B2(_085_),
    .X(_031_));
 sky130_fd_sc_hd__o22a_2 _127_ (.A1(_087_),
    .A2(\period_reg[3] ),
    .B1(\period_reg[2] ),
    .B2(_088_),
    .X(_032_));
 sky130_fd_sc_hd__o211a_2 _128_ (.A1(_089_),
    .A2(\period_reg[1] ),
    .B1(\period_reg[0] ),
    .C1(_090_),
    .X(_033_));
 sky130_fd_sc_hd__a22o_2 _129_ (.A1(_088_),
    .A2(\period_reg[2] ),
    .B1(\period_reg[1] ),
    .B2(_089_),
    .X(_034_));
 sky130_fd_sc_hd__o21a_2 _130_ (.A1(_033_),
    .A2(_034_),
    .B1(_032_),
    .X(_035_));
 sky130_fd_sc_hd__a22o_2 _131_ (.A1(_085_),
    .A2(\period_reg[4] ),
    .B1(\period_reg[3] ),
    .B2(_087_),
    .X(_036_));
 sky130_fd_sc_hd__o21a_2 _132_ (.A1(_035_),
    .A2(_036_),
    .B1(_031_),
    .X(_037_));
 sky130_fd_sc_hd__and2b_2 _133_ (.A_N(\counter_reg[7] ),
    .B(\period_reg[7] ),
    .X(_038_));
 sky130_fd_sc_hd__xor2_2 _134_ (.A(\counter_reg[6] ),
    .B(\period_reg[6] ),
    .X(_039_));
 sky130_fd_sc_hd__a211o_2 _135_ (.A1(_084_),
    .A2(\period_reg[5] ),
    .B1(_038_),
    .C1(_039_),
    .X(_040_));
 sky130_fd_sc_hd__or3b_2 _136_ (.A(\period_reg[6] ),
    .B(_038_),
    .C_N(\counter_reg[6] ),
    .X(_041_));
 sky130_fd_sc_hd__nand2b_2 _137_ (.A_N(\period_reg[7] ),
    .B(\counter_reg[7] ),
    .Y(_042_));
 sky130_fd_sc_hd__o211a_2 _138_ (.A1(_037_),
    .A2(_040_),
    .B1(_041_),
    .C1(_042_),
    .X(_043_));
 sky130_fd_sc_hd__or4_2 _139_ (.A(\period_reg[3] ),
    .B(\period_reg[2] ),
    .C(\period_reg[1] ),
    .D(\period_reg[0] ),
    .X(_044_));
 sky130_fd_sc_hd__or4_2 _140_ (.A(\period_reg[7] ),
    .B(\period_reg[6] ),
    .C(\period_reg[5] ),
    .D(\period_reg[4] ),
    .X(_045_));
 sky130_fd_sc_hd__o21a_2 _141_ (.A1(_044_),
    .A2(_045_),
    .B1(enable_reg),
    .X(_046_));
 sky130_fd_sc_hd__and3_2 _142_ (.A(_090_),
    .B(_043_),
    .C(_046_),
    .X(_000_));
 sky130_fd_sc_hd__and2_2 _143_ (.A(\counter_reg[1] ),
    .B(\counter_reg[0] ),
    .X(_047_));
 sky130_fd_sc_hd__or2_2 _144_ (.A(\counter_reg[1] ),
    .B(\counter_reg[0] ),
    .X(_048_));
 sky130_fd_sc_hd__and4b_2 _145_ (.A_N(_047_),
    .B(_048_),
    .C(_043_),
    .D(_046_),
    .X(_001_));
 sky130_fd_sc_hd__nand2_2 _146_ (.A(\counter_reg[2] ),
    .B(_047_),
    .Y(_049_));
 sky130_fd_sc_hd__or2_2 _147_ (.A(\counter_reg[2] ),
    .B(_047_),
    .X(_050_));
 sky130_fd_sc_hd__and4_2 _148_ (.A(_043_),
    .B(_046_),
    .C(_049_),
    .D(_050_),
    .X(_002_));
 sky130_fd_sc_hd__and3_2 _149_ (.A(\counter_reg[3] ),
    .B(\counter_reg[2] ),
    .C(_047_),
    .X(_051_));
 sky130_fd_sc_hd__a31o_2 _150_ (.A1(\counter_reg[2] ),
    .A2(\counter_reg[1] ),
    .A3(\counter_reg[0] ),
    .B1(\counter_reg[3] ),
    .X(_052_));
 sky130_fd_sc_hd__and4b_2 _151_ (.A_N(_051_),
    .B(_052_),
    .C(_043_),
    .D(_046_),
    .X(_003_));
 sky130_fd_sc_hd__and2_2 _152_ (.A(\counter_reg[4] ),
    .B(_051_),
    .X(_053_));
 sky130_fd_sc_hd__inv_2 _153_ (.A(_053_),
    .Y(_054_));
 sky130_fd_sc_hd__o2111a_2 _154_ (.A1(\counter_reg[4] ),
    .A2(_051_),
    .B1(_054_),
    .C1(_043_),
    .D1(_046_),
    .X(_004_));
 sky130_fd_sc_hd__o21a_2 _155_ (.A1(\counter_reg[5] ),
    .A2(_053_),
    .B1(_046_),
    .X(_055_));
 sky130_fd_sc_hd__o211a_2 _156_ (.A1(_084_),
    .A2(_054_),
    .B1(_055_),
    .C1(_043_),
    .X(_005_));
 sky130_fd_sc_hd__and3_2 _157_ (.A(\counter_reg[6] ),
    .B(\counter_reg[5] ),
    .C(_053_),
    .X(_056_));
 sky130_fd_sc_hd__a31o_2 _158_ (.A1(\counter_reg[5] ),
    .A2(\counter_reg[4] ),
    .A3(_051_),
    .B1(\counter_reg[6] ),
    .X(_057_));
 sky130_fd_sc_hd__and4b_2 _159_ (.A_N(_056_),
    .B(_057_),
    .C(_043_),
    .D(_046_),
    .X(_006_));
 sky130_fd_sc_hd__nand2_2 _160_ (.A(\counter_reg[7] ),
    .B(_056_),
    .Y(_058_));
 sky130_fd_sc_hd__o2111a_2 _161_ (.A1(\counter_reg[7] ),
    .A2(_056_),
    .B1(_058_),
    .C1(_043_),
    .D1(_046_),
    .X(_007_));
 sky130_fd_sc_hd__or4_2 _162_ (.A(rd_addr[5]),
    .B(rd_addr[4]),
    .C(rd_addr[7]),
    .D(rd_addr[6]),
    .X(_059_));
 sky130_fd_sc_hd__inv_2 _163_ (.A(_059_),
    .Y(_060_));
 sky130_fd_sc_hd__nor2_2 _164_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .Y(_061_));
 sky130_fd_sc_hd__and4_2 _165_ (.A(rd_addr[3]),
    .B(rd_addr[2]),
    .C(_060_),
    .D(_061_),
    .X(_062_));
 sky130_fd_sc_hd__and3b_2 _166_ (.A_N(rd_addr[3]),
    .B(_060_),
    .C(_061_),
    .X(_063_));
 sky130_fd_sc_hd__mux2_1 _167_ (.A0(enable_reg),
    .A1(\duty_cycle_reg[0] ),
    .S(rd_addr[2]),
    .X(_064_));
 sky130_fd_sc_hd__and4b_2 _168_ (.A_N(rd_addr[2]),
    .B(_060_),
    .C(_061_),
    .D(rd_addr[3]),
    .X(_065_));
 sky130_fd_sc_hd__a22o_2 _169_ (.A1(_063_),
    .A2(_064_),
    .B1(_065_),
    .B2(\period_reg[0] ),
    .X(_066_));
 sky130_fd_sc_hd__a21o_2 _170_ (.A1(\counter_reg[0] ),
    .A2(_062_),
    .B1(_066_),
    .X(_097_));
 sky130_fd_sc_hd__and2_2 _171_ (.A(rd_addr[2]),
    .B(_063_),
    .X(_067_));
 sky130_fd_sc_hd__a22o_2 _172_ (.A1(\counter_reg[1] ),
    .A2(_062_),
    .B1(_065_),
    .B2(\period_reg[1] ),
    .X(_068_));
 sky130_fd_sc_hd__a21o_2 _173_ (.A1(\duty_cycle_reg[1] ),
    .A2(_067_),
    .B1(_068_),
    .X(_098_));
 sky130_fd_sc_hd__a22o_2 _174_ (.A1(\counter_reg[2] ),
    .A2(_062_),
    .B1(_065_),
    .B2(\period_reg[2] ),
    .X(_069_));
 sky130_fd_sc_hd__a21o_2 _175_ (.A1(\duty_cycle_reg[2] ),
    .A2(_067_),
    .B1(_069_),
    .X(_099_));
 sky130_fd_sc_hd__a22o_2 _176_ (.A1(\counter_reg[3] ),
    .A2(_062_),
    .B1(_065_),
    .B2(\period_reg[3] ),
    .X(_070_));
 sky130_fd_sc_hd__a21o_2 _177_ (.A1(\duty_cycle_reg[3] ),
    .A2(_067_),
    .B1(_070_),
    .X(_100_));
 sky130_fd_sc_hd__a22o_2 _178_ (.A1(\counter_reg[4] ),
    .A2(_062_),
    .B1(_065_),
    .B2(\period_reg[4] ),
    .X(_071_));
 sky130_fd_sc_hd__a21o_2 _179_ (.A1(\duty_cycle_reg[4] ),
    .A2(_067_),
    .B1(_071_),
    .X(_101_));
 sky130_fd_sc_hd__and2_2 _180_ (.A(\counter_reg[5] ),
    .B(_062_),
    .X(_072_));
 sky130_fd_sc_hd__a221o_2 _181_ (.A1(\period_reg[5] ),
    .A2(_065_),
    .B1(_067_),
    .B2(\duty_cycle_reg[5] ),
    .C1(_072_),
    .X(_102_));
 sky130_fd_sc_hd__a22o_2 _182_ (.A1(\counter_reg[6] ),
    .A2(_062_),
    .B1(_065_),
    .B2(\period_reg[6] ),
    .X(_073_));
 sky130_fd_sc_hd__a21o_2 _183_ (.A1(\duty_cycle_reg[6] ),
    .A2(_067_),
    .B1(_073_),
    .X(_103_));
 sky130_fd_sc_hd__a22o_2 _184_ (.A1(\counter_reg[7] ),
    .A2(_062_),
    .B1(_065_),
    .B2(\period_reg[7] ),
    .X(_074_));
 sky130_fd_sc_hd__a21o_2 _185_ (.A1(\duty_cycle_reg[7] ),
    .A2(_067_),
    .B1(_074_),
    .X(_104_));
 sky130_fd_sc_hd__or3_2 _186_ (.A(wr_addr[5]),
    .B(wr_addr[4]),
    .C(wr_addr[7]),
    .X(_075_));
 sky130_fd_sc_hd__or3b_2 _187_ (.A(_075_),
    .B(wr_addr[6]),
    .C_N(wr_en),
    .X(_076_));
 sky130_fd_sc_hd__or2_2 _188_ (.A(wr_addr[3]),
    .B(_076_),
    .X(_077_));
 sky130_fd_sc_hd__or4_2 _189_ (.A(wr_addr[2]),
    .B(wr_addr[1]),
    .C(wr_addr[0]),
    .D(_077_),
    .X(_078_));
 sky130_fd_sc_hd__mux2_1 _190_ (.A0(wr_data[0]),
    .A1(enable_reg),
    .S(_078_),
    .X(_024_));
 sky130_fd_sc_hd__nor4b_2 _191_ (.A(wr_addr[1]),
    .B(wr_addr[0]),
    .C(_077_),
    .D_N(wr_addr[2]),
    .Y(_079_));
 sky130_fd_sc_hd__mux2_1 _192_ (.A0(\duty_cycle_reg[0] ),
    .A1(wr_data[0]),
    .S(_079_),
    .X(_025_));
 sky130_fd_sc_hd__mux2_1 _193_ (.A0(\duty_cycle_reg[1] ),
    .A1(wr_data[1]),
    .S(_079_),
    .X(_009_));
 sky130_fd_sc_hd__mux2_1 _194_ (.A0(\duty_cycle_reg[2] ),
    .A1(wr_data[2]),
    .S(_079_),
    .X(_010_));
 sky130_fd_sc_hd__mux2_1 _195_ (.A0(\duty_cycle_reg[3] ),
    .A1(wr_data[3]),
    .S(_079_),
    .X(_011_));
 sky130_fd_sc_hd__mux2_1 _196_ (.A0(\duty_cycle_reg[4] ),
    .A1(wr_data[4]),
    .S(_079_),
    .X(_012_));
 sky130_fd_sc_hd__mux2_1 _197_ (.A0(\duty_cycle_reg[5] ),
    .A1(wr_data[5]),
    .S(_079_),
    .X(_013_));
 sky130_fd_sc_hd__mux2_1 _198_ (.A0(\duty_cycle_reg[6] ),
    .A1(wr_data[6]),
    .S(_079_),
    .X(_014_));
 sky130_fd_sc_hd__mux2_1 _199_ (.A0(\duty_cycle_reg[7] ),
    .A1(wr_data[7]),
    .S(_079_),
    .X(_015_));
 sky130_fd_sc_hd__or4b_2 _200_ (.A(wr_addr[2]),
    .B(wr_addr[1]),
    .C(wr_addr[0]),
    .D_N(wr_addr[3]),
    .X(_080_));
 sky130_fd_sc_hd__or2_2 _201_ (.A(_076_),
    .B(_080_),
    .X(_081_));
 sky130_fd_sc_hd__mux2_1 _202_ (.A0(wr_data[0]),
    .A1(\period_reg[0] ),
    .S(_081_),
    .X(_016_));
 sky130_fd_sc_hd__mux2_1 _203_ (.A0(wr_data[1]),
    .A1(\period_reg[1] ),
    .S(_081_),
    .X(_017_));
 sky130_fd_sc_hd__mux2_1 _204_ (.A0(wr_data[2]),
    .A1(\period_reg[2] ),
    .S(_081_),
    .X(_018_));
 sky130_fd_sc_hd__mux2_1 _205_ (.A0(wr_data[3]),
    .A1(\period_reg[3] ),
    .S(_081_),
    .X(_019_));
 sky130_fd_sc_hd__mux2_1 _206_ (.A0(wr_data[4]),
    .A1(\period_reg[4] ),
    .S(_081_),
    .X(_020_));
 sky130_fd_sc_hd__mux2_1 _207_ (.A0(wr_data[5]),
    .A1(\period_reg[5] ),
    .S(_081_),
    .X(_021_));
 sky130_fd_sc_hd__mux2_1 _208_ (.A0(wr_data[6]),
    .A1(\period_reg[6] ),
    .S(_081_),
    .X(_022_));
 sky130_fd_sc_hd__mux2_1 _209_ (.A0(wr_data[7]),
    .A1(\period_reg[7] ),
    .S(_081_),
    .X(_023_));
 sky130_fd_sc_hd__sdfrtp_2 _210_ (.CLK(clk),
    .D(_097_),
    .RESET_B(reset_n),
    .SCD(scan_in[0]),
    .SCE(scan_en),
    .Q(rd_data[0]));
 sky130_fd_sc_hd__sdfrtp_2 _211_ (.CLK(clk),
    .D(_098_),
    .RESET_B(reset_n),
    .SCD(scan_in[1]),
    .SCE(scan_en),
    .Q(rd_data[1]));
 sky130_fd_sc_hd__sdfrtp_2 _212_ (.CLK(clk),
    .D(_099_),
    .RESET_B(reset_n),
    .SCD(scan_in[2]),
    .SCE(scan_en),
    .Q(rd_data[2]));
 sky130_fd_sc_hd__sdfrtp_2 _213_ (.CLK(clk),
    .D(_100_),
    .RESET_B(reset_n),
    .SCD(scan_in[3]),
    .SCE(scan_en),
    .Q(rd_data[3]));
 sky130_fd_sc_hd__sdfrtp_2 _214_ (.CLK(clk),
    .D(_101_),
    .RESET_B(reset_n),
    .SCD(rd_data[0]),
    .SCE(scan_en),
    .Q(rd_data[4]));
 sky130_fd_sc_hd__sdfrtp_2 _215_ (.CLK(clk),
    .D(_102_),
    .RESET_B(reset_n),
    .SCD(rd_data[1]),
    .SCE(scan_en),
    .Q(rd_data[5]));
 sky130_fd_sc_hd__sdfrtp_2 _216_ (.CLK(clk),
    .D(_103_),
    .RESET_B(reset_n),
    .SCD(rd_data[2]),
    .SCE(scan_en),
    .Q(rd_data[6]));
 sky130_fd_sc_hd__sdfrtp_2 _217_ (.CLK(clk),
    .D(_104_),
    .RESET_B(reset_n),
    .SCD(rd_data[3]),
    .SCE(scan_en),
    .Q(rd_data[7]));
 sky130_fd_sc_hd__sdfrtp_2 _218_ (.CLK(clk),
    .D(_008_),
    .RESET_B(reset_n),
    .SCD(rd_data[4]),
    .SCE(scan_en),
    .Q(pwm_out));
 sky130_fd_sc_hd__sdfrtp_2 _219_ (.CLK(clk),
    .D(\counter_reg[0] ),
    .RESET_B(reset_n),
    .SCD(rd_data[5]),
    .SCE(scan_en),
    .Q(counter_value[0]));
 sky130_fd_sc_hd__sdfrtp_2 _220_ (.CLK(clk),
    .D(\counter_reg[1] ),
    .RESET_B(reset_n),
    .SCD(rd_data[6]),
    .SCE(scan_en),
    .Q(counter_value[1]));
 sky130_fd_sc_hd__sdfrtp_2 _221_ (.CLK(clk),
    .D(\counter_reg[2] ),
    .RESET_B(reset_n),
    .SCD(rd_data[7]),
    .SCE(scan_en),
    .Q(counter_value[2]));
 sky130_fd_sc_hd__sdfrtp_2 _222_ (.CLK(clk),
    .D(\counter_reg[3] ),
    .RESET_B(reset_n),
    .SCD(pwm_out),
    .SCE(scan_en),
    .Q(counter_value[3]));
 sky130_fd_sc_hd__sdfrtp_2 _223_ (.CLK(clk),
    .D(\counter_reg[4] ),
    .RESET_B(reset_n),
    .SCD(counter_value[0]),
    .SCE(scan_en),
    .Q(counter_value[4]));
 sky130_fd_sc_hd__sdfrtp_2 _224_ (.CLK(clk),
    .D(\counter_reg[5] ),
    .RESET_B(reset_n),
    .SCD(counter_value[1]),
    .SCE(scan_en),
    .Q(counter_value[5]));
 sky130_fd_sc_hd__sdfrtp_2 _225_ (.CLK(clk),
    .D(\counter_reg[6] ),
    .RESET_B(reset_n),
    .SCD(counter_value[2]),
    .SCE(scan_en),
    .Q(counter_value[6]));
 sky130_fd_sc_hd__sdfrtp_2 _226_ (.CLK(clk),
    .D(\counter_reg[7] ),
    .RESET_B(reset_n),
    .SCD(counter_value[3]),
    .SCE(scan_en),
    .Q(counter_value[7]));
 sky130_fd_sc_hd__sdfrtp_2 _227_ (.CLK(clk),
    .D(_024_),
    .RESET_B(reset_n),
    .SCD(counter_value[4]),
    .SCE(scan_en),
    .Q(enable_reg));
 sky130_fd_sc_hd__sdfrtp_2 _228_ (.CLK(clk),
    .D(_025_),
    .RESET_B(reset_n),
    .SCD(counter_value[5]),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _229_ (.CLK(clk),
    .D(_009_),
    .RESET_B(reset_n),
    .SCD(counter_value[6]),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _230_ (.CLK(clk),
    .D(_010_),
    .RESET_B(reset_n),
    .SCD(counter_value[7]),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _231_ (.CLK(clk),
    .D(_011_),
    .RESET_B(reset_n),
    .SCD(enable_reg),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _232_ (.CLK(clk),
    .D(_012_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[0] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _233_ (.CLK(clk),
    .D(_013_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[1] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _234_ (.CLK(clk),
    .D(_014_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[2] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _235_ (.CLK(clk),
    .D(_015_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[3] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _236_ (.CLK(clk),
    .D(_016_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[4] ),
    .SCE(scan_en),
    .Q(\period_reg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _237_ (.CLK(clk),
    .D(_017_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[5] ),
    .SCE(scan_en),
    .Q(\period_reg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _238_ (.CLK(clk),
    .D(_018_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[6] ),
    .SCE(scan_en),
    .Q(\period_reg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _239_ (.CLK(clk),
    .D(_019_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[7] ),
    .SCE(scan_en),
    .Q(\period_reg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _240_ (.CLK(clk),
    .D(_020_),
    .RESET_B(reset_n),
    .SCD(\period_reg[0] ),
    .SCE(scan_en),
    .Q(\period_reg[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _241_ (.CLK(clk),
    .D(_021_),
    .RESET_B(reset_n),
    .SCD(\period_reg[1] ),
    .SCE(scan_en),
    .Q(\period_reg[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _242_ (.CLK(clk),
    .D(_022_),
    .RESET_B(reset_n),
    .SCD(\period_reg[2] ),
    .SCE(scan_en),
    .Q(\period_reg[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _243_ (.CLK(clk),
    .D(_023_),
    .RESET_B(reset_n),
    .SCD(\period_reg[3] ),
    .SCE(scan_en),
    .Q(\period_reg[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _244_ (.CLK(clk),
    .D(_000_),
    .RESET_B(reset_n),
    .SCD(\period_reg[4] ),
    .SCE(scan_en),
    .Q(\counter_reg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _245_ (.CLK(clk),
    .D(_001_),
    .RESET_B(reset_n),
    .SCD(\period_reg[5] ),
    .SCE(scan_en),
    .Q(\counter_reg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _246_ (.CLK(clk),
    .D(_002_),
    .RESET_B(reset_n),
    .SCD(\period_reg[6] ),
    .SCE(scan_en),
    .Q(\counter_reg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _247_ (.CLK(clk),
    .D(_003_),
    .RESET_B(reset_n),
    .SCD(\period_reg[7] ),
    .SCE(scan_en),
    .Q(\counter_reg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _248_ (.CLK(clk),
    .D(_004_),
    .RESET_B(reset_n),
    .SCD(\counter_reg[0] ),
    .SCE(scan_en),
    .Q(\counter_reg[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _249_ (.CLK(clk),
    .D(_005_),
    .RESET_B(reset_n),
    .SCD(\counter_reg[1] ),
    .SCE(scan_en),
    .Q(\counter_reg[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _250_ (.CLK(clk),
    .D(_006_),
    .RESET_B(reset_n),
    .SCD(\counter_reg[2] ),
    .SCE(scan_en),
    .Q(\counter_reg[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _251_ (.CLK(clk),
    .D(_007_),
    .RESET_B(reset_n),
    .SCD(\counter_reg[3] ),
    .SCE(scan_en),
    .Q(\counter_reg[7] ));
 assign scan_out[2] = \counter_reg[4] ;
 assign scan_out[3] = \counter_reg[5] ;
 assign scan_out[0] = \counter_reg[6] ;
 assign scan_out[1] = \counter_reg[7] ;
endmodule
