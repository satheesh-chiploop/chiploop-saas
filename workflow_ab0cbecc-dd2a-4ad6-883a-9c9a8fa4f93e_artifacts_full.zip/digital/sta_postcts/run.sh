#!/usr/bin/env bash
set -euo pipefail

echo "== ChipLoop: Digital STA PostCTS Agent =="
echo "PDK_VARIANT=sky130A"
echo "OPENLANE_IMAGE=ghcr.io/efabless/openlane2:2.4.0.dev1"
echo "WORKDIR=/work"

export OPENLANE_NUM_CORES=2

docker run --rm   -v "/root/chiploop-backend/backend/pdk":/pdk   -v "/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/ab0cbecc-dd2a-4ad6-883a-9c9a8fa4f93e/39d04ddb-be50-4def-85f8-415fea1d11d0/digital/arch2tapeout/digital/run_work":/work   -e PDK=sky130A   -e PDK_ROOT=/pdk   ghcr.io/efabless/openlane2:2.4.0.dev1   bash -lc 'set -e; cd /work && openlane --flow Classic --run-tag digital_ab0cbecc-dd2a-4ad6-883a-9c9a8fa4f93e --override-config RUN_LINTER=False --to OpenROAD.STAMidPNR sta_postcts/config.json'
