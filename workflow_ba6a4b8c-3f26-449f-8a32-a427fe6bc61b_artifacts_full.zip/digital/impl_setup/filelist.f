/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/ba6a4b8c-3f26-449f-8a32-a427fe6bc61b/04732f29-efd4-48d3-acb8-9590d262d77e/digital/system/imported_rtl/temp_sensor_adc_model.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/ba6a4b8c-3f26-449f-8a32-a427fe6bc61b/04732f29-efd4-48d3-acb8-9590d262d77e/digital/system/imported_rtl/temp_monitor_digital.v
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/ba6a4b8c-3f26-449f-8a32-a427fe6bc61b/04732f29-efd4-48d3-acb8-9590d262d77e/digital/system/imported_rtl/temp_monitor_soc_phys.sv
/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/ba6a4b8c-3f26-449f-8a32-a427fe6bc61b/04732f29-efd4-48d3-acb8-9590d262d77e/digital/system/imported_rtl/temp_monitor_soc_sim.sv
