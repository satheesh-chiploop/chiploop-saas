# Digital Executive Summary
- workflow_id: `ba6a4b8c-3f26-449f-8a32-a427fe6bc61b`
- run_tag: `System_PD_ba6a4b8c-3f26-449f-8a32-a427fe6bc61b`
- run_work_dir: `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/ba6a4b8c-3f26-449f-8a32-a427fe6bc61b/04732f29-efd4-48d3-acb8-9590d262d77e/digital/digital/run_work`

## Key Metrics (best-effort parsed)
- Cell count: `376`
- Area: `4659.4688`
- Flip-flops: `80`
- Latches: `0`
- STA stage used: `sta_postplace`
- Worst slack: `15.912`
- TNS: `0`
- DRC violations: `1182`
- DRC status: `violations_found`
- LVS status: `completed_with_deferred_xor_error`
- Tapeout status: `failed`
- Tapeout LEC status: `inconclusive_unresolved_cells`
- ATPG status: `patterns_generated`
- Summary status: `failed`

## STA Stage Breakdown
- sta_preplace: worst_slack=`11.249326233382876`, tns=`0`
- sta_postplace: worst_slack=`15.912`, tns=`0`
- sta_postcts: worst_slack=`None`, tns=`None`
- sta_postroute: worst_slack=`None`, tns=`None`
- sta_postfill: worst_slack=`None`, tns=`None`

## GDS Paths (local, only if produced)
- KLayout GDS: `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/ba6a4b8c-3f26-449f-8a32-a427fe6bc61b/04732f29-efd4-48d3-acb8-9590d262d77e/digital/digital/tapeout/gds/klayout.gds`
- Magic GDS: `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/ba6a4b8c-3f26-449f-8a32-a427fe6bc61b/04732f29-efd4-48d3-acb8-9590d262d77e/digital/digital/tapeout/gds/magic.gds`

## Artifact Map
- synth_metrics: `digital/synth/metrics.json`
- sta_preplace_metrics: `digital/sta_preplace/metrics.json`
- sta_postplace_metrics: `digital/sta_postplace/metrics.json`
- sta_postcts_metrics: `None`
- sta_postroute_metrics: `None`
- sta_postfill_metrics: `None`
- drc_metrics: `None`
- lvs_metrics: `None`
- tapeout_metrics: `digital/tapeout/metrics.json`

## Next Iteration Suggestions
- If worst_slack < 0: relax constraints or improve synthesis/placement/CTS/route parameters.
- If DRC violations > 0: inspect DRC logs and rerun with adjusted floorplan/route settings.
- If LVS not clean: check extraction/streamout mismatch and netlist naming.