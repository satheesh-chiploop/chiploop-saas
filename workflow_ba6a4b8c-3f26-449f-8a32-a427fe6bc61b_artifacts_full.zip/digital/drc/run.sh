#!/usr/bin/env bash
set -euo pipefail

echo "== ChipLoop: Digital DRC Agent =="
echo "PDK_VARIANT=sky130A"
echo "OPENLANE_IMAGE=ghcr.io/efabless/openlane2:2.4.0.dev1"
echo "WORKDIR=/work"

export OPENLANE_NUM_CORES=2

docker run --rm \
  -v "/root/chiploop-backend/backend/pdk":/pdk \
  -v "/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/ba6a4b8c-3f26-449f-8a32-a427fe6bc61b/04732f29-efd4-48d3-acb8-9590d262d77e/digital/digital/run_work":/work \
  -e PDK=sky130A \
  -e PDK_ROOT=/pdk \
  ghcr.io/efabless/openlane2:2.4.0.dev1 \
  bash -lc 'set -e; cd /work && openlane --flow Classic --run-tag System_PD_ba6a4b8c-3f26-449f-8a32-a427fe6bc61b --override-config RUN_LINTER=False --to KLayout.DRC drc/config.json'
