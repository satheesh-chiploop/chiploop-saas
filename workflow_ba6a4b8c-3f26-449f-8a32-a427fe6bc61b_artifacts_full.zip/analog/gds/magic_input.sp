.lib "$PDK_ROOT/sky130A/libs.tech/ngspice/sky130.lib.spice" tt

.subckt temp_sensor_adc_model VGND VPWR adc_code adc_code[0] adc_code[10] adc_code[11] adc_code[1] adc_code[2] adc_code[3] adc_code[4] adc_code[5] adc_code[6] adc_code[7] adc_code[8] adc_code[9] adc_valid avdd avss sample_req sensor_temp_celsius sensor_temp_celsius[0] sensor_temp_celsius[10] sensor_temp_celsius[11] sensor_temp_celsius[12] sensor_temp_celsius[13] sensor_temp_celsius[14] sensor_temp_celsius[15] sensor_temp_celsius[1] sensor_temp_celsius[2] sensor_temp_celsius[3] sensor_temp_celsius[4] sensor_temp_celsius[5] sensor_temp_celsius[6] sensor_temp_celsius[7] sensor_temp_celsius[8] sensor_temp_celsius[9]

M1 n_vref sensor_temp_celsius[15] avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M2 n_vref sensor_temp_celsius[14] avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M3 n_vref sensor_temp_celsius[13] avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M4 n_vref sensor_temp_celsius[12] avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M5 n_vref sensor_temp_celsius[11] avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M6 n_vref sensor_temp_celsius[10] avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M7 n_vref sensor_temp_celsius[9] avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M8 n_vref sensor_temp_celsius[8] avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M9 n_vref sensor_temp_celsius[7] avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M10 n_vref sensor_temp_celsius[6] avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M11 n_vref sensor_temp_celsius[5] avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M12 n_vref sensor_temp_celsius[4] avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M13 n_vref sensor_temp_celsius[3] avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M14 n_vref sensor_temp_celsius[2] avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M15 n_vref sensor_temp_celsius[1] avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M16 n_vref sensor_temp_celsius[0] avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15

M17 n_sample sample_req avss avss sky130_fd_pr__nfet_01v8 W=1.68 L=0.15
M18 n_sampleb sample_req VPWR VPWR sky130_fd_pr__pfet_01v8 W=1.68 L=0.15
M19 n_hold n_sample VPWR VPWR sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M20 n_holdb n_sample avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15

M21 adc_valid n_hold VPWR VPWR sky130_fd_pr__pfet_01v8 W=1.26 L=0.15
M22 adc_valid n_holdb avss avss sky130_fd_pr__nfet_01v8 W=1.26 L=0.15

M23 adc_code[0] n_vref avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M24 adc_code[1] n_vref avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M25 adc_code[2] n_vref avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M26 adc_code[3] n_vref avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M27 adc_code[4] n_vref avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M28 adc_code[5] n_vref avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M29 adc_code[6] n_vref avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M30 adc_code[7] n_vref avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M31 adc_code[8] n_vref avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M32 adc_code[9] n_vref avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M33 adc_code[10] n_vref avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M34 adc_code[11] n_vref avss avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15

M35 n_valid_p avdd sample_req avdd sky130_fd_pr__pfet_01v8 W=0.84 L=0.15
M36 n_valid_n avss sample_req avss sky130_fd_pr__nfet_01v8 W=0.84 L=0.15
M37 adc_code n_valid_p avdd avdd sky130_fd_pr__pfet_01v8 W=1.26 L=0.15
M38 adc_code n_valid_n avss avss sky130_fd_pr__nfet_01v8 W=1.26 L=0.15

M39 sensor_temp_celsius[0] VPWR VGND VGND sky130_fd_pr__nfet_01v8 W=0.42 L=0.15
M40 sensor_temp_celsius[1] VPWR VGND VGND sky130_fd_pr__nfet_01v8 W=0.42 L=0.15
M41 sensor_temp_celsius[2] VPWR VGND VGND sky130_fd_pr__nfet_01v8 W=0.42 L=0.15
M42 sensor_temp_celsius[3] VPWR VGND VGND sky130_fd_pr__nfet_01v8 W=0.42 L=0.15
M43 sensor_temp_celsius[4] VPWR VGND VGND sky130_fd_pr__nfet_01v8 W=0.42 L=0.15
M44 sensor_temp_celsius[5] VPWR VGND VGND sky130_fd_pr__nfet_01v8 W=0.42 L=0.15
M45 sensor_temp_celsius[6] VPWR VGND VGND sky130_fd_pr__nfet_01v8 W=0.42 L=0.15
M46 sensor_temp_celsius[7] VPWR VGND VGND sky130_fd_pr__nfet_01v8 W=0.42 L=0.15
M47 sensor_temp_celsius[8] VPWR VGND VGND sky130_fd_pr__nfet_01v8 W=0.42 L=0.15
M48 sensor_temp_celsius[9] VPWR VGND VGND sky130_fd_pr__nfet_01v8 W=0.42 L=0.15
M49 sensor_temp_celsius[10] VPWR VGND VGND sky130_fd_pr__nfet_01v8 W=0.42 L=0.15
M50 sensor_temp_celsius[11] VPWR VGND VGND sky130_fd_pr__nfet_01v8 W=0.42 L=0.15
M51 sensor_temp_celsius[12] VPWR VGND VGND sky130_fd_pr__nfet_01v8 W=0.42 L=0.15
M52 sensor_temp_celsius[13] VPWR VGND VGND sky130_fd_pr__nfet_01v8 W=0.42 L=0.15
M53 sensor_temp_celsius[14] VPWR VGND VGND sky130_fd_pr__nfet_01v8 W=0.42 L=0.15
M54 sensor_temp_celsius[15] VPWR VGND VGND sky130_fd_pr__nfet_01v8 W=0.42 L=0.15

.ends temp_sensor_adc_model
.end
