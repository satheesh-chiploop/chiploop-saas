# IP Packaging & Handoff Report

- Top: `imported_from_arch2rtl`
- Package: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/f8bb6e99-31f4-436c-ae90-bcae9a3c5905/0d2e18ad-ab4c-4d63-9408-3b32834d503b/digital/arch2synthesis/handoff/imported_from_arch2rtl_ip_package`
- Zip: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/f8bb6e99-31f4-436c-ae90-bcae9a3c5905/0d2e18ad-ab4c-4d63-9408-3b32834d503b/digital/arch2synthesis/handoff/imported_from_arch2rtl_ip_package.zip`

## Bucket counts
- **rtl**: 1
- **spec**: 1
- **arch**: 0
- **microarch**: 0
- **regmap**: 1
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 2
