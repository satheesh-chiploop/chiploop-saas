/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/f8bb6e99-31f4-436c-ae90-bcae9a3c5905/0d2e18ad-ab4c-4d63-9408-3b32834d503b/digital/arch2synthesis/handoff/rtl/pwm_controller.sv
