module pwm_controller (clk,
    pwm_out,
    rd_en,
    reset_n,
    scan_en,
    wr_en,
    counter_value,
    rd_addr,
    rd_data,
    scan_in,
    scan_out,
    wr_addr,
    wr_data);
 input clk;
 output pwm_out;
 input rd_en;
 input reset_n;
 input scan_en;
 input wr_en;
 output [7:0] counter_value;
 input [7:0] rd_addr;
 output [7:0] rd_data;
 input [3:0] scan_in;
 output [3:0] scan_out;
 input [7:0] wr_addr;
 input [7:0] wr_data;

 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire _086_;
 wire _087_;
 wire _088_;
 wire _089_;
 wire _090_;
 wire _091_;
 wire _092_;
 wire _093_;
 wire _094_;
 wire _095_;
 wire _096_;
 wire _097_;
 wire _098_;
 wire _099_;
 wire _100_;
 wire _101_;
 wire _102_;
 wire _103_;
 wire _104_;
 wire _105_;
 wire _106_;
 wire _107_;
 wire _108_;
 wire _109_;
 wire _110_;
 wire _111_;
 wire _112_;
 wire _113_;
 wire _114_;
 wire _115_;
 wire _116_;
 wire _117_;
 wire _118_;
 wire control_reg;
 wire \counter_reg[0] ;
 wire \counter_reg[1] ;
 wire \counter_reg[2] ;
 wire \counter_reg[3] ;
 wire \counter_reg[4] ;
 wire \counter_reg[5] ;
 wire \counter_reg[6] ;
 wire \counter_reg[7] ;
 wire \duty_cycle_reg[0] ;
 wire \duty_cycle_reg[1] ;
 wire \duty_cycle_reg[2] ;
 wire \duty_cycle_reg[3] ;
 wire \duty_cycle_reg[4] ;
 wire \duty_cycle_reg[5] ;
 wire \duty_cycle_reg[6] ;
 wire \duty_cycle_reg[7] ;
 wire \period_reg[0] ;
 wire \period_reg[1] ;
 wire \period_reg[2] ;
 wire \period_reg[3] ;
 wire \period_reg[4] ;
 wire \period_reg[5] ;
 wire \period_reg[6] ;
 wire \period_reg[7] ;

 sky130_fd_sc_hd__inv_2 _119_ (.A(\counter_reg[0] ),
    .Y(_105_));
 sky130_fd_sc_hd__inv_2 _120_ (.A(\counter_reg[1] ),
    .Y(_106_));
 sky130_fd_sc_hd__inv_2 _121_ (.A(\counter_reg[2] ),
    .Y(_107_));
 sky130_fd_sc_hd__inv_2 _122_ (.A(\counter_reg[3] ),
    .Y(_108_));
 sky130_fd_sc_hd__inv_2 _123_ (.A(\counter_reg[4] ),
    .Y(_109_));
 sky130_fd_sc_hd__inv_2 _124_ (.A(\counter_reg[5] ),
    .Y(_110_));
 sky130_fd_sc_hd__inv_2 _125_ (.A(\counter_reg[6] ),
    .Y(_111_));
 sky130_fd_sc_hd__inv_2 _126_ (.A(\counter_reg[7] ),
    .Y(_112_));
 sky130_fd_sc_hd__or2_2 _127_ (.A(rd_addr[5]),
    .B(rd_addr[4]),
    .X(_113_));
 sky130_fd_sc_hd__or4b_2 _128_ (.A(rd_addr[7]),
    .B(rd_addr[6]),
    .C(_113_),
    .D_N(rd_addr[3]),
    .X(_114_));
 sky130_fd_sc_hd__or3b_2 _129_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .C_N(rd_addr[2]),
    .X(_115_));
 sky130_fd_sc_hd__nor2_2 _130_ (.A(_114_),
    .B(_115_),
    .Y(_116_));
 sky130_fd_sc_hd__nor4_2 _131_ (.A(rd_addr[3]),
    .B(rd_addr[7]),
    .C(rd_addr[6]),
    .D(_113_),
    .Y(_117_));
 sky130_fd_sc_hd__nor3_2 _132_ (.A(rd_addr[1]),
    .B(rd_addr[0]),
    .C(rd_addr[2]),
    .Y(_118_));
 sky130_fd_sc_hd__a32o_2 _133_ (.A1(control_reg),
    .A2(_117_),
    .A3(_118_),
    .B1(\counter_reg[0] ),
    .B2(_116_),
    .X(_034_));
 sky130_fd_sc_hd__and2b_2 _134_ (.A_N(_114_),
    .B(_118_),
    .X(_035_));
 sky130_fd_sc_hd__and2b_2 _135_ (.A_N(_115_),
    .B(_117_),
    .X(_036_));
 sky130_fd_sc_hd__a22o_2 _136_ (.A1(\period_reg[0] ),
    .A2(_035_),
    .B1(_036_),
    .B2(\duty_cycle_reg[0] ),
    .X(_037_));
 sky130_fd_sc_hd__o21a_2 _137_ (.A1(_034_),
    .A2(_037_),
    .B1(rd_en),
    .X(_001_));
 sky130_fd_sc_hd__and2_2 _138_ (.A(\counter_reg[1] ),
    .B(_116_),
    .X(_038_));
 sky130_fd_sc_hd__a22o_2 _139_ (.A1(\period_reg[1] ),
    .A2(_035_),
    .B1(_036_),
    .B2(\duty_cycle_reg[1] ),
    .X(_039_));
 sky130_fd_sc_hd__o21a_2 _140_ (.A1(_038_),
    .A2(_039_),
    .B1(rd_en),
    .X(_002_));
 sky130_fd_sc_hd__and2_2 _141_ (.A(\duty_cycle_reg[2] ),
    .B(_036_),
    .X(_040_));
 sky130_fd_sc_hd__a22o_2 _142_ (.A1(\counter_reg[2] ),
    .A2(_116_),
    .B1(_035_),
    .B2(\period_reg[2] ),
    .X(_041_));
 sky130_fd_sc_hd__o21a_2 _143_ (.A1(_040_),
    .A2(_041_),
    .B1(rd_en),
    .X(_003_));
 sky130_fd_sc_hd__and2_2 _144_ (.A(\counter_reg[3] ),
    .B(_116_),
    .X(_042_));
 sky130_fd_sc_hd__a22o_2 _145_ (.A1(\period_reg[3] ),
    .A2(_035_),
    .B1(_036_),
    .B2(\duty_cycle_reg[3] ),
    .X(_043_));
 sky130_fd_sc_hd__o21a_2 _146_ (.A1(_042_),
    .A2(_043_),
    .B1(rd_en),
    .X(_004_));
 sky130_fd_sc_hd__and2_2 _147_ (.A(\duty_cycle_reg[4] ),
    .B(_036_),
    .X(_044_));
 sky130_fd_sc_hd__a22o_2 _148_ (.A1(\counter_reg[4] ),
    .A2(_116_),
    .B1(_035_),
    .B2(\period_reg[4] ),
    .X(_045_));
 sky130_fd_sc_hd__o21a_2 _149_ (.A1(_044_),
    .A2(_045_),
    .B1(rd_en),
    .X(_005_));
 sky130_fd_sc_hd__and2_2 _150_ (.A(\period_reg[5] ),
    .B(_035_),
    .X(_046_));
 sky130_fd_sc_hd__a22o_2 _151_ (.A1(\counter_reg[5] ),
    .A2(_116_),
    .B1(_036_),
    .B2(\duty_cycle_reg[5] ),
    .X(_047_));
 sky130_fd_sc_hd__o21a_2 _152_ (.A1(_046_),
    .A2(_047_),
    .B1(rd_en),
    .X(_006_));
 sky130_fd_sc_hd__and2_2 _153_ (.A(\counter_reg[6] ),
    .B(_116_),
    .X(_048_));
 sky130_fd_sc_hd__a22o_2 _154_ (.A1(\period_reg[6] ),
    .A2(_035_),
    .B1(_036_),
    .B2(\duty_cycle_reg[6] ),
    .X(_049_));
 sky130_fd_sc_hd__o21a_2 _155_ (.A1(_048_),
    .A2(_049_),
    .B1(rd_en),
    .X(_007_));
 sky130_fd_sc_hd__and2_2 _156_ (.A(\counter_reg[7] ),
    .B(_116_),
    .X(_050_));
 sky130_fd_sc_hd__a22o_2 _157_ (.A1(\period_reg[7] ),
    .A2(_035_),
    .B1(_036_),
    .B2(\duty_cycle_reg[7] ),
    .X(_051_));
 sky130_fd_sc_hd__o21a_2 _158_ (.A1(_050_),
    .A2(_051_),
    .B1(rd_en),
    .X(_008_));
 sky130_fd_sc_hd__and2_2 _159_ (.A(_110_),
    .B(\duty_cycle_reg[5] ),
    .X(_052_));
 sky130_fd_sc_hd__o22a_2 _160_ (.A1(_109_),
    .A2(\duty_cycle_reg[4] ),
    .B1(_110_),
    .B2(\duty_cycle_reg[5] ),
    .X(_053_));
 sky130_fd_sc_hd__and2_2 _161_ (.A(_107_),
    .B(\duty_cycle_reg[2] ),
    .X(_054_));
 sky130_fd_sc_hd__and2b_2 _162_ (.A_N(\counter_reg[1] ),
    .B(\duty_cycle_reg[1] ),
    .X(_055_));
 sky130_fd_sc_hd__and2b_2 _163_ (.A_N(\counter_reg[0] ),
    .B(\duty_cycle_reg[0] ),
    .X(_056_));
 sky130_fd_sc_hd__nand2b_2 _164_ (.A_N(\duty_cycle_reg[1] ),
    .B(\counter_reg[1] ),
    .Y(_057_));
 sky130_fd_sc_hd__o221a_2 _165_ (.A1(_107_),
    .A2(\duty_cycle_reg[2] ),
    .B1(_055_),
    .B2(_056_),
    .C1(_057_),
    .X(_058_));
 sky130_fd_sc_hd__o22a_2 _166_ (.A1(_108_),
    .A2(\duty_cycle_reg[3] ),
    .B1(_054_),
    .B2(_058_),
    .X(_059_));
 sky130_fd_sc_hd__a22o_2 _167_ (.A1(_108_),
    .A2(\duty_cycle_reg[3] ),
    .B1(_109_),
    .B2(\duty_cycle_reg[4] ),
    .X(_060_));
 sky130_fd_sc_hd__o21a_2 _168_ (.A1(_059_),
    .A2(_060_),
    .B1(_053_),
    .X(_061_));
 sky130_fd_sc_hd__o22a_2 _169_ (.A1(_111_),
    .A2(\duty_cycle_reg[6] ),
    .B1(_052_),
    .B2(_061_),
    .X(_062_));
 sky130_fd_sc_hd__a22o_2 _170_ (.A1(_111_),
    .A2(\duty_cycle_reg[6] ),
    .B1(_112_),
    .B2(\duty_cycle_reg[7] ),
    .X(_063_));
 sky130_fd_sc_hd__o221a_2 _171_ (.A1(_112_),
    .A2(\duty_cycle_reg[7] ),
    .B1(_062_),
    .B2(_063_),
    .C1(control_reg),
    .X(_000_));
 sky130_fd_sc_hd__or3_2 _172_ (.A(wr_addr[5]),
    .B(wr_addr[4]),
    .C(wr_addr[7]),
    .X(_064_));
 sky130_fd_sc_hd__or3b_2 _173_ (.A(_064_),
    .B(wr_addr[6]),
    .C_N(wr_en),
    .X(_065_));
 sky130_fd_sc_hd__or2_2 _174_ (.A(wr_addr[3]),
    .B(_065_),
    .X(_066_));
 sky130_fd_sc_hd__or4_2 _175_ (.A(wr_addr[2]),
    .B(wr_addr[1]),
    .C(wr_addr[0]),
    .D(_066_),
    .X(_067_));
 sky130_fd_sc_hd__mux2_1 _176_ (.A0(wr_data[0]),
    .A1(control_reg),
    .S(_067_),
    .X(_009_));
 sky130_fd_sc_hd__nor4b_2 _177_ (.A(wr_addr[1]),
    .B(wr_addr[0]),
    .C(_066_),
    .D_N(wr_addr[2]),
    .Y(_068_));
 sky130_fd_sc_hd__mux2_1 _178_ (.A0(\duty_cycle_reg[0] ),
    .A1(wr_data[0]),
    .S(_068_),
    .X(_010_));
 sky130_fd_sc_hd__mux2_1 _179_ (.A0(\duty_cycle_reg[1] ),
    .A1(wr_data[1]),
    .S(_068_),
    .X(_011_));
 sky130_fd_sc_hd__mux2_1 _180_ (.A0(\duty_cycle_reg[2] ),
    .A1(wr_data[2]),
    .S(_068_),
    .X(_012_));
 sky130_fd_sc_hd__mux2_1 _181_ (.A0(\duty_cycle_reg[3] ),
    .A1(wr_data[3]),
    .S(_068_),
    .X(_013_));
 sky130_fd_sc_hd__mux2_1 _182_ (.A0(\duty_cycle_reg[4] ),
    .A1(wr_data[4]),
    .S(_068_),
    .X(_014_));
 sky130_fd_sc_hd__mux2_1 _183_ (.A0(\duty_cycle_reg[5] ),
    .A1(wr_data[5]),
    .S(_068_),
    .X(_015_));
 sky130_fd_sc_hd__mux2_1 _184_ (.A0(\duty_cycle_reg[6] ),
    .A1(wr_data[6]),
    .S(_068_),
    .X(_016_));
 sky130_fd_sc_hd__mux2_1 _185_ (.A0(\duty_cycle_reg[7] ),
    .A1(wr_data[7]),
    .S(_068_),
    .X(_017_));
 sky130_fd_sc_hd__or4_2 _186_ (.A(\period_reg[1] ),
    .B(\period_reg[0] ),
    .C(\period_reg[3] ),
    .D(\period_reg[2] ),
    .X(_069_));
 sky130_fd_sc_hd__or4_2 _187_ (.A(\period_reg[5] ),
    .B(\period_reg[4] ),
    .C(\period_reg[7] ),
    .D(\period_reg[6] ),
    .X(_070_));
 sky130_fd_sc_hd__o21ai_2 _188_ (.A1(_069_),
    .A2(_070_),
    .B1(control_reg),
    .Y(_071_));
 sky130_fd_sc_hd__o211a_2 _189_ (.A1(\period_reg[1] ),
    .A2(_106_),
    .B1(_105_),
    .C1(\period_reg[0] ),
    .X(_072_));
 sky130_fd_sc_hd__a221o_2 _190_ (.A1(\period_reg[1] ),
    .A2(_106_),
    .B1(_107_),
    .B2(\period_reg[2] ),
    .C1(_072_),
    .X(_073_));
 sky130_fd_sc_hd__o22a_2 _191_ (.A1(\period_reg[2] ),
    .A2(_107_),
    .B1(_108_),
    .B2(\period_reg[3] ),
    .X(_074_));
 sky130_fd_sc_hd__and2b_2 _192_ (.A_N(\period_reg[7] ),
    .B(\counter_reg[7] ),
    .X(_075_));
 sky130_fd_sc_hd__and2b_2 _193_ (.A_N(\period_reg[6] ),
    .B(\counter_reg[6] ),
    .X(_076_));
 sky130_fd_sc_hd__and2b_2 _194_ (.A_N(\counter_reg[7] ),
    .B(\period_reg[7] ),
    .X(_077_));
 sky130_fd_sc_hd__or3_2 _195_ (.A(_075_),
    .B(_076_),
    .C(_077_),
    .X(_078_));
 sky130_fd_sc_hd__a21o_2 _196_ (.A1(\period_reg[6] ),
    .A2(_111_),
    .B1(_078_),
    .X(_079_));
 sky130_fd_sc_hd__o22a_2 _197_ (.A1(\period_reg[4] ),
    .A2(_109_),
    .B1(_110_),
    .B2(\period_reg[5] ),
    .X(_080_));
 sky130_fd_sc_hd__and2_2 _198_ (.A(\period_reg[5] ),
    .B(_110_),
    .X(_081_));
 sky130_fd_sc_hd__a22o_2 _199_ (.A1(\period_reg[3] ),
    .A2(_108_),
    .B1(_109_),
    .B2(\period_reg[4] ),
    .X(_082_));
 sky130_fd_sc_hd__or3b_2 _200_ (.A(_081_),
    .B(_082_),
    .C_N(_080_),
    .X(_083_));
 sky130_fd_sc_hd__a211o_2 _201_ (.A1(_073_),
    .A2(_074_),
    .B1(_079_),
    .C1(_083_),
    .X(_084_));
 sky130_fd_sc_hd__or3_2 _202_ (.A(_079_),
    .B(_080_),
    .C(_081_),
    .X(_085_));
 sky130_fd_sc_hd__o21bai_2 _203_ (.A1(_075_),
    .A2(_076_),
    .B1_N(_077_),
    .Y(_086_));
 sky130_fd_sc_hd__and4b_2 _204_ (.A_N(_071_),
    .B(_084_),
    .C(_085_),
    .D(_086_),
    .X(_087_));
 sky130_fd_sc_hd__mux2_1 _205_ (.A0(_071_),
    .A1(_087_),
    .S(_105_),
    .X(_018_));
 sky130_fd_sc_hd__nand2_2 _206_ (.A(\counter_reg[0] ),
    .B(\counter_reg[1] ),
    .Y(_088_));
 sky130_fd_sc_hd__or2_2 _207_ (.A(\counter_reg[0] ),
    .B(\counter_reg[1] ),
    .X(_089_));
 sky130_fd_sc_hd__a32o_2 _208_ (.A1(_087_),
    .A2(_088_),
    .A3(_089_),
    .B1(_071_),
    .B2(\counter_reg[1] ),
    .X(_019_));
 sky130_fd_sc_hd__nand2_2 _209_ (.A(_107_),
    .B(_088_),
    .Y(_090_));
 sky130_fd_sc_hd__nand3_2 _210_ (.A(\counter_reg[0] ),
    .B(\counter_reg[1] ),
    .C(\counter_reg[2] ),
    .Y(_091_));
 sky130_fd_sc_hd__a32o_2 _211_ (.A1(_087_),
    .A2(_090_),
    .A3(_091_),
    .B1(_071_),
    .B2(\counter_reg[2] ),
    .X(_020_));
 sky130_fd_sc_hd__nand2_2 _212_ (.A(_108_),
    .B(_091_),
    .Y(_092_));
 sky130_fd_sc_hd__nor2_2 _213_ (.A(_108_),
    .B(_091_),
    .Y(_093_));
 sky130_fd_sc_hd__inv_2 _214_ (.A(_093_),
    .Y(_094_));
 sky130_fd_sc_hd__a32o_2 _215_ (.A1(_087_),
    .A2(_092_),
    .A3(_094_),
    .B1(_071_),
    .B2(\counter_reg[3] ),
    .X(_021_));
 sky130_fd_sc_hd__or2_2 _216_ (.A(\counter_reg[4] ),
    .B(_093_),
    .X(_095_));
 sky130_fd_sc_hd__nand2_2 _217_ (.A(\counter_reg[4] ),
    .B(_093_),
    .Y(_096_));
 sky130_fd_sc_hd__a32o_2 _218_ (.A1(_087_),
    .A2(_095_),
    .A3(_096_),
    .B1(_071_),
    .B2(\counter_reg[4] ),
    .X(_022_));
 sky130_fd_sc_hd__nand2_2 _219_ (.A(_110_),
    .B(_096_),
    .Y(_097_));
 sky130_fd_sc_hd__nor2_2 _220_ (.A(_110_),
    .B(_096_),
    .Y(_098_));
 sky130_fd_sc_hd__inv_2 _221_ (.A(_098_),
    .Y(_099_));
 sky130_fd_sc_hd__a32o_2 _222_ (.A1(_087_),
    .A2(_097_),
    .A3(_099_),
    .B1(_071_),
    .B2(\counter_reg[5] ),
    .X(_023_));
 sky130_fd_sc_hd__or2_2 _223_ (.A(\counter_reg[6] ),
    .B(_098_),
    .X(_100_));
 sky130_fd_sc_hd__nand2_2 _224_ (.A(\counter_reg[6] ),
    .B(_098_),
    .Y(_101_));
 sky130_fd_sc_hd__a32o_2 _225_ (.A1(_087_),
    .A2(_100_),
    .A3(_101_),
    .B1(_071_),
    .B2(\counter_reg[6] ),
    .X(_024_));
 sky130_fd_sc_hd__a21o_2 _226_ (.A1(\counter_reg[6] ),
    .A2(_098_),
    .B1(\counter_reg[7] ),
    .X(_102_));
 sky130_fd_sc_hd__a22o_2 _227_ (.A1(\counter_reg[7] ),
    .A2(_071_),
    .B1(_087_),
    .B2(_102_),
    .X(_025_));
 sky130_fd_sc_hd__or4b_2 _228_ (.A(wr_addr[2]),
    .B(wr_addr[1]),
    .C(wr_addr[0]),
    .D_N(wr_addr[3]),
    .X(_103_));
 sky130_fd_sc_hd__or2_2 _229_ (.A(_065_),
    .B(_103_),
    .X(_104_));
 sky130_fd_sc_hd__mux2_1 _230_ (.A0(wr_data[0]),
    .A1(\period_reg[0] ),
    .S(_104_),
    .X(_026_));
 sky130_fd_sc_hd__mux2_1 _231_ (.A0(wr_data[1]),
    .A1(\period_reg[1] ),
    .S(_104_),
    .X(_027_));
 sky130_fd_sc_hd__mux2_1 _232_ (.A0(wr_data[2]),
    .A1(\period_reg[2] ),
    .S(_104_),
    .X(_028_));
 sky130_fd_sc_hd__mux2_1 _233_ (.A0(wr_data[3]),
    .A1(\period_reg[3] ),
    .S(_104_),
    .X(_029_));
 sky130_fd_sc_hd__mux2_1 _234_ (.A0(wr_data[4]),
    .A1(\period_reg[4] ),
    .S(_104_),
    .X(_030_));
 sky130_fd_sc_hd__mux2_1 _235_ (.A0(wr_data[5]),
    .A1(\period_reg[5] ),
    .S(_104_),
    .X(_031_));
 sky130_fd_sc_hd__mux2_1 _236_ (.A0(wr_data[6]),
    .A1(\period_reg[6] ),
    .S(_104_),
    .X(_032_));
 sky130_fd_sc_hd__mux2_1 _237_ (.A0(wr_data[7]),
    .A1(\period_reg[7] ),
    .S(_104_),
    .X(_033_));
 sky130_fd_sc_hd__sdfrtp_2 _238_ (.CLK(clk),
    .D(_001_),
    .RESET_B(reset_n),
    .SCD(scan_in[0]),
    .SCE(scan_en),
    .Q(rd_data[0]));
 sky130_fd_sc_hd__sdfrtp_2 _239_ (.CLK(clk),
    .D(_002_),
    .RESET_B(reset_n),
    .SCD(scan_in[1]),
    .SCE(scan_en),
    .Q(rd_data[1]));
 sky130_fd_sc_hd__sdfrtp_2 _240_ (.CLK(clk),
    .D(_003_),
    .RESET_B(reset_n),
    .SCD(scan_in[2]),
    .SCE(scan_en),
    .Q(rd_data[2]));
 sky130_fd_sc_hd__sdfrtp_2 _241_ (.CLK(clk),
    .D(_004_),
    .RESET_B(reset_n),
    .SCD(scan_in[3]),
    .SCE(scan_en),
    .Q(rd_data[3]));
 sky130_fd_sc_hd__sdfrtp_2 _242_ (.CLK(clk),
    .D(_005_),
    .RESET_B(reset_n),
    .SCD(rd_data[0]),
    .SCE(scan_en),
    .Q(rd_data[4]));
 sky130_fd_sc_hd__sdfrtp_2 _243_ (.CLK(clk),
    .D(_006_),
    .RESET_B(reset_n),
    .SCD(rd_data[1]),
    .SCE(scan_en),
    .Q(rd_data[5]));
 sky130_fd_sc_hd__sdfrtp_2 _244_ (.CLK(clk),
    .D(_007_),
    .RESET_B(reset_n),
    .SCD(rd_data[2]),
    .SCE(scan_en),
    .Q(rd_data[6]));
 sky130_fd_sc_hd__sdfrtp_2 _245_ (.CLK(clk),
    .D(_008_),
    .RESET_B(reset_n),
    .SCD(rd_data[3]),
    .SCE(scan_en),
    .Q(rd_data[7]));
 sky130_fd_sc_hd__sdfrtp_2 _246_ (.CLK(clk),
    .D(_000_),
    .RESET_B(reset_n),
    .SCD(rd_data[4]),
    .SCE(scan_en),
    .Q(pwm_out));
 sky130_fd_sc_hd__sdfrtp_2 _247_ (.CLK(clk),
    .D(\counter_reg[0] ),
    .RESET_B(reset_n),
    .SCD(rd_data[5]),
    .SCE(scan_en),
    .Q(counter_value[0]));
 sky130_fd_sc_hd__sdfrtp_2 _248_ (.CLK(clk),
    .D(\counter_reg[1] ),
    .RESET_B(reset_n),
    .SCD(rd_data[6]),
    .SCE(scan_en),
    .Q(counter_value[1]));
 sky130_fd_sc_hd__sdfrtp_2 _249_ (.CLK(clk),
    .D(\counter_reg[2] ),
    .RESET_B(reset_n),
    .SCD(rd_data[7]),
    .SCE(scan_en),
    .Q(counter_value[2]));
 sky130_fd_sc_hd__sdfrtp_2 _250_ (.CLK(clk),
    .D(\counter_reg[3] ),
    .RESET_B(reset_n),
    .SCD(pwm_out),
    .SCE(scan_en),
    .Q(counter_value[3]));
 sky130_fd_sc_hd__sdfrtp_2 _251_ (.CLK(clk),
    .D(\counter_reg[4] ),
    .RESET_B(reset_n),
    .SCD(counter_value[0]),
    .SCE(scan_en),
    .Q(counter_value[4]));
 sky130_fd_sc_hd__sdfrtp_2 _252_ (.CLK(clk),
    .D(\counter_reg[5] ),
    .RESET_B(reset_n),
    .SCD(counter_value[1]),
    .SCE(scan_en),
    .Q(counter_value[5]));
 sky130_fd_sc_hd__sdfrtp_2 _253_ (.CLK(clk),
    .D(\counter_reg[6] ),
    .RESET_B(reset_n),
    .SCD(counter_value[2]),
    .SCE(scan_en),
    .Q(counter_value[6]));
 sky130_fd_sc_hd__sdfrtp_2 _254_ (.CLK(clk),
    .D(\counter_reg[7] ),
    .RESET_B(reset_n),
    .SCD(counter_value[3]),
    .SCE(scan_en),
    .Q(counter_value[7]));
 sky130_fd_sc_hd__sdfrtp_2 _255_ (.CLK(clk),
    .D(_009_),
    .RESET_B(reset_n),
    .SCD(counter_value[4]),
    .SCE(scan_en),
    .Q(control_reg));
 sky130_fd_sc_hd__sdfrtp_2 _256_ (.CLK(clk),
    .D(_010_),
    .RESET_B(reset_n),
    .SCD(counter_value[5]),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _257_ (.CLK(clk),
    .D(_011_),
    .RESET_B(reset_n),
    .SCD(counter_value[6]),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _258_ (.CLK(clk),
    .D(_012_),
    .RESET_B(reset_n),
    .SCD(counter_value[7]),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _259_ (.CLK(clk),
    .D(_013_),
    .RESET_B(reset_n),
    .SCD(control_reg),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _260_ (.CLK(clk),
    .D(_014_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[0] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _261_ (.CLK(clk),
    .D(_015_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[1] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _262_ (.CLK(clk),
    .D(_016_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[2] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _263_ (.CLK(clk),
    .D(_017_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[3] ),
    .SCE(scan_en),
    .Q(\duty_cycle_reg[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _264_ (.CLK(clk),
    .D(_018_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[4] ),
    .SCE(scan_en),
    .Q(\counter_reg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _265_ (.CLK(clk),
    .D(_019_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[5] ),
    .SCE(scan_en),
    .Q(\counter_reg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _266_ (.CLK(clk),
    .D(_020_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[6] ),
    .SCE(scan_en),
    .Q(\counter_reg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _267_ (.CLK(clk),
    .D(_021_),
    .RESET_B(reset_n),
    .SCD(\duty_cycle_reg[7] ),
    .SCE(scan_en),
    .Q(\counter_reg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _268_ (.CLK(clk),
    .D(_022_),
    .RESET_B(reset_n),
    .SCD(\counter_reg[0] ),
    .SCE(scan_en),
    .Q(\counter_reg[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _269_ (.CLK(clk),
    .D(_023_),
    .RESET_B(reset_n),
    .SCD(\counter_reg[1] ),
    .SCE(scan_en),
    .Q(\counter_reg[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _270_ (.CLK(clk),
    .D(_024_),
    .RESET_B(reset_n),
    .SCD(\counter_reg[2] ),
    .SCE(scan_en),
    .Q(\counter_reg[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _271_ (.CLK(clk),
    .D(_025_),
    .RESET_B(reset_n),
    .SCD(\counter_reg[3] ),
    .SCE(scan_en),
    .Q(\counter_reg[7] ));
 sky130_fd_sc_hd__sdfrtp_2 _272_ (.CLK(clk),
    .D(_026_),
    .RESET_B(reset_n),
    .SCD(\counter_reg[4] ),
    .SCE(scan_en),
    .Q(\period_reg[0] ));
 sky130_fd_sc_hd__sdfrtp_2 _273_ (.CLK(clk),
    .D(_027_),
    .RESET_B(reset_n),
    .SCD(\counter_reg[5] ),
    .SCE(scan_en),
    .Q(\period_reg[1] ));
 sky130_fd_sc_hd__sdfrtp_2 _274_ (.CLK(clk),
    .D(_028_),
    .RESET_B(reset_n),
    .SCD(\counter_reg[6] ),
    .SCE(scan_en),
    .Q(\period_reg[2] ));
 sky130_fd_sc_hd__sdfrtp_2 _275_ (.CLK(clk),
    .D(_029_),
    .RESET_B(reset_n),
    .SCD(\counter_reg[7] ),
    .SCE(scan_en),
    .Q(\period_reg[3] ));
 sky130_fd_sc_hd__sdfrtp_2 _276_ (.CLK(clk),
    .D(_030_),
    .RESET_B(reset_n),
    .SCD(\period_reg[0] ),
    .SCE(scan_en),
    .Q(\period_reg[4] ));
 sky130_fd_sc_hd__sdfrtp_2 _277_ (.CLK(clk),
    .D(_031_),
    .RESET_B(reset_n),
    .SCD(\period_reg[1] ),
    .SCE(scan_en),
    .Q(\period_reg[5] ));
 sky130_fd_sc_hd__sdfrtp_2 _278_ (.CLK(clk),
    .D(_032_),
    .RESET_B(reset_n),
    .SCD(\period_reg[2] ),
    .SCE(scan_en),
    .Q(\period_reg[6] ));
 sky130_fd_sc_hd__sdfrtp_2 _279_ (.CLK(clk),
    .D(_033_),
    .RESET_B(reset_n),
    .SCD(\period_reg[3] ),
    .SCE(scan_en),
    .Q(\period_reg[7] ));
 assign scan_out[2] = \period_reg[4] ;
 assign scan_out[3] = \period_reg[5] ;
 assign scan_out[0] = \period_reg[6] ;
 assign scan_out[1] = \period_reg[7] ;
endmodule
