# Digital Synthesis Summary

- **Workflow**: f8bb6e99-31f4-436c-ae90-bcae9a3c5905
- **Status**: `ok` (rc=0)
- **Top module**: `pwm_controller`
- **Clock**: `clk` @ **5.000 ns**
- **PDK**: `sky130A`
- **Image**: `ghcr.io/efabless/openlane2:2.4.0.dev1`
- **OpenLane stop step**: `OpenROAD.STAPrePNR`

## Deterministic outputs (rerunnable)
- `digital/synth/config.json`
- `digital/synth/constraints/top.sdc`
- `digital/synth/run.sh`
- `digital/synth/logs/openlane_synth.log`

## Parsed outputs (best-effort)
- metrics.json: `artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/f8bb6e99-31f4-436c-ae90-bcae9a3c5905/0d2e18ad-ab4c-4d63-9408-3b32834d503b/digital/arch2synthesis/digital/synth/runs/digital_f8bb6e99-31f4-436c-ae90-bcae9a3c5905/final/metrics.json`
- netlist candidates: 1 found
