module temp_sensor_adc_model (
    input  sample_req,
    input  [15:0] sensor_temp_celsius,
    input  avdd,
    input  avss,
    output reg [11:0] adc_code,
    output reg adc_valid
);

    localparam integer NOMINAL_LATENCY = 2;
    localparam integer TEMP_SCALE_NUM   = 1;
    localparam integer TEMP_SCALE_DEN   = 1;
    localparam integer GAIN_ERROR_PPM   = 0;
    localparam integer OFFSET_ERROR     = 0;

    reg [11:0] last_conversion_code;
    reg conversion_in_progress;
    reg [31:0] sample_timer;
    reg [31:0] pending_code;
    reg [31:0] scaled_temp;
    reg [31:0] gain_term;
    reg [31:0] temp_linear;
    reg [31:0] temp_with_offset;
    reg [31:0] quantized_code;
    reg [31:0] temp_unsigned;

    

    always @(posedge sample_req) begin
        temp_unsigned = {16'd0, sensor_temp_celsius};

        gain_term = (temp_unsigned * (1000000 + GAIN_ERROR_PPM)) / 1000000;
        scaled_temp = (gain_term * TEMP_SCALE_NUM) / TEMP_SCALE_DEN;
        temp_with_offset = scaled_temp + OFFSET_ERROR;

        if (temp_with_offset[31] == 1'b1)
            quantized_code = 32'd0;
        else if (temp_with_offset > 32'd4095)
            quantized_code = 32'd4095;
        else
            quantized_code = temp_with_offset;

        pending_code = quantized_code;
        sample_timer = NOMINAL_LATENCY;
        conversion_in_progress = 1'b1;
        adc_valid = 1'b0;
    end

    always @(posedge avdd or posedge avss) begin
        if (conversion_in_progress) begin
            if (sample_timer != 0)
                sample_timer <= sample_timer - 1'b1;

            if (sample_timer == 1) begin
                if (pending_code > 32'd4095)
                    last_conversion_code <= 12'd4095;
                else
                    last_conversion_code <= pending_code[11:0];

                adc_code <= (pending_code > 32'd4095) ? 12'd4095 : pending_code[11:0];
                adc_valid <= 1'b1;
                conversion_in_progress <= 1'b0;
                sample_timer <= 32'd0;
            end
        end
    end

    initial begin
        adc_code <= 12'd0;
        adc_valid <= 1'b0;
        last_conversion_code <= 12'd0;
        conversion_in_progress <= 1'b0;
        sample_timer <= 32'd0;
        pending_code = 32'd0;
        scaled_temp = 32'd0;
        gain_term = 32'd0;
        temp_linear = 32'd0;
        temp_with_offset = 32'd0;
        quantized_code = 32'd0;
        temp_unsigned = 32'd0;
    end

    

endmodule
