# Spec-to-RTL Conformance Report

Status: **partial**

- Requirements checked: 37
- Matched: 34
- Partial: 0
- Missing: 3
- Inconclusive: 0
- Interface: pass
- Register map: pass
- Clock/reset: pass

## Missing Or Partial Requirements
- REQ-001 [missing]: Decode register accesses for CONTROL, STATUS, THRESHOLD, LATEST_TEMP, SAMPLE_COUNT, IRQ_STATUS, and IRQ_CLEAR.
- REQ-004 [missing]: Maintain sticky status and IRQ latch bits with the specified clear semantics.
- REQ-024 [missing]: ALERT_CLEAR and IRQ_CLEAR only clear their specified bits and must not alter LATEST_TEMP, THRESHOLD, or SAMPLE_COUNT.
