module temp_monitor_digital (
    clk,
    reset_n,
    wr_en,
    wr_addr,
    wr_data,
    rd_en,
    rd_addr,
    adc_code,
    adc_valid,
    rd_data,
    sample_req,
    alert_irq,
    temp_code,
    threshold_code,
    alert_status
);

input clk;
input reset_n;
input wr_en;
input [7:0] wr_addr;
input [15:0] wr_data;
input rd_en;
input [7:0] rd_addr;
input [11:0] adc_code;
input adc_valid;

output [15:0] rd_data;
output sample_req;
output alert_irq;
output [11:0] temp_code;
output [11:0] threshold_code;
output alert_status;

reg [15:0] rd_data_reg;
reg sample_req_reg;
reg alert_irq_reg;
reg [11:0] temp_code_reg;
reg [11:0] threshold_code_reg;
reg alert_status_reg;

reg control_enable;
reg control_irq_enable;
reg status_sample_done;
reg status_alert_pending;
reg status_adc_valid_seen;
reg status_busy;
reg irq_status_alert;
reg irq_status_sample_done;
reg [11:0] latest_temp_reg;
reg [15:0] sample_count_reg;
reg [11:0] adc_prev_reg;
reg adc_prev_valid;
reg sample_req_pending;
reg periodic_req_pending;
reg [3:0] periodic_counter;
reg [11:0] avg_temp_next;
reg [12:0] sum_temp;

wire sample_complete;
wire do_sample_req;
wire control_sample_start;
wire control_alert_clear;
wire irq_clear_alert;
wire irq_clear_sample_done;
wire sample_pending_now;
wire [11:0] avg_temp_calc;
wire [15:0] sample_count_next;
wire [3:0] periodic_counter_next;

assign rd_data = rd_data_reg;
assign sample_req = sample_req_reg;
assign alert_irq = alert_irq_reg;
assign temp_code = temp_code_reg;
assign threshold_code = threshold_code_reg;
assign alert_status = alert_status_reg;

assign control_sample_start = wr_en && (wr_addr == 8'h00) && wr_data[1];
assign control_alert_clear = wr_en && (wr_addr == 8'h00) && wr_data[3];
assign irq_clear_alert = wr_en && (wr_addr == 8'h18) && wr_data[0];
assign irq_clear_sample_done = wr_en && (wr_addr == 8'h18) && wr_data[1];
assign sample_complete = adc_valid;
assign sample_pending_now = sample_req_pending | periodic_req_pending;
assign do_sample_req = control_sample_start | periodic_req_pending;

assign avg_temp_calc = sum_temp[12:1];

assign sample_count_next = sample_count_reg + 16'h0001;
assign periodic_counter_next = periodic_counter + 4'h1;

always @(*) begin
    rd_data_reg = 16'h0000;
    case (rd_addr)
        8'h00: rd_data_reg = {12'h000, control_enable, 1'b0, control_irq_enable, 1'b0};
        8'h04: rd_data_reg = {12'h000, status_busy, status_adc_valid_seen, status_alert_pending, status_sample_done};
        8'h08: rd_data_reg = {4'h0, threshold_code_reg};
        8'h0C: rd_data_reg = {4'h0, temp_code_reg};
        8'h10: rd_data_reg = sample_count_reg;
        8'h14: rd_data_reg = {14'h0000, irq_status_sample_done, irq_status_alert};
        8'h18: rd_data_reg = 16'h0000;
        default: rd_data_reg = 16'h0000;
    endcase
end

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        control_enable <= 1'b0;
        control_irq_enable <= 1'b0;
        status_sample_done <= 1'b0;
        status_alert_pending <= 1'b0;
        status_adc_valid_seen <= 1'b0;
        status_busy <= 1'b0;
        irq_status_alert <= 1'b0;
        irq_status_sample_done <= 1'b0;
        latest_temp_reg <= 12'h000;
        sample_count_reg <= 16'h0000;
        adc_prev_reg <= 12'h000;
        adc_prev_valid <= 1'b0;
        sample_req_pending <= 1'b0;
        periodic_req_pending <= 1'b0;
        periodic_counter <= 4'h0;
        temp_code_reg <= 12'h000;
        threshold_code_reg <= 12'h000;
        alert_status_reg <= 1'b0;
        sample_req_reg <= 1'b0;
        alert_irq_reg <= 1'b0;
        sum_temp <= 13'h0000;
    end else begin
        sample_req_reg <= 1'b0;

        if (wr_en && (wr_addr == 8'h00)) begin
            control_enable <= wr_data[0];
            control_irq_enable <= wr_data[2];
            if (wr_data[1]) begin
                sample_req_reg <= 1'b1;
                sample_req_pending <= 1'b1;
            end
            if (wr_data[3]) begin
                alert_status_reg <= 1'b0;
                status_alert_pending <= 1'b0;
                irq_status_alert <= 1'b0;
            end
        end

        if (wr_en && (wr_addr == 8'h08)) begin
            threshold_code_reg <= wr_data[11:0];
        end

        if (control_enable && !sample_req_pending && !periodic_req_pending) begin
            if (periodic_counter == 4'hF) begin
                periodic_counter <= 4'h0;
                periodic_req_pending <= 1'b1;
                sample_req_reg <= 1'b1;
            end else begin
                periodic_counter <= periodic_counter_next;
            end
        end else if (!control_enable) begin
            periodic_counter <= 4'h0;
            periodic_req_pending <= 1'b0;
        end

        if (sample_complete) begin
            status_adc_valid_seen <= 1'b1;
            status_sample_done <= 1'b1;
            irq_status_sample_done <= 1'b1;
            sample_count_reg <= sample_count_next;
            latest_temp_reg <= avg_temp_calc;
            temp_code_reg <= avg_temp_calc;
            adc_prev_reg <= adc_code;
            adc_prev_valid <= 1'b1;
            sample_req_pending <= 1'b0;
            periodic_req_pending <= 1'b0;
            status_busy <= 1'b0;
            sum_temp <= {1'b0, adc_prev_reg} + {1'b0, adc_code};
            if (avg_temp_calc > threshold_code_reg) begin
                alert_status_reg <= 1'b1;
                status_alert_pending <= 1'b1;
                irq_status_alert <= 1'b1;
            end
        end else begin
            if (do_sample_req) begin
                status_busy <= 1'b1;
            end
        end

        if (control_alert_clear || irq_clear_alert) begin
            alert_status_reg <= 1'b0;
            status_alert_pending <= 1'b0;
            irq_status_alert <= 1'b0;
        end

        if (irq_clear_sample_done) begin
            status_sample_done <= 1'b0;
            irq_status_sample_done <= 1'b0;
        end

        if (control_enable && !sample_req_pending && !periodic_req_pending && !sample_complete) begin
            status_busy <= 1'b1;
        end

        alert_irq_reg <= control_irq_enable & (irq_status_alert | irq_status_sample_done);
    end
end

endmodule
