#!/usr/bin/env bash
set -euo pipefail

RTL_TOP="${RTL_TOP:-<RTL_TOP>}"
RTL_DIR="${RTL_DIR:-<RTL_DIR>}"
FILELIST="${FILELIST:-<FILELIST>}"
FW_DIR="${FW_DIR:-.}"
SIM_BUILD_DIR="${SIM_BUILD_DIR:-firmware/validate/build}"
PYTEST_ARGS="${PYTEST_ARGS:-}"
COCOTB_TEST_MODULES="${COCOTB_TEST_MODULES:-}"

mkdir -p firmware/validate
mkdir -p "${SIM_BUILD_DIR}"

if [[ -f "firmware/validate/verilator_build.md" ]]; then
  sed -n '1,220p' firmware/validate/verilator_build.md
fi

if [[ -n "${IDF_PATH:-}" && -f "${IDF_PATH}/export.sh" ]]; then
  # shellcheck disable=SC1090
  source "${IDF_PATH}/export.sh"
fi

if command -v verilator >/dev/null 2>&1; then
  verilator --version
else
  echo "ERROR: verilator not found in PATH" >&2
  exit 127
fi

if [[ "${RTL_TOP}" == "<RTL_TOP>" || "${RTL_DIR}" == "<RTL_DIR>" || "${FILELIST}" == "<FILELIST>" ]]; then
  echo "ERROR: RTL_TOP, RTL_DIR, and FILELIST must be provided via environment overrides" >&2
  exit 2
fi

if [[ -f "${FILELIST}" ]]; then
  echo "Building RTL simulation with file list: ${FILELIST}"
else
  echo "WARNING: FILELIST does not exist as a file: ${FILELIST}"
fi

verilator \
  -Wall \
  --cc \
  --trace \
  --Mdir "${SIM_BUILD_DIR}/verilator" \
  -top-module "${RTL_TOP}" \
  -f "${FILELIST}"

if [[ -f "${FW_DIR}/CMakeLists.txt" || -f "${FW_DIR}/main/CMakeLists.txt" || -d "${FW_DIR}/components" ]]; then
  if command -v idf.py >/dev/null 2>&1; then
    echo "Building firmware in ${FW_DIR}"
    idf.py -C "${FW_DIR}" build
  else
    echo "WARNING: idf.py not found; skipping firmware build" >&2
  fi
else
  echo "WARNING: FW_DIR does not look like an ESP-IDF project; skipping firmware build" >&2
fi

export PYTHONPATH="${PWD}:${PYTHONPATH:-}"
export COCOTB_RESULTS_FILE="${SIM_BUILD_DIR}/results.xml"
export COCOTB_LOG_FILE="${SIM_BUILD_DIR}/cocotb.log"

PYTEST_MODULES=()
if [[ -n "${COCOTB_TEST_MODULES}" ]]; then
  PYTEST_MODULES+=("-k" "${COCOTB_TEST_MODULES}")
fi

python3 -m pytest -q firmware/validate \
  --junitxml="${SIM_BUILD_DIR}/junit.xml" \
  ${PYTEST_ARGS} \
  "${PYTEST_MODULES[@]}"

echo "Co-simulation complete."
echo "Artifacts:"
echo "  ${SIM_BUILD_DIR}/junit.xml"
echo "  ${SIM_BUILD_DIR}/results.xml"
echo "  ${SIM_BUILD_DIR}/cocotb.log"
echo "  ${SIM_BUILD_DIR}/verilator/"
