<!-- ASSUMPTION: RTL simulation is driven by Verilator and cocotb/pytest, with RTL build inputs supplied via RTL_DIR, RTL_TOP, and FILELIST environment variables. -->
<!-- ASSUMPTION: The firmware under test is an ESP-IDF project or component tree located at the repository root or provided via FW_DIR. -->
<!-- ASSUMPTION: The cocotb test entrypoint is discoverable via pytest from firmware/validate (for example, tests under firmware/validate/ or configured by PYTHONPATH). -->

# Co-simulation runner steps

## Prerequisites

Install or make available:

- Verilator
- Python 3.10+ (or compatible with your cocotb/pytest environment)
- cocotb
- pytest
- ESP-IDF toolchain for esp32
- cmake and ninja or make, as used by your ESP-IDF setup

Recommended Python packages:

- cocotb
- pytest
- pytest-xdist optional
- pytest-cov optional

## Environment variables

Provide these overrides as needed:

- `RTL_TOP` : top-level RTL module name
- `RTL_DIR` : RTL source directory
- `FILELIST` : RTL file list or compilation argument file
- `FW_DIR` : firmware project root, if not the repository root
- `IDF_PATH` : ESP-IDF installation path
- `COCOTB_TEST_MODULES` : optional test module(s) for pytest
- `SIM_BUILD_DIR` : optional build directory under `firmware/validate/`

## Exact commands

### 1) Build RTL simulation

If a repository-local guide exists, follow it first:

- `sed -n '1,220p' firmware/validate/verilator_build.md`

Then run the RTL build with the environment overrides provided by the repository contract. A typical Verilator build flow is:

- `verilator --version`
- `mkdir -p firmware/validate/build`
- `verilator -Wall --cc --trace --Mdir firmware/validate/build/verilator \
  -top-module "${RTL_TOP}" \
  -f "${FILELIST}" \
  "${RTL_DIR}"/*.v`

If the project uses a generated makefile or a dedicated file list format, prefer the repository-defined command in `firmware/validate/verilator_build.md`.

### 2) Build firmware

If the firmware is an ESP-IDF project, build it with:

- `source "${IDF_PATH}/export.sh"`
- `idf.py -C "${FW_DIR:-.}" build`

If firmware build artifacts are not required for the cocotb test, this step may be optional; keep it enabled when the testbench consumes generated headers, register maps, or firmware images.

### 3) Run cocotb via pytest

Run the cocotb test suite from `firmware/validate`:

- `python3 -m pytest -q firmware/validate --junitxml=firmware/validate/junit.xml`

If you need to select specific cocotb tests:

- `python3 -m pytest -q firmware/validate -k "${COCOTB_TEST_MODULES}" --junitxml=firmware/validate/junit.xml`

Recommended environment for simulation:

- `export PYTHONPATH="${PWD}:${PYTHONPATH:-}"`
- `export COCOTB_RESULTS_FILE=firmware/validate/results.xml`
- `export COCOTB_LOG_FILE=firmware/validate/cocotb.log`

## Expected outputs

After a successful run, expect these outputs under `firmware/validate/`:

- `cocotb.log` or equivalent simulator/test log
- `results.xml` or cocotb results XML
- `junit.xml` from pytest, if enabled
- Verilator build artifacts under `build/verilator/` or a configured simulation build directory
- Optional coverage outputs if enabled by the RTL flow, such as:
  - `coverage.dat`
  - `coverage.info`
  - `lcov`/HTML coverage reports

## Notes

- The transport contract uses SPI mode 0 and MSB-first full-duplex frames; ensure the testbench and firmware both honor the frame size and response latency requirements.
- The command/data path is held stable until synchronized commit, so cocotb stimulus should preserve values across the SPI frame boundary.
- Do not assume a deployable binary unless the platform contract gate is ready; this task only prepares validation steps and execution scripts.
