# firmware/integration_contract.md

## 1) Contract overview

- Target platform is **ULX3S ECP5 45F + ESP32**, with **ESP32 as the hard CPU** and **FPGA accessed over SPI register transport**.
- Firmware is implemented in **ESP-IDF / C / CMake** targeting **esp32**.
- The current target refinement is **resolved** and the **integration wrapper is ready**; the firmware contract is therefore defined against the existing RTL register collateral.
- The host-to-fabric interface is **SPI mode 0**, **MSB-first**, **full-duplex**, with **216-bit frames** and **12 leading padding bits**.
- Command transactions are **committed on CS rising edge**; response data is observed with a **2-frame latency**.
- CDC behavior is explicitly bounded: command data is held stable until synchronized commit; `spi_cs_n` is two-flop synchronized into core clock; response data is snapshot-held stable for the complete frame.
- Firmware must expose a stable integration contract for **register access**, **stream handshakes**, **status reporting**, **safe mode**, and **boot/bring-up signaling**.
- No deployable binary claim is made beyond the platform contract gate; this document defines the firmware integration contract only.

## 2) Contract version + compatibility policy

**Contract version:** `chiploop.integration_contract.v1`

**Compatibility policy:**
- **Backward-compatible changes only** within a declared minor revision.
- Field additions are allowed only if:
  - they do not change existing bit assignments,
  - they do not alter frame length,
  - they do not change timing/commit semantics.
- Any change to:
  - frame size,
  - bit ordering,
  - commit timing,
  - response latency,
  - reset semantics,
  - error code meanings,
  requires a **major version bump** and host/software coordination.
- Firmware shall publish a contract version string at runtime and reject incompatible host contract versions when version gating is enabled.

## 3) Interfaces

### 3.1 SPI transport contract

| Item | Value |
|---|---|
| Transport | SPI |
| Mode | 0 |
| Bit order | MSB-first |
| Frame size | 216 bits |
| Frame size bytes | 27 bytes |
| Command leading padding | 12 bits |
| Response trailing padding | 3 bits |
| Max SPI clock | 10 MHz |
| Minimum inter-frame delay | 1 us |
| Response latency | 2 frames |
| Command commit | On `spi_cs_n` rising edge |
| Response model | Frame `N+2` returns response to command `N` |

### 3.2 Serialized input bit map

| LSB | Width | Field |
|---:|---:|---|
| 0 | 8 | `reg_addr` |
| 8 | 64 | `reg_wdata` |
| 72 | 1 | `reg_valid` |
| 73 | 1 | `reg_write_en` |
| 74 | 1 | `req_stream_ready` |
| 75 | 1 | `resp_stream_valid` |
| 76 | 128 | `resp_stream_data` |

### 3.3 Serialized output bit map

| LSB | Width | Field |
|---:|---:|---|
| 0 | 1 | `safe_mode` |
| 1 | 1 | `status_irq` |
| 2 | 16 | `actuator_cmd` |
| 18 | 1 | `resp_stream_ready` |
| 19 | 128 | `req_stream_data` |
| 147 | 1 | `req_stream_valid` |
| 148 | 1 | `reg_ready` |
| 149 | 64 | `reg_rdata` |

### 3.4 Register access behavior

| Signal/Field | Direction | Behavior |
|---|---|---|
| `reg_addr` | Host → FPGA | Selects target register address. |
| `reg_wdata` | Host → FPGA | Write data for register write transactions. |
| `reg_valid` | Host → FPGA | Qualifies a register access transaction. |
| `reg_write_en` | Host → FPGA | Selects write when asserted; read otherwise. |
| `reg_ready` | FPGA → Host | Indicates the register transaction is accepted/complete for the sampled command context. |
| `reg_rdata` | FPGA → Host | Read data returned for addressed register. |

**Behavioral requirements**
- A transaction is only valid when `reg_valid=1`.
- When `reg_write_en=1`, `reg_wdata` is consumed for the addressed register write.
- When `reg_write_en=0`, `reg_rdata` must return the addressed register contents.
- Host must treat `reg_rdata` as belonging to the command presented **2 frames earlier**.
- `reg_ready` is a response-side status bit and must be sampled from the corresponding delayed response frame.

### 3.5 Stream handshakes

| Signal/Field | Direction | Behavior |
|---|---|---|
| `req_stream_ready` | Host → FPGA | Host readiness indication for request stream consumption. |
| `req_stream_valid` | FPGA → Host | FPGA asserts when request stream data is valid. |
| `req_stream_data[127:0]` | FPGA → Host | 128-bit request stream payload. |
| `resp_stream_valid` | Host → FPGA | Host indicates response stream data is valid. |
| `resp_stream_ready` | FPGA → Host | FPGA readiness to accept response stream data. |
| `resp_stream_data[127:0]` | Host → FPGA | 128-bit response stream payload. |

**Behavioral requirements**
- Stream payloads are held stable for the complete SPI frame in which they are observed.
- Host-side valid/ready signals are sampled only at frame boundaries.
- Flow-control state must not change mid-frame.
- If stream backpressure is asserted, firmware must preserve payload integrity and not partially consume data.

### 3.6 Status and control outputs

| Signal | Direction | Behavior |
|---|---|---|
| `safe_mode` | FPGA → Host | Indicates firmware/firmware-controlled safe state is active. |
| `status_irq` | FPGA → Host | Indicates an attention event or status change requiring host polling/acknowledge. |
| `actuator_cmd[15:0]` | FPGA → Host | Current actuator command word exported by fabric-side logic. |

**Behavioral requirements**
- `safe_mode=1` indicates the system is in a constrained operation mode and host must not issue non-safe actions.
- `status_irq=1` is level-based status signaling unless otherwise defined by the register collateral.
- `actuator_cmd` is read-only from the host perspective.

### 3.7 Boot and bring-up behavior

| Item | Requirement |
|---|---|
| Reset assertion | May assert asynchronously. |
| Reset release | Must be synchronous and two-flop released. |
| Clocking | Firmware must not assume any SPI transaction before clocks and reset release are stable. |
| Readiness | Firmware must not expose ready/valid semantics until initialization completes. |

## 4) Ownership boundaries

| Area | Firmware ownership | System/Host ownership | Validation ownership |
|---|---|---|---|
| SPI framing and timing | Implement frame packing/unpacking, CS-driven commit semantics | Respect frame size, mode, and latency | Verify frame conformance and timing |
| Register access sequencing | Implement register transaction handling | Provide correct addresses and write data | Check read/write correctness |
| Stream handshake policy | Enforce stable frame-bounded handshakes | Present valid/ready per contract | Stress backpressure and data integrity |
| Safe mode behavior | Assert and maintain `safe_mode` per firmware policy | Treat `safe_mode` as a hard operational constraint | Inject fault/limit conditions and confirm response |
| Status signaling | Emit `status_irq` and status metadata | Poll/acknowledge per host policy | Verify event visibility and clearance |
| Version reporting | Publish contract/firmware version identifiers | Refuse incompatible versions if gating is enabled | Verify version match and mismatch handling |
| Error reporting | Map firmware errors to contract codes | Consume codes and take action | Assert deterministic error mapping |

## 5) Assumptions

- The listed bit maps are the authoritative serialized interface for this target.
- The FPGA RTL collateral already implements the signal names referenced in the target refinement.
- SPI frame packing is fixed at **216 bits** and host software will zero/ignore unused padding bits.
- The `response_latency_frames=2` rule is mandatory for both register and stream-related response observation.
- No extra device-layer jobs or peripheral interfaces are in scope beyond the provided SPI register transport.
- The firmware will be built with ESP-IDF on ESP32 and will not depend on unsupported platform services.
- This document defines integration semantics; it does not define any additional interrupt, DMA, or power-mode subsystem beyond what is explicitly present in the target refinement.

## 6) Validation hooks

| Hook | Method | Pass criteria |
|---|---|---|
| Frame packing check | Unit test serialization against the 216-bit map | All fields land at exact bit offsets; unused bits remain untouched |
| Frame commit test | Drive CS low/high around command frames | Command is applied only on CS rising edge |
| Latency check | Issue command N and sample response at N+2 | Observed response matches the correct delayed command |
| SPI mode check | Logic analyzer capture on SCLK/MOSI/MISO/CS | Mode 0 timing and MSB-first ordering verified |
| Register read/write test | Write known register values, read back later | `reg_rdata` matches expected register state |
| Stream handshake test | Toggle valid/ready across frame boundaries | No mid-frame mutation; payloads remain stable |
| Safe mode test | Force a fault or policy trigger | `safe_mode` asserts and host is constrained accordingly |
| Status signaling test | Generate status events | `status_irq` is observed and cleared/handled per policy |
| Reset/release test | Apply async reset and release | Release is synchronous and system does not mis-sequence transactions |
| Version gating test | Present incompatible contract version | Firmware rejects or enters safe failure path per policy |