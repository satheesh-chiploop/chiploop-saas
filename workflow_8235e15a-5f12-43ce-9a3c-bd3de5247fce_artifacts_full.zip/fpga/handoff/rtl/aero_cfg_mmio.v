module aero_cfg_mmio (
    input         clk,
    input         rst_n,
    input  [7:0] cfg_bus_addr,
    input  [63:0] cfg_bus_wdata,
    input         cfg_bus_valid,
    input         cfg_bus_write,
    output reg [63:0] cfg_bus_rdata,
    output reg        cfg_bus_ready,
    output reg        cfg_bus_rvalid,
    output reg        cfg_enable,
    output reg [1:0] cfg_mode,
    output reg [15:0] cfg_velocity_min,
    output reg [15:0] cfg_velocity_max,
    output reg [15:0] cfg_timeout_cycles,
    output reg [15:0] cfg_clamp_min,
    output reg [15:0] cfg_clamp_max,
    output reg [7:0] cfg_clamp_rate,
    output reg [7:0] cfg_req_limit,
    output reg [7:0] cfg_geometry_token,
    output reg        cfg_ref_mode,
    output reg [15:0] cfg_ref_cmd,
    output reg [7:0] cfg_clear_ack,
    output reg [15:0] cfg_arm_key,
    input             cfg_seq_accepted,
    input  [7:0] fault_status_latched,
    output reg        cfg_valid
);

reg [15:0] nominal_velocity;
reg [7:0]  seq_accepted_shadow;
reg [7:0]  fault_status_shadow;
reg [63:0] read_data_next;
reg [7:0]  addr_index;
reg        cfg_valid_next;

always @(*) begin
    read_data_next = 64'b0;
    case (addr_index)
        8'h00: read_data_next = {36'b0, cfg_arm_key[15:0], cfg_clear_ack[7:0], cfg_ref_mode, cfg_mode[1:0], cfg_enable};
        8'h08: read_data_next = {16'b0, nominal_velocity[15:0], cfg_velocity_max[15:0], cfg_velocity_min[15:0]};
        8'h10: read_data_next = {cfg_req_limit[7:0], cfg_clamp_rate[7:0], cfg_clamp_max[15:0], cfg_clamp_min[15:0], cfg_timeout_cycles[15:0]};
        8'h18: read_data_next = {16'b0, cfg_arm_key[15:0], cfg_clear_ack[7:0], cfg_ref_cmd[15:0], cfg_geometry_token[7:0]};
        8'h20: read_data_next = {48'b0, cfg_valid, (cfg_enable & cfg_valid), fault_status_shadow[7:0], seq_accepted_shadow[7:0]};
        8'h28: read_data_next = 64'b0;
        8'h30: read_data_next = 64'b0;
        8'h38: read_data_next = {48'b0, cfg_ref_cmd[15:0]};
        8'h40: read_data_next = {63'b0, 1'b0};
        default: read_data_next = 64'b0;
    endcase
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        cfg_enable <= 1'b0;
        cfg_mode <= 2'b00;
        cfg_velocity_min <= 16'd0;
        cfg_velocity_max <= 16'd0;
        cfg_timeout_cycles <= 16'd0;
        cfg_clamp_min <= 16'd0;
        cfg_clamp_max <= 16'd0;
        cfg_clamp_rate <= 8'd0;
        cfg_req_limit <= 8'd0;
        cfg_geometry_token <= 8'd0;
        cfg_ref_mode <= 1'b0;
        cfg_ref_cmd <= 16'd0;
        cfg_clear_ack <= 8'd0;
        cfg_arm_key <= 16'd0;
        nominal_velocity <= 16'd3889;
        seq_accepted_shadow <= 8'd0;
        fault_status_shadow <= 8'd0;
        cfg_bus_rdata <= 64'd0;
        cfg_bus_ready <= 1'b0;
        cfg_bus_rvalid <= 1'b0;
        cfg_valid <= 1'b0;
        addr_index <= 8'd0;
        cfg_valid_next <= 1'b0;
    end else begin
        cfg_bus_ready <= cfg_bus_valid;
        cfg_bus_rvalid <= cfg_bus_valid & ~cfg_bus_write;
        addr_index <= cfg_bus_addr;
        if (cfg_seq_accepted)
            seq_accepted_shadow <= seq_accepted_shadow + 8'd1;
        fault_status_shadow <= fault_status_latched;
        if (cfg_bus_valid && cfg_bus_write) begin
            case (cfg_bus_addr)
                8'h00: begin
                    cfg_enable <= cfg_bus_wdata[0];
                    cfg_mode <= cfg_bus_wdata[2:1];
                    cfg_ref_mode <= cfg_bus_wdata[3];
                    cfg_arm_key <= cfg_bus_wdata[19:4];
                    cfg_clear_ack <= cfg_bus_wdata[27:20];
                end
                8'h08: begin
                    cfg_velocity_min <= cfg_bus_wdata[15:0];
                    cfg_velocity_max <= cfg_bus_wdata[31:16];
                    nominal_velocity <= cfg_bus_wdata[47:32];
                end
                8'h10: begin
                    cfg_timeout_cycles <= cfg_bus_wdata[15:0];
                    cfg_clamp_min <= cfg_bus_wdata[31:16];
                    cfg_clamp_max <= cfg_bus_wdata[47:32];
                    cfg_clamp_rate <= cfg_bus_wdata[55:48];
                    cfg_req_limit <= cfg_bus_wdata[63:56];
                end
                8'h18: begin
                    cfg_geometry_token <= cfg_bus_wdata[7:0];
                    cfg_ref_cmd <= cfg_bus_wdata[23:8];
                    cfg_clear_ack <= cfg_bus_wdata[31:24];
                    cfg_arm_key <= cfg_bus_wdata[47:32];
                end
                8'h40: begin
                    cfg_valid <= cfg_bus_wdata[0];
                end
                default: begin
                end
            endcase
        end
        cfg_valid_next = (cfg_velocity_min <= cfg_velocity_max) &&
                         (cfg_velocity_min >= 16'd2000) &&
                         (cfg_velocity_max <= 16'd5500);
        cfg_valid <= cfg_valid_next;
        cfg_bus_rdata <= read_data_next;
    end
end

endmodule
