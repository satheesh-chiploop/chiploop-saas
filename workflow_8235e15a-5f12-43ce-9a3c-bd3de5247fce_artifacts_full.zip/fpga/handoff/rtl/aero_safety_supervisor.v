module aero_safety_supervisor (
    input         clk,
    input         rst_n,
    input         cfg_enable,
    input  [1:0] cfg_mode,
    input  [15:0] cfg_velocity_min,
    input  [15:0] cfg_velocity_max,
    input  [15:0] cfg_timeout_cycles,
    input  [15:0] cfg_clamp_min,
    input  [15:0] cfg_clamp_max,
    input  [7:0] cfg_clamp_rate,
    input  [7:0] cfg_req_limit,
    input         cfg_ref_mode,
    input  [15:0] cfg_ref_cmd,
    input  [7:0] cfg_clear_ack,
    input  [15:0] cfg_arm_key,
    input         cfg_valid,
    input         host_ready,
    input  [15:0] velocity_current,
    input         rsp_frame_valid,
    input         rsp_invalid_format_fault,
    input         timeout_fault,
    input         stale_data_fault,
    input         seq_mismatch_fault,
    input         cfg_fault_clear_accept,
    input  [15:0] validated_cmd_in,
    input         validated_cmd_in_valid,
    output reg        state_normal,
    output reg        state_hold_last_safe,
    output reg        state_safe_fallback,
    output reg [15:0] cmd_out,
    output reg        cmd_out_valid,
    output reg        cmd_clamped,
    output reg [7:0] fault_status_latched,
    output reg        enable_gate_ok,
    output reg        request_arm,
    output reg        rearm_required
);

reg [15:0] last_safe_cmd;
reg [15:0] next_cmd;
reg [1:0] state;
localparam ST_NORMAL = 2'd0;
localparam ST_HOLD   = 2'd1;
localparam ST_SAFE   = 2'd2;

always @(*) begin
    enable_gate_ok = cfg_valid && cfg_enable && (velocity_current >= cfg_velocity_min) && (velocity_current <= cfg_velocity_max) && host_ready && (cfg_velocity_min >= 16'd2000) && (cfg_velocity_max <= 16'd5500);
    request_arm = enable_gate_ok && !fault_status_latched[0] && !fault_status_latched[1] && !fault_status_latched[2];
    rearm_required = (state == ST_SAFE);
    next_cmd = validated_cmd_in_valid ? validated_cmd_in : cfg_ref_cmd;
    if (next_cmd < cfg_clamp_min) begin
        next_cmd = cfg_clamp_min;
    end
    if (next_cmd > cfg_clamp_max) begin
        next_cmd = cfg_clamp_max;
    end
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        state <= ST_SAFE;
        state_normal <= 1'b0;
        state_hold_last_safe <= 1'b0;
        state_safe_fallback <= 1'b1;
        cmd_out <= 16'd0;
        cmd_out_valid <= 1'b0;
        fault_status_latched <= 8'd0;
        last_safe_cmd <= 16'd0;
        cmd_clamped <= 1'b0;
    end else begin
        if (cfg_fault_clear_accept && (cfg_clear_ack != 8'd0) && (cfg_arm_key != 16'd0) && !timeout_fault && !stale_data_fault && !seq_mismatch_fault && !rsp_invalid_format_fault) begin
            fault_status_latched <= 8'd0;
            if (state == ST_SAFE) state <= ST_HOLD;
        end else begin
            fault_status_latched[0] <= fault_status_latched[0] | rsp_invalid_format_fault;
            fault_status_latched[1] <= fault_status_latched[1] | timeout_fault;
            fault_status_latched[2] <= fault_status_latched[2] | stale_data_fault;
            fault_status_latched[3] <= fault_status_latched[3] | seq_mismatch_fault;
        end
        case (state)
            ST_NORMAL: begin
                state_normal <= 1'b1;
                state_hold_last_safe <= 1'b0;
                state_safe_fallback <= 1'b0;
                if (cfg_enable && cfg_valid && enable_gate_ok && validated_cmd_in_valid) begin
                    cmd_out <= next_cmd;
                    cmd_out_valid <= 1'b1;
                    last_safe_cmd <= next_cmd;
                end else begin
                    cmd_out_valid <= 1'b0;
                    state <= ST_HOLD;
                end
                if (rsp_invalid_format_fault || timeout_fault || stale_data_fault || seq_mismatch_fault || !cfg_enable || !cfg_valid) begin
                    state <= ST_SAFE;
                end
            end
            ST_HOLD: begin
                state_normal <= 1'b0;
                state_hold_last_safe <= 1'b1;
                state_safe_fallback <= 1'b0;
                cmd_out <= last_safe_cmd;
                cmd_out_valid <= 1'b0;
                if (cfg_enable && cfg_valid && enable_gate_ok && validated_cmd_in_valid && !(rsp_invalid_format_fault || timeout_fault || stale_data_fault || seq_mismatch_fault)) begin
                    state <= ST_NORMAL;
                end
                if (rsp_invalid_format_fault || timeout_fault || stale_data_fault || seq_mismatch_fault || !cfg_enable || !cfg_valid) begin
                    state <= ST_SAFE;
                end
            end
            default: begin
                state_normal <= 1'b0;
                state_hold_last_safe <= 1'b0;
                state_safe_fallback <= 1'b1;
                cmd_out_valid <= 1'b0;
                if (cfg_fault_clear_accept && (cfg_clear_ack != 8'd0) && (cfg_arm_key != 16'd0) && cfg_enable && cfg_valid) begin
                    state <= ST_HOLD;
                end
            end
        endcase
        cmd_clamped <= cmd_clamped;
    end
end

endmodule
