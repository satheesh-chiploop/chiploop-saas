module aero_req_packer (
    input         clk,
    input         rst_n,
    input         cfg_enable,
    input  [1:0] cfg_mode,
    input  [15:0] cfg_velocity_min,
    input  [15:0] cfg_velocity_max,
    input  [7:0] cfg_geometry_token,
    input         cfg_ref_mode,
    input  [15:0] cfg_ref_cmd,
    input  [7:0] seq_next,
    input         request_arm,
    output reg [127:0] req_data,
    output reg        req_valid,
    input         req_ready,
    output reg        req_inflight,
    output reg [7:0] req_seq_issued
);

reg [15:0] velocity_mid;
reg [15:0] request_payload;

always @(*) begin
    velocity_mid = (cfg_velocity_min + cfg_velocity_max) >> 1;
    request_payload = cfg_ref_mode ? cfg_ref_cmd : velocity_mid;
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        req_data <= 128'd0;
        req_valid <= 1'b0;
        req_inflight <= 1'b0;
        req_seq_issued <= 8'd0;
    end else begin
        if (request_arm && cfg_enable && !req_inflight) begin
            req_seq_issued <= seq_next;
            req_data <= {29'b0, 32'hA0C10001, cfg_geometry_token, cfg_ref_mode, cfg_mode, request_payload, cfg_velocity_min, cfg_velocity_max, seq_next};
            req_valid <= 1'b1;
            req_inflight <= 1'b1;
        end else if (req_valid && req_ready) begin
            req_valid <= 1'b0;
            req_inflight <= 1'b0;
        end else if (!cfg_enable) begin
            req_valid <= 1'b0;
            req_inflight <= 1'b0;
        end
    end
end

endmodule
