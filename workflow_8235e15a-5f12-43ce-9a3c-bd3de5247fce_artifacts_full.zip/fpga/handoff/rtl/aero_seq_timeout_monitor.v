module aero_seq_timeout_monitor (
    input         clk,
    input         rst_n,
    input         req_launch,
    input  [7:0] req_seq_issued,
    input         rsp_frame_valid,
    input  [7:0] rsp_seq_echo,
    input  [15:0] timeout_cycles,
    input         watchdog_enable,
    output reg        outstanding_valid,
    output reg [7:0] outstanding_seq,
    output reg [15:0] age_counter,
    output reg        timeout_fault,
    output reg        stale_data_fault,
    output reg        seq_mismatch_fault,
    output reg        seq_accepted
);

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        outstanding_valid <= 1'b0;
        outstanding_seq <= 8'd0;
        age_counter <= 16'd0;
        timeout_fault <= 1'b0;
        stale_data_fault <= 1'b0;
        seq_mismatch_fault <= 1'b0;
        seq_accepted <= 1'b0;
    end else begin
        seq_accepted <= 1'b0;
        if (req_launch) begin
            outstanding_valid <= 1'b1;
            outstanding_seq <= req_seq_issued;
            age_counter <= 16'd0;
        end else if (outstanding_valid) begin
            age_counter <= age_counter + 16'd1;
        end
        if (outstanding_valid && rsp_frame_valid) begin
            if (rsp_seq_echo == outstanding_seq) begin
                outstanding_valid <= 1'b0;
                seq_accepted <= 1'b1;
                stale_data_fault <= 1'b0;
            end else begin
                seq_mismatch_fault <= 1'b1;
            end
        end
        if (watchdog_enable && outstanding_valid && (age_counter >= timeout_cycles) && (timeout_cycles != 16'd0)) begin
            timeout_fault <= 1'b1;
            stale_data_fault <= 1'b1;
        end
    end
end

endmodule
