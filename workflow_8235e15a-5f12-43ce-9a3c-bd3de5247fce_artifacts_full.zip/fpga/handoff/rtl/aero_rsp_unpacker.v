module aero_rsp_unpacker (
    input         clk,
    input         rst_n,
    input  [127:0] rsp_data,
    input         rsp_valid,
    output reg        rsp_ready,
    output reg [7:0] rsp_seq_echo,
    output reg [7:0] rsp_status_bits,
    output reg [15:0] rsp_drag_summary,
    output reg [15:0] rsp_lift_summary,
    output reg        rsp_frame_valid,
    output reg        rsp_invalid_format_fault,
    input         ref_mode,
    input  [15:0] ref_cmd,
    output reg        ref_cmd_valid
);

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        rsp_ready <= 1'b1;
        rsp_seq_echo <= 8'd0;
        rsp_status_bits <= 8'd0;
        rsp_drag_summary <= 16'd0;
        rsp_lift_summary <= 16'd0;
        rsp_frame_valid <= 1'b0;
        rsp_invalid_format_fault <= 1'b0;
        ref_cmd_valid <= 1'b0;
    end else begin
        rsp_ready <= 1'b1;
        ref_cmd_valid <= ref_mode;
        rsp_frame_valid <= 1'b0;
        if (rsp_valid) begin
            if (rsp_data[127:96] == 32'hC0DEFACE) begin
                rsp_seq_echo <= rsp_data[7:0];
                rsp_status_bits <= rsp_data[15:8];
                rsp_drag_summary <= rsp_data[31:16];
                rsp_lift_summary <= rsp_data[47:32];
                rsp_frame_valid <= 1'b1;
            end else begin
                rsp_invalid_format_fault <= 1'b1;
            end
        end
    end
end

endmodule
