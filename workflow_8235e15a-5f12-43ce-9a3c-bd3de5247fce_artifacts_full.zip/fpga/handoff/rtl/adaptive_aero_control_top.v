module adaptive_aero_control_top (
    input         clk,
    input         clk_rst_n,
    input  [7:0] cfg_bus_addr,
    input  [63:0] cfg_bus_wdata,
    input         cfg_bus_valid,
    input         cfg_bus_write,
    output [63:0] cfg_bus_rdata,
    output        cfg_bus_ready,
    output        cfg_bus_rvalid,
    output [127:0] req_data,
    output        req_valid,
    input         req_ready,
    input  [127:0] rsp_data,
    input         rsp_valid,
    output        rsp_ready,
    output [15:0] act_cmd,
    output [7:0] fault_out,
    input  [7:0] seq_next
);
wire cfg_enable;
wire [1:0] cfg_mode;
wire [15:0] cfg_velocity_min;
wire [15:0] cfg_velocity_max;
wire [15:0] cfg_timeout_cycles;
wire [15:0] cfg_clamp_min;
wire [15:0] cfg_clamp_max;
wire [7:0] cfg_clamp_rate;
wire [7:0] cfg_req_limit;
wire [7:0] cfg_geometry_token;
wire cfg_ref_mode;
wire [15:0] cfg_ref_cmd;
wire [7:0] cfg_clear_ack;
wire [15:0] cfg_arm_key;
wire cfg_valid;
wire cfg_seq_accepted;
wire [7:0] fault_status_latched;
wire req_inflight;
wire [7:0] req_seq_issued;
wire [7:0] rsp_seq_echo;
wire [7:0] rsp_status_bits;
wire [15:0] rsp_drag_summary;
wire [15:0] rsp_lift_summary;
wire rsp_frame_valid;
wire rsp_invalid_format_fault;
wire ref_cmd_valid;

wire outstanding_valid;
wire [7:0] outstanding_seq;
wire [15:0] age_counter;
wire timeout_fault;
wire stale_data_fault;
wire seq_mismatch_fault;
wire seq_accepted;
wire state_normal;
wire state_hold_last_safe;
wire state_safe_fallback;
wire cmd_clamped;
wire enable_gate_ok;
wire request_arm;
wire rearm_required;

wire [127:0] bram_dout;
wire mem_csb;
wire mem_we;
wire [4:0] mem_addr;
wire [127:0] mem_din;
wire mem_read_enable;
wire [63:0] mem_readback;
wire [63:0] cfg_bus_rdata_int;

wire req_launch;
wire [15:0] validated_cmd_in;
wire validated_cmd_in_valid;
wire watchdog_enable;
wire [15:0] velocity_current;
wire cfg_fault_clear_accept;
wire aero_safety_supervisor_request_arm;
assign mem_read_enable = cfg_bus_valid & ~cfg_bus_write & (cfg_bus_addr == 8'h60);
assign mem_csb = ~(cfg_bus_valid & (cfg_bus_write | mem_read_enable));
assign mem_we   = cfg_bus_valid & cfg_bus_write & (cfg_bus_addr == 8'h60);
assign mem_addr = cfg_bus_addr[4:0];
assign mem_din  = {64'b0, cfg_bus_wdata};

aero_cfg_mmio u_cfg (
    .clk(clk),
    .rst_n(clk_rst_n),
    .cfg_bus_addr(cfg_bus_addr),
    .cfg_bus_wdata(cfg_bus_wdata),
    .cfg_bus_valid(cfg_bus_valid),
    .cfg_bus_write(cfg_bus_write),
    .cfg_bus_rdata(cfg_bus_rdata_int),
    .cfg_bus_ready(cfg_bus_ready),
    .cfg_bus_rvalid(cfg_bus_rvalid),
    .cfg_enable(cfg_enable),
    .cfg_mode(cfg_mode),
    .cfg_velocity_min(cfg_velocity_min),
    .cfg_velocity_max(cfg_velocity_max),
    .cfg_timeout_cycles(cfg_timeout_cycles),
    .cfg_clamp_min(cfg_clamp_min),
    .cfg_clamp_max(cfg_clamp_max),
    .cfg_clamp_rate(cfg_clamp_rate),
    .cfg_req_limit(cfg_req_limit),
    .cfg_geometry_token(cfg_geometry_token),
    .cfg_ref_mode(cfg_ref_mode),
    .cfg_ref_cmd(cfg_ref_cmd),
    .cfg_clear_ack(cfg_clear_ack),
    .cfg_arm_key(cfg_arm_key),
    .cfg_seq_accepted(cfg_seq_accepted),
    .fault_status_latched(fault_status_latched),
    .cfg_valid(cfg_valid)
);

aero_req_packer u_req (
    .clk(clk),
    .rst_n(clk_rst_n),
    .cfg_enable(cfg_enable),
    .cfg_mode(cfg_mode),
    .cfg_velocity_min(cfg_velocity_min),
    .cfg_velocity_max(cfg_velocity_max),
    .cfg_geometry_token(cfg_geometry_token),
    .cfg_ref_mode(cfg_ref_mode),
    .cfg_ref_cmd(cfg_ref_cmd),
    .seq_next(seq_next),
    .request_arm(request_arm),
    .req_data(req_data),
    .req_valid(req_valid),
    .req_ready(req_ready),
    .req_inflight(req_inflight),
    .req_seq_issued(req_seq_issued)
);

aero_rsp_unpacker u_rsp (
    .clk(clk),
    .rst_n(clk_rst_n),
    .rsp_data(rsp_data),
    .rsp_valid(rsp_valid),
    .rsp_ready(rsp_ready),
    .rsp_seq_echo(rsp_seq_echo),
    .rsp_status_bits(rsp_status_bits),
    .rsp_drag_summary(rsp_drag_summary),
    .rsp_lift_summary(rsp_lift_summary),
    .rsp_frame_valid(rsp_frame_valid),
    .rsp_invalid_format_fault(rsp_invalid_format_fault),
    .ref_mode(cfg_ref_mode),
    .ref_cmd(cfg_ref_cmd),
    .ref_cmd_valid(ref_cmd_valid)
);

aero_seq_timeout_monitor u_mon (
    .clk(clk),
    .rst_n(clk_rst_n),
    .req_launch(request_arm),
    .req_seq_issued(req_seq_issued),
    .rsp_frame_valid(rsp_frame_valid),
    .rsp_seq_echo(rsp_seq_echo),
    .timeout_cycles(cfg_timeout_cycles),
    .watchdog_enable(cfg_enable),
    .outstanding_valid(outstanding_valid),
    .outstanding_seq(outstanding_seq),
    .age_counter(age_counter),
    .timeout_fault(timeout_fault),
    .stale_data_fault(stale_data_fault),
    .seq_mismatch_fault(seq_mismatch_fault),
    .seq_accepted(seq_accepted)
);

aero_safety_supervisor u_sup (
    .clk(clk),
    .rst_n(clk_rst_n),
    .cfg_enable(cfg_enable),
    .cfg_mode(cfg_mode),
    .cfg_velocity_min(cfg_velocity_min),
    .cfg_velocity_max(cfg_velocity_max),
    .cfg_timeout_cycles(cfg_timeout_cycles),
    .cfg_clamp_min(cfg_clamp_min),
    .cfg_clamp_max(cfg_clamp_max),
    .cfg_clamp_rate(cfg_clamp_rate),
    .cfg_req_limit(cfg_req_limit),
    .cfg_ref_mode(cfg_ref_mode),
    .cfg_ref_cmd(cfg_ref_cmd),
    .cfg_clear_ack(cfg_clear_ack),
    .cfg_arm_key(cfg_arm_key),
    .cfg_valid(cfg_valid),
    .host_ready(req_inflight),
    .velocity_current(rsp_lift_summary),
    .rsp_frame_valid(rsp_frame_valid),
    .rsp_invalid_format_fault(rsp_invalid_format_fault),
    .timeout_fault(timeout_fault),
    .stale_data_fault(stale_data_fault),
    .seq_mismatch_fault(seq_mismatch_fault),
    .cfg_fault_clear_accept(cfg_seq_accepted),
    .validated_cmd_in(rsp_drag_summary),
    .validated_cmd_in_valid(ref_cmd_valid),
    .state_normal(state_normal),
    .state_hold_last_safe(state_hold_last_safe),
    .state_safe_fallback(state_safe_fallback),
    .cmd_out(act_cmd),
    .cmd_out_valid(),
    .cmd_clamped(cmd_clamped),
    .fault_status_latched(fault_status_latched),
    .enable_gate_ok(enable_gate_ok),
    .request_arm(request_arm),
    .rearm_required(rearm_required)
);

aero_req_rsp_fifo_bram u_req_rsp_bram (
    .clk(clk),
    .mem_csb(mem_csb),
    .mem_we(mem_we),
    .mem_addr(mem_addr),
    .mem_din(mem_din),
    .mem_dout(bram_dout)
);

assign mem_readback = bram_dout[63:0];
assign cfg_bus_rdata = (cfg_bus_addr == 8'h60) ? mem_readback : cfg_bus_rdata_int;
assign fault_out = fault_status_latched;

assign cfg_seq_accepted = seq_accepted;

endmodule
