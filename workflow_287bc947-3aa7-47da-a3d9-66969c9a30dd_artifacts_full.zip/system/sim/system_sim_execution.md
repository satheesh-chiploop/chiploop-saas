# System Simulation Execution Report

- Top: `temp_monitor_soc_sim`
- Tests run: 6
- Passed: 5
- Failed: 1
- Total runtime (s): 16.373
- Coverage JSON present: True
- Coverage MD present: True

## Run Matrix
- `system_smoke_test` / seed `1` → FAIL (rc=2, 1.425s)
- `system_smoke_test` / seed `2` → PASS (rc=0, 5.255s)
- `system_smoke_test` / seed `7` → PASS (rc=0, 2.303s)
- `integrated_input_sanity` / seed `1` → PASS (rc=0, 2.386s)
- `integrated_input_sanity` / seed `2` → PASS (rc=0, 2.58s)
- `integrated_input_sanity` / seed `7` → PASS (rc=0, 2.424s)

## Waveforms
- `vv/tb/dump.vcd`
