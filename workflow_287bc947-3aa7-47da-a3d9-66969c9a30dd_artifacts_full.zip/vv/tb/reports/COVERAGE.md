# System Functional Coverage Summary

- Top module: temp_monitor_soc_sim
- Functional coverage: 76.67%
- Bins hit: 23
- Total bins: 30

## Outputs
- alert_irq: samples=5, bins=1/2
- alert_status: samples=5, bins=1/2
- rd_data: samples=5, bins=1/2
- temp_code: samples=5, bins=1/2
- threshold_code: samples=5, bins=1/2

## Inputs
- avdd: samples=5, bins=2/2
- avss: samples=5, bins=2/2
- clk: samples=5, bins=1/2
- rd_addr: samples=5, bins=2/2
- rd_en: samples=5, bins=2/2
- reset_n: samples=5, bins=1/2
- sensor_temp_celsius: samples=5, bins=2/2
- wr_addr: samples=5, bins=2/2
- wr_data: samples=5, bins=2/2
- wr_en: samples=5, bins=2/2

## Registers

## Fields
