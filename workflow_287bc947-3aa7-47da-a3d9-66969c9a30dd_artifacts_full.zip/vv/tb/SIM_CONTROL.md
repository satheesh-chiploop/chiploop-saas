# System Simulation Control

Generated files:
- `run_regression.py`: orchestrates multi-seed runs via `make TESTCASE=...`
- `simulation_manifest.json`: consolidated simulation-control manifest for the integrated system DUT

Key resolved inputs:
- Top module: `temp_monitor_soc_sim`
- System integration intent: `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/287bc947-3aa7-47da-a3d9-66969c9a30dd/55b60703-5a09-4f88-b0fb-f4d551deec2b/digital/system/integration/system_integration_intent.json`
- SoC top (sim): `/root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/287bc947-3aa7-47da-a3d9-66969c9a30dd/55b60703-5a09-4f88-b0fb-f4d551deec2b/digital/system/imported_rtl/temp_monitor_soc_sim.sv`
- RTL file count: `6`

Seed management:
- override with `RANDOM_SEED=<int>`

Usage:
```bash
python run_regression.py --tests system_smoke_test integrated_input_sanity --seeds 1 2 3 4 5
```
