# System Simulation Execution Report

- Top: `temp_monitor_soc_sim`
- Tests run: 6
- Passed: 0
- Failed: 6
- Total runtime (s): 8.255
- Coverage JSON present: False
- Coverage MD present: False

## Run Matrix
- `system_smoke_test` / seed `1` → FAIL (rc=2, 1.405s)
- `system_smoke_test` / seed `2` → FAIL (rc=2, 1.324s)
- `system_smoke_test` / seed `7` → FAIL (rc=2, 1.363s)
- `integrated_input_sanity` / seed `1` → FAIL (rc=2, 1.342s)
- `integrated_input_sanity` / seed `2` → FAIL (rc=2, 1.365s)
- `integrated_input_sanity` / seed `7` → FAIL (rc=2, 1.456s)
