# System Simulation Summary + Coverage

- Top module: temp_monitor_soc_sim
- Status: failed
- Total simulation runs: 6
- Simulation pass count: 0
- Simulation fail count: 6
- Total runtime (s): 8.255
- Coverage status: ok
- Functional coverage %: None
- Coverage bins hit: None
- Coverage total bins: None
- Code line coverage %: None
- Code branch coverage %: None
- Code condition coverage %: None
- Code toggle coverage %: None
- Assertions total: 7
- Assertion failures: 0
- Formal status: fail
- Golden model status: generated
