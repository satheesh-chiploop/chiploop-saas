module temp_sensor_adc_model (
    input  sample_req,
    input  [15:0] sensor_temp_celsius,
    input  avdd,
    input  avss,
    output reg [11:0] adc_code,
    output reg adc_valid
);

    parameter integer LINEAR_GAIN_NUM = 1;
    parameter integer LINEAR_GAIN_DEN = 1;
    parameter integer OFFSET_ERROR_LSB = 0;
    parameter integer GAIN_ERROR_PPM   = 0;
    parameter integer SAMPLE_LATENCY_CYCLES = 2;

    reg pending_sample;
    reg [15:0] latched_temp;
    reg [31:0] latency_count;

    reg [31:0] temp_u32;
    reg signed [63:0] base_code_s64;
    reg signed [63:0] gain_adj_s64;
    reg signed [63:0] offset_adj_s64;
    reg signed [63:0] final_code_s64;
    reg signed [63:0] gain_scaled_s64;
    reg signed [63:0] gain_delta_s64;

    always @(*) begin
        temp_u32 = {16'd0, latched_temp};

        base_code_s64 = $signed({1'b0, temp_u32});
        if (LINEAR_GAIN_DEN != 0) begin
            gain_scaled_s64 = (base_code_s64 * LINEAR_GAIN_NUM) / LINEAR_GAIN_DEN;
        end else begin
            gain_scaled_s64 = base_code_s64;
        end

        gain_delta_s64 = (gain_scaled_s64 * GAIN_ERROR_PPM) / 1000000;
        gain_adj_s64 = gain_scaled_s64 + gain_delta_s64;
        offset_adj_s64 = $signed(OFFSET_ERROR_LSB);
        final_code_s64 = gain_adj_s64 + offset_adj_s64;

        if (final_code_s64 < 0) begin
            adc_code = 12'd0;
        end else if (final_code_s64 > 63'd4095) begin
            adc_code = 12'd4095;
        end else begin
            adc_code = final_code_s64[11:0];
        end
    end

    always @(posedge sample_req) begin
        latched_temp <= sensor_temp_celsius;
        pending_sample <= 1'b1;
        adc_valid <= 1'b0;
        if (SAMPLE_LATENCY_CYCLES <= 0) begin
            latency_count <= 32'd0;
        end else begin
            latency_count <= SAMPLE_LATENCY_CYCLES[31:0];
        end
    end

    always @(posedge sample_req or posedge pending_sample) begin
        if (pending_sample) begin
            if (latency_count == 32'd0) begin
                pending_sample <= 1'b0;
                adc_valid <= 1'b1;
            end
        end
    end

    always @(latched_temp or temp_u32 or base_code_s64 or gain_scaled_s64 or gain_delta_s64 or gain_adj_s64 or offset_adj_s64 or final_code_s64) begin
        if (pending_sample && (latency_count == 32'd0)) begin
            adc_valid = 1'b1;
        end
    end

    always @(sample_req or sensor_temp_celsius or avdd or avss) begin
        if (!sample_req) begin
            if (pending_sample && (latency_count != 32'd0)) begin
                latency_count = latency_count - 32'd1;
                if (latency_count == 32'd1) begin
                    pending_sample = 1'b0;
                    adc_valid = 1'b1;
                end
            end else if (!pending_sample) begin
                adc_valid = 1'b0;
            end
        end
    end

    initial begin
        adc_code = 12'd0;
        adc_valid <= 1'b0;
        pending_sample <= 1'b0;
        latched_temp <= 16'd0;
        latency_count <= 32'd0;
    end

endmodule
