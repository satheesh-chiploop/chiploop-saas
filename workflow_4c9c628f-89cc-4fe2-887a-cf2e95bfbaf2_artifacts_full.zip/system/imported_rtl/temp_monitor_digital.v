module temp_monitor_digital (
    input clk,
    input reset_n,
    input wr_en,
    input [7:0] wr_addr,
    input [15:0] wr_data,
    input rd_en,
    input [7:0] rd_addr,
    input [11:0] adc_code,
    input adc_valid,
    output [15:0] rd_data,
    output sample_req,
    output alert_irq,
    output [11:0] temp_code,
    output [11:0] threshold_code,
    output alert_status
);

reg [7:0] control_reg;
reg [11:0] threshold_reg;
reg [11:0] latest_temp_reg;
reg [11:0] prev_adc_code;
reg prev_adc_valid;
reg [15:0] sample_count_reg;
reg irq_status_alert_reg;
reg irq_status_sample_done_reg;
reg status_sample_done_reg;
reg status_alert_pending_reg;
reg status_adc_valid_seen_reg;
reg status_busy_reg;
reg alert_status_reg;
reg sample_req_reg;
reg [15:0] rd_data_reg;

wire sample_start_pulse;
wire alert_clear_pulse;
wire irq_clear_alert_pulse;
wire irq_clear_sample_done_pulse;
wire sample_pending_next;
wire [11:0] filtered_temp_next;
wire [12:0] adc_sum;
wire [12:0] adc_avg;
wire alert_condition;

assign sample_req = sample_req_reg;
assign alert_irq = alert_irq_reg;
assign temp_code = latest_temp_reg;
assign threshold_code = threshold_reg;
assign alert_status = alert_status_reg;
assign rd_data = rd_data_reg;

assign sample_start_pulse = wr_en && (wr_addr == 8'h00) && wr_data[1];
assign alert_clear_pulse = wr_en && (wr_addr == 8'h00) && wr_data[3];
assign irq_clear_alert_pulse = wr_en && (wr_addr == 8'h18) && wr_data[0];
assign irq_clear_sample_done_pulse = wr_en && (wr_addr == 8'h18) && wr_data[1];
assign adc_sum = {1'b0, prev_adc_code} + {1'b0, adc_code};
assign adc_avg = adc_sum >> 1;
assign filtered_temp_next = adc_valid ? adc_avg[11:0] : latest_temp_reg;
assign alert_condition = adc_valid && (filtered_temp_next > threshold_reg);
assign sample_pending_next = (control_reg[0] && !prev_adc_valid);

reg alert_irq_reg;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        control_reg <= 8'h00;
        threshold_reg <= 12'h000;
        latest_temp_reg <= 12'h000;
        prev_adc_code <= 12'h000;
        prev_adc_valid <= 1'b0;
        sample_count_reg <= 16'h0000;
        irq_status_alert_reg <= 1'b0;
        irq_status_sample_done_reg <= 1'b0;
        status_sample_done_reg <= 1'b0;
        status_alert_pending_reg <= 1'b0;
        status_adc_valid_seen_reg <= 1'b0;
        status_busy_reg <= 1'b0;
        alert_status_reg <= 1'b0;
        sample_req_reg <= 1'b0;
        rd_data_reg <= 16'h0000;
        alert_irq_reg <= 1'b0;
    end else begin
        sample_req_reg <= 1'b0;
        if (wr_en) begin
            case (wr_addr)
                8'h00: begin
                    control_reg[0] <= wr_data[0];
                    control_reg[2] <= wr_data[2];
                    if (wr_data[1]) begin
                        sample_req_reg <= 1'b1;
                    end
                    if (wr_data[3]) begin
                        alert_status_reg <= 1'b0;
                        status_alert_pending_reg <= 1'b0;
                        irq_status_alert_reg <= 1'b0;
                    end
                end
                8'h08: begin
                    threshold_reg <= wr_data[11:0];
                end
                8'h18: begin
                    if (wr_data[0]) begin
                        irq_status_alert_reg <= 1'b0;
                        alert_status_reg <= 1'b0;
                        status_alert_pending_reg <= 1'b0;
                    end
                    if (wr_data[1]) begin
                        irq_status_sample_done_reg <= 1'b0;
                        status_sample_done_reg <= 1'b0;
                    end
                end
                default: begin
                end
            endcase
        end

        if (control_reg[0] && !prev_adc_valid) begin
            sample_req_reg <= 1'b1;
        end

        if (adc_valid) begin
            prev_adc_code <= adc_code;
            prev_adc_valid <= 1'b1;
            latest_temp_reg <= adc_avg[11:0];
            sample_count_reg <= sample_count_reg + 16'h0001;
            status_sample_done_reg <= 1'b1;
            irq_status_sample_done_reg <= 1'b1;
            status_adc_valid_seen_reg <= 1'b1;
            status_busy_reg <= 1'b0;
            if (adc_avg[11:0] > threshold_reg) begin
                irq_status_alert_reg <= 1'b1;
                status_alert_pending_reg <= 1'b1;
                alert_status_reg <= 1'b1;
            end
        end else begin
            prev_adc_valid <= 1'b0;
            status_busy_reg <= sample_pending_next;
        end

        alert_irq_reg <= control_reg[2] && (irq_status_alert_reg || irq_status_sample_done_reg);
        if (!control_reg[2]) begin
            alert_irq_reg <= 1'b0;
        end

        if (rd_en) begin
            case (rd_addr)
                8'h00: rd_data_reg <= {12'h000, control_reg[3], 1'b0, control_reg[2], control_reg[0]};
                8'h04: rd_data_reg <= {12'h000, status_busy_reg, status_adc_valid_seen_reg, status_alert_pending_reg, status_sample_done_reg};
                8'h08: rd_data_reg <= {4'h0, threshold_reg};
                8'h0C: rd_data_reg <= {4'h0, latest_temp_reg};
                8'h10: rd_data_reg <= sample_count_reg;
                8'h14: rd_data_reg <= {14'h0000, irq_status_sample_done_reg, irq_status_alert_reg};
                8'h18: rd_data_reg <= 16'h0000;
                default: rd_data_reg <= 16'h0000;
            endcase
        end
    end
end

endmodule
