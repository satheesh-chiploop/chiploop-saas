# System Software CoSim Trace Validation Summary

- Trace validation status: **pass**
- Scenario count: `9`
- Passed: `6`
- Failed: `0`

## Mismatch categories
- none

## Scenario validations
- `control_service_boot_smoke` → status=`pass` mismatches=`0`
- `control_service_register_rw_basic` → status=`pass` mismatches=`0`
- `control_service_interrupt_propagation_basic` → status=`not_applicable` mismatches=`0`
- `diagnostics_boot_smoke` → status=`pass` mismatches=`0`
- `diagnostics_register_rw_basic` → status=`pass` mismatches=`0`
- `diagnostics_interrupt_propagation_basic` → status=`not_applicable` mismatches=`0`
- `demo_cli_boot_smoke` → status=`pass` mismatches=`0`
- `demo_cli_register_rw_basic` → status=`pass` mismatches=`0`
- `demo_cli_interrupt_propagation_basic` → status=`not_applicable` mismatches=`0`
