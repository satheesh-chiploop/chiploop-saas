# System Software CoSim Harness Summary

- Generated at: `2026-08-12T05:03:14.823614+00:00`
- L1 ready: `None`
- Harness status: `ready`
- Scenario count: `9`

## Blocked dependencies
- none

## Resolved commands
- `control_service_boot_smoke` → `make -C /root/chiploop-backend/artifacts/3c6dfa47-ba1d-4be5-857c-c60b38fc0ff6/a94f1369-129d-4397-bcce-0da3f98ccf1f/10e72e25-18ba-414d-8884-3661cfc9a21c/system/system/restored_rtl_sim/4890f5e4-b717-4faa-9224-b50557a3c91b/vv/tb`
- `control_service_boot_smoke` → `cargo run -p ss_app_control_service -- --scenario control_service_boot_smoke`
- `control_service_register_rw_basic` → `cargo run -p ss_app_control_service -- --scenario control_service_register_rw_basic`
- `diagnostics_boot_smoke` → `cargo run -p ss_app_diagnostics -- --scenario diagnostics_boot_smoke`
- `diagnostics_register_rw_basic` → `cargo run -p ss_app_diagnostics -- --scenario diagnostics_register_rw_basic`
- `demo_cli_boot_smoke` → `cargo run -p ss_app_demo_cli -- --scenario demo_cli_boot_smoke`
- `demo_cli_register_rw_basic` → `cargo run -p ss_app_demo_cli -- --scenario demo_cli_register_rw_basic`
