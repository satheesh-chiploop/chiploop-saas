# System Software CoSim Execution Summary

- Execution status: **partial_pass**
- Scenario count: `9`
- Passed: `6`
- Failed: `0`
- Blocked: `3`

## Scenario results
- `control_service_boot_smoke` → status=`pass` returncode=`0`
- `control_service_register_rw_basic` → status=`pass` returncode=`0`
- `control_service_interrupt_propagation_basic` → status=`blocked` returncode=`-1`
- `diagnostics_boot_smoke` → status=`pass` returncode=`0`
- `diagnostics_register_rw_basic` → status=`pass` returncode=`0`
- `diagnostics_interrupt_propagation_basic` → status=`blocked` returncode=`-1`
- `demo_cli_boot_smoke` → status=`pass` returncode=`0`
- `demo_cli_register_rw_basic` → status=`pass` returncode=`0`
- `demo_cli_interrupt_propagation_basic` → status=`blocked` returncode=`-1`
