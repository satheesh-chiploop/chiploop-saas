# System Software Validation Summary (L2)

- Generated at: `2026-08-12T05:03:43.151393+00:00`
- L1 ready: `False`
- Harness status: `ready`
- Execution status: `partial_pass`
- Trace validation status: `pass`
- Final correctness verdict: **partial_pass**

## Scenario totals

- Scenario count: `9`
- Passed: `6`
- Failed: `0`
- Not applicable: `3`
- Blocked: `0`

## Mismatch categories
- none
