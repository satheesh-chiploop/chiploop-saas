module pwm_fpga_demo (
    input clk,
    output led
);

reg [15:0] slow_counter;
reg [7:0] pwm_counter;
reg [7:0] duty_cycle;
reg direction;
reg led_r;

assign led = led_r;

always @(posedge clk) begin
    pwm_counter <= pwm_counter + 8'd1;
    slow_counter <= slow_counter + 16'd1;

    if (slow_counter == 16'hFFFF) begin
        if (direction == 1'b0) begin
            if (duty_cycle == 8'hFF) begin
                direction <= 1'b1;
                duty_cycle <= duty_cycle - 8'd1;
            end else begin
                duty_cycle <= duty_cycle + 8'd1;
            end
        end else begin
            if (duty_cycle == 8'h00) begin
                direction <= 1'b0;
                duty_cycle <= duty_cycle + 8'd1;
            end else begin
                duty_cycle <= duty_cycle - 8'd1;
            end
        end
    end

    led_r <= (pwm_counter < duty_cycle);
end

endmodule
