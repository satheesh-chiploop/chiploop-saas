# IP Packaging & Handoff Report

- Top: `pwm_fpga_demo`
- Package: `backend/workflows/dcdfa48a-e702-4b19-a413-1e391de45b58/handoff/pwm_fpga_demo_ip_package`
- Zip: `backend/workflows/dcdfa48a-e702-4b19-a413-1e391de45b58/handoff/pwm_fpga_demo_ip_package.zip`

## Bucket counts
- **rtl**: 1
- **spec**: 3
- **arch**: 1
- **microarch**: 1
- **regmap**: 2
- **constraints**: 0
- **power_intent**: 1
- **verification**: 0
- **reports**: 0
- **other**: 7
