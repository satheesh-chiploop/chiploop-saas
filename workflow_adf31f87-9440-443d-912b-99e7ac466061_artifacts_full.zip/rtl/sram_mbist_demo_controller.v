module sram_mbist_demo_controller(
    output wire clk,
    output wire reset_n,
    output wire wr_en,
    output wire [7:0] wr_addr,
    output wire [31:0] wr_data,
    output wire rd_en,
    output wire [7:0] rd_addr,
    output wire bist_start,
    output wire [31:0] rd_data,
    output wire ready,
    output wire bist_done,
    output wire bist_fail,
    output wire irq,
    output wire sram_csb,
    output wire sram_web,
    output wire [5:0] sram_addr,
    output wire [31:0] sram_din,
    input wire [31:0] sram_dout
);
assign clk = 1'b0;
assign reset_n = 1'b0;
assign wr_en = 1'b0;
assign wr_addr = 8'h00;
assign wr_data = 32'h00000000;
assign rd_en = 1'b0;
assign rd_addr = 8'h00;
assign bist_start = 1'b0;
assign rd_data = 32'h00000000;
assign ready = 1'b1;
assign bist_done = 1'b0;
assign bist_fail = 1'b0;
assign irq = 1'b0;
assign sram_csb = 1'b1;
assign sram_web = 1'b1;
assign sram_addr = 6'h00;
assign sram_din = 32'h00000000;
endmodule
