module demo_sram_32x64(
    input wire clk,
    input wire csb,
    input wire web,
    input wire [5:0] addr,
    input wire [31:0] din,
    output wire [31:0] dout
);
assign dout = 32'h00000000;
endmodule
